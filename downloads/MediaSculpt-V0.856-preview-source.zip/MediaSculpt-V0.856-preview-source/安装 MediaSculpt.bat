@echo off
title MediaSculpt installer
cd /d "%~dp0"
set "LOG=%~dp0mediasculpt-diagnostics.log"
echo MediaSculpt installer
echo Log: %LOG%
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows-setup\stop-services.ps1" >nul 2>&1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows-setup\install-with-diagnostics.ps1"
set "EXITCODE=%errorlevel%"
echo.
if "%EXITCODE%"=="0" (echo Installation/update completed.) else (echo Installation/update failed. See mediasculpt-diagnostics.log.)
pause
exit /b %EXITCODE%
