// Standalone DB migration — runs before the server starts.
// Uses only `pg` (always available in production) — no drizzle-kit needed.
import pg from "pg";

const { Client } = pg;

const client = new Client({ connectionString: process.env.DATABASE_URL });
await client.connect();

// ── jobs ──────────────────────────────────────────────────────────────────────
await client.query(`
CREATE TABLE IF NOT EXISTS jobs (
  id                      SERIAL PRIMARY KEY,
  file_path               TEXT NOT NULL,
  output_path             TEXT,
  status                  TEXT NOT NULL DEFAULT 'pending',
  subtitle_mode           TEXT NOT NULL DEFAULT 'auto',
  subtitle_path           TEXT,
  has_embedded_subtitles  BOOLEAN,
  file_size_before        INTEGER,
  file_size_after         INTEGER,
  duration_seconds        REAL,
  progress                REAL,
  error_message           TEXT,
  movie_title             TEXT,
  movie_title_en          TEXT,
  movie_year              INTEGER,
  movie_rating            REAL,
  movie_director          TEXT,
  movie_genres            TEXT,
  movie_overview          TEXT,
  movie_poster            TEXT,
  standardized_name       TEXT,
  tmdb_id                 INTEGER,
  readme_path             TEXT,
  subtitle_source         TEXT,
  translated_subtitle_path TEXT,
  subtitle_pipeline_status TEXT,
  media_type              TEXT NOT NULL DEFAULT 'video',
  main_track_path         TEXT,
  selected_streams        TEXT,
  processing_mode         TEXT NOT NULL DEFAULT 'compress',
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  started_at              TIMESTAMPTZ,
  completed_at            TIMESTAMPTZ
);
`);

// Add any columns introduced after initial creation (safe to run repeatedly)
const jobCols = [
  ["subtitle_source",           "TEXT"],
  ["translated_subtitle_path",  "TEXT"],
  ["subtitle_pipeline_status",  "TEXT"],
  ["media_type",                "TEXT NOT NULL DEFAULT 'video'"],
  ["main_track_path",           "TEXT"],
  ["selected_streams",          "TEXT"],
  ["processing_mode",           "TEXT NOT NULL DEFAULT 'compress'"],
  ["movie_title_en",            "TEXT"],
  ["tmdb_id",                   "INTEGER"],
  ["readme_path",               "TEXT"],
];
for (const [col, def] of jobCols) {
  await client.query(`ALTER TABLE jobs ADD COLUMN IF NOT EXISTS ${col} ${def};`);
}

// ── job_logs ──────────────────────────────────────────────────────────────────
await client.query(`
CREATE TABLE IF NOT EXISTS job_logs (
  id         SERIAL PRIMARY KEY,
  job_id     INTEGER NOT NULL,
  level      TEXT NOT NULL DEFAULT 'info',
  message    TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
`);

// ── config ────────────────────────────────────────────────────────────────────
await client.query(`
CREATE TABLE IF NOT EXISTS config (
  id                      SERIAL PRIMARY KEY,
  watch_directory         TEXT NOT NULL DEFAULT '/downloads',
  output_directory        TEXT NOT NULL DEFAULT '/output',
  handbrake_preset        TEXT NOT NULL DEFAULT 'HQ 1080p30 Surround',
  whisper_model           TEXT NOT NULL DEFAULT 'medium',
  subtitle_language       TEXT NOT NULL DEFAULT 'zh',
  crf                     INTEGER NOT NULL DEFAULT 20,
  encoder                 TEXT NOT NULL DEFAULT 'x264_10bit',
  audio_copy              BOOLEAN NOT NULL DEFAULT TRUE,
  output_format           TEXT NOT NULL DEFAULT 'mkv',
  handbrake_cli_path      TEXT,
  subtitle_edit_cli_path  TEXT,
  tmdb_api_key            TEXT,
  openai_api_key          TEXT,
  deepseek_api_key        TEXT,
  siliconflow_api_key     TEXT,
  zhipu_api_key           TEXT,
  moonshot_api_key        TEXT,
  qwen_api_key            TEXT,
  groq_api_key            TEXT,
  gemini_api_key          TEXT,
  ai_translation_enabled  BOOLEAN NOT NULL DEFAULT FALSE,
  translation_target_lang TEXT NOT NULL DEFAULT 'zh-CN',
  ai_provider             TEXT NOT NULL DEFAULT 'deepseek',
  ai_base_url             TEXT,
  ai_model                TEXT,
  frame_rate              TEXT NOT NULL DEFAULT 'same',
  encoder_preset          TEXT NOT NULL DEFAULT 'slow',
  encoder_tune            TEXT NOT NULL DEFAULT 'film',
  encoder_profile         TEXT NOT NULL DEFAULT 'high10',
  encoder_level           TEXT NOT NULL DEFAULT '4.1'
);
`);

// Add any columns introduced after initial creation (safe to run repeatedly)
const cfgCols = [
  ["openai_api_key",          "TEXT"],
  ["deepseek_api_key",        "TEXT"],
  ["siliconflow_api_key",     "TEXT"],
  ["zhipu_api_key",           "TEXT"],
  ["moonshot_api_key",        "TEXT"],
  ["qwen_api_key",            "TEXT"],
  ["groq_api_key",            "TEXT"],
  ["gemini_api_key",          "TEXT"],
  ["ai_translation_enabled",  "BOOLEAN NOT NULL DEFAULT FALSE"],
  ["translation_target_lang", "TEXT NOT NULL DEFAULT 'zh-CN'"],
  ["ai_provider",             "TEXT NOT NULL DEFAULT 'deepseek'"],
  ["ai_base_url",             "TEXT"],
  ["ai_model",                "TEXT"],
  ["frame_rate",              "TEXT NOT NULL DEFAULT 'same'"],
  ["encoder_preset",          "TEXT NOT NULL DEFAULT 'slow'"],
  ["encoder_tune",            "TEXT NOT NULL DEFAULT 'film'"],
  ["encoder_profile",         "TEXT NOT NULL DEFAULT 'high10'"],
  ["encoder_level",           "TEXT NOT NULL DEFAULT '4.1'"],
];
for (const [col, def] of cfgCols) {
  await client.query(`ALTER TABLE config ADD COLUMN IF NOT EXISTS ${col} ${def};`);
}

await client.end();
console.log("[migrate] Done.");
