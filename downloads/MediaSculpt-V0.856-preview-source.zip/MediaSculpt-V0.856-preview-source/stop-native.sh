#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
for pattern in "artifacts/api-server" "artifacts/video-agent"; do
  pids=$(pgrep -f "$ROOT_DIR/$pattern" || true)
  if [[ -n "$pids" ]]; then kill $pids 2>/dev/null || true; fi
done
echo "MediaSculpt native services stopped."
