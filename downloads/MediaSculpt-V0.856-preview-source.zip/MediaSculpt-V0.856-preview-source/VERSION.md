# Version

> **Version:** V 0.856 · 版本：V 0.856
**Current version: V 0.856** (Windows limited base-installer preview release; not a source archive)

Version rule: the version is bumped by one step (`V 0.796` → `V 0.797` → …) when a new version is released (when the user asks to push). Formal releases start from `V 1.0.XX`. See `docs/product-rules.md` for full details.

All Markdown files in this repository carry a version note in their header (`Version: V 0.856 · 版本：V 0.856`). When releasing a new version, update the version in every Markdown header and this file at the same time.

## V 0.856 release notes

**交付类型：Windows 受限基础安装包，不是源代码发布包。** 普通用户应下载并运行 `MediaSculpt_0.856.0_x64-setup-base.exe`；源码预览压缩包仅供开发、复现和问题定位。

- Unified the two divergent lines: the V 0.855 preview snapshot was folded back into the main line, restoring the i18n routing of hard-coded visible text and the release markers, while keeping the newer metadata, AI-enrichment, and Blu-ray AACS work that only existed on the main line.
- Added tiered metadata resolution (filename, keyless, keyed, AI) with a durable per-title sidecar beside the media, so an already resolved title is served without touching the network.
- Added opt-in AI metadata gap-filling, off by default, that only fills empty fields and records which fields came from the AI.
- Added keyless Douban lookup for Chinese titles, kept every credited director and the billed cast, and mapped OMDb actors, director, and genres.
- Added Blu-ray AACS/BD+ decryption through auto-provisioned libaacs/libbdplus and a KEYDB, with an explicit warning when a disc stays encrypted.
- Updated Windows native version metadata, release markers, installer names, and documentation to V 0.856.
## V 0.852 release notes

- Published the current Smart Workflow, disc-selection, subtitle-routing, and batch-preview fixes as the V 0.852 source release.
- Kept the base package limited to the public toolchain; the personal unlimited installer is not part of this upload.
- Updated Windows native version metadata, release markers, installer names, and documentation to V 0.852.

## V 0.851 release notes

- Added explicit select-all and clear-all stream controls for selected DVD/Blu-ray titles, with subtitle-mode safeguards.
- Preserved distinct DVD titles that share duration and stream layouts by deferring duplicate detection to exact IFO/PGC/Cell physical ranges.
- Kept IFO/PGC duration and chapter metadata authoritative after FFprobe verification.
- Synchronized subtitle-tab, bilingual, and Smart Assistant processing choices; the confirmed subtitle mode now reaches the created job.
- Rejected known local/test placeholder responses before writing translated `.zhs.srt` or bilingual `.ass` files, so a provider test reply cannot be reported as a successful subtitle task.
- Updated the Windows native source and package version to V 0.851.

## V 0.850 release notes

- Added physical DVD `VIDEO_TS` capacity accounting for multi-title Remux selection; unknown mappings remain blocked instead of being guessed.
- Added source-title duration caps to DVD navigation, VOB fallback, and compression pre-Remux paths, with output validation for timestamp overrun.
- Kept processing-mode, stream, subtitle, and chapter selections independent; no processing mode is silently preselected.
- Prevented long smart-analysis notices from overflowing the native window by wrapping and scrolling them inside the notice area.
- Updated the Windows native installer, release markers, documentation, and package name to V 0.850.

## V 0.843 release notes

- Hardened DVD/Blu-ray media orchestration by moving probe, input, chapter, segment, fallback, finalization, and output-health responsibilities into focused tested modules.
- Kept Remux selection explicit for titles, audio, subtitles, and chapters, with conservative DVD identity and physical-size validation.
- Improved poster identity matching and local graphic-subtitle OCR fallback without silently routing graphic subtitles into Whisper.
- Hardened Windows native startup, current-user installation, Node.js 22 packaging requirements, and staged Tauri resource validation.
- Published the verified Windows base and personal installers for this release; AI remains optional and MakeMKV remains outside the application.

## V 0.842 release notes

- Completed the high-risk media pipeline handoff: immutable task snapshots now drive DVD/Blu-ray Remux, compression, subtitle routing, output validation, and partial-success cleanup through shared contracts.
- Added explicit DVD chapter selection metadata for the standalone Remux route, preserving the full source duration while preventing chapter-map drift.
- Verified the final route with complete real DVD samples, including a 20-second MC.14.22 Title 4 Remux retaining video, AC-3 audio, graphic subtitles, and a valid timeline.
- Kept the AI layer optional and kept MakeMKV outside the software and installers.

## V 0.841 release notes

- Split low- and medium-risk settings, scan, and job-detail model responsibilities into focused, tested modules.
- Added documentation for installing and using Whisper, RapidOCR/Tesseract, LibreTranslate, and the bundled media tools.
- Kept the core job orchestration route and media processing contracts unchanged for a separate high-risk refactor.

## V 0.840 release notes

- Added the local preview entitlement system: development source runs remain unlimited, while the packaged preview edition allows 20 successful tasks within 30 days.
- Added local-only usage status, idempotent task settlement, AI call diagnostics, and explicit blocked-task responses. Failed, cancelled, and preview-only jobs do not consume successful-task quota.
- Kept AI optional and direct-to-provider: API keys, prompts, and media data stay on the user's machine and are never routed through MediaSculpt servers.

## V 0.839 release notes

- Added deterministic DVD smart validation before Remux or compression, including real FFprobe/FFmpeg title reads, timestamp checks, and conservative physical `VIDEO_TS` capacity accounting.
- Preserved multiple independent long features, rejected menu/short candidates, and removed only proven duplicate chains.
- Kept AI advisory-only and persisted the validated manifest into downstream processing so title, stream, chapter, Remux, compression, and subtitle steps share one selection.

## V 0.838 release notes

- Published the latest MediaSculpt preview and metadata reliability fixes: continuous preview streaming, IMDb propagation, and proxy-aware poster fallback.
- Kept smart-workflow selection explicit so compression and subtitle actions remain independent and no processing mode is preselected.

## V 0.835 release notes

- Published the Windows baseline package workflow. `windows-setup/package-base.ps1` creates a reproducible source installer archive and SHA-256 file without bundling user data, logs, caches, or downloaded tools.
- Built the real Tauri NSIS baseline installer `MediaSculpt_0.835.0_x64-setup-base.exe`, matching the previous `setup-base.exe` delivery format.
- Reworked the Windows installation and testing instructions around the MediaSculpt product name and the real root launchers.
- Documented V0.835 preview seeking, subtitle rendering, local tool setup, and diagnostic-log collection for real-machine testing.

- Preview seeking now preempts stale segment generation and starts the latest requested segment after the old process exits.
- No-subtitle H.264 previews use a fast video-copy path with AAC audio; subtitle burn-in and unsupported codecs retain the transcoding path.
- Preview prefetch starts earlier to reduce pauses at segment boundaries.

## V 0.832 release notes

- The app window is clamped to the monitor work area at launch, so the bottom is no longer clipped by the taskbar on 1080p screens with 125% scaling.
- Tool downloads now use multi-threaded segmented parallel downloads (Xunlei-style Range segments), which bypass single-connection throttling and resume partial files across mirrors and install attempts; truncated streams are detected instead of being treated as complete, and installs are no longer misreported as failed after a successful download.
- Python setup is serialized across concurrent tool installs and downloads from domestic mirrors (npmmirror / Huawei Cloud / python.org), fixing ENOENT/EBUSY when Whisper, RapidOCR and LibreTranslate install at the same time.
- Install-status polling handles missing tasks gracefully (refreshes tool state instead of showing a failure), and the Tool Manager now shows the purpose of every tool, real download progress, model sizes, a pause button on the job page, and task-completion taskbar notifications.
- A base installer mode (FFmpeg/FFprobe/HandBrakeCLI only) is available for testing on-demand external tool installs.
- AGENTS.md records the standing interaction rules: always explain why + the plan first, and never program or package without explicit user consent.

---

# 版本说明

**当前版本：V 0.856**（Windows 受限基础安装包预览版，不是源代码发布包）

版本规则：发布新版本（用户要求推送）时，版本号步进 +1（`V 0.796` → `V 0.797` → …）。正式版从 `V 1.0.XX` 开始。完整规则见 `docs/product-rules.md`。

本仓库所有 Markdown 文件头部都带有版本说明（`Version: V 0.856 · 版本：V 0.856`）。发布新版本时，需同步更新本文件与所有 Markdown 头部中的版本号。

## V 0.856 更新内容

**交付类型：Windows 受限基础安装包，不是源代码发布包。** 普通用户应下载并运行 `MediaSculpt_0.856.0_x64-setup-base.exe`；源码预览压缩包仅供开发、复现和问题定位。

- 合并两条分支：把 V 0.855 预览快照合回主线，恢复硬编码可见文案的多语言路由和发布标记，同时保留只存在于主线上的元数据、AI 补全和蓝光 AACS 工作。
- 元数据分级解析（文件名、免密钥、需密钥、AI），并在媒体目录旁持久化每部影片的元数据，已解析过的影片不再联网。
- 新增默认关闭的 AI 元数据补全，只填空缺字段，并记录哪些字段来自 AI。
- 新增面向中文片名的免密钥豆瓣查询；保留全部导演署名和完整演员表；补齐 OMDb 的演员、导演和类型映射。
- 通过自动配置 libaacs/libbdplus 与 KEYDB 支持蓝光 AACS/BD+ 解密，光盘仍处于加密状态时给出明确提示。
- Windows 原生版本、发布标记、安装包名称和说明文档统一更新为 V 0.856。
## V 0.852 更新内容

- 将当前智能工作流、光盘流轨选择、字幕处理和视频字幕预览修复纳入 V 0.852 源代码发布。
- 基础包只包含公开基础工具链，本次不上传自用的无限制安装包。
- Windows 原生版本、发布标记、安装包名称和说明文档统一更新为 V 0.852。

## V 0.851 更新内容

- 增加 DVD/蓝光已选标题的流轨全选和清空控制，并遵守字幕模式的流轨限制。
- 延后 DVD 重复标题判断到 IFO/PGC/Cell 物理范围，保留时长和流轨布局相同但内容不同的标题。
- FFprobe 验证完成后仍以 IFO/PGC 的时长和章节为准。
- 字幕页、双语选项和智能助手的处理状态统一同步，确认后的字幕模式会直接写入新建任务。
- 在翻译结果写入 `.zhs.srt` 或双语 `.ass` 前拒绝已知的本机测试占位文本，避免测试返回被误报为成功字幕任务。
- Windows 源代码和程序包版本更新为 V 0.851。

## V 0.850 更新内容

- 增加 DVD 多标题 Remux 的物理 `VIDEO_TS` 容量核算；映射未知时不再猜测容量，而是阻止存在风险的批量任务。
- DVD 导航、VOB 回退和压缩前临时 Remux 均限制为所选标题时长，并在输出校验阶段拒绝时间戳尾部超出。
- 保持处理方式、流轨、字幕和章节选择互相独立，不再静默预选处理方式。
- 智能解析长文字改为自动换行并在提示区域内部滚动，不再撑破原生窗口。
- Windows 原生安装器、发布标记、说明文件和软件版本统一更新为 V 0.850。

## V 0.843 更新内容

- 将媒体编排中的探测、输入、章节、片段、回退、收尾和输出健康检查拆分为职责清晰且有测试的模块，降低大文件和高风险流程的耦合。
- Remux 继续要求用户明确选择标题、音轨、字幕和章节，并保留 DVD 标题身份与物理容量的保守校验。
- 改进海报身份匹配和本地图形字幕 OCR 回退，不再把图形字幕静默转入 Whisper。
- 加固 Windows 原生启动、当前用户安装、Node.js 22 封装前置条件和 Tauri 资源暂存校验。
- 生成并验证本版本 Windows 基础版和个人版安装器；AI 仍为可选模块，MakeMKV 仍不在软件内。

## V 0.842 更新内容

- 完成高风险媒体链路收口：不可变任务快照统一驱动 DVD/蓝光 Remux、压缩、字幕分流、输出校验和部分成功清理。
- 为独立 DVD Remux 增加明确的章节选择元数据路线，保持完整源时长，避免章节映射漂移。
- 使用完整真实 DVD 样本完成最终路线校验，包括 MC.14.22 Title 4 的 20 秒 Remux，视频、AC-3 音轨、图形字幕和时间轴均保留且有效。
- AI 仍是可选增强模块，MakeMKV 仍未进入软件和安装包。

## V 0.841 更新内容

- 拆分设置、扫描和任务详情中的低、中风险纯逻辑与工具管理模块，减少页面组件职责并增加回归测试。
- 补齐 Whisper、RapidOCR/Tesseract、LibreTranslate、FFmpeg/FFprobe/HandBrakeCLI 的安装、选择、模型和隐私说明。
- 保留核心任务编排路由和媒体处理契约不变，为后续高风险拆分保留独立验证边界。

## V 0.840 更新内容

- 增加本地预览版授权状态：源码开发版不限成功任务次数，封装后的预览版为 30 天内 20 次成功任务。
- 增加本地状态显示、幂等扣次、AI 调用统计和明确的额度拦截；失败、取消和仅预览任务不扣成功任务次数。
- AI 仍为可选增强模块：API Key、提示词和媒体数据只在用户本机直连用户配置的服务商，不经过 MediaSculpt 服务端。

## V 0.839 更新内容

- 在 Remux 或压缩之前增加确定性的 DVD 智能校验：真实 FFprobe/FFmpeg 标题读取、时间码检查，以及保守的 `VIDEO_TS` 物理容量核算。
- 保留多个独立的长片，排除菜单和短片段，只删除有充分证据的重复链。
- AI 仅提供建议，并将已验证清单传递给后续处理，使标题、流轨、章节、Remux、压缩和字幕步骤使用同一份选择结果。

## V 0.838 更新内容

- 发布最新 MediaSculpt 预览与元数据可靠性修复：连续预览流、IMDb 传递和支持代理的海报回退。
- 保持智能工作流由用户明确选择，压缩与字幕操作彼此独立且不预先勾选处理模式。

## V 0.835 更新内容

- 增加 Windows 基础版封装流程：`windows-setup/package-base.ps1` 可生成可重复的源码安装包和 SHA-256 校验文件，不会把用户数据、日志、缓存或已下载工具打进压缩包。
- 按上一版 `setup-base.exe` 形式生成真正的 Tauri NSIS 基础安装器 `MediaSculpt_0.835.0_x64-setup-base.exe`。
- 按 MediaSculpt 产品名和当前根目录启动脚本重新整理 Windows 安装与测试说明。
- 补充 V0.835 预览快进、字幕显示、本地工具配置和真实机器诊断日志收集说明。

- 预览快进时会抢占过期的片段生成任务，并在旧进程退出后继续生成最新目标片段。
- 无字幕 H.264 预览使用快速视频流拷贝并将音频转为 AAC；字幕烧录和不兼容编码继续使用转码路径。
- 提前触发预取，减少片段边界处的播放停顿。

## V 0.832 更新内容

- 启动时窗口按显示器工作区自动钳制尺寸：1080P + 125% 缩放下底部不再被任务栏截掉（修复“下部溢出”）。
- 工具下载升级为多线程分段并行（迅雷式 Range 分片），绕开单连接限速；断点续传跨镜像、跨安装尝试保留部分文件；能识别被截断的流而不是当成“下载完成”；“装好了却报安装失败”的判定 bug 已修复。
- Python 安装全局串行化并改用国内镜像（npmmirror / 华为云 / python.org）：Whisper、RapidOCR、LibreTranslate 同时安装时不再出现 ENOENT/EBUSY。
- 安装状态查询不到任务时不再误报失败，改为刷新工具状态；工具管理器显示各工具用途、真实下载进度、Whisper 模型大小；任务详情页增加暂停按钮；任务完成时任务栏闪烁并弹系统通知。
- 新增“基础版”安装包模式（仅 FFmpeg/FFprobe/HandBrakeCLI），便于测试外挂工具按需安装。
- AGENTS.md 记录常驻交互规则：先回答“为什么”与“准备怎么办”，未经明确同意不编程、不封装。

