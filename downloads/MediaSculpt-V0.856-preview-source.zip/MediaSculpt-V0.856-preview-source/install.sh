#!/usr/bin/env bash
set -euo pipefail

# Native setup for macOS/Linux. No container or virtual machine is required.
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
TOOLS_DIR="${MEDIASCULPT_TOOLS_DIR:-${VX_AGENT_TOOLS_DIR:-$HOME/.local/share/MediaSculpt/tools}}"
if [[ "$(uname -s)" == "Darwin" ]]; then
  TOOLS_DIR="${MEDIASCULPT_TOOLS_DIR:-${VX_AGENT_TOOLS_DIR:-$HOME/Library/Application Support/MediaSculpt/tools}}"
fi
OUTPUT_DIR="${MEDIASCULPT_OUTPUT_DIR:-${VX_AGENT_OUTPUT_DIR:-$HOME/Movies/MediaSculpt Output}}"
INPUT_DIR="${MEDIASCULPT_INPUT_DIR:-${VX_AGENT_INPUT_DIR:-$HOME/Downloads}}"
DATABASE_PATH="$ROOT_DIR/data/mediasculpt.db"
# Keep using a database created by an older source checkout if the new file does not exist yet.
if [[ ! -f "$DATABASE_PATH" && -f "$ROOT_DIR/data/vx-agent.db" ]]; then DATABASE_PATH="$ROOT_DIR/data/vx-agent.db"; fi

mkdir -p "$TOOLS_DIR" "$OUTPUT_DIR" "$INPUT_DIR"

cat > "$ROOT_DIR/.env.local" <<EOF
NODE_ENV=development
PORT=8080
DATABASE_DRIVER=sqlite
MEDIASCULPT_DATABASE_PATH=$DATABASE_PATH
MEDIASCULPT_TOOLS_DIR=$TOOLS_DIR
HOST_DOWNLOADS_PATH=$INPUT_DIR
HOST_OUTPUT_PATH=$OUTPUT_DIR
EOF

echo "MediaSculpt native runtime initialized"
echo "Tools directory:  $TOOLS_DIR"
echo "Input directory:  $INPUT_DIR"
echo "Output directory: $OUTPUT_DIR"
echo
echo "Make sure Node.js and pnpm are installed; FFmpeg, HandBrakeCLI and Whisper can be installed from the Settings page."
echo "Start the development services with:"
echo "  cd \"$ROOT_DIR\" && pnpm install && pnpm run build"
echo "  DATABASE_DRIVER=sqlite PORT=8080 pnpm --filter @workspace/api-server run start"
