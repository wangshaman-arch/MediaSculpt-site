use std::{
    fs::{self, File, OpenOptions},
    io::{self, Read, Write},
    net::{Shutdown, TcpListener, TcpStream, ToSocketAddrs},
    path::{Path, PathBuf},
    process::{Child, Command, Stdio},
    sync::{Arc, Mutex},
    thread,
    time::{Duration, Instant},
};

#[cfg(windows)]
use std::os::windows::process::CommandExt;

#[cfg(windows)]
const CREATE_NO_WINDOW: u32 = 0x08000000;

const API_PORT: u16 = 18080;
const HEALTH_PATH: &str = "/api/healthz";
const SHUTDOWN_PATH: &str = "/api/shutdown";
const STARTUP_TIMEOUT: Duration = Duration::from_secs(30);
const REQUEST_TIMEOUT: Duration = Duration::from_millis(1_500);
const POLL_INTERVAL: Duration = Duration::from_millis(250);
const SHUTDOWN_TIMEOUT: Duration = Duration::from_secs(3);
const DIAGNOSTICS_MAX_BYTES: u64 = 8 * 1024 * 1024;
const COMPILED_EDITION: &str = env!("MEDIASCULPT_BUILD_EDITION");

#[derive(Debug, PartialEq, Eq)]
pub enum ShutdownResult {
    Accepted,
    ActiveJobs,
    Unavailable,
}

pub struct SidecarManager {
    child: Mutex<Option<Child>>,
    node_executable: PathBuf,
    api_entry: PathBuf,
    diagnostics_log: PathBuf,
    resource_dir: PathBuf,
}

impl SidecarManager {
    pub fn from_app_paths(resource_dir: PathBuf, app_data_dir: PathBuf) -> Self {
        let sidecar_dir = resource_dir.join("sidecar");
        let node_executable = std::env::var_os("MEDIASCULPT_SIDECAR_NODE")
            .map(PathBuf::from)
            .unwrap_or_else(|| sidecar_dir.join("node").join(node_name()));
        let api_entry = std::env::var_os("MEDIASCULPT_SIDECAR_ENTRY")
            .map(PathBuf::from)
            .unwrap_or_else(|| {
                sidecar_dir
                    .join("api-server")
                    .join("dist")
                    .join("index.mjs")
            });
        Self {
            child: Mutex::new(None),
            node_executable,
            api_entry,
            diagnostics_log: app_data_dir.join("mediasculpt-diagnostics.log"),
            resource_dir,
        }
    }

    pub fn start(&self) -> Result<(), SidecarError> {
        let mut log = open_diagnostics_log(&self.diagnostics_log)?;
        writeln!(
            log,
            "MediaSculpt sidecar start: node={} entry={}",
            self.node_executable.display(),
            self.api_entry.display()
        )?;
        drop(log);
        if let Err(error) = validate_startup_resources(&self.node_executable, &self.api_entry) {
            append_diagnostics(&self.diagnostics_log, &format!("Sidecar startup validation failed: {error}"));
            return Err(error);
        }
        if let Err(error) = ensure_api_port_available(API_PORT) {
            append_diagnostics(&self.diagnostics_log, &format!("Sidecar port validation failed: {error}"));
            return Err(error);
        }
        let api_working_directory = self.api_entry.parent().ok_or_else(|| {
            io::Error::new(
                io::ErrorKind::InvalidInput,
                "API entry has no parent directory",
            )
        })?;
        let node_executable = command_path(&self.node_executable);
        let api_entry = command_path(&self.api_entry);
        let api_working_directory = command_path(api_working_directory);
        let mut command = Command::new(node_executable);
        let database_path = preferred_database_path();
        let tools_dir = preferred_tools_dir();
        let edition = resolve_sidecar_edition(
            std::env::var("MEDIASCULPT_EDITION").ok().as_deref(),
            if cfg!(debug_assertions) { "development" } else { COMPILED_EDITION },
        );
        command
            .current_dir(api_working_directory)
            .arg("--enable-source-maps")
            .arg(api_entry)
            .env("PORT", API_PORT.to_string())
            .env("NODE_ENV", "production")
            .env("MEDIASCULPT_EDITION", edition)
            .env("DATABASE_DRIVER", "sqlite")
            .env("MEDIASCULPT_DATABASE_PATH", &database_path)
            .env("VX_AGENT_DATABASE_PATH", &database_path)
            .env("MEDIASCULPT_TOOLS_DIR", &tools_dir)
            .env("VX_AGENT_TOOLS_DIR", &tools_dir)
            .env("MEDIASCULPT_RESOURCE_DIR", command_path(&self.resource_dir))
            .env("MEDIASCULPT_RELEASE_ID", env!("CARGO_PKG_VERSION"))
            .env(
                "MEDIASCULPT_VERSION",
                concat!("V ", env!("CARGO_PKG_VERSION")),
            )
            .env("MEDIASCULPT_AUTO_SHUTDOWN", "0")
            .env("MEDIASCULPT_DIAGNOSTICS_LOG", &self.diagnostics_log)
            .stdout(Stdio::piped())
            .stderr(Stdio::piped());
        #[cfg(windows)]
        command.creation_flags(CREATE_NO_WINDOW);
        let mut child = command.spawn().map_err(|source| SidecarError::Start {
            executable: self.node_executable.clone(),
            source,
        })?;

        let output_lock = Arc::new(Mutex::new(()));
        if let Some(stdout) = child.stdout.take() {
            spawn_output_pump(stdout, self.diagnostics_log.clone(), output_lock.clone());
        }
        if let Some(stderr) = child.stderr.take() {
            spawn_output_pump(stderr, self.diagnostics_log.clone(), output_lock);
        }

        *self.child.lock().expect("sidecar child mutex poisoned") = Some(child);
        if let Err(error) = self.wait_for_ready() {
            append_diagnostics(&self.diagnostics_log, &format!("MediaSculpt sidecar startup failed: {error}"));
            self.stop_child();
            return Err(error);
        }
        Ok(())
    }

    pub fn request_shutdown(&self) -> ShutdownResult {
        let result = match request(API_PORT, "POST", SHUTDOWN_PATH, REQUEST_TIMEOUT) {
            Ok(202) | Ok(200) => ShutdownResult::Accepted,
            Ok(409) => ShutdownResult::ActiveJobs,
            Ok(_) | Err(_) => ShutdownResult::Unavailable,
        };
        if result == ShutdownResult::Accepted {
            self.wait_for_child_exit();
        }
        result
    }

    fn wait_for_ready(&self) -> Result<(), SidecarError> {
        let deadline = Instant::now() + STARTUP_TIMEOUT;
        loop {
            if let Some(child) = self
                .child
                .lock()
                .expect("sidecar child mutex poisoned")
                .as_mut()
            {
                if let Some(status) = child.try_wait()? {
                    return Err(SidecarError::ExitedBeforeReady(status));
                }
            }
            if let Ok(status) = request(API_PORT, "GET", HEALTH_PATH, REQUEST_TIMEOUT) {
                if is_ready_status(status) {
                    return Ok(());
                }
            }
            if Instant::now() >= deadline {
                return Err(SidecarError::HealthTimeout);
            }
            thread::sleep(POLL_INTERVAL);
        }
    }

    fn stop_child(&self) {
        if let Some(mut child) = self
            .child
            .lock()
            .expect("sidecar child mutex poisoned")
            .take()
        {
            let _ = child.kill();
            let _ = child.wait();
        }
    }

    fn wait_for_child_exit(&self) {
        let deadline = Instant::now() + SHUTDOWN_TIMEOUT;
        loop {
            let child_status = {
                let mut child = self.child.lock().expect("sidecar child mutex poisoned");
                child.as_mut().map(|process| process.try_wait())
            };
            match child_status {
                None | Some(Ok(Some(_))) | Some(Err(_)) => return,
                Some(Ok(None)) if Instant::now() >= deadline => return,
                Some(Ok(None)) => thread::sleep(POLL_INTERVAL),
            }
        }
    }
}

impl Drop for SidecarManager {
    fn drop(&mut self) {
        self.stop_child();
    }
}

#[derive(Debug)]
pub enum SidecarError {
    Start {
        executable: PathBuf,
        source: io::Error,
    },
    MissingResource {
        kind: &'static str,
        path: PathBuf,
    },
    PortInUse {
        port: u16,
        source: io::Error,
    },
    Io(io::Error),
    ExitedBeforeReady(std::process::ExitStatus),
    HealthTimeout,
}

impl From<io::Error> for SidecarError {
    fn from(source: io::Error) -> Self {
        Self::Io(source)
    }
}

impl std::fmt::Display for SidecarError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Start { executable, source } => write!(
                formatter,
                "could not start {}: {source}",
                executable.display()
            ),
            Self::MissingResource { kind, path } => write!(
                formatter,
                "packaged {kind} was not found or is not a file: {}",
                path.display()
            ),
            Self::PortInUse { port, source } => write!(
                formatter,
                "MediaSculpt local API port {port} is unavailable; close the other local API or MediaSculpt instance and retry: {source}"
            ),
            Self::Io(source) => write!(formatter, "sidecar I/O failed: {source}"),
            Self::ExitedBeforeReady(status) => write!(
                formatter,
                "API sidecar exited before becoming ready: {status}"
            ),
            Self::HealthTimeout => write!(
                formatter,
                "API sidecar did not return HTTP 200 from {HEALTH_PATH}"
            ),
        }
    }
}

impl std::error::Error for SidecarError {}

fn node_name() -> &'static str {
    if cfg!(windows) {
        "node.exe"
    } else {
        "node"
    }
}

fn local_data_root() -> Option<PathBuf> {
    if cfg!(windows) {
        std::env::var_os("LOCALAPPDATA").map(PathBuf::from)
    } else {
        std::env::var_os("XDG_DATA_HOME")
            .map(PathBuf::from)
            .or_else(|| std::env::var_os("HOME").map(|home| PathBuf::from(home).join(".local").join("share")))
    }
}

/// Point the sidecar at the branded MediaSculpt data directory. Older installs
/// may have lived under VX-Agent; those were migrated to MediaSculpt so the app
/// uses a single, consistently-named data location on every platform.
fn preferred_database_path() -> PathBuf {
    if let Some(root) = local_data_root() {
        return root.join("MediaSculpt").join("mediasculpt.db");
    }
    PathBuf::from("mediasculpt.db")
}

fn preferred_tools_dir() -> PathBuf {
    if let Some(root) = local_data_root() {
        return root.join("MediaSculpt").join("Tools");
    }
    PathBuf::from("tools")
}

fn command_path(path: &Path) -> PathBuf {
    #[cfg(windows)]
    if let Some(without_verbatim_prefix) = path.to_string_lossy().strip_prefix(r"\\?\") {
        return PathBuf::from(without_verbatim_prefix);
    }
    path.to_path_buf()
}

fn open_diagnostics_log(path: &Path) -> io::Result<File> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    if path.is_file() && fs::metadata(path)?.len() >= DIAGNOSTICS_MAX_BYTES {
        let rotated = PathBuf::from(format!("{}.1", path.display()));
        let _ = fs::remove_file(&rotated);
        if fs::rename(path, rotated).is_err() {
            // A stale process may still hold the old file on Windows. Keep the
            // current log usable even when rotation cannot acquire the lock.
            let _ = OpenOptions::new().write(true).truncate(true).open(path);
        }
    }
    OpenOptions::new().create(true).append(true).open(path)
}

fn append_diagnostics(path: &Path, message: &str) {
    if let Ok(mut log) = open_diagnostics_log(path) {
        let _ = writeln!(log, "{message}");
    }
}

fn spawn_output_pump<R>(mut reader: R, path: PathBuf, output_lock: Arc<Mutex<()>>)
where
    R: Read + Send + 'static,
{
    thread::spawn(move || {
        let mut buffer = [0_u8; 8192];
        loop {
            match reader.read(&mut buffer) {
                Ok(0) | Err(_) => break,
                Ok(count) => {
                    let _guard = output_lock.lock().expect("diagnostics output mutex poisoned");
                    if let Ok(mut log) = open_diagnostics_log(&path) {
                        let _ = log.write_all(&buffer[..count]);
                    }
                }
            }
        }
    });
}

fn validate_startup_resources(node_executable: &Path, api_entry: &Path) -> Result<(), SidecarError> {
    for (kind, path) in [("Node runtime", node_executable), ("API sidecar", api_entry)] {
        if !path.is_file() {
            return Err(SidecarError::MissingResource {
                kind,
                path: path.to_path_buf(),
            });
        }
    }
    Ok(())
}

fn ensure_api_port_available(port: u16) -> Result<(), SidecarError> {
    TcpListener::bind(("127.0.0.1", port))
        .map(|listener| drop(listener))
        .map_err(|source| SidecarError::PortInUse { port, source })
}

fn request(port: u16, method: &str, path: &str, timeout: Duration) -> io::Result<u16> {
    let address = ("127.0.0.1", port)
        .to_socket_addrs()?
        .next()
        .ok_or_else(|| {
            io::Error::new(io::ErrorKind::AddrNotAvailable, "localhost did not resolve")
        })?;
    let mut stream = TcpStream::connect_timeout(&address, timeout)?;
    stream.set_read_timeout(Some(timeout))?;
    stream.set_write_timeout(Some(timeout))?;
    write!(
        stream,
        "{method} {path} HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n"
    )?;
    let _ = stream.shutdown(Shutdown::Write);
    let mut response = String::new();
    stream.read_to_string(&mut response)?;
    parse_status(&response)
}

fn parse_status(response: &str) -> io::Result<u16> {
    response
        .split_whitespace()
        .nth(1)
        .and_then(|status| status.parse().ok())
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "malformed HTTP response"))
}

pub fn is_ready_status(status: u16) -> bool {
    status == 200
}

fn resolve_sidecar_edition(runtime_override: Option<&str>, compiled_edition: &str) -> String {
    runtime_override
        .filter(|edition| matches!(*edition, "development" | "preview"))
        .unwrap_or(compiled_edition)
        .to_string()
}

#[cfg(test)]
mod tests {
    use super::{
        ensure_api_port_available, is_ready_status, resolve_sidecar_edition,
        validate_startup_resources, SidecarError,
    };
    use std::{
        fs,
        io::Write,
        path::PathBuf,
        time::{SystemTime, UNIX_EPOCH},
    };

    #[test]
    fn health_endpoint_treats_only_http_ok_as_ready() {
        assert!(is_ready_status(200));
        assert!(!is_ready_status(503));
    }

    #[test]
    fn packaged_edition_is_used_when_no_runtime_override_exists() {
        assert_eq!(resolve_sidecar_edition(None, "development"), "development");
        assert_eq!(resolve_sidecar_edition(Some("preview"), "development"), "preview");
    }

    #[test]
    fn startup_validation_reports_missing_packaged_resources() {
        let error = validate_startup_resources(
            PathBuf::from("missing-node.exe").as_path(),
            PathBuf::from("missing-index.mjs").as_path(),
        )
        .expect_err("missing resources must stop startup before spawning");
        assert!(matches!(error, SidecarError::MissingResource { .. }));
        assert!(error.to_string().contains("Node runtime"));
    }

    #[test]
    fn startup_port_check_accepts_an_ephemeral_free_port() {
        ensure_api_port_available(0).expect("an ephemeral port should be bindable");
    }

    #[test]
    fn startup_validation_accepts_existing_files() {
        let dir = tempfile_dir();
        let node = dir.join("node.exe");
        let entry = dir.join("index.mjs");
        fs::write(&node, b"node").expect("write test node");
        fs::write(&entry, b"entry").expect("write test entry");
        validate_startup_resources(&node, &entry).expect("existing files should pass");
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn diagnostics_log_rotates_before_it_grows_without_bound() {
        let dir = tempfile_dir();
        let log_path = dir.join("mediasculpt-diagnostics.log");
        fs::write(&log_path, vec![b'x'; super::DIAGNOSTICS_MAX_BYTES as usize])
            .expect("write oversized diagnostics log");
        let mut log = super::open_diagnostics_log(&log_path).expect("open diagnostics log");
        log.write_all(b"new").expect("write current diagnostics log");
        drop(log);
        assert!(dir.join("mediasculpt-diagnostics.log.1").is_file());
        assert!(fs::metadata(&log_path).expect("stat current diagnostics log").len() < 1024);
        let _ = fs::remove_dir_all(dir);
    }

    fn tempfile_dir() -> PathBuf {
        let nonce = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system clock should be after epoch")
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "mediasculpt-sidecar-test-{}-{nonce}",
            std::process::id()
        ));
        fs::create_dir_all(&path).expect("create test directory");
        path
    }
}
