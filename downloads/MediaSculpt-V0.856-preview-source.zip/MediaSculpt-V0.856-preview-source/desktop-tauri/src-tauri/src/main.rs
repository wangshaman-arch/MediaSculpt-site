#![cfg_attr(windows, windows_subsystem = "windows")]

mod sidecar;

use sidecar::{ShutdownResult, SidecarManager};
use std::{
    net::{SocketAddr, TcpStream},
    path::PathBuf,
    process::Command,
    time::Duration,
};
use tauri::{
    Emitter, Manager, RunEvent, Theme, UserAttentionType, WebviewUrl, WebviewWindowBuilder, Window,
    WindowEvent,
};
use tauri_plugin_notification::NotificationExt;

#[cfg(windows)]
mod single_instance {
    use std::{ffi::c_void, os::windows::ffi::OsStrExt, ptr::null_mut};

    const ERROR_ALREADY_EXISTS: u32 = 183;

    #[link(name = "kernel32")]
    extern "system" {
        fn CreateMutexW(
            attributes: *mut c_void,
            initial_owner: i32,
            name: *const u16,
        ) -> *mut c_void;
        fn GetLastError() -> u32;
        fn CloseHandle(handle: *mut c_void) -> i32;
    }

    pub struct Guard(*mut c_void);

    impl Drop for Guard {
        fn drop(&mut self) {
            unsafe {
                let _ = CloseHandle(self.0);
            }
        }
    }

    pub fn acquire() -> Option<Guard> {
        let name: Vec<u16> = std::ffi::OsStr::new("MediaSculpt-Desktop")
            .encode_wide()
            .chain(std::iter::once(0))
            .collect();
        let handle = unsafe { CreateMutexW(null_mut(), 0, name.as_ptr()) };
        if handle.is_null() {
            return None;
        }
        if unsafe { GetLastError() } == ERROR_ALREADY_EXISTS {
            unsafe {
                let _ = CloseHandle(handle);
            }
            return None;
        }
        Some(Guard(handle))
    }
}

#[cfg(not(windows))]
mod single_instance {
    pub struct Guard;

    pub fn acquire() -> Option<Guard> {
        Some(Guard)
    }
}

#[tauri::command]
fn open_path(path: String) -> Result<(), String> {
    let directory = existing_directory(&path)?;

    #[cfg(target_os = "windows")]
    Command::new("explorer.exe")
        .arg(directory)
        .spawn()
        .map_err(|error| format!("could not open path: {error}"))?;

    #[cfg(target_os = "macos")]
    Command::new("open")
        .arg(directory)
        .spawn()
        .map_err(|error| format!("could not open path: {error}"))?;

    #[cfg(all(not(target_os = "windows"), not(target_os = "macos")))]
    Command::new("xdg-open")
        .arg(directory)
        .spawn()
        .map_err(|error| format!("could not open path: {error}"))?;

    Ok(())
}

fn existing_directory(raw_path: &str) -> Result<PathBuf, String> {
    let mut candidate = PathBuf::from(raw_path.trim());
    if candidate.as_os_str().is_empty() {
        return Err("path is empty".into());
    }
    while !candidate.is_dir() {
        if !candidate.pop() {
            return Err(format!("no directory exists for {raw_path}"));
        }
    }
    Ok(candidate)
}

#[tauri::command]
fn set_theme(window: Window, theme: String) -> Result<(), String> {
    let theme = if theme == "morning-light" {
        Theme::Light
    } else {
        Theme::Dark
    };
    window
        .set_theme(Some(theme))
        .map_err(|error| error.to_string())
}

#[tauri::command]
fn minimize_window(window: Window) -> Result<(), String> {
    window.minimize().map_err(|error| error.to_string())
}

#[tauri::command]
fn toggle_maximize_window(window: Window) -> Result<(), String> {
    let maximized = window.is_maximized().map_err(|error| error.to_string())?;
    if maximized {
        window.unmaximize().map_err(|error| error.to_string())
    } else {
        window.maximize().map_err(|error| error.to_string())
    }
}

#[tauri::command]
fn close_window(window: Window) -> Result<(), String> {
    window.close().map_err(|error| error.to_string())
}

#[tauri::command]
fn notify_task_complete(
    app: tauri::AppHandle,
    window: Window,
    title: String,
    body: String,
) -> Result<(), String> {
    // 任务完成后闪烁任务栏图标（Informational：窗口获得焦点后自动停止），再弹系统通知。
    let _ = window.request_user_attention(Some(UserAttentionType::Informational));
    app.notification()
        .builder()
        .title(&title)
        .body(&body)
        .show()
        .map_err(|error| error.to_string())
}

#[tauri::command]
fn is_window_maximized(window: Window) -> Result<bool, String> {
    window.is_maximized().map_err(|error| error.to_string())
}

fn main() {
    let _instance_guard = match single_instance::acquire() {
        Some(guard) => guard,
        None => {
            eprintln!("MediaSculpt is already running; refusing to open a second window.");
            return;
        }
    };

    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            open_path,
            set_theme,
            minimize_window,
            toggle_maximize_window,
            close_window,
            notify_task_complete,
            is_window_maximized
        ])
        .plugin(tauri_plugin_notification::init())
        .setup(|app| {
            let manager = SidecarManager::from_app_paths(
                app.path().resource_dir()?,
                app.path().app_data_dir()?,
            );
            manager.start()?;
            app.manage(manager);
            // 1080P + 125% 缩放下，820 DIP 高度超出工作区（约 816 DIP），
            // 窗口底部会被任务栏截掉。启动时按主显示器工作区（DIP）钳制窗口尺寸。
            let (window_width, window_height) = match app.primary_monitor()? {
                Some(monitor) => {
                    let work_area = monitor.work_area();
                    let scale = monitor.scale_factor();
                    let available_width = work_area.size.width as f64 / scale;
                    let available_height = work_area.size.height as f64 / scale;
                    (
                        1180.0_f64.min(available_width),
                        820.0_f64.min(available_height),
                    )
                }
                None => (1180.0, 820.0),
            };
            // Frameless window so the app's top row fuses with the title bar.
            // The three caption buttons are drawn by the frontend and call the
            // core:window plugin commands (allowed in capabilities/default.json).
            WebviewWindowBuilder::new(app, "main", local_application_url()?)
                .title("MediaSculpt")
                .decorations(false)
                .shadow(true)
                .inner_size(window_width, window_height)
                .min_inner_size(960.0, 640.0)
                .center()
                .build()?;
            Ok(())
        })
        .on_window_event(|window, event| {
            if let WindowEvent::CloseRequested { api, .. } = event {
                let sidecar = window.state::<SidecarManager>();
                if sidecar.request_shutdown() == ShutdownResult::ActiveJobs {
                    api.prevent_close();
                    // 有正在运行的任务时不能关闭：通知前端给出明确提示，而不是静默阻止。
                    let _ = window.emit("shutdown-blocked", ());
                }
            }
        })
        .build(tauri::generate_context!())
        .expect("error while building MediaSculpt")
        .run(|app, event| {
            if let RunEvent::ExitRequested { api, .. } = event {
                let sidecar = app.state::<SidecarManager>();
                if sidecar.request_shutdown() == ShutdownResult::ActiveJobs {
                    api.prevent_exit();
                    let _ = app.emit("shutdown-blocked", ());
                }
            }
        });
}

fn local_application_url() -> Result<WebviewUrl, String> {
    let candidates = if cfg!(debug_assertions) {
        [
            ("http://127.0.0.1:5173", 5173),
            ("http://127.0.0.1:18080", 18080),
        ]
    } else {
        [("http://127.0.0.1:18080", 18080), ("", 0)]
    };

    for (url, port) in candidates {
        if port != 0 && is_local_service_available(port) {
            return Ok(WebviewUrl::External(
                url.parse().expect("local application URL is valid"),
            ));
        }
    }

    Err("MediaSculpt local UI service is unavailable; no window was opened. Start the native launcher again after the sidecar is ready.".into())
}

fn is_local_service_available(port: u16) -> bool {
    let address: SocketAddr = ([127, 0, 0, 1], port).into();
    TcpStream::connect_timeout(&address, Duration::from_millis(250)).is_ok()
}
