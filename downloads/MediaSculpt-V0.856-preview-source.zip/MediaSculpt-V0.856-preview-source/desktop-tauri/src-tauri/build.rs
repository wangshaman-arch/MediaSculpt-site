fn main() {
    println!("cargo:rerun-if-env-changed=MEDIASCULPT_BUILD_EDITION");
    let requested_edition = std::env::var("MEDIASCULPT_BUILD_EDITION").ok();
    let compiled_edition = match requested_edition.as_deref() {
        Some("development") => "development",
        _ => "preview",
    };
    println!("cargo:rustc-env=MEDIASCULPT_BUILD_EDITION={compiled_edition}");
    tauri_build::build()
}
