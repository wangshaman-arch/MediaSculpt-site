# MediaSculpt Native Local Installation

> **Version:** V 0.856 · 版本：V 0.856
MediaSculpt runs directly on Windows, macOS, or Linux hosts. It does not require Docker, virtual machines, or cloud video processing.

## Windows

1. Run `MediaSculpt_0.856.0_x64-setup-base.exe`.
2. Choose the installation directory and finish the installer.
3. Launch MediaSculpt from the desktop or Start menu shortcut.
4. In Settings, choose the input and output directories and verify the local tool paths.
5. Use the installed MediaSculpt diagnostics entry after a failed install or processing job; upload `mediasculpt-diagnostics.log` for diagnosis.

## macOS / Linux

Install Node.js LTS, then run these commands in the project directory:

```bash
chmod +x install.sh
./install.sh
```

Then run:

```bash
./start-native.sh
```

The script starts the API sidecar and the native MediaSculpt desktop window automatically. It does not open a browser. Tools are installed into a MediaSculpt-specific directory for the system user. Stop with `./stop-native.sh`; restart with `./restart-native.sh`.

## Notes

- Video is always processed locally and never uploaded to the cloud.
- SQLite is the default local database; PostgreSQL is not required.
- Whisper models use additional disk space; choose tiny, base, small, medium, or large in the settings page.
- V0.850 is a Windows preview release; the baseline package is not a single-file portable executable.
- Copyright, third-party licensing, and privacy notes: `docs/legal-and-privacy.md`.

---

# MediaSculpt 原生本地安装

MediaSculpt 直接运行在 Windows、macOS 或 Linux 主机上，不需要 Docker、虚拟机或云端视频处理。

## Windows

1. 运行 `MediaSculpt_0.856.0_x64-setup-base.exe`。
2. 选择安装目录并完成安装程序。
3. 从桌面或开始菜单的 MediaSculpt 快捷方式启动。
4. 在设置页选择输入目录和输出目录，并确认本地工具路径。
5. 安装或处理失败后使用已安装的 MediaSculpt 诊断入口，上传 `mediasculpt-diagnostics.log`。

## macOS / Linux

安装 Node.js LTS 后，在项目目录运行：

```bash
chmod +x install.sh
./install.sh
```

然后运行：

```bash
./start-native.sh
```

脚本会自动启动 API 侧车和 MediaSculpt 原生桌面窗口，不会打开浏览器。工具会安装到系统用户的 MediaSculpt 专用目录。停止运行 `./stop-native.sh`，重启运行 `./restart-native.sh`。

## 说明

- 视频始终在本机处理，不会上传云端。
- SQLite 是默认本地数据库，不要求安装 PostgreSQL。
- Whisper 模型会占用额外磁盘空间，可在设置页选择 tiny、base、small、medium 或 large。
- V0.850 是 Windows 预览发布版，基础包不是单文件免安装程序。
- 版权、第三方许可证和隐私说明见：`docs/legal-and-privacy.md`。
