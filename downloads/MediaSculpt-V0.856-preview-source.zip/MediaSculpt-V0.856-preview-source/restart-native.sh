#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
"$ROOT_DIR/stop-native.sh" || true
exec "$ROOT_DIR/start-native.sh"
