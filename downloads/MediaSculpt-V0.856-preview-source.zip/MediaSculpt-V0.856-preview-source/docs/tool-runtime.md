# Tool Runtime and Installation Strategy

> **Version:** V 0.856 · 版本：V 0.856
## Product goal

The goal is not to require users to install ffmpeg, HandBrake, MKVToolNix, Subtitle Edit, or Whisper first and then have the software call them.

The goal is: after installing this software on a new computer, the main features work.

## Recommended strategy

The software package should include or manage a tool runtime.

Options:

1. Bundle core tools in the installer.
2. Automatically download the tool package on first launch.
3. Provide a tool manager in the settings page for detection, repair, and updates.

Recommended priority:

- ffmpeg/ffprobe: core tools, must be available.
- HandBrakeCLI: core compression tool, must be available.
- MKVToolNix: muxing, track processing, chapter and attachment preservation; recommended as a core tool.
- Tesseract OCR: local graphic-subtitle OCR (PGS/VobSub → text SRT). On Windows
  it is a managed tool: the installer runs silently into the managed directory
  and the common language data (tessdata_fast) is downloaded automatically.
  Extra languages can be added per language through the tool manager.
- Subtitle Edit CLI or OCR components: needed for subtitle OCR.
- Whisper or faster-whisper: needed for speech recognition.

## Behavior when a tool is missing

The software must still start.

When a tool is missing, only disable the affected features and show a clear message:

- Missing ffmpeg/ffprobe: disable normal video remux, basic analysis, subtitle extraction, and output validation.
- Missing HandBrakeCLI: disable compression.
- Missing MKVToolNix: disable advanced muxing and chapter/attachment processing.
- Missing OCR: disable graphic subtitle OCR.
- Missing Whisper: disable speech-recognition subtitles.
- Missing AI key: disable AI translation, AI scraping, and AI README, but local processing remains available.

## Tesseract OCR (managed tool, V 0.69+)

- Install: Settings → Tools → Tesseract OCR. The UB-Mannheim Windows installer
  runs with `/S /D=<managed tools>/tesseract`; `tesseract.exe` is then made
  discoverable from the managed tool directory (or `VX_AGENT_TESSERACT_PATH`).
  The runtime also discovers a system-wide Tesseract on Windows (registry
  `InstallPath` or `Program Files\Tesseract-OCR`), so an existing install is
  reused instead of forcing a duplicate download.
- Language data: the install downloads the core set
  (eng / chi_sim / chi_tra / jpn / kor / rus / deu / fra / spa / por / ita /
  nld / pol / tur / ara / heb / tha / vie / ukr / hin). The OCR panel lists
  more languages; missing ones are installed on demand. Downloads prefer the
  accurate `tessdata_best` models and fall back to `tessdata_fast` only when a
  language is not published in the best tier.
- Fail-fast: OCR queue jobs verify engine availability and traineddata before
  any DVD scan or HandBrake transcode, so missing components fail immediately
  with an actionable message.

## faster-whisper and RapidOCR (V 0.79+)

- Speech recognition uses faster-whisper (CTranslate2 + int8) in the managed
  Whisper Python environment. Models are downloaded by the app itself (Node
  fetch) from the HuggingFace mirror into the managed tools directory and
  loaded from the local path — this works on China networks and when security
  software blocks python outbound traffic.
- RapidOCR is a managed tool (its own Python venv, `rapidocr_onnxruntime` +
  onnxruntime). Install from Settings → Tools → RapidOCR（中文 OCR）. It is
  preferred automatically for Chinese graphic subtitle tracks; other languages
  keep using Tesseract unless RapidOCR is chosen explicitly.

## Per-segment language detection (V 0.791+)

- In auto language mode, faster-whisper now splits the audio with VAD and
  detects the language of each speech segment before transcribing it, then
  merges everything into one SRT. Mixed-language audio (e.g. English narration
  with Chinese interviewees) is transcribed in each language instead of forcing
  one language for the whole track. The log reports the segment language
  summary; the SRT is named `*.mixed.srt` (then renamed to the job name) when
  more than one language is detected.
- Version numbering is now `V 0.79X`: each release increments the last digit
  (`V 0.796` → `V 0.797` → …).

## Adaptive bilingual correction (V 0.792+)

- OCR jobs now estimate a recognition quality score (0-100) before the LLM
  pass: RapidOCR uses its built-in per-line confidence, Tesseract uses tsv
  word confidence, and the LLM engine uses text heuristics.
- The bilingual English-reference pass is adaptive: quality ≥ 85 skips it
  (single-track OCR + LLM correction only); quality < 85 enables it. The queue
  logs `识别质量 N（引擎置信度/内容启发式）→ 启用/跳过双语对照`.
- The "Bilingual OCR cross-correction" setting still controls whether the
  adaptive logic runs at all (off = never bilingual).

## Proper-noun background and native English reference (V 0.796+)

- When a bilingual reference is needed, the disc's native English graphic
  subtitle track is OCR'd first (most accurate names); an existing English
  subtitle file in the directory (e.g. a previous Whisper SRT) is only reused
  as a fallback.
- When a job has no confirmed movie metadata, the translation prompt now
  searches TMDb by the filename-derived title + year and attaches the cast /
  character list and the official Chinese title, so proper nouns (actor and
  character Chinese names) are corrected instead of guessed from OCR alone.

## Smart workflow capacity model and local poster (V 0.796+)

- Compression output estimates use the capacity model: documentary 2 GB /
  50 minutes, movie 8 GB (H.265 reduces by 30%), scaled by actual duration.
  Clips under 5 minutes never trigger compression. Documentary sources are
  flagged by genre or filename keywords.
- Local poster cascade: confirmed TMDb poster → TMDb by id → OMDb → Wikipedia
  page image (free, no key). The image is scaled/cropped to the IMDb standard
  1024x1532 JPEG and saved as `poster.jpg` + `folder.jpg` beside the media;
  existing posters are never overwritten and nothing is fabricated.

## AI generation options per job (V 0.796+)

- Every job stores AI generation toggles (`generate_readme`, `generate_poster`,
  `generate_review`). The smart workflow enables Readme + poster by default and
  review off; the assistant chip bar and the job detail panel can change them
  (`PATCH /jobs/:id/ai-options`, `POST /jobs/ai-options/apply-all` for all
  queued jobs).
- Readme (bilingual, with technical parameters) is generated on completion when
  enabled (default); poster downloads when enabled and metadata exists; review
  (`review.txt`, ~500 Chinese characters via the configured LLM) runs only when
  explicitly enabled and skips with a warning when no AI key is configured.
- The smart workflow now jumps to the queue preview (`/jobs/:id`) after job
  creation, and the detail drawer shows the decision basis and estimated output
  size from the plan.

## Horizontal assistant toolbar and workflow confirmation (V 0.796+)

- The AI assistant is a single horizontal toolbar (~64-72px): generate toggles,
  movie title input + year stepper (1920–current year, default 1980),
  processing/subtitle chips, quality/naming chips, and one free-text LLM prompt
  (clicks take priority over the prompt). It scrolls horizontally on narrow
  screens and never grows taller, so the preview layout stays untouched.
- Only smart-workflow jobs auto-jump to the preview page; the preview shows a
  "Smart workflow" confirmation banner with "Confirm & back to queue", and the
  queue list badges workflow-created jobs.

## Ordered processing pipeline and output naming (V 0.797+)

- The assistant processing chips are an ordered multi-select pipeline
  (① Remux → ② Subtitles → ③ Compress, draggable, default order restored on
  open). A pipeline job runs the stages sequentially in one queue task and the
  detail page lists them with per-stage names.
- Remux is kept as the lossless artifact; without Remux the disc is compressed
  directly. Loose video files ignore Remux (chip hidden).
- Subtitle file base names follow the pipeline stage: the Remux base name after
  Remux, or the compressed base name when subtitles run after compression; the
  compression step also emits same-name SRT copies for the compressed file.
- Compression output names no longer include a bitrate label; bit depth is a
  separate token and 8bit is omitted (see `docs/product-rules.md`).

## Compact assistant bar, quality/subtitle entry and source analysis (V 0.798+)

- The assistant bar now has a left poster preview, a title input (defaults to
  the source folder/file name) and a year stepper (year auto-detected from the
  name), the ordered processing pipeline, and two entry buttons "Quality" and
  "Subtitles" instead of inline quality/subtitle chips.
- "Quality" is the four real compression presets and defaults by source type
  (DVD → DVD conversion, Blu-ray/ISO → Blu-ray collection, video → balanced);
  the selection is reflected in the detail drawer and applied to the global
  compression config. The old naming (ZH/EN first) chips were removed.
- The free-text prompt is collapsed by default (click to expand) and the Send
  button was removed; an "Analyze" button sends the source basic info + the
  prompt to the LLM and shows a collapsible basic-info intro below the bar.
- In the task detail page, Quality/Subtitles open the matching drawer section;
  the subtitle strategy (Auto / Force speech / Skip) is auto-selected and can be
  changed with the mouse via `PATCH /jobs/:id/subtitle-mode`.

## Streamlined smart-workflow entry and auto-extraction (V 0.800+)

- The 4-step tab strip and the prominent "Analyze Source" button were removed
  from the workbench entry. Picking or changing the source directory triggers
  smart analysis automatically (debounced; the default directory is never
  scanned just by opening the workbench). Back buttons remain on the
  confirmation steps.
- The assistant auto-extracts the source folder/file name into the title field
  and any year in that name into the year field (editable afterwards).

## Pipeline-driven assistant/detail behavior (V 0.801+)

- The job-page assistant title always defaults to the source folder/file name
  (year auto-extracted from it). The preview toolbar shows only a plain
  "Smart workflow" text hint (the chain toggle button and banner were removed).
- Selecting Remux without Compress greys out the assistant Quality button; the
  detail drawer shows only the sections relevant to the pipeline: Compress →
  compression presets, Subtitles → subtitle strategy, Remux → streams/muxing.
- The separate Subtitles entry button was removed (it duplicated the pipeline
  chip); the chip is now labelled "Subtitles" and keeps its original function.

## Source-sync assistant + restart robustness (V 0.802+)

- The assistant receives the source folder/file name directly: the title and
  year fields follow the DVD/folder name the moment the source changes,
  independent of the plan; manual edits persist until the next source change.
- The detail drawer follows the assistant's live pipeline selection, so
  selecting Remux only hides the compression-preset section immediately.
- The source-run launcher force-releases stale listeners on ports 8080/24403
  before starting and when stopping, so restarting always succeeds (no more
  "port already in use").

## User-driven auto-analysis + explicit source-name sync (V 0.803+)

- Smart-workflow auto-analysis fires only when the user actively picks or edits
  the source (debounced, analyzing the newly selected path). Opening the
  workbench no longer scans the default/watch directory and no longer shows a
  false "no analyzable media files" failure.
- Title/year sync rules: DVD/Blu-ray folder → the disc folder name plus the
  year found in that name; loose video file → the video file name (without
  extension) plus the year found in it.
- V 0.804+: the source folder/file name is the authoritative title/year source
  (plan metadata only fills in when no source name exists), and the assistant
  shows a "Source: <folder/file name>" label under the title input for visible
  confirmation of the sync.
- V 0.805+: title/year re-sync directly from the context source path on every
  source change (guaranteed, no dependency on the plan identity); the analysis
  panel is a structured card with poster/placeholder, source name, type, year,
  duration and track counts; the analysis LLM may return a public poster URL
  (`POSTER_URL=`), used when no metadata poster exists. The launcher has a
  single-instance lock and only force-releases ports when no healthy instance
  exists, so an overlapping launcher can no longer kill the fresh instance.
- V 0.806+: source-name resolution handles VIDEO_TS/BDMV folders (uses the
  parent movie-folder name) and loose video files; year extraction searches the
  source name first, then the parent directory name that shares the title
  (`Documentary.mkv` inside `Documentary.2019` → 2019), then metadata year.
- V 0.808+: poster generation no longer requires API keys — the metadata lookup
  runs a free no-key cascade in parallel (Douban subject-suggest → Wikipedia
  page image → iTunes artwork), with short timeouts so a blocked network never
  hangs analysis; the same cascade writes poster.jpg/folder.jpg at job
  execution, and the analysis LLM may return a public poster URL as a fallback.
- V 0.809+: the assistant source section is two fields — 外语名 (English,
  IMDB-aligned) and 中文名 (Douban-aligned) — plus year, auto-filled from the
  folder/file name; Analyze returns `TITLE_EN/TITLE_ZH/YEAR` which are written
  back into the fields and the year, and Confirm records them into the plan
  identity / job metadata. Layout: generate options above the pipeline,
  Analyze left of Confirm, and the prompt collapsed at the top of the detail
  drawer (drawer width when open).
- V 0.810+: "Generate" is 智能生成 (amber) and "Process" is 任务处理, laid out
  side by side on the right of the bar with a divider (no extra height); the
  analysis bar always spans the full video-column width; all LLM-calling parts
  (smart-generate chips, Analyze, prompt) are amber and turn gray+disabled when
  no AI API key is configured.
- V 0.811+: 智能生成 sits above 任务处理 (top/bottom) with a horizontal divider;
  the smart workflow defaults DVD sources to Remux, and selecting Compress on a
  DVD applies the "DVD 压缩" preset by default; all audio and subtitle tracks
  are kept by default.
- V 0.812+: a small arrow left of the Analyze button toggles the basic-info
  analysis bar (hidden by default, auto-shown after Analyze); the bar always
  spans the full video column width without overlapping or squeezing the detail
  drawer.
- V 0.813+: Settings → 自定义调优 lets users edit the smart-workflow logic
  parameters and LLM prompt templates, restore defaults per item, and
  export/import a JSON file; the backend applies the tuning to the analysis,
  identity, translation and review prompts and to the compression capacity
  model.
- V 0.814+: every tuning field has a plain-language hint (purpose, default,
  required LLM output); the rarely-used tools area merges local tools and
  external tool paths into one section placed at the bottom-right of the
  settings overview.
- V 0.826+: jobs created from the same DVD share one compression-config source
  and the detail preset editor keeps the group display in sync; before
  execution every job is checked for viability (video for Remux/compress,
  subtitle track for extract/OCR, audio for whisper/translate). Non-executable
  jobs are marked `VX_BLOCKED:<code>` with an amber "not executable + reason"
  badge, no tool is run, and the queue continues. The directory picker now has
  a single outer scrollbar (inner ScrollArea removed).
- V 0.826+: the top menu bar is 文件 / 处理 / 设置 / 帮助; the language
  switch lives only in Settings → System → UI language (applies immediately);
  the tools section is also inside the Settings menu (本地工具, between
  API 与数据源 and 智能工作流逻辑) — there is no separate Tools menu; menu
  labels reuse the
  settings section title keys so the dropdown and page stay in sync; the
  compression section in the job detail always shows real compression
  parameters and chips auto-scroll to their section (chapter preview
  included); "export presets" = compression presets, tuning exports are
  per-section (logic parameters and LLM prompts each export/import their own
  JSON, old combined files still import).
- V 0.826+: smart-workflow tuning is fully mouse-operated — six scenario preset
  cards, sliders for the numeric logic parameters, dropdowns for the DVD default
  mode and the DVD compression preset, and mouse-saved custom presets; the smart
  workflow reads the DVD default mode and preset from the tuning config; the LLM
  prompt editors are large resizable textareas with a placeholder list. The
  logic parameters themselves form an editable table: every row can be renamed,
  have its value/range/unit edited, be restored to its default individually, or
  be deleted (a deleted built-in simply falls back to its factory default at
  runtime and can be re-added under "Add parameter → Default parameters"); new
  custom parameters can be added by mouse (key, name, kind number/select/text,
  value, range, options). The whole parameter table is injected into the movie
  analysis / identity-confirmation LLM prompts automatically, and prompt
  templates can reference any parameter with `{{logic.<key>}}` placeholders
  (resolved at runtime in analysis, identity, translation and review prompts).
  Existing configs in the old fixed-field shape migrate automatically. The
  former single "自定义调优" section is split into two Settings sections:
  「智能工作流逻辑」 (scenario cards + parameter table; built-in English keys are
  hidden by default and shown under the row's Advanced panel) and 「LLM 提示词模板」
  (the five prompt editors, each with its usage hint, per-prompt restore, and a
  collapsible glossary explaining the English output markers such as TITLE_EN /
  POSTER_URL / matchReason / confidence). Both sections share one config and
  support restore-all, save, export and import; the shared tuning state lives
  in the Settings page so edits survive switching between the two sections.
- V 0.826+: bilingual subtitle tasks always translate/correct to Simplified
  Chinese (zh-CN) — the "输出语言" setting only affects single-language
  translation, so a bilingual pair can never collapse into two identical
  languages; the bilingual settings card states this rule. Settings page
  reserves bottom padding so the sticky save bar never covers the last card;
  the playing preview stage adapts to the video aspect ratio and centers
  (no conflicting max-height cap, no oversized bottom black band); subtitle /
  info scroll areas keep mouse scrolling but hide the visible scrollbar
  (`scrollbar-none`).
- V 0.832+: English/foreign title extraction (assistant, readme, metadata)
  strips brackets `[](){}` and truncates at the first release marker (year /
  resolution / codec / audio / source like AMZN / episode marker), so release
  groups never leak into titles (`Panic.Room.AMZN.Silence` → `Panic.Room`);
  the analysis chain requires `TITLE_EN` output with a fallback chain and
  never echoes the raw file name. The overview preview is persisted to the job
  and the readme Synopsis uses the same text; readme generation writes
  `readme.txt` + `readme.html` (the HTML card embeds the poster image).
  readme/poster/folder files are all written into a capitalized `MediaInfo`
  subfolder of the media directory; `folder.jpg` is a 400px thumbnail of the
  same poster (legacy byte-identical duplicates auto-converted).

## Recommended tool directory

Windows:

```text
%LOCALAPPDATA%\MediaSculpt\tools\
```

macOS:

```text
~/Library/Application Support/MediaSculpt/tools/
```

Tools should not be scattered across system directories, making updates, uninstalls, and troubleshooting easier.

## AI module

AI is an enhancement module, not a core dependency.

AI can be used for:

- Poster and content scraping.
- IMDb ID, title, and year matching assistance.
- Multi-title disc content identification.
- OCR subtitle correction.
- Subtitle translation.
- Chinese/English README generation.

Without AI, the software should still complete local compression, remux, subtitle preservation, chapter preservation, basic naming, and output.

## Commercialization notes

Third-party tool licenses need review before commercialization:

- ffmpeg GPL/LGPL version differences.
- HandBrake licensing.
- MKVToolNix licensing.
- Subtitle Edit licensing.
- Whisper model and runtime licensing.
- IMDb/TMDb/OMDb data interface terms.

A safer approach: the software manages tool downloads and path configuration, and asks the user to confirm third-party licenses when necessary.

---

# 工具运行时与安装策略

## 产品目标

目标不是要求用户先安装 ffmpeg、HandBrake、MKVToolNix、Subtitle Edit、Whisper 后再让软件去调用它们。

目标是：一台新电脑安装本软件后，就能完成主要功能。

## 推荐策略

软件本体应包含或管理一套工具运行时。

可选方案：

1. 安装包内置核心工具
2. 首次启动时自动下载工具包
3. 设置页提供工具管理器，允许检测、修复、更新工具

推荐优先级：

- ffmpeg/ffprobe：核心工具，必须可用
- HandBrakeCLI：压缩核心工具，必须可用
- MKVToolNix：封装、轨道处理、章节和附件保留，建议作为核心工具
- Subtitle Edit CLI 或 OCR 组件：字幕 OCR 需要
- Whisper 或 faster-whisper：语音识别需要

## 缺失工具时的行为

软件必须可以启动。

缺少某个工具时，只禁用对应功能，并给出明确提示：

- 缺 ffmpeg/ffprobe：禁用普通视频 remux、基础分析、字幕提取和输出校验
- 缺 HandBrakeCLI：禁用压缩
- 缺 MKVToolNix：禁用高级封装、章节附件处理
- 缺 OCR：禁用图形字幕 OCR
- 缺 Whisper：禁用语音识别字幕
- 缺 AI Key：禁用 AI 翻译、AI 刮削、AI README，但本地处理继续可用

## 工具目录建议

Windows：

```text
%LOCALAPPDATA%\MediaSculpt\tools\
```

macOS：

```text
~/Library/Application Support/MediaSculpt/tools/
```

工具不应散落在系统目录里，方便更新、卸载和排错。

## AI 模块

AI 是增强模块，不是核心依赖。

AI 可用于：

- 封面和内容刮削
- IMDb ID、标题、年份辅助匹配
- 光盘多 title 内容识别
- OCR 字幕纠错
- 字幕翻译
- 中英文 README 生成

没有 AI 时，软件仍应完成本地压缩、remux、字幕保留、章节保留、基础命名和输出。

## 商业化注意

商业化前需要确认第三方工具授权：

- ffmpeg 的 GPL/LGPL 版本差异
- HandBrake 授权
- MKVToolNix 授权
- Subtitle Edit 授权
- Whisper 模型和运行库授权
- IMDb/TMDb/OMDb 等数据接口条款

更稳妥的方式是：软件管理工具下载和路径配置，必要时让用户确认第三方许可。

## 有序处理流水线与输出命名（V 0.797+）

- 助手处理选项改为可多选的有序流水线（① Remux → ② 字幕 → ③ 压缩，可拖动，
  每次打开恢复默认顺序）。流水线任务在一个队列任务中按阶段顺序执行，
  详情页展示各阶段名称。
- Remux 作为无损版最终产物保留；未勾选 Remux 时直接压缩原盘。单个视频文件忽略 Remux（隐藏该选项）。
- 字幕文件基准名跟随流水线所在阶段：Remux 之后用 Remux 名；字幕在压缩之后则用压缩版名；
  压缩完成后还会自动为压缩版生成同名字幕副本。
- 压缩版文件名不再包含码率；位深作为独立标签，8bit 省略（详见 `docs/product-rules.md`）。

## 紧凑助手条、画质/字幕入口与源分析（V 0.798+）

- 助手条改为：左侧海报预览；片名输入框（默认取源文件夹/文件名，可改）与年代步进器
  （年份从名字自动识别）；有序处理流水线；以及“画质”“字幕”两个入口按钮（不再内联显示选项）。
- “画质”就是四个真实压缩预设，并按来源默认预选（DVD→DVD转制、蓝光/ISO→蓝光收藏、
  视频→综合均衡），选择同步到详情抽屉并写入全局压缩配置。旧的“中文/英文优先”命名选项已删除。
- 提示词默认收起（点击展开），发送按钮删除（由“分析”覆盖）；新增“分析”按钮：
  把源文件基本信息＋提示词发给 LLM，在条下方生成可折叠的基本信息简介。
- 任务详情页：点画质/字幕打开右侧对应区块；字幕策略（自动/强制语音/跳过）按智能逻辑自动预选，
  可用鼠标修改（新增 `PATCH /jobs/:id/subtitle-mode` 接口）。

## 精简智能工作流入口与自动提取（V 0.800+）

- 工作台入口的“四步选项卡”与醒目的“分析来源”按钮已删除；选择/修改来源目录后自动开始智能分析
  （防抖触发；仅打开工作台不会扫描默认目录）。确认步骤仍保留“上一步/重新选择来源”返回按钮。
- 助手自动把源文件/文件夹名填入片名，并把名字里的年份自动提取到年代栏（之后仍可手动修改）。

## 流水线驱动的助手/详情行为（V 0.801+）

- 任务页助手片名始终默认取源文件/文件夹名（年份自动从名字提取）。预览工具栏只显示
  “智能工作流”文字提示（删除切换按钮与链路横幅）。
- 只选 Remux 未选压缩时，助手“画质”按钮置灰；右侧详情栏只显示与流水线相关的区块：
  压缩→压缩预设、字幕→字幕策略、Remux→流轨/封装。
- 删除独立的“字幕”入口按钮（与流水线“字幕”chip 重复）；chip 文字改为“字幕”，功能不变。

## 源同步助手与重启健壮性（V 0.802+）

- 助手直接接收源文件/文件夹名：来源一变，片名与年代立即跟随 DVD 文件夹名（不依赖计划）；
  手动修改在源不变时保留。
- 右侧详情跟随助手当前流水线选择：只选 Remux 时压缩预设区立即隐藏。
- 桌面启动器在启动前与停止时强制释放 8080/24403 的残留监听进程与旧窗口，
  关闭窗口后再启动永远可用（不再出现 “port already in use”）。

## 用户驱动的自动分析与明确的源名同步（V 0.803+）

- 智能工作流只在用户主动选择/修改来源时自动分析（防抖，且分析新选择的路径）。
  打开工作台不再扫描默认/监视目录，也不再出现虚假的“没有找到可分析媒体文件”失败。
- 片名/年代同步规则：DVD/蓝光文件夹 → 取光碟文件夹名及名字中的年份；
  单个视频文件 → 取视频文件名（去掉扩展名）及名字中的年份。
- V 0.804+：片名/年代以源文件（文件夹）名为唯一权威来源（仅当源名为空时才回退到计划元数据），
  并在片名输入框下方显示“来源：文件夹名”，同步结果直观可见。
- V 0.805+：片名/年代每次来源变化都直接从上下文源路径重新同步（保证生效，不依赖计划识别名）；
  分析面板升级为结构化卡片（左侧海报或占位、右侧来源名/类型/年代/时长/音轨/字幕轨 + LLM 简介）；
  分析 LLM 可返回公开海报 URL（`POSTER_URL=`），无元数据海报时使用。启动器增加单实例锁，
  仅在没有健康实例时才强制释放端口，重叠启动不再误杀新实例。
- V 0.806+：源名解析兼容 VIDEO_TS/BDMV 文件夹（取上层影片文件夹名）与单个视频文件；
  年代提取顺序：源名 → 与片名同名的上级目录名（如 `Documentary.mkv` 位于 `Documentary.2019` 目录 → 2019）→ 元数据年代。
- V 0.808+：海报生成不再依赖 API Key —— 元数据查找并行运行免 Key 海报级联
  （豆瓣 subject_suggest → Wikipedia 页图 → iTunes 封面），短超时保证网络受限时不挂起分析；
  任务执行时同一级联写入 poster.jpg/folder.jpg；分析 LLM 还可返回公开海报 URL 兜底。
- V 0.809+：助手来源区拆为 外语名（英文，IMDB 对齐）与 中文名（豆瓣对齐）两栏 + 年代，
  由目录/文件名自动填充；点“分析”后 LLM 返回 `TITLE_EN/TITLE_ZH/YEAR` 并回写两栏与年代，
  点“确认”写入计划身份/任务元数据。布局：生成选项在处理流水线上方，分析在确认左侧，
  提示词折叠在详情栏顶部（展开占详情栏宽）。
- V 0.810+：“生成”改为“智能生成”（琥珀色）、“处理”改为“任务处理”，两者横排在助手条右侧并用竖线分隔
  （不增加栏高）；基本信息分析栏始终横跨整个视频列；所有调用 LLM 的部分（智能生成、分析、提示词）
  使用琥珀色，未配置 AI API Key 时置灰且不可选。
- V 0.811+：智能生成在上、任务处理在下（上下关系，中间横线分隔）；智能工作流对 DVD 源默认选 Remux；
  点选压缩时自动应用“DVD 压缩”预设；默认保留全部音轨与字幕轨道。
- V 0.812+：分析按钮左侧新增小的展开/收起箭头，点击才显示“基本信息分析栏”（默认隐藏，分析后自动展开）；
  分析栏始终横跨视频列全宽，不遮挡、不挤占详情栏。
- V 0.813+：设置 → 自定义调优：可编辑智能工作流逻辑参数与 LLM 提示词模板（逐项恢复默认、
  导出/导入 JSON 文件）；后端据此应用于分析/身份确认/字幕翻译/影评提示词与压缩容量模型。
- V 0.814+：调优界面每个字段都带通俗说明（用途/默认值/LLM 必输出项）；不常用的工具区合并为
  “本地工具 + 外部工具路径”一个栏，并移到设置概览右下角。
- V 0.826+：同一 DVD 创建的任务共用一套压缩配置，详情页预设编辑会保持同组显示同步；
  执行前逐任务做可执行性检查（Remux/压缩需视频流、字幕提取/OCR 需字幕轨、语音识别/翻译需音轨），
  不可执行的任务标记 `VX_BLOCKED:<code>`，以琥珀色“不可执行 + 原因”徽标显示，不运行任何工具、
  不阻塞队列，可在队列中单独改模式后重试；选择目录对话框合并为单条最外层滚动条（移除内部 ScrollArea）。
- V 0.826+：顶部菜单栏为 文件 / 处理 / 设置 / 帮助；语言切换只保留在 设置→系统→界面语言
  （选择即生效）；本地工具也并入“设置”菜单（位于“API 与数据源”与“智能工作流逻辑”之间），不再有单独的“工具”菜单；
  菜单项复用设置分区标题 key，下拉与界面保持同步；任务详情压缩区永远显示真实压缩参数，
  点处理芯片自动滚动到对应区块（含章节预览）；“导出预设”= 压缩预设，调优按分区导出/导入
  （逻辑参数与 LLM 提示词各自导出，兼容旧版整份文件）。
- V 0.826+：智能工作流调优完全鼠标操作——六个场景预设卡、数值参数滑条、DVD 默认处理与压缩预设下拉、
  鼠标另存/删除自定义预设；智能工作流读取调优配置中的 DVD 默认处理与压缩预设；LLM 提示词为大文本编辑区
  并附占位符列表。逻辑参数本身为可编辑参数表：每行可改名、改数值/范围/单位、逐项恢复默认、删除
  （内置参数删除后运行时自动使用出厂默认值，可在“添加参数 → 默认参数”中找回）；可鼠标新增自定义参数
  （标识、名称、类型 数值/下拉/文本、数值、范围、选项）。整张参数表会自动注入影片分析/资料确认的
  LLM 提示，提示词模板可用 `{{logic.<标识>}}` 占位符引用任意参数（分析、资料确认、翻译、影评提示词
  运行时都会替换）。旧版固定字段配置自动迁移为新格式。原“自定义调优”已拆成两个设置分区：
  「智能工作流逻辑」（场景卡 + 参数表；内置参数英文 key 默认隐藏，收在每行的“高级”里）与
  「LLM 提示词模板」（五个提示词编辑器，各带用途说明、逐项恢复默认，并提供可折叠的
  “这些英文标记是什么意思”释义表，解释 TITLE_EN / POSTER_URL / matchReason / confidence 等）。
  两个分区共用同一份配置，均支持整组恢复默认、保存、导出/导入；调优状态提升到设置页共享，
  在两个分区之间切换不会丢失未保存的修改。
- V 0.826+：双语字幕任务内部固定以简体中文（zh-CN）为纠错/翻译目标——「输出语言」只作用于单语翻译，
  双语对永远不会退化成两份相同语言；双语设置卡已注明此规则。设置页内容底部预留留白，
  sticky 保存条不再遮挡最后一张卡；预览播放中舞台按视频宽高比自适应并居中（移除冲突的
  max-height 上限，消除过宽的下部黑边）；字幕/信息可滚动区域保留鼠标滚动但隐藏可见滚动条（scrollbar-none）。
- V 0.832+：英文/外文片名提取（智能助手、readme、元数据）先剥离 `[](){}` 括号，并在遇到第一个
  发布标记（年份/分辨率/编码/音轨/来源如 AMZN/季集号）时截断，发布组不再残留在片名里
  （`Panic.Room.AMZN.Silence` → `Panic.Room`）；分析链路强制输出 `TITLE_EN` 并带兜底链，
  禁止照抄原始文件名。概要预览正文持久化到任务，readme 的 Synopsis 与预览一致；readme 生成
  `readme.txt` + `readme.html`（HTML 卡片左侧嵌入海报图）。readme/海报统一写入媒体目录下
  首字母大写的 `MediaInfo` 子目录；`folder.jpg` 为同一海报的 400px 缩略图（旧重复文件自动转换）。

