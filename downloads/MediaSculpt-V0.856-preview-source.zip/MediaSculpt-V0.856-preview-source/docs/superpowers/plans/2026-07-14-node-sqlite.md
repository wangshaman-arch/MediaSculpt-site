# Node SQLite Implementation Plan

> **Version:** V 0.856 · 版本：V 0.856
> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace native `better-sqlite3` with built-in `node:sqlite` and make Windows installation require no C++ toolchain.

**Architecture:** Keep the synchronous database contract and Drizzle schema, swap only the SQLite client and migration transaction implementation. Require Node.js 22.20+ on every platform.

**Tech Stack:** Node.js 22.20+, node:sqlite, Drizzle ORM, Vitest, PowerShell.

## Global Constraints

- Windows 10 LTSC and Windows 11 must install without Visual Studio.
- Existing SQLite database files and PostgreSQL compatibility must remain supported.
- Whisper remains optional and skipped in base setup.

---

### Task 1: Runtime SQLite driver

**Files:** `lib/db/src/sqlite.ts`, `lib/db/src/sqlite-init.ts`, `lib/db/src/sqlite.test.ts`

- [x] Write a failing test that opens an in-memory database and reads initialized tables.
- [x] Run the test and confirm the old native dependency blocks the test.
- [x] Replace the driver with `DatabaseSync` and Drizzle's stable `sqlite-proxy` adapter.
- [x] Run the test and typecheck.

### Task 2: Migration and dependencies

**Files:** `lib/db/src/migrate-postgres-to-sqlite.ts`, `lib/db/package.json`, `artifacts/api-server/package.json`

- [x] Replace the native transaction helper with explicit BEGIN/COMMIT/ROLLBACK.
- [x] Remove every `better-sqlite3` dependency and type package.
- [x] Run dependency scan and typecheck.

### Task 3: Windows installer

**Files:** `windows-setup/install.ps1`

- [x] Require Node.js 22.20+ and install a portable LTS runtime when older.
- [x] Remove native SQLite build workarounds.
- [x] Verify the script skips Whisper and no longer references Visual Studio.

### Task 4: Verification and publish

- [x] Run SQLite tests, API tests, typecheck, and diff checks.
- [ ] Commit all changes, push `native-main-fix`, and verify the remote commit.

---

# Node SQLite 实施计划

> **给智能体执行者：** 必需子技能：使用 superpowers:executing-plans 逐任务实施本计划。步骤使用复选框（`- [ ]`）语法跟踪。

**目标：** 用内置 `node:sqlite` 替换原生 `better-sqlite3`，使 Windows 安装不再需要 C++ 工具链。

**架构：** 保留同步数据库契约与 Drizzle schema，只替换 SQLite 客户端和迁移事务实现。所有平台要求 Node.js 22.20+。

**技术栈：** Node.js 22.20+、node:sqlite、Drizzle ORM、Vitest、PowerShell。

## 全局约束

- Windows 10 LTSC 和 Windows 11 必须无需 Visual Studio 即可安装。
- 现有 SQLite 数据库文件与 PostgreSQL 兼容性必须继续支持。
- Whisper 保持可选，基础安装跳过。

---

### 任务 1：运行时 SQLite 驱动

**文件：** `lib/db/src/sqlite.ts`、`lib/db/src/sqlite-init.ts`、`lib/db/src/sqlite.test.ts`

- [x] 编写一个失败测试：打开内存数据库并读取初始化后的表。
- [x] 运行测试，确认旧的原生依赖阻挡了该测试。
- [x] 用 `DatabaseSync` 和 Drizzle 稳定版 `sqlite-proxy` 适配器替换驱动。
- [x] 运行测试和类型检查。

### 任务 2：迁移与依赖

**文件：** `lib/db/src/migrate-postgres-to-sqlite.ts`、`lib/db/package.json`、`artifacts/api-server/package.json`

- [x] 用显式 BEGIN/COMMIT/ROLLBACK 替换原生事务辅助函数。
- [x] 移除所有 `better-sqlite3` 依赖和类型包。
- [x] 运行依赖扫描和类型检查。

### 任务 3：Windows 安装器

**文件：** `windows-setup/install.ps1`

- [x] 要求 Node.js 22.20+，版本更旧时安装便携 LTS 运行时。
- [x] 移除原生 SQLite 构建 workaround。
- [x] 验证脚本跳过 Whisper，且不再引用 Visual Studio。

### 任务 4：验证与发布

- [x] 运行 SQLite 测试、API 测试、类型检查和 diff 检查。
- [ ] 提交所有改动，推送 `native-main-fix`，并验证远程提交。

