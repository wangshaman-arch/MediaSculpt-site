> **Version:** V 0.856 · 版本：V 0.856
# MediaSculpt Brand Migration Implementation Plan

**Goal:** Replace VX-Agent with MediaSculpt / 影刻 while safely copying legacy user data.

**Spec:** `docs/superpowers/specs/2026-08-18-mediasculpt-brand-migration-design.md`

## Constraints

- Keep Electron and version V 0.832 in this release.
- New installations use only MediaSculpt identifiers.
- Legacy VX-Agent data is copied, verified, and never deleted automatically.

## Tasks

1. Add `lib/db/src/brand-paths.ts`, export it from `@workspace/db`, and cover MediaSculpt path and legacy-copy behavior with API-server Vitest tests. Route SQLite and managed-tool paths through it.
2. Rename frontend copy, HTML metadata, browser storage keys, and i18n strings; retain a one-time browser-storage migration.
3. Generate MediaSculpt icon assets from the supplied PNG and update Electron identity, packaging, IPC names, and diagnostics.
4. Update Windows installer, launchers, uninstaller, and old-data migration; retain old wrappers only as forwarding compatibility entry points.
5. Update bilingual documentation and run API tests, frontend build, desktop package, clean-install and legacy-upgrade smoke tests.

---

# MediaSculpt 品牌迁移实施计划

第一阶段保留 Electron 和 V 0.832，依次完成公共路径迁移、前端品牌、桌面壳与图标、Windows 安装迁移、文档与全量验证。旧 VX-Agent 数据只复制和校验，绝不自动删除。

