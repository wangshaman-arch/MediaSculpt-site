# Workbench Layout and LLM Subtitle Strategy Implementation Plan

> **Version:** V 0.856 · 版本：V 0.856
> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Make the disc dialog, job preview, workbench source picker, and automatic subtitle strategy fit a 1080P window without nested scrolling or duplicated controls, while routing subtitle translation through the configured LLM provider.

**Architecture:** Keep the existing HandBrake/ffprobe analysis, task snapshot, job queue, and media executors unchanged. The UI will have one scroll owner per surface; the server will expose a small strategy/translation boundary that consumes existing media analysis and returns subtitle decisions without executing media commands.

**Tech Stack:** React + TypeScript + Tailwind, Express + TypeScript, Vitest, existing API client and AI provider helpers.

## Global Constraints

- Do not redesign DVD parsing, Remux, HandBrake compression, Whisper execution, or taskSnapshot.
- Do not create a second media execution path.
- Keep the current top navigation and dark cyan visual language.
- Preserve the existing `sourceFingerprint + titleId` identity.
- LLM failure must fall back to the existing traditional subtitle/Whisper path.
- Never log API keys or prompt secrets.
- Preserve `vx-agent-diagnostics.log` as an uncommitted user file.

### Task 1: Regression contracts for layout and subtitle strategy

**Files:**
- Modify: `artifacts/api-server/src/lib/windows-launcher-contract.test.ts`
- Test: existing contract suite

**Interfaces:**
- Consumes: current `Scan.tsx`, `JobDetail.tsx`, `Settings.tsx`, and AI route source.
- Produces: failing assertions for one outer dialog scroll owner, removed batch-scan row, responsive preview controls, detailed title summary, and automatic subtitle strategy order.

- [ ] **Step 1: Write failing tests** for the exact strings/classes/structure already used by the project.
- [ ] **Step 2: Run the focused contract test and confirm failures are caused by missing behavior, not syntax errors.**
- [ ] **Step 3: Keep these tests as the regression boundary for all later tasks.**

### Task 2: Disc dialog single-scroll layout and detailed selection summary

**Files:**
- Modify: `artifacts/video-agent/src/pages/Scan.tsx`

**Interfaces:**
- Consumes: existing `DiscAnalyzeDialog`, `previewByTitleId`, `selectedStreamIndices`, `selectedChapterIds`, and title/stream models.
- Produces: one `overflow-y-auto` owner on the dialog body, title rows with compact metadata, and a right summary that lists selected stream/chapter details.

- [ ] **Step 1:** Remove nested `overflow-y-auto`/fixed max-height owners from title-level track and chapter lists while retaining the outer dialog body scroll.
- [ ] **Step 2:** Remove the "统一预览窗口" explanation card without removing the title preview area.
- [ ] **Step 3:** Add a pure display helper that derives selected stream summaries from the current title and selection sets; show language, codec, channels/resolution, real stream index, and chapter time ranges in the right summary.
- [ ] **Step 4:** Keep title list rows limited to title ID, duration, resolution, track counts, and chapter count.
- [ ] **Step 5:** Run the focused contract test and the front-end type check.

### Task 3: Responsive job preview and directory picker bounds

**Files:**
- Modify: `artifacts/video-agent/src/pages/JobDetail.tsx`
- Modify: `artifacts/video-agent/src/components/DirectoryPicker.tsx`
- Modify: `artifacts/video-agent/src/pages/Scan.tsx`

**Interfaces:**
- Consumes: existing preview stage, details drawer, subtitle controls, and `DirectoryPicker` callback.
- Produces: 1366×768/1536×864/1920×1080-safe layout with no horizontal overflow and no delayed width jump.

- [ ] **Step 1:** Make the preview/details grid use `minmax(0, 1fr)` and a bounded drawer width only when space permits; keep the drawer overlay-safe at narrower widths.
- [ ] **Step 2:** Make the preview control overlay use shrinkable controls and a bounded subtitle-control region so no button extends past the viewport.
- [ ] **Step 3:** Keep DAR/SAR aspect-ratio behavior and preserve player state when opening/closing the drawer.
- [ ] **Step 4:** Remove the visible "打开批量扫描" row from the workbench while leaving the existing scan API untouched.
- [ ] **Step 5:** Bound directory picker dialog width/height to the viewport, use `min-width: 0`, and allow action buttons to wrap.
- [ ] **Step 6:** Run contract tests, front-end typecheck, and production build.

### Task 4: LLM-backed automatic subtitle decision boundary

**Files:**
- Inspect/modify: `artifacts/api-server/src/lib/ai-provider.ts`
- Inspect/modify: `artifacts/api-server/src/routes/runtime.ts`
- Modify: `artifacts/api-server/src/lib/smart-workflow.ts` or the existing subtitle strategy module only if it is the current shared strategy boundary.
- Modify: `artifacts/video-agent/src/pages/Scan.tsx` copy/selection only as needed.
- Test: add a focused server unit test beside the existing smart-workflow tests.

**Interfaces:**
- Consumes: configured provider/API key/model and existing media streams/subtitle files.
- Produces: `automaticSubtitleStrategy(input)` returning one of `external-translate`, `embedded-extract-translate`, `whisper-original-translate`, or `none`, plus a non-secret LLM translation request boundary.

- [ ] **Step 1:** Write failing tests for external subtitle precedence, embedded subtitle fallback, Whisper fallback, and LLM-unavailable fallback.
- [ ] **Step 2:** Confirm tests fail before implementation.
- [ ] **Step 3:** Reuse `resolveAiEndpoint`/`resolveApiKey`; send only structured metadata and subtitle text, never API keys or raw media commands.
- [ ] **Step 4:** Implement the decision order: external subtitle → embedded subtitle extraction → Whisper original-language SRT + translated copy → none.
- [ ] **Step 5:** Ensure traditional subtitle/Whisper execution remains the only executor and LLM errors are warnings.
- [ ] **Step 6:** Run focused smart-workflow tests and full server typecheck/tests.

### Task 5: Full verification and commit

**Files:**
- Verify all modified files above.

- [ ] **Step 1:** Run API focused tests, full server tests, root typecheck, front-end typecheck, and front-end production build with `PORT=24404`.
- [ ] **Step 2:** Run `git diff --check` and inspect that Remux, HandBrake, Whisper executor, and taskSnapshot files are unchanged except approved shared boundaries.
- [ ] **Step 3:** Commit with `fix: fit workbench surfaces and route automatic subtitles`.
- [ ] **Step 4:** Push the current feature branch and report the commit hash plus Windows test steps.

---

# 影音工作台布局与 LLM 字幕策略实施计划

> **给智能体执行者：** 必需子技能：使用 superpowers:executing-plans 逐任务实施本计划。

**目标：** 让光盘弹窗、任务预览、工作台来源选择器和自动字幕策略适配 1080P 窗口，避免嵌套滚动或重复控件，同时让字幕翻译走已配置的 LLM 提供方。

**架构：** 保留现有 HandBrake/ffprobe 分析、任务快照、任务队列和媒体执行器不变。每个界面只有一个滚动所有者；服务端暴露一个小的策略/翻译边界，消费现有媒体分析并返回字幕决策，不执行媒体命令。

**技术栈：** React + TypeScript + Tailwind、Express + TypeScript、Vitest、现有 API 客户端与 AI provider 辅助函数。

## 全局约束

- 不重新设计 DVD 解析、Remux、HandBrake 压缩、Whisper 执行或 taskSnapshot。
- 不创建第二条媒体执行路径。
- 保留当前顶部导航和深青色视觉语言。
- 保留现有 `sourceFingerprint + titleId` 身份。
- LLM 失败必须回退到现有传统字幕/Whisper 路径。
- 绝不记录 API Key 或提示词机密。
- 保留 `vx-agent-diagnostics.log` 作为未提交的用户文件。

### 任务 1：布局与字幕策略的回归契约

**文件：**
- 修改：`artifacts/api-server/src/lib/windows-launcher-contract.test.ts`
- 测试：现有契约套件

**接口：**
- 消费：当前 `Scan.tsx`、`JobDetail.tsx`、`Settings.tsx` 和 AI 路由源码。
- 产出：针对“弹窗只有一个外层滚动所有者、移除批量扫描行、响应式预览控件、详细标题摘要、自动字幕策略顺序”的失败断言。

- [ ] **步骤 1：编写失败测试**，使用项目已有的确切字符串/类/结构。
- [ ] **步骤 2：运行聚焦契约测试，确认失败来自缺失行为而非语法错误。**
- [ ] **步骤 3：把这些测试作为后续所有任务的回归边界。**

### 任务 2：光盘弹窗单滚动布局与详细选择摘要

**文件：**
- 修改：`artifacts/video-agent/src/pages/Scan.tsx`

**接口：**
- 消费：现有 `DiscAnalyzeDialog`、`previewByTitleId`、`selectedStreamIndices`、`selectedChapterIds` 和 title/stream 模型。
- 产出：弹窗主体只有一个 `overflow-y-auto` 所有者；title 行带紧凑元数据；右侧摘要列出所选流轨/章节详情。

- [ ] **步骤 1：** 移除 title 级轨道和章节列表中的嵌套 `overflow-y-auto`/固定 max-height 所有者，保留外层弹窗主体滚动。
- [ ] **步骤 2：** 移除“统一预览窗口”说明卡但不移除 title 预览区域。
- [ ] **步骤 3：** 增加纯展示辅助函数，从当前 title 和选择集推导所选流轨摘要；在右侧摘要显示语言、编码、声道/分辨率、真实流索引和章节时间范围。
- [ ] **步骤 4：** title 列表行只保留 title ID、时长、分辨率、轨道数量和章节数量。
- [ ] **步骤 5：** 运行聚焦契约测试和前端类型检查。

### 任务 3：响应式任务预览与目录选择器边界

**文件：**
- 修改：`artifacts/video-agent/src/pages/JobDetail.tsx`
- 修改：`artifacts/video-agent/src/components/DirectoryPicker.tsx`
- 修改：`artifacts/video-agent/src/pages/Scan.tsx`

**接口：**
- 消费：现有预览阶段、详情抽屉、字幕控件和 `DirectoryPicker` 回调。
- 产出：1366×768 / 1536×864 / 1920×1080 安全布局，无横向溢出、无延迟宽度跳动。

- [ ] **步骤 1：** 预览/详情网格使用 `minmax(0, 1fr)`，仅在空间允许时限制抽屉宽度；较窄宽度下保持抽屉不越界。
- [ ] **步骤 2：** 预览控件浮层使用可收缩控件和有界的字幕控件区，任何按钮都不超出视口。
- [ ] **步骤 3：** 保留 DAR/SAR 宽高比行为，打开/关闭抽屉时保持播放器状态。
- [ ] **步骤 4：** 从工作台移除可见的“打开批量扫描”行，但保留现有扫描 API 不变。
- [ ] **步骤 5：** 目录选择器弹窗宽高限制在视口内，使用 `min-width: 0`，允许操作按钮换行。
- [ ] **步骤 6：** 运行契约测试、前端类型检查和生产构建。

### 任务 4：LLM 驱动的自动字幕决策边界

**文件：**
- 检查/修改：`artifacts/api-server/src/lib/ai-provider.ts`
- 检查/修改：`artifacts/api-server/src/routes/runtime.ts`
- 修改：`artifacts/api-server/src/lib/smart-workflow.ts`，或仅在它是当前共享策略边界时修改现有字幕策略模块。
- 仅按需修改：`artifacts/video-agent/src/pages/Scan.tsx` 的文案/选择。
- 测试：在现有 smart-workflow 测试旁增加聚焦服务端单元测试。

**接口：**
- 消费：已配置的 provider/API Key/模型和现有媒体流/字幕文件。
- 产出：`automaticSubtitleStrategy(input)` 返回 `external-translate`、`embedded-extract-translate`、`whisper-original-translate` 或 `none` 之一，外加一个不涉密的 LLM 翻译请求边界。

- [ ] **步骤 1：** 编写失败测试：外挂字幕优先、内置字幕回退、Whisper 回退、LLM 不可用回退。
- [ ] **步骤 2：** 确认实现前测试失败。
- [ ] **步骤 3：** 复用 `resolveAiEndpoint`/`resolveApiKey`；只发送结构化元数据和字幕文本，绝不发送 API Key 或原始媒体命令。
- [ ] **步骤 4：** 实现决策顺序：外挂字幕 → 内置字幕提取 → Whisper 原语言 SRT + 翻译副本 → none。
- [ ] **步骤 5：** 确保传统字幕/Whisper 执行仍是唯一执行器，LLM 错误只是警告。
- [ ] **步骤 6：** 运行聚焦 smart-workflow 测试和服务端完整类型检查/测试。

### 任务 5：完整验证与提交

**文件：**
- 验证上述所有修改文件。

- [ ] **步骤 1：** 运行 API 聚焦测试、完整服务端测试、根类型检查、前端类型检查和 `PORT=24404` 的前端生产构建。
- [ ] **步骤 2：** 运行 `git diff --check`，确认 Remux、HandBrake、Whisper 执行器和 taskSnapshot 文件除批准的共享边界外未改动。
- [ ] **步骤 3：** 以 `fix: fit workbench surfaces and route automatic subtitles` 提交。
- [ ] **步骤 4：** 推送当前特性分支，报告提交哈希和 Windows 测试步骤。

