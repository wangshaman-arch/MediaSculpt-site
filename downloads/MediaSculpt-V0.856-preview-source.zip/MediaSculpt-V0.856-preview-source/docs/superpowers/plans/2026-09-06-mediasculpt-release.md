# MediaSculpt V 0.837 Release Implementation Plan

> **Version:** V 0.856 · 版本：V 0.856
> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Produce a smaller, verified MediaSculpt release, publish it to GitHub `main`, and create a basic Windows installer without removing required media-processing capability.

**Architecture:** Keep the bundled FFmpeg/FFprobe and Node runtime for predictable offline operation, but remove development-only source maps from release resources and ensure the installer compresses the remaining payload. Keep frontend code-splitting as a follow-up only if measurements show a real startup benefit. Release changes are committed on the Codex branch, reviewed against the remote `main`, then pushed only when the remote is clean and fast-forwardable.

**Tech Stack:** pnpm workspaces, Vite, esbuild, Tauri 2, NSIS/WiX installer tooling, GitHub remote.

**Spec:** User request on 2026-09-06: complete the planned size reduction, upload to GitHub main, and package one basic Windows installer for morning acceptance.

## Global Constraints

- Current product identity is MediaSculpt / 影刻.
- Release version will be `V 0.837` unless the repository's canonical version files show a newer unreleased version; no version is skipped.
- Every Markdown file remains bilingual and carries the repository version header.
- Do not delete FFmpeg codecs or the Node runtime in this release; doing so would risk DVD/Bluray, subtitle, and remux regressions.
- Do not overwrite concurrent opencode changes; inspect task files, branch, worktree, and remote state before editing.
- The installed copy `C:\VX-Agent` is synchronized only if it exists; otherwise skip it.
- Do not publish secrets, API keys, local paths, generated databases, or user media.

---

### Task 1: Release and collaboration audit

**Files:**
- Read: `.agents/memory/tasks/*.md`, `VERSION.md`, `windows-setup/release-id.txt`, `package.json`, `desktop-tauri/src-tauri/tauri.conf.json`
- Modify: none

- [ ] Confirm the active branch, worktree status, remote URL, and whether `origin/main` is ahead or has uncommitted-equivalent changes.
- [ ] Confirm no task file marks `JobDetail.tsx`, packaging files, or release documentation as owned by another agent.
- [ ] Resolve the version discrepancy between the AGENTS header and the canonical `VERSION.md` before any release edit.
- [ ] Stop before mutation if `origin/main` is not fast-forwardable or if a concurrent agent owns a file required by this release.

### Task 2: Remove development-only release weight

**Files:**
- Modify: `artifacts/api-server/build.mjs`
- Modify: `artifacts/video-agent/vite.config.ts`
- Modify: `scripts/prepare-tauri-sidecar.ps1`
- Test: existing API and frontend build commands

- [ ] Configure production builds to omit source maps from the staged sidecar while retaining source maps for local development.
- [ ] Ensure `prepare-tauri-sidecar.ps1 -IncludeFrontend` removes stale `.map` files from the release staging destination before copying fresh output.
- [ ] Do not alter FFmpeg/FFprobe feature flags in this release.
- [ ] Measure sidecar size before and after and record the result in the release notes.

### Task 3: Version and bilingual documentation update

**Files:**
- Modify: `VERSION.md`
- Modify: every repository `*.md` header and version-management section required by AGENTS.md
- Modify: `docs/product-rules.md`
- Modify: `windows-setup/release-id.txt`
- Modify: software-visible fallback version in `artifacts/video-agent/src/App.tsx` if present

- [ ] Bump all required version locations consistently to `V 0.837`.
- [ ] Preserve English-first/Chinese-second Markdown structure.
- [ ] Document the remaining payload sizes and the reason FFmpeg/Node remain bundled.
- [ ] If `C:\VX-Agent` exists, update its `.vx-install-complete` marker to the same release id; otherwise record that no installed copy was present.

### Task 4: Build and package a basic Windows installer

**Files:**
- Read/modify only the Tauri packaging configuration required by the existing project setup.
- Create: release artifacts under the repository's configured output directory (not source-controlled unless the project already tracks installers)

- [ ] Build API and frontend production resources.
- [ ] Stage the sidecar with frontend resources and no development source maps.
- [ ] Run the existing Tauri Windows packaging command for the basic installer target (NSIS or the repository's configured target); do not create a signed installer or alter signing credentials.
- [ ] Verify installer metadata, product name `MediaSculpt`, Chinese display name `影刻` where supported, version, architecture, and output path.
- [ ] Verify the installer includes the required Node runtime and FFmpeg tools.

### Task 5: Verification and smoke checks

**Files:**
- Read-only verification of built resources and installer
- Update: release plan/task notes with command results

- [ ] Run `pnpm run typecheck:libs` first if any schema/lib file changed.
- [ ] Run `pnpm run typecheck` and `pnpm run test` (or the repository's equivalent workspace commands).
- [ ] Verify the frontend production bundle loads, the API sidecar starts, and the basic info/IMDb display path remains intact.
- [ ] Smoke-test the installer on this machine if the packaging tool permits it without replacing an existing installation.
- [ ] Run `git diff --check`, inspect the staged diff, and verify no secrets or user media paths are included.

### Task 6: Commit, publish, and handoff

**Files:**
- Git metadata only
- Modify: release/task handoff note with commit hash and artifact path

- [ ] Commit the reviewed release changes on the Codex branch with a release message.
- [ ] Re-fetch `origin/main`; push/fast-forward `main` only if it has not changed since the audit and the user-approved scope is unchanged.
- [ ] Record the commit hash, GitHub branch, installer path, SHA-256, test results, and known limitation that FFmpeg/Node dominate size.
- [ ] Do not force-push or rewrite remote history.

---

## Size expectation

The safe immediate reduction is approximately the API/frontend source-map payload (about 8 MB in the current build). The remaining roughly 360 MB is primarily FFmpeg/FFprobe and Node; reducing that further requires a separate compatibility-tested native-service or custom FFmpeg build project and is not safe to fold into this overnight release.

## Execution record

- Release: MediaSculpt V 0.837 (`0.837.0`), release id `2026.09.06.837`.
- Verification: `pnpm run typecheck:libs`, `pnpm run typecheck`, `pnpm run lint`, and `pnpm run test` all passed.
- Packaging: NSIS basic installer built successfully at `desktop-tauri/src-tauri/target/release/bundle/nsis/MediaSculpt_0.837.0_x64-setup.exe` (about 162.34 MB); SHA-256 is recorded in the adjacent `.sha256` file.
- Release staging contains no source maps; FFmpeg/FFprobe and Node remain bundled for offline media processing and local service startup. The local `C:\VX-Agent` installed copy was absent, so no marker sync was required.

### 执行记录

- 发布版本：MediaSculpt V 0.837（`0.837.0`），发布 ID 为 `2026.09.06.837`。
- 验证结果：`pnpm run typecheck:libs`、`pnpm run typecheck`、`pnpm run lint`、`pnpm run test` 全部通过。
- 封装结果：NSIS 基础安装包已成功生成，路径为 `desktop-tauri/src-tauri/target/release/bundle/nsis/MediaSculpt_0.837.0_x64-setup.exe`（约 162.34 MB）；SHA-256 已记录在同目录 `.sha256` 文件中。
- 发布暂存目录不含 source map；为保证离线媒体处理和本地服务启动，仍保留 FFmpeg/FFprobe 与 Node。本机不存在 `C:\VX-Agent` 安装副本，因此无需同步标记文件。

