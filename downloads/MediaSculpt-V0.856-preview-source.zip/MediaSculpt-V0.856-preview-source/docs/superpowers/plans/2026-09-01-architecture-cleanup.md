# MediaSculpt Architecture Cleanup Implementation Plan

> **Version:** V 0.856 · 版本：V 0.856
> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Refactor MediaSculpt into explicit media, application, infrastructure, route, and UI feature boundaries without changing the existing API contract.

**Architecture:** First stabilize the test entry points and extract pure/runtime boundaries from `jobs.ts`. Then move DVD analysis and Remux execution behind immutable media-source contracts, followed by queue/application extraction and frontend feature decomposition. Keep compatibility adapters until all consumers and tests use the new interfaces.

**Tech Stack:** TypeScript 5.9, Node.js 22, Express 5, Vitest, React 19, Vite, TanStack Query, Tauri 2, FFmpeg, HandBrakeCLI, Drizzle/SQLite.

**Spec:** `docs/superpowers/specs/2026-09-01-architecture-cleanup-design.md`

## Global Constraints

- Current version remains `V 0.835`; do not bump it for refactoring.
- Every Markdown file remains bilingual with English first, Chinese underneath, and the `V 0.835` header.
- Do not change public REST paths or generated API contracts during extraction.
- All user-visible frontend text goes through the existing i18n packs.
- DVD title analysis must produce an immutable ordered input list before Remux or compression.
- Production Windows packaging remains Tauri; Electron is not the default release path.
- Production code changes require a failing test first, followed by a passing targeted test and the full relevant suite.

---

### Task 1: Make the isolated test environment reproducible

**Files:**
- Modify: `artifacts/api-server/vitest.config.ts`
- Modify: `artifacts/video-agent/vitest.config.ts`
- Modify: `artifacts/video-agent/vite.config.ts`
- Modify: `package.json`
- Test: existing API and frontend `*.test.ts` files

**Interfaces:**
- Produces a test command that runs from the repository root and from a linked worktree without reading outside the project root.

- [x] **Step 1: Add a failing test command contract**

Add a root script named `test` that invokes both workspace test packages, then add a small script-level assertion or documented command check showing that the command exists and uses the package-local Vitest configs.

- [x] **Step 2: Run the new command and verify the current failure**

Run `pnpm test` from the isolated worktree. It must fail with the current config/root resolution error before the config is corrected.

- [x] **Step 3: Make Vite/Vitest paths project-root based**

Use `fileURLToPath(new URL(".", import.meta.url))` or an equivalent absolute path derived from the config file. Do not resolve `@assets` to a missing directory; make the alias conditional or point it to an existing repository directory. Keep the API server test environment values unchanged.

- [x] **Step 4: Run the targeted test suites**

Run `pnpm --filter @workspace/api-server test` and `pnpm --filter @workspace/video-agent test`. Expected result: Vitest starts and reports assertion results rather than a config startup error.

- [x] **Step 5: Run the repository typecheck**

Run `pnpm run typecheck`. Expected result: exit code 0.

- [x] **Step 6: Commit the test-entry fix**

```text
git add package.json artifacts/api-server/vitest.config.ts artifacts/video-agent/vitest.config.ts artifacts/video-agent/vite.config.ts
git commit -m "test: make workspace test entry points reproducible"
```

### Task 2: Extract shared runtime path and process contracts

**Files:**
- Create: `artifacts/api-server/src/infrastructure/process-runner.ts`
- Create: `artifacts/api-server/src/infrastructure/process-types.ts`
- Modify: `artifacts/api-server/src/lib/runtime-paths.ts`
- Modify: `artifacts/api-server/src/routes/jobs.ts`
- Test: `artifacts/api-server/src/lib/runtime-paths.test.ts`
- Test: new `artifacts/api-server/src/infrastructure/process-runner.test.ts`

**Interfaces:**
- `ProcessRequest { executable: string; args: string[]; cwd?: string; env?: NodeJS.ProcessEnv; jobId?: number; stage?: string; signal?: AbortSignal }`.
- `ProcessResult { code: number | null; stdout: string; stderr: string; durationMs: number }`.
- `ProcessRunner.run(request): Promise<ProcessResult>`.
- `ProcessRunner.spawn(request): ManagedProcess`.

- [x] **Step 1: Write process-runner behavior tests**

Cover successful exit, non-zero exit with stderr, spawn error, abort, and argument recording. The tests must use a real Node child process with a short inline script; only the logger callback may be injected.

- [x] **Step 2: Run the new tests and verify they fail**

Run `pnpm --filter @workspace/api-server exec vitest run src/infrastructure/process-runner.test.ts`. Expected result: the module or exported runner is missing.

- [x] **Step 3: Implement the minimal process runner**

Wrap `execFile`/`spawn`, use `windowsHide: true`, collect stdout/stderr, resolve exactly once, propagate abort, and return a normalized result. Do not add retries or concurrency policy here.

- [x] **Step 4: Run process and runtime-path tests**

Run `pnpm --filter @workspace/api-server exec vitest run src/infrastructure/process-runner.test.ts src/lib/runtime-paths.test.ts`. Expected result: all pass.

- [x] **Step 5: Replace duplicate path helpers in `jobs.ts`**

Import `resolveRuntimePath` and `resolveOutputDir` from `lib/runtime-paths.ts`, remove the duplicate local implementations, and keep a compatibility wrapper only where the route file needs a job-specific name.

- [x] **Step 6: Run typecheck and the API suite**

Run `pnpm --filter @workspace/api-server typecheck` and `pnpm --filter @workspace/api-server test`. Expected result: exit code 0 with no changed API responses.

- [x] **Step 7: Commit the infrastructure extraction**

```text
git add artifacts/api-server/src/infrastructure artifacts/api-server/src/lib/runtime-paths.ts artifacts/api-server/src/routes/jobs.ts artifacts/api-server/src/lib/runtime-paths.test.ts
git commit -m "refactor: isolate process execution and runtime paths"
```

### Task 3: Establish the immutable disc-source model

**Files:**
- Create: `artifacts/api-server/src/media/media-source.ts`
- Create: `artifacts/api-server/src/media/dvd-source.ts`
- Modify: `artifacts/api-server/src/lib/disc.ts`
- Modify: `artifacts/api-server/src/lib/disc-analysis.ts`
- Modify: `artifacts/api-server/src/lib/dvd-remux.ts`
- Test: new `artifacts/api-server/src/media/dvd-source.test.ts`
- Test: existing `disc.test.ts`, `disc-analysis.test.ts`, `dvd-remux.test.ts`

**Interfaces:**
- `analyzeDvdSource(input: { sourcePath: string; runner?: ProcessRunner }): Promise<MediaSource>`.
- `orderedDvdInputs(title: MediaTitle): readonly string[]`.
- `assertCompleteMediaTitle(title: MediaTitle): void`.

- [x] **Step 1: Write DVD ordering and immutability tests**

Use a temporary `VIDEO_TS` fixture containing `VTS_01_0.IFO`, `VTS_01_1.VOB`, `VTS_01_2.VOB`, and `VTS_01_10.VOB`. Assert that the title is selected from IFO analysis, VOBs are ordered numerically, the returned list is immutable to callers, and missing segments produce a typed failure.

- [x] **Step 2: Run the tests and verify the intended failures**

Run `pnpm --filter @workspace/api-server exec vitest run src/media/dvd-source.test.ts`. Expected result: the new source module and contract are absent.

- [x] **Step 3: Implement the source model and DVD adapter**

Reuse the existing IFO/HandBrake parsing helpers. Normalize the result once into `MediaSource` and `MediaTitle`; preserve stable title IDs, chapters, stream metadata, and ordered inputs. Do not let the adapter enumerate VOBs after the title is resolved.

- [x] **Step 4: Make Remux consume the ordered contract**

Change `dvd-remux.ts` to accept the normalized title or its ordered input list, build the concat manifest from that list, and keep timestamps continuous. Preserve existing audio/subtitle selection behavior.

- [x] **Step 5: Run focused media tests**

Run `pnpm --filter @workspace/api-server exec vitest run src/media/dvd-source.test.ts src/lib/disc.test.ts src/lib/disc-analysis.test.ts src/lib/dvd-remux.test.ts src/lib/ffconcat.test.ts`. Expected result: all pass.

- [x] **Step 6: Run typecheck and commit**

Run `pnpm --filter @workspace/api-server typecheck`, then commit with:

```text
git add artifacts/api-server/src/media artifacts/api-server/src/lib/disc.ts artifacts/api-server/src/lib/disc-analysis.ts artifacts/api-server/src/lib/dvd-remux.ts artifacts/api-server/src/lib/*test.ts
git commit -m "refactor: model disc titles before media processing"
```

### Task 4: Move job orchestration out of the jobs route

**Files:**
- Create: `artifacts/api-server/src/application/job-service.ts`
- Create: `artifacts/api-server/src/application/job-runner.ts`
- Create: `artifacts/api-server/src/application/job-errors.ts`
- Create: `artifacts/api-server/src/media/remux-service.ts`
- Create: `artifacts/api-server/src/media/compression-service.ts`
- Create: `artifacts/api-server/src/media/subtitle-service.ts`
- Create: `artifacts/api-server/src/media/preview-service.ts`
- Modify: `artifacts/api-server/src/routes/jobs.ts`
- Test: new application and media service tests
- Test: existing route contract tests

**Interfaces:**
- `JobService.create(input): Promise<JobRecord>`.
- `JobService.start(jobId): Promise<void>`.
- `JobService.pause(jobId): Promise<void>`.
- `JobService.cancel(jobId): Promise<void>`.
- `JobService.retry(jobId): Promise<void>`.
- Each media service accepts a `ProcessRunner`, immutable job snapshot, and stage logger; none imports Express.

- [x] **Step 1: Write route-independent orchestration tests**

Test that a job command selects exactly one processing mode, records stage transitions, rejects incomplete disc titles before spawning a process, and treats cancellation as idempotent.

- [x] **Step 2: Run the tests and verify failure**

Run the new application tests. Expected result: the service modules and command interfaces are absent.

- [x] **Step 3: Extract one command at a time**

Move create/start first, then pause/resume/cancel/retry, preserving database writes and existing response payloads. Keep route handlers as input validation plus service invocation.

- [x] **Step 4: Extract media stage execution**

Move Remux, compression, subtitles, and preview execution into services. All output files must use temporary paths until post-process validation succeeds.

- [x] **Step 5: Keep compatibility exports until consumers migrate**

Re-export only the symbols still required by existing tests or routes; remove each compatibility export after its final consumer is migrated.

- [x] **Step 6: Run API typecheck, targeted tests, and full API tests**

Run `pnpm --filter @workspace/api-server typecheck`, the new application tests, then `pnpm --filter @workspace/api-server test`. Expected result: exit code 0.

- [x] **Step 7: Commit the application split**

```text
git add artifacts/api-server/src/application artifacts/api-server/src/media artifacts/api-server/src/routes/jobs.ts artifacts/api-server/src/routes/*test.ts
git commit -m "refactor: move job orchestration out of HTTP routes"
```

### Task 5: Split frontend workbench, settings, and job detail features

**Files:**
- Create: `artifacts/video-agent/src/features/workbench/`
- Create: `artifacts/video-agent/src/features/settings/`
- Create: `artifacts/video-agent/src/features/jobs/`
- Create: `artifacts/video-agent/src/hooks/useWorkbenchState.ts`
- Create: `artifacts/video-agent/src/hooks/useSettingsSections.ts`
- Create: `artifacts/video-agent/src/hooks/useJobActions.ts`
- Modify: `artifacts/video-agent/src/pages/Scan.tsx`
- Modify: `artifacts/video-agent/src/pages/Settings.tsx`
- Modify: `artifacts/video-agent/src/pages/JobDetail.tsx`
- Test: existing frontend tests plus focused hook/component tests

**Interfaces:**
- `useWorkbenchState()` owns source path, active mode, and job-creation state.
- `useSettingsSections()` owns section selection, dirty state, save, and navigation guard.
- `useJobActions(jobId)` owns start, pause, cancel, retry, metadata, and preview actions.

- [x] **Step 1: Add behavior tests for state ownership**

Assert that changing the workbench mode does not erase the shared source directory, saving one settings section does not dirty unrelated sections, and unmounting a preview cancels stale updates.

- [x] **Step 2: Run focused frontend tests and verify failure**

Run `pnpm --filter @workspace/video-agent test`. Add the new test files before implementation so the desired hook contracts fail for the expected missing exports.

- [x] **Step 3: Extract workbench components without changing layout**

Move source browser, mode tabs, disc title selection, compression controls, subtitle controls, and Remux controls into feature components. `Scan.tsx` becomes a composition file.

- [x] **Step 4: Extract settings sections and shared persistence**

Move each settings area into its own component and centralize local storage/config API interaction. Preserve i18n keys and the existing dirty navigation guard.

- [x] **Step 5: Extract job detail panels and actions**

Separate summary, streams, preview, logs, metadata, assistant, and action controls. Keep the current route and query keys.

- [x] **Step 6: Run frontend typecheck, tests, and production build**

Run `pnpm --filter @workspace/video-agent typecheck`, `pnpm --filter @workspace/video-agent test`, and `pnpm --filter @workspace/video-agent build`. Expected result: exit code 0.

- [x] **Step 7: Commit the frontend feature split**

```text
git add artifacts/video-agent/src/features artifacts/video-agent/src/hooks artifacts/video-agent/src/pages/Scan.tsx artifacts/video-agent/src/pages/Settings.tsx artifacts/video-agent/src/pages/JobDetail.tsx
git commit -m "refactor: split workbench settings and job features"
```

### Task 6: Remove verified legacy and enforce quality gates

**Files:**
- Modify: `package.json`
- Modify: `lib/api-spec/package.json`
- Modify: `.github/workflows/windows-script-compatibility.yml`
- Modify: `README.md`
- Modify: relevant bilingual Markdown docs
- Delete only after reference checks: `scripts/src/hello.ts`, duplicate `README.txt`, obsolete VX-Agent launchers, unused Electron build files
- Test: split Windows launcher contract tests

**Interfaces:**
- `pnpm lint` or an equivalent repository-wide static check.
- `pnpm format:check`.
- `pnpm test`.
- `pnpm check:generated`.

- [x] **Step 1: Search all legacy references**

Run `rg -n "hello.ts|README.txt|VX-Agent|desktop-shell|generated" . -g '!node_modules/**' -g '!release/**'`. Record every reference before deleting a candidate.

- [x] **Step 2: Split the Windows contract test**

Move launcher, installer, version, and runtime assertions into separate files without changing assertions. Run each file and the combined suite.

- [x] **Step 3: Add quality commands**

Add deterministic format, typecheck, test, and generated-code verification commands. Generated verification must run API codegen in a temporary working tree or compare the generated diff and fail when tracked output changes unexpectedly.

- [x] **Step 4: Delete only confirmed unused files**

Remove a candidate only when `rg` shows no active reference and the corresponding build/test command has passed. Do not delete release assets or compatibility migration code solely because it is old.

- [x] **Step 5: Update bilingual README and architecture notes**

Document the canonical Tauri build, local development, test commands, module boundaries, and the rule that DVD analysis produces the ordered title input before processing.

- [x] **Step 6: Run final verification**

Run `pnpm run typecheck`, `pnpm test`, `pnpm -r --if-present run build`, `pnpm check:generated`, and the Windows launcher compatibility checks. Inspect `git diff --check` and `git status --short`.

- [x] **Step 7: Commit the cleanup gates**

```text
git add package.json lib/api-spec/package.json .github README.md docs
git commit -m "chore: enforce architecture cleanup quality gates"
```

## 中文执行说明

### 总目标

在不改变现有 API 契约的情况下，把 MediaSculpt 拆成清晰的媒体层、应用层、基础设施层、路由层和前端功能层。先稳定测试入口和后端媒体边界，再拆任务编排和前端页面，最后清理遗留文件并加入质量门禁。

### 执行顺序

1. 让隔离 worktree 中的 Vitest 可以稳定启动。
2. 抽取进程执行和运行时路径接口。
3. 建立不可变的 DVD/媒体源模型，固定 IFO、Title、VOB 顺序。
4. 把任务编排和媒体阶段移出 `jobs.ts`。
5. 拆分工作台、设置和任务详情页面。
6. 拆分过大的合约测试，确认引用后清理遗留文件，加入类型检查、测试、构建和 API 生成代码检查。

### 完成标准

每个任务都必须先写失败测试，再写最小实现，随后运行目标测试和完整相关测试。最终必须通过类型检查、全部测试、生产构建、生成代码检查和 Windows 启动器兼容性检查，并确认工作区没有无意改动。

