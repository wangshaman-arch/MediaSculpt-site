# DVD Title Manifest Implementation Plan

> **Version:** V 0.856 · 版本：V 0.856
> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Preserve every real DVD title and carry one stable title/stream identity from analysis through Remux, compression, and subtitle processing.

**Architecture:** The DVD analyzer will retain raw HandBrake titles and annotate possible duplicates instead of deleting similar titles. A stable manifest identity will be carried in the selected task snapshot; tool-specific title and stream numbers remain adapter mappings and are never used as business identifiers. DVD execution will use the frozen title mapping and output validation will reject mismatches.

**Tech Stack:** TypeScript, Vitest, HandBrakeCLI, FFprobe, FFmpeg, Tauri/Windows runtime.

**Spec:** `docs/superpowers/specs/2026-09-07-summary-metadata-display-design.md`

## Global Constraints

- Do not infer DVD title identity from duration, chapter similarity, or file size alone.
- Do not remove a scanned title unless its physical playback-chain identity is proven identical.
- Do not change the main branch during implementation.
- Real DVD verification must record the source path, tool versions, title count, selected title, output duration, and output stream summary.

---

### Task 1: Stop destructive DVD title consolidation

**Files:**
- Modify: `artifacts/api-server/src/lib/handbrake-scan.ts`
- Test: `artifacts/api-server/src/lib/handbrake-scan.test.ts`

**Interfaces:**
- Consumes: parsed HandBrake titles with `titleNumber`, duration, chapters, and streams.
- Produces: all raw titles in stable `titleNumber` order; duplicate similarity may be reported but must not remove a title.

- [ ] **Step 1: Write the failing test**

Add a test with three different title numbers that have identical duration, chapter durations, and stream layouts. Assert that all three title numbers remain in the result.

- [ ] **Step 2: Run the focused test and verify it fails**

Run `pnpm --dir artifacts/api-server exec vitest run src/lib/handbrake-scan.test.ts -t "keeps three independent titles"`.

- [ ] **Step 3: Implement the minimal behavior**

Change consolidation so duration/chapter/stream similarity is an annotation or log only; the returned DVD title list must keep each distinct HandBrake `titleNumber`.

- [ ] **Step 4: Run the focused test and the existing scan tests**

Run `pnpm --dir artifacts/api-server exec vitest run src/lib/handbrake-scan.test.ts`.

- [ ] **Step 5: Commit**

Commit with `fix: preserve independent dvd titles`.

### Task 2: Add stable DVD title and stream identities

**Files:**
- Create: `artifacts/api-server/src/lib/dvd-manifest.ts`
- Test: `artifacts/api-server/src/lib/dvd-manifest.test.ts`
- Modify: `artifacts/api-server/src/lib/disc-analysis.ts`

**Interfaces:**
- Consumes: unified DVD titles and their HandBrake/FFprobe mappings.
- Produces: deterministic `titleUid`, `trackUid`, and tool mapping records.

- [ ] **Step 1: Write failing identity tests**

Assert that the same source fingerprint and title number produce the same title identity across array reordering, while different title numbers produce different identities. Assert that audio tracks with the same codec/language require an ordinal in the identity.

- [ ] **Step 2: Run tests to verify the new module is missing**

Run `pnpm --dir artifacts/api-server exec vitest run src/lib/dvd-manifest.test.ts`.

- [ ] **Step 3: Implement deterministic identity helpers**

Use normalized source fingerprint, physical/tool title number, stream type, codec, language, channel count, and type-relative ordinal. Never use array position as the title identity.

- [ ] **Step 4: Attach manifest identity to the unified analysis result**

Keep the existing tool mappings, and add stable identity fields without changing the raw HandBrake title number.

- [ ] **Step 5: Run focused tests and typecheck**

Run `pnpm --dir artifacts/api-server exec vitest run src/lib/dvd-manifest.test.ts src/lib/disc-analysis.test.ts` and `pnpm --dir artifacts/api-server typecheck`.

- [ ] **Step 6: Commit**

Commit with `feat: add stable dvd manifest identities`.

### Task 3: Freeze manifest identities in task creation and execution

**Files:**
- Modify: `artifacts/api-server/src/lib/task-snapshot.ts`
- Modify: `artifacts/api-server/src/routes/jobs.ts`
- Test: `artifacts/api-server/src/lib/task-snapshot.test.ts`
- Test: `artifacts/api-server/src/lib/windows-media-contract.test.ts`

**Interfaces:**
- Consumes: selected unified title and canonical track identities.
- Produces: task snapshots that retain title identity plus explicit HandBrake/FFprobe/MakeMKV mappings.

- [ ] **Step 1: Write failing snapshot tests**

Assert that a DVD snapshot retains `titleUid`, `trackUid` selections, and the exact HandBrake title number even when the analysis array order changes.

- [ ] **Step 2: Run focused tests and verify failure**

Run `pnpm --dir artifacts/api-server exec vitest run src/lib/task-snapshot.test.ts -t "stable dvd title identity"`.

- [ ] **Step 3: Implement snapshot fields and server validation**

Require the submitted source fingerprint, analysis ID, title identity, and tool mapping to match the registered analysis. Reject stale or ambiguous mappings rather than falling back to title order.

- [ ] **Step 4: Ensure Remux, compression, preview, and subtitle extraction use the frozen mapping**

Keep DVD title selection on the exact verified HandBrake title; use type-relative stream mappings generated from the selected manifest rather than raw indices from a different probe.

- [ ] **Step 5: Run backend tests and typecheck**

Run `pnpm --dir artifacts/api-server test` and `pnpm --dir artifacts/api-server typecheck`.

- [ ] **Step 6: Commit**

Commit with `fix: freeze dvd execution mappings`.

### Task 4: Real DVD acceptance verification

**Files:**
- Modify: `README.md`
- Create: `scripts/verify-dvd-title-manifest.ps1`
- Test: `artifacts/api-server/src/lib/windows-media-contract.test.ts`

**Interfaces:**
- Consumes: an actual DVD/VIDEO_TS path and the built MediaSculpt tools.
- Produces: a diagnostic report with raw title count, manifest title count, selected title, output validation, and subtitle presence.

- [ ] **Step 1: Add a Windows verification script**

The script must run HandBrake Title 0 scan, invoke the MediaSculpt analysis endpoint, export one selected title, run FFprobe/MKVToolNix validation, and write a readable report without deleting source files.

- [ ] **Step 2: Run the script against a real H: DVD**

Use the actual three-video DVD path and record the exact result. If HandBrake, FFprobe, and MakeMKV disagree, report the disagreement and do not mark the case as passed.

- [ ] **Step 3: Update README usage and diagnostic expectations**

Document the DVD title identity, tool roles, fallback states, and required output validation.

- [ ] **Step 4: Run full tests and build**

Run `pnpm --dir artifacts/api-server test`, `pnpm --dir artifacts/api-server typecheck`, `pnpm --dir artifacts/video-agent test`, `pnpm --dir artifacts/video-agent typecheck`, and both production builds.

- [ ] **Step 5: Commit**

Commit with `test: verify dvd manifest against real media`.
