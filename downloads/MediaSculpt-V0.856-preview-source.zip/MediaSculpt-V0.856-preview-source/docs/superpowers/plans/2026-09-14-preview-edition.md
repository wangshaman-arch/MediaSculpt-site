# V0.840 Preview 发布版 Implementation Plan

> **Version:** V 0.856 · 版本：V 0.856
> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 将 MediaSculpt 做成可公开分发的 V0.840 Preview 闭源免费试用版，具备本地 30 天/20 次成功主任务限制、可审计的第三方声明、可编辑提示词和用户设备直连 AI 服务，同时不影响扫描、预览、历史查看和已有输出。

**Architecture:** 在现有本地 SQLite 数据目录中增加独立的预览资格与成功任务流水模块；任务入口只负责调用“允许启动”检查，所有成功出口统一调用幂等结算。AI 仍由本地 API 进程使用用户配置的 Key 和端点直接请求供应商，开发者服务器不参与转发；前端通过明确的只读状态接口展示试用状态。

**Tech Stack:** TypeScript, Express 5, Drizzle ORM, SQLite (`node:sqlite`), PostgreSQL schema parity, React, React Query, OpenAPI/Orval, Vitest, Tauri/NSIS Windows packaging.

**Spec:** `docs/superpowers/specs/2026-09-14-preview-edition-design.md`

## Global Constraints

- 版本统一为 `V0.840 Preview` / `0.840.0`。
- `development` 开发启动不限主任务次数；`preview` Windows 安装包启用 30 天/20 次限制；通道由构建/启动配置明确注入。
- 试用期为首次有效启动起 30 个自然日，成功主任务上限为 20 次。
- 失败、取消、扫描、媒体信息分析、普通预览和章节预览不扣主任务次数；组合任务只扣一次。
- AI 请求单独统计，不从 20 次主任务配额扣除，也不设置 V0.840 AI 次数上限。
- 配额数据只保存在本机，不要求登录，不建立在线授权服务器。
- 软件源码和产品本身采用专有软件许可；当前 MIT 授权必须被替换。
- MakeMKV 不属于当前软件依赖、打包内容、自动下载内容或第三方清单；DVD/蓝光输入只按文件夹、ISO、M2TS、VOB 等媒体源处理。
- AI Key、视频、字幕、提示词和 AI 返回内容不得发送到 MediaSculpt 开发者服务器；请求只从用户设备发往用户配置的供应商或端点。
- 生产实现遵循 TDD：先写失败测试，确认红灯，再写最小实现，确认绿灯。
- 不修改与本功能无关的 Remux、字幕 OCR、海报或压缩算法；若现有测试引用历史 MakeMKV 名称，只在不破坏旧任务快照兼容性的前提下清理产品表述。

## File Map

- Create: `artifacts/api-server/src/lib/preview-entitlement.ts` — 无数据库依赖的试用规则、时间计算、状态与错误码。
- Create: `artifacts/api-server/src/lib/preview-entitlement.test.ts` — 规则边界和时间异常测试。
- Create: `artifacts/api-server/src/lib/preview-entitlement-repository.ts` — 本地数据库读写、初始化、AI 统计和幂等结算。
- Create: `artifacts/api-server/src/lib/preview-entitlement-repository.test.ts` — SQLite 内存数据库与重复结算测试。
- Create: `artifacts/api-server/src/routes/preview.ts` — `GET /api/preview/status` 状态接口。
- Create: `artifacts/api-server/src/routes/preview.test.ts` — 接口响应和阻止状态测试。
- Modify: `lib/db/src/schema/index.ts` — 导出两张 PostgreSQL schema 表。
- Modify: `lib/db/src/schema/preview.ts` — 添加 PostgreSQL 预览表定义。
- Modify: `lib/db/src/sqlite-schema.ts` — 添加 SQLite Drizzle 表定义。
- Modify: `lib/db/src/sqlite-init.ts` — 为旧数据库增加幂等初始化 SQL 和索引。
- Modify: `lib/db/src/index.ts` — 导出 SQLite/PostgreSQL 对应的预览表。
- Modify: `artifacts/api-server/src/routes/index.ts` — 注册预览路由。
- Modify: `artifacts/api-server/src/routes/jobs.ts` — 在任务入口和所有有效成功出口接入检查/结算，并在 AI 请求成功发送后递增本地统计。
- Modify: `artifacts/api-server/src/application/job-service.ts` — 给队列服务增加可选的启动前配额检查结果传递。
- Modify: `artifacts/api-server/src/application/job-service.test.ts` — 配额阻止启动测试。
- Modify: `artifacts/api-server/src/lib/ai-provider.ts` — 提供可注入的本地 AI 请求计数回调，不改变请求端点。
- Create: `artifacts/api-server/src/lib/preview-job-settlement.ts` — 统一封装有效输出判断后的幂等结算调用。
- Create: `artifacts/api-server/src/lib/preview-job-settlement.test.ts` — 成功、失败、取消、章节预览和重复回调测试。
- Modify: `artifacts/api-server/src/routes/assistant.ts` — AI 助手实际发出请求后计数，不记录 Key 和正文。
- Modify: `artifacts/api-server/src/routes/smart-workflow.ts` — 智能工作流 AI 请求实际发出后计数。
- Modify: `artifacts/video-agent/src/pages/Dashboard.tsx` — 显示试用状态条。
- Modify: `artifacts/video-agent/src/pages/Settings.tsx` — 增加预览版授权区域和许可证入口。
- Modify: `artifacts/video-agent/src/hooks/useAssistantAnalysis.ts` — 将提示词编辑和预览版错误展示保持为用户可理解的状态。
- Modify: `artifacts/video-agent/src/i18n/zh-CN.ts`, `artifacts/video-agent/src/i18n/en-US.ts` — 增加试用、配额、直连 AI 和专有许可文案。
- Modify: `lib/api-spec/openapi.yaml` — 增加预览状态 schema 和 endpoint。
- Regenerate: `lib/api-zod/src/generated/**`, `lib/api-client-react/src/generated/**` — 通过现有 Orval codegen 生成。
- Modify: `LICENSE`, `docs/legal-and-privacy.md`, `README.md`, `INSTALL.md`, `index.html`, `VERSION.md`, `package.json` — 统一专有免费试用说明和版本号。
- Create: `EULA.md`, `THIRD-PARTY-NOTICES.md` — 随源码和安装包提供。
- Modify: `windows-setup/README.txt`, `windows-setup/package-base.ps1`, `scripts/build-tauri.ps1` — 将许可文件、第三方声明和版本元数据纳入 Windows 基础包。
- Create: `scripts/check-release-metadata.mjs` — 阻止发布包再次出现 MIT 项目授权和 MakeMKV 当前依赖声明。

---

### Task 1: Replace the release license and document actual dependencies

**Files:**
- Modify: `LICENSE`
- Create: `EULA.md`
- Create: `THIRD-PARTY-NOTICES.md`
- Modify: `docs/legal-and-privacy.md`
- Modify: `README.md`, `INSTALL.md`, `index.html`, `VERSION.md`, `package.json`
- Test: `artifacts/api-server/src/lib/release-metadata.test.ts`

**Interfaces:**
- Produces a machine-checkable release contract: the product license is proprietary, the preview trial is free and limited, development mode is unlimited for local testing, MakeMKV is absent from current dependency notices, and every runtime-managed component has a notice entry.

- [ ] **Step 1: Write the failing release metadata test**

```ts
import { readFile } from "node:fs/promises";
import { describe, expect, it } from "vitest";

describe("V0.840 release metadata", () => {
  it("does not publish MIT as the MediaSculpt product license", async () => {
    const license = await readFile("LICENSE", "utf8");
    const packageJson = JSON.parse(await readFile("package.json", "utf8")) as { license?: string };
    expect(license).toContain("MediaSculpt Proprietary Preview License");
    expect(license).not.toMatch(/^MIT License/m);
    expect(packageJson.license).toBe("UNLICENSED");
  });

  it("lists runtime components without claiming MakeMKV is a dependency", async () => {
    const notices = await readFile("THIRD-PARTY-NOTICES.md", "utf8");
    expect(notices).toContain("FFmpeg");
    expect(notices).toContain("HandBrakeCLI");
    expect(notices).toContain("Whisper");
    expect(notices).not.toMatch(/MakeMKV|makemkv/i);
  });
});
```

- [ ] **Step 2: Run the focused test and verify it fails**

Run from `artifacts/api-server`:
`& "$env:USERPROFILE\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" node_modules/vitest/vitest.mjs run src/lib/release-metadata.test.ts`

Expected: FAIL because the repository still declares MIT and has no `THIRD-PARTY-NOTICES.md`.

- [ ] **Step 3: Write the proprietary documents**

`LICENSE` must state that MediaSculpt source code, UI, branding and documentation are proprietary, that V0.840 Preview is a non-transferable free trial, and that copying, modifying or redistributing MediaSculpt itself requires written permission. `EULA.md` must cover trial limits, local processing, user responsibility for media rights, no warranty, and direct third-party AI requests. `THIRD-PARTY-NOTICES.md` must list only components actually bundled or managed by the current runtime: Tauri, Node.js, React, FFmpeg/FFprobe, HandBrakeCLI, Whisper/runtime models, RapidOCR, Tesseract and other packages found by the release inventory. It must not list MakeMKV.

- [ ] **Step 4: Update product and installer references**

Replace the current MIT wording in legal docs, README and the GitHub release page. Set the root package license to `UNLICENSED`, update all release-facing version labels to `V0.840 Preview` / `0.840.0`, and include the EULA and notices in the base installer archive.

- [ ] **Step 5: Run the focused test and verify it passes**

Run the same Vitest command. Expected: PASS.

- [ ] **Step 6: Commit**

`git add LICENSE EULA.md THIRD-PARTY-NOTICES.md docs/legal-and-privacy.md README.md INSTALL.md index.html VERSION.md package.json artifacts/api-server/src/lib/release-metadata.test.ts && git commit -m "docs: prepare proprietary v0.840 preview release"`

### Task 2: Add the pure preview policy module

**Files:**
- Create: `artifacts/api-server/src/lib/preview-entitlement.ts`
- Create: `artifacts/api-server/src/lib/preview-entitlement.test.ts`

**Interfaces:**
- Produces `PreviewStatus`, `PreviewBlockedReason`, `PreviewPolicy`, `createPreviewState(now, installationId)`, `evaluatePreviewStatus(state, now, policy)`, and `previewErrorCode(reason)`.

- [ ] **Step 1: Write failing policy tests**

```ts
import { describe, expect, it } from "vitest";
import { createPreviewState, evaluatePreviewStatus, type PreviewPolicy } from "./preview-entitlement";

const policy: PreviewPolicy = { taskLimit: 20, trialDays: 30 };
const date = (value: string) => new Date(value);

describe("preview entitlement policy", () => {
  it("starts at 20 tasks and expires after 30 calendar days", () => {
    const state = createPreviewState(date("2026-09-14T04:00:00.000Z"), "install-1", policy);
    expect(state.successfulTaskCount).toBe(0);
    expect(state.expiresAt.toISOString()).toBe("2026-10-14T04:00:00.000Z");
    expect(evaluatePreviewStatus(state, date("2026-09-20T04:00:00.000Z"), policy)).toMatchObject({ remainingTasks: 20, blockedReason: null });
  });

  it("blocks on quota or expiry but permits ordinary app viewing", () => {
    const state = { ...createPreviewState(date("2026-09-14T00:00:00.000Z"), "install-1", policy), successfulTaskCount: 20 };
    expect(evaluatePreviewStatus(state, date("2026-09-20T00:00:00.000Z"), policy).blockedReason).toBe("quota_exhausted");
    expect(evaluatePreviewStatus({ ...state, successfulTaskCount: 0 }, date("2026-10-15T00:00:00.000Z"), policy).blockedReason).toBe("expired");
  });

  it("detects a clock moving backwards", () => {
    const state = { ...createPreviewState(date("2026-09-14T00:00:00.000Z"), "install-1", policy), lastSeenAt: date("2026-09-20T00:00:00.000Z") };
    expect(evaluatePreviewStatus(state, date("2026-09-19T00:00:00.000Z"), policy).blockedReason).toBe("clock_invalid");
  });
});
```

- [ ] **Step 2: Run the test and verify it fails**

Run: `vitest run src/lib/preview-entitlement.test.ts`

Expected: FAIL because the module and types do not exist.

- [ ] **Step 3: Implement the pure rule functions**

Use UTC timestamps for persistence, compute the deadline by adding 30 calendar days to the first-start timestamp, clamp `remainingTasks` to zero, and make `clock_invalid` win before quota/expiry. Do not read environment variables, filesystem state or the database in this module.

- [ ] **Step 4: Run the test and verify it passes**

Run: `vitest run src/lib/preview-entitlement.test.ts`

Expected: PASS.

- [ ] **Step 5: Commit**

`git add artifacts/api-server/src/lib/preview-entitlement.ts artifacts/api-server/src/lib/preview-entitlement.test.ts && git commit -m "feat: add deterministic preview entitlement policy"`

### Task 3: Persist entitlement state and idempotent usage

**Files:**
- Create: `lib/db/src/schema/preview.ts`
- Modify: `lib/db/src/schema/index.ts`, `lib/db/src/sqlite-schema.ts`, `lib/db/src/sqlite-init.ts`, `lib/db/src/index.ts`
- Create: `artifacts/api-server/src/lib/preview-entitlement-repository.ts`
- Create: `artifacts/api-server/src/lib/preview-entitlement-repository.test.ts`

**Interfaces:**
- `PreviewEntitlementRepository.getOrCreate(now: Date): Promise<PreviewEntitlementRecord>`
- `PreviewEntitlementRepository.getStatus(now: Date): Promise<PreviewStatus>`
- `PreviewEntitlementRepository.chargeTaskOnce(input: { jobId: number; taskKind: string; chargedAt: Date }): Promise<{ charged: boolean; successfulTaskCount: number }>`
- `PreviewEntitlementRepository.recordAiCall(now: Date): Promise<number>`

- [ ] **Step 1: Write failing schema/repository tests**

```ts
it("creates one entitlement row and preserves it across reads", async () => {
  const repository = createPreviewEntitlementRepository(createTestDatabase(), { now: () => new Date("2026-09-14T00:00:00.000Z") });
  const first = await repository.getOrCreate(new Date("2026-09-14T00:00:00.000Z"));
  const second = await repository.getOrCreate(new Date("2026-09-15T00:00:00.000Z"));
  expect(second.installationId).toBe(first.installationId);
  expect(second.successfulTaskCount).toBe(0);
  expect(second.aiCallCount).toBe(0);
});

it("charges the same job only once and keeps AI calls separate", async () => {
  const repository = createPreviewEntitlementRepository(createTestDatabase());
  await repository.getOrCreate(new Date("2026-09-14T00:00:00.000Z"));
  await expect(repository.chargeTaskOnce({ jobId: 7, taskKind: "compress", chargedAt: new Date() })).resolves.toEqual({ charged: true, successfulTaskCount: 1 });
  await expect(repository.chargeTaskOnce({ jobId: 7, taskKind: "compress", chargedAt: new Date() })).resolves.toEqual({ charged: false, successfulTaskCount: 1 });
  await expect(repository.recordAiCall(new Date())).resolves.toBe(1);
});
```

- [ ] **Step 2: Run the test and verify it fails**

Run: `vitest run src/lib/preview-entitlement-repository.test.ts`

Expected: FAIL because the schema, initializer and repository are absent.

- [ ] **Step 3: Add both database dialect schemas and initialization**

Create `preview_entitlements` with the single-row primary key, installation ID, UTC timestamps, limits and counters. Create `preview_task_usage` with a unique `job_id` and indexes for lookup. Add both tables to the PostgreSQL Drizzle schema and SQLite schema. Extend `initializeSqliteDatabase` with `CREATE TABLE IF NOT EXISTS` and `CREATE UNIQUE INDEX IF NOT EXISTS`, without deleting or rewriting old rows.

- [ ] **Step 4: Implement repository transactions**

For SQLite use the existing local database connection and an atomic `BEGIN IMMEDIATE` transaction so the unique `job_id` insert and counter increment cannot race. For PostgreSQL use a Drizzle transaction. Treat a unique constraint conflict as already charged. Generate the installation ID once with a cryptographically random UUID and store it in the local data directory. Never include API keys, media paths, prompts or output text in these tables.

- [ ] **Step 5: Run the test and verify it passes**

Run: `vitest run src/lib/preview-entitlement-repository.test.ts`

Expected: PASS.

- [ ] **Step 6: Commit**

`git add lib/db artifacts/api-server/src/lib/preview-entitlement-repository.ts artifacts/api-server/src/lib/preview-entitlement-repository.test.ts && git commit -m "feat: persist local preview usage idempotently"`

### Task 4: Add the preview API and block task starts

**Files:**
- Create: `artifacts/api-server/src/routes/preview.ts`
- Create: `artifacts/api-server/src/routes/preview.test.ts`
- Modify: `artifacts/api-server/src/routes/index.ts`
- Modify: `artifacts/api-server/src/application/job-service.ts`, `artifacts/api-server/src/application/job-service.test.ts`
- Modify: `artifacts/api-server/src/routes/jobs.ts`
- Modify: `lib/api-spec/openapi.yaml`
- Regenerate: `lib/api-zod/src/generated/**`, `lib/api-client-react/src/generated/**`

**Interfaces:**
- `GET /api/preview/status` returns the exact status object in the spec.
- `assertPreviewTaskAllowed(now): Promise<void>` throws `PREVIEW_LIMIT_EXPIRED`, `PREVIEW_LIMIT_EXHAUSTED`, or `PREVIEW_LIMIT_CLOCK_INVALID`.
- `chargePreviewTaskOnSuccess(jobId, taskKind, hasValidOutput): Promise<void>` charges only when output validation is true.

- [ ] **Step 1: Write failing route and service tests**

```ts
it("returns a stable preview status payload", async () => {
  const response = await request(app).get("/api/preview/status");
  expect(response.status).toBe(200);
  expect(response.body).toMatchObject({ edition: "preview", taskLimit: 20, successfulTaskCount: 0, remainingTasks: 20, blockedReason: null });
});

it("does not start a job when preview quota is exhausted", async () => {
  const gate = vi.fn(async () => { throw new PreviewLimitError("PREVIEW_LIMIT_EXHAUSTED", "预览版成功任务次数已用完"); });
  const service = createJobService({ assertPreviewTaskAllowed: gate });
  await expect(service.start(7)).resolves.toMatchObject({ kind: "preview-blocked", code: "PREVIEW_LIMIT_EXHAUSTED" });
  expect(gate).toHaveBeenCalledOnce();
});
```

- [ ] **Step 2: Run tests and verify they fail**

Run: `vitest run src/routes/preview.test.ts src/application/job-service.test.ts`

Expected: FAIL because the endpoint, error type and service result do not exist.

- [ ] **Step 3: Implement the repository-backed route and start guard**

Register the new router before `jobsRouter`. Ensure `POST /jobs/:id/start`, retry-start, queue-start and automatic next-pending start all pass through the same guard before any media tool is spawned. A blocked start returns HTTP 409 with `{ errorCode, error, preview }`; it must not be written as an ordinary FFmpeg failure.

- [ ] **Step 4: Add the OpenAPI contract and regenerate clients**

Add the preview status response and `GET /preview/status` to `lib/api-spec/openapi.yaml`, then run `pnpm --filter @workspace/api-spec codegen`. Confirm generated Zod and React Query exports contain `getPreviewStatus` and `useGetPreviewStatus`.

- [ ] **Step 5: Run focused tests, typecheck and codegen check**

Run from the repository root:
`pnpm --filter @workspace/api-server test -- src/routes/preview.test.ts src/application/job-service.test.ts`
`pnpm run typecheck:libs`
`pnpm run check:generated`

Expected: PASS.

- [ ] **Step 6: Commit**

`git add artifacts/api-server/src/routes/preview.ts artifacts/api-server/src/routes/preview.test.ts artifacts/api-server/src/application/job-service.ts artifacts/api-server/src/application/job-service.test.ts artifacts/api-server/src/routes/index.ts artifacts/api-server/src/routes/jobs.ts lib/api-spec lib/api-zod lib/api-client-react && git commit -m "feat: expose preview status and guard task starts"`

### Task 5: Charge only verified successful outputs and count AI calls locally

**Files:**
- Modify: `artifacts/api-server/src/routes/jobs.ts`
- Modify: `artifacts/api-server/src/lib/ai-provider.ts`
- Modify: `artifacts/api-server/src/routes/assistant.ts`, `artifacts/api-server/src/routes/smart-workflow.ts`
- Create: `artifacts/api-server/src/lib/preview-job-settlement.ts`
- Create: `artifacts/api-server/src/lib/preview-job-settlement.test.ts`

**Interfaces:**
- `recordAiCall?: (kind: string) => Promise<void>` is an optional local callback passed to AI request helpers.
- `settlePreviewJob(input: { jobId: number; taskKind: string; outputValid: boolean; isPreviewOnly: boolean; cancelled: boolean }): Promise<{ charged: boolean }>` is called after output validation and decides whether the repository is charged.

- [ ] **Step 1: Write failing lifecycle tests**

```ts
it("charges a completed compression job once", async () => {
  await settlePreviewJob({ jobId: 11, taskKind: "compress", outputValid: true, isPreviewOnly: false, cancelled: false });
  await settlePreviewJob({ jobId: 11, taskKind: "compress", outputValid: true, isPreviewOnly: false, cancelled: false });
  expect(await repository.getStatus(now())).toMatchObject({ successfulTaskCount: 1 });
});

it("does not charge failure, cancellation or preview", async () => {
  for (const result of [
    { outputValid: false, isPreviewOnly: false, cancelled: false },
    { outputValid: true, isPreviewOnly: false, cancelled: true },
    { outputValid: true, isPreviewOnly: true, cancelled: false },
  ]) {
    await settlePreviewJob({ jobId: 12, taskKind: "chapter-preview", ...result });
  }
  expect(await repository.getStatus(now())).toMatchObject({ successfulTaskCount: 0 });
});
```

- [ ] **Step 2: Run tests and verify they fail**

Run the focused job/lifecycle tests. Expected: FAIL because the success exits do not call the repository.

- [ ] **Step 3: Centralize successful-task settlement**

Add one local helper in `jobs.ts` that receives the job ID, task kind and output validation result. Call it from the final success paths for normal compression, Remux, subtitle-only processing, and combined pipelines. Do not call it from scanning, chapter preview, metadata/poster/readme/review-only generation, error, cancel or invalid-output paths. For partial completion, charge only when the task’s declared main output is valid and persist the existing partial-status message.

- [ ] **Step 4: Count actual remote AI requests only after dispatch**

Increment `ai_call_count` after a remote request is accepted for dispatch, including assistant analysis and smart-workflow metadata calls. Do not count connection tests that do not process media, local OCR, local translation or failed preflight with no request. Log only provider label, model and duration; never log Key, prompt body, subtitle text or media bytes. Keep requests pointed at the configured endpoint and do not add a developer proxy URL.

- [ ] **Step 5: Run focused tests and full API tests**

Run:
`pnpm --filter @workspace/api-server test -- src/lib/preview-entitlement-repository.test.ts src/application/job-service.test.ts`
`pnpm --filter @workspace/api-server test`

Expected: all tests PASS and duplicate success callbacks leave the counter unchanged.

- [ ] **Step 6: Commit**

`git add artifacts/api-server/src/routes/jobs.ts artifacts/api-server/src/lib/ai-provider.ts artifacts/api-server/src/routes/assistant.ts artifacts/api-server/src/routes/smart-workflow.ts artifacts/api-server/src/**/*.test.ts && git commit -m "feat: settle preview tasks and track local ai calls"`

### Task 6: Add user-facing preview status and editable AI disclosure

**Files:**
- Modify: `artifacts/video-agent/src/pages/Dashboard.tsx`
- Modify: `artifacts/video-agent/src/pages/Settings.tsx`
- Modify: `artifacts/video-agent/src/hooks/useAssistantAnalysis.ts`
- Modify: `artifacts/video-agent/src/i18n/zh-CN.ts`, `artifacts/video-agent/src/i18n/en-US.ts`
- Create: `artifacts/video-agent/src/components/PreviewStatusBar.tsx`
- Create: `artifacts/video-agent/src/components/PreviewStatusBar.test.tsx`

**Interfaces:**
- Frontend consumes `useGetPreviewStatus({ query: { refetchInterval: 5000 } })`.
- The status bar renders `remainingTasks`, `expiresAt`, `aiCallCount` and `blockedReason` without exposing installation ID.

- [ ] **Step 1: Write failing UI/model tests**

```ts
it("shows remaining preview tasks and AI calls", () => {
  render(<PreviewStatusBar status={{ edition: "preview", isActive: true, firstStartedAt: "2026-09-14T00:00:00.000Z", expiresAt: "2026-10-14T00:00:00.000Z", daysRemaining: 30, taskLimit: 20, successfulTaskCount: 3, remainingTasks: 17, aiCallCount: 4, blockedReason: null }} />);
  expect(screen.getByText("17/20")).toBeInTheDocument();
  expect(screen.getByText(/AI.*4/)).toBeInTheDocument();
});

it("shows a non-payment blocking message when exhausted", () => {
  render(<PreviewStatusBar status={{ edition: "preview", isActive: false, firstStartedAt: "2026-09-14T00:00:00.000Z", expiresAt: "2026-10-14T00:00:00.000Z", daysRemaining: 0, taskLimit: 20, successfulTaskCount: 20, remainingTasks: 0, aiCallCount: 0, blockedReason: "quota_exhausted" }} />);
  expect(screen.getByText(/预览版.*次数已用完/)).toBeInTheDocument();
  expect(screen.queryByText(/订阅|欠费/)).not.toBeInTheDocument();
});
```

- [ ] **Step 2: Run tests and verify they fail**

Run the video-agent Vitest command for the new test. Expected: FAIL because the status component and generated hook are absent.

- [ ] **Step 3: Implement the status bar and Settings section**

Keep the Dashboard strip compact. Settings must show first-start date, expiration date, successful count, remaining count, AI call count, and a link/button that opens the local EULA and third-party notices. Do not display the installation ID or any secret. Before a task starts, show “成功完成后消耗 1 次；失败或取消不消耗”；when blocked, disable only new full-task starts while keeping scan, preview, history and existing outputs available.

- [ ] **Step 4: Update direct-AI wording and error handling**

Make the editable prompt control explicit: MediaSculpt supplies a template, the user may edit it, the user supplies the Key, and the request goes from this computer to the selected provider. A `PREVIEW_LIMIT_*` response must render as a trial-limit notice, not as a generic AI or FFmpeg error.

- [ ] **Step 5: Run frontend tests and typecheck**

Run: `pnpm --filter @workspace/video-agent test` and `pnpm --filter @workspace/video-agent typecheck`.

Expected: PASS.

- [ ] **Step 6: Commit**

`git add artifacts/video-agent/src/pages/Dashboard.tsx artifacts/video-agent/src/pages/Settings.tsx artifacts/video-agent/src/hooks/useAssistantAnalysis.ts artifacts/video-agent/src/i18n artifacts/video-agent/src/**/*.test.ts && git commit -m "feat: show preview limits and direct ai disclosure"`

### Task 7: Package and verify the Windows preview release

**Files:**
- Modify: `windows-setup/README.txt`, `windows-setup/package-base.ps1`, `scripts/build-tauri.ps1`
- Create: `artifacts/api-server/src/lib/release-package-contract.test.ts`
- Modify: `README.md`, `INSTALL.md`, `VERSION.md` if version checks find stale release labels

**Interfaces:**
- The base installer contains the MediaSculpt executable, `EULA.md`, `THIRD-PARTY-NOTICES.md`, and the proprietary `LICENSE`.
- The package does not contain MakeMKV binaries, MakeMKV installers or MakeMKV auto-install entries.

- [ ] **Step 1: Write failing package contract tests**

```ts
it("packages the preview legal files and no MakeMKV payload", async () => {
  const manifest = await readReleasePackageManifestFrom("windows-setup/package-base.ps1");
  expect(manifest.version).toBe("0.840.0");
  expect(manifest.files).toEqual(expect.arrayContaining(["LICENSE", "EULA.md", "THIRD-PARTY-NOTICES.md"]));
  expect(manifest.files.some((file) => /makemkv/i.test(file))).toBe(false);
});
```

- [ ] **Step 2: Run the test and verify it fails**

Run the package contract test. Expected: FAIL until the packaging manifest and version metadata are updated.

- [ ] **Step 3: Update the Windows base package**

Keep the base package self-contained with the current runtime behavior, include the legal files in the archive/installer, and make the installer display the EULA. Do not add MakeMKV detection, download, import or payload. The installer must preserve `%LOCALAPPDATA%\MediaSculpt` data during upgrade so entitlement state survives normal updates.

- [ ] **Step 4: Run the full verification suite**

Run from the repository root:
`pnpm test`
`pnpm run typecheck`
`pnpm run check:generated`
`pnpm --filter @workspace/api-server run build`

Expected: all tests, generated-file checks, typechecks and API build pass.

- [ ] **Step 5: Build and test a real Windows install**

Run the existing base packaging script to produce `MediaSculpt_0.840.0_x64-setup-base.exe`. Install it on Windows 11, start it once, confirm the UI shows 20/20 and a 30-day deadline, complete one small valid task and confirm 19/20, then force a local test database to 20/20 and confirm a new full-task start is rejected without starting FFmpeg/HandBrake/Whisper. Confirm scan, preview and history remain usable. Verify the installer and runtime logs contain no API Key, prompt body, subtitle text or media content.

- [ ] **Step 6: Commit the release packaging changes**

`git add windows-setup scripts artifacts/api-server/src/lib/release-package-contract.test.ts README.md INSTALL.md VERSION.md && git commit -m "release: package v0.840 preview for windows"`

## Final Review Checklist

- [ ] `LICENSE` no longer grants MIT rights to MediaSculpt source.
- [ ] `EULA.md` and `THIRD-PARTY-NOTICES.md` are present in the installer.
- [ ] Third-party notices match actual bundled or runtime-managed components; MakeMKV is excluded.
- [ ] SQLite migration is upgrade-safe and stores no media or AI secrets.
- [ ] Every complete valid main task charges exactly once.
- [ ] Failures, cancellation, scans and previews do not charge.
- [ ] AI call count is separate and direct-provider behavior remains intact.
- [ ] UI clearly shows remaining tasks, deadline and AI calls without exposing secrets.
- [ ] V0.840 Preview metadata is consistent across source, installer and release page.
- [ ] Full tests, typecheck, build and real Windows install verification pass before claiming release readiness.
