# MediaSculpt Tauri Desktop Migration Implementation Plan

> **Version:** V 0.856 · 版本：V 0.856
> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver MediaSculpt as a Tauri 2 Windows app with a native window, installed shortcut, and managed existing Node API sidecar.

**Architecture:** Tauri owns the native window, package and lifecycle. The React app remains the renderer and the Node API remains a bundled sidecar for existing media tooling.

**Tech Stack:** Tauri 2, Rust, WebView2, Node.js 22, React/Vite, Express, NSIS.

**Spec:** `docs/superpowers/specs/2026-08-18-mediasculpt-tauri-desktop-design.md`

## Global Constraints

- Keep version `V 0.832`; only bump on a user-requested release.
- The product identity is `MediaSculpt` / `影刻`, application id `com.wangshaman.mediasculpt`.
- New runtime names use `MEDIASCULPT_*`; `VX_AGENT_*` are compatibility fallbacks only.
- Copy legacy `%LOCALAPPDATA%\\VX-Agent` data and tools without deleting them.
- Production installer must not include or depend on Electron.

---

### Task 1: Scaffold and test the Tauri product configuration

**Files:**
- Create: `desktop-tauri/package.json`
- Create: `desktop-tauri/src-tauri/Cargo.toml`
- Create: `desktop-tauri/src-tauri/tauri.conf.json`
- Create: `desktop-tauri/src-tauri/build.rs`
- Create: `desktop-tauri/src-tauri/icons/icon.ico`
- Test: `artifacts/api-server/src/lib/tauri-contract.test.ts`

**Produces:** NSIS configuration with product name `MediaSculpt`, identifier `com.wangshaman.mediasculpt`, and the supplied icon.

- [ ] Write a failing contract test that parses `tauri.conf.json` and asserts the product name, identifier, NSIS target, and icon path.
- [ ] Run `pnpm --filter @workspace/api-server test -- tauri-contract.test.ts` and verify it fails because the configuration is absent.
- [ ] Create the minimal Tauri 2 workspace and configuration, then copy `artifacts/video-agent/public/mediasculpt.ico` to the Tauri icon location.
- [ ] Re-run the contract test and verify it passes.
- [ ] Commit with `git commit -m "feat: add MediaSculpt Tauri configuration"`.

### Task 2: Add a managed Node API sidecar

**Files:**
- Create: `desktop-tauri/src-tauri/src/main.rs`
- Create: `desktop-tauri/src-tauri/src/sidecar.rs`
- Test: `desktop-tauri/src-tauri/src/sidecar.rs`
- Modify: `artifacts/api-server/src/routes/runtime.ts`

**Produces:** `SidecarManager` that starts Node with `PORT=8080` and `MEDIASCULPT_AUTO_SHUTDOWN=0`, waits for `/api/healthz`, and calls `/api/shutdown` on close.

- [ ] Write a failing Rust unit test asserting `is_ready_status(200)` is true and `is_ready_status(503)` is false.
- [ ] Run `cargo test --manifest-path desktop-tauri/src-tauri/Cargo.toml health_endpoint` and verify it fails because the helper is absent.
- [ ] Implement health polling, child-process log redirection to `mediasculpt-diagnostics.log`, and graceful shutdown requests.
- [ ] Re-run the Rust test and verify it passes.
- [ ] Commit with `git commit -m "feat: manage API sidecar from Tauri"`.

### Task 3: Bridge the React renderer to native Tauri commands

**Files:**
- Create: `artifacts/video-agent/src/lib/desktop-bridge.ts`
- Test: `artifacts/video-agent/src/lib/desktop-bridge.test.ts`
- Modify: `artifacts/video-agent/src/App.tsx`
- Modify: `artifacts/video-agent/src/pages/Jobs.tsx`
- Modify: `artifacts/video-agent/src/pages/JobDetail.tsx`
- Modify: `artifacts/video-agent/src/global.d.ts`
- Modify: `desktop-tauri/src-tauri/src/main.rs`

**Produces:** `openDesktopPath(path)` and `setDesktopTheme(theme)` frontend helpers that invoke Tauri commands in the desktop app and safely fall back in browser development.

- [ ] Write failing Vitest assertions for Tauri detection with and without `__TAURI_INTERNALS__`.
- [ ] Run `pnpm --filter @workspace/video-agent test -- desktop-bridge.test.ts` and verify it fails because the bridge is absent.
- [ ] Implement the bridge and matching Rust `open_path` and `set_theme` commands.
- [ ] Re-run the test and `pnpm --filter @workspace/video-agent typecheck`.
- [ ] Commit with `git commit -m "feat: connect frontend to Tauri desktop bridge"`.

### Task 4: Build a Windows installer and shortcut

**Files:**
- Create: `scripts/build-tauri.ps1`
- Modify: `desktop-tauri/package.json`
- Modify: `desktop-tauri/src-tauri/tauri.conf.json`
- Modify: `windows-setup/install.ps1`
- Test: `artifacts/api-server/src/lib/tauri-contract.test.ts`

**Produces:** `MediaSculpt_*.exe` NSIS installer containing React assets, Node API sidecar inputs, and the MediaSculpt icon.

- [ ] Extend the contract test to require API sidecar resources and the configured icon.
- [ ] Run the contract test and verify it fails before resource configuration exists.
- [ ] Implement `scripts/build-tauri.ps1`: build API, build frontend, stage Node sidecar resources, then execute `tauri build --bundles nsis`.
- [ ] Run `powershell -ExecutionPolicy Bypass -File scripts/build-tauri.ps1` and verify that a MediaSculpt NSIS installer exists.
- [ ] Commit with `git commit -m "feat: package MediaSculpt as a Tauri installer"`.

### Task 5: Switch production delivery from Electron to Tauri

**Files:**
- Modify: `windows-setup/start-services.ps1`
- Modify: `windows-setup/update.ps1`
- Modify: `README.md`
- Modify: `desktop-shell/README.md`
- Modify: `artifacts/api-server/src/lib/windows-launcher-contract.test.ts`

**Produces:** a production shortcut and installer path that starts Tauri only; Electron remains no more than an explicitly labeled temporary development fallback until release verification succeeds.

- [ ] Add failing contract assertions that the production installer names MediaSculpt/Tauri and does not reference `electron.exe`.
- [ ] Run `pnpm --filter @workspace/api-server test -- windows-launcher-contract.test.ts` and verify it fails before the production path is changed.
- [ ] Switch normal installation, launcher, update, and documentation flows to the Tauri executable.
- [ ] Run `pnpm --filter @workspace/api-server test; pnpm --filter @workspace/video-agent test; pnpm run typecheck; powershell -ExecutionPolicy Bypass -File scripts/build-tauri.ps1`.
- [ ] Commit with `git commit -m "feat: make Tauri the MediaSculpt production shell"`.

---

# MediaSculpt（影刻）Tauri 桌面版迁移实施计划

英文部分是可执行清单。该计划将先建立 Tauri 原生壳，再接入 Node 后台服务和前端桥接，随后制作带图标与快捷方式的 Windows 安装包，最后将正式交付入口从 Electron 切换为 Tauri。

