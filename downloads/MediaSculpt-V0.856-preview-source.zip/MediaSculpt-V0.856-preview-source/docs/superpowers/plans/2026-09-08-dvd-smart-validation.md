# DVD Smart Validation Implementation Plan

> **Version:** V 0.856 · 版本：V 0.856
> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Turn DVD smart analysis into a deterministic validated-title manifest that safely selects independent features and is shared by all output modes.

**Architecture:** Keep tool execution in the existing DVD remux module, add a pure `dvd-smart-validation` decision module for candidate scoring, duplicate grouping, and physical-capacity accounting, and make the smart route orchestrate both. The frontend applies the returned manifest to all title, stream, and chapter selections; AI is optional metadata on top of the deterministic result.

**Tech Stack:** TypeScript, Express, Vitest, React, OpenAPI generated types, FFprobe/FFmpeg/HandBrake.

**Spec:** `docs/superpowers/specs/2026-09-08-dvd-smart-validation-design.md`

## Global Constraints

- Never treat a logical DVD title number as a physical VTS number.
- Never invent an exact title size when a physical mapping is unknown.
- Never automatically select an unavailable, failed-read, empty, short-menu, or duplicate candidate.
- AI may rank or explain validated candidates but cannot create ids or stream mappings.
- Remux, compression, and subtitle jobs must consume the same final selection manifest.
- Preserve existing uncommitted user changes and remain on a non-main branch.

---

### Task 1: Define the deterministic DVD decision model

**Files:**
- Create: `artifacts/api-server/src/lib/dvd-smart-validation.test.ts`
- Create: `artifacts/api-server/src/lib/dvd-smart-validation.ts`

**Interfaces:**
- `DvdSmartCandidateInput` contains `titleId`, `titleNumber`, `durationSeconds`, `chapterStarts`, `streamSignature`, `availabilityStatus`, `verificationStatus`, and optional `physicalVtsNumbers`.
- `validateDvdCandidates(input): DvdSmartDecision` returns `selectedTitleIds`, candidate verdicts, `confidence`, `requiresUserSelection`, and `capacity`.
- `DvdSmartDecision` contains `physicalBytes`, `countedPhysicalBytes`, `coveragePercent`, and reasons suitable for API/UI display.

- [ ] **Step 1: Write failing pure tests** for three independent long titles, a strong duplicate pair, a failed/unavailable title, a short menu, unknown VTS mapping, and mapped-VTS capacity counted once.
- [ ] **Step 2: Run the focused test** with `pnpm --filter @workspace/api-server test -- dvd-smart-validation.test.ts`; confirm the new module/tests fail because the model is absent.
- [ ] **Step 3: Implement the pure selector** with explicit thresholds: meaningful feature duration at least 300 seconds, menu/extra exclusion only when a long feature exists, strong fingerprint equality for duplicate grouping, and collection selection for distinct long candidates.
- [ ] **Step 4: Implement physical capacity accounting** by summing each mapped VTS group once and clamping reported counted bytes to `physicalBytes`; leave unknown mapping uncounted and lower confidence to `medium`.
- [ ] **Step 5: Run the focused tests** and confirm all decision cases pass.

### Task 2: Add bounded real-tool title validation

**Files:**
- Modify: `artifacts/api-server/src/lib/dvd-remux.ts`
- Create: `artifacts/api-server/src/lib/dvd-title-validation.test.ts`
- Create: `artifacts/api-server/src/lib/dvd-title-validation.ts`

**Interfaces:**
- `validateDvdTitleRead(input, run): Promise<DvdTitleReadEvidence>` runs probe/read checks through the injected `ExternalToolRunner`.
- `DvdTitleReadEvidence` has `status`, `durationSeconds`, `videoFrameCount`, `timestampStatus`, `warnings`, and `failureReason`.

- [ ] **Step 1: Write failing tests** for successful probe/read evidence, non-zero FFprobe, empty output, missing video evidence, and non-monotonic timestamp diagnostics.
- [ ] **Step 2: Run the focused tests** and confirm failure before implementation.
- [ ] **Step 3: Export the minimal reusable FFmpeg short-read argument builder** from `dvd-remux.ts` without changing existing Remux arguments.
- [ ] **Step 4: Implement the validator** with three bounded windows (beginning, middle, end), FFprobe JSON evidence, and a non-empty null-output read. Treat any failed window as unreadable; do not accept an exit code alone.
- [ ] **Step 5: Run unit tests** and existing `dvd-remux` tests.

### Task 3: Orchestrate smart analysis into a final manifest

**Files:**
- Modify: `artifacts/api-server/src/routes/jobs.ts`
- Modify: `artifacts/api-server/src/lib/dvd-llm.ts`
- Modify: `artifacts/api-server/src/lib/disc-analysis.ts`
- Create: `artifacts/api-server/src/lib/dvd-smart-manifest.test.ts`

**Interfaces:**
- `buildDvdSmartManifest(analysis, dependencies): Promise<SmartDvdManifest>` validates every candidate, calls the pure selector, then optionally attaches an AI ranking that has passed id/index validation.
- `SmartDvdManifest` is the single response/snapshot contract for selected title ids, selected stream indices, candidate evidence, capacity, confidence, and reasons.

- [ ] **Step 1: Write route/manifest tests** proving the endpoint selects all three independent features, excludes a failed title, and returns a low-confidence manual-selection result when evidence conflicts.
- [ ] **Step 2: Run the focused tests** and confirm failure before orchestration exists.
- [ ] **Step 3: Implement manifest construction** from the cached analysis and real-tool validator, preserving stable title/stream UIDs and never assigning physical mappings from title numbers.
- [ ] **Step 4: Update LLM payload and validation** to accept only the validated candidate manifest and to return optional ranking/explanation metadata without changing the deterministic selection.
- [ ] **Step 5: Replace the smart route’s one-title response** with the manifest response while preserving `applied`, `titleId`, and legacy fields for existing clients.
- [ ] **Step 6: Run API tests and typecheck** for the route and manifest contract.

### Task 4: Apply the manifest consistently in the Scan UI and jobs

**Files:**
- Modify: `artifacts/video-agent/src/pages/Scan.tsx`
- Modify: `artifacts/video-agent/src/i18n/zh-CN.ts`
- Modify: `artifacts/video-agent/src/i18n/en-US.ts`
- Modify: `artifacts/api-server/src/lib/task-snapshot.ts`
- Create: `artifacts/video-agent/src/pages/Scan.smart-analysis.test.tsx`

**Interfaces:**
- The smart response supplies `selectedTitleIds`, `selectedStreamsByTitle`, `confidence`, `requiresUserSelection`, `capacity`, `candidates`, and `reasons`.
- `runSmartParse` maps title ids to indices, initializes default streams/chapters for every selected title, and stores the manifest used by `handleCreate`.

- [ ] **Step 1: Write failing UI tests** for applying three selected titles, keeping failed titles unselected, and disabling progression for low confidence.
- [ ] **Step 2: Run the focused UI tests** and confirm failure before the new response is consumed.
- [ ] **Step 3: Update `runSmartParse`** to replace the selected set and active title from the manifest, initialize every selected title, and display capacity/confidence/reasons.
- [ ] **Step 4: Update creation payload/snapshot** so every created job contains the same smart manifest identifier and selected title UID/stream indices.
- [ ] **Step 5: Add concise Chinese/English UI messages** for validated, incomplete-capacity, and manual-selection states.
- [ ] **Step 6: Run frontend tests and typecheck**.

### Task 5: Synchronize API contracts and documentation

**Files:**
- Modify: `lib/api-spec/openapi.yaml`
- Regenerate: `lib/api-client-react/src/generated/api.schemas.ts`
- Regenerate: `lib/api-zod/src/generated/api.ts`
- Regenerate: `lib/api-zod/src/generated/types/index.ts`
- Create/modify: generated smart-manifest type files under `lib/api-zod/src/generated/types/`
- Modify: `README.md`

- [ ] **Step 1: Add the `SmartDvdManifest` schema** and smart endpoint response fields to OpenAPI.
- [ ] **Step 2: Run the repository’s existing API generation command** and inspect the diff for only expected generated files.
- [ ] **Step 3: Update README** with DVD smart-analysis behavior, physical-size limitations, installation, and the manual-selection fallback.
- [ ] **Step 4: Run API generation/typecheck** and confirm generated code compiles.

### Task 6: Real-DVD verification and cleanup

**Files:**
- Modify only files shown by the implementation diff; remove only newly introduced unused/debug files.
- Update: `VERSION.md` to the next feature version only if the repository’s current release workflow requires it.

- [ ] **Step 1: Run the full test suite** with `pnpm test`.
- [ ] **Step 2: Run `pnpm typecheck`, `pnpm build`, and `git diff --check`**; fix every compilation or formatting error.
- [ ] **Step 3: Run the rebuilt source API against representative DVD folders on `H:`** and record title count, selected title ids, physical bytes, counted bytes, and failed candidates.
- [ ] **Step 4: Run at least one real Remux and one compression smoke test** from the manifest and validate output with FFprobe, including duration and stream count.
- [ ] **Step 5: Inspect changed files for stale debug logs, generated artifacts, and unused imports.**
- [ ] **Step 6: Commit the complete branch with a clear message** and report test evidence and any disc-specific limitations.
