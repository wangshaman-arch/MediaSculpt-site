# Smart Workflow V1 Implementation Plan

> **Version:** V 0.856 · 版本：V 0.856
## Goal

Implement local analysis, movie confirmation, structured plans, user confirmation, and existing job creation in the current "Smart workflow" entry, while keeping traditional tools independently usable.

## Steps

1. Build versioned plan types, compression/subtitle deterministic strategy, business validation, and existing job-input conversion in `smart-workflow.ts`.
2. Write and run strategy and validation failure tests first, then make them pass with a minimal implementation.
3. Add normal-media probe, plan generation, validation, and save endpoints; DVD/Blu-ray keep reusing `/disc/analyze`.
4. Switch the `/workflow` route to the existing but blank `Workflow.tsx`, implementing the four-stage confirmation UI; all execution still submits to the existing `/jobs`.
5. Reuse existing metadata lookup and preset state; do not copy AI/API config.
6. Keep existing path parsing for opening job-queue output directories and run the existing regression tests.
7. Run API tests, typecheck, frontend typecheck, and production build; after confirming no regression on traditional paths, commit and push `feat/smart-workflow-v1` separately.

## Acceptance

- Plans can be generated offline when AI/movie info is unavailable;
- No jobs are created before user confirmation;
- After confirmation, existing snapshots and executors are used;
- Plans contain no command lines, never overwrite source files, and title/track identity is stable;
- Traditional pages, DVD Remux, HandBrake, and Whisper entries are not duplicated or hidden;
- Directory-open logic for Windows Chinese and space paths passes regression tests.

---

# 智能工作流 V1 实施计划

## 目标

在现有“智能工作流”入口实现本地分析、影片确认、结构化计划、用户确认和现有任务创建，同时保持传统工具独立可用。

## 步骤

1. `smart-workflow.ts` 建立版本化计划类型、压缩/字幕确定性策略、业务校验和现有任务输入转换。
2. 先写并运行策略与校验失败测试，再以最小实现使其通过。
3. 新增普通媒体探测、计划生成、校验、保存接口；DVD/蓝光继续复用 `/disc/analyze`。
4. 将 `/workflow` 路由切换到现有但空白的 `Workflow.tsx`，实现四阶段确认界面；所有执行仍提交现有 `/jobs`。
5. 复用现有 metadata lookup 和 preset 状态，不复制 AI/API 配置。
6. 为任务队列打开输出目录保留现有路径解析，并运行现有回归测试。
7. 运行 API 测试、类型检查、前端类型检查和生产构建；确认传统路径无回归后独立提交并推送 `feat/smart-workflow-v1`。

## 验收

- AI/影片信息不可用时可以离线生成计划；
- 用户确认前不创建任务；
- 确认后使用现有快照与执行器；
- 计划不含命令行，不覆盖源文件，标题和轨道身份稳定；
- 传统页面、DVD Remux、HandBrake、Whisper 入口未被复制或隐藏；
- Windows 中文、空格路径的打开目录逻辑通过回归测试。

