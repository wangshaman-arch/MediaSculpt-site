# MediaSculpt V0.835 Release Notes

> **Version:** V 0.856 · 版本：V 0.856
## English

V0.835 completes the architecture cleanup and Windows baseline packaging work.

- DVD analysis now creates an immutable title model with numerically ordered VOB inputs and explicit missing-segment validation before processing.
- Media stages, process execution, preview probing, subtitle parsing, and job queue decisions have explicit application or infrastructure boundaries.
- DVD Remux jobs report the `remuxing` state instead of appearing as compression jobs.
- Root quality commands now cover type checking, tests, formatting, and generated API drift checks.
- The formal Windows package is the Tauri NSIS installer: `MediaSculpt_0.835.0_x64-setup-base.exe`.

## 中文

V0.835 完成架构整理和 Windows 基础安装包更新。

- DVD 分析先生成不可变标题模型，按数字顺序固定 VOB 输入，并在处理前明确检查缺失分段。
- 媒体阶段、进程执行、预览探测、字幕解析和任务队列决策分别落在清晰的应用层或基础设施层边界内。
- DVD Remux 任务现在显示 `remuxing` 状态，不再误显示为压缩任务。
- 根目录质量命令覆盖类型检查、全部测试、格式检查和 API 生成代码漂移检查。
- Windows 正式基础包使用 Tauri NSIS 安装器：`MediaSculpt_0.835.0_x64-setup-base.exe`。

## Verification

```powershell
pnpm run typecheck
pnpm test
pnpm run lint
pnpm run check:generated
powershell -ExecutionPolicy Bypass -File .\scripts\build-tauri-base.ps1
```

