# Windows Testing Steps

> **Version:** V 0.856 · 版本：V 0.856
## Which build to test

- The formal Windows package is the Tauri NSIS installer (`MediaSculpt_<version>_x64-setup-base.exe`). It bundles the frontend, the Node API sidecar, FFmpeg, FFprobe, and HandBrakeCLI, and opens MediaSculpt as a native desktop window.
- Source run mode (`安装 MediaSculpt.bat` then `Start MediaSculpt.bat`) is for developers: it starts the API sidecar and one native Tauri window from the extracted source. It does not open the default browser or a second desktop shell.

## Whether to delete the old version

When testing a new version for the first time, do not delete the old installation immediately. Install the new version into a new directory, for example `C:\MediaSculpt-test`.

Database, tools, and caches live under `%LOCALAPPDATA%\MediaSculpt` and are shared between versions. If you want to keep a clean copy, back up `%LOCALAPPDATA%\MediaSculpt\Data` first.

## Installation and launch

1. Download and run the Tauri installer.
2. Choose a new test installation directory, for example `C:\MediaSculpt-test`.
3. Finish the installer and launch MediaSculpt from the desktop or Start menu shortcut.
4. Wait for the local API sidecar to become ready; the window opens on its own.
5. Confirm the input and output directories in Settings before processing a disc.

## Test order

1. Import a normal video and confirm preview and track analysis.
2. Select video, audio, subtitle, and chapter tracks, then run Remux.
3. Confirm the output file plays and that duration and timeline are correct.
4. Test HandBrake compression.
5. Test Whisper language, job, and model options.
6. When a DVD or Blu-ray sample is available, test title, playlist, m2ts segment, and chapter selection.
7. Let a job finish while the window is in the background: the taskbar icon should flash and a system notification should appear.
8. Try to close the window while a job is running: the window must stay open and show the "cannot exit yet" notice.

## Issue logs

If you hit a problem, run the MediaSculpt diagnostics entry (root `收集诊断信息.bat` in source run mode). It merges startup, API, frontend, local-tool installation, and Remux/video job logs into `mediasculpt-diagnostics.log`. You only need to upload this file.

In source run mode, stop services with `Stop MediaSculpt.bat`; do not force-kill individual Node processes in Task Manager.

---

# Windows 测试步骤

## 测试哪个版本

- Windows 正式包是 Tauri NSIS 安装器（`MediaSculpt_<版本>_x64-setup-base.exe`）。它内置前端、Node API 侧车、FFmpeg、FFprobe 和 HandBrakeCLI，以原生桌面窗口打开影刻。
- 源码运行模式（先运行 `安装 MediaSculpt.bat`，再运行 `Start MediaSculpt.bat`）供开发者使用：从解压的源码启动 API 侧车和一个原生 Tauri 窗口，不打开默认浏览器，也不启动第二个桌面壳。

## 是否删除旧版本

第一次测试新版本时，不要立即删除旧安装。把新版本安装到新目录，例如 `C:\MediaSculpt-test`。

数据库、工具和缓存位于 `%LOCALAPPDATA%\MediaSculpt`，各版本共用。若需要保留一份干净数据，请先备份 `%LOCALAPPDATA%\MediaSculpt\Data`。

## 安装和启动

1. 下载并运行 Tauri 安装器。
2. 选择新的测试安装目录，例如 `C:\MediaSculpt-test`。
3. 完成安装后，从桌面或开始菜单的 MediaSculpt 快捷方式启动。
4. 等待本地 API 侧车就绪，窗口会自动打开。
5. 处理光盘前先在设置页确认输入目录和输出目录。

## 测试顺序

1. 导入普通视频，确认预览和轨道分析。
2. 选择视频、音频、字幕和章节，执行 Remux。
3. 确认输出文件可以播放，时长和时间轴正常。
4. 测试 HandBrake 压缩。
5. 测试 Whisper 语言、任务和模型选项。
6. 有 DVD 或蓝光样本时，再测试标题、playlist、m2ts 片段和章节选择。
7. 让任务在窗口处于后台时完成：任务栏图标应闪烁，并弹出系统通知。
8. 在任务运行中尝试关闭窗口：窗口必须保持打开并提示暂时无法退出。

## 问题日志

遇到问题时，运行 MediaSculpt 诊断入口（源码运行模式下为根目录 `收集诊断信息.bat`）。它会把启动、API、前端、本地工具安装、Remux/视频任务日志合并进 `mediasculpt-diagnostics.log`。你只需要上传这个文件。

源码运行模式下请用 `Stop MediaSculpt.bat` 停止服务，不要在任务管理器中强制结束单个 Node 进程。

