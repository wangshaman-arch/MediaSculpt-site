# DVD/Blu-ray Remux and Desktop Window Direction

> **Version:** V 0.856 · 版本：V 0.856
> Deprecated: MakeMKV was removed because of closed-source and portable-version licensing risks. DVD Remux uses FFmpeg `dvdvideo`; Blu-ray Remux uses FFmpeg playlist (mpls) parsing plus segment lossless muxing. The content below is kept only as historical archive.

## Conclusion

Current DVD Remux should not rely on FFmpeg reading the IFO directly, and should not simply concatenate VOB files and pretend it is a reliable lossless mux.

Real DVD title, PGC, cell, angle, chapter, subtitle, and timeline information mainly comes from the IFO navigation structure. Simply reading a single IFO or concatenating VOBs easily produces undersized files, wrong durations, wrong chapters, or lost tracks.

The reliable main route for DVD/Blu-ray Remux changed to:

- Lossless Remux: MakeMKV / `makemkvcon`.
- Compression/transcoding: HandBrakeCLI.
- Output validation: FFprobe.
- Later track cleanup: MKVToolNix / `mkvmerge`.

## MakeMKV cross-platform strategy

MakeMKV is a local tool dependency; video is never uploaded to the cloud.

Per-platform invocation:

- Windows: `makemkvcon.exe`.
- macOS: `makemkvcon` inside MakeMKV.app or on PATH.
- Linux: system-installed `makemkvcon`.

The software should:

1. Detect whether MakeMKV is available.
2. Show MakeMKV status and path in the settings page.
3. Support importing a portable MakeMKV directory into MediaSculpt's managed tool directory; Remux prefers `makemkvcon` from the managed directory.
4. When MakeMKV is missing, the Remux feature explicitly shows unavailable instead of exporting wrong files.
5. Users can later install or set the path in the tool manager.

## Remux implementation principles

The first-stage goal is to "reliably export the complete main-title MKV" and stop producing wrong undersized files.

Execution flow:

1. Scan the DVD/Blu-ray directory or ISO.
2. Prefer `makemkvcon --robot info` to analyze titles.
3. Show title number, size, duration, and track summary in the UI.
4. The user selects a title.
5. Run `makemkvcon --robot mkv` to export the selected title to MKV.
6. Validate the output with FFprobe:
   - The file exists and its size is non-zero.
   - Output size must not be significantly smaller than the selected title.
   - Output duration must not be significantly shorter than the selected title.
   - At least one video track is present.
7. On validation failure, the job fails and writes a log; it must not show as completed.

## Track selection strategy

MakeMKV's advantage is reliably reading DVD/Blu-ray titles. The first stage exports complete titles, keeping all audio tracks, subtitles, and chapters by default to guarantee losslessness and completeness.

HandBrake can analyze DVD/Blu-ray titles and chapters accurately, but its output goal is re-encoding compression, not video-stream passthrough Remux. Therefore the main Remux path uses MakeMKV; the main HandBrake path is direct compression of DVD/Blu-ray/ISO. FFmpeg is only used for normal-file Remux or special fallbacks and is no longer a reliable main path for DVD disc Remux.

Precise track/subtitle/chapter selection belongs to stage two:

1. First export the complete MKV with MakeMKV.
2. Then do lossless secondary cleanup with MKVToolNix / `mkvmerge`.
3. Keep the user-selected audio tracks, subtitles, and chapters.
4. Validate again with FFprobe.

This is safer than filtering tracks at the DVD VOB layer and closer to how mature software works.

## Desktop window direction

Users should never see a black launch window or be forced to open a browser.

Target form:

1. Double-click a normal software icon.
2. The software window opens.
3. The local API starts automatically in the background.
4. Closing the software window closes the API and child processes automatically.
5. Errors and runtime info are written to log files.
6. The UI provides an "export diagnostics log" button.

Implementation:

- Windows is the first priority.
- Wrap the existing React UI with Tauri.
- Reuse the existing web frontend code.
- Build the desktop shell after the Remux core is stable, avoiding packaging unstable features into an installer.

## Current stage boundary

The current stage only does stage one:

- Document this decision.
- Add MakeMKV tool detection.
- Add MakeMKV title scanning.
- Switch the DVD/Blu-ray Remux execution core to MakeMKV.
- Keep FFmpeg Remux only for normal video files, not the DVD IFO main flow.

Not done in this stage:

- Portable MakeMKV import into the managed tool directory.
- MKVToolNix secondary track cleanup.
- A complete windowless desktop shell.
- A complete native installer rebuild.

---

> 已废弃：MakeMKV 因闭源与绿色版版权风险被移除。DVD Remux 走 FFmpeg dvdvideo，蓝光 Remux 走 FFmpeg 播放列表（mpls）解析 + 按段无损封装。以下内容仅作历史存档。

# DVD/蓝光 Remux 与桌面窗口方向

## 结论

当前 DVD Remux 不应继续依赖 FFmpeg 直接读取 IFO，也不应把 VOB 文件简单 concat 后假装是可靠无损封装。

真实 DVD 的 title、PGC、cell、角度、章节、字幕和时间轴信息主要来自 IFO 导航结构。简单读取单个 IFO 或拼接 VOB 很容易得到偏小文件、错时长、错章节或丢轨道。

后续 DVD/蓝光 Remux 的可靠主路线改为：

- Remux 无损封装：MakeMKV / `makemkvcon`
- 压缩转码：HandBrakeCLI
- 输出校验：FFprobe
- 后续轨道二次整理：MKVToolNix / `mkvmerge`

## MakeMKV 跨平台策略

MakeMKV 是本地工具依赖，不把视频上传云端。

各平台调用方式：

- Windows：`makemkvcon.exe`
- macOS：MakeMKV.app 内部或 PATH 中的 `makemkvcon`
- Linux：系统安装的 `makemkvcon`

软件应做到：

1. 检测 MakeMKV 是否可用。
2. 在设置页显示 MakeMKV 状态和路径。
3. 设置页支持导入绿色版 MakeMKV 目录到 MediaSculpt 本地托管工具目录；Remux 优先使用托管目录中的 `makemkvcon`。
4. 缺少 MakeMKV 时，Remux 功能明确显示不可用，不再错误导出。
5. 用户后续可在工具管理器里安装或设置路径。

## Remux 实现原则

第一阶段目标是解决“能可靠导出完整主标题 MKV”，不再产出错误的小文件。

执行流程：

1. 扫描 DVD/蓝光目录或 ISO。
2. 优先调用 `makemkvcon --robot info` 分析 title。
3. 在界面显示 title 编号、大小、时长、轨道摘要。
4. 用户选择 title。
5. 执行 `makemkvcon --robot mkv` 导出选中 title 到 MKV。
6. 使用 FFprobe 校验输出：
   - 文件存在且大小非零。
   - 输出大小不能明显小于所选 title。
   - 输出时长不能明显短于所选 title。
   - 至少包含一个视频轨。
7. 校验失败时任务失败并写入日志，不能显示完成。

## 轨道选择策略

MakeMKV 的优势是可靠读取 DVD/蓝光 title。第一阶段导出完整 title，默认保留全部音轨、字幕和章节，保证无损和完整。

HandBrake 虽然能准确分析 DVD/蓝光 title 和章节，但它的输出目标是重新编码压缩，不作为视频流 passthrough 的 Remux 工具。因此 Remux 主路径使用 MakeMKV；HandBrake 主路径用于 DVD/蓝光/ISO 直接压缩。FFmpeg 只作为普通文件 Remux 或特殊备用，不再作为 DVD 原盘 Remux 的可靠主路径。

精确选择音轨、字幕、章节属于第二阶段：

1. 先用 MakeMKV 导出完整 MKV。
2. 再用 MKVToolNix / `mkvmerge` 对 MKV 做无损二次整理。
3. 按用户选择保留指定音轨、字幕、章节。
4. 再做 FFprobe 校验。

这样比直接在 DVD VOB 层筛轨更安全，也更接近成熟软件的处理方式。

## 桌面窗口方向

用户最终不应看到黑色启动窗口，也不应必须打开浏览器。

目标形态：

1. 双击普通软件图标。
2. 软件窗口打开。
3. 后台自动启动本地 API。
4. 关闭软件窗口时自动关闭 API 和子进程。
5. 错误和运行信息写入日志文件。
6. 界面中提供“导出诊断日志”按钮。

实现方式：

- Windows 第一优先。
- 使用 Tauri 包装现有 React 界面。
- 现有网页前端代码继续复用。
- 桌面壳在 Remux 核心稳定后再做，避免只是把不稳定功能包装成安装包。

## 当前阶段边界

当前先做第一阶段：

- 文档记录本决策。
- 增加 MakeMKV 工具检测。
- 增加 MakeMKV title 扫描。
- 将 DVD/蓝光 Remux 执行核心切换到 MakeMKV。
- 保留 FFmpeg Remux 仅用于普通视频文件，不再用于 DVD IFO 主流程。

不在当前阶段一次性完成：

- MakeMKV 绿色版导入到本地托管工具目录。
- MKVToolNix 二次轨道整理。
- 完整无黑窗口桌面壳。
- 完整原生安装包重做。

