# Long-Job Stability, Output Naming, and Unified Preview Plan

> **Version:** V 0.856 · 版本：V 0.856
## User feedback

The current version can export DVD Remux, but these problems remain:

1. When Remux or compression runs long, the API exits and the UI freezes.
2. Auto-exported Remux file names need source and processing suffixes, such as `DVD.Remux`.
3. Compression output names also need to express source, compression format, bitrate or quality parameters, and the main audio format.
4. "Video and subtitle preview window" and "disc - DVD disc" should not be two separate entries; Remux, compression, subtitle extraction, and subtitle recognition should all use the same source preview/selection window.
5. DVD or Blu-ray needs chapter preview so users can see chapter numbers and time ranges, providing a basis for later chapter selection.
6. The software only displays the software version number, not the GitHub commit or branch; but every delivery note must include the GitHub branch, GitHub commit, and software version.
7. `vx-agent-diagnostics.log` is the root aggregated log users upload; running API, frontend, tools, and jobs must not race to write this file. Internal runtime logs go to the system temp directory first, then the log page and diagnostics script aggregate them, avoiding Windows file-lock startup failures.
7. Remux extraction needs multi-title selection because DVD/Blu-ray may contain multiple main features, extras, episodes, or multi-angle content.
8. Whisper speech recognition currently does not work and must become diagnosable: failure reasons go to logs, and the UI shows whether it is stuck at environment, model, audio extraction, or execution.
9. The unified preview window must show subtitle previews, including embedded text subtitles, external subtitles, recognized subtitles, and translated subtitles.
10. Processing-mode logic needs rework: "high-quality compression" and "video compression with subtitles skipped" once conflicted; remove misleading modes, and offer a "process subtitles or not" option inside compression.
11. Compression jobs must be able to choose HandBrake presets instead of only fixed parameters.
12. DVD/Blu-ray compression must fully handle disc info: title, chapters, audio, subtitles, subtitle keep/extract, output naming, and logs must all be visible, selectable, and verifiable.
13. A small window still follows startup; remove it completely. The final form is a normal desktop window; closing it stops API, frontend, and child processes.
14. Installation relies too much on external addresses; add domestic mirrors, fallback sources, resume/caching, reused downloads, and offline tool-package import so installation does not fail without a VPN.
15. Compression presets in "video processing" must no longer be independent hard-coded "quick preview" items; they should share the same custom presets as the settings page, syncing across pages after edits.
16. The workbench needs LAN path support such as `\\NAS\Movies` and `\\192.168.1.10\video` for processing files on NAS or servers directly.
17. Processing logs in the job detail page should merge into the "file details" area instead of being displayed separately.
18. Video preview and subtitle preview must share the top video window; after subtitle extraction, recognition, or translation, the same video window can switch display directly.
19. Remux is lossless muxing, not compression; Remux job details must not show "compressed size" or "savings ratio"; only real compression jobs show those.
20. Remux default output should be the directory containing the DVD/Blu-ray folder, not inside the DVD root or `VIDEO_TS`/`BDMV`; e.g., choosing `Movies/Film/VIDEO_TS` outputs to `Movies`, alongside the `Film` folder.
21. When DVD/Blu-ray sources contain multiple titles or video contents, Remux must allow multi-selection and create multiple Remux jobs.

## Priority 1: long-job API stability

Root-cause direction:

- The current API has dev-period browser heartbeat auto-exit logic.
- The frontend sends `/api/ping` every 15 seconds.
- In dev mode, if no heartbeat arrives within 60 seconds, the API assumes the browser closed and exits itself.
- For long Remux, compression, and Whisper runs, the browser may sleep, network requests may pause, or the page may switch, causing the API to misjudge and exit.

Fix principles:

1. Windows local startup disables browser-heartbeat auto-exit by default.
2. Even if auto-exit is enabled, the API must not exit while jobs are running.
3. Auto-exit behavior must be written to API logs for diagnosis.
4. Job child-process exits, API exceptions, and uncaught errors continue to be logged.

## Priority 2: output naming rules

Remux naming:

- DVD disc: `Title.DVD.Remux.mkv`
- Blu-ray disc: `Title.BluRay.Remux.mkv`
- ISO: prefer `DVD` or `BluRay` from recognition; use `ISO.Remux` when unrecognized
- Normal video re-mux: `Title.Video.Remux.mkv`

Compression naming:

- Format: `Title.Source.CompressionFormat.Quality.MainAudio.mkv`
- Example: `Movie.DVD.H264-10bit.RF18.AC3.mkv`
- Example: `Movie.BluRay.H264-10bit.RF22.DTS.mkv`

Naming fields come from:

1. Source type: `DVD`, `BluRay`, `ISO`, `Video`
2. Compression format: HandBrake encoder, e.g., `H264-10bit`, `H265-10bit`
3. Quality parameter: current CRF/RF value, e.g., `RF18`
4. Main audio format: the first audio track codec of the source, e.g., `AC3`, `DTS`, `AAC`

## Priority 3: unified preview window

Goals:

- "Video and subtitle preview" and "disc - DVD disc" must not look like two features.
- After choosing video, DVD, Blu-ray, or ISO, enter the same "source preview and processing settings" window.
- The same window completes:
  - Video preview
  - Subtitle preview
  - Source info
  - title/playlist selection
  - Video track, audio track, subtitle track selection
  - Chapter preview and chapter selection
  - Processing method selection: Remux, compression, subtitle extraction, Whisper, translation
  - Parameter preview
  - Job creation

The unified preview window cannot be split into two entries:

- One entry cannot be "disc - DVD disc" and another "video and subtitle preview".
- Normal video, DVD, Blu-ray, and ISO should all enter the same "source preview and processing settings" window.
- When DVD/Blu-ray cannot be played directly in the browser, the window must explain why and still show titles, chapters, audio tracks, subtitles, and processing parameters.

## Priority 4: chapter preview

Chapter preview shows at least:

- Chapter number
- Start time
- End time
- Duration
- Title (if present)

DVD/Blu-ray chapter sources:

- MakeMKV title scan results first.
- If MakeMKV cannot provide chapter details, use FFprobe on the exported or probeable source.
- Chapter thumbnail images are a later enhancement, not a blocker for the first stability batch.

## Current execution order

1. Fix version display: the software shows only the software version; delivery replies give GitHub branch, GitHub commit, and software version.
2. Rework processing modes: remove misleading modes, keep "high-quality compression", and treat subtitle processing as an optional step inside compression jobs.
3. Add HandBrake preset selection, and let DVD/Blu-ray compression use the selected title, audio, subtitles, and chapters.
4. Implement multi-title Remux selection and multi-job creation.
5. Fix the Whisper diagnostic chain: environment, model, audio extraction, and execution failures all go to logs and show in the UI.
6. Merge the unified preview window: video preview, subtitle preview, and disc title/chapter/track selection into one entry.
7. Remove the startup mini-window: transition from hidden script startup to the desktop shell; closing the window stops all services.
8. Rework installation sources: add domestic mirrors, fallback sources, download caching, and offline import to reduce external network dependency.
9. Add tests at each stage and push to GitHub after verification.

## This round's UI and Remux refinement rules

This round first lands non-conflicting base experiences:

1. Shared compression presets: scan/video-processing pages read built-in preset edits and custom presets saved in settings; settings broadcasts changes on save/delete and the video-processing page refreshes.
2. LAN browsing: scan page and file-browser dialog provide UNC path input and common examples; the backend keeps accessing local paths without copying or uploading video files.
3. Multi-title Remux: disc analysis results support checking multiple titles; each title keeps its own stream/chapter selection; job creation generates one job per checked title.
4. Remux output directory: defaults to the bottom-most directory of the input DVD/Blu-ray source; normal video still outputs to the source file directory.
5. Unified preview: the top video window in the job detail page serves both video and subtitle preview; original/translated subtitles switch via the same player tracks.
6. Details and logs merged: job logs go into the file-details area so users do not bounce between job detail and log areas.
7. Remux info display: Remux details show only original size, output path, duration, and logs; no misleading compression fields such as compressed size or savings ratio.

## This round's queue, preview, and processing-mode fixes

1. The job detail page keeps only one video/subtitle preview window; the disc stream-settings component no longer has a second player.
2. Remux jobs do not show "after compression" or "savings ratio", but show "muxed" file size to confirm the actual output MKV size.
3. The job queue list does not show stream-selection areas; stream, chapter, and title selection stay in the job detail or source-analysis window.
4. Processing modes show as parallel first-level entries:
   - High-quality compression
   - Remux lossless muxing
   - Speech and subtitle file processing
5. "Speech and subtitle file processing" is no longer a child of "high-quality compression"; after entering the mode, choose subtitle extraction, Whisper recognition, or recognition+translation.
6. Output folder, subtitle folder, and translated-subtitle folder in the job queue and file details all provide click-to-open entries.

## This round's preview, Remux, and directory-open fixes

1. The job detail layout order is fixed: video and subtitle preview at top, disc/Remux stream settings below it, file details and logs on the right.
2. Remux jobs do not show the subtitle pipeline, keeping Remux separate from speech recognition/subtitle processing.
3. The Remux source-analysis window must show audio and subtitle track language, title/comment, codec, channels, and default/forced flags so users can choose independently.
4. Multi-title Remux output names carry `Title01`, `Title02`, etc., avoiding overwrites.
5. Output directories still save under the bottom-most directory of the original DVD/Blu-ray source; opening a directory sends the raw output directory path to the local API, not the display path.
6. LAN path input adds a "choose network location" button for mouse selection and direct UNC input.
7. The video preview window supports listing embedded subtitle tracks and switching via the same player; the backend converts convertible embedded tracks to WebVTT on demand for the browser.
8. The high-quality compression entry must directly show compression preset and current parameters below it; users must not go to settings to learn the compression config.

## Professional base module hardening: video compression

The video-compression module's priority goal is "real compression, explainable, verifiable"; DVD/Blu-ray compression must never be mistaken for completed Remux again.

1. When DVD, Blu-ray, or ISO chooses "high-quality compression", the job type must stay compression.
2. Disc compression by default must have HandBrake analyze the DVD, Blu-ray, or ISO source directly and re-encode after title, chapter, audio, and subtitle selection.
3. MakeMKV is only the core Remux lossless-muxing tool; MakeMKV → HandBrake must not be the default compression chain.
4. After HandBrake exits successfully, the output file must be validated: at least exists and is non-empty, and preferably duration is compared with the source.
5. On compression-output validation failure, the job must fail and write a log; abnormal output must not be marked successful.
6. If MakeMKV → HandBrake is added later, it should only be an explicit user-chosen fallback chain, marked "Remux first, then compress" in UI, job logs, and file names.
7. On compression failure, logs must locate whether it stuck at HandBrake analysis, HandBrake execution, or output validation.

Key boundaries:

- HandBrake reads DVD/Blu-ray structure accurately, but it is a transcoder, not a Remux lossless-muxing tool.
- MakeMKV is for DVD/Blu-ray/ISO disc Remux, exporting MKV losslessly.
- FFmpeg can Remux normal files; DVD disc Remux no longer uses FFmpeg IFO/VOB concatenation as the main path because it repeatedly introduces title, cell, angle, subtitle, and timeline errors.
- Disc analysis windows can be shared, but job creation must respect the current processing mode: Remux creates Remux jobs, high-quality compression creates HandBrake compression jobs.

## MakeMKV portable integration requirements

1. The settings page lets users choose and import a portable MakeMKV directory; the directory may contain `makemkvcon.exe` directly or be its parent.
2. After import, copy it into MediaSculpt's managed tool directory; users are not required to install MakeMKV into system directories.
3. Remux scanning and export prefer `makemkvcon` in the managed directory, then system-installed versions and PATH.

## This round's workflow UI consolidation rules

1. Left navigation merges into "Media workbench" as the single main entry for source parsing, Remux, compression, Whisper, subtitle translation, movie info, and output validation.
2. The job detail page no longer handles source stream editing, subtitle pipeline execution, or movie-info editing; those belong to the upper source-analysis/workbench configuration, avoiding long queue-detail pages.
3. The job detail page keeps only:
   - Unified video and subtitle preview window;
   - Source selection summary;
   - Output file/subtitle file;
   - Processing logs;
   - Status timeline.
4. Default-window decisions come first: long file lists, logs, and necessary details use local scrolling; the whole page no longer stacks downward indefinitely.
5. Global scrollbar colors follow the theme, avoiding system-default scrollbars inconsistent with dark/light themes.
6. Opening output folders is uniformly handled by the backend `/api/runtime/open-path`; the frontend sends the raw output file path, and the backend decides file or directory and opens its location.
7. Processing boundaries stay fixed:
   - Remux: MakeMKV handles DVD/Blu-ray/ISO lossless muxing;
   - Compression: HandBrake analyzes DVD/Blu-ray/ISO directly and re-encodes;
   - FFmpeg is no longer the DVD disc Remux main path.
8. Explanatory text defaults to tooltips or question hints; the main UI prioritizes icons, actions, status, and key parameters.
4. Import, recognition, and failure reasons must be written to the unified diagnostics log.

## This round's preview decision-center refactor

Goal: the video and subtitle preview window is not just a player, but a decision center where users decide "video compression / Remux / speech and subtitle processing" parameters.

1. "High-quality compression" is renamed "Video compression". "High quality" becomes a preset name or quality tier, no longer a first-level feature name.
2. The upper main navigation's selected state must be clearer than lower steps; lower steps use local highlighting to avoid whole blocks turning blue at multiple levels.
3. The job detail top bar merges file title, status, smart assistant, start/cancel/retry, and delete; no extra detached action bar above the video preview.
4. The smart assistant entry sits on the right of the top action bar, left of start/delete buttons; opening it shows a structured input area instead of only a chat box.
5. The structured smart-assistant input at least includes: processing goal, source issue, expected output size/quality, subtitle language, audio-keep strategy, and extra notes.
6. Near the video and subtitle preview window, show a source-info summary to help choose parameters:
   - Source type;
   - Duration;
   - Resolution;
   - Video codec / frame rate;
   - Audio track count, language, codec, channels;
   - Subtitle count, language, type;
   - Chapter count.
7. Video compression parameter presets move below the preview window; logical order: choose file → preview video and subtitles → view source info → choose compression parameters → start processing.
8. The subtitle mode for speech and subtitle file processing also moves below the preview window; logical order: preview subtitles/audio → choose extract, Whisper, recognize+translate, or skip.
9. The Remux page does not show compression parameters; the Remux parameter area shows title, audio, subtitle, and chapter selection summaries.
10. Parameter display in the job queue must serve execution decisions; users must not return to settings to confirm current compression/subtitle parameters.
11. Within default window size, core information must stay complete and readable; long lists may scroll locally, but cards must not be clipped, buttons half-hidden, or layout misaligned.

## This round's job-detail compaction execution rules

1. The "video and subtitle preview" title merges into the job detail top action bar, on the same level as file title, status, smart assistant, start, cancel, retry, and delete.
2. The video player card no longer shows a duplicate title and description, reducing vertical usage in the default window.
3. Subtitle-switch buttons (subtitles off, original, translated, embedded tracks) merge into the video source-info bar, ideally in the same info band as resolution, codec, frame rate, duration, audio count, subtitle count, and chapter count.
4. Detailed audio/subtitle lists collapse by default and open via "expand details / collapse details", so the default window does not need scrolling to see core actions.
5. Compression preset and speech/subtitle processing mode sit below the preview window; users decide parameters after seeing picture, subtitles, and source info.
6. The workbench no longer shows a standalone smart-assistant card or a standalone compression-preset editing area; these decision entries sink into specific job detail pages to avoid duplicating the same capability across pages.
7. Job details keep the merged processing-log/file-details area, but stream selection, subtitle pipeline, and movie-info input still belong to the upper source analysis/workflow, not the queue detail.

## This round's HandBrake professional compression loop

1. Overview and job queue merge into one home/job-queue entry: statistics at top, full queue, filter, select-all, and sequential start below.
2. Top main entries keep only "Job queue" and "Media workbench"; a gear on the right enters the settings center, which drills into tools, directories, compression, Whisper, AI, movie info, system behavior, etc.
3. DVD/Blu-ray compression must use HandBrake scan structure as the professional analysis source, not only ffprobe or the browser player.
4. HandBrake scan results must expose title, video format, resolution, frame rate, audio language, audio format, channels, sample rate, subtitle language, subtitle format, and chapters to the frontend.
5. Frontend stream selection must show HandBrake track numbers so users see language/format and the execution layer maps accurately.
6. When creating compression jobs, the selection plan must save HandBrake title number, audio track numbers, subtitle track numbers, and chapter numbers.
6.1. MakeMKV title indexes are only for Remux export; HandBrake compression must use the `handbrakeTitleNumber` matched by HandBrake scanning, never MakeMKV title order or UI list order directly as HandBrake `--title`.
7. HandBrake compression execution must generate `--title`, `--audio`, `--aencoder`, `--subtitle`, `--chapters`, and `--markers` per user selection; if users select a subset, execution must not default back to `--all-audio` / `--all-subtitles`.
8. Normal videos or old jobs without a selection plan may keep the all-audio/all-subtitle default behavior to avoid breaking old data.
9. The root unified diagnostics log must append job logs, including HandBrake arguments, failed stderr, and job errors, not only install/startup.
10. Next, add HandBrake chapter/title screenshot preview: when DVD/Blu-ray cannot play directly in the browser, show chapter screenshots in the same preview window for title/chapter confirmation.

## This round's title-level compression statistics and three-column workbench rules

1. "Cumulative saved space" counts only real compression jobs, not Remux; when a DVD/Blu-ray compresses only one title, the original size must be the selected title's size, not the whole disc directory.
2. When creating DVD/Blu-ray compression jobs, the selection plan must save the HandBrake title number, the selected title's original size and duration for compression validation, duration validation, and saved-space statistics.
3. After switching title/video streams, audio, subtitle, and chapter lists must follow the current title; tracks/chapters not in the current title must not remain selectable.
4. Compression presets in job details must use the same preset data and localStorage item as settings; no second hard-coded compression options in job details.
5. Job details by default show only main file info, output result, and size; source path, subtitle paths, and long processing logs expand via "file details" and "processing logs" buttons.
6. The status timeline sits at the top-right of the detail page: status, time, and progress first, then file details and logs.
7. The "professional compression chain" does not occupy a full card; it expands via a button into a compact note, so the default window is not crowded by explanatory text.
8. The home page uses three columns: left "Media workbench", middle "Job queue + statistics overview", right "Settings entry". Work entry, execution queue, and settings entry are visible at once; overview and queue are no longer split.

## This round's top three entries and job-queue space fixes

1. The pinned top workspace must show three same-level buttons: Job queue, Media workbench, Settings. Settings cannot exist only as a small gear or dropdown.
2. The job queue body must not repeat the "Media workbench" entry or a set of body settings entries; these belong to the top navigation.
3. The job queue page focuses on the job list and execution status. Cumulative saved space, running, waiting, and completed are one compact status row, not four big cards crowding the default window.
4. The DVD/Blu-ray title list must directly show each title's audio language/format summary and subtitle language/format summary, not just "N audio tracks / N subtitle tracks".
5. After switching titles, stream/chapter check states must be scoped to the current title. When switching to a title for the first time, check/uncheck must not start from an empty set but from that title's default selection set.
6. For future UI-space changes, the priority is: in the default window, leave space for job queue, source parsing, title/audio/subtitle/chapter, output, and logs — information with operational value.

## This round's settings overview, scrollbar, and title inline selection fixes

1. Clicking top "Settings" shows all settings categories' titles, icons, and descriptions by default; clicking a category expands its content. It must not default to showing only "Tools".
2. The main content area uses a visible themed scrollbar; the right scrollbar must move in sync with the mouse wheel; no hidden-scrollbar style for the main scroll area.
3. Secondary switches in the workbench such as "browse selection / batch import" dim as second-level menus and must not be more prominent than the main processing mode.
4. In the DVD/Blu-ray title list, resolution display no longer appends easily-misunderstood meaningless numbers such as frame rate.
5. Each title can expand audio, subtitle, and chapter selection inline. Users decide at the title level what to mux or compress, instead of relying on another separate stream area below the title.
6. When audio tracks, subtitles, or chapters are many, the title inline expansion uses local scrolling to avoid blowing up the default window.

## This round's settings return, smart workflow, and unified log fixes

1. Top first-level entries become: Smart workflow, Media workbench, Job queue, Settings. Smart workflow is the future AI auto-processing entry; it first reuses the current workbench's file selection and job-creation capability, later gradually integrating "AI recommends a processing plan after source selection".
2. Every settings sub-item must provide "return to settings overview"; users must not get stuck in compression parameters, AI translation, local tools, etc., without a way back.
3. Outer `html/body/root` scrolling is forbidden; only the app main content area scrolls, avoiding double scrollbars in settings, compression parameters, AI translation, etc.
4. Audio, subtitle, and chapter checkboxes in the DVD/Blu-ray title inline expansion must be clickable directly, not disturbed by the title row's click event.
5. Compression presets in the job detail page must be clickable and provide a draft edit area for current job parameters; not just non-interactive parameter text.
6. Disc analysis must not use export-grade long waits. MakeMKV analysis uses a short timeout; on failure/timeout, record the reason and fall back to other analysis capabilities.
7. The root unified diagnostics log must include job-creation failures, tool failures, and disc-analysis failures/timeouts; uploading only `vx-agent-diagnostics.log` should let users judge the main problem.

## 2026.07.15.69 Tool-management fixes

- Windows install logs showed FFmpeg, FFprobe, and HandBrakeCLI downloaded successfully, but runtime status detection cannot rely only on PATH; the tool manager now recursively scans the managed tool directory and recognizes versioned extracted directories and `bin` subdirectories.
- MakeMKV has no stable redistributable CLI direct link; the misleading "online install" path was removed and portable-directory import kept; after import, the original directory is written to `makemkv-source.json`, auto-restored on settings refresh or restart.
- Whisper and LibreTranslate Python environments install by trying Tsinghua, Aliyun, and PyPI sources in order, each with timeouts and retries; failure reasons go to the unified diagnostics log.
- Tool status still shows the real executable path and version; failed installs are no longer shown as "completed", and MakeMKV can only be confirmed through portable import.

## 2026.07.15.70 Startup, browsing, and tool feedback optimizations

- API and frontend start in parallel; the desktop window no longer waits for unnecessary full tool checks.
- Network location "recently used" displays compactly horizontally, collapsed by default; clicking the title expands the full list.
- Settings subpages return to the overview via the top settings title; the duplicate "return to settings overview" button was removed; the tool card title is now "Tool status and installation".
- Installed local tools and Python packages are reused first instead of re-downloaded; after install, paths and versions are validated automatically and success is shown.

---

# 长任务稳定性、输出命名与统一预览计划

## 用户反馈

当前版本已经可以导出 DVD Remux，但仍存在以下问题：

1. Remux 或压缩时间一长，程序会出现 API 退出，界面卡死。
2. Remux 自动导出的文件名需要带有来源和处理方式后缀，例如 `DVD.Remux`。
3. 压缩输出文件名也需要表达来源、压缩格式、比特率或质量参数、主要音频格式。
4. “视频与字幕预览窗口”和“原盘-DVD原盘”不应是两个割裂入口；无论执行 Remux、压缩、字幕提取、字幕识别，都应使用同一个源预览/选择窗口。
5. DVD 或蓝光需要章节预览，让用户可以看到章节编号、时间范围，并为后续章节选择提供基础。
6. 软件内部只显示软件版本号，不显示 GitHub 提交号和分支；但每次交付说明必须包含 GitHub 分支、GitHub 提交号和软件版本号。
7. `vx-agent-diagnostics.log` 是用户上传用的根目录汇总日志；运行中的 API、前端、工具和任务不得同时抢写该文件，内部运行日志先写入系统临时目录，再由日志页面和诊断脚本汇总，避免 Windows 文件占用导致启动失败。
7. Remux 提取需要支持多选 title，因为 DVD/蓝光里可能包含多个正片、花絮、剧集或多角度内容。
8. Whisper 语音识别目前不能工作，必须改为可诊断：失败原因要写入日志，并在界面显示具体卡在环境、模型、音频提取还是执行阶段。
9. 统一预览窗口必须能显示字幕预览，包括内置文本字幕、外置字幕、识别字幕和翻译字幕。
10. 处理模式逻辑需要重新整理：“高质量压缩”和“跳过字幕的视频压缩”曾经存在概念冲突，删除误导性处理模式，压缩模式内部提供是否处理字幕的选项。
11. 压缩任务必须能选择 HandBrake 预设，而不是只能使用固定参数。
12. DVD/蓝光压缩必须完整处理原盘信息：title、章节、音轨、字幕、字幕保留/提取、输出命名和日志都要可见、可选择、可验证。
13. 启动时仍有小窗口跟随启动，必须彻底去除；最终应使用普通桌面窗口，关闭窗口即停止 API、前端和子进程。
14. 安装过程过度依赖外网地址；需要增加国内镜像、备用源、断点/缓存、已下载复用和离线工具包导入，避免不翻墙就安装失败。
15. “视频处理”里的压缩预设不能再是独立的“快速预览”硬编码项，应与设置页共用同一套自定义预设；在任意页面修改预设后，其他页面应同步更新。
16. 影音工作台需要支持局域网路径，例如 `\\NAS\Movies`、`\\192.168.1.10\video`，方便直接处理 NAS 或服务器上的文件。
17. 任务队列详情页里的处理日志应并入“文件详情”区域，不再与文件详情割裂显示。
18. 视频预览和字幕预览必须共用最上方的视频窗口；字幕完成提取、识别或翻译后，应能直接在同一视频窗口中切换显示。
19. Remux 是无损封装，不是压缩；Remux 任务详情不显示“压缩后大小”和“节省比例”，只有真正压缩任务才显示。
20. Remux 默认输出目录应放在 DVD/蓝光文件夹所在目录，而不是 DVD 内部根目录或 `VIDEO_TS` / `BDMV` 内；例如选择 `Movies/Film/VIDEO_TS` 时输出到 `Movies`，与 `Film` 文件夹并列。
21. DVD/蓝光源中存在多个 title 或多条视频内容时，Remux 应允许多选，并按选择创建多个 Remux 任务。

## 第一优先级：长任务 API 稳定性

根因方向：

- 当前 API 有开发期浏览器心跳自动退出逻辑。
- 前端每 15 秒发送一次 `/api/ping`。
- API 在开发模式下如果 60 秒没有收到心跳，会认为浏览器关闭并主动退出。
- 对长时间 Remux、压缩、Whisper 来说，浏览器可能休眠、网络请求被暂停或页面被切换，导致 API 误判退出。

修复原则：

1. Windows 本地启动默认禁用浏览器心跳自动退出。
2. 即使开启自动退出，只要存在运行中的任务，也不能退出 API。
3. 自动退出行为必须写入 API 日志，方便诊断。
4. 任务子进程退出、API 异常、未捕获错误继续写入日志。

## 第二优先级：输出命名规则

Remux 命名：

- DVD 原盘：`片名.DVD.Remux.mkv`
- 蓝光原盘：`片名.BluRay.Remux.mkv`
- ISO：根据识别结果优先使用 `DVD` 或 `BluRay`，无法识别时使用 `ISO.Remux`
- 普通视频转封装：`片名.Video.Remux.mkv`

压缩命名：

- 格式：`片名.片源类型.压缩格式.质量参数.主要音频格式.mkv`
- 示例：`Movie.DVD.H264-10bit.RF18.AC3.mkv`
- 示例：`Movie.BluRay.H264-10bit.RF22.DTS.mkv`

命名字段应来自：

1. 片源类型：`DVD`、`BluRay`、`ISO`、`Video`
2. 压缩格式：HandBrake encoder，例如 `H264-10bit`、`H265-10bit`
3. 质量参数：当前 CRF/RF 值，例如 `RF18`
4. 主要音频格式：源文件第一个音频轨的 codec，例如 `AC3`、`DTS`、`AAC`

## 第三优先级：统一预览窗口

目标：

- 不再让“视频与字幕预览”和“原盘-DVD原盘”像两个功能。
- 用户选择视频、DVD、蓝光、ISO 后进入同一个“源预览与处理设置”窗口。
- 同一窗口中完成：
  - 视频画面预览
  - 字幕预览
  - 源信息
  - title/playlist 选择
  - 视频轨、音轨、字幕轨选择
  - 章节预览和章节选择
  - 处理方式选择：Remux、压缩、字幕提取、Whisper、翻译
  - 参数预览
  - 创建任务

统一预览窗口不能拆成两个入口：

- 不能一个入口叫“原盘-DVD原盘”，另一个入口叫“视频与字幕预览”。
- 普通视频、DVD、蓝光、ISO 都应进入同一个“源预览与处理设置”窗口。
- DVD/蓝光无法直接浏览器播放时，窗口也必须解释原因，并继续显示 title、章节、音轨、字幕和处理参数。

## 第四优先级：章节预览

章节预览至少显示：

- 章节编号
- 开始时间
- 结束时间
- 时长
- 标题（如果存在）

DVD/蓝光章节来源：

- MakeMKV title 扫描结果优先。
- 如果 MakeMKV 不能提供章节明细，使用 FFprobe 对导出的或可探测源进行补充。
- 章节级画面缩略图属于后续增强，不作为第一批稳定性修复的阻塞项。

## 当前执行顺序

1. 修正版本显示：软件内只显示软件版本号；交付回复同时给出 GitHub 分支、GitHub 提交号、软件版本号。
2. 重新整理处理模式：删除误导性处理模式，保留“高质量压缩”，字幕处理作为压缩任务内的可选步骤。
3. 增加 HandBrake 预设选择，并让 DVD/蓝光压缩任务可以使用选定 title、音轨、字幕、章节。
4. 实现 Remux 多 title 选择和多任务创建。
5. 修复 Whisper 诊断链路：环境、模型、音频提取、执行失败都写入日志并在界面展示。
6. 合并统一预览窗口：视频预览、字幕预览、原盘 title/章节/轨道选择合并到同一个入口。
7. 去除启动小窗口：从脚本隐藏启动过渡到桌面壳，关闭窗口即停止所有服务。
8. 改造安装源：增加国内镜像、备用源、下载缓存、离线导入，减少外网依赖。
9. 每个阶段补充测试，验证通过后上传 GitHub。

## 本轮界面与 Remux 细化规则

本轮修改优先落地不互相冲突的基础体验：

1. 压缩预设共享：扫描/视频处理页读取设置页保存的内置预设修改和自定义预设，设置页保存或删除后广播变更，视频处理页同步刷新。
2. 局域网浏览：扫描页和文件浏览弹窗提供 UNC 路径输入和常用示例入口，后端继续按本机路径访问，不复制、不上传视频文件。
3. 多 title Remux：原盘分析结果支持勾选多个 title；每个 title 可保留独立的流轨和章节选择，创建任务时按勾选 title 逐个生成任务。
4. Remux 输出目录：默认输出到输入 DVD/蓝光源的最底层目录；普通视频仍输出到源文件所在目录。
5. 统一预览：任务详情页顶部视频窗口同时承担视频和字幕预览，原字幕/译文字幕通过同一播放器轨道切换。
6. 详情与日志合并：任务日志放入文件详情区域，避免用户在任务详情和日志区之间来回找问题。
7. Remux 信息显示：Remux 详情只显示原始大小、输出路径、时长和日志；不显示压缩后大小、节省比例等会误导用户的压缩字段。

## 本轮队列、预览与处理模式修正

1. 任务详情页只能保留一个视频/字幕预览窗口；原盘流轨设置组件不再自带第二个播放器。
2. Remux 任务不显示“压缩后”和“节省比例”，但显示“封装后”文件大小，用于确认输出 MKV 的实际大小。
3. 任务队列列表不显示流轨选择区域；流轨、章节、title 等选择留在任务详情或源分析窗口中处理。
4. 处理模式一级入口并列显示：
   - 高质量压缩
   - Remux 无损封装
   - 语音与字幕文件处理
5. “语音与字幕文件处理”不再作为“高质量压缩”的下级；进入该模式后再选择字幕提取、Whisper 识别或识别翻译。
6. 任务队列和文件详情中的输出文件夹、字幕文件夹、译文字幕文件夹都应提供点击打开入口，避免用户只能复制路径。

## 本轮预览、Remux 与目录打开继续修正

1. 任务详情页布局顺序固定为：视频与字幕预览在最上方，原盘/Remux 流轨设置在其下方，文件详情和日志在右侧。
2. Remux 任务不显示字幕流水线，避免把 Remux 与语音识别/字幕处理混在一起。
3. Remux 源分析窗口必须显示音轨和字幕轨的语言、标题/备注、编码、声道、默认/强制标记，用户才能自主选择。
4. 多 title Remux 输出文件名带 `Title01`、`Title02` 等顺序后缀，避免多个 title 输出互相覆盖。
5. 输出目录仍按原始 DVD/蓝光源最底层目录保存；打开目录时前端向本地 API 发送原始输出目录路径，不再把显示用路径当成打开路径。
6. 局域网路径输入增加“选择网络位置”按钮，方便鼠标点选并直接输入 UNC 路径。
7. 视频预览窗口支持列出内置字幕轨，并通过同一播放器切换；后端按需把可转换的内置字幕轨转为 WebVTT 供浏览器显示。
8. 高质量压缩入口下方必须直接显示压缩参数预设和当前压缩参数，不能让用户切到设置页才知道压缩配置。

## 基础模块专业可用补强：视频压缩

视频压缩模块的优先目标是“真正压缩、可解释、可校验”，不能再出现 DVD/蓝光压缩被误当作 Remux 完成的情况。

1. DVD、蓝光、ISO 选择“高质量压缩”时，任务类型必须保持为压缩任务。
2. 光碟压缩默认必须由 HandBrake 直接分析 DVD、蓝光或 ISO 源，由 HandBrake 负责 title、章节、音轨和字幕选择后的重新编码。
3. MakeMKV 只作为 Remux 无损封装核心工具；不得把 MakeMKV → HandBrake 作为默认压缩链路。
4. HandBrake 退出成功后必须校验输出文件，至少确认输出文件存在、非空，并尽量比对输出时长与源时长。
5. 压缩输出校验失败时，任务必须失败并写入日志，不允许把异常输出标记为成功。
6. 如果未来增加 MakeMKV → HandBrake，应仅作为用户明确选择的备用链路，并在界面、任务日志和文件名中标明“先 Remux 再压缩”。
7. 压缩失败时，日志应能定位卡在 HandBrake 分析、HandBrake 执行或输出校验阶段。

关键边界：

- HandBrake 能准确读取 DVD/蓝光结构，但它是转码器，不作为 Remux 无损封装工具。
- MakeMKV 用于 DVD/蓝光/ISO 原盘 Remux，无损导出 MKV。
- FFmpeg 可用于普通文件 Remux；DVD 原盘 Remux 不再作为主路径使用 FFmpeg 拼接 IFO/VOB，因为这会反复引入 title、cell、angle、字幕和时间轴错误。
- 光盘分析窗口可以共用，但创建任务时必须尊重当前处理模式：Remux 创建 Remux 任务，高质量压缩创建 HandBrake 压缩任务。

## MakeMKV 绿色版集成要求

1. 设置页允许用户选择绿色版 MakeMKV 目录并导入，目录中可以直接包含 `makemkvcon.exe`，也可以是其上级目录。
2. 导入后复制到 MediaSculpt 本地托管工具目录，不要求用户把 MakeMKV 安装到系统目录。
3. Remux 扫描和导出优先使用托管目录中的 `makemkvcon`，再查找系统安装版和 PATH。

## 本轮工作流界面收纳规则

1. 左侧导航合并为“影音工作台”，作为源解析、Remux、压缩、Whisper、字幕翻译、影片信息和输出校验的唯一主入口。
2. 任务详情页不再承担源流轨编辑、字幕流水线执行和影片信息编辑；这些属于上一级源分析/影音工作台配置，避免队列详情成为长页面。
3. 任务详情页只保留：
   - 视频与字幕统一预览窗口；
   - 源选择摘要；
   - 输出文件/字幕文件；
   - 处理日志；
   - 状态时间线。
4. 默认窗口内优先完成判断：长文件列表、日志和必要细节使用局部滚动，不再让整个页面无限向下堆。
5. 全局滚动条颜色跟随主题，避免出现与深色/浅色主题不一致的系统默认滚动条。
6. 打开输出文件夹统一由后端 `/api/runtime/open-path` 处理，前端传原始输出文件路径，后端判断文件或目录并打开所在位置。
7. 处理边界继续固定：
   - Remux：MakeMKV 负责 DVD/蓝光/ISO 无损封装；
   - 压缩：HandBrake 直接分析 DVD/蓝光/ISO 并重新编码；
   - FFmpeg 不再作为 DVD 原盘 Remux 主路径。
8. 说明性文字默认收进悬浮提示或问号提示里，主界面优先显示图标、动作、状态和关键参数。
4. 导入、识别、失败原因必须写入统一诊断日志。

## 本轮预览决策中心重构

目标：视频与字幕预览窗口不只是播放器，而是用户决定“视频压缩 / Remux / 语音与字幕处理”参数的决策中心。

1. “高质量压缩”统一改名为“视频压缩”。“高质量”作为压缩预设名称或质量档位，不再作为一级功能名称。
2. 上级主导航的选中态必须比下级步骤更明确；下级步骤使用局部高亮，避免多个层级同时整块全蓝。
3. 任务详情顶部栏合并文件标题、状态、智能助手、开始/取消/重试和删除操作；视频预览上方不再额外堆一条割裂操作栏。
4. 智能助手入口放在顶部操作栏右侧，位于开始/删除等任务按钮左侧；点开后显示结构化输入区域，而不是只有普通聊天框。
5. 智能助手结构化输入至少包含：处理目标、片源问题、期望输出体积/质量、字幕语言、音轨保留策略、补充说明。
6. 视频与字幕预览窗口附近显示源信息摘要，帮助用户选择处理参数：
   - 源类型；
   - 时长；
   - 分辨率；
   - 视频编码 / 帧率；
   - 音轨数量、语言、编码、声道；
   - 字幕数量、语言、类型；
   - 章节数量。
7. 视频压缩参数预设移动到预览窗口下方，逻辑顺序是：选择文件 → 预览视频和字幕 → 查看源信息 → 选择压缩参数 → 开始处理。
8. 语音与字幕文件处理的字幕模式也移动到预览窗口下方，逻辑顺序是：预览字幕/音轨 → 选择提取、Whisper、识别翻译或跳过。
9. Remux 页面不显示压缩参数；Remux 参数区显示 title、音轨、字幕和章节选择摘要。
10. 任务队列里的参数显示要服务于执行决策，不能让用户必须返回设置页才能确认当前压缩/字幕参数。
11. 默认窗口尺寸内优先保证核心信息完整可读；长列表可以局部滚动，但卡片不能出现内容被截断、按钮半露或布局随意错位。

## 本轮任务详情紧凑化执行规则

1. “视频与字幕预览”标题并入任务详情顶部操作栏，与文件标题、状态、智能助手、开始、取消、重试和删除按钮处在同一层。
2. 视频播放器卡片不再额外显示重复标题和说明文字，减少默认窗口内的纵向占用。
3. 字幕切换按钮（关闭字幕、原字幕、译文字幕、内置字幕轨）并入视频源信息栏，尽量与分辨率、编码、帧率、时长、音轨数、字幕数、章节数处在同一信息带。
4. 音轨和字幕的详细列表默认收起，通过“展开详情 / 收起详情”按钮查看，避免默认窗口必须滚动才能看到核心操作。
5. 压缩参数预设和语音/字幕处理模式放到预览窗口下方，用户看过画面、字幕和源信息后再决定处理参数。
6. 影音工作台不再显示独立智能助手卡片，也不再显示独立压缩预设编辑区；这些决策入口统一下沉到具体任务详情页，避免同一能力在多个页面重复出现。
7. 任务详情保留处理日志和文件详情合并区，但流轨选择、字幕流水线和影片信息输入仍归属上一级源分析/工作流，不塞回队列详情。

## 本轮 HandBrake 专业压缩闭环

1. 总览和任务队列合并为同一个首页/任务队列入口：上方显示统计信息，下方显示完整任务队列、筛选、全选和顺序开始。
2. 顶部主入口只保留“任务队列”和“影音工作台”；右侧齿轮进入设置中心，设置中心再按工具、目录、压缩、Whisper、AI、影片信息、系统行为等分项点选进入。
3. DVD/蓝光压缩必须使用 HandBrake 扫描结构作为专业分析来源，不只依赖 ffprobe 或浏览器播放器。
4. HandBrake 扫描结果必须向前端暴露 title、视频格式、分辨率、帧率、音轨语言、音轨格式、声道、采样率、字幕语言、字幕格式、章节。
5. 前端流轨选择必须显示 HandBrake 轨道编号，避免用户看到语言和格式但执行层无法准确映射。
6. 创建压缩任务时，选择方案必须保存 HandBrake title 编号、音轨编号、字幕编号和章节编号。
6.1. MakeMKV title 索引只用于 Remux 导出；HandBrake 压缩必须使用 HandBrake 扫描匹配出的 `handbrakeTitleNumber`，不能把 MakeMKV title 顺序或界面列表顺序直接当作 HandBrake `--title`。
7. HandBrake 压缩执行必须按用户选择生成 `--title`、`--audio`、`--aencoder`、`--subtitle`、`--chapters` 和 `--markers` 参数；不能用户选择了子集，执行时仍默认 `--all-audio` / `--all-subtitles`。
8. 没有选择方案的普通视频或旧任务可以继续使用全部音轨/全部字幕默认行为，避免破坏旧数据。
9. 根目录统一诊断日志必须追加任务日志，包括 HandBrake 参数、失败 stderr 和任务错误，不能只记录安装/启动。
10. 下一步在此基础上增加 HandBrake 章节/标题截图预览：当 DVD/蓝光不能直接在浏览器播放时，在同一预览窗口显示章节截图，供用户确认 title 和章节内容。

## 本轮 title 级压缩统计与三栏工作台规则

1. “累计节省空间”只统计实际压缩任务，不统计 Remux；DVD/蓝光只压缩单个 title 时，原始大小必须使用所选 title 的大小，而不是整个 DVD/蓝光目录总大小。
2. 创建 DVD/蓝光压缩任务时，选择方案必须保存 HandBrake title 编号、所选 title 的原始大小和时长，用于后续压缩校验、时长校验和空间节省统计。
3. 切换 title / 视频流轨后，音轨、字幕和章节列表必须随当前 title 切换；当前 title 没有的音轨/字幕/章节不应继续显示为可选内容。
4. 任务详情里的压缩参数预设必须与设置页使用同一套预设数据和同一份本地保存项，不能在任务详情中再硬编码一套不同的压缩选项。
5. 任务详情默认只显示主要文件信息、输出结果和大小；源路径、字幕路径和长处理日志通过“文件详情”“处理日志”按钮展开。
6. 状态时间线应放在详情页右侧上方，先显示任务状态、时间和进度，再显示文件详情与日志。
7. “专业压缩链路”不占用整层卡片；通过按钮展开为紧凑说明，避免默认窗口被说明文字挤满。
8. 首页采用三栏结构：左侧“影音工作台”，中间“任务队列 + 统计总览”，右侧“设置入口”。这样工作入口、执行队列和设置入口同时可见，不再把总览和队列割裂。

## 本轮顶部三入口与任务队列空间修正

1. 顶部置顶工作区必须显示三个同级按键：任务队列、影音工作台、设置。设置不能只作为小齿轮或下拉菜单存在。
2. 任务队列正文不能再重复显示“影音工作台”入口，也不能再放一组正文设置入口；这些入口已经归属顶部导航。
3. 任务队列页必须以任务列表和执行状态为主。累计节省空间、运行中、等待、完成四项只作为一行紧凑状态条，不能用四个大卡片挤占默认窗口。
4. DVD/蓝光 title 列表必须直接显示每个 title 的音轨语言/格式摘要和字幕语言/格式摘要，不能只显示“几条音轨/几条字幕”。
5. 切换 title 后，流轨和章节的勾选状态必须以当前 title 为作用域。首次切换某个 title 时，勾选/取消不能从空集合开始，而应从该 title 的默认选择集开始。
6. 后续涉及界面空间的改动，优先原则是：默认窗口内把空间留给任务队列、源解析、title/音轨/字幕/章节、输出和日志等有操作价值的信息。

## 本轮设置总览、滚动条与 title 内联选择修正

1. 点击顶部“设置”进入设置页时，默认显示所有设置分类的标题、图标和说明；点击某个分类后再展开该分类具体内容，不能默认只显示“工具”一项。
2. 主内容区使用可见主题滚动条，鼠标滚轮滚动时右侧滚动条必须同步移动；不再对主滚动区使用隐藏滚动条样式。
3. 影音工作台中的“浏览选择 / 批量导入”等二级切换控件降低明度，作为二级菜单显示，不能比主处理模式更抢眼。
4. DVD/蓝光 title 列表中，视频分辨率后不再显示帧率等容易被误解的无意义数字。
5. 每条 title 可在本行内展开音轨、字幕和章节选择。用户应在 title 这一级直接决定要封装或压缩哪些内容，不再依赖 title 下方另一个独立流轨区域。
6. 当音轨、字幕或章节较多时，title 行内展开区域使用局部滚动，避免撑爆默认窗口。

## 本轮设置返回、智能工作流与统一日志修正

1. 顶部一级入口调整为：智能工作流、影音工作台、任务队列、设置。智能工作流作为未来 AI 自动处理入口，先复用当前影音工作台的文件选择与任务创建能力，后续逐步接入“选择来源后由 AI 推荐处理方案”的逻辑。
2. 设置页的任意子项必须提供“返回设置总览”，不能进入压缩参数、AI 翻译、本地工具等界面后无法回到上一级。
3. 页面外层 `html/body/root` 禁止滚动，只保留应用主内容区滚动，避免设置、压缩参数、AI 翻译等界面出现双滚动条。
4. DVD/蓝光 title 行内展开区域中的音轨、字幕和章节复选项必须可直接点击，不被 title 行点击事件干扰。
5. 任务详情页中的压缩参数预设必须可点选，并提供当前任务参数草稿编辑区；不能只显示不可操作的参数文字。
6. 光盘分析阶段不能使用导出级别的超长等待。MakeMKV 分析使用短超时，失败或超时后记录原因并回退到其他分析能力。
7. 根目录统一诊断日志必须包含任务创建失败、工具失败、光盘分析失败/超时等信息；用户只上传一个 `vx-agent-diagnostics.log` 时应能判断主要问题。

## 2026.07.15.69 工具管理修复

- Windows 安装日志显示 FFmpeg、FFprobe、HandBrakeCLI 已成功下载，但运行时状态探测不能只依赖 PATH；工具管理器现在会递归扫描托管工具目录，能够识别带版本号的解压目录和 `bin` 子目录。
- MakeMKV 没有稳定的可再分发 CLI 直链，取消误导性的“在线安装”路径，保留绿色版目录导入；导入后把原目录写入 `makemkv-source.json`，设置页刷新或重启后自动恢复。
- Whisper 与 LibreTranslate 的 Python 环境安装依次尝试清华、阿里云和 PyPI 源，每个源有超时与重试，失败原因写入统一诊断日志。
- 工具状态仍显示真实可执行文件路径和版本；安装失败不会再被显示成“已完成”，MakeMKV 只能通过绿色版导入确认。

## 2026.07.15.70 启动、浏览和工具反馈优化

- API 与前端并行启动，桌面窗口不再等待不必要的工具全量检查。
- 网络位置“最近使用”改为横向紧凑显示，默认折叠，点击标题才展开完整列表。
- 设置子页面通过顶部设置标题返回总览，删除重复的“返回设置总览”按钮；工具卡片标题改为“工具状态与安装”。
- 已安装的本地工具和 Python 包优先复用，不重复下载；安装完成后自动验证路径和版本并显示成功状态。

