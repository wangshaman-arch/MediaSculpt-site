# Windows install cache and uninstall plan

> **Version:** V 0.856 · 版本：V 0.856
Current implementation release: `2026.09.09.839`.

## Goal

MediaSculpt updates should not repeatedly download npm packages, FFmpeg, HandBrakeCLI, Whisper, LibreTranslate, or large model files.

The extracted software folder should be disposable. Large reusable assets should live outside that folder.

## Root-level one-click update and uninstall

- `安装 MediaSculpt.bat` and `收集诊断信息.bat` are available in the package root; users no longer need to enter `windows-setup`.
- Root installation first stops any previous MediaSculpt process tree, then runs the versioned installer while preserving `%LOCALAPPDATA%\MediaSculpt\Cache`, `Tools`, and `Data`.
- Root uninstall first stops services. Software-only uninstall schedules removal of the extracted package folder after the batch process exits; cache, tools, and user data remain. Complete uninstall still removes those selected external directories.

## Long-lived directories

- Software folder: the extracted MediaSculpt package.
- Cache: `%LOCALAPPDATA%\MediaSculpt\Cache`
- Tools: `%LOCALAPPDATA%\MediaSculpt\Tools`
- Data: `%LOCALAPPDATA%\MediaSculpt\Data`

The software folder can be deleted after MediaSculpt exits. Cache, Tools, and Data can remain for the next version.

## Exit and folder deletion behavior

- Closing the native desktop window requests local API shutdown instead of only closing the window. The native window is provided by the Tauri app; in source run mode the API exits on its own after the browser stops pinging it.
- If a job is still active, MediaSculpt keeps the window open and reports that it cannot exit yet.
- When shutdown is allowed, the Windows source-run launcher stops the web and API process trees and removes the temporary PID file.
- After the MediaSculpt window has closed and the launcher cleanup has finished, the extracted software folder should be deletable. Cache, Tools, and Data remain under `%LOCALAPPDATA%\MediaSculpt` unless the uninstaller removes them.

## Installer behavior

- Every bootstrap download uses built-in official and domestic mirrors where available. The installer tries each source automatically and writes the failed source into the diagnostics log before trying the next source.
- npm uses multiple registries:
  - `https://registry.npmmirror.com/`
  - `https://registry.npmjs.org/`
  - `https://registry.yarnpkg.com/`
- Node.js uses multiple sources:
  - `https://npmmirror.com/mirrors/node/`
  - `https://npmmirror.com/mirrors/nodejs-release/`
  - `https://nodejs.org/dist/`
- FFmpeg uses multiple sources:
  - `https://www.gyan.dev/ffmpeg/builds/`
  - GitHub release URLs through `https://gh.llkk.cc/`
  - GitHub release URLs through `https://mirror.ghproxy.com/`
  - direct GitHub release URLs
- HandBrakeCLI uses the official GitHub release URL plus GitHub proxy mirrors `https://gh.llkk.cc/` and `https://mirror.ghproxy.com/`.
- Python uses multiple sources:
  - `https://npmmirror.com/mirrors/python/`
  - `https://www.python.org/ftp/python/`
- Whisper pip installs use multiple indexes:
  - `https://pypi.tuna.tsinghua.edu.cn/simple`
  - `https://pypi.org/simple`
- Downloads are stored under Cache.
- Incomplete downloads use `.part` files and resume with HTTP Range headers.
- pnpm uses a long-lived store under Cache.
- The desktop window comes from the Tauri installer; the source-run installer does not download any desktop runtime, and source runs open the local UI in the browser.
- FFmpeg, HandBrakeCLI, portable Node.js, Whisper, and LibreTranslate should be installed under Tools instead of the extracted software folder.

## Install manifest

The installer writes:

`%LOCALAPPDATA%\MediaSculpt\install-manifest.json`

The manifest records:

- software folder
- release id
- Cache folder
- Tools folder
- Data folder
- desktop shortcut
- install marker
- supported uninstall modes

## Uninstall modes

- `only uninstall software`: remove shortcut and install marker, but keep Cache, Tools, and Data.
- `cache`: clear reusable download/package cache only.
- `tools`: remove installed local tools only.
- `complete uninstall`: remove software marker, Cache, Tools, Data, and manifest.

The uninstaller must not delete user media input folders, output folders, or subtitle folders.

## Recommended update flow

1. Close MediaSculpt.
2. Run `Uninstall MediaSculpt.bat`.
3. Choose `only uninstall software`.
4. Delete the old extracted software folder.
5. Download and extract the new version.
6. Run the installer.
7. The installer reuses Cache and Tools whenever possible.

---

# Windows 安装缓存与卸载方案

当前实现发布号：`2026.09.09.839`。

## 目标

MediaSculpt 更新时不应反复下载 npm 包、FFmpeg、HandBrakeCLI、Whisper、LibreTranslate 或大型模型文件。

解压出来的软件目录应可随时丢弃。大型可复用资源应放在该目录之外。

## 根目录一键更新与卸载

- 包根目录提供 `安装 MediaSculpt.bat` 和 `收集诊断信息.bat`，用户不再需要进入 `windows-setup`。
- 根目录安装先停止之前的 MediaSculpt 进程树，再运行带版本的安装器，同时保留 `%LOCALAPPDATA%\MediaSculpt\Cache`、`Tools` 和 `Data`。
- 根目录卸载先停止服务。仅卸载软件时，在批处理进程退出后调度删除解压的软件目录；缓存、工具和用户数据保留。完全卸载仍会删除这些选中的外部目录。

## 长期保留目录

- 软件目录：解压出来的 MediaSculpt 包。
- 缓存：`%LOCALAPPDATA%\MediaSculpt\Cache`
- 工具：`%LOCALAPPDATA%\MediaSculpt\Tools`
- 数据：`%LOCALAPPDATA%\MediaSculpt\Data`

MediaSculpt 退出后软件目录可以删除。Cache、Tools、Data 可留给下一版本继续使用。

## 退出与目录删除行为

- 关闭原生桌面窗口时请求本地 API 关闭，而不仅是关闭窗口。原生窗口由 Tauri 应用提供；源码运行模式下，浏览器停止心跳后 API 会自行退出。
- 如果仍有任务在运行，MediaSculpt 保持窗口打开并提示暂时无法退出。
- 允许关闭时，Windows 源码启动器停止网页和 API 进程树，并删除临时 PID 文件。
- MediaSculpt 窗口关闭且启动器清理完成后，解压的软件目录应可删除。除非卸载器删除，否则 Cache、Tools、Data 保留在 `%LOCALAPPDATA%\MediaSculpt` 下。

## 安装器行为

- 每次引导下载都尽量使用内置官方源与国内镜像。安装器自动逐个尝试来源，并在尝试下一个来源前把失败的来源写入诊断日志。
- npm 使用多个 registry：
  - `https://registry.npmmirror.com/`
  - `https://registry.npmjs.org/`
  - `https://registry.yarnpkg.com/`
- Node.js 使用多个来源：
  - `https://npmmirror.com/mirrors/node/`
  - `https://npmmirror.com/mirrors/nodejs-release/`
  - `https://nodejs.org/dist/`
- FFmpeg 使用多个来源：
  - `https://www.gyan.dev/ffmpeg/builds/`
  - 经 `https://gh.llkk.cc/` 的 GitHub release 地址
  - 经 `https://mirror.ghproxy.com/` 的 GitHub release 地址
  - 直接的 GitHub release 地址
- HandBrakeCLI 使用官方 GitHub release 地址以及 GitHub 代理镜像 `https://gh.llkk.cc/` 和 `https://mirror.ghproxy.com/`。
- Python 使用多个来源：
  - `https://npmmirror.com/mirrors/python/`
  - `https://www.python.org/ftp/python/`
- Whisper pip 安装使用多个索引：
  - `https://pypi.tuna.tsinghua.edu.cn/simple`
  - `https://pypi.org/simple`
- 下载存放在 Cache 下。
- 未完成的下载使用 `.part` 文件，并通过 HTTP Range 头断点续传。
- pnpm 在 Cache 下使用长期 store。
- 桌面窗口由 Tauri 安装器提供；源码安装器不再下载任何桌面运行时，源码运行时在浏览器中打开本地界面。
- FFmpeg、HandBrakeCLI、便携 Node.js、Whisper 和 LibreTranslate 应安装到 Tools 而不是解压的软件目录内。

## 安装清单

安装器写入：

`%LOCALAPPDATA%\MediaSculpt\install-manifest.json`

清单记录：

- 软件目录
- release id
- Cache 目录
- Tools 目录
- Data 目录
- 桌面快捷方式
- 安装完成标记
- 支持的卸载模式

## 卸载模式

- `only uninstall software`（仅卸载软件）：删除快捷方式和安装标记，保留 Cache、Tools、Data。
- `cache`：只清理可复用的下载/包缓存。
- `tools`：只删除已安装的本地工具。
- `complete uninstall`（完全卸载）：删除软件标记、Cache、Tools、Data 和安装清单。

卸载器绝不能删除用户媒体输入目录、输出目录或字幕目录。

## 推荐更新流程

1. 关闭 MediaSculpt。
2. 运行 `Uninstall MediaSculpt.bat`。
3. 选择 `only uninstall software`。
4. 删除旧解压软件目录。
5. 下载并解压新版本。
6. 运行安装器。
7. 安装器尽量复用 Cache 和 Tools。

