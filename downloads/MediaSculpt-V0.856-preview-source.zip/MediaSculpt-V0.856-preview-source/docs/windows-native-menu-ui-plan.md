# Windows Normal Window and Dropdown Menu UI Plan

> **Version:** V 0.856 · 版本：V 0.856
## Confirmed requirements

- MediaSculpt opens as a normal Windows window on Windows and no longer opens the system browser automatically.
- The API and frontend services can still run as local background services, but users only need to see the MediaSculpt main window.
- Closing the MediaSculpt main window stops the API and frontend services started this time, so the install directory can be deleted or replaced.
- Settings and system logs no longer appear in the left navigation.
- Settings, system logs, and other entries move to the top dropdown menu.
- After clicking an item in the top dropdown menu, the UI shows only that item's content, avoiding laying out the whole settings page at once.

## Top menu structure

- File
  - Choose video or disc
  - Open job queue
  - Exit MediaSculpt
- Process
  - Scan/analyze source
  - Job queue
- Tools
  - Local tool status
  - Install/update local tools
- Settings
  - Directory settings
  - Compression parameters
  - Whisper and subtitles
  - AI translation
  - Movie information
  - External tool paths
  - System behavior
- Help
  - System logs
  - Diagnostics logs

## Current implementation

- Reuse the same local API and frontend core code, avoiding rewriting business logic for Windows.
- The Windows launcher starts the API and frontend services hidden.
- The installed application is the Tauri desktop app (`desktop-tauri`): it starts the bundled Node API sidecar on `http://127.0.0.1:18080`, opens a frameless native window with custom caption buttons, and loads the local UI from the sidecar. It never opens the system browser.
- Closing the Tauri window asks the local API to shut down; while a job is still running the window stays open and the UI shows a "shutdown blocked" notice.
- Task completion flashes the taskbar icon and shows a system notification through the Tauri notification plugin.
- Source run mode (`Start MediaSculpt.bat` after `安装 MediaSculpt.bat`) is for development and testing only: the launcher starts the API sidecar hidden and opens one native Tauri window. It does not open a browser or start a separate desktop shell.

## Remaining UI work

- Further organize scanning, preview, processing parameters, and the job queue into a workflow closer to traditional desktop software.
- Unify DVD/Blu-ray chapter preview, subtitle preview, compression preset selection, and movie-info input into the same source preview window.
- Keep converging system logs, tool install logs, and job logs into the root unified diagnostics log to reduce the number of files users must upload.

---

# Windows 常规窗口与下拉菜单界面计划

## 已确认要求

- MediaSculpt 在 Windows 上应以常规 Windows 窗口形式打开，不再自动打开系统浏览器。
- API、前端服务仍可作为本地后台服务运行，但用户只需要看到 MediaSculpt 主窗口。
- 关闭 MediaSculpt 主窗口后，应停止本次启动的 API 和前端服务，使安装目录可删除或替换。
- 设置和系统日志不再出现在左侧导航。
- 设置、系统日志等功能入口移动到顶部下拉菜单。
- 用户点击顶部下拉菜单中的具体项目后，界面只显示对应项目内容，避免设置页一次性铺开。

## 顶部菜单结构

- 文件
  - 选择视频或原盘
  - 打开任务队列
  - 退出 MediaSculpt
- 处理
  - 扫描/分析来源
  - 任务队列
- 工具
  - 本地工具状态
  - 安装/更新本地工具
- 设置
  - 目录设置
  - 压缩参数
  - Whisper 与字幕
  - AI 翻译
  - 影片信息
  - 外部工具路径
  - 系统行为
- 帮助
  - 系统日志
  - 诊断日志

## 当前实现方式

- 继续复用同一套本地 API 和前端核心代码，避免为 Windows 单独重写业务逻辑。
- Windows 启动脚本隐藏启动 API 与前端服务。
- 正式安装的应用是 Tauri 桌面应用（`desktop-tauri`）：它启动内置的 Node API 侧车（`http://127.0.0.1:18080`），打开带自绘标题栏按钮的无边框原生窗口，并从侧车加载本地界面，不会打开系统浏览器。
- 关闭 Tauri 窗口时请求本地 API 关闭；仍有任务运行时窗口保持打开，界面提示暂时无法退出。
- 任务完成时通过 Tauri 通知插件闪烁任务栏图标并弹出系统通知。
- 源码运行模式（先运行 `安装 MediaSculpt.bat`，再运行 `Start MediaSculpt.bat`）仅用于开发和测试：启动脚本隐藏启动 API 侧车并打开一个原生 Tauri 窗口，不打开浏览器，也不启动任何独立桌面壳。

## 后续仍需继续的界面工作

- 把扫描、预览、处理参数、任务队列进一步整理成更接近传统桌面软件的工作流。
- 将 DVD/蓝光章节预览、字幕预览、压缩预设选择和影片信息输入统一到同一个源预览窗口中。
- 将系统日志、工具安装日志、任务日志继续收敛到根目录统一诊断日志，减少用户需要上传的文件数量。

