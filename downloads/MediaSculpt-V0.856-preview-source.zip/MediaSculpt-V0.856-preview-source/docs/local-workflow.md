# Local Video Processing Workflow

> **Version:** V 0.856 · 版本：V 0.856
1. Choose a normal video, DVD, Blu-ray directory, or ISO.
2. The API reads media information locally and the frontend shows a video preview.
3. Probe video, audio, subtitle streams, and chapters.
4. Select video tracks, audio tracks, subtitles, and chapters; DVD supports title selection and Blu-ray supports playlist selection.
5. Choose the processing method: lossless Remux or HandBrake compression.
6. Choose the subtitle flow: automatic extraction, Whisper original-language recognition, Whisper translation, or skip.
7. Save processing parameters and show the current step and estimated output.
8. Execute the job and record logs and progress in real time.
9. After Remux/compression completes, validate the output file, size, and duration.
10. Preview the final video locally and save the video, original subtitles, and translated subtitles.

All media reading, processing, and output happen on the user's own computer; no video is uploaded to the cloud.

---

# 本地视频处理流程

1. 选择普通视频、DVD、蓝光目录或 ISO。
2. API 在本机读取媒体信息，前端显示视频预览。
3. 探测视频、音频、字幕流和章节。
4. 选择视频轨道、音轨、字幕和章节；DVD 可选 title，蓝光可选 playlist。
5. 选择处理方式：Remux 无损封装或 HandBrake 压缩。
6. 选择字幕流程：自动提取、Whisper 原语言识别、Whisper 翻译或跳过。
7. 保存处理参数，显示当前步骤和预计输出。
8. 执行任务并实时记录日志和进度。
9. Remux/压缩完成后校验输出文件、大小和时长。
10. 在本地预览最终视频，并保存视频、原始字幕和译文字幕。

所有媒体读取、处理和输出都发生在用户自己的电脑上，不上传视频到云端。

