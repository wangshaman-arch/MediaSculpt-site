# MediaSculpt legal, licensing, and privacy notes

> **Version:** V 0.856 · 版本：V 0.856
## Copyright and license

MediaSculpt（影刻）源代码、界面、品牌、文档和软件本身是专有内容，不按 MIT 或其他开源许可证授权。V0.840 Preview 是免费试用版，具体限制和责任见 [`EULA.md`](../EULA.md) 与 [`LICENSE`](../LICENSE)。

## Third-party software

MediaSculpt can use or bundle Tauri, Node.js, React, FFmpeg/FFprobe, HandBrakeCLI, Whisper, LibreTranslate, OCR engines, and other open-source packages. They remain under their own licenses; MediaSculpt does not relicense them. See [`THIRD-PARTY-NOTICES.md`](../THIRD-PARTY-NOTICES.md) and retain the notices shipped with each actual binary or model.

## Privacy and network behavior

Media files, SQLite data, logs, tool caches, and generated outputs are processed on the local machine by default. Network access occurs only when enabled or required by the selected setup, such as downloading tools/models or calling a configured translation, metadata, poster, or visual-OCR service. When a remote service is configured, the data sent to that service is governed by its terms and privacy policy. Do not submit media or subtitles unless you have the necessary rights and consent.

This is a Windows public preview release. The software is provided without warranty; verify outputs and keep backups of source media.

---

# MediaSculpt（影刻）版权、许可与隐私说明

## 版权与许可证

MediaSculpt（影刻）的源代码、界面、品牌、文档和软件本身是专有内容，不按 MIT 或其他开源许可证发布。V0.840 Preview 为免费试用版，具体条款见 [`EULA.md`](../EULA.md) 和 [`LICENSE`](../LICENSE)。

## 第三方软件

MediaSculpt 可能使用或随软件提供 Tauri、Node.js、React、FFmpeg/FFprobe、HandBrakeCLI、Whisper、LibreTranslate、OCR 引擎以及其他开源依赖。它们仍分别适用各自的许可证和版权声明；MediaSculpt 不会重新授权这些组件。重新分发实际组件时应保留各工具随附的许可证文件，具体产品级清单见 [`THIRD-PARTY-NOTICES.md`](../THIRD-PARTY-NOTICES.md)。

## 隐私与联网行为

默认情况下，视频、SQLite 数据、日志、工具缓存和生成文件都在本机处理。只有在用户启用或所选流程需要时才会联网，例如下载工具/模型，或调用已配置的翻译、元数据、海报或视觉 OCR 服务。配置远程服务后，发送给该服务的数据受其条款和隐私政策约束。请确认自己拥有处理和提交相关视频、字幕的必要权利与授权。

当前版本是 Windows 公开预览版，软件不提供保证；请自行核验输出并保留源素材备份。
