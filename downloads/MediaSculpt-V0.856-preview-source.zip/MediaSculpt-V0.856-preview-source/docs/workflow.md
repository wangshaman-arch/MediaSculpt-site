# Workflow Design

> **Version:** V 0.856 · 版本：V 0.856
## Overall flow

The software should deliver a workflow-style experience instead of simply piling tools such as Subtitle Edit, HandBrake, MakeMKV, and MKVToolNix together.

Recommended main flow:

1. Add source.
2. Auto-analyze.
3. Generate a processing plan.
4. User confirms or fine-tunes.
5. Execute the job queue.
6. Validate output.
7. Archive results.

## Add source

Source types include:

- A single video file.
- A folder.
- A Blu-ray BDMV folder.
- A DVD VIDEO_TS folder.
- An ISO image.
- Loose downloaded videos.
- NAS or network share paths.

On first use, let the user choose the default input directory. Afterwards, remember the last input directory when the app opens.

## Auto-analyze

Analysis includes:

- Video format, resolution, HDR/SDR, frame rate, and bitrate.
- Audio track count, language, channels, and codec.
- Subtitle count, language, and text or graphic format.
- Chapter information.
- Attachments and fonts.
- File source and probable movie title, year, and IMDb ID.

For Blu-ray and DVD, identify multiple titles/playlists and distinguish main features, extras, interviews, trailers, and menu segments.

AI can enhance type judgment of multiple video contents, but it must not replace local analysis or delete content automatically.

## Generate a processing plan

The software should generate a readable plan for each source, for example:

- Lossless mux.
- High-quality compression.
- Video compression with subtitles skipped.
- Subtitle extraction.
- OCR subtitles.
- Speech-recognition subtitles.
- AI translation.
- Metadata scraping.
- README/NFO generation.

Users can accept the default plan or modify audio tracks, subtitles, compression parameters, naming rules, and the output directory.

## Execute jobs

Jobs should be split into independent steps, each with status, logs, and failure reasons.

Recommended steps:

1. Analyze the source file.
2. Choose the main video or title.
3. Extract or preserve audio tracks, subtitles, and chapters.
4. Run remux or compression.
5. Generate subtitle files.
6. Run AI translation or correction.
7. Generate metadata and description files.
8. Validate output.

If video processing succeeds but AI translation fails, the job should be allowed to complete partially.

## Suggested output structure

```text
Videos/MediaSculpt Output/
  Movies/
  Subtitles/
    original/
    translated/
    bilingual/
  Metadata/
  Logs/
```

Finished videos go into Movies.

Original subtitles, OCR results, Chinese subtitles, and bilingual subtitles are saved separately. By default, translated subtitles are not embedded into the video, so a translation failure does not affect video processing.

Metadata stores posters, NFO, and Chinese/English README files.

Logs store each job's log for troubleshooting.

---

# 工作流程设计

## 总体流程

软件应采用工作流式体验，而不是把 Subtitle Edit、HandBrake、MakeMKV、MKVToolNix 等工具简单堆在一起。

推荐主流程：

1. 添加来源
2. 自动分析
3. 生成处理方案
4. 用户确认或微调
5. 执行任务队列
6. 校验输出
7. 归档结果

## 添加来源

来源类型包括：

- 单个视频文件
- 文件夹
- 蓝光 BDMV 文件夹
- DVD VIDEO_TS 文件夹
- ISO 镜像
- 零散下载视频
- NAS 或网络共享路径

第一次使用时让用户选择默认输入目录。之后打开软件时自动记住上次输入目录。

## 自动分析

分析内容包括：

- 视频格式、分辨率、HDR/SDR、帧率、码率
- 音轨数量、语言、声道、编码格式
- 字幕数量、语言、文本或图形格式
- 章节信息
- 附件和字体
- 文件来源和可能的影片名、年份、IMDb ID

对于蓝光和 DVD，应识别多个 title/playlist，区分正片、花絮、采访、预告片、菜单片段等。

AI 可以作为增强，用于辅助判断多个视频内容的类型，但不能替代本地分析，也不能自动删除内容。

## 生成处理方案

软件应为每个来源生成可读的处理方案，例如：

- 无损封装
- 高质量压缩
- 跳过字幕的视频压缩
- 字幕提取
- OCR 字幕
- 语音识别字幕
- AI 翻译
- 元数据刮削
- README/NFO 生成

用户可以直接接受默认方案，也可以修改音轨、字幕、压缩参数、命名规则和输出目录。

## 执行任务

任务应拆成独立步骤，每一步有状态、日志和失败原因。

推荐步骤：

1. 分析源文件
2. 选择主视频或标题
3. 提取或保留音轨、字幕、章节
4. 执行 remux 或压缩
5. 生成字幕文件
6. 执行 AI 翻译或纠错
7. 生成元数据和说明文件
8. 校验输出

视频处理成功但 AI 翻译失败时，任务应允许部分完成。

## 输出结构建议

```text
Videos/MediaSculpt Output/
  Movies/
  Subtitles/
    original/
    translated/
    bilingual/
  Metadata/
  Logs/
```

成品视频放在 Movies。

原始字幕、OCR 结果、中文字幕、双语字幕分别保存，不建议默认把翻译字幕内嵌进视频，以免翻译失败影响视频处理。

Metadata 保存封面、NFO、README 中英文说明。

Logs 保存每个任务的日志，便于排查失败原因。

