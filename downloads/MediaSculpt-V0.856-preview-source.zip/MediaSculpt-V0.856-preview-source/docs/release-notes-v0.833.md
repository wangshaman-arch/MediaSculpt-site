# MediaSculpt V0.833 基础版发布说明

> **Version:** V 0.856 · 版本：V 0.856
## 版本定位

V0.833 基础版是 MediaSculpt 的 Windows 原生本地测试安装器。它是参照上一版制作的 Tauri NSIS `.exe`，内置当前前端、API、Node、FFmpeg、FFprobe 和 HandBrakeCLI，安装后可直接启动。

该版本适合在真实 Windows 机器上验证：

- DVD / 蓝光目录或 ISO 的媒体分析、Remux 和压缩任务
- 预览播放、拖动快进和字幕显示
- 字幕提取、Whisper 转写和翻译工作流
- 本地输入目录、输出目录和工具路径配置
- 安装、启动、停止、升级及诊断日志流程

## 基础安装器内容

基础安装器内置：

- Tauri 原生 Windows 窗口和桌面快捷方式
- 当前 API、前端静态文件和 Node sidecar
- FFmpeg / FFprobe（包含 DVD `dvdvideo` 所需能力）
- HandBrakeCLI
- 安装和卸载所需的本地运行资源

基础安装器不包含：Whisper 大模型、用户 SQLite 数据库、诊断日志和下载缓存。可选工具在软件内按需安装，用户数据保留在本机。

仓库同时保留 `MediaSculpt-V0.833-baseline.zip` 作为开发者源码安装包。

## 安装和运行

1. 运行 `MediaSculpt_0.833.0_x64-setup-base.exe`。
2. 选择安装目录并完成安装。
3. 从桌面或开始菜单启动 MediaSculpt。
4. 首次启动后，在设置页确认输入目录、输出目录和本地工具状态。
5. 处理失败时使用已安装的 MediaSculpt 诊断入口，上传 `mediasculpt-diagnostics.log`。

安装器默认跳过 Whisper 的大型模型下载。需要语音转写时，在设置页安装模型，或在安装前设置 `VX_AGENT_INSTALL_WHISPER=1`。

## 已知限制

- 这是带安装程序的基础测试发布包，不是免安装单文件程序；Whisper 和其他可选工具需要首次使用时再下载。
- DVD / 蓝光 Remux 对原盘结构、FFmpeg `dvdvideo` 能力和可读权限敏感，真实原盘测试时应保留诊断日志。
- 完整 API 测试中仍有历史 Windows/Tauri 合约测试与当前 Electron 启动方式不一致；发布前已通过类型检查、构建和本次预览相关测试，详见仓库 CI 或开发记录。

