# Smart Workflow V1

> **Version:** V 0.856 · 版本：V 0.856
The currently displayed software version is `V 0.850` (Windows baseline release). Version rules are documented in `docs/product-rules.md`: development builds use `V 0.832`, `V 0.835`, `V 0.836`, `V 0.837`, `V 0.838`, `V 0.850`, ... and the installer's internal `release-id.txt` continues to use an independent packaging verification number.

## Positioning

MediaSculpt keeps two coexisting working modes: traditional tool mode and smart workflow mode. Traditional pages continue to call the existing media analysis, Remux, HandBrake, Whisper, subtitle processing, and job queue directly; the smart workflow is only responsible for analysis, suggestions, confirmation, and scheduling — it does not duplicate any executors.

The dependency direction is fixed as:

```text
smart workflow → shared analysis/strategy → existing job creation + taskSnapshot → job queue/executors
```

When AI, movie metadata, or poster services are unavailable, the workflow degrades to local analysis plus deterministic rules; such failures do not pollute the traditional pages.

## V1 data flow

1. The user enters a file or folder in the existing "Smart workflow" tab.
2. The server reads technical facts only with local tools and the existing `/disc/analyze` and `ffprobe` capabilities.
3. Movie information reuses the existing `metadata/lookup` and the TMDB, OMDb, and IMDb configuration in settings. Without configuration, the manual identity form and generic name remain available.
4. The shared strategy module generates a versioned `SmartWorkflowPlanV1`. The plan contains only data, selections, and actions — no command lines.
5. The user confirms source, identity, titles/files, tracks, presets, subtitles, and output names layer by layer.
6. After final validation, save `processing-plan.json`, then convert each enabled item into existing `/jobs` requests, reusing taskSnapshot and the executors.

## Connection testing and failure logs

- "Test current AI connection" in settings sends only a minimal request: it does not run media processing and never writes API keys to logs.
- Workflow analysis and job-creation errors are aggregated into the root diagnostics log via `/smart-workflow/client-log`; the server also records response status, model, duration, and error context.
- DVD Remux validates the user-selected title before creating the job; on validation failure it keeps an explicit error and does not fall back to a default title.

## Processing plan

The plan contains `schemaVersion`, source fingerprint, movie identity, stable title/file IDs, actions, existing preset IDs, track selection, subtitle/Whisper/translation strategy, output names, warnings, rationale, and confidence. Title IDs come from DVD/Blu-ray analysis; normal files use a stable ID generated from the source fingerprint plus file name, never an array index in the UI.

Plan validation rejects nonexistent sources, duplicate IDs, invalid presets, illegal output names, overwriting source files, output conflicts, missing Whisper audio tracks, handing graphic subtitles directly to translation, and circular dependencies. Plans can be saved, restored, and edited.

## Deterministic strategy

- High-bitrate old codecs (MPEG-2, MPEG-4, or high-bitrate AVC) suggest compression and mark it as an estimate.
- Efficient codecs already at a reasonable bitrate (HEVC/AV1) do not suggest re-compression by default.
- Chinese text subtitles are preserved by default; foreign text subtitles are translated directly without Whisper; when no text subtitle exists, Whisper runs on the bound real main audio track; graphic subtitles are preserved as-is without OCR.
- DVD/Blu-ray generate one plan per title; AI only assists with purpose and naming suggestions, and the user can always re-enable or modify.

## Reusing settings and traditional modules

The workflow reads the existing AI translation and movie-info settings and only displays service status; it never stores a second key or model config. Compression references existing preset IDs only and does not copy parameters. After confirmation, it calls the existing `/jobs`, snapshot, logs, progress, cancel, and output-validation chain.

## Layered UI

The existing smart workflow page is divided into: choose source, analyze and confirm movie, processing plan, and created results. When analysis or candidate search fails, technical results are preserved so the user can continue manually; plan editing never re-scans or re-calls AI.

For a disc, confirming the title selection must open the existing video/subtitle preview page (`/batch`) with the verified title, stream, and chapter selections. This handoff is selection-only: it must not call `/api/jobs` or enter the job queue. Jobs are created only after the user reviews the preview and confirms the processing choices there.

## Out of scope for this round

This round does not develop graphic subtitle OCR, unattended execution, automatic source deletion, media library, poster editor, standalone subtitle pages, new executors, new Blu-ray routes, or an overall navigation refactor. Opening job-queue directories uses the existing safe path module and is protected by regression tests.

---

# 智能工作流 V1

当前软件显示版本：`V 0.850`（Windows 基础发布版）。版本规则见 `docs/product-rules.md`：开发版从 `V 0.832` 起、`V 0.835`、`V 0.836`、`V 0.837`、`V 0.838`、`V 0.850` … 每次发布步进；安装包内部 `release-id.txt` 继续使用独立的打包校验编号。

## 定位

MediaSculpt 保留两种同时存在的工作方式：传统工具模式与智能工作流模式。传统页面继续直接调用现有的媒体分析、Remux、HandBrake、Whisper、字幕处理和任务队列；智能工作流只负责分析、建议、确认和调度，不复制任何执行器。

依赖方向固定为：

```text
智能工作流 → 公共分析/策略 → 现有任务创建与 taskSnapshot → 任务队列/执行器
```

AI、影片资料或海报服务不可用时，工作流退化为本地分析加确定性规则；这类故障不会污染传统页面。

## V1 数据流

1. 用户在现有“智能工作流”选项卡输入一个文件或文件夹。
2. 服务端只使用本地工具和已有 `/disc/analyze`、`ffprobe` 能力读取技术事实。
3. 影片信息沿用现有 `metadata/lookup` 和设置中的 TMDB、OMDb、IMDb 配置。没有配置时保留手动身份表单和通用名称。
4. 公共策略模块生成版本化 `SmartWorkflowPlanV1`。计划只包含数据、选择和动作，不包含命令行。
5. 用户逐层确认来源、身份、标题/文件、轨道、预设、字幕和输出名称。
6. 最终校验通过后保存 `processing-plan.json`，再把每个启用项转换为现有 `/jobs` 请求，沿用现有 taskSnapshot 和执行器。

## 连接测试与故障日志

- 设置中的“测试当前 AI 连接”只发送一个最小请求，不执行媒体处理，也不把 API Key 写入日志。
- 工作流分析和任务创建错误通过 `/smart-workflow/client-log` 汇总到根目录诊断日志；服务端同时记录响应状态、模型、耗时和错误上下文。
- DVD Remux 在创建任务前验证用户选择的具体标题，验证失败时保留明确错误，不回退到默认标题。

## 处理计划

计划包含 `schemaVersion`、来源指纹、影片身份、标题/文件稳定 ID、动作、现有 preset ID、轨道选择、字幕/Whisper/翻译策略、输出名称、警告、理由和置信度。标题 ID 来源于 DVD/蓝光分析结果；普通文件使用来源指纹加文件名生成的稳定 ID，绝不使用界面数组下标作为执行身份。

计划校验会拒绝不存在的来源、重复 ID、无效 preset、非法输出名、覆盖源文件、输出冲突、缺少 Whisper 音轨、把图形字幕直接交给翻译，以及循环依赖。计划可以保存、恢复和编辑。

## 确定性策略

- 高码率旧编码（例如 MPEG-2、MPEG-4 或高码率 AVC）建议压缩，并显示这是估算。
- 已是合理码率的 HEVC/AV1 等高效编码默认不建议二次压缩。
- 中文文本字幕默认保留；外语文本字幕直接翻译，不运行 Whisper；没有文本字幕时绑定真实主音轨运行 Whisper；图形字幕原样保留，不做 OCR。
- DVD/蓝光每个标题分别生成计划，AI只能辅助用途和命名建议，用户始终可以重新启用或修改。

## 复用设置和传统模块

工作流读取现有 AI 翻译和影片信息设置，只显示服务状态，不保存第二份密钥或模型配置。压缩只引用现有 preset ID，不复制参数。确认后调用现有 `/jobs`、快照、日志、进度、取消和输出校验链路。

## 分层界面

现有智能工作流页分为：选择来源、分析与影片确认、处理计划、创建结果。分析和候选搜索失败时保留技术结果，允许手动继续；计划编辑不会重新扫描或重复调用 AI。

智能工作流中的光盘预览弹窗属于“仅解析”入口：它负责读取 DVD/蓝光标题、完整流轨、章节和 DVD 标题校验，只展示预览与选择摘要，不显示 Remux、压缩、字幕处理三个重复的处理按钮，也不直接创建任务。每个 Title 的流轨区域提供“全选/清空流轨”，Title 列表顶部提供“全选/清空光盘轨道”；DVD 的整盘选择仍经过无效标题和容量安全校验。默认全选章节不把初次扫描的章节编号固化到任务，服务端会按已校验 Title 重新解析实际章节。处理方式统一留给下一层的处理计划选择。传统工作台入口不受此规则影响，仍可在光盘解析弹窗中按原流程创建任务。

光盘选择确认后，必须进入现有的“视频与字幕预览”页（`/batch`），把已验证的 Title、流轨和章节选择写入临时批量清单；这个动作本身不得调用 `/api/jobs`，也不得跳转任务队列。用户在预览页检查画面、字幕和详情，并在处理方式确认后才创建任务。这样可以避免“选择确认即入队”以及用失败任务代替预览的问题。

## 本轮范围外

本轮不开发图形字幕 OCR、无人确认执行、自动删除源文件、媒体库、海报编辑器、独立字幕页面、新执行器、蓝光新路线或整体导航重构。任务队列的打开目录使用现有安全路径模块，并以回归测试保护。

