# Graphic Subtitle OCR (V1)

> **Version:** V 0.856 · 版本：V 0.856
## Scope

- Recognize Blu-ray PGS (`.sup`) and DVD VobSub graphic subtitles into text SRT.
- Engine selection: "auto" prefers the local Tesseract engine and falls back to the vision LLM; both are available in V1.
- Local engine: Tesseract OCR (offline, no cloud upload; needs Tesseract + language data installed in the managed tools directory or on PATH).
- Cloud engine: LLM vision (requires a vision-capable model such as gpt-4o / qwen-vl / glm-4v / gemini).
- Auto language detection (script analysis + LLM confirmation), with manual override.
- The original graphic subtitle track is always preserved.

## Usage

1. In the workbench, open the subtitle tab and click "Graphic subtitle OCR".
2. Set the OCR preset (engine + language). It is saved globally and applied
   automatically to every new OCR task — no per-task re-selection.
3. Video files: select the files, add them to the queue, then press Start in
   the task queue (same flow as other subtitle modes).
4. DVD / Blu-ray: open the disc directory, click Analyze, choose the title and
   stream, confirm — the task enters the queue, then press Start.
5. While running, the queue shows the current stage and the tool in use
   (HandBrake passthrough → ffmpeg frame decode → Tesseract / vision LLM → SRT).

"Auto" language prefers the English graphic subtitle track when the source has
multiple tracks; it falls back to the first tagged track, then to content
detection when there is no language tag.

## API

OCR runs as a queue job (same executor as other subtitle modes):

```json
POST /api/jobs
{ "filePath": "...", "subtitleMode": "ocr", "ocrEngine": "auto",
  "ocrLanguage": "auto", "processingMode": "none" }
```

- The task snapshot stores `ocrEngine` / `ocrLanguage`; `subtitleSource` becomes
  `ocr` on success and `subtitlePath` points to the generated `*.ocr.srt`.
- Disc jobs are created through disc analysis with `analysisId`,
  `sourceFingerprint`, `selectedTitleId` and `outputMode: "subtitle"`.

## Engines

- `auto` (default): local Tesseract first, vision LLM fallback.
- `tesseract` (V1): local OCR, fully offline.
- `llm` (V1): vision LLM OCR via the configured AI provider.
- `subtitleedit`: reserved, coming in a later version.
- DVD VobSub is supported: the DVD folder is extracted through HandBrake (subtitle passthrough, cached per disc+title), decoded to subtitle frames and OCR'd with the same engines. The first run per title needs HandBrake (about 10-20 minutes); repeat runs use the cache.

## Notes

- Video stays local; only subtitle images are sent to the configured AI provider.
- OCR quality depends on the subtitle font and the vision model; the AI provider must support image input.

## V 0.69 changes

- Tesseract is now a managed tool: on Windows it can be installed from
  Settings → Tools (the standard installer runs silently into the managed tool
  directory) and the common language data
  (eng / chi_sim / chi_tra / jpn / kor / rus / deu / fra / spa / ...) is
  downloaded automatically. Missing languages can be added individually through
  the tool manager or `POST /api/runtime/tools/tesseract/language/:lang`.
- OCR jobs now fail fast: before any DVD scan or HandBrake transcode, the
  software verifies that the selected engine and its language data are
  available. A missing Tesseract or missing traineddata fails in seconds with
  an actionable message instead of after a 10-20 minute transcode.

## V 0.70 changes

- The DVD subtitle track's real language is now propagated into OCR: an "auto"
  preset on a Russian-only disc actually uses `rus` (Tesseract `-l rus`)
  instead of always falling back to `eng`.
- When the track has no language tag and the preset is "auto", the OCR samples
  one subtitle frame, tries the installed language data, and picks the script
  that matches best (Cyrillic / Han / Kana / Hangul / Arabic / Latin).
- The queue logs now show the subtitle coverage span
  (`解析到 N 条字幕（时间范围 HH:MM:SS → HH:MM:SS）`), so a sparse/partial
  source track is visible before the result is used.
- DVD OCR no longer leaves a duplicate `VIDEO_TS.ocr.srt` next to the disc:
  only the single `*.ocr.srt` in the job subtitle directory is kept.

## V 0.71 changes

- OCR results are now validated before saving: the job measures the source
  track's subtitle events, coverage end and video duration, and rejects the
  result when the line count is far below a dialog-subtitle estimate
  (`max(minutes × 6, 30)`) or coverage is under 80%. A 96-minute movie that
  yields 41 lines therefore fails with a clear "track incomplete" error
  instead of producing an unusable SRT. Clips under 10 minutes are skipped.
- The OCR language picker is redesigned as a searchable combobox: it stays
  inside the viewport (`max-height: min(50vh, 360px)` with scrolling) and
  supports typing a language name or code to filter the 50+ entries.
- Tesseract language data now prefers the accurate `tessdata_best` models
  (the recognition dictionaries) and falls back to `tessdata_fast` only when a
  language is not published in the best tier.

## V 0.72 changes

- Fixed HandBrake scan parsing: the CLI prints a version banner before the
  JSON document, which previously broke subtitle-track selection and silently
  fell back to track 1 with no language (the root cause of the "Russian OCR"
  confusion). Track selection now works and the chosen track's language is
  used for OCR.
- Auto track preference is now Chinese first, then English, then any tagged
  track, then the first track. A disc with a Chinese VobSub track is OCR'd
  directly as Chinese (chi_sim/chi_tra), so no translation is needed.
- Auto language detection is more robust: it samples up to three frames
  (first/middle/last), skips ambiguous frames with no recognized text, and
  prefers English on ties instead of arbitrarily picking Russian.
- After OCR, when the source language is not Chinese, the job calls the
  configured LLM with an OCR-correction prompt that includes the DVD/source
  name ("this is OCR-recognized subtitle of <name>; correct errors, then
  translate to Chinese") and writes `<name>.zhs.srt`, batching 50 lines per
  request.
- The OCR extraction cache key now includes the subtitle track number, so
  switching tracks never reuses a cache built from a different track.

## V 0.73 changes

- Subtitle frames are preprocessed before OCR: transparent VobSub/PGS bitmaps
  (white text with outline) are upscaled 2x and converted to black-on-white
  grayscale, which dramatically improves recognition (previously Tesseract saw
  mostly-empty transparent canvases and produced gibberish).
- Chinese tracks are auto-detected as simplified or traditional: up to three
  sample frames are OCR'd with both chi_sim and chi_tra, and the variant with
  coherent traditional characters wins (this DVD's track is traditional).
- Tesseract's per-character spacing in CJK output is cleaned up
  ("旁 述" → "旁述").
- OCR now always runs the configured LLM pass: Chinese sources are corrected
  (including traditional → simplified), non-Chinese sources are corrected and
  translated. The raw OCR result stays in `*.ocr.srt` and the LLM result is
  written to `*.zhs.srt`, both with the DVD/source name in the prompt.

## V 0.74 changes

- Bilingual cross-correction: when the OCR source track is not English, the
  job automatically OCRs the English track too (cached) and passes both to the
  LLM, which uses the accurate English lines as the semantic reference to fix
  Chinese OCR errors (names, proper nouns, wrong/missing characters).
- The LLM instruction now forces simplified Chinese output with explicit
  examples ("我們" → "我们") and forbids traditional characters; verified
  against a live DeepSeek call (e.g. OCR "肉嘉倫" corrected to "帕瓦罗蒂").
- The English reference pass writes a temporary `*.eng.ocr.srt` that is
  removed after being read, so no extra files are left behind.

## V 0.75 changes

- OCR is now integrated into the "auto" subtitle pipeline: when a source has
  only graphic subtitles (PGS/VobSub), auto mode OCRs them (with bilingual
  cross-correction) instead of immediately falling back to Whisper. OCR is
  still skipped and Whisper is used when OCR fails or the track is rejected by
  the completeness check.
- New global setting "Bilingual OCR cross-correction" (Settings → Subtitles):
  turning it off skips the extra English-track OCR pass for speed while keeping
  single-track OCR + LLM correction.
- The OCR flow is extracted into a shared executor used by both explicit OCR
  jobs and the auto pipeline, so behavior stays identical.

## V 0.76 changes

- Existing subtitles are detected by content and file size (not extension):
  if a Chinese subtitle already exists in the source directory, OCR and
  translation are skipped; if an English subtitle exists, it is reused as the
  bilingual reference instead of re-OCR'ing the English track. Explicit OCR
  mode also skips already-existing languages with a log.
- Three output files: `*.ocr.srt` (source-track OCR raw), `*.en.srt` (English
  track, native, when present) and `*.zhs.srt` (simplified Chinese).
- Bilingual reference is aligned by start time (nearest match within 5s)
  instead of by line index, so tracks with different event counts stay in sync.
- Track selection for video files counts subtitle packets: auto prefers the
  longest Chinese track, then the longest English track, then the longest
  tagged track, then the track with the most events overall. DVD selection
  keeps Chinese → English → tagged → first language priority.
- LLM context now includes Douban as the authoritative source for the Chinese
  title and name translations (best-effort fetch, never blocking), plus the
  TMDb zh-CN translation; the prompt explicitly says Wikipedia-zh is only a
  reference and may contain Taiwan-maintained translation differences.

## V 0.77 changes

- Speech recognition switched to faster-whisper (CTranslate2, int8, CPU):
  roughly 4x faster than openai-whisper with lower memory use; models download
  through the HuggingFace mirror. The "large" preset maps to large-v3.
- New local OCR engine: RapidOCR (PP-OCRv4 via ONNX), a managed tool installed
  into its own Python environment. Chinese tracks automatically prefer
  RapidOCR over Tesseract in auto mode (Tesseract remains the fallback and
  stays selectable). All frames are processed in one batch for speed.
- OCR engine presets now include: auto / llm / tesseract / rapidocr.

## V 0.78 changes

- Fixed faster-whisper model downloads being blocked by security software
  (python outbound denied, WinError 10013): models are now downloaded by the
  app itself via Node fetch from the HuggingFace mirror into the managed tools
  directory and loaded from the local path. Works on China networks and on
  machines that restrict python outbound traffic.
- Verified end-to-end: the tiny model (75 MB) downloaded and a real audio
  segment was transcribed (language detection, progress and SRT output all
  working).

## V 0.79 changes

- Fixed Whisper on disc sources (DVD/Blu-ray): faster-whisper cannot read a
  DVD folder, so disc jobs now probe the title's audio, score the tracks
  (English first, Russian deprioritized — pirate Russian dubs are often poor
  first tracks; then channels/codec/bitrate) and extract the best track to a
  16k mono wav before transcribing. Video files get the same best-track
  selection instead of the container default.
- The produced SRT is renamed to the job's standard `<name>.<lang>.srt` and
  the temporary wav is removed after transcription.

---

# 图形字幕 OCR（V1）

## 范围

- 把蓝光 PGS（`.sup`）与 DVD VobSub 图形字幕识别为文字 SRT。
- 引擎选择：“自动”优先本地 Tesseract，没有时回退大模型视觉识别；V1 两者都可用。
- 本地引擎：Tesseract OCR（完全离线，不传云端；需要把 Tesseract 及语言数据装入托管工具目录或加入 PATH）。
- 云端引擎：大模型视觉识别（需要支持图片的模型，如 gpt-4o / qwen-vl / glm-4v / gemini）。
- 语种自动判断（文字范围分析 + 大模型确认），支持手动指定。
- 原始图形字幕轨始终保留。

## 使用方式

1. 在影音工作台打开「字幕处理」选项卡，点击「图形字幕 OCR 识别」。
2. 设置 OCR 预设（引擎 + 语言）。预设保存在全局，新建 OCR 任务自动生效，
   不需要每次重复选择。
3. 视频文件：勾选文件 → 加入任务队列 → 在队列中点「开始」（与其他字幕模式一致）。
4. DVD / 蓝光：进入光盘目录 → 点「分析」→ 选择标题与流轨 → 确认后进入任务队列 → 点「开始」。
5. 执行期间队列会实时显示当前阶段与所用工具
   （HandBrake 直通 → ffmpeg 解码字幕帧 → Tesseract / 大模型视觉识别 → 生成 SRT）。

「自动」语言在多语言图形字幕时优先选用英文图形字幕轨；没有英文轨时退回第一条带语言标记的字幕轨，
完全没有语言标记时按识别出的内容判断语种。

## API

OCR 作为队列任务执行（与其他字幕模式同一执行器）：

```json
POST /api/jobs
{ "filePath": "...", "subtitleMode": "ocr", "ocrEngine": "auto",
  "ocrLanguage": "auto", "processingMode": "none" }
```

- 任务固化保存 `ocrEngine` / `ocrLanguage`；成功后 `subtitleSource` 为 `ocr`，
  `subtitlePath` 指向生成的 `*.ocr.srt`。
- 光盘任务通过光盘分析创建，携带 `analysisId`、`sourceFingerprint`、
  `selectedTitleId` 与 `outputMode: "subtitle"`。

## 引擎

- `auto`（默认）：本地 Tesseract 优先，大模型兜底。
- `tesseract`（V1）：本地 OCR，完全离线。
- `llm`（V1）：通过已配置的 AI 提供商做视觉识别。
- `subtitleedit`：预留，后续版本支持。
- DVD VobSub 已支持：DVD 目录先经 HandBrake 直通提取字幕轨（按盘+标题缓存），再解码为字幕画面并用同一套引擎识别；每个标题首次约需 10-20 分钟，再次识别直接用缓存。

## 说明

- 视频始终留在本机，只有字幕图片发送到已配置的 AI 提供商。
- 识别质量取决于字幕字体和视觉模型；AI 提供商必须支持图片输入。

## V 0.69 变更

- Tesseract 现在是托管工具：Windows 上可在「设置 → 工具」一键安装（官方安装器静默安装到托管工具目录），
  并自动下载常用语言数据（eng / chi_sim / chi_tra / jpn / kor / rus / deu / fra / spa / …）。
  缺少的语言可单独补装（工具管理或 `POST /api/runtime/tools/tesseract/language/:lang`）。
- OCR 任务改为“先体检、后干活”：在任何光盘扫描或 HandBrake 转码之前，先确认所选引擎及语言数据可用。
  缺少 Tesseract 或缺少语言数据时会在几秒内失败并给出明确提示，而不是转码 10-20 分钟后才失败。

## V 0.70 变更

- DVD 字幕轨的真实语言现在会传入 OCR：“自动”语言遇到纯俄语盘会真正使用 `rus`（Tesseract `-l rus`），
  不再一律退回 `eng`。
- 字幕轨没有语言标记且预设为“自动”时，会取一帧字幕画面采样，用已安装的语言数据逐个尝试，
  按识别结果中的文字体系（西里尔 / 汉字 / 假名 / 谚文 / 阿拉伯 / 拉丁）自动选定语言。
- 任务日志会显示字幕覆盖范围（`解析到 N 条字幕（时间范围 HH:MM:SS → HH:MM:SS）`），
  源盘字幕轨稀疏/不完整时能提前发现。
- DVD OCR 不再在光盘目录旁留下重复的 `VIDEO_TS.ocr.srt`，只保留任务字幕目录中的单个 `*.ocr.srt`。

## V 0.71 变更

- OCR 结果在保存前强制执行完整性校验：程序先测得源轨字幕事件数、覆盖终点与影片时长，
  当行数远低于对白字幕估算下限（`max(分钟数 × 6, 30)`）或覆盖不足 80% 时直接判定失败并报错，
  不再产出“96 分钟影片只有 41 行”这种不可用的 SRT。10 分钟以内的短片跳过校验。
- 识别语言选择器重新设计为可搜索下拉：高度限制在 `min(50vh, 360px)` 内滚动，不会溢出屏幕；
  可直接输入语言名或代码过滤 50 多种语言。
- Tesseract 语言数据改为优先下载高质量 `tessdata_best` 模型（即识别“字典”，可明显减少误识），
  仅当某语言在 best 层缺失时才回退 `tessdata_fast`。

## V 0.72 变更

- 修复 HandBrake 扫描解析：CLI 在 JSON 前会打印版本横幅，导致选轨解析失败并静默回退到第 1 轨、
  语言丢失（这正是误判“俄语字幕”的根源）。现在正确解析，并把所选字幕轨的真实语言用于 OCR。
- 自动选轨顺序改为：中文 → 英文 → 任一带语言标记的轨 → 第一条轨。盘上有中文 VobSub 轨时直接按中文识别，
  无需再翻译。
- 自动判语更稳健：采样首/中/尾最多 3 帧，跳过无法识别文字的空帧，分数相同时优先英文，不再随机选中俄语。
- OCR 完成后，若源语言不是中文，会调用已配置的 LLM，提示词包含光盘/来源名称
  （“这是 OCR 识别的「…」字幕，先纠错再翻译成中文”），分批（每批 50 条）纠错翻译并生成 `<名称>.zhs.srt`。
- OCR 提取缓存键加入字幕轨号，切换字幕轨不会复用其它轨的缓存。

## V 0.73 变更

- OCR 前对字幕画面做预处理：透明底 VobSub/PGS 位图（白字带描边）先 2 倍放大，再转成“黑字白底”灰度图，
  识别率大幅提升（此前 Tesseract 面对大量透明空白画布基本识别失败）。
- 中文轨自动判定简体/繁体：取最多 3 帧采样，同时用 chi_sim 和 chi_tra 识别，
  繁体字形连贯者胜出（这张盘的轨道即繁体中文）。
- 清理 Tesseract 在中文间插入的空格（“旁 述” → “旁述”）。
- OCR 后始终执行已配置的 LLM 环节：中文源做纠错（含繁体转简体），非中文源做纠错并翻译；
  原始识别结果保留在 `*.ocr.srt`，LLM 结果写入 `*.zhs.srt`，提示词均含光盘/来源名称。

## V 0.74 变更

- 双语对照纠错：OCR 源轨非英文时，任务会自动再识别英文字幕轨（走缓存），把英文与中文 OCR 一起交给 LLM，
  以准确的英文为语义基准纠正中文识别错误（人名、专名、错字、漏字）。
- LLM 提示词强化为强制输出简体中文：带明确示例（“我們”→“我们”）并禁止繁体；已用真实 DeepSeek 调用验证
  （如 OCR 的“肉嘉倫”被纠正为“帕瓦罗蒂”）。
- 英文对照轨使用临时 `*.eng.ocr.srt`，读取后自动删除，不遗留多余文件。

## V 0.75 变更

- OCR 已接入“自动”字幕流水线：当源只有图形字幕（PGS/VobSub）时，自动模式会先做 OCR（含双语对照纠错），
  不再直接回退 Whisper；OCR 失败或完整度校验拒绝时才回退语音识别。
- 新增全局开关“图形字幕 OCR 英文对照纠错”（设置 → 字幕）：关闭后跳过额外的英文轨识别以提速，
  保留单轨 OCR + LLM 纠错。
- OCR 流程提取为共享执行器，显式 OCR 任务与自动流水线走同一套逻辑，行为一致。

## V 0.76 变更

- 已有字幕按“内容 + 文件大小”判定（不看后缀名）：目录里已有中文字幕时跳过 OCR 与翻译；
  已有英文字幕时直接复用作双语参照，不再重复识别英文轨；显式 OCR 模式对已存在语言同样跳过并提示。
- 输出三份文件：`*.ocr.srt`（源轨识别原文）、`*.en.srt`（英文轨原生内容，有英文轨时生成）、`*.zhs.srt`（简体中文）。
- 双语参照改为按开始时间对齐（5 秒内最近匹配），不再依赖行号一一对应，条数不一致也不会错位。
- 视频文件的选轨按字幕事件数：自动模式优先“事件数最多的中文轨 → 事件数最多的英文轨 → 带标记最长轨 →
  事件数最多轨”；DVD 保持中文 → 英文 → 带标记 → 首条的语言优先级。
- LLM 背景增加豆瓣校准（尽力而为、不阻塞）：豆瓣中文片名/译名优先采用，并附 TMDb 官方中译；
  提示词明确“维基百科中文仅作参考，可能存在台湾译名差异”。

## V 0.77 变更

- 语音识别切换为 faster-whisper（CTranslate2 + int8，CPU 优化）：比 openai-whisper 快约 4 倍、内存更低；
  模型经 HuggingFace 镜像下载，“large”自动映射 large-v3。
- 新增本地 OCR 引擎 RapidOCR（PP-OCRv4 / ONNX，托管工具，独立 Python 环境）：
  自动模式下中文轨优先用 RapidOCR 替代 Tesseract（Tesseract 仍可手动选、作为兜底）；
  全部字幕帧一次性批量识别，速度可控。
- OCR 引擎预设扩展为：自动 / 大模型 / Tesseract / RapidOCR。

## V 0.78 变更

- 修复 faster-whisper 模型下载被安全软件拦截（python 出网 WinError 10013）的问题：
  模型改为程序自身（Node fetch）从 HuggingFace 镜像下载到托管目录，
  再以本地路径加载；国内网络与限制 python 出网的环境均可正常安装模型。
- 实测：tiny 模型下载 75MB 并完成真实音轨转写（语言检测、进度、SRT 输出全链路正常）。

## V 0.79 变更

- 修复光盘源（DVD/蓝光）的 Whisper：faster-whisper 无法直接读取 DVD 文件夹，
  任务现在先探测标题音轨并评分（英语优先、俄语降权——毛子盘第一轨常是劣质俄语配音；
  再按声道/编码/码率加权），把最佳音轨提取为 16k 单声道 wav 再转写。
  视频文件同样按评分选轨，不再依赖容器默认第一轨。
- 转写产生的 SRT 会改名为任务标准名 `<名称>.<语言>.srt`，临时 wav 转写后自动删除。

