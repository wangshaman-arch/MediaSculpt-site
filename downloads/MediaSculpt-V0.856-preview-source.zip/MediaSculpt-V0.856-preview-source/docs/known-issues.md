# Known Issues and Fix Directions

> **Version:** V 0.856 · 版本：V 0.856
## Current Status (2026-09-18)

The following items are implemented and covered by automated regression tests:

- DVD Remux no longer silently falls back to a physically different VTS when
  the selected logical title cannot be navigated. The selected logical title
  is also the size-validation baseline.
- Disc smart analysis is advisory. It verifies and focuses a candidate, but it
  does not preselect titles, streams, or chapters. The user must make those
  choices explicitly in the preview dialog.
- Graphic-subtitle OCR preserves the original PGS/VobSub track and, in auto
  mode, retries the other installed local OCR engine before reporting failure.
  It does not incorrectly fall through to Whisper merely because OCR failed.
- Poster lookup accepts only identity-bound candidates and now includes the
  public IMDb suggestion feed as an additional no-key source.

The remaining acceptance gap is real-media validation. The current Codex
process cannot access the authorized network sample directory, so multi-PGC
DVD, encrypted DVD, Blu-ray playlist, PGS/VobSub OCR, and chapter/timestamp
preservation still require testing on a machine that can read those samples.
The old sections below are historical failure descriptions and fix direction;
do not treat every item labelled “current problem” as an unverified regression.

## Video compression with skipped subtitles once failed or did not really compress

Current problem:

When the frontend chooses "skip subtitles", it is effectively `subtitleMode = skip`. In the old version the batch-scan API only accepted `directory` and `recursive` and did not receive or save `subtitleMode`, so tasks created by batch scanning could fall back to the default `auto`.

In the backend logic, any `subtitleMode` other than `skip` routes the job into the subtitle-processing branch, which ends after subtitle processing without entering HandBrake compression.

Result: users thought they chose high-quality compression, but the task may only have run the subtitle step without compressing.

Fix direction:

- Add `subtitleMode` and the expected processing mode to the scan API.
- Save the currently selected subtitle mode when batch scanning creates normal-video tasks.
- Split "subtitle processing" and "video processing" into two independent dimensions instead of using one field for both workflows.

## Remux failures

Current problem:

The code still has Docker path-mapping logic such as `/media/downloads` and `/media/output`. Native Windows runtime should not convert Windows paths into Docker paths.

DVD remux also has a temporary concat list path issue. Existing failure logs show ffmpeg cannot open paths like:

```text
file:///H:/.../VIDEO_TS/vx-vob-34.txt
```

This means the problem is not just ffmpeg arguments; the way paths and temporary list files are passed to ffmpeg is unstable.

Fix direction:

- Native Windows mode uses real Windows paths throughout.
- Docker path mapping is only used when Docker mode is enabled.
- DVD remux should not hand the `VIDEO_TS` directory directly to ffmpeg.
- DVD should be analyzed via IFO/title first, then an explicit VOB list generated.
- The concat list should be written to a stable temporary directory using a path form ffmpeg reliably supports on Windows.

## Inconsistent DVD entry points

Current problem:

Batch scanning a DVD may save the `VIDEO_TS` directory as the job input, but VOB concatenation logic only triggers for `.IFO` inputs.

Result: the same DVD creates jobs through different entry points that take different execution paths and fail differently.

Fix direction:

- Unify the DVD job model.
- Every DVD job must have an explicit title, IFO path, and VOB list.
- The same source must not take different processing logic through different entry points.

## Windows 10 LTSC startup issues

Possible causes:

- winget is missing or unavailable.
- PowerShell/TLS/certificate chain is old.
- Dependency install scripts assume environments more common on Windows 11.
- Docker Desktop path leftovers.
- Node, pnpm, PostgreSQL, or external tools are not installed correctly.

Fix direction:

- Drop Docker Desktop as the default run mode.
- Build a native Windows installer.
- Switch the database to SQLite or a built-in lightweight database.
- Do environment checks and tool installation on first launch.
- When tools are missing, the software still starts and disables only the affected features.

## Current code-structure risk

`jobs.ts` simultaneously contains scanning, subtitles, remux, compression, AI, metadata, README, path mapping, and statistics logic, making the file too large.

This means fixing one mode can affect another mode.

Fix direction:

- Split pipelines.
- Split tool adapters.
- Split remux, encode, subtitle, metadata, and AI modules.
- Every job step has its own input, output, status, and error log.

---

## 当前状态（2026-09-18）

以下内容已经实现，并有自动化回归测试覆盖：

- DVD Remux 在所选逻辑标题无法导航时，不再静默回退到其他物理 VTS；体积校验也以所选逻辑标题为基准。
- 光盘智能解析只负责校验和定位，不会自动勾选标题、流轨或章节；用户必须在预览界面明确选择。
- 图形字幕 OCR 会保留原始 PGS/VobSub；自动模式下首选本地 OCR 引擎失败后会尝试另一种已安装的本地引擎，不会因为 OCR 失败错误转入 Whisper。
- 海报只接受带身份校验的候选，并增加了免 Key 的 IMDb 建议源。

目前真正缺少的是实物媒体验收。当前 Codex 进程无法访问已授权的网络样本目录，因此多 PGC DVD、加密 DVD、蓝光播放列表、PGS/VobSub OCR 以及章节/时间戳保留仍需在能读取这些样本的机器上验证。下面的旧章节是历史故障描述和修复方向，不要把所有标为“当前问题”的内容都当作已经复现的回归问题。

# 已知问题与修复方向

## 跳过字幕的视频压缩曾经失败或没有真正压缩

当前问题：

前端选择跳过字幕时，本质是 `subtitleMode = skip`。旧版本里批量扫描接口曾经只接收 `directory` 和 `recursive`，没有接收并保存 `subtitleMode`。因此批量扫描创建出来的任务可能回到默认 `auto`。

后端逻辑中，只要 `subtitleMode` 不是 `skip`，任务会进入字幕处理分支，处理完字幕后直接结束，不进入 HandBrake 压缩。

结果：用户以为选择了高质量压缩，实际任务可能只做字幕步骤，压缩没有执行。

修复方向：

- 扫描接口增加 `subtitleMode` 和期望的处理模式参数
- 批量扫描创建普通视频任务时保存当前选择的字幕模式
- 将“字幕处理”和“视频处理”拆成两个独立维度，不再用一个字段同时表达工作流

## Remux 失败

当前问题：

代码里仍有 Docker 路径映射逻辑，例如 `/media/downloads`、`/media/output`。原生 Windows 运行时不应继续把 Windows 路径转换成 Docker 路径。

DVD remux 还存在临时 concat 列表路径问题。已有失败日志显示 ffmpeg 打不开类似下面的路径：

```text
file:///H:/.../VIDEO_TS/vx-vob-34.txt
```

这说明问题不只是 ffmpeg 参数，而是路径和临时列表文件交给 ffmpeg 的方式不稳定。

修复方向：

- 原生 Windows 模式完全使用真实 Windows 路径
- Docker 路径映射只在 Docker 模式开启时使用
- DVD remux 不应把 `VIDEO_TS` 目录直接交给 ffmpeg
- DVD 应先分析 IFO/title，再生成明确的 VOB 列表
- concat list 应写到稳定临时目录，并使用 ffmpeg 在 Windows 下可靠支持的路径形式

## DVD 入口不一致

当前问题：

批量扫描 DVD 时可能保存 `VIDEO_TS` 目录作为任务输入，但 VOB 拼接逻辑只在 `.IFO` 输入时触发。

结果：同一张 DVD 通过不同入口创建任务，执行路径不同，失败表现也不同。

修复方向：

- 统一 DVD 任务模型
- 每个 DVD 任务必须有明确的 title、IFO 路径、VOB 列表
- 不允许同一种来源在不同入口走不同处理逻辑

## Windows 10 LTSC 启动问题

可能原因：

- winget 不存在或不可用
- PowerShell/TLS/证书链较旧
- 依赖安装脚本使用了 Windows 11 更常见的环境假设
- Docker Desktop 路径残留
- 系统没有正确安装 Node、pnpm、PostgreSQL 或外部工具

修复方向：

- 放弃 Docker Desktop 作为默认运行方式
- 做 Windows 原生安装包
- 将数据库改为 SQLite 或内置轻量数据库
- 首次启动做环境检查和工具安装
- 缺失工具时软件仍可启动，只禁用对应功能

## 当前代码结构风险

`jobs.ts` 同时包含扫描、字幕、remux、压缩、AI、元数据、README、路径映射和统计逻辑，文件过大。

这会导致一个模式修复后影响另一个模式。

修复方向：

- 拆分 pipeline
- 拆分 tool adapters
- 拆分 remux、encode、subtitle、metadata、ai 模块
- 每个任务步骤有独立输入、输出、状态和错误日志

