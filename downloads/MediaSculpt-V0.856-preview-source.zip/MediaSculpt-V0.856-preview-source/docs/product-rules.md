# MediaSculpt Product Rules

> **Version:** V 0.856 · 版本：V 0.856

## Product positioning

MediaSculpt is a local-first suite for media organization, compression, muxing, subtitle localization, and AI enhancement. The goal is not to simply link installed software together, but to let users install this software on a new computer and complete the main processing flows.

Core features must not depend on AI. AI is an enhancement module for improving posters, content identification, subtitle correction, translation, and documentation generation quality.

## Mandatory development quality gates

All bug fixes and feature changes must follow [`development-quality-gates.md`](development-quality-gates.md). In particular, DVD/Blu-ray physical media groups and logical Title/PGC segments must remain separate, physical capacity must not be counted repeatedly, and no change may be reported as fixed without regression tests and real-media verification. A change that fixes one case but breaks an already-fixed case is not complete.

## Version management

Current software version: `V 0.856` (Windows preview release).

V 0.856 carries forward explicit all-stream selection for selected titles and keeps DVD IFO/PGC/Cell navigation authoritative for title identity, physical capacity, duration, chapters, and duplicate detection.

Version rules: development builds use the `V 0.796`, `V 0.797`, ... sequence. When a new version is pushed/released (when the user asks to push), the version increments by one step (`V 0.796` → `V 0.797` → …). **Formal releases start from `V 1.0.XX`**: after reaching the formal release standard, the version enters the `1.0.00` line, and each subsequent release still increments the last digit (`1.0.00` → `1.0.01` → …). The software only displays the version number; delivery notes also give the GitHub branch and commit. V0.856 is a free preview edition with a local 30-day / 20-successful-task limit; source development runs remain unlimited.

## Bilingual rule (mandatory)

**All user-visible UI text must go through the i18n language packs** (`artifacts/video-agent/src/i18n/zh-CN.ts` and `en-US.ts`); hard-coding visible Chinese or English text in components is forbidden. When adding or changing any UI text, you must add both `zh-CN` and `en-US` keys at the same time and keep key naming consistent. Hard-coded text is only allowed in comments (not displayed). Date, time, and number formatting follows the UI language.

## Default orientation

Default priority: collection quality first, then compatibility, size, and speed.

Default video codec: H.264 10-bit.

Reason: H.264 10-bit loses less quality at higher bitrates and compresses significantly faster than H.265 10-bit, making it the better default collection-grade option.

Hardware encoding is not the default. It depends on the GPU and usually has lower quality than software x264/x265; it is suitable as an optional fast mode.

## Compression rules

Blu-ray defaults:

- H.264 10-bit
- RF 22-23
- preset slower, or slow/slower tiers
- Preserve source video color information by default
- Target roughly 5-8 GB for a 90-minute movie, but fixed size is not the only goal

DVD defaults:

- H.264 10-bit
- RF 18-19
- tune grain
- profile high10
- level 3.1
- Preserve source video color information by default

Audio: always keep the original audio track by default.

Subtitles: keep all subtitles by default.

Chapters: keep chapters by default.

Attachments: keep valid attachments such as fonts and posters when possible.

Output container: MKV by default.

## Smart-workflow pipeline (V 0.797+)

- The AI assistant's processing options are an ordered multi-select pipeline:
  ① Remux → ② Subtitles → ③ Compress. The default order is restored every time
  the assistant opens; the user can drag chips to reorder for the current task.
- Remux itself is the lossless final artifact and is kept when selected. When
  Remux is not selected, compression/processing starts directly from the disc.
- Loose video files do not support Remux: the chip is hidden with a
  "not supported" note, and processing is "compress-first + subtitles on demand".
- The assistant panel has no title row and never scrolls horizontally; it wraps
  to fit the window, and has a visible Confirm button at the end.
- The detail page banner is titled "Smart workflow" (not "Professional
  compression chain") and shows the ordered pipeline steps; double-clicking the
  preview window toggles fullscreen.
- V 0.798+: "Quality" is the four real compression presets with source-based
  defaults (DVD → DVD conversion, Blu-ray/ISO → Blu-ray collection, video →
  balanced), shown in the detail drawer and applied to the global compression
  config. "Subtitles" opens the drawer's subtitle strategy section (Auto /
  Force speech / Skip, auto-selected, mouse-editable). The naming (ZH/EN first)
  chips were removed; the prompt is collapsed by default with no Send button;
  the assistant has a poster preview and an Analyze button that sends the source
  info + prompt to the LLM for a basic-info intro.
- V 0.799+: the assistant title defaults to the source folder/file name and
  follows source changes; chips/buttons follow the app's rounded-md filled
  style; clicking the poster preview opens a large dialog.
- V 0.800+: the workbench smart-workflow entry no longer shows the 4-step tab
  strip or a separate "Analyze Source" button; changing the source directory
  auto-analyzes, and the assistant auto-extracts the folder/file name into the
  title and the year in that name into the year field.
- V 0.801+: the job-page assistant title always follows the source folder/file
  name; the preview toolbar shows a plain "Smart workflow" text hint; the Quality
  button greys out without a Compress step and the detail drawer shows only
  pipeline-relevant sections; the separate Subtitles button was removed (the
  pipeline chip is simply "Subtitles").

## Subtitle rules

Text subtitles: auto-detect, organize, and translate.

Graphic subtitles: OCR first; AI can correct and translate; the original PGS/VobSub graphic subtitle is preserved after OCR.

Videos without subtitles: automatically extract the audio track for speech recognition, then generate subtitles.

Subtitle-track completeness is judged by "count ÷ duration": a complete dialogue track is about 10-15 lines/minute; forced/incomplete tracks are about 1.5-2 lines/minute. During extraction, skip forced tracks and choose the complete dialogue track; the threshold is `max(duration minutes × 6, 30)`, falling back to 400 lines when duration is unknown.

Multi-language/multi-track files do not take the first track; ffmpeg's subtitle-track parameter `s:N` is the "subtitle track sequence number", not the container index, and the server must convert it automatically.

**When the video already contains Chinese subtitles** (language tags chi/zho/zh, or content sampling contains CJK without Japanese kana/Korean Hangul), auto mode skips extraction and translation directly and does not enter Whisper.

**LLM translation context**: the prompt must include at least media background inferred from the file name (series name/season/episode/year), and should include a Wikipedia summary and confirmed movie metadata when available; the smart workflow "confirm movie" result should be written back to the job row for translation reuse.

AI translation output:

- Chinese subtitle files
- Bilingual subtitle files

Bilingual subtitle requirement: Chinese on top, foreign language below, with the foreign font size at half the Chinese size. ASS format is preferred because SRT cannot express different font sizes reliably.

Translation failure must not fail video processing. Subtitle translation can be an independent step; on failure the video job is allowed to complete partially.

## Naming rules

File naming rules allow user templating.

Chinese-title derivation from the source folder (V 0.826): when a video file sits inside a folder whose English segment basically matches the file's English name (longest common prefix ≥ 10 chars and ≥ 60% of the shorter side, ignoring case/dots/apostrophes and release tags), the folder's Chinese segment (trailing all-Chinese tokens, e.g. `唐璜.大都会歌剧院`) becomes the video's Chinese title in the assistant — the folder Chinese name wins over the file's own Chinese text when matched.

Confirmed templates (V 0.797+):

```text
Prisoners.of.Terpsichore.1995.DVDrip.H264.10bit.AC3.mkv
Prisoners.of.Terpsichore.1995.DVD.Remux.mkv
```

- Chinese names only appear in the directory name (collection folder); video and
  subtitle file names never contain Chinese characters.
- Remux lossless output: `English.Year.Source.Remux.mkv`
  (`XXX.1995.DVD.Remux.mkv`, `XXX.2007.BluRay.Remux.mkv`; no source tag when unknown).
- Compressed output: `English.Year.[Resolution.][Source.][Codec.]BitDepth.Audio.mkv`,
  no bitrate label. DVD → `XXX.1995.DVDrip.H264.10bit.AC3.mkv` (no resolution);
  Blu-ray → `XXX.2007.1080p.BluRay.10bit.DTS.mkv` (audio named after the best
  audio track, no codec tag); unknown source → `XXX.2010.1080p.H264.10bit.AC3.mkv`
  (no source tag). 8bit is omitted; 10bit+ is labelled.
- Subtitle files follow the pipeline stage base name (`.zhs.srt` / `.en.srt` /
  `.ocr.srt`): after Remux they use the Remux name; after compression the
  compression step generates same-name SRT copies for the compressed file.

Naming can combine movie title, year, source, codec, bit depth, audio format, and other information.

## Input and output directories

The source directory should be selectable, and the last chosen default input directory should be remembered so the user does not need to re-choose every time.

The output directory defaults to the user's video directory, for example:

```text
Videos/MediaSculpt Output/
```

Users can change the default output directory in settings.

Every processing feature that produces files must offer a mouse-selectable "output to the same directory as the source" option, without requiring users to type special paths manually.

Subtitle files are output to the video source directory by default. A different subtitle export directory is only used when the user explicitly chooses one.

## NAS and network paths

NAS paths and Windows network share directories, including UNC paths, must be supported.

Path handling must use the host system's real paths; native Windows runtime must not continue relying on Docker's `/media/downloads` and `/media/output` paths.

Network-mapped directories the user entered or picked must be saved and must survive leaving the UI or restarting the software.

## Mouse-first settings

Common options such as compression presets, encoder, CRF, encoding speed preset, output resolution, and output directory mode should use dropdowns, buttons, or pickers. Except for content that really needs typing, such as paths, API keys, and model names, users should not fill in enum values manually.

## Video preview rules

- Preview uses streaming "transcode-while-playing" fMP4, supporting `?seek=` (arbitrary seeking) and `?sub=` (embedded graphic subtitle burn-in).
- Quality tier: 1280 width, `veryfast`, 2500 kbps (peak 3500k) + 128k audio; keeps startup fast.
- Only one preview transcode process per job at a time: a new request must terminate the old process first to prevent ffmpeg CPU contention during rapid seeking or subtitle switching.
- Transient browser media errors auto-retry up to 2 times with increasing intervals; success recovers immediately. Only after repeated failure show a fallback message with a "retry preview" button and an error code.

## UI interaction

- Opening the desktop software defaults to the media workbench (`/workbench`, default "Smart workflow" tab).
- The directory picker uses a text button "Choose directory…" plus a quick menu: network locations (shared history with the workbench), default input folder, My Computer; the menu must be portal-rendered and not clipped by parent overflow.
- The workbench "Video compression" tab shows 4 compression presets with inline editing (shared with the settings page via the same localStorage), and edits apply to the global config; enums such as resolution use click dropdowns.
- Compression jobs automatically expand the "details" drawer in the job detail page (including compression preset select/edit).
- While preview is playing, the job toolbar keeps only the video title; the "details" drawer and "smart assistant" collapse automatically, the preview window expands, and it restores on pause.
- Top menu bar structure (V 0.826): 文件 (import/export compression presets, exit) / 处理 (open workbench, job queue) / 设置 (directory & output file name settings, compression, subtitles, API & data sources, local tools, smart-workflow logic, LLM prompt templates, system) / 帮助 (version, logs, diagnostics). The language switch lives only in Settings → System → UI language and applies immediately; there is no separate language or Tools menu — the tools section (本地工具) is one of the Settings menu items. The former "AI translation" and "Movie metadata" sections were merged into one Settings section 「API 与数据源」, where every API-key input (8 LLM providers + TMDb/OMDb) is collapsed by default and expands on click (one at a time, green dot = configured). Menu labels reuse the same i18n keys as the settings section titles, so dropdown and page stay in sync. No stale menu item may point to a removed section.
- Job detail "click-what-you-see": clicking a processing chip (compress / chapter preview / subtitles / remux) shows only that section in the drawer and auto-scrolls to it; the compression section always renders real compression parameters (the chapter-preview sample-position controls live only in the chapter-preview section); deselecting a chip returns to stacked display.
- "Export presets" in the File menu exports the compression presets (four built-in archive presets + custom presets); the smart-workflow tuning is exported/imported per section under Settings → 智能工作流逻辑 (logic parameters) and Settings → LLM 提示词模板 (prompts); old combined tuning JSON files still import.
- Smart-workflow tuning (V 0.826+) is fully mouse-operated and split into two Settings sections. 「智能工作流逻辑」: scenario preset cards (standard / size-first / quality-first / documentary-series / Blu-ray collection / fast) fill the logic parameters in one click; numeric parameters are sliders, DVD default mode and DVD compression preset are dropdowns; custom presets can be saved/removed by mouse; the logic parameters are an editable table — every row can be renamed, edited (value/range/unit), restored to its default individually, or deleted (a deleted built-in falls back to its factory default at runtime and can be recovered under "Add parameter → Default parameters"); new custom parameters can be added by mouse; built-in English keys are hidden by default (shown in each row's Advanced panel). 「LLM 提示词模板」: the five prompt editors each have a usage hint, per-prompt restore, and a collapsible glossary explaining the English output markers (TITLE_EN / TITLE_ZH / YEAR / POSTER_URL / matchReason / confidence / technicalAssessment / recommendedAction…). Both sections share one config, support restore-all/save/export/import, and the shared tuning state lives in the Settings page so unsaved edits survive switching sections. The DVD default mode and DVD compression preset are read from the tuning config by the smart workflow (no longer hard-coded). The whole parameter table is injected into the movie analysis / identity-confirmation LLM prompts automatically, and any prompt template can reference a parameter with `{{logic.<key>}}` placeholders (resolved at runtime). Old fixed-field configs migrate automatically.

## Window behavior and language

The Windows desktop window must be draggable with the mouse; the top menu and button area must not block window dragging.

Language switching must cover the main UI, menus, scan/process entries, and common output options at minimum. Switching to English must not leave the main UI largely in Chinese with only menus translated.

Settings and preview adaptation (V 0.826): the sticky save bar must never cover the last card — the settings page reserves bottom padding (pb-24). While the preview is playing the stage adapts to the video aspect ratio and centers within the available frame (no conflicting max-height cap), so the oversized bottom black band disappears; the subtitle/info scroll areas keep mouse scrolling but hide the visible scrollbar (`scrollbar-none`).

AI extras and posters (V 0.826): readme / poster / review generation all default to OFF (opt-in per task — the features are still maturing; users explicitly check them in the assistant), and readme/review run on the common finalize path for all job types including subtitle-only tasks. Posters are real images only — the lookup cascade tries the confirmed URL, TMDb/OMDb (when keyed), Douban subject_suggest, English/Chinese Wikipedia page images, iTunes, then an LLM-provided public poster URL; the video-frame screenshot fallback was removed, and if every source fails the poster is skipped with a log entry instead of fabricating one.

Title cleaning and analysis correction (V 0.832): the English/foreign title extraction (assistant panel, readme, metadata) strips brackets `[](){}`, then splits on dots/spaces/underscores and truncates at the first release marker (year / resolution / codec / audio / source tag such as AMZN / episode marker) — anything after it (release groups like `Silence` or `Kinosvalka&rutracker`) is dropped; `Panic Room (2002) (1080p AMZN WEB-DL x265 Silence)` → `Panic.Room`. The analysis chain makes LLM title correction mandatory with a fallback chain: structured `TITLE_EN` → database canonical name → cleaned source name; `TITLE_EN` must always be output and never echo the raw file name.

Readme and overview consistency (V 0.832): the assistant's overview preview is persisted to the job (`movieOverview`) — the workflow carries it at job creation and the job page saves it after analysis — so the readme Synopsis uses exactly the same text. Readme generation writes `readme.txt` + `readme.html`; the HTML card embeds the poster image on the left.

MediaInfo folder and poster files (V 0.832): readme.txt / readme.html / poster.jpg / folder.jpg are all written into a `MediaInfo` subfolder (capitalized first letter) of the media directory; `folder.jpg` is a 400px-wide thumbnail of the same poster (legacy byte-identical duplicates are auto-converted); poster discovery checks `MediaInfo` first and falls back to legacy root files. Subtitle sidecars and compressed/Remux outputs stay in their original locations.

Security (V 0.826): API and web services bind to 127.0.0.1 only (no LAN exposure); CORS is restricted to the local frontend origin (http://127.0.0.1:24403 / localhost:24403), so no external web page can call the API. API keys are never returned to the frontend — GET /api/config masks configured keys as `__set__`; the settings page never prefills them and an empty input means "keep the current key" (the backend ignores empty key fields on save). Keys are encrypted at rest with Windows DPAPI (CurrentUser scope, `dpapi:` prefix in the SQLite config) with automatic migration of legacy plaintext values, and a process-level cache avoids per-request PowerShell calls. Keys never appear in logs. Non-Windows platforms currently store keys as-is (Keychain integration planned for macOS).

## Preview playback and seeking (V 0.836)

- Preview is cached as fixed 5-second segments. When the user seeks or drags to a new segment, the previous segment's generation must yield to the newest target; the newest target starts only after the old process has exited, so several FFmpeg processes never compete for the same preview session.
- H.264 sources without subtitles use video stream copy with audio transcoded to AAC, which shortens first-frame and segment-switch waits; subtitle burn-in, HEVC, MPEG-2 and similar cases keep using controlled re-encoding.
- During continuous playback, prefetch of the next segment starts 20% into the current segment to reduce pauses at segment boundaries.

## Disc analysis and Remux (V 0.832, finalized in this session)

> The following are the **product requirements/principles** confirmed in this session; the implementation follows them.

### 1) Results first; the software itself is the foundation (highest priority)
- The software's own deterministic analysis must **correctly analyze the vast majority of discs**; AI (LLM) is only an **upgrade/suggestion**, must **never replace** the software's own analysis capability, and must not "act on its own".
- Under no circumstances may a job error out, fail, or abort merely because "tool results differ" or "AI was not involved"; the goal is always **a correct, lossless remux**.

### 2) Tool disagreements → real disc data is the source of truth
- It is **not unusual** for HandBrake and ffprobe dvdvideo to report different stream layouts for the same title (audio/subtitle counts often differ). **Do not** treat this as an error or fail the job.
- Real parameters are always determined from the **actual files/streams on the disc** (ffprobe dvdvideo + IFO/VOB); user/tool stream selections are **remapped by type and ordinal to the real stream indices** (reconciled, not rejected).

### 3) Layered analysis architecture (offline default → smart → manual)
- **Basic deterministic analysis**: handles most discs, returns within seconds, no LLM needed.
- **Difficult/special disc detection**: ambiguous main feature, no main title, mapping disagreements/validation failures, multiple audio languages, forced subtitles, etc.
- **Smart analysis (entry button)**: push the disc's **real structure** to the LLM → produce a remux title/stream-routing plan → **validate against the real stream set** (keep only streams that actually exist) → apply when it matches the selected title; progress (text/icon) may be shown during analysis.
- **Manual confirmation**: appears only when the LLM plan **fails real-stream validation** (showing candidates + real streams + failure reason) — a last resort, not the default flow.
- Any LLM failure/invalid result/title mismatch → **fall back to deterministic analysis**; never fail, and never silently switch the user's selected title.

### 4) No background pre-mux verification during "smart analysis"
- Smart analysis performs **pure data validation** only (real streams, duration) and **must not** pre-mux a remux in the background to "verify the AI's judgement". "Check after output" happens naturally when the job finishes.

### 5) AI capability gate and greying out
- Every operation that needs an LLM (smart analysis, assistant analysis/generation, etc.) is **greyed out and disabled** with a "requires API key" hint when **no API key is configured**.
- Key present but **LLM unreachable**: do not hard-disable automatically based on probe results (avoid false negatives); on click, **fall back gracefully and explain why**; connectivity is checked on the **Settings page via "Test connection + status light"** (reusing `/api/runtime/ai/test`).

### 6) Remux output validation (short titles must not be rejected)
- Size validation must **take duration into account**: fail only when "the output is clearly too small" **and** "the duration also clearly deviates from the selected title (>15%)".
- Short titles/extras (e.g. a 17-minute featurette) "look too small" relative to the whole disc, but their duration matches the selected title and the remux is correct → **must pass**.

### 7) Bilingual subtitle track selection
- The foreign-language subtitle track is chosen by **line count**; when the English line count is within **10%** of the "fullest track", **English is preferred**.
- Prefer **highly complete** tracks that **cover the ending (≥80%)**; incomplete tracks that only cover the beginning (e.g. 39%) are **dropped automatically**; fall back to the original logic when no complete track exists.
- The bilingual `.ass` must **share the base name of the remux/compressed output**; font size **does not scale with the video aspect ratio** (fixed height ratio).

### 8) Desktop window and player interaction
- Title-bar caption buttons (minimize / maximize-restore / close): the frontend calls **custom window commands** (`minimize_window` / `toggle_maximize_window` / `close_window` / `is_window_maximized`), and the dev origins (`localhost:5173` / `127.0.0.1:5173`) are added to the capabilities `remote.urls` (otherwise the buttons do nothing in dev mode).
- Video preview: **ESC = pause**, **Left/Right arrow = rewind/forward 10 seconds**; **the progress marker follows the actual playback position** (time updates at 0.2 s granularity to avoid whole-second lag/jumps).
- Assistant bar: the four rightmost buttons **hug the right edge**; the "smart generation + job processing" bar **hugs the right edge** (adjacent to those buttons); the left info bar is **as wide as possible** (its inputs fill the width).

### 9) IMDb ID input and uniqueness
- An **IMDb ID input** (starting with `tt`) sits to the right of "Source" in the assistant bar.
- It **feeds the identification chain**: the analysis request carries `imdbId`, and the backend **pins the local IMDb dataset record by `tconst`** as the authoritative identity (better than fuzzy search; it distinguishes same-name titles from different years).

### 10) Versioning and sync
- After a change is complete and verified: **repackage** (`tauri build` produces the matching `MediaSculpt_x64-setup.exe`) and **commit and push to the remote** (`https://github.com/wangshaman-arch/MediaSculpt.git`).

---

# MediaSculpt 产品规则

## 产品定位

MediaSculpt 是一套本地优先的影音整理、压缩、封装、字幕本地化和 AI 增强软件。目标不是把已安装的软件简单链接在一起，而是让用户在一台新电脑上安装本软件后，就能完成主要处理流程。

核心功能应当不依赖 AI。AI 是增强模块，用于提高封面、内容识别、字幕纠错、翻译和说明文档生成质量。

## 版本管理

当前软件版本：`V 0.856`（Windows 预览发布版）。

V 0.856 延续已选标题的流轨全选/清空控制，并保持 DVD IFO/PGC/Cell 导航对标题身份、物理容量、时长、章节和重复判断的权威性。

版本规则：软件采用 `V 0.796`、`V 0.797`、… 的开发版号。发布新版本（用户要求推送）时，版本号步进 +1（`V 0.796` → `V 0.797` → …）。**正式版从 `V 1.0.XX` 开始**：达到正式发布标准后进入 `1.0.00` 线，此后每次发布仍是末位 +1（`1.0.00` → `1.0.01` → …）。软件内只显示版本号；交付说明同时给出 GitHub 分支和提交号。

## 双语规则（强制）

**所有界面可见文案必须走 i18n 语言包**（`artifacts/video-agent/src/i18n/zh-CN.ts` 与 `en-US.ts`），禁止在组件中硬编码可见的中文或英文文本；新增或修改任何界面文字时，必须**同时**添加 `zh-CN` 与 `en-US` 两个 key，并保持 key 命名一致。硬编码文本只允许出现在注释中（不显示）。日期时间、数字格式随界面语言切换。

## 默认取向

默认优先级：收藏质量优先，其次是兼容性、体积和速度。

默认视频编码：H.264 10bit。

原因：H.264 10bit 在较高码率下画质损失小，压缩速度明显快于 H.265 10bit，更适合作为默认收藏级方案。

硬件编码不作为默认方案。硬件编码依赖显卡，画质通常不如软件 x264/x265，适合作为可选快速模式。

## 压缩规则

蓝光默认：

- H.264 10bit
- RF 22-23
- preset slower 或 slow/slower 档位
- 默认保留源视频色彩信息
- 90 分钟影片目标体积大约 5-8GB，但不以固定体积作为唯一目标

DVD 默认：

- H.264 10bit
- RF 18-19
- tune grain
- profile high10
- level 3.1
- 默认保留源视频色彩信息

音轨：默认永远保留原音轨。

字幕：默认保留全部字幕。

章节：默认保留章节。

附件：尽量保留字体、封面等有效附件。

输出容器：默认 MKV。

## 智能工作流流水线（V 0.797+）

- AI 助手的处理选项是一条可多选的有序流水线：① Remux → ② 字幕 → ③ 压缩。
  每次打开助手都恢复默认顺序；可拖动 chips 调整当前任务的执行顺序。
- Remux 本身就是无损版最终产物，勾选即保留；未勾选 Remux 时，直接从原盘开始压缩或处理。
- 单个视频文件不支持 Remux：隐藏该 chip 并标注“不支持”，按“压缩为主 + 按需字幕”处理。
- 助手面板去掉标题行、禁止横向滚动（自适应换行），末尾始终有「确认」按钮。
- 详情页横幅标题统一为“智能工作流”（不再显示“专业压缩链路”），并展示流水线步骤；
  双击视频预览窗口可进入/退出全屏。
- V 0.798+：“画质”就是四个真实压缩预设，按来源默认预选（DVD→DVD转制、蓝光/ISO→蓝光收藏、
  视频→综合均衡），在详情抽屉中显示并写入全局压缩配置；“字幕”打开详情中的字幕策略区
  （自动/强制语音/跳过，自动预选、鼠标可改）。已删除“中文/英文优先”命名选项；
  提示词默认收起、无发送按钮；助手条新增海报预览与“分析”按钮（源信息＋提示词 → LLM 简介）。
- V 0.799+：助手片名默认取源文件/文件夹名并随源同步；按钮统一为应用风格
  （圆角矩形、实底填充）；点击海报预览可放大查看。
- V 0.800+：工作台智能工作流入口去掉四步选项卡与“分析来源”按钮；修改来源目录后自动分析；
  助手自动把源文件/文件夹名填入片名，并把名字中的年份提取到年代栏。
- V 0.801+：任务页助手片名始终跟随源文件/文件夹名；预览工具栏只显示“智能工作流”文字提示；
  画质按钮在未选压缩时置灰，右侧详情只显示与流水线相关的区块；删除独立“字幕”按钮
  （流水线 chip 改名为“字幕”，功能不变）。

## 字幕规则

文本字幕：自动识别、整理、翻译。

图形字幕：先 OCR，AI 可用于纠错和翻译；OCR 后仍保留原 PGS/VobSub 图形字幕。蓝光 PGS 直接提取；DVD VobSub 经 HandBrake 直通提取（按盘+标题缓存，首次约 10-20 分钟），再解码为字幕画面识别。

无字幕视频：自动提取音轨做语音识别，再生成字幕。

字幕轨完整性按“条数 ÷ 时长”判断：完整对白轨约 10-15 条/分钟，强制/残缺轨约 1.5-2 条/分钟。提取时跳过强制轨，选择完整对白轨；阈值 = max(时长分钟 × 6, 30)，时长未知回退 400 条。

多语言/多轨文件不取第一条轨；ffmpeg 字幕轨参数 `s:N` 是“字幕轨序号”而非容器索引，服务端必须自动换算。

**视频已包含中文字幕时**（语言标签 chi/zho/zh，或内容采样含 CJK 且无日文假名/韩文谚文），auto 模式直接跳过提取与翻译，不进入 Whisper。

**LLM 翻译背景**：提示词至少包含文件名推导的媒体背景（系列名/季集/年份），并尽量加入 Wikipedia 摘要与已确认的影片元数据；智能工作流“确认影片”结果应回写任务行供翻译复用。

AI 翻译输出：

- 中文字幕文件
- 双语字幕文件

双语字幕要求：中文在上，外语在下，外语字号为中文的一半。优先使用 ASS 格式，因为 SRT 无法稳定表达不同字号。

双语输出恒为「中文 + 外文」一对：双语任务内部的翻译/OCR 目标固定为简体中文（zh-CN），不受「输出语言」设置影响，因此永远不可能退化成两份相同语言；「输出语言」只作用于单语翻译。双语设置卡中已注明此规则。

翻译失败不应导致视频处理失败。字幕翻译可作为独立步骤，失败后允许视频任务部分完成。

## 命名规则

文件命名规则允许用户模板化。

来源目录推导中文片名（V 0.826）：当视频文件所在目录的英文段与文件英文名基本一致时（最长公共前缀 ≥ 10 个字符且 ≥ 较短一侧的 60%，忽略大小写、点号、撇号与发布标签），目录末尾的纯中文段（如 `唐璜.大都会歌剧院`）即该视频的中文片名——匹配成功时目录中文名优先于文件名自带的中文。

已确认的命名模板（V 0.797+）：

```text
Prisoners.of.Terpsichore.1995.DVDrip.H264.10bit.AC3.mkv
Prisoners.of.Terpsichore.1995.DVD.Remux.mkv
```

- 中文名只出现在目录名（收藏文件夹）上；视频与字幕文件名一律不含中文。
- Remux 无损版：`英文名.年份.来源.Remux.mkv`
  （`XXX.1995.DVD.Remux.mkv`、`XXX.2007.BluRay.Remux.mkv`；来源未知省略标签）。
- 压缩版：`英文名.年份.[分辨率.][来源.][编码.]位深.音频格式.mkv`，不加码率。
  DVD → `XXX.1995.DVDrip.H264.10bit.AC3.mkv`（不写分辨率）；蓝光 →
  `XXX.2007.1080p.BluRay.10bit.DTS.mkv`（音频按最佳音轨命名，不写编码）；
  未知来源 → `XXX.2010.1080p.H264.10bit.AC3.mkv`（无来源标签）。8bit 省略，10bit 及以上标注。
- 字幕文件跟随流水线所在阶段的基准名（`.zhs.srt` / `.en.srt` / `.ocr.srt`）：
  Remux 之后按 Remux 名；压缩步骤完成后自动为压缩版生成同名字幕。

命名可结合影片名、年份、来源、编码、位深、音频格式等信息。

## 输入与输出目录

来源目录应可选择，并记住用户上次选择的默认输入目录，不需要每次都重新选择。

输出目录默认放在用户视频目录下，例如：

```text
Videos/MediaSculpt Output/
```

用户可以在设置中修改默认输出目录。

所有会产生文件的处理功能都必须提供“输出到与源文件同目录”的鼠标选择项，不要求用户手动填写特殊路径。

字幕文件默认自动输出到视频源文件同目录。只有用户明确选择其他字幕导出目录时，才改用指定目录。

## NAS 与网络路径

需要支持 NAS 路径和 Windows 网络共享目录，包括 UNC 路径。

路径处理必须以宿主系统真实路径为准，不应在原生 Windows 运行时继续依赖 Docker 的 `/media/downloads`、`/media/output` 路径。

用户输入或点选过的网络映射目录必须保存下来，退出界面或重启软件后不能丢失。

## 鼠标优先的设置方式

压缩预设、编码器、CRF、编码速度预设、输出分辨率、输出目录模式等常用选项应优先使用下拉框、按钮或选择器完成。除路径、API Key、模型名等确实需要输入的内容外，不应让用户手动填写枚举值。

## 视频预览规则

- 预览采用“边转码边播放”的流式 fMP4，支持 `?seek=`（任意定位）与 `?sub=`（内置图形字幕烧录）。
- 画质档位：1280 宽、`veryfast`、2500kbps（峰值 3500k）+ 128k 音频；保持快速起播。
- 同一任务同一时刻只允许一个预览转码进程：新请求必须先终止旧进程，防止快速 seek/切字幕时 ffmpeg 争抢 CPU。
- 浏览器端瞬时媒体错误自动重试最多 2 次（间隔递增），成功即恢复；仍失败才显示兜底提示，并提供“重试预览”按钮与错误码。

## 界面交互

- 桌面版打开软件默认进入影音工作台（`/workbench`，默认“智能工作流”选项卡）。
- 目录选择器使用带文字的“选择目录…”按钮 + 快捷菜单：网络位置（与工作台共用历史）、默认输入文件夹、我的电脑；菜单需 portal 渲染，不受父级 overflow 裁剪。
- 影音工作台“视频压缩”选项卡下显示 4 个压缩预设，可内联编辑（与设置页同一份 localStorage，互通），编辑后应用到全局配置；分辨率等枚举用点选下拉。
- 压缩类任务进入任务详情页自动展开“详情”抽屉（含压缩预设选择/编辑）。
- 预览播放时：任务工具栏只保留视频标题；“详情”抽屉与“智能助手”自动收起，预览窗口自动扩大，暂停后恢复。
- 顶部菜单栏结构（V 0.826）：文件（导入/导出压缩预设、退出）/ 处理（打开影音工作台、任务队列）/ 设置（目录与输出文件名设置、压缩参数、Whisper 与字幕、API 与数据源、本地工具、智能工作流逻辑、LLM 提示词模板、系统）/ 帮助（版本、日志、诊断信息）。语言切换只保留在 设置→系统→界面语言，选择后立即生效；菜单栏不再单设“语言”和“工具”菜单，“本地工具”作为设置菜单的一项。原“AI 翻译”与“影片信息”已合并为设置分区「API 与数据源」：8 个大模型与 TMDb/OMDb 的 API Key 输入全部默认收起，点击哪个展开哪个（同一时间一个，绿点=已配置）。菜单项复用设置分区标题的同一 i18n key，下拉与界面天然同步；任何失效菜单项必须删除。
- 任务详情“点击什么显示什么”：点处理芯片（压缩/章节预览/字幕/Remux）只显示对应区块并自动滚动；压缩区永远显示真实压缩参数（章节预览采样位置控件只在章节预览区块）；取消选择恢复堆叠显示。
- 文件菜单的“导出预设”导出的是压缩预设（四个内置 + 自定义）；智能工作流调优按分区导出/导入：设置→智能工作流逻辑（逻辑参数）、设置→LLM 提示词模板（提示词），旧版整份调优 JSON 仍可导入。
- 智能工作流调优（V 0.826+）完全鼠标操作，并拆成两个设置分区。「智能工作流逻辑」：场景预设卡（标准收藏/轻量优先/画质优先/纪录片剧集/蓝光收藏/极速处理）一键填入逻辑参数；数值参数用滑条，DVD 默认处理与 DVD 压缩预设用下拉；支持鼠标另存/删除自定义预设；逻辑参数为可编辑参数表——每行可改名、编辑（数值/范围/单位）、逐项恢复默认、删除（内置参数删除后运行时按出厂默认值运行，可在“添加参数 → 默认参数”中找回），可鼠标新增自定义参数；内置参数英文 key 默认隐藏（显示在每行的“高级”里）。「LLM 提示词模板」：五个提示词编辑器各带用途说明与逐项恢复默认，并提供可折叠的“这些英文标记是什么意思”释义表（TITLE_EN / TITLE_ZH / YEAR / POSTER_URL / matchReason / confidence / technicalAssessment / recommendedAction 等）。两个分区共用同一份配置，均支持整组恢复默认、保存、导出/导入；调优状态提升到设置页共享，切换分区不丢失未保存修改。DVD 默认处理与压缩预设由智能工作流读取调优配置（不再写死）。整张参数表自动注入影片分析/资料确认的 LLM 提示，任何提示词模板可用 `{{logic.<标识>}}` 占位符引用参数（运行时替换）。旧版固定字段配置自动迁移。

## 窗口行为与语言

Windows 桌面版窗口必须能用鼠标拖动；顶部菜单和按钮区域不得阻挡窗口拖动。

语言切换至少覆盖主界面、菜单、扫描/处理入口和常用输出选项。切换为英文时，不能只翻译菜单而让主体界面仍大面积显示中文。

设置与预览适配（V 0.826）：sticky 保存条不得遮挡最后一张卡——设置页内容底部预留留白（pb-24）；预览播放中舞台按视频宽高比自适应并居中（移除冲突的 max-height 上限），消除过宽的下部黑边；字幕/信息可滚动区域保留鼠标滚动但隐藏可见滚动条（scrollbar-none）。

AI 生成与海报（V 0.826）：readme / 海报 / 影评三项**全部默认关闭**（按任务显式勾选才生成，功能仍在完善中），且 readme/影评在所有任务类型（含纯字幕任务）的通用收尾路径生成。海报只使用真实图片：依次尝试已确认 URL、TMDb/OMDb（有 key 时）、豆瓣 subject_suggest、维基英文/中文页图、iTunes，最后让 LLM 提供公开海报 URL；已删除视频帧截图兜底，全部来源失败时跳过并记录日志，绝不伪造海报。

片名清洗与分析修正（V 0.832）：英文/外文片名提取（智能助手、readme、元数据）先剥离 `[](){}` 括号，再按点/空格/下划线切分，并在遇到第一个发布标记（年份/分辨率/编码/音轨/来源标记如 AMZN/季集号）时截断——标记之后的内容（如发布组 `Silence`、`Kinosvalka&rutracker`）一律丢弃；`Panic Room (2002) (1080p AMZN WEB-DL x265 Silence)` → `Panic.Room`。分析链路的 LLM 片名修正改为强制输出并带兜底链：结构化 `TITLE_EN` → 资料库规范名 → 源名清洗结果；`TITLE_EN` 必须输出，禁止照抄原始文件名。

readme 与概要预览一致（V 0.832）：智能助手“概要预览”正文持久化为任务 `movieOverview`（工作流创建任务时带入、任务详情页分析后自动保存），readme 的 Synopsis 与概要预览使用同一段文字。readme 生成 `readme.txt` + `readme.html`，HTML 卡片左侧嵌入海报图。

MediaInfo 资料目录与海报文件（V 0.832）：readme.txt / readme.html / poster.jpg / folder.jpg 统一写入媒体目录下首字母大写的 `MediaInfo` 子目录；`folder.jpg` 为同一海报的 400px 宽缩略图（历史字节完全重复的文件自动转换）；海报发现优先读取 `MediaInfo`，找不到再回退根目录旧文件。字幕旁挂文件与压缩/Remux 输出保持原位。

安全（V 0.826）：API 与 Web 只监听 127.0.0.1（不暴露到局域网）；CORS 仅允许本地前端来源（http://127.0.0.1:24403 / localhost:24403），外部网页无法调用本机 API。API Key 绝不返回给前端——GET /api/config 对已配置的 Key 返回掩码 `__set__`；设置页不预填真实值，输入留空表示“保持不变”（后端保存时空值忽略）。Key 落库用 Windows DPAPI（CurrentUser 作用域，SQLite 中以 `dpapi:` 前缀存储）加密，旧明文自动迁移，进程级缓存避免每次请求调用 PowerShell；Key 不进日志。非 Windows 平台暂以原样存储（macOS 后续接入 Keychain）。

## 预览播放与快进（V 0.836）

- 预览以固定 5 秒片段缓存，用户快进或拖动到新片段时，旧片段生成任务必须让位给最新目标；旧进程退出后再启动最新目标，避免多个 FFmpeg 进程竞争同一预览会话。
- 无字幕 H.264 源使用视频流拷贝并将音频转为 AAC，以降低首帧和切段等待；字幕烧录、HEVC、MPEG-2 等场景继续使用受控重编码。
- 连续播放在片段前 20% 触发下一段预取，减少片段边界停顿。

## 光碟解析与 Remux（V 0.832，本次定稿）

> 下列为本次会话确认的**产品要求/原则**，实现以此为准。

### 1) 结果导向，软件自身是地基（最高优先）
- 软件自身的确定性解析应能**正确解析绝大多数光碟**；AI（LLM）只是**升级/建议**，**不得取代**软件自身解析能力，更不得“乱作为”。
- 任何情况下都不得仅因“工具检测结果不同”或“AI 未参与”而报错、失败或中断，目标始终是**能产出正确、无损的 remux**。

### 2) 工具差异 → 以真实光盘数据为准
- HandBrake 与 ffprobe dvdvideo 对同一标题报出不同流结构**不稀奇**（音轨/字幕数量常不一致）。**不要**因此报错或任务失败。
- 判定与定义真实参数一律以**光盘内真实文件/真实流**（ffprobe dvdvideo + IFO/VOB）为准；用户/工具的流选择要**按类型与序数重映射到真实流索引**（归并，而非报错）。

### 3) 分层解析架构（离线默认→智能→人工）
- **基础确定性解析**：处理大多数光碟，秒出，无需 LLM。
- **困难/特殊光碟判定**：主影片不唯一、无主标题、映射分歧/验证失败、多音轨语言、强制字幕等。
- **智能解析（入口按钮）**：把光碟**真实结构**推给 LLM → 生成 remux 标题/流向方案 → **用真实流集合校验**（只保留真实存在流）→ 命中同标题时应用；可在解析过程显示进度（文字/图标）。
- **人工确认**：仅当 LLM 方案**未通过真实流校验/验证**时才出现（展示候选 + 真实流 + 失败原因）——作为最后兜底，不是默认流程。
- 任何 LLM 失败/无效/标题不符 → **回退确定性解析**，绝不失败、绝不静默切换用户所选标题。

### 4) 不在“智能解析”阶段做后台预封装验证
- 智能解析只做**纯数据校验**（真实流、时长），**不得**在后台预封装 remux 去“验证 AI 判断”。“输出后再核对”在任务运行结束自然进行。

### 5) AI 能力门槛与置灰
- 凡是需要 LLM 的操作（智能解析、智能助手分析/生成等），在**未配置任何 API Key** 时**置灰禁用**并给出“需 API Key”提示。
- 有 Key 但**连不上 LLM**：不因探测结果自动硬置灰（避免误判），点到时**优雅回退 + 提示原因**；连接性在**设置页“测试连接 + 状态灯”**查看（复用 `/api/runtime/ai/test`）。

### 6) Remux 输出校验（短标题不被误杀）
- 大小校验必须**结合时长**：只有当“输出明显过小”**且**“时长也明显偏离所选标题（>15%）”才判失败。
- 短标题/花絮（如 17 分钟附片）相对整碟会“显得过小”，但其时长与所选标题一致、是正确 remux → **应通过**。

### 7) 双语字幕轨选择
- 外语字幕轨按**字幕行数**选择；当英语行数在“最满轨”的 **10% 以内**时**优先英语**。
- 优先选**覆盖到尾端（≥80%）的高完整**字幕轨，残缺/只到前段（如 39%）的轨**自动丢弃**；无完整轨时回退原逻辑。
- 双语 `.ass` 必须**与 remux/压缩输出文件同名**；字体尺寸**不随视频宽高比缩放**（固定高度比例）。

### 8) 桌面窗口与播放器交互
- 标题栏三键（最小化 / 最大化/还原 / 关闭）：前端调用**自定义窗口命令**（`minimize_window` / `toggle_maximize_window` / `close_window` / `is_window_maximized`），并让 dev 源（`localhost:5173`/`127.0.0.1:5173`）加入 capabilities `remote.urls`（否则 dev 模式按钮失效）。
- 视频预览：**ESC=暂停**，**左/右方向键 = 快退/快进 10 秒**；**进度块紧跟实际播放位置**（时间更新用 0.2s 粒度，避免整秒滞后/跳格）。
- 智能助手栏：最右 4 个按钮**贴合右侧**；“智能生成 + 任务处理”栏**贴合右侧**（与右侧按钮相邻）；左侧信息栏**尽可能宽**（内部输入框填满）。

### 9) IMDb 号输入与唯一性
- 助栏“来源”右侧提供 **IMDb 号输入框**（`tt` 开头）。
- 该信息**联动识别链路**：分析请求带 `imdbId`，后端按 `tconst` **精确锁定本地 IMDb 库记录**作为权威身份（优于模糊检索，区分同名异年）。

### 10) 版本与同步
- 改动完成并验证后：**重新封装**（`tauri build` 生成对应版本的 `MediaSculpt_x64-setup.exe`）并**提交推送到远端**（远端 `https://github.com/wangshaman-arch/MediaSculpt.git`）。




