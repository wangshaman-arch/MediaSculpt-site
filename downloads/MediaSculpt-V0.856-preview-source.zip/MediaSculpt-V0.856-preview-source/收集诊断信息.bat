@echo off
title MediaSculpt diagnostics
cd /d "%~dp0"
call "%~dp0windows-setup\收集诊断信息.bat"
exit /b %errorlevel%
