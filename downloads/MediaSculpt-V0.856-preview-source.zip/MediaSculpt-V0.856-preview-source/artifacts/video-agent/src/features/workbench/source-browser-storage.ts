export const VX_AGENT_LAST_NETWORK_PATH = "VX_AGENT_LAST_NETWORK_PATH";
export const VX_AGENT_NETWORK_PATHS = "VX_AGENT_NETWORK_PATHS";
export const VX_AGENT_LAST_BROWSE_PATH = "VX_AGENT_LAST_BROWSE_PATH";
const MAX_NETWORK_PATH_HISTORY = 8;

export interface BrowserStorage {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
}

export function browserStorage(): BrowserStorage | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage;
  } catch {
    return null;
  }
}

export function readNetworkPathHistory(storage: BrowserStorage | null): string[] {
  if (!storage) return [];
  try {
    const parsed = JSON.parse(storage.getItem(VX_AGENT_NETWORK_PATHS) || "[]");
    if (Array.isArray(parsed)) {
      return parsed.filter((item): item is string => typeof item === "string" && item.trim().length > 0);
    }
  } catch {
    // Fall through to the legacy single-path value.
  }
  try {
    const legacy = storage.getItem(VX_AGENT_LAST_NETWORK_PATH);
    return legacy ? [legacy] : [];
  } catch {
    return [];
  }
}

export function rememberNetworkPath(storage: BrowserStorage | null, pathValue: string): string[] {
  const trimmed = pathValue.trim();
  if (!trimmed) return readNetworkPathHistory(storage);
  const next = [trimmed, ...readNetworkPathHistory(storage).filter((item) => item !== trimmed)].slice(0, MAX_NETWORK_PATH_HISTORY);
  try {
    storage?.setItem(VX_AGENT_NETWORK_PATHS, JSON.stringify(next));
    storage?.setItem(VX_AGENT_LAST_NETWORK_PATH, trimmed);
  } catch {
    // Browsers can reject storage in private or restricted contexts.
  }
  return next;
}

export function readLastBrowsePath(storage: BrowserStorage | null, fallback: string): string {
  if (!storage) return fallback;
  try {
    const saved = storage.getItem(VX_AGENT_LAST_BROWSE_PATH)?.trim();
    if (!saved) return fallback;
    const savedNorm = saved.replace(/[\\/]+$/, "").toLowerCase();
    const fallbackNorm = fallback.replace(/[\\/]+$/, "").toLowerCase();
    if (savedNorm === fallbackNorm) return saved;
    if (fallbackNorm && (savedNorm.startsWith(`${fallbackNorm}\\`) || savedNorm.startsWith(`${fallbackNorm}/`))) return saved;
  } catch {
    // Use the current selection when storage cannot be read.
  }
  return fallback;
}

export function rememberBrowsePath(storage: BrowserStorage | null, pathValue: string): void {
  if (!pathValue.trim()) return;
  try {
    storage?.setItem(VX_AGENT_LAST_BROWSE_PATH, pathValue);
  } catch {
    // Browsers can reject storage in private or restricted contexts.
  }
}
