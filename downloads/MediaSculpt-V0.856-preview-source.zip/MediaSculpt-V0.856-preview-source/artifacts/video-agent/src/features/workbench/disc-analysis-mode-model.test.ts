import { describe, expect, it } from "vitest";
import { discAnalysisDialogBehavior } from "./disc-analysis-mode-model";

describe("discAnalysisDialogBehavior", () => {
  it("keeps smart-workflow disc analysis independent from a processing mode", () => {
    expect(
      discAnalysisDialogBehavior({
        analysisOnly: true,
        processingMode: "none",
        subtitleMode: "skip",
      }),
    ).toEqual({
      showModePicker: false,
      includeVideoStreams: true,
      verifyDvdTitles: true,
      filterTitlesByProcessingMode: false,
      allowJobCreation: false,
    });
  });

  it("preserves the normal subtitle-only dialog behavior", () => {
    expect(
      discAnalysisDialogBehavior({
        processingMode: "none",
        subtitleMode: "auto",
      }),
    ).toEqual({
      showModePicker: false,
      includeVideoStreams: false,
      verifyDvdTitles: false,
      filterTitlesByProcessingMode: true,
      allowJobCreation: true,
    });
  });
});
