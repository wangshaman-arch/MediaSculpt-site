import { describe, expect, it } from "vitest";
import { DEFAULT_COMPRESSION_PRESETS } from "../../lib/compression-presets";
import { compressionPresetSummary, customPresetSummary } from "./compression-preset-model";

describe("compression preset model", () => {
  it("formats the compact preset summary used by the workbench", () => {
    expect(compressionPresetSummary({ encoder: "x265", crf: 22, outputResolution: "1080p" })).toBe("x265 · CRF 22 · 1080p");
    expect(compressionPresetSummary({ encoder: "x264", crf: 20 })).toBe("x264 · CRF 20 · source");
  });

  it("uses the current compression settings for the custom option", () => {
    expect(customPresetSummary({ encoder: "x264_10bit", crf: "21", outputResolution: "source" })).toBe("x264_10bit · CRF 21 · source");
    expect(customPresetSummary({ encoder: "x265", crf: 0, outputResolution: "source" })).toBe("x265 · CRF 0 · source");
  });

  it("uses translated labels when rendered in the Chinese workbench", () => {
    const t = (key: string, params?: Record<string, string | number>) => ({
      "settings.encoderX265Plain": "H.265 8 位",
      "settings.crfShort": `CRF ${params?.value ?? ""}`,
      "settings.resSourceShort": "原始分辨率",
    }[key] ?? key);

    expect(customPresetSummary({ encoder: "x265", crf: 20, outputResolution: "source" }, t)).toBe("H.265 8 位 · CRF 20 · 原始分辨率");
  });

  it("includes an episodic preset with source resolution", () => {
    const preset = DEFAULT_COMPRESSION_PRESETS.find((item) => item.id === "episodic");
    expect(preset).toMatchObject({
      labelKey: "settings.presetEpisodicLabel",
      descriptionKey: "settings.presetEpisodicDesc",
      icon: "📺",
      values: { encoder: "x265_10bit", crf: 20, outputResolution: "source" },
    });
  });
});
