import { describe, expect, it } from "vitest";
import {
  filterValidSelection,
  selectionMatches,
} from "./disc-selection-reconciliation-model";

describe("disc selection reconciliation", () => {
  it("keeps only stream or chapter ids that the local parser found", () => {
    expect(filterValidSelection([3, 1, 999], [1, 2, 3])).toEqual([1, 3]);
  });

  it("detects whether an AI selection agrees with the local selection", () => {
    expect(selectionMatches([3, 1, 2], [2, 1, 3])).toBe(true);
    expect(selectionMatches([1, 2], [1, 2, 3])).toBe(false);
  });
});
