import type { ReactNode } from "react";
import { Brain, HelpCircle, PackageOpen, Subtitles, Video } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { cn } from "../../lib/utils";
import { WORKBENCH_TABS, type ProcessingMode, type WorkbenchTab } from "../../hooks/useWorkbenchState";
import { modeTechnology } from "./workbench-mode-model";

export type ModeCopy = { label: string; desc: string };

export interface WorkbenchModeTabsProps {
  activeTab: WorkbenchTab;
  title: string;
  description: string;
  workflow: ModeCopy;
  modes: Record<ProcessingMode, ModeCopy>;
  onSelect: (tab: WorkbenchTab) => void;
  hint: ReactNode;
}

function modeIcon(mode: WorkbenchTab): ReactNode {
  if (mode === "workflow") return <Brain className="h-4 w-4" />;
  if (mode === "remux") return <PackageOpen className="h-4 w-4" />;
  if (mode === "none") return <Subtitles className="h-4 w-4" />;
  return <Video className="h-4 w-4" />;
}

function modeClassName(mode: WorkbenchTab, active: boolean): string {
  const accent = mode === "workflow" || mode === "none" ? "amber" : mode === "remux" ? "blue" : "primary";
  if (active) {
    if (accent === "amber") return "border-amber-400 bg-amber-400/10 text-amber-400";
    if (accent === "blue") return "border-blue-500 bg-blue-500/10 text-blue-400";
    return "border-primary bg-primary/10 text-primary";
  }
  if (accent === "amber") return "border-border hover:border-amber-400/50 hover:bg-amber-400/5";
  if (accent === "blue") return "border-border hover:border-blue-500/50 hover:bg-blue-500/5";
  return "border-border hover:border-primary/50 hover:bg-secondary/40";
}

export function WorkbenchModeTabs({ activeTab, title, description, workflow, modes, onSelect, hint }: WorkbenchModeTabsProps) {
  return (
    <Card data-testid="workbench-mode-tabs">
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center gap-2">
          {title}
          {hint}
        </CardTitle>
        <span className="sr-only">{description}</span>
      </CardHeader>
      <CardContent className="px-4 pb-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
          {WORKBENCH_TABS.map((mode) => {
            const isWorkflow = mode === "workflow";
            const copy = isWorkflow ? workflow : modes[mode];
            return (
              <button
                key={mode}
                type="button"
                onClick={() => onSelect(mode)}
                data-testid={`mode-tab-${mode}`}
                className={cn("text-left px-3 py-1.5 rounded-xl border transition-all", modeClassName(mode, activeTab === mode))}
              >
                <div className="font-semibold text-sm flex items-center justify-between gap-2">
                  <span className="flex items-center gap-2">{modeIcon(mode)}{copy.label}</span>
                  <HelpCircle className="h-3.5 w-3.5 opacity-60" />
                </div>
                <div className="text-[11px] text-muted-foreground mt-1 font-mono">{modeTechnology(mode)}</div>
                <span className="sr-only">{copy.desc}</span>
              </button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
