import { memo } from "react";
import type { DiscTrack } from "@workspace/api-client-react";
import { Checkbox } from "../../components/ui/checkbox";
import { useI18n } from "../../i18n";
import { cn } from "../../lib/utils";
import {
  discTrackAvailabilityReason,
  formatDiscBytes,
  formatDiscDuration,
  type DiscTrackWithMakeMkv,
} from "./disc-display-model";

export interface DiscTitleRowProps {
  index: number;
  track: DiscTrackWithMakeMkv;
  isSelected: boolean;
  isActive: boolean;
  isVerifying: boolean;
  discType: "dvd" | "bluray";
  onSelect: (index: number) => void;
  onToggleSelected: (index: number, selected: boolean) => void;
  selectionDisabled?: boolean;
}

export const DiscTitleRow = memo(function DiscTitleRow({
  index,
  track,
  isSelected,
  isActive,
  isVerifying,
  discType,
  onSelect,
  onToggleSelected,
  selectionDisabled = false,
}: DiscTitleRowProps) {
  const { t } = useI18n();
  const unavailableReason = discTrackAvailabilityReason(track);
  const unavailable = unavailableReason !== null;

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => onSelect(index)}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          onSelect(index);
        }
      }}
      className={cn(
        "w-full cursor-pointer text-left px-3 py-2.5 rounded-lg border transition-colors text-sm",
        unavailable && "cursor-not-allowed border-amber-400/40 bg-amber-400/5",
        isActive
          ? "border-primary bg-primary/10 ring-1 ring-primary/30"
          : "border-border hover:border-primary/40 hover:bg-secondary/40",
      )}
    >
      <div className="flex items-center gap-2">
        <Checkbox
          checked={isSelected}
          disabled={unavailable || (selectionDisabled && !isSelected)}
          onPointerDown={(event) => event.stopPropagation()}
          onClick={(event) => event.stopPropagation()}
          onCheckedChange={(checked) =>
            onToggleSelected(index, checked === true)
          }
          className="shrink-0"
        />
        <span className="min-w-0 flex-1 truncate">
          <span className="font-mono font-medium">{track.name}</span>
          {track.titleId && (
            <span className="ml-2 text-[10px] text-muted-foreground">
              {track.titleId}
            </span>
          )}
        </span>
        <span className="text-xs text-muted-foreground shrink-0">
          {track.sizeBytes > 0
            ? formatDiscBytes(track.sizeBytes)
            : t("scan.unknownAfterExport")}
        </span>
        {discType === "dvd" && isVerifying && (
          <span className="text-xs text-primary shrink-0">
            {t("scan.verifyingTitle")}
          </span>
        )}
        <span className="text-xs text-muted-foreground shrink-0">
          {track.durationSeconds
            ? formatDiscDuration(track.durationSeconds)
            : "--"}
        </span>
      </div>
      {unavailableReason && (
        <p className="mt-1 pl-7 text-[11px] text-amber-400">
          不可读取：{unavailableReason}
        </p>
      )}
    </div>
  );
});
