export type BrowserSortField = "name" | "modified";
export type BrowserSortDirection = "asc" | "desc";

export type BrowserEntry = {
  name: string;
  modifiedAt?: string | null;
};

export type BrowserBatchStream = {
  index: number;
  codecType: string;
  codecName: string | null;
  language: string | null;
  channels: number | null;
  width: number | null;
  height: number | null;
  frameRate: string | number | null;
};

export function sortBrowserEntries<T extends BrowserEntry>(list: T[], sortBy: BrowserSortField, sortDir: BrowserSortDirection): T[] {
  return [...list].sort((a, b) => {
    if (sortBy === "name") {
      const result = a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: "base" });
      return sortDir === "asc" ? result : -result;
    }
    const aTime = a.modifiedAt ? Date.parse(a.modifiedAt) : -1;
    const bTime = b.modifiedAt ? Date.parse(b.modifiedAt) : -1;
    if (aTime === -1 && bTime === -1) return 0;
    if (aTime === -1) return 1;
    if (bTime === -1) return -1;
    const result = aTime - bTime;
    return sortDir === "asc" ? result : -result;
  });
}

export function lastPathSegment(value: string): string {
  const parts = value.replace(/[\\/]+$/, "").split(/[\\/]/);
  return parts[parts.length - 1] ?? value;
}

export function isIsoFileName(name: string): boolean {
  return /\.iso$/i.test(name);
}

export function normalizeBatchStreams(raw: unknown): BrowserBatchStream[] {
  const list = Array.isArray(raw) ? raw : [];
  return list
    .map((stream, position) => {
      const source = (stream ?? {}) as Record<string, unknown>;
      const codecType = typeof source.codecType === "string" ? source.codecType : "unknown";
      const index = typeof source.index === "number" ? source.index : position;
      return {
        index,
        codecType,
        codecName: typeof source.codecName === "string" ? source.codecName : null,
        language: typeof source.language === "string" ? source.language : null,
        channels: typeof source.channels === "number" ? source.channels : null,
        width: typeof source.width === "number" ? source.width : null,
        height: typeof source.height === "number" ? source.height : null,
        frameRate: typeof source.frameRate === "string" || typeof source.frameRate === "number" ? source.frameRate : null,
      } satisfies BrowserBatchStream;
    })
    .filter((stream) => stream.codecType === "video" || stream.codecType === "audio" || stream.codecType === "subtitle");
}
