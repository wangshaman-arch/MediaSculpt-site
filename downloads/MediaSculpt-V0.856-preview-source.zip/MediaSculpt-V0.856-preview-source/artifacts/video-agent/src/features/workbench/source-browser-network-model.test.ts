import { describe, expect, it } from "vitest";
import { networkPathExamples } from "./source-browser-network-model";

describe("source browser network model", () => {
  it("keeps usable Windows network examples", () => {
    expect(networkPathExamples()).toEqual(["\\\\NAS\\Movies", "\\\\192.168.1.10\\video"]);
  });
});
