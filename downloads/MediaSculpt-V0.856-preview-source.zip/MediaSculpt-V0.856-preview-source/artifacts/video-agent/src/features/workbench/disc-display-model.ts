import type { DiscStream, DiscTrack } from "@workspace/api-client-react";

export type DiscTrackWithMakeMkv = DiscTrack & {
  titleId?: string;
  titleIndex?: number;
  titleKind?: "m2ts" | "handbrake" | string | null;
  previewSourcePath?: string | null;
  makemkvTitleIndex?: number;
  playlistId?: string | null;
  titleNumber?: number | null;
  handbrakeTitleNumber?: number | null;
  dvdVtsNumber?: number | null;
  physicalVtsNumber?: number | null;
  mappingStatus?: "not-required" | "unmapped";
  verificationStatus?: "pending" | "verified" | "failed";
  verificationFailureReason?: string | null;
  verificationWarnings?: string[];
  availabilityStatus?: "confirmed" | "unavailable";
  availabilityFailureReason?: string | null;
  analyzer?: string;
};

export function discTrackAvailabilityReason(track: {
  availabilityStatus?: string | null;
  availabilityFailureReason?: string | null;
}): string | null {
  if (track.availabilityStatus !== "unavailable") return null;
  return track.availabilityFailureReason?.trim() || "标题源文件不可读取";
}

export type DiscStreamWithHandBrake = DiscStream & {
  channelLayout?: string | null;
  sampleRate?: number | null;
  frameRate?: string | null;
  handbrakeTrackNumber?: number | null;
};

/**
 * Warning codes emitted by the disc analysis API. A code (not a sentence) is
 * sent so the visible text can be resolved through the language packs — the
 * server does not know the UI language.
 *
 * Keep in sync with `BLURAY_ENCRYPTED_WARNING_CODE` in
 * `artifacts/api-server/src/lib/bluray-encryption.ts`; a contract test asserts
 * the two literals match so they cannot drift apart silently.
 */
export const BLURAY_ENCRYPTED_WARNING_CODE = "bluray-aacs-encrypted";

/**
 * Resolve an analysis warning into user-visible text. Known codes are
 * translated; anything else is passed through unchanged so existing
 * analysis notes keep working.
 */
export function warningDisplayText(
  warning: string,
  t: (key: string, params?: Record<string, string>) => string,
): string {
  if (warning === BLURAY_ENCRYPTED_WARNING_CODE || warning.startsWith(`${BLURAY_ENCRYPTED_WARNING_CODE}:`)) {
    const evidence = warning.slice(BLURAY_ENCRYPTED_WARNING_CODE.length + 1);
    const hint = t("scan.blurayEncryptedHint");
    return evidence ? `${hint}（${evidence}）` : hint;
  }
  return warning;
}

export function streamDisplayLabel(streamInput: DiscStream): string {
  const stream = streamInput as DiscStreamWithHandBrake;
  const lang =
    streamInput.language && streamInput.language !== "und"
      ? streamInput.language.toUpperCase()
      : "";
  const title = streamInput.title ? ` · ${streamInput.title}` : "";
  if (streamInput.codecType === "video") {
    const resolution =
      streamInput.width && streamInput.height
        ? ` ${streamInput.width}×${streamInput.height}`
        : "";
    return `${streamInput.codecName.toUpperCase()}${resolution}${title}`;
  }
  if (streamInput.codecType === "audio") {
    const channels = streamInput.channels
      ? ` ${streamInput.channels}ch`
      : stream.channelLayout
        ? ` ${stream.channelLayout}`
        : "";
    const sampleRate = stream.sampleRate
      ? ` · ${Math.round(stream.sampleRate / 1000)}kHz`
      : "";
    const handBrakeNumber = stream.handbrakeTrackNumber
      ? ` · HB#${stream.handbrakeTrackNumber}`
      : "";
    return `${streamInput.codecName.toUpperCase()}${channels}${sampleRate}${lang ? " · " + lang : ""}${handBrakeNumber}${title}`;
  }
  const handBrakeNumber = stream.handbrakeTrackNumber
    ? ` · HB#${stream.handbrakeTrackNumber}`
    : "";
  return `${streamInput.codecName.toUpperCase()}${lang ? " · " + lang : ""}${handBrakeNumber}${title}`;
}

export function streamLanguageDisplay(
  stream: DiscStream,
  t: (key: string) => string,
): string {
  if (!stream.language || stream.language === "und")
    return t("scan.unknownLanguage");
  return stream.language.toUpperCase();
}

function uniqueLabels(
  values: Array<string | null | undefined>,
  fallback: string,
): string {
  const labels = Array.from(
    new Set(
      values.filter((value): value is string => Boolean(value && value.trim())),
    ),
  );
  if (labels.length === 0) return fallback;
  return (
    labels.slice(0, 4).join(" / ") +
    (labels.length > 4 ? ` +${labels.length - 4}` : "")
  );
}

export function trackLanguageDisplay(
  track: DiscTrack,
  codecType: "audio" | "subtitle",
  t: (key: string) => string,
): string {
  const streams = track.streams.filter(
    (stream) => stream.codecType === codecType,
  );
  const fallback =
    codecType === "audio" ? t("scan.noAudioInfo") : t("scan.noSubtitleInfo");
  return uniqueLabels(
    streams.map((stream) => {
      const language = streamLanguageDisplay(stream, t);
      const title = stream.title ? ` ${stream.title}` : "";
      return `${language} ${stream.codecName.toUpperCase()}${title}`.trim();
    }),
    fallback,
  );
}

export function streamTechnicalBadges(streamInput: DiscStream): string[] {
  const stream = streamInput as DiscStreamWithHandBrake;
  const badges = [streamInput.codecName.toUpperCase()];
  if (
    streamInput.codecType === "video" &&
    streamInput.width &&
    streamInput.height
  ) {
    badges.push(`${streamInput.width}×${streamInput.height}`);
  }
  if (streamInput.codecType === "audio") {
    if (streamInput.channels) badges.push(`${streamInput.channels}ch`);
    else if (stream.channelLayout) badges.push(stream.channelLayout);
    if (stream.sampleRate)
      badges.push(`${Math.round(stream.sampleRate / 1000)}kHz`);
  }
  if (stream.handbrakeTrackNumber && streamInput.codecType !== "video")
    badges.push(`HandBrake #${stream.handbrakeTrackNumber}`);
  return badges;
}

export function handBrakeTrackNumbers(
  track: DiscTrack,
  streamSet: Set<number>,
  codecType: "audio" | "subtitle",
): number[] {
  return track.streams
    .filter(
      (stream) => stream.codecType === codecType && streamSet.has(stream.index),
    )
    .map((stream) => (stream as DiscStreamWithHandBrake).handbrakeTrackNumber)
    .filter((value): value is number => typeof value === "number" && value > 0)
    .sort((a, b) => a - b);
}

export function formatDiscBytes(bytes: number): string {
  if (bytes >= 1e9) return (bytes / 1e9).toFixed(1) + " GB";
  if (bytes >= 1e6) return (bytes / 1e6).toFixed(1) + " MB";
  return (bytes / 1e3).toFixed(0) + " KB";
}

export function formatDiscDuration(seconds: number | null | undefined): string {
  if (!seconds) return "";
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainder = Math.floor(seconds % 60);
  return hours > 0
    ? `${hours}:${String(minutes).padStart(2, "0")}:${String(remainder).padStart(2, "0")}`
    : `${minutes}:${String(remainder).padStart(2, "0")}`;
}

export function formatDiscChapterDuration(
  startSeconds: number | null | undefined,
  endSeconds: number | null | undefined,
): string {
  if (
    typeof startSeconds !== "number" ||
    typeof endSeconds !== "number" ||
    endSeconds <= startSeconds
  )
    return "";
  return formatDiscDuration(endSeconds - startSeconds);
}
