export function filterValidSelection(requested: number[] | undefined, available: number[]): number[] {
  const requestedSet = new Set(requested ?? []);
  return available.filter((id) => requestedSet.has(id));
}

export function selectionMatches(left: number[] | undefined, right: number[] | undefined): boolean {
  const a = [...new Set(left ?? [])].sort((x, y) => x - y);
  const b = [...new Set(right ?? [])].sort((x, y) => x - y);
  return a.length === b.length && a.every((id, index) => id === b[index]);
}
