import type { RefObject } from "react";
import { ChevronDown, Network } from "lucide-react";
import { Button } from "../../components/ui/button";
import { DirectoryPicker } from "../../components/DirectoryPicker";
import { Input } from "../../components/ui/input";
import { cn } from "../../lib/utils";
import { networkPathExamples } from "./source-browser-network-model";

export interface SourceBrowserNetworkPanelProps {
  networkPath: string;
  networkPathHistory: string[];
  recentLocationsOpen: boolean;
  networkDetailsOpen: boolean;
  networkPathInputRef: RefObject<HTMLInputElement | null>;
  text: {
    networkLocation: string;
    networkPathPlaceholder: string;
    openNetworkLocation: string;
    chooseNetworkLocation: string;
    directoryPickerPlaceholder: string;
    recentLocations: string;
  };
  onToggleNetworkDetails: () => void;
  onNetworkPathChange: (value: string) => void;
  onOpenNetworkPath: (value?: string) => void;
  onChooseNetworkLocation: () => void;
  onDirectoryPathChange: (value: string) => void;
  onToggleRecentLocations: () => void;
}

export function SourceBrowserNetworkPanel({
  networkPath,
  networkPathHistory,
  recentLocationsOpen,
  networkDetailsOpen,
  networkPathInputRef,
  text,
  onToggleNetworkDetails,
  onNetworkPathChange,
  onOpenNetworkPath,
  onChooseNetworkLocation,
  onDirectoryPathChange,
  onToggleRecentLocations,
}: SourceBrowserNetworkPanelProps) {
  return (
    <>
      <button type="button" className="flex w-full items-center justify-between rounded-lg border bg-secondary/10 px-3 py-2 text-left text-sm text-muted-foreground hover:text-foreground" onClick={onToggleNetworkDetails} aria-expanded={networkDetailsOpen}>
        <span className="flex items-center gap-2"><Network className="h-4 w-4" />{text.networkLocation}</span>
        <ChevronDown className={cn("h-4 w-4 transition-transform", networkDetailsOpen && "rotate-180")} />
      </button>

      {networkDetailsOpen && <div className="rounded-lg border bg-secondary/10 p-3 space-y-2">
        <div className="flex gap-2">
          <Input
            ref={networkPathInputRef}
            value={networkPath}
            onChange={(event) => onNetworkPathChange(event.target.value)}
            onKeyDown={(event) => { if (event.key === "Enter") onOpenNetworkPath(); }}
            placeholder={text.networkPathPlaceholder}
            className="font-mono bg-background/70"
          />
          <Button type="button" variant="outline" onClick={() => onOpenNetworkPath()}>{text.openNetworkLocation}</Button>
          <Button type="button" variant="secondary" onClick={onChooseNetworkLocation}>{text.chooseNetworkLocation}</Button>
        </div>
        <DirectoryPicker value={networkPath} onChange={onDirectoryPathChange} placeholder={text.directoryPickerPlaceholder} className="mt-2" />
        {networkPathHistory.length > 0 && (
          <div className="space-y-1">
            <button type="button" onClick={onToggleRecentLocations} className="flex w-full items-center justify-between gap-2 text-xs font-medium text-muted-foreground hover:text-foreground">
              <span>{text.recentLocations}（{networkPathHistory.length}）</span>
              <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", recentLocationsOpen && "rotate-180")} />
            </button>
            <div className={cn("flex gap-2 overflow-hidden text-xs", recentLocationsOpen ? "flex-wrap" : "flex-nowrap max-h-7")}>
              {networkPathHistory.map((savedPath) => (
                <button key={savedPath} type="button" onClick={() => onOpenNetworkPath(savedPath)} className="max-w-full truncate rounded border px-2 py-1 font-mono text-muted-foreground hover:border-primary/50 hover:text-foreground" title={savedPath}>
                  {savedPath}
                </button>
              ))}
            </div>
          </div>
        )}
        <div className="flex flex-wrap gap-2 text-xs">
          {networkPathExamples().map((example) => (
            <button key={example} type="button" onClick={() => onOpenNetworkPath(example)} className="rounded border px-2 py-1 font-mono text-muted-foreground hover:border-primary/50 hover:text-foreground">
              {example}
            </button>
          ))}
        </div>
      </div>}
    </>
  );
}
