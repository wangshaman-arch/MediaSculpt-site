// Extracted from pages/Scan.tsx: direct path entry for any BD/DVD directory.
import {
  Profiler,
  useState,
  useCallback,
  useEffect,
  useMemo,
  useRef,
} from "react";
import {
  useCreateJob,
  useBrowseDirectory,
  useGetConfig,
  getGetConfigQueryKey,
  useUpdateConfig,
  useAnalyzeDisc,
  useListJobs,
  getListJobsQueryKey,
} from "@workspace/api-client-react";
import type { DiscTrack, DiscStream } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import { ToastAction } from "@/components/ui/toast";
import {
  Loader2,
  Play,
  ArrowLeft,
  SquareCheck,
  Square,
  Disc,
  X,
  Video,
  Music,
  Subtitles,
  HelpCircle,
  ChevronDown,
  ChevronsUpDown,
  Save,
  ScanText,
  Sparkles,
  Layers,
  List,
  Wand2,
  Mic,
  Languages,
  Captions,
  Settings2,
  RotateCcw,
} from "lucide-react";
import { useLocation } from "wouter";
import {
  useToolAvailability,
  toolsRequiredForSubtitle,
} from "@/lib/use-tool-availability";
import { cn, formatDate } from "@/lib/utils";
import {
  ARCHIVE_PRESETS,
  ARCHIVE_PRESET_LS_KEY,
  compressionConfigValues,
  CUSTOM_COMPRESSION_PRESET_ID,
  PRESET_CHANGED_EVENT,
  loadCompressionPresets,
  presetConfigValues,
  type ArchivePreset,
  type CompressionPresetValues,
} from "@/lib/compression-presets";
import { useI18n, useScanCopy } from "@/i18n";
import {
  useWorkbenchState,
  type ProcessingMode,
  type SubtitleMode,
  type WorkbenchTab,
} from "@/hooks/useWorkbenchState";
import { WorkbenchModeTabs } from "./WorkbenchModeTabs";
import { SubtitleModeSelector } from "./SubtitleModeSelector";
import { CompressionPresetPanel } from "./CompressionPresetPanel";
import { DiscTitleRow } from "./DiscTitleRow";
import { WorkbenchSourceEntry } from "./WorkbenchSourceEntry";
import {
  browserStorage,
  readLastBrowsePath,
  readNetworkPathHistory,
  rememberBrowsePath,
  rememberNetworkPath,
} from "./source-browser-storage";
import {
  lastPathSegment,
  normalizeBatchStreams,
  sortBrowserEntries,
} from "./source-browser-model";
import { SourceBrowserNetworkPanel } from "./SourceBrowserNetworkPanel";
import { SourceBrowserDirectoryList } from "./SourceBrowserDirectoryList";
import {
  formatDiscBytes as fmtBytes,
  formatDiscChapterDuration as fmtChapterDuration,
  formatDiscDuration as fmtDuration,
  handBrakeTrackNumbers,
  streamLanguageDisplay as languageLabel,
  streamDisplayLabel as streamLabel,
  streamTechnicalBadges,
  trackLanguageDisplay as trackLanguageSummary,
  type DiscStreamWithHandBrake,
  type DiscTrackWithMakeMkv,
} from "./disc-display-model";
import Workflow from "@/pages/Workflow";
import type { BatchItem } from "@/pages/BatchConfirmPage";
import {
  OCR_ENGINE_KEY,
  OCR_LANGUAGE_KEY,
  OCR_LANGUAGE_CODES,
  ocrLanguageLabel,
} from "@/lib/ocr-languages";
import {
  discFolderName,
  isDirectM2tsTitle,
  stableDiscTitleKey,
} from "../../pages/scan-model";
import { DiscAnalyzeDialog } from "./DiscAnalyzeDialog";

import { type ScanCopy } from "../../pages/Scan";

// ── RemuxPanel — direct path entry for any BD/DVD directory on disk ────────────
export function RemuxPanel({
  onJobCreated,
  defaultPath,
  uiText,
}: {
  onJobCreated: (count: number, firstId?: number) => void;
  defaultPath?: string;
  uiText: ScanCopy;
}) {
  const [discPath, setDiscPath] = useState(defaultPath || "/media/downloads/");
  const [analyzing, setAnalyzing] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const { toast } = useToast();

  function handleAnalyze(e: React.FormEvent) {
    e.preventDefault();
    if (!discPath.trim()) return;
    setAnalyzing(true);
    setOpenDialog(true);
  }

  if (openDialog && analyzing) {
    return (
      <DiscAnalyzeDialog
        discPath={discPath.trim()}
        processingMode="remux"
        subtitleMode="skip"
        uiText={uiText}
        onClose={() => {
          setOpenDialog(false);
          setAnalyzing(false);
        }}
        onJobCreated={(count, firstId) => {
          setOpenDialog(false);
          setAnalyzing(false);
          onJobCreated(count, firstId);
          toast({ title: uiText.createdRemuxJob, description: `${count}` });
        }}
      />
    );
  }

  return (
    <div className="space-y-4">
      {/* Instructions */}
      <div className="px-4 py-3 rounded-lg bg-blue-500/8 border border-blue-500/20 text-sm space-y-1.5">
        <p className="font-medium text-blue-400 flex items-center gap-1.5">
          <Disc className="h-3.5 w-3.5" /> {uiText.discDirInstructionTitle}
        </p>
        <p className="text-muted-foreground text-xs leading-relaxed">
          {uiText.discDirInstructionBody}
        </p>
      </div>

      <form onSubmit={handleAnalyze} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="remux-path">{uiText.discDirPathLabel}</Label>
          <div className="flex gap-2">
            <Input
              id="remux-path"
              placeholder="/media/downloads/MovieName_BluRay"
              value={discPath}
              onChange={(e) => {
                setDiscPath(e.target.value);
                setAnalyzing(false);
              }}
              className="font-mono bg-secondary/30 flex-1"
              required
            />
            <Button type="submit" disabled={!discPath.trim()}>
              <Disc className="h-4 w-4 mr-1.5" />
              {uiText.analyze}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            {uiText.driveRootHint}　{uiText.outputDirHint}
          </p>
        </div>

        {/* Common path examples */}
        <div className="space-y-1.5">
          <p className="text-xs font-medium text-muted-foreground">
            {uiText.pathExamples}
          </p>
          <div className="flex flex-wrap gap-2">
            {[
              "/media/downloads/",
              "/media/downloads/BDMV",
              "/media/downloads/VIDEO_TS",
            ].map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => {
                  setDiscPath(p);
                  setAnalyzing(false);
                }}
                className="font-mono text-xs px-2.5 py-1 rounded border border-border hover:border-primary/50 hover:bg-secondary/60 transition-colors"
              >
                {p}
              </button>
            ))}
          </div>
        </div>
      </form>

      {/* How it works */}
      <div className="grid grid-cols-3 gap-3 text-xs text-center">
        {[
          {
            icon: "1",
            label: uiText.stepInputPath,
            desc: uiText.stepInputPathDesc,
          },
          {
            icon: "2",
            label: uiText.stepClickAnalyze,
            desc: uiText.stepClickAnalyzeDesc,
          },
          {
            icon: "3",
            label: uiText.stepSelectCreate,
            desc: uiText.stepSelectCreateDesc,
          },
        ].map((s) => (
          <div
            key={s.icon}
            className="border rounded-lg p-3 space-y-1 bg-secondary/10"
          >
            <div className="h-6 w-6 rounded-full bg-primary/20 text-primary text-xs font-bold flex items-center justify-center mx-auto">
              {s.icon}
            </div>
            <div className="font-medium">{s.label}</div>
            <div className="text-muted-foreground leading-snug">{s.desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
