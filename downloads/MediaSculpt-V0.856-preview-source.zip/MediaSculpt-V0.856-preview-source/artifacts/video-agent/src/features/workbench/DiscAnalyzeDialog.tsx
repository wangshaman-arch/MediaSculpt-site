// Extracted from pages/Scan.tsx: the disc analyze dialog.
import {
  Profiler,
  useState,
  useCallback,
  useEffect,
  useMemo,
  useRef,
} from "react";
import {
  useCreateJob,
  useBrowseDirectory,
  useGetConfig,
  getGetConfigQueryKey,
  useUpdateConfig,
  useAnalyzeDisc,
  useListJobs,
  getListJobsQueryKey,
} from "@workspace/api-client-react";
import type { DiscTrack, DiscStream } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import { ToastAction } from "@/components/ui/toast";
import {
  Loader2,
  Play,
  ArrowLeft,
  SquareCheck,
  Square,
  Disc,
  X,
  Video,
  Music,
  Subtitles,
  HelpCircle,
  ChevronDown,
  ChevronsUpDown,
  Save,
  ScanText,
  Sparkles,
  Layers,
  List,
  Wand2,
  Mic,
  Languages,
  Captions,
  Settings2,
  RotateCcw,
} from "lucide-react";
import { useLocation } from "wouter";
import {
  useToolAvailability,
  toolsRequiredForSubtitle,
} from "@/lib/use-tool-availability";
import { cn, formatDate } from "@/lib/utils";
import {
  ARCHIVE_PRESETS,
  ARCHIVE_PRESET_LS_KEY,
  compressionConfigValues,
  CUSTOM_COMPRESSION_PRESET_ID,
  PRESET_CHANGED_EVENT,
  loadCompressionPresets,
  presetConfigValues,
  type ArchivePreset,
  type CompressionPresetValues,
} from "@/lib/compression-presets";
import { useI18n, useScanCopy } from "@/i18n";
import {
  useWorkbenchState,
  type ProcessingMode,
  type SubtitleMode,
  type WorkbenchTab,
} from "@/hooks/useWorkbenchState";
import { WorkbenchModeTabs } from "./WorkbenchModeTabs";
import { SubtitleModeSelector } from "./SubtitleModeSelector";
import { CompressionPresetPanel } from "./CompressionPresetPanel";
import { DiscTitleRow } from "./DiscTitleRow";
import { WorkbenchSourceEntry } from "./WorkbenchSourceEntry";
import {
  browserStorage,
  readLastBrowsePath,
  readNetworkPathHistory,
  rememberBrowsePath,
  rememberNetworkPath,
} from "./source-browser-storage";
import {
  lastPathSegment,
  normalizeBatchStreams,
  sortBrowserEntries,
} from "./source-browser-model";
import { SourceBrowserNetworkPanel } from "./SourceBrowserNetworkPanel";
import { SourceBrowserDirectoryList } from "./SourceBrowserDirectoryList";
import {
  filterValidSelection,
  selectionMatches,
} from "./disc-selection-reconciliation-model";
import {
  formatDiscBytes as fmtBytes,
  formatDiscChapterDuration as fmtChapterDuration,
  formatDiscDuration as fmtDuration,
  handBrakeTrackNumbers,
  streamLanguageDisplay as languageLabel,
  streamDisplayLabel as streamLabel,
  streamTechnicalBadges,
  trackLanguageDisplay as trackLanguageSummary,
  type DiscTrackWithMakeMkv,
} from "./disc-display-model";
import Workflow from "@/pages/Workflow";
import type { BatchItem } from "@/pages/BatchConfirmPage";
import {
  OCR_ENGINE_KEY,
  OCR_LANGUAGE_KEY,
  OCR_LANGUAGE_CODES,
  ocrLanguageLabel,
} from "@/lib/ocr-languages";
import {
  discFolderName,
  isDirectM2tsTitle,
  stableDiscTitleKey,
} from "../../pages/scan-model";

// Shared helpers that still live in the Scan page module.
import {
  onDiscPreviewRender,
  measureDiscPreviewInteraction,
  streamKindLabel,
  type ScanCopy,
  type DiscTitlePreviewState,
} from "../../pages/Scan";
import {
  assessDiscRemuxCapacity,
  canCreateDiscJobsWithMode,
  isClearlyInvalidDiscTrack,
  selectCapacitySafeDiscTitles,
  setDiscTitleSelection,
} from "./disc-job-mode-model";
import { discAnalysisDialogBehavior } from "./disc-analysis-mode-model";

export function DiscAnalyzeDialog({
  discPath,
  processingMode: requestedProcessingMode,
  subtitleMode: requestedSubtitleMode,
  ocrEngine,
  ocrLanguage,
  bilingualLayout = "zh-top",
  uiText,
  onClose,
  onJobCreated,
  onAnalysisConfirmed,
  onSelectMode,
  analysisOnly = false,
}: {
  discPath: string;
  processingMode: ProcessingMode;
  subtitleMode: SubtitleMode;
  ocrEngine?: string;
  ocrLanguage?: string;
  bilingualLayout?: "zh-top" | "foreign-top";
  uiText: ScanCopy;
  onClose: () => void;
  onJobCreated: (count: number, firstId?: number) => void;
  /** Smart Workflow hands the verified selection to the pre-queue preview page. */
  onAnalysisConfirmed?: (items: BatchItem[]) => void;
  onSelectMode?: (mode: ProcessingMode, subtitleMode?: SubtitleMode) => void;
  /** Smart Workflow analyzes the disc here and chooses the job mode later. */
  analysisOnly?: boolean;
}) {
  const { t } = useI18n();
  // A newly opened analysis must observe the current VOB layout. The server
  // may retain a five-minute snapshot for job hand-off, but the selection UI
  // must not show a stale title list after the source or parser changed.
  const { data, isLoading, isError } = useAnalyzeDisc({
    path: discPath,
    force: true,
  });
  // The dialog only needs a snapshot for the duplicate hint.  The server
  // performs the authoritative check when a job is created; polling the full
  // queue here used to rerender the whole preview every three seconds.
  const { data: existingJobs } = useListJobs(
    {},
    {
      query: {
        refetchInterval: false,
        refetchOnWindowFocus: false,
        staleTime: 30_000,
        queryKey: getListJobsQueryKey({}),
      },
    },
  );
  const createJob = useCreateJob();
  const { toast } = useToast();

  const [activeTrackIdx, setActiveTrackIdx] = useState(-1);
  const [selectedTrackIndices, setSelectedTrackIndices] = useState<Set<number>>(
    new Set(),
  );
  const [streamSelections, setStreamSelections] = useState<
    Map<number, Set<number>>
  >(new Map());
  const [chapterSelections, setChapterSelections] = useState<
    Map<number, Set<number>>
  >(new Map());
  const [verifiedTracks, setVerifiedTracks] = useState<
    Map<number, DiscTrackWithMakeMkv>
  >(new Map());
  const [verifyingTracks, setVerifyingTracks] = useState<Set<number>>(
    new Set(),
  );
  const [selectionInitialized, setSelectionInitialized] = useState<Set<number>>(
    new Set(),
  );
  const [verificationRequests, setVerificationRequests] = useState<
    Map<number, number>
  >(new Map());
  const [previewByTitleId, setPreviewByTitleId] = useState<
    Record<string, DiscTitlePreviewState>
  >({});
  const [previewGeneration, setPreviewGeneration] = useState(0);
  const [previewPage, setPreviewPage] = useState(0);
  const [creating, setCreating] = useState(false);
  // Normal workbench entries may choose a job mode here. Smart Workflow keeps
  // that decision for the next stage and uses this dialog only for analysis.
  const [processingMode, setProcessingMode] = useState<ProcessingMode>(
    requestedProcessingMode,
  );
  const [subtitleMode, setSubtitleMode] = useState<SubtitleMode>(
    requestedSubtitleMode,
  );
  const [modeChosen, setModeChosen] = useState(
    requestedProcessingMode !== "none" || requestedSubtitleMode !== "skip",
  );
  const [smartParsing, setSmartParsing] = useState(false);
  const [smartNote, setSmartNote] = useState<string | null>(null);
  const [smartManifestId, setSmartManifestId] = useState<string | null>(null);
  const [dvdVerificationComplete, setDvdVerificationComplete] = useState(false);
  const selectionScopeRef = useRef("");
  const dvdVerificationScopeRef = useRef("");
  const autoDvdSelectionScopeRef = useRef("");
  const verifyingTracksRef = useRef<Set<number>>(new Set());
  const activeTrackRef = useRef(activeTrackIdx);
  activeTrackRef.current = activeTrackIdx;

  const {
    showModePicker,
    includeVideoStreams,
    verifyDvdTitles,
    filterTitlesByProcessingMode,
    allowJobCreation,
  } = discAnalysisDialogBehavior({
    analysisOnly,
    processingMode,
    subtitleMode,
  });

  useEffect(() => {
    setProcessingMode(requestedProcessingMode);
    setSubtitleMode(requestedSubtitleMode);
    setModeChosen(
      requestedProcessingMode !== "none" || requestedSubtitleMode !== "skip",
    );
  }, [requestedProcessingMode, requestedSubtitleMode]);

  const modeSelectionAttention =
    showModePicker && Boolean(data) && !isLoading && !isError && !modeChosen;

  function chooseProcessingMode(mode: ProcessingMode) {
    setProcessingMode(mode);
    setModeChosen(true);
    // Video actions do not run subtitle processing. Selecting the subtitle
    // action from the neutral workflow state needs an explicit usable mode.
    const nextSubtitleMode: SubtitleMode = mode === "none" ? "auto" : "skip";
    setSubtitleMode(nextSubtitleMode);
    // The neutral workflow initially exposes only audio/subtitle streams.
    // When the user confirms a video action, reconcile any existing selection
    // so a stale audio-only set cannot create an invalid DVD Remux snapshot.
    setStreamSelections((current) => {
      if (!data) return current;
      const next = new Map(current);
      const indexes = new Set([...current.keys(), ...selectedTrackIndices]);
      for (const idx of indexes) {
        const track = data.tracks[idx] as DiscTrackWithMakeMkv | undefined;
        if (!track) continue;
        const existing = current.get(idx) ?? new Set<number>();
        const hasVideo = track.streams.some(
          (stream) =>
            stream.codecType === "video" && existing.has(stream.index),
        );
        if (mode !== "none" && !hasVideo) {
          next.set(idx, defaultStreamSelection(track));
        } else if (mode === "none") {
          next.set(
            idx,
            new Set(
              Array.from(existing).filter((streamIndex) =>
                track.streams.some(
                  (stream) =>
                    stream.index === streamIndex &&
                    (stream.codecType === "audio" ||
                      stream.codecType === "subtitle"),
                ),
              ),
            ),
          );
        }
      }
      return next;
    });
    onSelectMode?.(mode, nextSubtitleMode);
  }

  const effectiveTrack = useCallback(
    (idx: number): DiscTrackWithMakeMkv | undefined =>
      verifiedTracks.get(idx) ??
      (data?.tracks[idx] as DiscTrackWithMakeMkv | undefined),
    [data?.tracks, verifiedTracks],
  );
  const selectedTrack = effectiveTrack(activeTrackIdx);

  // 智能解析：服务端先做真实读取和容量校验，再一次性应用最终标题清单。
  const runSmartParse = useCallback(async () => {
    if (!data) return;
    setSmartParsing(true);
    setSmartNote(null);
    try {
      const response = await fetch("/api/disc/analyze/smart", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ analysisId: data.analysisId, force: true }),
      });
      const result = (await response.json().catch(() => ({}))) as {
        applied?: boolean;
        manifestId?: string;
        selectedTitleIds?: string[];
        selectedStreamsByTitle?: Record<string, number[]>;
        selectedChaptersByTitle?: Record<string, number[]>;
        confidence?: "high" | "medium" | "low";
        requiresUserSelection?: boolean;
        reason?: string;
        reasons?: string[];
        ai?: {
          titleId?: string;
          videoIndex?: number | null;
          audioIndices?: number[];
          subtitleIndices?: number[];
          reason?: string;
        } | null;
      };
      const selectedIds = Array.isArray(result.selectedTitleIds)
        ? result.selectedTitleIds.filter(
            (value): value is string => typeof value === "string",
          )
        : [];
      const selectedIndices = selectedIds
        .map((titleId) =>
          (data.tracks ?? []).findIndex((track) => track.titleId === titleId),
        )
        .filter((idx) => idx >= 0);
      const safeSelectedIndices = selectCapacitySafeDiscTitles(
        data.tracks as Array<DiscTrackWithMakeMkv>,
        selectedIndices,
        data.sourceSizeBytes,
      );
      if (response.ok && result.applied && safeSelectedIndices.length > 0) {
        const selectedStreamsByTitle = result.selectedStreamsByTitle ?? {};
        const selectedChaptersByTitle = result.selectedChaptersByTitle ?? {};
        // Apply the server's safe title decision to the actual title checklist.
        // Previously only stream/chapter maps were updated, so the UI could
        // still keep an empty or stale title selection after smart parsing.
        setSelectedTrackIndices(new Set(safeSelectedIndices));
        setStreamSelections((current) => {
          const next = new Map(current);
          for (const idx of safeSelectedIndices) {
            const track = data.tracks[idx];
            const requested = track?.titleId
              ? selectedStreamsByTitle[track.titleId]
              : undefined;
            if (track && Array.isArray(requested)) {
              const allowedIndexes = track.streams
                .filter(
                  (stream) =>
                    includeVideoStreams ||
                    stream.codecType === "audio" ||
                    stream.codecType === "subtitle",
                )
                .map((stream) => stream.index);
              const cleaned = filterValidSelection(requested, allowedIndexes);
              next.set(
                idx,
                new Set(cleaned.length > 0 ? cleaned : allowedIndexes),
              );
            }
          }
          return next;
        });
        setChapterSelections((current) => {
          const next = new Map(current);
          for (const idx of safeSelectedIndices) {
            const track = data.tracks[idx];
            const requested = track?.titleId
              ? selectedChaptersByTitle[track.titleId]
              : undefined;
            if (track && Array.isArray(requested)) {
              next.set(
                idx,
                new Set(
                  filterValidSelection(
                    requested,
                    track.chapters?.map((chapter) => chapter.id) ?? [],
                  ),
                ),
              );
            }
          }
          return next;
        });
        setActiveTrackIdx(safeSelectedIndices[0] ?? 0);
        setSmartManifestId(
          typeof result.manifestId === "string" ? result.manifestId : null,
        );
        setVerifiedTracks((current) => {
          const next = new Map(current);
          for (const idx of safeSelectedIndices) {
            const track = data.tracks[idx] as DiscTrackWithMakeMkv | undefined;
            if (track)
              next.set(idx, {
                ...track,
                verificationStatus: "verified",
                verificationFailureReason: null,
                // This is the verified logical dvdvideo title number used by the
                // executor; it is intentionally distinct from physical VTS size mapping.
                dvdVtsNumber: track.handbrakeTitleNumber ?? null,
              });
          }
          return next;
        });
        const primaryTitleId =
          data.tracks[safeSelectedIndices[0] ?? -1]?.titleId ?? null;
        const localStreams = primaryTitleId
          ? selectedStreamsByTitle[primaryTitleId]
          : undefined;
        const aiStreams =
          result.ai && result.ai.titleId === primaryTitleId
            ? [
                ...(typeof result.ai.videoIndex === "number"
                  ? [result.ai.videoIndex]
                  : []),
                ...(result.ai.audioIndices ?? []),
                ...(result.ai.subtitleIndices ?? []),
              ]
            : undefined;
        const unknownTitle = t("scan.unknownTitle");
        const aiHint = result.ai?.titleId
          ? result.ai.titleId !== primaryTitleId
            ? t("scan.smartAiSuggestedTitle", {
                suggested: result.ai.titleId,
                primary: primaryTitleId ?? unknownTitle,
              })
            : selectionMatches(localStreams, aiStreams)
              ? t("scan.smartAiStreamsMatch", { title: result.ai.titleId })
              : t("scan.smartAiStreamsDiffer", { title: result.ai.titleId })
          : t("scan.smartAiUnavailable");
        setSmartNote(
          t("scan.smartValidatedCount", {
            count: String(safeSelectedIndices.length),
            confidence: result.confidence ?? "medium",
            hint: aiHint,
            reasons: (result.reasons ?? []).slice(0, 2).join("；"),
          }),
        );
      } else {
        setSmartManifestId(null);
        const noSelectionReason =
          result.reason ??
          ((result.reasons ?? []).join("；") ||
            t("scan.noValidatedCandidate"));
        setSmartNote(
          t("scan.smartValidationNoTitle", { reason: noSelectionReason }),
        );
      }
    } catch (error) {
      setSmartNote(
        t("scan.smartValidationFailed", {
          reason: error instanceof Error ? error.message : String(error),
        }),
      );
    } finally {
      setSmartParsing(false);
    }
  }, [data, includeVideoStreams, processingMode]);

  // Focusing a title prepares a complete export selection. Users can narrow it
  // explicitly in the selection summary without changing the title selection.
  const defaultStreamSelection = useCallback(
    (track?: DiscTrack) =>
      new Set(
        track?.streams
          .filter(
            (stream) =>
              includeVideoStreams ||
              stream.codecType === "audio" ||
              stream.codecType === "subtitle",
          )
          .map((stream) => stream.index) ?? [],
      ),
    [includeVideoStreams, processingMode],
  );

  const defaultChapterSelection = useCallback(
    (track?: DiscTrack) =>
      new Set(track?.chapters?.map((chapter) => chapter.id) ?? []),
    [],
  );

  const initializeTrackSelection = useCallback(
    (idx: number, track: DiscTrack) => {
      setSelectionInitialized((previous) => {
        if (previous.has(idx)) return previous;
        const next = new Set(previous);
        next.add(idx);
        setStreamSelections((current) =>
          current.has(idx)
            ? current
            : new Map(current).set(idx, defaultStreamSelection(track)),
        );
        setChapterSelections((current) =>
          current.has(idx)
            ? current
            : new Map(current).set(idx, defaultChapterSelection(track)),
        );
        return next;
      });
    },
    [defaultChapterSelection, defaultStreamSelection],
  );

  const ensureTrackSelection = useCallback(
    (idx: number) => {
      const track = effectiveTrack(idx);
      if (!track) return;
      // DVD Remux controls are locked until FFprobe enriches the title. Initialize
      // once from the verified stream list so newly discovered subtitles/audio are
      // included without overwriting later user changes.
      if (
        verifyDvdTitles &&
        data?.discType === "dvd" &&
        track.verificationStatus !== "verified"
      )
        return;
      initializeTrackSelection(idx, track);
    },
    [
      data?.discType,
      effectiveTrack,
      initializeTrackSelection,
      processingMode,
      verifyDvdTitles,
    ],
  );

  const handleTrackSelect = useCallback(
    (idx: number) => {
      setActiveTrackIdx(idx);
      setPreviewPage(0);
      ensureTrackSelection(idx);
    },
    [ensureTrackSelection],
  );

  const toggleTrackSelected = useCallback(
    (idx: number, selected: boolean) => {
      ensureTrackSelection(idx);
      setSelectedTrackIndices((prev) => {
        const next = setDiscTitleSelection(prev, idx, selected);
        if (
          selected &&
          processingMode === "remux" &&
          data?.discType === "dvd" &&
          assessDiscRemuxCapacity({
            sourceBytes: data.sourceSizeBytes,
            tracks: data.tracks as Array<DiscTrackWithMakeMkv>,
            selectedIndexes: next,
          }).blocked
        ) {
          toast({
            title: t("scan.capacitySelectionBlocked"),
            variant: "destructive",
          });
          return prev;
        }
        return next;
      });
      setActiveTrackIdx(idx);
      setPreviewPage(0);
    },
    [data, ensureTrackSelection, processingMode, t, toast],
  );

  useEffect(() => {
    if (!data?.tracks[0]) return;
    setPreviewPage(0);
    const scope = `${data.analysisId}:${data.sourceFingerprint}:${data.discType}:${processingMode}`;
    if (selectionScopeRef.current === scope) return;
    selectionScopeRef.current = scope;
    setVerifiedTracks(new Map());
    setVerifyingTracks(new Set());
    setVerificationRequests(new Map());
    setDvdVerificationComplete(false);
    dvdVerificationScopeRef.current = "";
    autoDvdSelectionScopeRef.current = "";
    if (verifyDvdTitles && data.discType === "dvd") {
      const firstValidIndex = data.tracks.findIndex(
        (track) => !isClearlyInvalidDiscTrack(track as DiscTrackWithMakeMkv),
      );
      setActiveTrackIdx(firstValidIndex >= 0 ? firstValidIndex : 0);
      setSelectedTrackIndices(new Set());
      setStreamSelections(new Map());
      setChapterSelections(new Map());
      setSelectionInitialized(new Set());
      return;
    }
    // Compress mode prefers HandBrake titles (merged full-performance grouping)
    // when available; Remux/subtitle modes use the per-m2ts fallback titles.
    const hasHandbrakeTitles = data.tracks.some(
      (track) => (track as DiscTrackWithMakeMkv).titleKind === "handbrake",
    );
    const visibleEntries = data.tracks
      .map((track, idx) => ({ track: track as DiscTrackWithMakeMkv, idx }))
      .filter(({ track }) => {
        if (!filterTitlesByProcessingMode) return true;
        const kind = track.titleKind;
        if (kind === "handbrake")
          return (
            processingMode === "compress" ||
            (processingMode === "remux" && typeof track.playlistId === "string")
          );
        if (kind === "m2ts")
          return processingMode !== "compress" || !hasHandbrakeTitles;
        return true;
      });
    // Focus the longest visible track for preview, but do not select it or any
    // stream/chapter automatically. Execution requires explicit user choices.
    const validVisibleEntries = visibleEntries.filter(
      ({ track }) => !isClearlyInvalidDiscTrack(track),
    );
    const initialEntry = validVisibleEntries.reduce<
      (typeof visibleEntries)[number] | null
    >(
      (best, entry) =>
        best == null ||
        (entry.track.durationSeconds ?? 0) > (best.track.durationSeconds ?? 0)
          ? entry
          : best,
      null,
    );
    const initialIdx = initialEntry ? initialEntry.idx : 0;
    const defaultIndices = selectCapacitySafeDiscTitles(
      data.tracks as Array<DiscTrackWithMakeMkv>,
      validVisibleEntries.map(({ idx }) => idx),
      data.sourceSizeBytes,
    );
    const defaultStreams = new Map<number, Set<number>>();
    const defaultChapters = new Map<number, Set<number>>();
    for (const idx of defaultIndices) {
      const track = data.tracks[idx];
      if (!track) continue;
      defaultStreams.set(idx, defaultStreamSelection(track));
      defaultChapters.set(idx, defaultChapterSelection(track));
    }
    setActiveTrackIdx(initialIdx);
    setSelectedTrackIndices(new Set(defaultIndices));
    setStreamSelections(defaultStreams);
    setChapterSelections(defaultChapters);
    setSelectionInitialized(new Set(defaultIndices));
  }, [
    data?.analysisId,
    data?.sourceFingerprint,
    data?.discType,
    data?.sourceSizeBytes,
    data?.tracks,
    defaultChapterSelection,
    defaultStreamSelection,
    filterTitlesByProcessingMode,
    processingMode,
    verifyDvdTitles,
  ]);

  const trackSummaries = useMemo<DiscTrackWithMakeMkv[]>(
    () =>
      (data?.tracks ?? []).map(
        (initialTrack, idx) =>
          effectiveTrack(idx) ?? (initialTrack as DiscTrackWithMakeMkv),
      ),
    [data?.tracks, effectiveTrack],
  );
  const hasHandbrakeTitles = (data?.tracks ?? []).some(
    (track) => (track as DiscTrackWithMakeMkv).titleKind === "handbrake",
  );
  const isTrackVisibleForMode = useCallback(
    (track: DiscTrackWithMakeMkv): boolean => {
      // Keep metadata-only titles visible so the user sees the authoritative
      // duration and missing-file reason; selection remains blocked below.
      if (track.availabilityStatus === "unavailable") return true;
      if (isClearlyInvalidDiscTrack(track)) return false;
      if (!filterTitlesByProcessingMode) return true;
      if (track.titleKind === "handbrake")
        return (
          processingMode === "compress" ||
          (processingMode === "remux" && typeof track.playlistId === "string")
        );
      if (track.titleKind === "m2ts")
        return processingMode !== "compress" || !hasHandbrakeTitles;
      return true;
    },
    [filterTitlesByProcessingMode, processingMode, hasHandbrakeTitles],
  );

  // DVD video actions verify titles asynchronously. Once a verified title is
  // available, select the valid capacity-safe set instead of leaving the user
  // with an empty queue or selecting an unverified decoy title.
  useEffect(() => {
    if (
      data?.discType !== "dvd" ||
      !verifyDvdTitles ||
      analysisOnly ||
      !dvdVerificationComplete
    )
      return;
    const scope = `${data.analysisId}:${data.sourceFingerprint}:${processingMode}`;
    if (autoDvdSelectionScopeRef.current === scope) return;
    const verifiedIndices = trackSummaries.flatMap((track, idx) =>
      track.verificationStatus === "verified" && isTrackVisibleForMode(track)
        ? [idx]
        : [],
    );
    if (verifiedIndices.length === 0) return;
    const defaults = selectCapacitySafeDiscTitles(
      trackSummaries,
      verifiedIndices,
      data.sourceSizeBytes,
    );
    if (defaults.length === 0) return;
    autoDvdSelectionScopeRef.current = scope;
    setSelectedTrackIndices((current) => {
      const next = new Set(current);
      defaults.forEach((idx) => next.add(idx));
      return next;
    });
    setStreamSelections((current) => {
      const next = new Map(current);
      for (const idx of defaults) {
        const track = trackSummaries[idx];
        if (track) next.set(idx, defaultStreamSelection(track));
      }
      return next;
    });
    setChapterSelections((current) => {
      const next = new Map(current);
      for (const idx of defaults) {
        const track = trackSummaries[idx];
        if (track) next.set(idx, defaultChapterSelection(track));
      }
      return next;
    });
    setSelectionInitialized((current) => {
      const next = new Set(current);
      defaults.forEach((idx) => next.add(idx));
      return next;
    });
  }, [
    data?.discType,
    data?.analysisId,
    data?.sourceSizeBytes,
    data?.sourceFingerprint,
    defaultChapterSelection,
    defaultStreamSelection,
    dvdVerificationComplete,
    isTrackVisibleForMode,
    processingMode,
    selectedTrackIndices.size,
    trackSummaries,
    analysisOnly,
    verifyDvdTitles,
  ]);

  const selectableDiscTitleIndices = useMemo(
    () =>
      trackSummaries.flatMap((track, idx) => {
        if (!isTrackVisibleForMode(track)) return [];
        if (track.availabilityStatus === "unavailable") return [];
        if (
          data?.discType === "dvd" &&
          verifyDvdTitles &&
          track.verificationStatus !== "verified"
        )
          return [];
        return [idx];
      }),
    [data?.discType, isTrackVisibleForMode, trackSummaries, verifyDvdTitles],
  );

  function setAllDiscTitlesSelected(selected: boolean) {
    if (!data) return;
    if (!selected) {
      setSelectedTrackIndices(new Set());
      return;
    }
    const indexes =
      data.discType === "dvd"
        ? selectCapacitySafeDiscTitles(
            trackSummaries,
            selectableDiscTitleIndices,
            data.sourceSizeBytes,
          )
        : selectableDiscTitleIndices;
    setSelectedTrackIndices(new Set(indexes));
    setStreamSelections((current) => {
      const next = new Map(current);
      for (const idx of indexes) {
        const track = trackSummaries[idx];
        if (track) next.set(idx, defaultStreamSelection(track));
      }
      return next;
    });
    setChapterSelections((current) => {
      const next = new Map(current);
      for (const idx of indexes) {
        const track = trackSummaries[idx];
        if (track) next.set(idx, defaultChapterSelection(track));
      }
      return next;
    });
    setSelectionInitialized((current) => {
      const next = new Set(current);
      indexes.forEach((idx) => next.add(idx));
      return next;
    });
  }

  useEffect(() => {
    setPreviewByTitleId({});
    setPreviewGeneration((value) => value + 1);
    setPreviewPage(0);
  }, [data?.analysisId, data?.sourceFingerprint]);

  useEffect(() => {
    const track =
      activeTrackIdx >= 0 ? trackSummaries[activeTrackIdx] : undefined;
    const titleId = track?.titleId;
    const previewKey = titleId
      ? stableDiscTitleKey(data?.sourceFingerprint, titleId)
      : "";
    if (
      !titleId ||
      !data?.analysisId ||
      previewByTitleId[previewKey]?.status === "loading" ||
      previewByTitleId[previewKey]?.status === "ready"
    )
      return;
    const generation = previewGeneration;
    setPreviewByTitleId((current) => ({
      ...current,
      [previewKey]: { status: "loading" },
    }));
    const params = new URLSearchParams({
      analysisId: data.analysisId,
      titleId,
      source: data.sourceFingerprint,
    });
    fetch(`/api/disc/title-preview?${params.toString()}`)
      .then(async (response) => {
        if (!response.ok)
          throw new Error(
            (await response.text().catch(() => "")) ||
              t("scan.previewServiceUnavailable"),
          );
        const body = (await response.json()) as {
          url?: string;
          previews?: string[];
          warning?: string;
        };
        if (!body.url) throw new Error(t("scan.previewNoImage"));
        const primaryUrl = body.url;
        const previews = (body.previews ?? [primaryUrl]).filter(
          (preview): preview is string =>
            typeof preview === "string" && preview.length > 0,
        );
        if (generation !== previewGeneration) return;
        setPreviewByTitleId((current) => ({
          ...current,
          [previewKey]: {
            status: "ready",
            url: primaryUrl,
            previews,
            warning: body.warning,
          },
        }));
      })
      .catch((error) => {
        if (generation !== previewGeneration) return;
        setPreviewByTitleId((current) => ({
          ...current,
          [previewKey]: {
            status: "failed",
            message: error instanceof Error ? error.message : String(error),
          },
        }));
      });
  }, [
    activeTrackIdx,
    data?.analysisId,
    data?.sourceFingerprint,
    previewByTitleId,
    previewGeneration,
    trackSummaries,
  ]);

  const requestReverification = useCallback((idx: number) => {
    setVerifiedTracks((previous) => {
      const next = new Map(previous);
      next.delete(idx);
      return next;
    });
    setVerificationRequests((previous) =>
      new Map(previous).set(idx, (previous.get(idx) ?? 0) + 1),
    );
  }, []);

  // Verify every candidate DVD title once after analysis. The previous active-
  // title-only verification made Remux/compression appear to contain only the
  // main title even when other valid VOB groups were available.
  useEffect(() => {
    if (
      (processingMode !== "remux" && processingMode !== "compress") ||
      data?.discType !== "dvd" ||
      !data.analysisId
    )
      return;
    const analysis = data;
    const scope = `${analysis.analysisId}:${analysis.sourceFingerprint}:${processingMode}`;
    if (dvdVerificationScopeRef.current === scope) return;
    dvdVerificationScopeRef.current = scope;
    const controller = new AbortController();
    let cancelled = false;
    const candidateIndices = analysis.tracks.flatMap((rawTrack, idx) => {
      const track = rawTrack as DiscTrackWithMakeMkv;
      return track.titleId && !isClearlyInvalidDiscTrack(track) ? [idx] : [];
    });

    async function verifyCandidate(idx: number) {
      const track = analysis.tracks[idx] as DiscTrackWithMakeMkv | undefined;
      if (!track?.titleId) return;
      verifyingTracksRef.current.add(idx);
      setVerifyingTracks((previous) => new Set(previous).add(idx));
      try {
        const response = await fetch("/api/disc/verify-title", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({
            analysisId: analysis.analysisId,
            titleId: track.titleId,
            force: false,
          }),
        });
        const body = (await response.json().catch(() => ({}))) as Record<
          string,
          unknown
        >;
        if (!response.ok || body.verified !== true)
          throw new Error(
            String(
              body.failureReason ?? body.error ?? t("scan.titleVerifyFailed"),
            ),
          );
        if (cancelled) return;
        const verifiedTrack: DiscTrackWithMakeMkv = {
          ...track,
          durationSeconds:
            typeof body.durationSeconds === "number"
              ? body.durationSeconds
              : track.durationSeconds,
          streams: Array.isArray(body.streams)
            ? (body.streams as DiscStream[])
            : track.streams,
          chapters: Array.isArray(body.chapters)
            ? (body.chapters as DiscTrack["chapters"])
            : track.chapters,
          dvdVtsNumber:
            typeof body.titleNumber === "number" ? body.titleNumber : null,
          verificationStatus: "verified",
          verificationFailureReason: null,
          verificationWarnings: Array.isArray(body.warnings)
            ? body.warnings.filter(
                (item): item is string => typeof item === "string",
              )
            : [],
        };
        setVerifiedTracks((previous) =>
          new Map(previous).set(idx, verifiedTrack),
        );
        initializeTrackSelection(idx, verifiedTrack);
      } catch (error) {
        if (
          cancelled ||
          (error instanceof DOMException && error.name === "AbortError")
        )
          return;
        const failedTrack: DiscTrackWithMakeMkv = {
          ...track,
          verificationStatus: "failed",
          verificationFailureReason:
            error instanceof Error ? error.message : String(error),
        };
        setVerifiedTracks((previous) =>
          new Map(previous).set(idx, failedTrack),
        );
      } finally {
        verifyingTracksRef.current.delete(idx);
        setVerifyingTracks((previous) => {
          if (!previous.has(idx)) return previous;
          const next = new Set(previous);
          next.delete(idx);
          return next;
        });
      }
    }

    void (async () => {
      for (const idx of candidateIndices) {
        if (cancelled) return;
        await verifyCandidate(idx);
      }
      if (!cancelled) setDvdVerificationComplete(true);
    })();
    return () => {
      cancelled = true;
      controller.abort();
      for (const idx of candidateIndices)
        verifyingTracksRef.current.delete(idx);
    };
  }, [
    data?.analysisId,
    data?.discType,
    data?.sourceFingerprint,
    data?.tracks,
    initializeTrackSelection,
    processingMode,
    t,
    verifyDvdTitles,
  ]);

  useEffect(() => {
    if (
      !verifyDvdTitles ||
      data?.discType !== "dvd" ||
      !data.analysisId ||
      activeTrackIdx < 0 ||
      (verificationRequests.get(activeTrackIdx) ?? 0) <= 0
    )
      return;
    const track = effectiveTrack(activeTrackIdx);
    if (
      !track ||
      track.verificationStatus === "verified" ||
      track.verificationStatus === "failed" ||
      verifyingTracksRef.current.has(activeTrackIdx)
    )
      return;
    const trackIdx = activeTrackIdx;
    const controller = new AbortController();
    let cancelled = false;
    verifyingTracksRef.current.add(trackIdx);
    setVerifyingTracks((previous) => new Set(previous).add(trackIdx));
    void fetch("/api/disc/verify-title", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({
        analysisId: data.analysisId,
        titleId: track.titleId,
        force: (verificationRequests.get(trackIdx) ?? 0) > 0,
      }),
    })
      .then(async (response) => {
        const body = (await response.json().catch(() => ({}))) as Record<
          string,
          unknown
        >;
        if (!response.ok || body.verified !== true)
          throw new Error(
            String(
              body.failureReason ?? body.error ?? t("scan.titleVerifyFailed"),
            ),
          );
        if (cancelled || activeTrackRef.current !== trackIdx) return;
        const verifiedTrack: DiscTrackWithMakeMkv = {
          ...track,
          durationSeconds:
            typeof body.durationSeconds === "number"
              ? body.durationSeconds
              : track.durationSeconds,
          streams: Array.isArray(body.streams)
            ? (body.streams as DiscStream[])
            : track.streams,
          chapters: Array.isArray(body.chapters)
            ? (body.chapters as DiscTrack["chapters"])
            : track.chapters,
          dvdVtsNumber:
            typeof body.titleNumber === "number" ? body.titleNumber : null,
          verificationStatus: "verified",
          verificationFailureReason: null,
          verificationWarnings: Array.isArray(body.warnings)
            ? body.warnings.filter(
                (item): item is string => typeof item === "string",
              )
            : [],
        };
        setVerifiedTracks((previous) =>
          new Map(previous).set(trackIdx, verifiedTrack),
        );
        // Verification may enrich streams/chapters, but must never reset a user's choices.
        initializeTrackSelection(trackIdx, verifiedTrack);
      })
      .catch((error) => {
        if (
          cancelled ||
          (error instanceof DOMException && error.name === "AbortError")
        )
          return;
        const failedTrack: DiscTrackWithMakeMkv = {
          ...track,
          verificationStatus: "failed",
          verificationFailureReason:
            error instanceof Error ? error.message : String(error),
        };
        setVerifiedTracks((previous) =>
          new Map(previous).set(trackIdx, failedTrack),
        );
        toast({
          title: t("scan.titleVerifyFailed"),
          description: failedTrack.verificationFailureReason ?? undefined,
          variant: "destructive",
        });
      })
      .finally(() => {
        verifyingTracksRef.current.delete(trackIdx);
        if (cancelled) return;
        setVerifyingTracks((previous) => {
          const next = new Set(previous);
          next.delete(trackIdx);
          return next;
        });
      });
    return () => {
      cancelled = true;
      controller.abort();
      verifyingTracksRef.current.delete(trackIdx);
      setVerifyingTracks((previous) => {
        if (!previous.has(trackIdx)) return previous;
        const next = new Set(previous);
        next.delete(trackIdx);
        return next;
      });
    };
  }, [
    activeTrackIdx,
    data?.analysisId,
    data?.discType,
    effectiveTrack,
    initializeTrackSelection,
    processingMode,
    toast,
    verificationRequests,
    verifyDvdTitles,
  ]);

  function toggleStream(idx: number) {
    if (!selectedTrack || verifyingTracks.has(activeTrackIdx)) return;
    const startedAt =
      typeof performance !== "undefined" ? performance.now() : Date.now();
    setStreamSelections((prev) => {
      const next = new Map(prev);
      const base =
        prev.get(activeTrackIdx) ?? defaultStreamSelection(selectedTrack);
      const current = new Set(base);
      current.has(idx) ? current.delete(idx) : current.add(idx);
      next.set(activeTrackIdx, current);
      return next;
    });
    measureDiscPreviewInteraction("streamToggle", startedAt);
  }

  function toggleChapter(id: number) {
    if (!selectedTrack || verifyingTracks.has(activeTrackIdx)) return;
    const startedAt =
      typeof performance !== "undefined" ? performance.now() : Date.now();
    setChapterSelections((prev) => {
      const next = new Map(prev);
      const base =
        prev.get(activeTrackIdx) ?? defaultChapterSelection(selectedTrack);
      const current = new Set(base);
      current.has(id) ? current.delete(id) : current.add(id);
      next.set(activeTrackIdx, current);
      return next;
    });
    measureDiscPreviewInteraction("chapterToggle", startedAt);
  }

  function setAllStreamsSelected(selected: boolean) {
    if (!selectedTrack || verifyingTracks.has(activeTrackIdx)) return;
    const selectableStreams = selectedTrack.streams.filter(
      (stream) =>
        includeVideoStreams ||
        stream.codecType === "audio" ||
        stream.codecType === "subtitle",
    );
    setStreamSelections((previous) => {
      const next = new Map(previous);
      next.set(
        activeTrackIdx,
        selected
          ? new Set(selectableStreams.map((stream) => stream.index))
          : new Set(),
      );
      return next;
    });
  }

  function setAllStreamsForSelectedTitles(selected: boolean) {
    if (selectedTrackIndices.size === 0) return;
    setStreamSelections((previous) => {
      const next = new Map(previous);
      for (const idx of selectedTrackIndices) {
        const track = trackSummaries[idx];
        if (!track || verifyingTracks.has(idx)) continue;
        const selectableStreams = track.streams.filter(
          (stream) =>
            includeVideoStreams ||
            stream.codecType === "audio" ||
            stream.codecType === "subtitle",
        );
        next.set(
          idx,
          selected
            ? new Set(selectableStreams.map((stream) => stream.index))
            : new Set(),
        );
      }
      return next;
    });
  }

  function setAllChaptersSelected(selected: boolean) {
    if (!selectedTrack || verifyingTracks.has(activeTrackIdx)) return;
    setChapterSelections((previous) => {
      const next = new Map(previous);
      next.set(
        activeTrackIdx,
        selected
          ? new Set(selectedTrack.chapters?.map((chapter) => chapter.id) ?? [])
          : new Set(),
      );
      return next;
    });
  }

  const selectedStreamIndices = selectedTrack
    ? (streamSelections.get(activeTrackIdx) ??
      defaultStreamSelection(selectedTrack))
    : new Set<number>();
  const selectedChapterIds = selectedTrack
    ? (chapterSelections.get(activeTrackIdx) ??
      defaultChapterSelection(selectedTrack))
    : new Set<number>();
  const selectableStreams = selectedTrack
    ? selectedTrack.streams.filter(
        (stream) =>
          includeVideoStreams ||
          stream.codecType === "audio" ||
          stream.codecType === "subtitle",
      )
    : [];
  const hasRunningDuplicate = useCallback(
    (track: DiscTrackWithMakeMkv) =>
      (existingJobs ?? []).some((job) => {
        if (
          !["pending", "scanning", "transcribing", "compressing"].includes(
            job.status ?? "",
          )
        )
          return false;
        if (job.processingMode !== "remux") return false;
        try {
          const snapshot = JSON.parse(job.taskSnapshot ?? "{}") as {
            selectedTitleId?: string;
            sourcePath?: string;
          };
          return (
            snapshot.selectedTitleId === track.titleId &&
            snapshot.sourcePath?.replace(/\\/g, "/").toLowerCase() ===
              track.path.replace(/\\/g, "/").toLowerCase()
          );
        } catch {
          return false;
        }
      }),
    [existingJobs],
  );
  const remuxCapacity =
    !analysisOnly && processingMode === "remux" && data?.discType === "dvd"
      ? assessDiscRemuxCapacity({
          sourceBytes: data.sourceSizeBytes,
          tracks: data.tracks as Array<DiscTrackWithMakeMkv>,
          selectedIndexes: selectedTrackIndices,
        })
      : null;
  const canCreate =
    allowJobCreation &&
    !!data &&
    canCreateDiscJobsWithMode({
      processingMode,
      subtitleMode,
      selectedTitleCount: selectedTrackIndices.size,
    }) &&
    !creating &&
    !remuxCapacity?.blocked &&
    Array.from(selectedTrackIndices).every((idx) => {
      const track = effectiveTrack(idx);
      if (!track) return false;
      const discTrack = track as DiscTrackWithMakeMkv;
      if (discTrack.availabilityStatus === "unavailable") return false;
      if (
        processingMode === "remux" &&
        data.discType === "dvd" &&
        (discTrack.verificationStatus !== "verified" ||
          typeof discTrack.dvdVtsNumber !== "number" ||
          discTrack.streams.every((stream) => stream.codecType !== "video"))
      )
        return false;
      if (
        processingMode === "remux" &&
        data.discType !== "dvd" &&
        !isDirectM2tsTitle(discTrack) &&
        (typeof discTrack.playlistId !== "string" ||
          discTrack.mappingStatus === "unmapped")
      )
        return false;
      if (processingMode === "remux" && hasRunningDuplicate(discTrack))
        return false;
      if (
        processingMode === "compress" &&
        (typeof discTrack.handbrakeTitleNumber !== "number" ||
          discTrack.handbrakeTitleNumber <= 0)
      )
        return false;
      const streamSet =
        streamSelections.get(idx) ?? defaultStreamSelection(track);
      const requiredTypes =
        processingMode === "none" ? ["audio", "subtitle"] : ["video"];
      return track.streams.some(
        (stream) =>
          requiredTypes.includes(stream.codecType) &&
          streamSet.has(stream.index),
      );
    });

  async function handleCreate() {
    if (!data || !allowJobCreation) return;
    setCreating(true);
    try {
      let created = 0;
      let firstId: number | undefined;
      for (const trackIdx of Array.from(selectedTrackIndices).sort(
        (a, b) => a - b,
      )) {
        const track = effectiveTrack(trackIdx);
        if (!track) continue;
        const streamSet =
          streamSelections.get(trackIdx) ?? defaultStreamSelection(track);
        const chapterSet =
          chapterSelections.get(trackIdx) ?? defaultChapterSelection();
        const streamArr = Array.from(streamSet).sort((a, b) => a - b);
        const chapterArr = Array.from(chapterSet).sort((a, b) => a - b);
        const handbrakeTitleNumber =
          typeof track.handbrakeTitleNumber === "number" &&
          track.handbrakeTitleNumber > 0
            ? track.handbrakeTitleNumber
            : null;
        const selectionPlan = JSON.stringify({
          version: 1,
          smartManifestId,
          analysis: {
            analysisId:
              (data as typeof data & { analysisId?: string }).analysisId ??
              null,
            titleId: track.titleId ?? null,
            titleIndex:
              typeof track.titleIndex === "number" ? track.titleIndex : null,
            mappingStatus: track.mappingStatus ?? "not-required",
          },
          video: track.streams
            .filter((s) => s.codecType === "video" && streamSet.has(s.index))
            .map((s) => s.index),
          audio: track.streams
            .filter((s) => s.codecType === "audio" && streamSet.has(s.index))
            .map((s) => s.index),
          audioStreams: track.streams
            .filter((s) => s.codecType === "audio" && streamSet.has(s.index))
            .map((s) => ({
              inputIndex: s.index,
              codecName: s.codecName ?? null,
              bitsPerRawSample:
                (s as typeof s & { bitsPerRawSample?: number | null })
                  .bitsPerRawSample ?? null,
            })),
          subtitle: track.streams
            .filter((s) => s.codecType === "subtitle" && streamSet.has(s.index))
            .map((s) => s.index),
          chapters: chapterArr,
          handbrake: {
            titleNumber: handbrakeTitleNumber,
            titleSizeBytes: track.sizeBytes ?? null,
            durationSeconds: track.durationSeconds ?? null,
            audioTrackNumbers: handBrakeTrackNumbers(track, streamSet, "audio"),
            subtitleTrackNumbers: handBrakeTrackNumbers(
              track,
              streamSet,
              "subtitle",
            ),
            chapterNumbers: chapterArr.map((id) => id + 1),
          },
          playlistId: track.playlistId ?? null,
          dvdvideo: {
            titleNumber: track.dvdVtsNumber ?? null,
            verified: track.verificationStatus === "verified",
          },
          analyzer: track.analyzer ?? "unified",
        });
        const outputMode =
          processingMode === "remux"
            ? "remux"
            : processingMode === "compress"
              ? "compress"
              : subtitleMode === "whisper" ||
                  subtitleMode === "transcribe_translate"
                ? "whisper"
                : "subtitle";
        const result = await createJob.mutateAsync({
          data: {
            filePath: discPath,
            subtitleMode: processingMode === "remux" ? "skip" : subtitleMode,
            ocrEngine:
              subtitleMode === "ocr"
                ? ((ocrEngine || "auto") as
                    | "auto"
                    | "llm"
                    | "tesseract"
                    | "rapidocr"
                    | "subtitleedit")
                : undefined,
            ocrLanguage:
              subtitleMode === "ocr" ? ocrLanguage || "auto" : undefined,
            mediaType: data.discType,
            processingMode:
              subtitleMode === "bilingual" ? "none" : processingMode,
            mainTrackPath: track.path,
            selectedStreams:
              streamArr.length > 0 ? JSON.stringify(streamArr) : undefined,
            selectedChapters:
              chapterArr.length > 0 ? JSON.stringify(chapterArr) : undefined,
            selectionPlan,
            analysisId: data.analysisId,
            sourceFingerprint: data.sourceFingerprint,
            selectedTitleId: track.titleId,
            outputMode,
            ...(subtitleMode === "bilingual" ? { bilingualLayout } : {}),
          },
        });
        if (!firstId && typeof (result as { id?: unknown })?.id === "number")
          firstId = (result as { id: number }).id;
        created++;
      }
      toast({
        title: uiText.createdDiscJob,
        description: `${created} · ${processingMode === "remux" ? uiText.createRemuxJob : processingMode === "compress" ? uiText.createCompressionJob : uiText.createSubtitleJob}`,
      });
      onJobCreated(created, firstId);
      onClose();
    } catch (e) {
      toast({
        title: t("scan.createFailed"),
        description: e instanceof Error ? e.message : t("common.unknownError"),
        variant: "destructive",
      });
    } finally {
      setCreating(false);
    }
  }

  function confirmAnalysisSelection() {
    if (!data || selectedTrackIndices.size === 0 || verifyingTracks.size > 0)
      return;
    const items: BatchItem[] = Array.from(selectedTrackIndices)
      .sort((a, b) => a - b)
      .map((trackIdx): BatchItem | null => {
        const track = effectiveTrack(trackIdx);
        if (!track) return null;
        const streamSet =
          streamSelections.get(trackIdx) ?? defaultStreamSelection(track);
        const chapterSet =
          chapterSelections.get(trackIdx) ?? defaultChapterSelection(track);
        return {
          key: `${discPath}::${track.titleId ?? trackIdx}`,
          path: discPath,
          kind: data.discType === "bluray" ? "bluray" : "dvd",
          label: track.name ?? `Title ${track.titleIndex ?? trackIdx + 1}`,
          durationSeconds: track.durationSeconds ?? null,
          titleId: track.titleId ?? null,
          analysisId: data.analysisId ?? null,
          sourceFingerprint: data.sourceFingerprint ?? null,
          handbrakeTitleNumber: track.handbrakeTitleNumber ?? null,
          playlistId: track.playlistId ?? null,
          mappingStatus: track.mappingStatus ?? null,
          verificationStatus: track.verificationStatus ?? null,
          dvdVtsNumber: track.dvdVtsNumber ?? null,
          streams: track.streams.map((stream) => ({
            index: stream.index,
            codecType: stream.codecType,
            codecName: stream.codecName ?? null,
            language: stream.language ?? null,
            channels: stream.channels ?? null,
            width: stream.width ?? null,
            height: stream.height ?? null,
            frameRate:
              (stream as DiscStream & { frameRate?: string | number | null })
                .frameRate ?? null,
          })),
          chapterCount: track.chapters?.length ?? 0,
          selectedStreamIndices: Array.from(streamSet).sort((a, b) => a - b),
          selectedChapterIds: Array.from(chapterSet).sort((a, b) => a - b),
          preview: null,
        };
      })
      .filter((item): item is BatchItem => item !== null);
    if (items.length === 0) return;
    onAnalysisConfirmed?.(items);
  }

  const discLabel =
    data?.discType === "bluray" ? t("scan.discBluray") : t("scan.discDvd");
  const processingLabel = uiText.modes[processingMode].label;
  const verificationMessage = (
    track: DiscTrackWithMakeMkv | undefined,
    idx: number,
  ): string | null => {
    if (!track) return null;
    if (verifyDvdTitles && data?.discType === "dvd") {
      if (verifyingTracks.has(idx) || track.verificationStatus === "pending")
        return t("scan.verifyingDiscTitle");
      if (track.verificationStatus === "failed") {
        const reason =
          track.verificationFailureReason ?? t("scan.dvdTitleVerifyFailed");
        if (/dvdvideo|dvd标题读取|demuxer|unknown format/i.test(reason))
          return t("scan.ffmpegDvdUnsupported");
        if (/没有可处理的视频流/.test(reason)) return t("scan.noVideoStream");
        return reason;
      }
      if (
        track.verificationStatus === "verified" &&
        !track.streams.some((stream) => stream.codecType === "video")
      ) {
        return t("scan.noVideoStream");
      }
      return null;
    }
    if (
      processingMode === "compress" &&
      (typeof track.handbrakeTitleNumber !== "number" ||
        track.handbrakeTitleNumber <= 0)
    ) {
      return t("scan.handbrakeNoTitle");
    }
    if (processingMode === "remux" && data?.discType === "bluray") {
      if (!isDirectM2tsTitle(track) && typeof track.playlistId !== "string")
        return t("scan.makemkvUnavailable");
      if (track.mappingStatus === "unmapped")
        return t("scan.blurayMappingFailed");
    }
    return null;
  };
  const processingMappingBlocked =
    ["remux", "compress"].includes(processingMode) &&
    Array.from(selectedTrackIndices).some((idx) => {
      const track = effectiveTrack(idx);
      if (!track) return true;
      if (processingMode === "remux" && data?.discType === "dvd")
        return (
          track.verificationStatus !== "verified" ||
          typeof track.dvdVtsNumber !== "number"
        );
      if (processingMode === "remux")
        return (
          (!isDirectM2tsTitle(track) && typeof track.playlistId !== "string") ||
          track.mappingStatus === "unmapped"
        );
      return (
        typeof track.handbrakeTitleNumber !== "number" ||
        track.handbrakeTitleNumber <= 0
      );
    });
  const renderExpandedTitleControls = () => {
    if (!selectedTrack) return null;
    if (selectedTrack.streams.length === 0) {
      return (
        <div className="mt-2 rounded-lg border bg-secondary/10 px-3 py-3 text-sm text-muted-foreground">
          {uiText.noStreams}
        </div>
      );
    }
    return (
      <Profiler
        id="StreamSelectionPanel"
        onRender={(id, phase, actualDuration) =>
          onDiscPreviewRender(id, phase, actualDuration)
        }
      >
        <div
          className="mt-2 space-y-3 rounded-lg border bg-background/55 p-3"
          onPointerDown={(event) => event.stopPropagation()}
          onClick={(event) => event.stopPropagation()}
        >
          <div data-testid="title-level-stream-controls">
            <div className="mb-2 flex items-center justify-between gap-2">
              <p className="text-xs font-medium text-muted-foreground">
                {uiText.selectStreams}
              </p>
              <div className="flex shrink-0 gap-1">
                <button
                  type="button"
                  className="rounded border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-secondary/50"
                  onClick={() => setAllStreamsSelected(true)}
                  disabled={verifyingTracks.has(activeTrackIdx)}
                >
                  {uiText.selectAllStreams}
                </button>
                <button
                  type="button"
                  className="rounded border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-secondary/50"
                  onClick={() => setAllStreamsSelected(false)}
                  disabled={verifyingTracks.has(activeTrackIdx)}
                >
                  {uiText.clearAllStreams}
                </button>
              </div>
            </div>
            <div className="space-y-1 rounded-lg border divide-y">
              {selectableStreams.map((s) => {
                const checked = selectedStreamIndices.has(s.index);
                const icon =
                  s.codecType === "video" ? (
                    <Video className="h-3.5 w-3.5 text-blue-400 shrink-0" />
                  ) : s.codecType === "audio" ? (
                    <Music className="h-3.5 w-3.5 text-green-400 shrink-0" />
                  ) : (
                    <Subtitles className="h-3.5 w-3.5 text-yellow-400 shrink-0" />
                  );
                return (
                  <label
                    key={s.index}
                    onPointerDown={(event) => event.stopPropagation()}
                    onClick={(event) => event.stopPropagation()}
                    className={cn(
                      "flex cursor-pointer items-center gap-3 px-3 py-2 text-sm transition-colors",
                      checked ? "bg-primary/5" : "hover:bg-secondary/30",
                    )}
                  >
                    <Checkbox
                      checked={checked}
                      disabled={verifyingTracks.has(activeTrackIdx)}
                      onCheckedChange={() => toggleStream(s.index)}
                      className="shrink-0"
                    />
                    {icon}
                    <span className="min-w-0 flex-1">
                      <span className="flex flex-wrap items-center gap-1.5">
                        <span className="font-medium">
                          {streamKindLabel(s.codecType, t)}
                        </span>
                        <span className="text-muted-foreground">
                          {languageLabel(s, t)}
                        </span>
                        {s.title && (
                          <span className="truncate text-muted-foreground">
                            · {s.title}
                          </span>
                        )}
                      </span>
                      <span className="mt-1 flex flex-wrap gap-1">
                        {streamTechnicalBadges(s).map((badge) => (
                          <span
                            key={badge}
                            className="rounded border bg-background/60 px-1.5 py-0.5 text-[10px] font-mono text-muted-foreground"
                          >
                            {badge}
                          </span>
                        ))}
                      </span>
                    </span>
                    {s.default && (
                      <span className="shrink-0 rounded bg-primary/10 px-1.5 py-0.5 text-[10px] text-primary">
                        {t("streamSelector.default")}
                      </span>
                    )}
                    {s.forced && (
                      <span className="shrink-0 rounded bg-orange-500/10 px-1.5 py-0.5 text-[10px] text-orange-500">
                        {t("streamSelector.forced")}
                      </span>
                    )}
                    <span className="shrink-0 font-mono text-xs text-muted-foreground">
                      #{s.index}
                    </span>
                  </label>
                );
              })}
            </div>
            <p className="mt-1.5 text-xs text-muted-foreground">
              {t("scan.titleSelectedSummary", {
                selected: selectedStreamIndices.size,
                total: selectableStreams.length,
                titles: selectedTrackIndices.size,
              })}
            </p>
            {processingMappingBlocked &&
              (() => {
                const warning = verificationMessage(
                  selectedTrack,
                  activeTrackIdx,
                );
                if (!warning) return null;
                const canReverify =
                  data?.discType === "dvd" &&
                  processingMode === "remux" &&
                  selectedTrack?.verificationStatus === "failed";
                const canSwitchToRemux =
                  data?.discType === "bluray" &&
                  processingMode === "compress" &&
                  selectedTrack &&
                  (typeof selectedTrack.handbrakeTitleNumber !== "number" ||
                    selectedTrack.handbrakeTitleNumber <= 0);
                return (
                  <div className="mt-1.5 flex items-center gap-2 text-xs text-orange-400">
                    <span>{warning}</span>
                    {canReverify && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => requestReverification(activeTrackIdx)}
                      >
                        {t("scan.reVerify")}
                      </Button>
                    )}
                    {canSwitchToRemux && onSelectMode && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => onSelectMode("remux")}
                      >
                        {t("scan.switchToRemux")}
                      </Button>
                    )}
                  </div>
                );
              })()}
            {processingMode === "remux" &&
              selectedTrack.verificationStatus === "verified" &&
              (selectedTrack.verificationWarnings?.length ?? 0) > 0 && (
                <div className="mt-1.5 rounded border border-yellow-500/30 bg-yellow-500/5 px-2 py-1.5 text-xs text-yellow-300">
                  <p>{t("scan.titleVerifiedHint")}</p>
                  <ul className="mt-1 list-disc space-y-0.5 pl-4">
                    {selectedTrack.verificationWarnings?.map((warning) => (
                      <li key={warning}>{warning}</li>
                    ))}
                  </ul>
                </div>
              )}
            {processingMode === "compress" &&
              data?.discType === "dvd" &&
              verifyingTracks.has(activeTrackIdx) && (
                <p className="mt-1.5 text-xs text-muted-foreground">
                  {t("scan.readingStreams")}
                </p>
              )}
            {processingMode === "compress" &&
              data?.discType === "dvd" &&
              selectedTrack.verificationStatus === "failed" && (
                <p className="mt-1.5 text-xs text-orange-400">
                  {verificationMessage(selectedTrack, activeTrackIdx)}
                </p>
              )}
            {verifyingTracks.has(activeTrackIdx) && (
              <p className="mt-1.5 text-xs text-muted-foreground">
                {t("scan.readingStreams")}
              </p>
            )}
          </div>

          {(selectedTrack.chapters?.length ?? 0) > 0 ? (
            <div data-testid="title-level-chapter-controls">
              <div className="mb-2 flex items-center justify-between gap-2">
                <p className="text-xs font-medium text-muted-foreground">
                  {uiText.chapterInfo}
                </p>
                <div className="flex shrink-0 gap-1">
                  <button
                    type="button"
                    className="rounded border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-secondary/50"
                    onClick={() => setAllChaptersSelected(true)}
                    disabled={verifyingTracks.has(activeTrackIdx)}
                  >
                    {uiText.selectAll}
                  </button>
                  <button
                    type="button"
                    className="rounded border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-secondary/50"
                    onClick={() => setAllChaptersSelected(false)}
                    disabled={verifyingTracks.has(activeTrackIdx)}
                  >
                    {uiText.clearSelection}
                  </button>
                </div>
              </div>
              <div className="space-y-1 rounded-lg border divide-y">
                {selectedTrack.chapters?.map((chapter) => (
                  <label
                    key={chapter.id}
                    onPointerDown={(event) => event.stopPropagation()}
                    onClick={(event) => event.stopPropagation()}
                    className="flex cursor-pointer items-center gap-3 px-3 py-2 text-sm hover:bg-secondary/30"
                  >
                    <Checkbox
                      checked={selectedChapterIds.has(chapter.id)}
                      disabled={verifyingTracks.has(activeTrackIdx)}
                      onCheckedChange={() => toggleChapter(chapter.id)}
                    />
                    <span className="font-mono text-xs">#{chapter.id + 1}</span>
                    <span className="flex-1 truncate">
                      {chapter.title || t("scan.unnamedChapter")}
                    </span>
                    <span className="font-mono text-xs text-muted-foreground">
                      {fmtDuration(chapter.startSeconds)} -{" "}
                      {fmtDuration(chapter.endSeconds)}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {t("scan.durationValue", {
                        value:
                          fmtChapterDuration(
                            chapter.startSeconds,
                            chapter.endSeconds,
                          ) || t("scan.unknown"),
                      })}
                    </span>
                  </label>
                ))}
              </div>
            </div>
          ) : (
            <div className="rounded-lg border border-yellow-500/25 bg-yellow-500/5 px-3 py-2 text-sm text-muted-foreground">
              <p className="font-medium text-foreground">{uiText.noChapters}</p>
              <p className="mt-1 text-xs">{uiText.noChaptersHint}</p>
            </div>
          )}
        </div>
      </Profiler>
    );
  };

  return (
    <Profiler
      id="DiscAnalyzeDialog"
      onRender={(id, phase, actualDuration) =>
        onDiscPreviewRender(id, phase, actualDuration)
      }
    >
      <div
        className="fixed inset-x-0 bottom-0 top-36 z-50 flex items-center justify-center bg-background/70 p-3 sm:p-6"
        role="dialog"
        aria-modal="true"
      >
        <div className="w-full max-w-6xl min-w-0 h-[calc(100vh-9rem)] max-h-[calc(100vh-9rem)] rounded-xl border bg-background shadow-2xl flex flex-col">
          <div className="flex h-full min-h-0 max-h-[calc(100vh-9rem)] w-full min-w-0 flex-col">
            {/* Header */}
            <div className="flex items-center justify-between gap-3 p-4 border-b shrink-0">
              <div className="min-w-0 flex-1">
                <h3 className="flex min-w-0 items-center gap-2 font-semibold text-base">
                  <span className="truncate">{uiText.sourcePreview}</span>
                  <span className="shrink-0 rounded bg-primary/10 px-1.5 py-0.5 text-[11px] font-normal text-primary">
                    {discFolderName(discPath)}
                  </span>
                </h3>
                {data && (
                  <p className="mt-0.5 truncate text-xs text-muted-foreground">
                    {discLabel} ·{" "}
                    {t("scan.trackCount", { count: data.tracks.length })}
                    {data.sourceSizeBytes
                      ? ` · ${t("scan.sourceSize")}: ${fmtBytes(data.sourceSizeBytes)}`
                      : ""}
                    {!analysisOnly && (
                      <>
                        {" "}
                        · {t("scan.processingLabelPrefix")}
                        {processingLabel}
                      </>
                    )}
                  </p>
                )}
                <p
                  className="mt-0.5 truncate font-mono text-[11px] text-muted-foreground"
                  title={discPath}
                >
                  {discPath}
                </p>
              </div>
              <div className="flex min-w-0 shrink-0 items-center gap-1.5">
                {showModePicker && (
                  <div
                    className="flex items-center gap-1"
                    aria-label={uiText.processingMode}
                  >
                    {(["remux", "compress", "none"] as const).map((mode) => (
                      <button
                        key={mode}
                        type="button"
                        onClick={() => chooseProcessingMode(mode)}
                        className={cn(
                          "h-7 max-w-[9rem] truncate rounded-md border px-2 text-[11px] transition-colors",
                          processingMode === mode && modeChosen
                            ? "border-primary bg-primary/10 text-primary"
                            : cn(
                                "border-border text-muted-foreground hover:border-primary/50 hover:bg-secondary/40 hover:text-foreground",
                                modeSelectionAttention &&
                                  "animate-pulse border-blue-400/80 text-blue-300",
                              ),
                        )}
                        title={uiText.modes[mode].label}
                      >
                        {uiText.modes[mode].label}
                      </button>
                    ))}
                  </div>
                )}
                {analysisOnly && (
                  <div className="flex shrink-0 items-center gap-1">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={onClose}
                      className={cn(
                        "h-7 min-h-0 w-32 px-2 text-[11px]",
                        analysisOnly &&
                          selectedTrackIndices.size === 0 &&
                          "animate-pulse ring-2 ring-primary/50",
                      )}
                    >
                      {uiText.cancel}
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      onClick={confirmAnalysisSelection}
                      disabled={
                        selectedTrackIndices.size === 0 ||
                        verifyingTracks.size > 0
                      }
                      className={cn(
                        "h-7 min-h-0 w-32 px-2 text-[11px]",
                        analysisOnly &&
                          selectedTrackIndices.size === 0 &&
                          "animate-pulse ring-2 ring-primary/50",
                      )}
                    >
                      {t("scan.confirmSelection")}
                    </Button>
                  </div>
                )}
                {smartParsing ? (
                  <span
                    className="inline-flex h-7 w-32 shrink-0 items-center justify-center gap-1.5 text-xs text-amber-400"
                    title={t("scan.smartParsing")}
                  >
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    {t("scan.smartParsing")}
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={runSmartParse}
                    disabled={
                      !data ||
                      data.discType !== "dvd" ||
                      data.tracks.length === 0
                    }
                    className={cn(
                      "inline-flex h-7 w-32 shrink-0 items-center justify-center gap-1.5 rounded-md border px-2 text-[11px] transition-colors",
                      "border-amber-400/40 text-amber-400 hover:bg-amber-400/10 disabled:opacity-40 disabled:cursor-not-allowed",
                    )}
                    title={t("scan.smartParseHint")}
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    {t("scan.smartParse")}
                  </button>
                )}
              </div>
              <button
                onClick={onClose}
                className="shrink-0 p-1 rounded hover:bg-secondary/60 transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {smartNote && (
              <div className="flex items-center justify-between gap-3 border-b bg-amber-400/5 px-4 py-1.5 text-xs text-amber-500/90">
                <span className="min-w-0 truncate">{smartNote}</span>
                <button
                  type="button"
                  onClick={() => setSmartNote(null)}
                  className="shrink-0 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            )}

            {/* Body */}
            <div className="flex min-h-0 flex-1 flex-col overflow-y-auto p-4 space-y-4">
              {isLoading && (
                <div className="text-center py-12 text-muted-foreground text-sm animate-pulse">
                  {uiText.analyzingDisc}
                </div>
              )}
              {isError && (
                <div className="text-center py-12 text-destructive text-sm space-y-1">
                  <p className="font-medium">{uiText.discAnalysisFailed}</p>
                  <p className="text-xs text-muted-foreground">
                    {uiText.discAnalysisHint}
                  </p>
                </div>
              )}

              {data && (
                <>
                  <div className="grid shrink-0 gap-3 lg:grid-cols-[minmax(0,1.1fr)_minmax(18rem,0.9fr)]">
                    <div className="flex h-[220px] max-lg:h-[120px] min-w-0 flex-col overflow-hidden rounded-lg border bg-black/40 p-3">
                      <div className="mb-2 flex items-center justify-between gap-2 text-xs text-muted-foreground">
                        <span className="font-medium text-foreground">
                          {t("scan.previewTitle")}
                        </span>
                        <span>
                          {selectedTrack?.titleId ??
                            t("scan.selectTitleToPreview")}
                        </span>
                      </div>
                      <div className="min-h-0 flex flex-1 flex-col overflow-hidden rounded-lg border border-white/10 bg-black">
                        {selectedTrack?.titleId &&
                        previewByTitleId[
                          stableDiscTitleKey(
                            data.sourceFingerprint,
                            selectedTrack.titleId,
                          )
                        ]?.status === "ready" ? (
                          (() => {
                            const previewKey = stableDiscTitleKey(
                              data.sourceFingerprint,
                              selectedTrack.titleId,
                            );
                            const previewState = previewByTitleId[previewKey];
                            const previews = previewState?.previews ?? [
                              previewState?.url ?? "",
                            ];
                            const pageCount = Math.max(
                              1,
                              Math.ceil(previews.length / 2),
                            );
                            const page = Math.min(previewPage, pageCount - 1);
                            const visible = previews.slice(
                              page * 2,
                              page * 2 + 2,
                            );
                            const hasChapters =
                              (selectedTrack.chapters?.length ?? 0) > 0;
                            const canPrev = page > 0;
                            const canNext = page < pageCount - 1;
                            return (
                              <div className="flex h-full w-full flex-col">
                                <div
                                  className="flex min-h-0 flex-1 items-stretch gap-1 overflow-hidden p-1"
                                  onWheel={(event) => {
                                    if (event.deltaY > 0 && canNext)
                                      setPreviewPage((value) => value + 1);
                                    else if (event.deltaY < 0 && canPrev)
                                      setPreviewPage((value) => value - 1);
                                  }}
                                >
                                  {visible.map((preview, index) => {
                                    const previewIndex = page * 2 + index + 1;
                                    return (
                                      <div
                                        key={`${selectedTrack.titleId}-${previewIndex}`}
                                        className="relative min-w-0 flex-1"
                                      >
                                        <img
                                          src={preview}
                                          alt={`${selectedTrack.name} ${t("scan.previewLabel", { n: previewIndex })}`}
                                          className="h-full w-full rounded object-cover"
                                          loading="lazy"
                                        />
                                        <span className="absolute bottom-1 left-1 rounded bg-black/60 px-1.5 py-0.5 text-[10px] text-white/90">
                                          {hasChapters
                                            ? t("scan.chapterLabel", {
                                                n: previewIndex,
                                              })
                                            : t("scan.previewLabel", {
                                                n: previewIndex,
                                              })}
                                        </span>
                                      </div>
                                    );
                                  })}
                                  {visible.length === 1 && (
                                    <div className="min-w-0 flex-1" />
                                  )}
                                </div>
                                <div className="flex items-center justify-between px-2 pb-1.5 pt-1">
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setPreviewPage((value) =>
                                        Math.max(0, value - 1),
                                      )
                                    }
                                    disabled={!canPrev}
                                    className="rounded border border-white/15 px-2 py-0.5 text-[11px] text-white/80 hover:bg-white/10 disabled:opacity-30"
                                    aria-label={t("scan.prevPreview")}
                                  >
                                    ‹
                                  </button>
                                  <span className="text-[10px] text-white/70">
                                    {page + 1} / {pageCount}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setPreviewPage((value) =>
                                        Math.min(pageCount - 1, value + 1),
                                      )
                                    }
                                    disabled={!canNext}
                                    className="rounded border border-white/15 px-2 py-0.5 text-[11px] text-white/80 hover:bg-white/10 disabled:opacity-30"
                                    aria-label={t("scan.nextPreview")}
                                  >
                                    ›
                                  </button>
                                </div>
                                {previewState?.warning && (
                                  <p className="px-3 py-1 text-center text-[10px] text-amber-300">
                                    {previewState.warning}
                                  </p>
                                )}
                              </div>
                            );
                          })()
                        ) : previewByTitleId[
                            selectedTrack?.titleId
                              ? stableDiscTitleKey(
                                  data.sourceFingerprint,
                                  selectedTrack.titleId,
                                )
                              : ""
                          ]?.status === "loading" ? (
                          <div className="text-sm text-muted-foreground">
                            {t("scan.generatingPreview")}
                          </div>
                        ) : previewByTitleId[
                            selectedTrack?.titleId
                              ? stableDiscTitleKey(
                                  data.sourceFingerprint,
                                  selectedTrack.titleId,
                                )
                              : ""
                          ]?.status === "failed" ? (
                          <div className="px-4 text-center text-xs text-muted-foreground">
                            {t("scan.previewUnavailable")}
                            <br />
                            <span className="text-[10px]">
                              {
                                previewByTitleId[
                                  selectedTrack?.titleId
                                    ? stableDiscTitleKey(
                                        data.sourceFingerprint,
                                        selectedTrack.titleId,
                                      )
                                    : ""
                                ]?.message
                              }
                            </span>
                          </div>
                        ) : (
                          <div className="px-4 text-center text-xs text-muted-foreground">
                            {t("scan.selectTitleForPreview")}
                          </div>
                        )}
                      </div>
                      {selectedTrack && (
                        <div className="mt-2 grid grid-cols-2 gap-2 text-xs text-muted-foreground sm:grid-cols-4">
                          <span>
                            {t("scan.titleMeta", {
                              value: selectedTrack.titleId ?? "--",
                            })}
                          </span>
                          <span>
                            {t("scan.durationValue", {
                              value: fmtDuration(selectedTrack.durationSeconds),
                            })}
                          </span>
                          <span>
                            {t("scan.resolutionMeta", {
                              value:
                                selectedTrack.streams
                                  .filter((s) => s.codecType === "video")
                                  .map((s) =>
                                    s.width && s.height
                                      ? `${s.width}×${s.height}`
                                      : t("scan.unknown"),
                                  )
                                  .join(" / ") || t("scan.unknown"),
                            })}
                          </span>
                          <span>
                            {t("scan.chaptersMeta", {
                              count: selectedTrack.chapters?.length ?? 0,
                            })}
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="flex h-[220px] max-lg:h-[120px] min-w-0 flex-col overflow-y-auto rounded-lg border bg-secondary/10 p-3 text-xs">
                      <div className="mb-2 flex items-center justify-between gap-2">
                        <div className="font-medium">
                          {t("scan.selectionSummary")}
                        </div>
                        <div className="flex shrink-0 gap-1">
                          <button
                            type="button"
                            className="rounded border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-secondary/50 disabled:cursor-not-allowed disabled:opacity-40"
                            onClick={() => setAllStreamsForSelectedTitles(true)}
                            disabled={
                              selectedTrackIndices.size === 0 ||
                              Array.from(selectedTrackIndices).some((idx) =>
                                verifyingTracks.has(idx),
                              )
                            }
                          >
                            {uiText.selectAllStreams}
                          </button>
                          <button
                            type="button"
                            className="rounded border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-secondary/50 disabled:cursor-not-allowed disabled:opacity-40"
                            onClick={() =>
                              setAllStreamsForSelectedTitles(false)
                            }
                            disabled={selectedTrackIndices.size === 0}
                          >
                            {uiText.clearAllStreams}
                          </button>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-muted-foreground">
                        <span>
                          {t("scan.summaryTitle")}
                          {selectedTrackIndices.size}
                        </span>
                        <span>
                          {t("scan.summaryVideo")}
                          {selectedTrack?.streams.filter(
                            (s) =>
                              s.codecType === "video" &&
                              selectedStreamIndices.has(s.index),
                          ).length ?? 0}
                        </span>
                        <span>
                          {t("scan.summaryAudio")}
                          {selectedTrack?.streams.filter(
                            (s) =>
                              s.codecType === "audio" &&
                              selectedStreamIndices.has(s.index),
                          ).length ?? 0}
                        </span>
                        <span>
                          {t("scan.summarySubtitle")}
                          {selectedTrack?.streams.filter(
                            (s) =>
                              s.codecType === "subtitle" &&
                              selectedStreamIndices.has(s.index),
                          ).length ?? 0}
                        </span>
                        <span>
                          {t("scan.summaryChapters")}
                          {selectedChapterIds.size}
                        </span>
                        {!analysisOnly && (
                          <span>
                            {t("scan.summaryMode")}
                            {processingLabel}
                          </span>
                        )}
                      </div>
                      <div className="mt-3">
                        {renderExpandedTitleControls()}
                      </div>
                      <div className="mt-3 rounded border border-primary/20 bg-primary/5 p-2 text-muted-foreground">
                        {t("scan.outputNamingHint")}
                      </div>
                    </div>
                  </div>

                  {/* Track selector */}
                  <div className="min-h-[12rem] flex-none overflow-y-auto pr-1">
                    <div className="sticky top-0 z-10 mb-2 flex flex-wrap items-center justify-between gap-2 bg-background/95 py-1">
                      <p className="text-xs font-medium text-muted-foreground">
                        {uiText.selectTitles}
                      </p>
                      <div className="flex shrink-0 gap-1">
                        <button
                          type="button"
                          className="rounded border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-secondary/50 disabled:cursor-not-allowed disabled:opacity-40"
                          onClick={(event) => {
                            event.stopPropagation();
                            setAllDiscTitlesSelected(true);
                          }}
                          disabled={
                            verifyingTracks.size > 0 ||
                            selectableDiscTitleIndices.length === 0
                          }
                        >
                          {uiText.selectAllTitles}
                        </button>
                        <button
                          type="button"
                          className="rounded border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-secondary/50 disabled:cursor-not-allowed disabled:opacity-40"
                          onClick={(event) => {
                            event.stopPropagation();
                            setAllDiscTitlesSelected(false);
                          }}
                          disabled={selectedTrackIndices.size === 0}
                        >
                          {uiText.clearAllTitles}
                        </button>
                      </div>
                    </div>
                    {remuxCapacity?.blocked && (
                      <p className="mb-2 rounded border border-destructive/30 bg-destructive/5 px-2 py-1.5 text-xs text-destructive">
                        {t("scan.capacitySelectionBlocked")}
                      </p>
                    )}
                    <div className="space-y-1.5 pr-1">
                      <Profiler
                        id="DiscTitleList"
                        onRender={(id, phase, actualDuration) =>
                          onDiscPreviewRender(id, phase, actualDuration)
                        }
                      >
                        {trackSummaries.map((track, idx) => {
                          if (!isTrackVisibleForMode(track)) return null;
                          const isSelected = selectedTrackIndices.has(idx);
                          const isActive = idx === activeTrackIdx;
                          return (
                            <div
                              key={`${track.path}-${idx}-${track.name}`}
                              className="rounded-lg"
                            >
                              <DiscTitleRow
                                index={idx}
                                track={track}
                                isSelected={isSelected}
                                isActive={isActive}
                                isVerifying={
                                  data.discType === "dvd" &&
                                  processingMode === "remux" &&
                                  verifyingTracks.has(idx)
                                }
                                discType={data.discType}
                                onSelect={handleTrackSelect}
                                onToggleSelected={toggleTrackSelected}
                                selectionDisabled={
                                  track.availabilityStatus === "unavailable" ||
                                  (processingMode === "remux" &&
                                    data.discType === "dvd" &&
                                    !isSelected &&
                                    assessDiscRemuxCapacity({
                                      sourceBytes: data.sourceSizeBytes,
                                      tracks:
                                        data.tracks as Array<DiscTrackWithMakeMkv>,
                                      selectedIndexes: [
                                        ...selectedTrackIndices,
                                        idx,
                                      ],
                                    }).blocked)
                                }
                              />
                            </div>
                          );
                        })}
                      </Profiler>
                    </div>
                  </div>
                </>
              )}
            </div>

            {!analysisOnly &&
              !canCreateDiscJobsWithMode({
                processingMode,
                subtitleMode,
                selectedTitleCount: selectedTrackIndices.size,
              }) &&
              selectedTrackIndices.size > 0 &&
              !modeChosen && (
                <div className="px-4 pb-2 text-xs text-destructive">
                  {t("scan.modeRequired")}
                </div>
              )}

            {/* Footer */}
            {!analysisOnly && (
              <div className="p-4 border-t flex gap-2 shrink-0">
                <Button variant="outline" onClick={onClose} className="flex-1">
                  {uiText.cancel}
                </Button>
                <Button
                  onClick={handleCreate}
                  disabled={!canCreate || (showModePicker && !modeChosen)}
                  className="flex-1"
                >
                  {creating
                    ? uiText.creating
                    : !modeChosen
                      ? t("scan.chooseProcessingBeforeCreate")
                      : selectedTrackIndices.size === 0
                        ? t("scan.chooseTitleBeforeCreate")
                        : t("scan.createTaskCount", {
                            count: selectedTrackIndices.size,
                          })}
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </Profiler>
  );
}
