import { describe, expect, it } from "vitest";
import { defaultSourceBrowserExpanded, shouldShowSourceBrowser } from "./source-entry-model";

describe("source entry model", () => {
  it("shows the browser after expansion or when a directory exists", () => {
    expect(shouldShowSourceBrowser(false, "")).toBe(false);
    expect(shouldShowSourceBrowser(false, "  ")).toBe(false);
    expect(shouldShowSourceBrowser(false, "C:/media" )).toBe(true);
    expect(shouldShowSourceBrowser(true, "")).toBe(true);
  });

  it("opens the source browser by default for the smart workflow", () => {
    expect(defaultSourceBrowserExpanded("workflow")).toBe(true);
    expect(defaultSourceBrowserExpanded("compress")).toBe(false);
  });
});
