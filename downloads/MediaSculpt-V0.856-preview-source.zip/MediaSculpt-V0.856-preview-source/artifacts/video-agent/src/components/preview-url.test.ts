import { describe, expect, it } from "vitest";
import { appendPreviewParams } from "./preview-url";

describe("preview URL parameters", () => {
  it("appends seek parameters to a URL that already has query parameters", () => {
    expect(
      appendPreviewParams(
        "/api/disc/title-preview.mp4?analysisId=disc-1&titleId=handbrake%3A1",
        { seek: "1200.00" },
      ),
    ).toBe(
      "/api/disc/title-preview.mp4?analysisId=disc-1&titleId=handbrake%3A1&seek=1200.00",
    );
  });
});
