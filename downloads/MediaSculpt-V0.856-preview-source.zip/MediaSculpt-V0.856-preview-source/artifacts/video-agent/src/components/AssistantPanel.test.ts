import { describe, expect, it } from "vitest";
import { cleanAnalysisBody, hasVerifiedMetadataValue, resolveAnalysisOverview } from "../lib/assistant-analysis";

describe("cleanAnalysisBody", () => {
  it("removes the structured metadata block already shown in the info grid", () => {
    const body = [
      "这是一段影片简介。",
      "",
      "资料信息：",
      "IMDb：tt36988628",
      "豆瓣：1295644",
    ].join("\n");

    expect(cleanAnalysisBody(body)).toBe("这是一段影片简介。");
  });

  it("removes echoed external metadata fields without removing the prose", () => {
    const body = [
      "外部检索资料（来源：IMDb 资料源）：",
      "来源年份：2025",
      "英文名/原名：In the Opinion of the Censor",
      "年份：2025",
      "类型：电影",
      "评分：7.4",
      "",
      "这是一段影片简介。",
    ].join("\n");

    expect(cleanAnalysisBody(body)).toBe("这是一段影片简介。");
  });

  it("treats only non-empty non-placeholder metadata as verified", () => {
    expect(hasVerifiedMetadataValue("7.4", "未核验")).toBe(true);
    expect(hasVerifiedMetadataValue("", "未核验")).toBe(false);
    expect(hasVerifiedMetadataValue("未核验", "未核验")).toBe(false);
    expect(hasVerifiedMetadataValue(null, "未核验")).toBe(false);
  });

  it("removes markdown title/year headers and inline credits from the prose", () => {
    const body = [
      "**片名**",
      "The Making of King Arthur 2010 造就亚瑟王",
      "**年代**",
      "2010",
      "The.Making.of.King.Arthur · 造就亚瑟王 · 2010 · 纪录片 · 英国 · 约59分钟 主创栏： 本片是英国广播公司制作的一部历史纪录片。",
    ].join("\n");

    expect(cleanAnalysisBody(body)).toBe("本片是英国广播公司制作的一部历史纪录片。");
  });

  it("keeps rating and crew fields out of the overview prose", () => {
    const body = [
      "Abrahams.Valley · 亚伯拉罕山谷 · 1993 · 剧情/爱情 · 葡萄牙/法国/瑞士 · 174分钟",
      "IMDb 评分：7.1（约 2000 票）",
      "豆瓣评分：8.0（来源：豆瓣）",
      "导演：曼努埃尔·德·奥利维拉（Manoel de Oliveira）",
      "主要演员：莱昂诺尔·西尔韦拉（Leonor Silveira）、路易斯·米格尔·辛特拉（Luís Miguel Cintra）",
      "影片讲述年轻女子埃玛在亚伯拉罕山谷的庄园中成长与婚姻的故事。",
    ].join("\n");

    expect(cleanAnalysisBody(body)).toBe("影片讲述年轻女子埃玛在亚伯拉罕山谷的庄园中成长与婚姻的故事。");
  });

  it("does not persist a trailing IMDb identity line as the overview", () => {
    expect(cleanAnalysisBody([
      "影片围绕年轻女子 Ema 的婚姻与情感经历展开。",
      "IMDb 编号：tt0108471",
    ].join("\n"))).toBe("影片围绕年轻女子 Ema 的婚姻与情感经历展开。");
  });

  it("falls back when the assistant reply contains only an IMDb identity", () => {
    expect(resolveAnalysisOverview("IMDb 编号：tt0108471", "已保存的简介。")).toBe("已保存的简介。");
  });

  it("extracts the prose from the real structured assistant response", () => {
    const reply = [
      "IMDBID=tt0108471",
      "Abrahams.Valley · 亚伯拉罕山谷 · 1993 · 剧情片 · 葡萄牙/法国/瑞士 · 片长187分钟",
      "IMDb 编号：tt0108471",
      "IMDb 评分：7.2（约2,100票）",
      "豆瓣评分：8.1（来源：豆瓣，仅供参考）",
      "导演：曼努埃尔·德·奥利维拉（Manoel de Oliveira）",
      "主演：塞西莉亚·卡瓦略（Cecília Carvalho）、莱昂诺尔·西尔维拉（Leonor Silveira）",
      "内容简介：影片围绕年轻女子 Ema 的婚姻与情感经历展开。",
      "",
      "资料信息：",
      "IMDb：tt0108471",
    ].join("\n");

    expect(resolveAnalysisOverview(reply)).toBe("影片围绕年轻女子 Ema 的婚姻与情感经历展开。");
  });
});
