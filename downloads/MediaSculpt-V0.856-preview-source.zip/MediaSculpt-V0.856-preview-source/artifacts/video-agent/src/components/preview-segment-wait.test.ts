import { describe, expect, it, vi } from "vitest";
import { waitForSegmentReady } from "./preview-segment-wait";

function fakeResponse(status: number, mode?: string): Response {
  return {
    status,
    headers: {
      get: (name: string) => (name === "X-Preview-Mode" ? (mode ?? null) : null),
    },
    body: { cancel: () => Promise.resolve() },
  } as unknown as Response;
}

const noSleep = async () => {};

describe("waitForSegmentReady", () => {
  it("reports a segment only when the server marks it as one", async () => {
    const fetchImpl = vi.fn().mockResolvedValue(fakeResponse(206, "segment"));
    await expect(waitForSegmentReady("/preview", new AbortController().signal, { fetchImpl, sleep: noSleep }))
      .resolves.toBe("segment");
  });

  it("reports legacy when the server is not serving segments", async () => {
    const fetchImpl = vi.fn().mockResolvedValue(fakeResponse(200));
    await expect(waitForSegmentReady("/preview", new AbortController().signal, { fetchImpl, sleep: noSleep }))
      .resolves.toBe("legacy");
  });

  it("reports not-found at the end of the video instead of failing", async () => {
    const fetchImpl = vi.fn().mockResolvedValue(fakeResponse(404));
    await expect(waitForSegmentReady("/preview", new AbortController().signal, { fetchImpl, sleep: noSleep }))
      .resolves.toBe("not-found");
  });

  it("returns timeout, never segment, when the wait budget is exhausted", async () => {
    // Regression for the misleading media error ("错误码 4"): while the server is
    // still transcoding (425) the segment must not be treated as ready.
    const fetchImpl = vi.fn().mockResolvedValue(fakeResponse(425));
    await expect(waitForSegmentReady("/preview", new AbortController().signal, {
      fetchImpl,
      attempts: 3,
      intervalMs: 0,
      sleep: noSleep,
    })).resolves.toBe("timeout");
    expect(fetchImpl).toHaveBeenCalledTimes(3);
  });

  it("returns timeout when the request was aborted", async () => {
    const controller = new AbortController();
    controller.abort();
    const fetchImpl = vi.fn().mockResolvedValue(fakeResponse(425));
    await expect(waitForSegmentReady("/preview", controller.signal, { fetchImpl, sleep: noSleep }))
      .resolves.toBe("timeout");
    expect(fetchImpl).not.toHaveBeenCalled();
  });

  it("keeps waiting through transient network errors", async () => {
    const fetchImpl = vi.fn()
      .mockRejectedValueOnce(new Error("network reset"))
      .mockResolvedValueOnce(fakeResponse(206, "segment"));
    await expect(waitForSegmentReady("/preview", new AbortController().signal, {
      fetchImpl,
      attempts: 5,
      intervalMs: 0,
      sleep: noSleep,
    })).resolves.toBe("segment");
  });
});
