import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Check, ChevronDown, ChevronRight, ChevronUp, GripVertical, Loader2, Maximize2, Search, Sparkles } from "lucide-react";
import { useI18n } from "@/i18n";
import { cn } from "@/lib/utils";
import { cleanAnalysisBody, hasVerifiedMetadataValue } from "@/lib/assistant-analysis";
import { getAnalysisAction, hasExistingAnalysis } from "@/lib/assistant-analysis-state";
import { buildAssistantDisplayMetadata, buildMetadataRows, isPosterCandidateUsable, parseAssistantMetadataFields, type AssistantMetadataSnapshot } from "@/lib/assistant-metadata";
import type { AssistantCorrection } from "@/hooks/useAssistantAnalysis";

export type AiGenerateOptions = {
  generateReadme: boolean;
  generatePoster: boolean;
  generateReview: boolean;
};

export type ProcessingStep = "compress" | "remux" | "subtitle" | "chapterPreview";
export type SubtitleChoice = "auto" | "extract" | "whisper" | "transcribe_translate" | "skip" | "ocr" | "bilingual";

export type AssistantPreferences = {
  /** 外语名（英文片名，IMDB 等数据库对齐，单词用 . 连接） */
  titleEn: string;
  /** 中文名（豆瓣等简中平台对齐） */
  titleZh: string;
  year: number | null;
  /** IMDb 号（tt 开头）：用于提高影片识别唯一性（区分同名异年版本），与传统匹配逻辑联动 */
  imdbId: string;
  /** 有序处理流水线：默认 ① Remux → ② 字幕 → ③ 压缩；可拖动调整，每次打开恢复默认顺序 */
  processing: ProcessingStep[];
  subtitle: SubtitleChoice | null;
};

export type AssistantMetadata = {
  movieTitle?: string | null;
  movieTitleEn?: string | null;
  movieYear?: number | null;
  movieImdbId?: string | null;
  movieRating?: number | null;
  movieDirector?: string | null;
  movieGenres?: string | null;
  metadataSnapshot?: AssistantMetadataSnapshot | null;
};

const DEFAULT_PREFERENCES: AssistantPreferences = {
  titleEn: "",
  titleZh: "",
  year: null,
  imdbId: "",
  processing: [],
  subtitle: null,
};

/** 年代字段的界面占位值：仅用于灰色显示与加减按钮的起点，绝不进入请求。 */
const YEAR_PLACEHOLDER = 2010;

const DEFAULT_STEP_ORDER: ProcessingStep[] = ["remux", "subtitle", "compress", "chapterPreview"];

export type PresetOption = { id: string; label: string };

const VIDEO_EXT_RE = /\.(mkv|mp4|avi|mov|wmv|flv|m4v|ts|m2ts|vob|iso)$/i;

function extractYearFromTitle(value: string): number | null {
  const match = /(?:19|20)\d{2}/.exec(value);
  return match ? Number(match[0]) : null;
}

/** 源显示名：DVD/蓝光取光碟文件夹名（VIDEO_TS/BDMV/DVD/AUDIO_TS 等光碟结构目录则取上层影片文件夹），视频取文件名。 */
function sourceDisplayName(value: string): string {
  const parts = value.split(/[\\/]/).filter(Boolean);
  const last = parts[parts.length - 1] ?? "";
  if (/^(VIDEO_TS|BDMV|DVD|AUDIO_TS)$/i.test(last)) return parts[parts.length - 2] ?? last;
  return VIDEO_EXT_RE.test(last) ? last.replace(VIDEO_EXT_RE, "") : last;
}

function parentBasename(value: string): string {
  const parts = value.split(/[\\/]/).filter(Boolean);
  return parts[parts.length - 2] ?? "";
}

/** 年代提取顺序：源名（文件夹/文件名）→ 与片名同名的上级目录名 → null */
function yearFromSource(value: string): number | null {
  return extractYearFromTitle(sourceDisplayName(value)) ?? extractYearFromTitle(parentBasename(value));
}

/** 把显示名拆成 外语名 / 中文名 / 年代：Prisoners.of.Terpsichore.1995.特彼斯霍瑞 → … */
function splitSourceName(value: string): { titleEn: string; titleZh: string; year: number | null } {
  const year = extractYearFromTitle(value);
  const zhMatch = value.match(/[\u3400-\u9fff][\u3400-\u9fff·•\u2022\u2027\u30fb\uff65]*/);
  const titleZh = zhMatch?.[0] ?? "";
  let english = titleZh ? value.replace(titleZh, "") : value;
  english = english.replace(/(?:19|20)\d{2}/, "").replace(/^[.\s]+|[.\s]+$/g, "");
  // 剥离方括号/圆括号/花括号，避免 [2007]、[]、[rutracker] 等发布标签碎片残留
  english = english.replace(/[\[\](){}]/g, " ");
  const tagPatterns: RegExp[] = [
    /^\d{3,4}p$/i,
    /^(s\d{1,2}(e\d{1,4})?)$/i,
    /^(season|seasons|episode|episodes|series)$/i,
    /^第?\d{1,2}季$/,
    /^(19|20)\d{2}$/,
    /^(x264|x265|h264|h265|hevc|avc|av1|10bit|8bit)$/i,
    /^(aac|ac3|dts|truehd|flac|mp3|pcm|eac3|atmos)$/i,
    /^(bluray|bdrip|dvdrip|webdl|web-dl|webrip|hdtv|hdtvrip|pdtv|remux|hdr|dv|uhd|4k|2160p|1080p|720p|480p|576p|amzn|amazon)$/i,
    /^(mvgroup|rutracker|kinosvalka|yify|rarbg|fgt|ctrlhd|nzb|deflate)$/i,
    /^(org|com|net|info)$/i,
    /^part\s*\d+$/i,
    /^p\d{1,2}$/i,
    /^\d{1,2}$/,
    /^(x26[45]|h26[45]|hevc|avc|av1|web|bd|bluray|dvdrip|webrip|hdtv|remux|uhd|2160p|1080p|720p|480p|576p)-[a-z0-9]+$/i,
    /^\d{1,2}of\d{1,2}$/i,
    /^\d{1,2}x\d{1,4}$/i,
    /^(dvd5|dvd9|2dvd5|2dvd9|dvdr|bd25|bd50|bdr)$/i,
    /^(multi|rus|eng|chi|zho|ger|deu|fre|fra|spa|jpn|kor|ita|pol|cze|hun|nld|swe|nor|dan|fin|por|ara|heb|tur|tha|vie|ind)$/i,
    /^(complete|proper|repack)$/i,
    /^(mkv|mp4|avi|mov|wmv|flv|m4v|ts|m2ts|vob|iso|srt|ass|idx|sub)$/i,
    /^(cc|uk|us|criterion|criterioncollection)$/i,
  ];
  const releaseMarkerPatterns: RegExp[] = [
    /^(19|20)\d{2}$/,
    /^\d{3,4}p$/i,
    /^(s\d{1,2}(e\d{1,4})?)$/i,
    /^\d{1,2}x\d{1,4}$/i,
    /^\d{1,2}of\d{1,2}$/i,
    /^(amzn|amazon|bluray|bdrip|dvdrip|webdl|web-dl|webrip|hdtv|hdtvrip|pdtv|remux|uhd|4k|2160p|1080p|720p|480p|576p|hdr|dv|x264|x265|h264|h265|hevc|avc|av1|10bit|8bit|aac|ac3|dts|truehd|flac|mp3|pcm|eac3|atmos|dvd5|dvd9|2dvd5|2dvd9|complete|proper|repack)$/i,
  ];
  const isTag = (token: string): boolean => {
    if (tagPatterns.some((pattern) => pattern.test(token))) return true;
    if (token.includes("&")) {
      const parts = token.split("&").filter(Boolean);
      return parts.length >= 2 && parts.every((part) => tagPatterns.some((pattern) => pattern.test(part)));
    }
    return false;
  };
  const rawTokens = english.split(/[.\s_]+/)
    .filter(Boolean)
  const markerIndex = rawTokens.findIndex((token) => releaseMarkerPatterns.some((pattern) => pattern.test(token)));
  const titleTokens = markerIndex >= 0 ? rawTokens.slice(0, markerIndex) : rawTokens;
  const titleEn = titleTokens
    .filter((token) => !/[\u3400-\u9fff]/.test(token))
    .filter((token) => !isTag(token))
    .join(".");
  return { titleEn, titleZh, year };
}

/** 目录名的中文段：取末尾连续的纯中文 token（允许 . 或 · 分隔），如 唐璜.大都会歌剧院。 */
function folderChineseSegment(dirName: string): string {
  const tokens = dirName.split(".").filter(Boolean);
  const zhTokens: string[] = [];
  for (let i = tokens.length - 1; i >= 0; i--) {
    const token = tokens[i];
    if (/^[\u3400-\u9fff·•\u2022\u2027\u30fb\uff65]+$/.test(token)) {
      zhTokens.unshift(token);
    } else {
      break;
    }
  }
  return zhTokens.join(".");
}

function longestCommonPrefixLen(a: string, b: string): number {
  let i = 0;
  while (i < a.length && i < b.length && a[i] === b[i]) i += 1;
  return i;
}

/** 视频文件所在目录规则：目录英文段与文件名基本一致时，目录的中文段即视频的中文片名。 */
function folderChineseTitleForSource(sourcePath: string): string {
  if (!sourcePath) return "";
  const parts = sourcePath.split(/[\\/]/).filter(Boolean);
  const last = parts[parts.length - 1] ?? "";
  if (!VIDEO_EXT_RE.test(last)) return "";
  const dir = parentBasename(sourcePath);
  const dirZh = folderChineseSegment(dir);
  if (!dirZh) return "";
  const dirEn = dir.replace(dirZh, "").replace(/(?:19|20)\d{2}/, "").replace(/^[.\s]+|[.\s]+$/g, "");
  const fileEn = splitSourceName(sourceDisplayName(sourcePath)).titleEn;
  const norm = (value: string) => value.toLowerCase().replace(/[^a-z0-9]+/g, "");
  const dn = norm(dirEn);
  const fn = norm(fileEn);
  if (!dn || !fn || dn.length < 8 || fn.length < 8) return "";
  const common = longestCommonPrefixLen(dn, fn);
  const shorter = Math.min(dn.length, fn.length);
  return common >= 10 && common >= shorter * 0.6 ? dirZh : "";
}

function formatDuration(seconds: number): string {
  const total = Math.max(0, Math.round(seconds));
  return `${Math.floor(total / 3600)}:${String(Math.floor((total % 3600) / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
}

function Chip({ active, label, onClick, disabled = false, amber = false, title }: { active: boolean; label: string; onClick: () => void; disabled?: boolean; amber?: boolean; title?: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      title={title}
      className={cn(
        "h-7 shrink-0 rounded-md border px-2.5 text-[11px] leading-none transition-colors disabled:cursor-not-allowed",
        disabled
          ? "border-border/40 text-muted-foreground/40"
          : amber
            ? active
              ? "border-amber-400/60 bg-amber-400/15 text-amber-400"
              : "border-border/70 text-muted-foreground hover:border-primary/50 hover:text-foreground"
            : active
              ? "border-primary/60 bg-primary/20 text-primary"
              : "border-border/70 text-muted-foreground hover:border-primary/50 hover:text-foreground",
      )}
    >
      {label}
    </button>
  );
}

export function AssistantPanel({
  contextType,
  context,
  jobId,
  generateOptions,
  preferences,
  allowRemux = true,
  aiAvailable = true,
  posterUrl,
  sourceName,
  presets = [],
  selectedPresetId = null,
  allowChapterPreview = true,
  expandMode = "inline",
  analysisPlacement = "inline",
  analysisPortalTarget = null,
  promptPlacement = "toolbar",
  prompt = "",
  promptOpen = false,
  promptFocusRequest,
  promptAttention = false,
  onPromptToggle,
  onPromptFocus,
  onPromptChange,
  onAnalyze,
  analyzing = false,
  analysisResult,
  analysisError,
  analysisPosterUrl,
  metadata,
  analysisOpen = false,
  onAnalysisOpenChange,
  correction,
  onPreferencesChange,
  onGenerateOptionsChange,
  onConfirm,
  onPresetSelect,
  onOpenQualityPanel,
  batchMode = false,
  batchCount = 0,
  onBatchConfirm,
  onFeatureClick,
  confirmed = false,
  processingLocked = false,
}: {
  contextType: "workflow" | "job";
  context: Record<string, unknown>;
  jobId?: number;
  generateOptions?: AiGenerateOptions;
  preferences?: Partial<AssistantPreferences>;
  allowRemux?: boolean;
  /** 是否已配置 AI API Key：无 Key 时调用 LLM 的部分置灰不可选 */
  aiAvailable?: boolean;
  posterUrl?: string | null;
  /** 源文件/文件夹名：变化时外语名/中文名/年代自动跟随 */
  sourceName?: string | null;
  presets?: PresetOption[];
  selectedPresetId?: string | null;
  expandMode?: "inline" | "external";
  /** 仅将基本信息分析卡片挂到视频区域的覆盖层。 */
  analysisPlacement?: "inline" | "video-overlay";
  analysisPortalTarget?: HTMLElement | null;
  promptPlacement?: "toolbar" | "drawer";
  prompt?: string;
  promptOpen?: boolean;
  promptFocusRequest?: number;
  promptAttention?: boolean;
  onPromptToggle?: (open: boolean) => void;
  onPromptFocus?: () => void;
  onPromptChange?: (value: string) => void;
  onAnalyze?: (fields: { titleEn: string; titleZh: string; year: number | null; imdbId: string; processing: ProcessingStep[]; prompt: string }) => void;
  analyzing?: boolean;
  analysisResult?: string | null;
  analysisError?: string | null;
  analysisPosterUrl?: string | null;
  /** 与概要正文对应的已保存、可核验元数据快照。 */
  metadata?: AssistantMetadata;
  analysisOpen?: boolean;
  onAnalysisOpenChange?: (open: boolean) => void;
  correction?: AssistantCorrection | null;
  onPreferencesChange?: (preferences: AssistantPreferences) => void;
  onGenerateOptionsChange?: (options: AiGenerateOptions) => void;
  onConfirm?: () => void;
  onPresetSelect?: (presetId: string) => void;
  onOpenQualityPanel?: () => void;
  /** 批量模式：非批量任务时“批量确认”按钮置灰不可点击。 */
  batchMode?: boolean;
  batchCount?: number;
  /** 功能确认后高亮锁定（批量页点击功能确认后为 true，未确认保持透明无底色） */
  confirmed?: boolean;
  onBatchConfirm?: () => void;
  /** 处理方式已在光盘分析阶段确认，智能助手只展示结果，不允许再次改选。 */
  processingLocked?: boolean;
  /** 批量/详情页联动：点击处理方式/字幕/画质时通知父级展开对应下级选项。 */
  onFeatureClick?: (feature: "remux" | "subtitle" | "preset" | "chapterPreview" | null) => void;
  /** 章节预览为独立预览模式：默认可用；工作流页等不支持该动作的页面可禁用。 */
  allowChapterPreview?: boolean;
}) {
  const { t, lang } = useI18n();
  const contextSourcePath = (
    (typeof context.sourcePath === "string" && context.sourcePath.trim())
    || (typeof context.filePath === "string" && context.filePath.trim())
    || ""
  );
  const contextSourceName = contextSourcePath ? sourceDisplayName(contextSourcePath) : (sourceName ?? "").trim();
  const contextSourceYear = contextSourcePath ? yearFromSource(contextSourcePath) : null;
  const folderZh = contextSourcePath ? folderChineseTitleForSource(contextSourcePath) : "";
  const fileSplit = splitSourceName(contextSourceName);
  const initialSplit = folderZh ? { ...fileSplit, titleZh: folderZh } : fileSplit;

  const [prefs, setPrefs] = useState<AssistantPreferences>(() => {
    const merged = { ...DEFAULT_PREFERENCES, ...(preferences ?? {}) };
    return {
      ...merged,
      titleEn: initialSplit.titleEn || merged.titleEn,
      titleZh: initialSplit.titleZh || merged.titleZh,
      year: contextSourceYear ?? initialSplit.year ?? (merged.year != null && merged.year >= 1920 ? merged.year : null),
    };
  });
  const [gen, setGen] = useState<AiGenerateOptions>(
    generateOptions ?? { generateReadme: false, generatePoster: false, generateReview: false },
  );
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [inlinePanel, setInlinePanel] = useState<"quality" | null>(null);
  const [posterOpen, setPosterOpen] = useState(false);
  const [readingOpen, setReadingOpen] = useState(false);
  /** An id the assistant suggested but no provider confirmed. */
  const [unverifiedImdbId, setUnverifiedImdbId] = useState<string | null>(null);
  const [dirPosterUrl, setDirPosterUrl] = useState<string | null>(null);
  const promptInputRef = useRef<HTMLInputElement>(null);
  const promptFocusSeenRef = useRef(promptFocusRequest ?? 0);
  const analyzingSeenRef = useRef(false);
  const [promptFocusPending, setPromptFocusPending] = useState(false);
  const [retryRequested, setRetryRequested] = useState(false);
  const currentYear = new Date().getFullYear();
  const workflowIdentity = context.identity as { title?: string } | undefined;
  // A just-completed analysis is newer than any poster left in the source
  // directory. Showing the directory file first can surface a stale poster
  // from a previous, incorrectly matched title.
  // Prefer the locally saved poster after provenance validation; the remote
  // URL is only a transient fallback while the local file is being refreshed.
  // A merely suggested id fills the input for the user to accept, but it must not
  // become verified identity: only a provider match or a hand-typed id may pin a
  // poster.
  const inputImdbId = prefs.imdbId.trim();
  const verifiedImdbId = metadata?.metadataSnapshot?.imdb?.id?.trim()
    || metadata?.movieImdbId?.trim()
    || (inputImdbId && inputImdbId !== unverifiedImdbId ? inputImdbId : "");
  const posterTitleEn = metadata?.metadataSnapshot?.titleEn?.trim() || metadata?.movieTitleEn?.trim() || prefs.titleEn.trim();
  const posterYear = metadata?.metadataSnapshot?.year ?? metadata?.movieYear ?? prefs.year;
  // Local posters are gated by the saved sidecar provenance and remote ones by
  // the identity they carry. The server-returned poster stays a candidate even
  // once the id is known: dropping it there is what lost every poster.
  const effectivePoster = [dirPosterUrl, analysisPosterUrl, posterUrl]
    .find((candidate) => isPosterCandidateUsable(candidate, verifiedImdbId, posterTitleEn, posterYear)) ?? null;
  const contextSourceType = typeof context.sourceType === "string" ? context.sourceType : "";
  const contextFirstItem = Array.isArray(context.items) ? (context.items[0] as { durationSeconds?: number | null; audioTracks?: number; subtitleTracks?: number } | undefined) : undefined;
  const contextDuration = Number(contextFirstItem?.durationSeconds ?? 0);
  const displayTitle = [
    prefs.titleEn.trim(),
    prefs.year ?? "",
    prefs.titleZh.trim(),
  ].filter(Boolean).join(".") || contextSourceName || t("assistant.posterPreview");
  const analysisBody = cleanAnalysisBody(analysisResult);
  const persistedOverview = metadata?.metadataSnapshot?.overview?.trim() ?? "";
  const hasExistingResult = hasExistingAnalysis({ analysisResult, persistedOverview });
  const analysisAction = getAnalysisAction({ hasResult: hasExistingResult, analyzing: Boolean(analyzing), retryRequested });
  const metadataTitle = [metadata?.movieTitleEn?.trim(), metadata?.movieYear ?? "", metadata?.movieTitle?.trim()]
    .filter(Boolean).join(".");
  const infoTitle = (metadataTitle || displayTitle).replace(/\.{2,}/g, ".").replace(/\./g, " ").replace(/\s+/g, " ").trim();
  const unverifiedLabel = t("assistant.metadataUnverified");
  const parsedFields = parseAssistantMetadataFields(analysisResult);
  const displayMetadata = buildAssistantDisplayMetadata(metadata?.metadataSnapshot, {
    ...parsedFields,
    // Identity scraped out of the assistant prose is the least reliable
    // source; it only fills what the correction, the verified snapshot,
    // and the persisted record all leave empty.
    title: correction?.titleZh || undefined,
    titleEn: correction?.titleEn || undefined,
    year: correction?.year ?? undefined,
    imdbId: correction?.imdbId || undefined,
  }, {
    title: metadata?.movieTitle || parsedFields.title,
    titleEn: metadata?.movieTitleEn || parsedFields.titleEn,
    year: metadata?.movieYear ?? parsedFields.year,
    imdbId: metadata?.movieImdbId || parsedFields.imdbId,
    imdbRating: metadata?.movieRating,
    director: metadata?.movieDirector,
    genres: metadata?.movieGenres,
  });
  const structuredRows = buildMetadataRows(displayMetadata);
  const metadataRows = structuredRows.length > 0
    ? structuredRows.map((row) => [row.label, row.value] as const)
    : [
      [t("assistant.titleField"), infoTitle],
      [t("assistant.yearField"), metadata?.movieYear ?? prefs.year ?? ""],
      [t("assistant.imdbField"), metadata?.movieImdbId || ""],
      [t("assistant.ratingField"), metadata?.movieRating != null ? String(metadata.movieRating) : ""],
      [t("assistant.directorField"), metadata?.movieDirector || ""],
      [t("assistant.genreField"), metadata?.movieGenres || ""],
    ].filter(([, value]) => hasVerifiedMetadataValue(value, unverifiedLabel));
  // Technical facts belong to the same table as the metadata; as a loose line
  // they collided with the 绫诲瀷 (genre) row and read as a stray fragment.
  const techRows: Array<[string, string]> = [];
  if (contextSourceType) techRows.push([t("assistant.sourceTypeLabel"), contextSourceType.toUpperCase()]);
  if (contextDuration > 0) techRows.push([t("assistant.durationLabel"), formatDuration(contextDuration)]);
  if (typeof contextFirstItem?.audioTracks === "number") techRows.push([t("assistant.audioTracksLabel"), String(contextFirstItem.audioTracks)]);
  if (typeof contextFirstItem?.subtitleTracks === "number") techRows.push([t("assistant.subtitleTracksLabel"), String(contextFirstItem.subtitleTracks)]);

  const updatePrefs = (patch: Partial<AssistantPreferences>) => {
    const next = { ...prefs, ...patch };
    setPrefs(next);
    onPreferencesChange?.(next);
  };

  // 源目录已有海报（poster.jpg/folder.jpg）→ 自动显示；分析保存后稍后刷新为本地文件
  useEffect(() => {
    if (!contextSourcePath) {
      setDirPosterUrl(null);
      return;
    }
    let cancelled = false;
    const check = () => {
      const posterQuery = new URLSearchParams({ path: contextSourcePath, t: String(Date.now()) });
      const identityImdb = metadata?.metadataSnapshot?.imdb?.id?.trim() || metadata?.movieImdbId?.trim() || prefs.imdbId.trim();
      if (identityImdb) setDirPosterUrl(null);
      if (identityImdb) posterQuery.set("imdbId", identityImdb);
      if (metadata?.movieTitle?.trim() || prefs.titleZh.trim()) posterQuery.set("title", metadata?.movieTitle?.trim() || prefs.titleZh.trim());
      if (posterTitleEn) posterQuery.set("titleEn", posterTitleEn);
      if (posterYear) posterQuery.set("year", String(posterYear));
      fetch(`/api/media/poster?${posterQuery.toString()}`)
        .then((response) => { if (!cancelled) setDirPosterUrl(response.ok ? response.url : null); })
        .catch(() => { if (!cancelled) setDirPosterUrl(null); });
    };
    check();
    if (analysisPosterUrl) {
      const timer = window.setTimeout(check, 1600);
      return () => { cancelled = true; window.clearTimeout(timer); };
    }
    return () => { cancelled = true; };
  }, [contextSourcePath, analysisPosterUrl, metadata?.metadataSnapshot, metadata?.movieImdbId, metadata?.movieTitle, metadata?.movieTitleEn, metadata?.movieYear, posterTitleEn, posterYear, prefs.imdbId, prefs.titleEn, prefs.titleZh, prefs.year]);

  // 源路径一变化（或挂载时），外语名/中文名/年代立即强制跟随源文件夹/文件名
  useEffect(() => {
    if (!contextSourceName) return;
    const split = folderZh ? { ...splitSourceName(contextSourceName), titleZh: folderZh } : splitSourceName(contextSourceName);
    setPrefs((current) => ({
      ...current,
      titleEn: split.titleEn || current.titleEn,
      titleZh: split.titleZh || current.titleZh,
      year: contextSourceYear ?? split.year ?? current.year,
    }));
    onPreferencesChange?.({
      ...prefs,
      titleEn: split.titleEn || prefs.titleEn,
      titleZh: split.titleZh || prefs.titleZh,
      year: contextSourceYear ?? split.year ?? prefs.year,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [contextSourcePath]);

  // 分析校对结果回写：外语名 / 中文名 / 年代 / IMDb 号（概要预览识别到资料库条目时自动反向填充）
  useEffect(() => {
    if (!correction) return;
    // Remember that the value came from the model rather than a provider, so the
    // field can mark it unverified and the poster gate can ignore it.
    setUnverifiedImdbId(correction.imdbIdSource === "assistant" ? (correction.imdbId?.trim() || null) : null);
    setPrefs((current) => {
      const next = {
        ...current,
        titleEn: correction.titleEn ?? current.titleEn,
        titleZh: correction.titleZh ?? current.titleZh,
        year: correction.year ?? current.year,
        imdbId: correction.imdbId?.trim() ? correction.imdbId.trim() : current.imdbId,
      };
      onPreferencesChange?.(next);
      return next;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [correction]);

  const preferencesKey = JSON.stringify(preferences ?? null);
  useEffect(() => {
    if (preferences) setPrefs((current) => ({
      ...current,
      ...preferences,
      // 外语名/中文名以源同步为准；年份在有源年份时也不被覆盖
      titleEn: current.titleEn || (preferences.titleEn ?? ""),
      titleZh: current.titleZh || (preferences.titleZh ?? ""),
      year: contextSourceYear ?? (preferences.year && preferences.year >= 1920 ? preferences.year : current.year),
    }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [preferencesKey]);

  const toggleGen = (key: keyof AiGenerateOptions) => {
    const next = { ...gen, [key]: !gen[key] };
    setGen(next);
    onGenerateOptionsChange?.(next);
    if (jobId) {
      void fetch(`/api/jobs/${jobId}/ai-options`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(next),
      }).catch(() => {});
    }
  };

  const toggleProcessing = (step: ProcessingStep) => {
    if (processingLocked) return;
    const wasSelected = prefs.processing.includes(step);
    const feature: "remux" | "subtitle" | "preset" | "chapterPreview" | null = wasSelected
      ? null
      : step === "compress"
        ? "preset"
        : step === "chapterPreview"
          ? "chapterPreview"
        : step === "subtitle"
          ? "subtitle"
          : "remux";
    onFeatureClick?.(feature);
    // 四项彼此独立，均可同时选择：章节预览会作为独立预览任务与其余步骤并存，
    // 由确认逻辑（任务详情拆分为独立预览任务 / 批量页逐个建任务）保证不互相覆盖。
    const others = prefs.processing.filter((item) => item !== step);
    let nextSteps: ProcessingStep[];
    if (wasSelected) {
      nextSteps = others;
    } else {
      nextSteps = [...others, step];
    }
    // 去重 + 按固定顺序展示（重复点击不会把同一项加入两次）。
    nextSteps = Array.from(new Set(nextSteps))
      .sort((a, b) => DEFAULT_STEP_ORDER.indexOf(a) - DEFAULT_STEP_ORDER.indexOf(b));
    updatePrefs({
      processing: nextSteps,
    });
  };

  const moveProcessing = (from: number, to: number) => {
    if (processingLocked || from === to || from < 0 || to < 0) return;
    const next = [...prefs.processing];
    const [moved] = next.splice(from, 1);
    next.splice(to, 0, moved);
    updatePrefs({ processing: next });
    setDragIndex(null);
  };

  const openPanel = () => {
    onFeatureClick?.("preset");
    if (expandMode === "external") {
      onOpenQualityPanel?.();
      return;
    }
    setInlinePanel((current) => (current === "quality" ? null : "quality"));
  };

  const stepLabel = (step: ProcessingStep) => t(
    step === "compress"
      ? "assistant.optionCompress"
      : step === "chapterPreview"
        ? "assistant.optionChapterPreview"
      : step === "remux"
        ? "assistant.optionRemux"
        : "assistant.optionSubtitleOnly",
  );

  const triggerAnalyze = () => {
    onAnalyze?.({
      titleEn: prefs.titleEn,
      titleZh: prefs.titleZh,
      year: prefs.year,
      imdbId: prefs.imdbId,
      processing: prefs.processing,
      prompt,
    });
  };

  useEffect(() => {
    if (promptFocusRequest == null || promptFocusRequest === promptFocusSeenRef.current) return;
    promptFocusSeenRef.current = promptFocusRequest;
    setPromptFocusPending(true);
  }, [promptFocusRequest]);

  useEffect(() => {
    if (!promptOpen || !promptFocusPending) return;
    const frame = window.requestAnimationFrame(() => {
      promptInputRef.current?.focus();
      setPromptFocusPending(false);
    });
    return () => window.cancelAnimationFrame(frame);
  }, [promptFocusPending, promptOpen]);

  useEffect(() => {
    const justFinished = analyzingSeenRef.current && !analyzing;
    if (justFinished && !analysisError) setRetryRequested(false);
    analyzingSeenRef.current = Boolean(analyzing);
  }, [analysisError, analyzing]);

  const handleAnalysisClick = () => {
    if (analysisAction === "show-existing") {
      onAnalysisOpenChange?.(true);
      return;
    }
    if (analysisAction === "analyze") triggerAnalyze();
  };

  const handleRetryAnalysis = () => {
    setRetryRequested(true);
    onAnalysisOpenChange?.(true);
    onPromptToggle?.(true);
    onPromptFocus?.();
  };

  const factsTable = (
    <dl className="grid min-w-0 grid-cols-1 gap-y-1.5 rounded-md border border-amber-400/20 bg-amber-400/5 p-2" data-testid="assistant-facts">
      {[...metadataRows, ...techRows].map(([label, value]) => <div key={label} className="grid min-w-0 grid-cols-[max-content_minmax(0,1fr)] gap-x-2"><dt className="whitespace-nowrap font-medium text-foreground/80">{label}</dt><dd className="min-w-0 break-words whitespace-pre-wrap text-muted-foreground">{value}</dd></div>)}
    </dl>
  );
  const analysisCard = analysisOpen ? (
    <div className={cn(
      "pointer-events-auto flex w-full flex-col overflow-hidden rounded-lg border border-amber-400/25 bg-background/95 shadow-xl",
      analysisPlacement === "video-overlay" ? "m-0 h-full max-h-full" : "mt-2",
    )} data-testid="assistant-analysis">
      <div className="flex shrink-0 items-center justify-between px-2.5 py-1.5">
        <span className="flex items-center gap-1.5 text-xs font-medium text-amber-400">
          <Sparkles className="h-3.5 w-3.5" />{t("assistant.analysisTitle")}
        </span>
        <div className="flex items-center gap-1">
          {hasExistingResult && <Button type="button" size="sm" variant="ghost" className="h-6 px-2 text-[11px] text-amber-400" onClick={handleRetryAnalysis} disabled={analyzing} data-testid="assistant-retry-analysis">
            <Search className="mr-1 h-3 w-3" />{t("assistant.retryAnalysis")}
          </Button>}
          {hasExistingResult && <Button type="button" size="sm" variant="ghost" className="h-6 px-2 text-[11px] text-muted-foreground hover:text-foreground" onClick={() => setReadingOpen(true)} title={t("assistant.expandReading")} data-testid="assistant-expand-reading">
            <Maximize2 className="mr-1 h-3 w-3" />{t("assistant.expandReading")}
          </Button>}
          <Button type="button" size="icon" variant="ghost" className="h-6 w-6 text-muted-foreground hover:text-foreground" onClick={() => onAnalysisOpenChange?.(false)} aria-label={t("assistant.hideAnalysis")}>
            <ChevronUp className="h-4 w-4" />
          </Button>
        </div>
      </div>
      {hasExistingResult ? (
        <div className="flex min-h-0 min-w-0 flex-1 flex-col gap-2 overflow-hidden border-t p-3 lg:flex-row lg:gap-3">
          {/* The card carries only what the assistant toolbar does not already
              show. The toolbar owns the poster, the titles, the year and the
              IMDb input, so that rail holds scores, crew and technical facts;
              it scrolls on its own and cannot squeeze the overview. */}
          <div className="flex max-h-[45%] min-h-0 min-w-0 shrink-0 flex-col gap-2 overflow-y-auto overscroll-contain text-xs leading-relaxed lg:h-full lg:max-h-none lg:w-[17rem]" data-testid="assistant-facts-rail">
            {factsTable}
          </div>
          {/* Reading column: takes the remaining width and the full height. */}
          <div className="flex min-h-0 min-w-0 flex-1 flex-col gap-1">
            <span className="text-xs font-medium text-foreground/80">{t("assistant.overviewLabel")}</span>
            <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain rounded-md border border-border/60 bg-background/50 p-2 pr-3 text-xs leading-relaxed text-muted-foreground">
              <div className="max-w-[68ch] whitespace-pre-wrap">{analysisBody || persistedOverview}</div>
            </div>
          </div>
        </div>
      ) : (
        <div className="border-t px-3 py-2 text-xs text-muted-foreground">{t("assistant.analysisEmpty")}</div>
      )}
      {analysisError && <div className="border-t px-3 py-2 text-xs text-destructive" data-testid="assistant-analysis-error">{analysisError}</div>}
    </div>
  ) : null;

  return (
    <div
      className="rounded-lg border border-cyan-500/25 bg-cyan-500/5 p-2.5"
      data-testid="assistant-panel"
    >
      <div className="flex flex-wrap items-stretch gap-x-3 gap-y-2" data-testid="assistant-toolbar">
        {/* ① 左侧：海报 + 外语名/年代/中文名 + 来源；flex-1 撑满剩余宽度，右侧②③贴合内容宽度 */}
        <div className="flex min-w-0 flex-1 items-center gap-3">
          {effectivePoster ? (
            <button
              type="button"
              onClick={() => setPosterOpen(true)}
              title={t("assistant.posterClickToEnlarge")}
              className="group relative shrink-0"
            >
              <img
                src={effectivePoster}
                alt={t("assistant.posterPreview")}
                className="h-20 w-14 shrink-0 rounded object-cover transition-transform group-hover:scale-[1.03]"
              />
              <span className="absolute inset-0 flex items-center justify-center rounded bg-black/0 text-white opacity-0 transition group-hover:bg-black/30 group-hover:opacity-100">
                <Search className="h-4 w-4" />
              </span>
            </button>
          ) : (
            <div className="flex h-20 w-14 shrink-0 items-center justify-center rounded bg-secondary/60 text-2xl">🎬</div>
          )}
          <div className="flex min-w-0 flex-1 flex-col justify-center gap-1">
            <div className="flex items-center gap-1">
              <span className="w-12 shrink-0 text-[10px] text-muted-foreground">{t("assistant.titleEnField")}</span>
              <Input
                value={prefs.titleEn}
                onChange={(e) => updatePrefs({ titleEn: e.currentTarget.value })}
                placeholder={t("assistant.titleEnPlaceholder")}
                className="h-7 w-44 min-w-0 flex-1 text-xs"
                aria-label={t("assistant.titleEnField")}
              />
              <span className="mx-1 text-[10px] text-muted-foreground">{t("assistant.yearField")}</span>
              <button type="button" className="h-6 w-6 rounded border text-xs" onClick={() => updatePrefs({ year: Math.max(1920, (prefs.year ?? YEAR_PLACEHOLDER) - 1) })}>−</button>
              <button type="button" title={t("assistant.clearYear")} onClick={() => updatePrefs({ year: null })} className={cn("w-12 cursor-pointer text-center text-xs font-mono", prefs.year == null ? "text-muted-foreground/60" : "text-foreground")}>{prefs.year ?? YEAR_PLACEHOLDER}</button>
              <button type="button" className="h-6 w-6 rounded border text-xs" onClick={() => updatePrefs({ year: Math.min(currentYear, (prefs.year ?? YEAR_PLACEHOLDER) + 1) })}>＋</button>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-12 shrink-0 text-[10px] text-muted-foreground">{t("assistant.titleZhField")}</span>
              <Input
                value={prefs.titleZh}
                onChange={(e) => updatePrefs({ titleZh: e.currentTarget.value })}
                placeholder={t("assistant.titleZhPlaceholder")}
                className="h-7 w-44 min-w-0 flex-1 text-xs"
                aria-label={t("assistant.titleZhField")}
              />
              {contextType === "workflow" && typeof workflowIdentity?.title === "string" && workflowIdentity.title.trim() && (
                <Button type="button" size="sm" variant="outline" className="h-7 shrink-0 px-2 text-[11px]" onClick={() => updatePrefs({ titleZh: String(workflowIdentity.title) })}>
                  {t("assistant.usePlanTitle")}
                </Button>
              )}
            </div>
            <div className="flex min-w-0 items-center gap-2">
              {contextSourceName && (
                <p className="min-w-0 flex-1 truncate text-[10px] text-muted-foreground/80" title={contextSourceName}>
                  {t("assistant.sourceLabel")}<span className="ml-1 font-mono text-foreground/70">{contextSourceName}</span>
                </p>
              )}
              <label className="flex shrink-0 items-center gap-1 text-[10px] text-muted-foreground" title={t("assistant.imdbHint")}>
                <span className="font-medium text-amber-400/80">IMDb</span>
                <Input
                  value={prefs.imdbId}
                  onChange={(e) => { setUnverifiedImdbId(null); updatePrefs({ imdbId: e.currentTarget.value.trim() }); }}
                  placeholder="tt0000000"
                  className={cn("h-6 w-[6.5rem] min-w-0 px-1.5 font-mono text-[10px]", unverifiedImdbId && inputImdbId === unverifiedImdbId && "border-amber-400/60")}
                  aria-label={t("assistant.imdbField")}
                />
                {unverifiedImdbId && inputImdbId === unverifiedImdbId && (
                  <span className="shrink-0 text-[9px] text-amber-400/90">{t("assistant.metadataUnverified")}</span>
                )}
              </label>
            </div>
          </div>
        </div>
        <div className="w-px self-stretch bg-border" />

        {/* ② 右侧（上下关系）：智能生成（琥珀）在上，任务处理在下，中间横线区分；ml-auto 使其贴合右侧与③相邻 */}
        <div className="ml-auto flex shrink-0 flex-col justify-center gap-1">
          <div className="flex flex-wrap items-center gap-1" data-testid="assistant-generate-bar">
            <span className="w-14 shrink-0 text-[10px] font-medium text-amber-400">{t("assistant.generateLabel")}</span>
            {(["generateReadme", "generatePoster", "generateReview"] as const).map((key) => (
              <Chip
                key={key}
                amber
                disabled={!aiAvailable}
                title={aiAvailable ? undefined : t("assistant.aiNeedsKey")}
                active={gen[key]}
                label={t(`assistant.generate${key === "generateReadme" ? "Readme" : key === "generatePoster" ? "Poster" : "Review"}`)}
                onClick={() => toggleGen(key)}
              />
            ))}
          </div>
          <div className="h-px w-full bg-border/70" />
          <div className="flex items-center gap-1">
            <span className="w-14 shrink-0 text-[10px] text-muted-foreground">{t("assistant.processingField")}</span>
            {DEFAULT_STEP_ORDER.map((step) => {
              const selected = prefs.processing.includes(step);
              const stepIndex = prefs.processing.indexOf(step);
              const remuxDisabled = step === "remux" && !allowRemux;
              const chapterPreviewDisabled = step === "chapterPreview" && !allowChapterPreview;
              const optionDisabled = processingLocked || remuxDisabled || chapterPreviewDisabled;
              // A confirmed mode is immutable, but the selected chip must
              // remain visibly active. Only alternative modes use the muted
              // disabled treatment; otherwise the whole assistant appears
              // unavailable after the user confirms the disc mode.
              const visuallyDisabled = (processingLocked && !selected) || remuxDisabled || chapterPreviewDisabled;
              return (
                <button
                  key={step}
                  type="button"
                  disabled={optionDisabled}
                  draggable={selected && !processingLocked}
                  onDragStart={(event) => {
                    if (stepIndex < 0) return;
                    setDragIndex(stepIndex);
                    event.dataTransfer.effectAllowed = "move";
                  }}
                  onDragOver={(event) => {
                    if (selected && dragIndex !== null) event.preventDefault();
                  }}
                  onDrop={(event) => {
                    event.preventDefault();
                    if (dragIndex !== null && stepIndex >= 0) moveProcessing(dragIndex, stepIndex);
                  }}
                  onDragEnd={() => setDragIndex(null)}
                  onClick={() => toggleProcessing(step)}
                  className={cn(
                    "flex h-7 shrink-0 items-center gap-1 rounded-md border px-2.5 text-[11px] leading-none transition-colors",
                    visuallyDisabled
                      ? "cursor-not-allowed border-border/40 text-muted-foreground/40"
                      : selected
                        ? "border-primary/60 bg-primary/20 text-primary"
                        : "border-border/70 text-muted-foreground hover:border-primary/50 hover:text-foreground",
                  )}
                  title={processingLocked
                    ? t("assistant.processingLocked")
                    : chapterPreviewDisabled
                    ? t("assistant.chapterPreviewUnavailable")
                    : step === "chapterPreview"
                      ? t("assistant.chapterPreviewSeparateTask")
                      : selected
                        ? t("assistant.dragToReorder")
                        : undefined}
                >
                  {selected && <GripVertical className="h-3 w-3 opacity-60" />}
                  {stepLabel(step)}
                  {selected && <span className="font-mono text-[9px]">{stepIndex + 1}</span>}
                </button>
              );
            })}
            <span className="mx-1 w-px self-stretch bg-border" />
          </div>
        </div>
        <div className="w-px self-stretch bg-border" />

        {/* ③ 最右侧：提示词 + 分析 + 确认 + 批量确认，两行两列布置，避免溢出；紧随② 贴合右侧 */}
        <div className="grid min-w-[12rem] shrink-0 grid-cols-2 items-center justify-end gap-1">
          {promptPlacement === "toolbar" && (
            promptOpen ? (
              <div className="col-span-2 flex items-center gap-1">
                <Input
                  autoFocus
                  ref={promptInputRef}
                  disabled={!aiAvailable}
                  value={prompt}
                  onChange={(e) => onPromptChange?.(e.currentTarget.value)}
                  placeholder={t("assistant.placeholder")}
                  className={cn("h-7 min-w-0 flex-1 text-xs disabled:opacity-50", promptAttention && "border-amber-400 ring-2 ring-amber-400/40")}
                />
                <Button type="button" size="icon" variant="ghost" className="h-7 w-7 shrink-0" onClick={() => onPromptToggle?.(false)} aria-label={t("assistant.collapsePrompt")}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            ) : (
                <Button type="button" size="sm" variant="outline" disabled={!aiAvailable} className="h-7 shrink-0 px-2 text-[11px] text-amber-400 disabled:text-muted-foreground/40" onClick={() => onPromptToggle?.(true)} title={aiAvailable ? undefined : t("assistant.aiNeedsKey")}>
                  <ChevronDown className="mr-1 h-3.5 w-3.5" />{t("assistant.promptLabel")}
                </Button>
              )
          )}
          {promptPlacement !== "toolbar" && (
            <Button
              type="button"
              size="sm"
              variant="outline"
              className="h-7 shrink-0 px-2 text-[11px] text-amber-400 disabled:text-muted-foreground/40"
              onClick={() => onPromptToggle?.(!promptOpen)}
              title={promptOpen ? t("assistant.collapsePrompt") : t("assistant.promptLabel")}
              aria-label={promptOpen ? t("assistant.collapsePrompt") : t("assistant.promptLabel")}
            >
              {promptOpen ? <ChevronUp className="mr-1 h-3.5 w-3.5" /> : <ChevronDown className="mr-1 h-3.5 w-3.5" />}
              {t("assistant.promptLabel")}
            </Button>
          )}
          <Button type="button" size="sm" variant="outline" onClick={handleAnalysisClick} disabled={analyzing || (analysisAction === "analyze" && !aiAvailable)} title={aiAvailable || analysisAction === "show-existing" ? undefined : t("assistant.aiNeedsKey")} className={cn("h-7 shrink-0 px-2.5 text-[11px]", aiAvailable || analysisAction === "show-existing" ? "border-amber-400/40 text-amber-400 hover:bg-amber-400/10" : "disabled:opacity-40")} data-testid="assistant-analyze">
            {analyzing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Search className="h-3.5 w-3.5" />}
            <span className="ml-1">{retryRequested ? t("assistant.retryAnalysis") : hasExistingResult ? t("assistant.showLastAnalysis") : t("assistant.analyze")}</span>
          </Button>
          <Button type="button" size="sm" variant={confirmed ? "default" : "outline"} onClick={onConfirm} disabled={!onConfirm} className={cn("h-7 shrink-0 px-3 text-[11px]", !confirmed && "text-primary hover:bg-primary/10")} data-testid="assistant-confirm">
            <Check className="mr-1 h-3.5 w-3.5" />{t(batchMode ? "assistant.functionConfirm" : "assistant.confirm")}
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={onBatchConfirm}
            disabled={!batchMode || batchCount === 0 || !onBatchConfirm}
            title={batchMode ? t("assistant.batchConfirm", { count: batchCount }) : t("assistant.batchConfirmDisabledHint")}
            className={cn(
              "h-7 shrink-0 px-3 text-[11px]",
              batchMode && batchCount > 0 && onBatchConfirm
                ? "border-amber-400/40 text-amber-400 hover:bg-amber-400/10"
                : "border-border/40 text-muted-foreground/50",
            )}
            data-testid="assistant-batch-confirm"
          >
            <Check className="mr-1 h-3.5 w-3.5" />{t("assistant.taskQueue")}
          </Button>
        </div>
      </div>

      {/* 工作流页内联面板：画质 */}
      {expandMode === "inline" && inlinePanel === "quality" && (
        <div className="mt-2 flex flex-wrap items-center gap-1 rounded-lg border border-primary/20 bg-primary/5 px-2.5 py-2" data-testid="assistant-inline-quality">
          <span className="w-12 shrink-0 text-[10px] text-muted-foreground">{t("assistant.qualityField")}</span>
          {presets.map((preset) => (
            <Chip key={preset.id} active={selectedPresetId === preset.id} label={preset.label} onClick={() => onPresetSelect?.(preset.id)} />
          ))}
        </div>
      )}

      {analysisPlacement === "video-overlay"
        ? analysisPortalTarget && analysisCard
          ? createPortal(analysisCard, analysisPortalTarget)
          : null
        : analysisCard}

      <Dialog open={posterOpen} onOpenChange={setPosterOpen}>
        <DialogContent className="max-w-[min(92vw,42rem)] border-primary/30 bg-background/95 p-4">
          <DialogTitle className="sr-only">{t("assistant.posterPreview")}</DialogTitle>
          {effectivePoster && (
            <img src={effectivePoster} alt={t("assistant.posterPreview")} className="mx-auto max-h-[82vh] w-auto rounded object-contain" />
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={readingOpen} onOpenChange={setReadingOpen}>
        <DialogContent className="flex h-[85vh] w-[min(1100px,92vw)] max-w-none flex-col gap-3 border-amber-400/25 bg-background/95 p-4">
          <DialogTitle className="sr-only">{t("assistant.readingTitle")}</DialogTitle>
          <div className="flex min-h-0 flex-1 gap-4">
            <div className="hidden w-72 shrink-0 flex-col gap-3 overflow-y-auto overscroll-contain pr-1 text-sm sm:flex">
              {factsTable}
            </div>
            <div className="min-h-0 min-w-0 flex-1 overflow-y-auto overscroll-contain pr-2 text-sm leading-7 text-muted-foreground" data-testid="assistant-reading-overview">
              <div className="max-w-[72ch] whitespace-pre-wrap">{analysisBody || persistedOverview}</div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
