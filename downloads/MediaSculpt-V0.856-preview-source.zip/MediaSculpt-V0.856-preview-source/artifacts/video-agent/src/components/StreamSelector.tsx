import { useState, useEffect } from "react";
import { useProbeJobStreams, getProbeJobStreamsQueryKey, useUpdateDiscSettings, getGetJobQueryKey } from "@workspace/api-client-react";
import type { StreamInfo } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Disc, Disc3, FileVideo, Volume2, Subtitles, Loader2, CheckCircle2, Save, RotateCcw, Zap, Package } from "lucide-react";
import { cn } from "@/lib/utils";
import { useI18n } from "@/i18n";

interface Props {
  jobId: number;
  mediaType: string;
  processingMode: string;
  selectedStreams: string | null | undefined;
  selectedChapters?: string | null;
  subtitleMode?: string | null;
  sourcePath?: string | null;
  selectedMainTrack?: string | null;
  disabled?: boolean;
}

function langLabel(code: string | null | undefined, t: (key: string) => string) {
  if (!code) return null;
  const key = `languages.${code.toLowerCase()}`;
  const translated = t(key);
  return translated === key ? code.toUpperCase() : translated;
}

function codecBadge(stream: StreamInfo) {
  const name = stream.codecName.toUpperCase();
  const variants: Record<string, string> = {
    H264: "blue", AVC: "blue", H265: "violet", HEVC: "violet",
    AV1: "green", VP9: "green", VC1: "orange",
    DTS: "yellow", TRUEHD: "purple", EAC3: "cyan", AC3: "sky",
    AAC: "blue", FLAC: "green", OPUS: "teal", MP3: "gray",
    PGS: "orange", ASS: "orange", SRT: "orange", SUBRIP: "orange",
    HDMV_PGS_SUBTITLE: "orange",
  };
  const color = variants[name] ?? "gray";
  const colorMap: Record<string, string> = {
    blue: "bg-blue-500/20 text-blue-300 border-blue-500/30",
    violet: "bg-violet-500/20 text-violet-300 border-violet-500/30",
    green: "bg-green-500/20 text-green-300 border-green-500/30",
    orange: "bg-orange-500/20 text-orange-300 border-orange-500/30",
    yellow: "bg-yellow-500/20 text-yellow-300 border-yellow-500/30",
    purple: "bg-purple-500/20 text-purple-300 border-purple-500/30",
    cyan: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
    sky: "bg-sky-500/20 text-sky-300 border-sky-500/30",
    teal: "bg-teal-500/20 text-teal-300 border-teal-500/30",
    gray: "bg-gray-500/20 text-gray-300 border-gray-500/30",
  };
  return <span className={cn("text-[10px] font-mono px-1.5 py-0.5 rounded border", colorMap[color])}>{name}</span>;
}

function streamIcon(type: string) {
  if (type === "video") return <FileVideo className="w-4 h-4 text-blue-400 shrink-0" />;
  if (type === "audio") return <Volume2 className="w-4 h-4 text-green-400 shrink-0" />;
  if (type === "subtitle") return <Subtitles className="w-4 h-4 text-orange-400 shrink-0" />;
  return <Package className="w-4 h-4 text-gray-400 shrink-0" />;
}

export function StreamSelector({ jobId, mediaType, processingMode: initialMode, selectedStreams: initialSelected, selectedChapters: initialChapters, subtitleMode, sourcePath, selectedMainTrack, disabled }: Props) {
  const { toast } = useToast();
  const { t } = useI18n();
  const queryClient = useQueryClient();

  const [mode, setMode] = useState<"compress" | "remux">(initialMode === "remux" ? "remux" : "compress");
  const [checked, setChecked] = useState<Set<number> | null>(null); // null = all selected
  const [probed, setProbed] = useState(false);
  const [chapterChecked, setChapterChecked] = useState<Set<number> | null>(null);
  const [dvdTitles, setDvdTitles] = useState<Array<{ path: string; name: string; titleNumber?: number }>>([]);
  const [dvdTitle, setDvdTitle] = useState("");
  const [blurayPlaylists, setBlurayPlaylists] = useState<Array<{ path: string; id: string; segments?: unknown[] }>>([]);
  const [blurayPlaylist, setBlurayPlaylist] = useState("");
  useEffect(() => { if (selectedMainTrack) { if (mediaType === "dvd") setDvdTitle(selectedMainTrack); if (mediaType === "bluray") setBlurayPlaylist(selectedMainTrack); } }, [mediaType, selectedMainTrack]);

  const probe = useProbeJobStreams(jobId, { query: { enabled: false, queryKey: getProbeJobStreamsQueryKey(jobId) } });
  const updateDisc = useUpdateDiscSettings();

  // Parse initial selectedStreams when probe data arrives
  useEffect(() => {
    if (!probe.data) return;
    if (!initialSelected) {
      // null = all streams
      setChecked(null);
    } else {
      try {
        const indices = JSON.parse(initialSelected) as number[];
        setChecked(new Set(indices));
      } catch {
        setChecked(null);
      }
    }
  }, [probe.data, initialSelected]);

  useEffect(() => {
    if (!probe.data) return;
    if (!initialChapters) setChapterChecked(null);
    else {
      try { setChapterChecked(new Set(JSON.parse(initialChapters) as number[])); } catch { setChapterChecked(null); }
    }
  }, [probe.data, initialChapters]);
  useEffect(() => { if ((mediaType === "dvd" || mediaType === "bluray") && sourcePath) void fetch(`/api/disc/analyze?path=${encodeURIComponent(sourcePath)}`).then((r) => r.ok ? r.json() : null).then((data) => { setDvdTitles(data?.tracks ?? []); setBlurayPlaylists(data?.playlists ?? []); }).catch(() => {}); }, [mediaType, sourcePath]);

  const handleProbe = async () => {
    await probe.refetch();
    setProbed(true);
  };

  const streams = probe.data?.streams ?? [];
  const videoStreams = streams.filter(s => s.codecType === "video");
  const audioStreams = streams.filter(s => s.codecType === "audio");
  const subStreams = streams.filter(s => s.codecType === "subtitle");
  const otherStreams = streams.filter(s => !["video", "audio", "subtitle"].includes(s.codecType));
  const chapters = probe.data?.chapters ?? [];

  const isChecked = (idx: number) => checked === null || checked.has(idx);

  const toggle = (idx: number) => {
    if (checked === null) {
      // Was "all", now deselect this one
      const all = new Set(streams.map(s => s.index));
      all.delete(idx);
      setChecked(all);
    } else {
      const next = new Set(checked);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      // If all selected, revert to null (all)
      if (next.size === streams.length) setChecked(null);
      else setChecked(next);
    }
  };

  const selectAll = () => setChecked(null);
  const selectNone = () => setChecked(new Set());
  const toggleChapter = (id: number) => {
    const next = chapterChecked === null ? new Set(chapters.map((chapter) => chapter.id)) : new Set(chapterChecked);
    if (chapterChecked === null) next.delete(id); else if (next.has(id)) next.delete(id); else next.add(id);
    setChapterChecked(next.size === chapters.length ? null : next);
  };

  const handleSave = async () => {
    const selectedStreamsJson = checked === null ? null : JSON.stringify([...checked].sort((a, b) => a - b));
    const selectedChaptersJson = chapterChecked === null ? null : JSON.stringify([...chapterChecked].sort((a, b) => a - b));
    try {
      await updateDisc.mutateAsync({
        id: jobId,
        data: { selectedStreams: selectedStreamsJson, selectedChapters: selectedChaptersJson, processingMode: mode },
      });
      const selectedMainTrack = dvdTitle || blurayPlaylist;
      if (selectedMainTrack) await fetch(`/api/jobs/${jobId}/disc-settings`, { method: "PUT", headers: { "content-type": "application/json" }, body: JSON.stringify({ mainTrackPath: selectedMainTrack }) });
      await queryClient.invalidateQueries({ queryKey: getGetJobQueryKey(jobId) });
      toast({ title: t("streamSelector.saveSuccess"), description: t("streamSelector.saveSuccessDesc") });
    } catch (e) {
      toast({ title: t("streamSelector.saveFailed"), description: String(e), variant: "destructive" });
    }
  };

  const discIcon = mediaType === "bluray" ? <Disc3 className="w-5 h-5 text-blue-400" /> : <Disc className="w-5 h-5 text-yellow-400" />;
  const discLabel = mediaType === "bluray" ? t("streamSelector.bluray") : mediaType === "dvd" ? t("streamSelector.dvd") : t("streamSelector.iso");

  const streamCount = checked === null ? streams.length : checked.size;

  return (
    <Card className="border-blue-500/20 bg-blue-950/10">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          {discIcon}
          {t("streamSelector.sourceAndStreams")} — {discLabel}
          <Badge variant="outline" className="ml-auto text-xs font-normal">
            {streams.length > 0 ? t("streamSelector.streamCount", { count: streams.length }) : t("streamSelector.notProbed")}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="rounded-lg border border-border/60 bg-secondary/20 px-3 py-2 text-xs text-muted-foreground">
          {t("streamSelector.hint")}
        </div>
        {/* Processing mode toggle */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setMode("remux")}
            className={cn(
              "flex flex-col items-center gap-1 p-3 rounded-lg border text-sm transition-all",
              mode === "remux"
                ? "border-blue-500 bg-blue-500/10 text-blue-300"
                : "border-border text-muted-foreground hover:border-border/80",
            )}
          >
            <Zap className="w-4 h-4" />
            <span className="font-medium">{t("streamSelector.lossless")}</span>
            <span className="text-[10px] leading-tight text-center opacity-70">{t("streamSelector.losslessDesc1")}<br/>{t("streamSelector.losslessDesc2")}</span>
          </button>
          <button
            onClick={() => setMode("compress")}
            className={cn(
              "flex flex-col items-center gap-1 p-3 rounded-lg border text-sm transition-all",
              mode === "compress"
                ? "border-violet-500 bg-violet-500/10 text-violet-300"
                : "border-border text-muted-foreground hover:border-border/80",
            )}
          >
            <Package className="w-4 h-4" />
            <span className="font-medium">{t("streamSelector.reencode")}</span>
            <span className="text-[10px] leading-tight text-center opacity-70">{t("streamSelector.reencodeDesc1")}<br/>{t("streamSelector.reencodeDesc2")}</span>
          </button>
        </div>
        {mediaType === "dvd" && dvdTitles.length > 0 && <label className="block text-xs text-muted-foreground">{t("streamSelector.dvdTitle")}<select className="mt-1 w-full rounded border bg-background px-2 py-1.5 text-foreground" value={dvdTitle} onChange={(event) => setDvdTitle(event.target.value)}><option value="">{t("streamSelector.autoMainTitle")}</option>{dvdTitles.map((title) => <option key={title.path} value={title.path}>{title.name}</option>)}</select></label>}
        {mediaType === "bluray" && blurayPlaylists.length > 0 && <label className="block text-xs text-muted-foreground">{t("streamSelector.blurayPlaylist")}<select className="mt-1 w-full rounded border bg-background px-2 py-1.5 text-foreground" value={blurayPlaylist} onChange={(event) => setBlurayPlaylist(event.target.value)}><option value="">{t("streamSelector.autoMainPlaylist")}</option>{blurayPlaylists.map((playlist) => <option key={playlist.path} value={playlist.path}>{playlist.id}{t("streamSelector.segmentsCount", { count: playlist.segments?.length ?? 0 })}</option>)}</select></label>}
        <div className="rounded-lg border border-orange-500/20 bg-orange-500/5 px-3 py-2 text-xs text-muted-foreground">
          {t("streamSelector.subtitleProcessing")}<span className="font-medium text-foreground">{subtitleMode === "whisper" ? t("streamSelector.whisperOriginal") : subtitleMode === "transcribe_translate" ? t("streamSelector.whisperTranslate") : subtitleMode === "extract" ? t("streamSelector.extractEmbedded") : subtitleMode === "skip" ? t("streamSelector.skipSubtitles") : t("streamSelector.autoProcess")}</span>{t("streamSelector.selectableInScan")}
        </div>

        <Separator />

        {chapters.length > 0 && (
          <div className="space-y-2">
            <Label>{t("streamSelector.chapters")}</Label>
            {chapters.map((chapter) => (
              <label key={chapter.id} className="flex items-center gap-2 text-sm">
                <Checkbox checked={chapterChecked === null || chapterChecked.has(chapter.id)} onCheckedChange={() => toggleChapter(chapter.id)} />
                <span>{chapter.title || t("streamSelector.chapterFallback", { id: chapter.id + 1 })}</span>
              </label>
            ))}
          </div>
        )}

        {/* Stream probe section */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-muted-foreground">{t("streamSelector.streamSelection")}</p>
            {streams.length > 0 && (
              <div className="flex gap-2 text-xs">
                <button onClick={selectAll} className="text-blue-400 hover:text-blue-300">{t("streamSelector.selectAll")}</button>
                <span className="text-muted-foreground">·</span>
                <button onClick={selectNone} className="text-muted-foreground hover:text-foreground">{t("streamSelector.selectNone")}</button>
              </div>
            )}
          </div>

          {!probed ? (
            <div className="flex flex-col items-center gap-3 py-6 text-center text-muted-foreground">
              <Disc3 className="w-8 h-8 opacity-30" />
              <p className="text-sm">{t("streamSelector.probeHint")}</p>
              <Button
                variant="outline"
                size="sm"
                onClick={handleProbe}
                disabled={probe.isFetching || disabled}
              >
                {probe.isFetching ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Disc3 className="w-4 h-4 mr-2" />}
                {probe.isFetching ? t("streamSelector.probing") : t("streamSelector.startProbe")}
              </Button>
              {probe.isError && (
                <p className="text-xs text-destructive">{t("streamSelector.probeFailed", { error: String(probe.error) })}</p>
              )}
            </div>
          ) : streams.length === 0 ? (
            <div className="text-center py-4 text-sm text-muted-foreground">{t("streamSelector.noStreamsFound")}</div>
          ) : (
            <ScrollArea className="h-64 rounded-md border border-border/50 p-2">
              <div className="space-y-1">
                {/* Video streams */}
                {videoStreams.length > 0 && (
                  <div className="mb-2">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider px-1 mb-1">{t("streamSelector.video")}</p>
                    {videoStreams.map(s => (
                      <StreamRow key={s.index} stream={s} checked={isChecked(s.index)} onToggle={toggle} />
                    ))}
                  </div>
                )}
                {/* Audio streams */}
                {audioStreams.length > 0 && (
                  <div className="mb-2">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider px-1 mb-1">{t("streamSelector.audio")}</p>
                    {audioStreams.map(s => (
                      <StreamRow key={s.index} stream={s} checked={isChecked(s.index)} onToggle={toggle} />
                    ))}
                  </div>
                )}
                {/* Subtitle streams */}
                {subStreams.length > 0 && (
                  <div className="mb-2">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider px-1 mb-1">{t("streamSelector.subtitle")}</p>
                    {subStreams.map(s => (
                      <StreamRow key={s.index} stream={s} checked={isChecked(s.index)} onToggle={toggle} />
                    ))}
                  </div>
                )}
                {/* Other streams */}
                {otherStreams.length > 0 && (
                  <div className="mb-2">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider px-1 mb-1">{t("streamSelector.other")}</p>
                    {otherStreams.map(s => (
                      <StreamRow key={s.index} stream={s} checked={isChecked(s.index)} onToggle={toggle} />
                    ))}
                  </div>
                )}
              </div>
            </ScrollArea>
          )}
        </div>

        <div className="rounded-lg border border-primary/20 bg-primary/5 px-3 py-2 text-xs">
          <p className="font-medium text-foreground mb-1">{t("streamSelector.paramPreview")}</p>
          <div className="grid grid-cols-2 gap-1 text-muted-foreground">
            <span>{t("streamSelector.videoProcessing", { mode: mode === "remux" ? t("streamSelector.remuxLossless") : t("streamSelector.handbrakeCompress") })}</span>
            <span>{t("streamSelector.streams", { selected: streamCount, total: streams.length || t("streamSelector.notProbed") })}</span>
            <span>{t("streamSelector.chaptersPreview", { text: chapters.length ? (chapterChecked === null ? t("streamSelector.chaptersAll", { count: chapters.length }) : `${chapterChecked.size} / ${chapters.length}`) : t("streamSelector.chaptersNone") })}</span>
            <span>{t("streamSelector.subtitlePreview", { mode: subtitleMode === "whisper" ? t("streamSelector.whisper") : subtitleMode === "transcribe_translate" ? t("streamSelector.whisperPlusTranslate") : subtitleMode === "skip" ? t("streamSelector.skip") : t("streamSelector.auto") })}</span>
          </div>
        </div>

        {/* Summary + save */}
        <div className="flex items-center gap-3 pt-1">
          <div className="flex-1 text-sm text-muted-foreground">
            {streams.length > 0 && (
              <span>{t("streamSelector.selectedStreams", { selected: streamCount, total: streams.length })}</span>
            )}
          </div>
          {probed && (
            <Button variant="outline" size="sm" onClick={handleProbe} disabled={probe.isFetching}>
              <RotateCcw className="w-3.5 h-3.5 mr-1.5" />
              {t("streamSelector.reprobe")}
            </Button>
          )}
          <Button
            size="sm"
            onClick={handleSave}
            disabled={updateDisc.isPending || disabled}
          >
            {updateDisc.isPending
              ? <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
              : updateDisc.isSuccess
              ? <CheckCircle2 className="w-3.5 h-3.5 mr-1.5 text-green-400" />
              : <Save className="w-3.5 h-3.5 mr-1.5" />}
            {t("streamSelector.saveSettings")}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function StreamRow({ stream, checked, onToggle }: { stream: StreamInfo; checked: boolean; onToggle: (i: number) => void }) {
  const { t } = useI18n();
  const label = [
    langLabel(stream.language, t),
    stream.title,
    stream.codecType === "video" && stream.width && stream.height ? `${stream.width}×${stream.height}` : null,
    stream.codecType === "video" && stream.hdr ? "HDR" : null,
    stream.codecType === "audio" && stream.channels ? `${stream.channels}ch` : null,
    stream.codecType === "audio" && stream.channelLayout ? stream.channelLayout : null,
  ].filter(Boolean).join(" · ");

  return (
    <Label
      htmlFor={`stream-${stream.index}`}
      className={cn(
        "flex items-center gap-2.5 px-2 py-1.5 rounded cursor-pointer transition-colors",
        checked ? "hover:bg-accent/50" : "opacity-50 hover:opacity-75 hover:bg-accent/30",
      )}
    >
      <Checkbox
        id={`stream-${stream.index}`}
        checked={checked}
        onCheckedChange={() => onToggle(stream.index)}
        className="shrink-0"
      />
      {streamIcon(stream.codecType)}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5 flex-wrap">
          {codecBadge(stream)}
          {stream.hdr && (
            <span className="text-[10px] font-bold px-1 py-0.5 rounded border bg-yellow-500/20 text-yellow-300 border-yellow-500/30">HDR</span>
          )}
          {stream.default && (
            <span className="text-[10px] px-1 py-0.5 rounded border bg-gray-500/10 text-gray-400 border-gray-500/20">{t("streamSelector.default")}</span>
          )}
          {stream.forced && (
            <span className="text-[10px] px-1 py-0.5 rounded border bg-red-500/10 text-red-400 border-red-500/20">{t("streamSelector.forced")}</span>
          )}
        </div>
        {label && <p className="text-[11px] text-muted-foreground mt-0.5 truncate">{label}</p>}
      </div>
      <span className="text-[10px] text-muted-foreground/50 shrink-0">#{stream.index}</span>
    </Label>
  );
}
