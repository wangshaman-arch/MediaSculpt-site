export function appendPreviewParams(
  baseUrl: string,
  params: Record<string, string>,
): string {
  const query = new URLSearchParams(params).toString();
  if (!query) return baseUrl;
  const separator = baseUrl.includes("?")
    ? baseUrl.endsWith("?") || baseUrl.endsWith("&")
      ? ""
      : "&"
    : "?";
  return `${baseUrl}${separator}${query}`;
}
