import { useState, useEffect, useCallback, useRef } from "react";
import { createPortal } from "react-dom";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Folder, FolderOpen, ChevronRight, ArrowUp, FileVideo, HardDrive, Loader2, Monitor, Network, CornerDownRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { useI18n } from "@/i18n";

type BrowseEntry = { name: string; path: string; type?: "dir" | "file"; sizeBytes?: number; modifiedAt?: string };
type BrowseResult = { path: string; parent: string | null; entries: BrowseEntry[] };

const DRIVES_ROOT = "__drives__";
const VX_AGENT_NETWORK_PATHS = "VX_AGENT_NETWORK_PATHS";

function loadNetworkPaths(): string[] {
  try {
    const raw = window.localStorage.getItem(VX_AGENT_NETWORK_PATHS);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter((x): x is string => typeof x === "string" && x.trim().length > 0).slice(0, 8) : [];
  } catch {
    return [];
  }
}

function rememberNetworkPath(dirPath: string): void {
  try {
    const list = [dirPath, ...loadNetworkPaths().filter((x) => x !== dirPath)].slice(0, 8);
    window.localStorage.setItem(VX_AGENT_NETWORK_PATHS, JSON.stringify(list));
  } catch {
    // localStorage unavailable — ignore
  }
}

function looksLikeNetworkPath(p: string): boolean {
  const trimmed = p.trim();
  return trimmed.startsWith("\\\\") || trimmed.startsWith("//");
}

interface DirectoryPickerProps {
  value: string;
  onChange: (path: string) => void;
  placeholder?: string;
  className?: string;
}

async function fetchDir(dirPath: string): Promise<BrowseResult> {
  const res = await fetch(`/api/browse?path=${encodeURIComponent(dirPath)}`);
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.error?.message ?? body?.error ?? `HTTP ${res.status}`);
  }
  return res.json();
}

function buildSegments(currentPath: string, t: (key: string) => string): Array<{ label: string; path: string }> {
  if (currentPath === DRIVES_ROOT) return [{ label: t("component.myComputer"), path: DRIVES_ROOT }];
  const parts = currentPath.split(/[/\\]/).filter(Boolean);
  if (parts.length === 0) return [{ label: "/", path: "/" }];
  const isWindows = /^[A-Za-z]:$/.test(parts[0]);
  if (isWindows) {
    const segs: Array<{ label: string; path: string }> = [
      { label: t("component.myComputer"), path: DRIVES_ROOT },
      { label: parts[0] + "\\", path: parts[0] + "\\" },
    ];
    for (let i = 1; i < parts.length; i++) {
      const prev = segs[segs.length - 1].path;
      segs.push({ label: parts[i], path: prev + parts[i] + "\\" });
    }
    if (segs.length > 2) {
      const last = segs[segs.length - 1];
      segs[segs.length - 1] = { ...last, path: last.path.replace(/\\$/, "") };
    }
    return segs;
  }
  return parts.reduce<Array<{ label: string; path: string }>>(
    (acc, seg) => [...acc, { label: seg, path: (acc.at(-1)?.path.replace(/\/$/, "") ?? "") + "/" + seg }],
    [{ label: "/", path: "/" }]
  );
}

export function DirectoryPicker({ value, onChange, placeholder, className }: DirectoryPickerProps) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const [typedPath, setTypedPath] = useState("");
  const [currentPath, setCurrentPath] = useState<string>(DRIVES_ROOT);
  const [result, setResult] = useState<BrowseResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [quickMenuOpen, setQuickMenuOpen] = useState(false);
  const [networkPaths, setNetworkPaths] = useState<string[]>(() => loadNetworkPaths());
  const [menuAnchor, setMenuAnchor] = useState<{ top: number; left: number } | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const quickMenuRef = useRef<HTMLDivElement>(null);

  const navigate = useCallback(async (dirPath: string) => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchDir(dirPath);
      setResult(data);
      setCurrentPath(data.path);
      setTypedPath(data.path === DRIVES_ROOT ? "" : data.path);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  const handleOpen = () => {
    setTypedPath(value || "");
    setOpen(true);
    // Start browse from current value or drives root
    navigate(value || DRIVES_ROOT);
  };

  const handleGoToTyped = () => {
    if (typedPath.trim()) navigate(typedPath.trim());
  };

  const handleConfirm = () => {
    const finalPath = typedPath.trim() || currentPath;
    if (finalPath && finalPath !== DRIVES_ROOT) {
      onChange(finalPath);
      if (looksLikeNetworkPath(finalPath)) rememberNetworkPath(finalPath);
      setOpen(false);
    }
  };

  const handleToggleQuickMenu = () => {
    setNetworkPaths(loadNetworkPaths());
    setQuickMenuOpen((open) => {
      const next = !open;
      if (next && quickMenuRef.current) {
        const rect = quickMenuRef.current.getBoundingClientRect();
        setMenuAnchor({ top: rect.bottom, left: rect.right });
      }
      return next;
    });
  };

  const pickQuickPath = (dirPath: string) => {
    setQuickMenuOpen(false);
    if (dirPath && dirPath !== DRIVES_ROOT) {
      onChange(dirPath);
      if (looksLikeNetworkPath(dirPath)) rememberNetworkPath(dirPath);
    }
  };

  const openQuickMyComputer = () => {
    setQuickMenuOpen(false);
    setOpen(true);
    navigate(DRIVES_ROOT);
  };

  const openCurrentValueFolder = () => {
    setQuickMenuOpen(false);
    const target = value.trim();
    setOpen(true);
    navigate(target || DRIVES_ROOT);
  };

  const isDrivesRoot = currentPath === DRIVES_ROOT;
  const segments = buildSegments(currentPath, t);

  return (
      <div className={cn("flex w-full min-w-0 gap-2", className)}>
      <Input
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className="font-mono bg-secondary/50 flex-1"
      />
      <div className="relative shrink-0" ref={quickMenuRef}>
        <Button
          type="button"
          variant="outline"
          onClick={handleToggleQuickMenu}
          title={t("component.setPathTitle")}
          className="h-10 gap-1.5 rounded-lg px-3 transition-colors active:scale-[0.98] active:bg-primary active:text-primary-foreground"
        >
          <FolderOpen className="h-4 w-4" />
          <span className="whitespace-nowrap">{t("component.chooseDirectory")}</span>
        </Button>
        {quickMenuOpen && menuAnchor && createPortal(
          <div className="fixed inset-0 z-[120]" onMouseDown={() => setQuickMenuOpen(false)}>
          <div
            className="absolute w-72 max-w-[calc(100vw-1rem)] overflow-hidden rounded-lg border bg-popover text-popover-foreground shadow-lg"
            style={{ top: Math.min(menuAnchor.top + 6, Math.max(0, window.innerHeight - 320)), left: Math.max(8, Math.min(menuAnchor.left - 288, window.innerWidth - 296)) }}
            onMouseDown={(event) => event.stopPropagation()}
          >
            <div className="px-3 py-2 text-xs font-semibold text-muted-foreground">{t("component.quickAccess")}</div>
            <div className="px-3 pb-1 text-[11px] text-muted-foreground/80">{t("component.networkLocations")}</div>
            {networkPaths.length > 0 ? networkPaths.slice(0, 5).map((dir) => (
              <button
                key={dir}
                type="button"
                onClick={() => pickQuickPath(dir)}
                className="block w-full truncate px-3 py-1.5 text-left font-mono text-xs hover:bg-secondary/70"
                title={dir}
              >
                <Network className="mr-1.5 inline h-3.5 w-3.5 text-muted-foreground" />
                {dir}
              </button>
            )) : (
              <div className="px-3 py-1.5 text-xs text-muted-foreground/70">{t("component.noNetworkLocations")}</div>
            )}
            <div className="px-3 pb-1 pt-2 text-[11px] text-muted-foreground/80">{t("component.defaultInputFolder")}</div>
            {value.trim() ? (
              <button
                type="button"
                onClick={openCurrentValueFolder}
                className="block w-full truncate px-3 py-1.5 text-left font-mono text-xs hover:bg-secondary/70"
                title={value}
              >
                <Folder className="mr-1.5 inline h-3.5 w-3.5 text-muted-foreground" />
                {value}
              </button>
            ) : (
              <div className="px-3 py-1.5 text-xs text-muted-foreground/70">{t("component.noInputFolder")}</div>
            )}
            <button
              type="button"
              onClick={openQuickMyComputer}
              className="block w-full px-3 py-1.5 text-left text-xs hover:bg-secondary/70"
            >
              <HardDrive className="mr-1.5 inline h-3.5 w-3.5 text-muted-foreground" />
              {t("component.myComputer")}
            </button>
          </div>
          </div>,
          document.body
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="box-border w-[calc(100vw-2rem)] max-w-[calc(100vw-2rem)] max-h-[90vh] min-w-0 overflow-x-hidden overflow-y-auto sm:max-w-[680px]" data-viewport-bound="min(96vw, 680px)">
          <DialogHeader className="min-w-0">
            <DialogTitle className="flex items-center gap-2">
              <HardDrive className="h-4 w-4 text-primary" />
              {t("component.setFolderPath")}
            </DialogTitle>
          </DialogHeader>

          {/* ── Primary: manual path input ── */}
          <div className="min-w-0 space-y-2">
            <label className="text-sm font-medium">{t("component.inputPath")}</label>
            <div className="flex min-w-0 flex-wrap gap-2">
              <Input
                ref={inputRef}
                value={typedPath}
                onChange={e => setTypedPath(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleGoToTyped()}
                placeholder={t("component.pathPlaceholder")}
                className="font-mono min-w-0 flex-1"
                autoFocus
              />
              <Button type="button" variant="secondary" size="sm" onClick={handleGoToTyped} className="shrink-0 gap-1">
                <CornerDownRight className="h-3.5 w-3.5" /> {t("component.go")}
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              {t("component.pathHint")}
            </p>
          </div>

          <div className="min-w-0 border-t pt-3 space-y-2">
            <p className="text-xs text-muted-foreground font-medium">{t("component.folderBrowse")}</p>

            {/* Breadcrumb */}
            <div className="flex min-w-0 max-w-full items-center gap-0.5 flex-wrap text-xs font-mono bg-secondary/30 rounded-md px-2 py-1.5 min-h-[30px]">
              {segments.map((seg, i) => (
                <span key={seg.path + i} className="flex min-w-0 max-w-full items-center gap-0.5">
                  {i > 0 && <ChevronRight className="h-3 w-3 text-muted-foreground shrink-0" />}
                  <button
                    type="button"
                    onClick={() => navigate(seg.path)}
                    className={cn(
                      "min-w-0 max-w-full truncate px-1 rounded hover:bg-primary/20 transition-colors flex items-center gap-1",
                      i === segments.length - 1 ? "text-primary font-semibold" : "text-muted-foreground hover:text-foreground"
                    )}
                  >
                    {i === 0 && <Monitor className="h-3 w-3" />}
                    <span className="min-w-0 truncate">{seg.label}</span>
                  </button>
                </span>
              ))}
            </div>

            {/* Directory list */}
            <div className="min-w-0 max-w-full border rounded-md">
              {loading ? (
                <div className="flex items-center justify-center h-full text-muted-foreground gap-2 text-sm">
                  <Loader2 className="h-4 w-4 animate-spin" /> {t("common.loading")}
                </div>
              ) : error ? (
                <div className="p-4 text-destructive text-sm">{t("component.readFailed")}</div>
              ) : (
                <div className="p-1">
                  {result?.parent !== null && result?.parent !== undefined && (
                    <button
                      type="button"
                      onClick={() => navigate(result.parent!)}
                      className="w-full flex items-center gap-2 px-3 py-1.5 rounded-md text-sm text-muted-foreground hover:bg-secondary/60 transition-colors"
                    >
                      <ArrowUp className="h-4 w-4 shrink-0" />
                      <span className="font-mono">..</span>
                    </button>
                  )}
                  {result?.entries.length === 0 && (
                    <p className="text-center py-6 text-xs text-muted-foreground">{t("component.emptyDir")}</p>
                  )}
                  {result?.entries.map(entry => (
                    <button
                      key={entry.path}
                      type="button"
                      onClick={() => { if (entry.type !== "file") navigate(entry.path); }}
                      className="w-full flex items-center gap-2 px-3 py-1.5 rounded-md text-sm hover:bg-secondary/60 transition-colors group"
                      title={entry.type === "file" ? entry.path : undefined}
                    >
                      {isDrivesRoot
                        ? <HardDrive className="h-4 w-4 shrink-0 text-primary/80" />
                        : entry.type === "file"
                          ? <FileVideo className="h-4 w-4 shrink-0 text-sky-400" />
                          : <FolderOpen className="h-4 w-4 shrink-0 text-yellow-400" />
                      }
                      <span className={cn("font-mono truncate text-left flex-1", entry.type === "file" && "text-muted-foreground")}>{entry.name}</span>
                      {entry.type !== "file" && <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          <DialogFooter className="w-full min-w-0 flex-wrap items-center gap-2 overflow-hidden">
            <Button type="button" variant="outline" className="min-w-0" onClick={() => setOpen(false)}>{t("common.cancel")}</Button>
            <Button
              type="button"
              className="min-w-0 max-w-full"
              onClick={handleConfirm}
              disabled={!typedPath.trim() && isDrivesRoot}
            >
              <FolderOpen className="h-4 w-4 mr-2" />
              {t("component.useThisPath")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
