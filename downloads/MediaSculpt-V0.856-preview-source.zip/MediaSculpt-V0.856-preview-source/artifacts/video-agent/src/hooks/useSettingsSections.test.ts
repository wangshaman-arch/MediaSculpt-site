import { describe, expect, it } from "vitest";
import { settingsLeaveDecision, settingsSectionFromHash, settingsSectionHash } from "./useSettingsSections";

describe("useSettingsSections", () => {
  it("normalizes supported hashes and falls back to overview", () => {
    expect(settingsSectionFromHash("#compression")).toBe("compression");
    expect(settingsSectionFromHash("#unknown")).toBe("overview");
    expect(settingsSectionFromHash("")).toBe("overview");
  });

  it("builds a stable hash for section navigation", () => {
    expect(settingsSectionHash("overview")).toBe("");
    expect(settingsSectionHash("tools")).toBe("#tools");
  });

  it("requires confirmation only when there are unsaved changes", () => {
    expect(settingsLeaveDecision(false, { kind: "section", section: "tools" })).toEqual({ action: "apply", target: { kind: "section", section: "tools" } });
    expect(settingsLeaveDecision(true, { kind: "nav", path: "/jobs" })).toEqual({ action: "confirm", target: { kind: "nav", path: "/jobs" } });
  });
});
