import { describe, expect, it } from "vitest";
import { jobActionUrl } from "./useJobActions";

describe("useJobActions", () => {
  it("builds encoded job action endpoints", () => {
    expect(jobActionUrl(42, "pause")).toBe("/api/jobs/42/pause");
    expect(jobActionUrl(7, "cancel")).toBe("/api/jobs/7/cancel");
  });
});
