import { useCallback, useEffect, useState } from "react";
import { useLocation } from "wouter";
import { setNavigationGuard } from "../lib/navigation-guard";

export type SettingsSection = "overview" | "tools" | "directories" | "compression" | "subtitles" | "ai" | "system" | "tuning" | "tuningPrompts";
export type SettingsLeaveTarget = { kind: "nav"; path: string } | { kind: "section"; section: SettingsSection };

export function settingsSectionFromHash(hash: string): SettingsSection {
  const key = hash.replace(/^#/, "");
  switch (key) {
    case "tools":
    case "directories":
    case "compression":
    case "subtitles":
    case "ai":
    case "system":
    case "tuning":
    case "tuningPrompts":
      return key;
    default:
      return "overview";
  }
}

export function settingsSectionHash(section: SettingsSection): string {
  return section === "overview" ? "" : `#${section}`;
}

export function settingsLeaveDecision(dirty: boolean, target: SettingsLeaveTarget): { action: "apply" | "confirm"; target: SettingsLeaveTarget } {
  return { action: dirty ? "confirm" : "apply", target };
}

export function useSettingsSections(input: {
  dirty: boolean;
  save: () => Promise<boolean>;
  discard: () => void;
}) {
  const [, setLocation] = useLocation();
  const [section, setSection] = useState<SettingsSection>(() => (
    typeof window === "undefined" ? "overview" : settingsSectionFromHash(window.location.hash)
  ));
  const [leaveTarget, setLeaveTarget] = useState<SettingsLeaveTarget | null>(null);
  const [pendingLeave, setPendingLeave] = useState<SettingsLeaveTarget | null>(null);

  useEffect(() => {
    const update = () => setSection(settingsSectionFromHash(window.location.hash));
    window.addEventListener("hashchange", update);
    return () => window.removeEventListener("hashchange", update);
  }, []);

  const applySection = useCallback((next: SettingsSection) => {
    setSection(next);
    window.location.hash = settingsSectionHash(next);
  }, []);

  const clearLeaveRequest = useCallback(() => {
    setLeaveTarget(null);
    setPendingLeave(null);
  }, []);

  const requestLeave = useCallback((target: SettingsLeaveTarget) => {
    const decision = settingsLeaveDecision(input.dirty, target);
    if (decision.action === "apply") {
      if (target.kind === "section") applySection(target.section);
      else setLocation(target.path);
      return;
    }
    setPendingLeave(target);
    setLeaveTarget(target);
  }, [applySection, input.dirty, setLocation]);

  const requestSectionChange = useCallback((next: SettingsSection) => {
    requestLeave({ kind: "section", section: next });
  }, [requestLeave]);

  const resolveLeave = useCallback(async (saveChanges: boolean) => {
    const target = pendingLeave ?? leaveTarget;
    if (!target) return;
    if (saveChanges) {
      if (!await input.save()) return;
    } else {
      input.discard();
    }
    clearLeaveRequest();
    setNavigationGuard(null);
    if (target.kind === "section") applySection(target.section);
    else setLocation(target.path);
  }, [applySection, clearLeaveRequest, input, leaveTarget, pendingLeave, setLocation]);

  useEffect(() => {
    if (!input.dirty) {
      setNavigationGuard(null);
      return;
    }
    setNavigationGuard((to) => {
      requestLeave({ kind: "nav", path: to });
      return false;
    });
    return () => setNavigationGuard(null);
  }, [input.dirty, requestLeave]);

  useEffect(() => {
    if (!input.dirty) return;
    const handler = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [input.dirty]);

  return { section, applySection, requestSectionChange, leaveTarget, resolveLeave, clearLeaveRequest };
}
