import { describe, expect, it } from "vitest";
import {
  getInitialWorkbenchTab,
  resolveWorkbenchDirectory,
  selectWorkbenchTab,
} from "./useWorkbenchState";

describe("useWorkbenchState", () => {
  it("reads a supported tab from the URL and defaults to workflow", () => {
    expect(getInitialWorkbenchTab("/scan?tab=remux")).toBe("remux");
    expect(getInitialWorkbenchTab("/scan?tab=unknown")).toBe("workflow");
    expect(getInitialWorkbenchTab("/scan")).toBe("workflow");
  });

  it("maps the configured scan directory to the host path", () => {
    expect(resolveWorkbenchDirectory({
      watchDirectory: "/media/downloads",
      hostDownloadsPath: "H:\\Movies",
    })).toBe("H:\\Movies");
    expect(resolveWorkbenchDirectory(null)).toBe("/media/downloads");
  });

  it("resets subtitle mode only when the selected tab requires it", () => {
    expect(selectWorkbenchTab("remux", "auto")).toEqual({ tab: "remux", subtitleMode: "skip" });
    expect(selectWorkbenchTab("none", "skip")).toEqual({ tab: "none", subtitleMode: "auto" });
    expect(selectWorkbenchTab("compress", "extract")).toEqual({ tab: "compress", subtitleMode: "extract" });
  });
});
