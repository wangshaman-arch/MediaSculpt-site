import { OCR_ENGINE_KEY, OCR_LANGUAGE_KEY } from "./brand-storage";

// OCR preset storage keys and the full language list used by the workbench
// picker. Codes are tesseract-style so the server can map them directly.
export { OCR_ENGINE_KEY, OCR_LANGUAGE_KEY };

export const OCR_LANGUAGE_CODES = [
  "eng", "chi_sim", "chi_tra", "jpn", "kor", "rus", "deu", "fra", "spa",
  "por", "ita", "nld", "pol", "tur", "ara", "heb", "tha", "vie", "ind", "msa",
  "ukr", "hun", "ces", "ell", "swe", "nor", "dan", "fin", "ron", "bul", "slv",
  "hrv", "srp", "slk", "lit", "lva", "est", "cat", "glg", "eus", "fas", "hin",
  "ben", "tam", "tel", "kan", "mal", "mar", "guj", "pan", "urd",
] as const;

export type OcrLanguageCode = (typeof OCR_LANGUAGE_CODES)[number];

/** Human label for an OCR language preset ("auto" or a tesseract-style code). */
export function ocrLanguageLabel(code: string | null | undefined, t: (key: string) => string): string {
  if (!code || code === "auto") return t("ocr.languageAuto");
  return t(`ocr.languageNames.${code}`);
}

/** Human label for an OCR engine preset. */
export function ocrEngineLabel(engine: string | null | undefined, t: (key: string) => string): string {
  switch (engine ?? "auto") {
    case "llm": return t("ocr.engineLlm");
    case "tesseract": return t("ocr.engineTesseract");
    case "rapidocr": return t("ocr.engineRapidOcr");
    case "subtitleedit": return t("ocr.engineSubtitleEdit");
    default: return t("ocr.engineAuto");
  }
}
