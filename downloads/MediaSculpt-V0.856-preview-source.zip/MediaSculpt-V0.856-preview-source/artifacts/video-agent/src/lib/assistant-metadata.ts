export type AssistantMetadataSnapshot = {
  identityStatus: "confirmed" | "probable" | "candidate" | "unknown";
  title?: string;
  titleEn?: string;
  year?: number;
  imdb?: { id?: string; rating?: number; votes?: number };
  tmdb?: { rating?: number; votes?: number };
  douban?: { id?: string; rating?: number };
  rottenTomatoes?: number;
  metacritic?: number;
  director?: string;
  cast?: string[];
  genres?: string;
  runtimeMinutes?: number;
  overview?: string;
  source?: string;
  sourceLabels: string[];
  /** Crew the assistant credited under its own label (缂栧墽/鎽勫奖/閰嶄箰/鍒剁墖鈥?. */
  credits?: Array<{ label: string; value: string }>;
};

export type MetadataDisplayRow = { label: string; value: string; priority?: "rating" | "fact" };

export type AssistantMetadataFields = {
  title?: string;
  titleEn?: string;
  year?: number;
  imdbId?: string;
  imdbRating?: number;
  imdbVotes?: number;
  doubanRating?: number;
  director?: string;
  cast?: string[];
  genres?: string;
  runtimeMinutes?: number;
};

export type AssistantMetadataFallbacks = {
  title?: string | null;
  titleEn?: string | null;
  year?: number | null;
  imdbId?: string | null;
  imdbRating?: number | null;
  director?: string | null;
  genres?: string | null;
};

const FIELD_LABELS = /^(?:片名|标题|英文名(?:\/原名)?|英文名|原名|中文名|IMDb|IMDB|IMDb\s*(?:编号|ID|评分|Rating)|IMDB\s*(?:编号|ID|评分|Rating)|豆瓣评分|Douban\s*评分|评分|Rating|年份|年代|Year|导演|Director|编剧|主要演员|主演|演员|Cast|类型|题材|Genres?|片长|时长|Runtime)\s*$/i;

function cleanMetadataLine(line: string): string {
  return line
    .trim()
    .replace(/^#{1,6}\s*/, "")
    .replace(/^(?:[-+*]|\d+[.)])\s+/, "")
    .replace(/^>\s*/, "")
    .replace(/^[*_]{1,3}/, "")
    .replace(/[*_]{1,3}([:：]?)$/, "$1")
    .replace(/^\x60|\x60$/g, "")
    .trim();
}

type MetadataFieldKey = "title" | "titleEn" | "imdbId" | "year" | "imdbRating" | "doubanRating" | "director" | "cast" | "genres" | "runtimeMinutes";

function fieldKey(label: string): MetadataFieldKey | null {
  const cleaned = cleanMetadataLine(label).replace(/[：:]\s*$/, "").trim().toLowerCase();
  // The assistant also emits machine keys (TITLE_EN=, TITLE_ZH=) that the
  // human-readable label list below does not cover; without these a reply
  // carrying the machine block lost both its English and Chinese titles.
  if (/^title_en$/i.test(cleaned)) return "titleEn";
  if (/^title_zh$/i.test(cleaned)) return "title";
  if (!FIELD_LABELS.test(cleaned)) return null;
  if (/^片名$|^标题$/.test(cleaned)) return "title";
  if (/^英文名|^原名/.test(cleaned)) return "titleEn";
  if (/^中文名/.test(cleaned)) return "title";
  if (/^imdb\s*(?:评分|rating)$/i.test(cleaned) || /^评分$|^rating$/i.test(cleaned)) return "imdbRating";
  if (/^(?:豆瓣评分|douban\s*评分)$/i.test(cleaned)) return "doubanRating";
  if (/^imdb/.test(cleaned)) return "imdbId";
  if (/^(?:年份|年代|year)$/i.test(cleaned)) return "year";
  // 编剧 is a separate credit: folding it into director credited screenwriters
  // as directors. The server extracts it into the credits list instead.
  if (/^(?:导演|director)$/i.test(cleaned)) return "director";
  if (/^(?:主要演员|主演|演员|cast)$/i.test(cleaned)) return "cast";
  if (/^(?:类型|题材|genres?)$/i.test(cleaned)) return "genres";
  if (/^(?:片长|时长|runtime)$/i.test(cleaned)) return "runtimeMinutes";
  return null;
}

function assignMetadataField(fields: AssistantMetadataFields, key: ReturnType<typeof fieldKey>, rawValue: string): void {
  const value = cleanMetadataLine(rawValue).replace(/^[：:]\s*/, "").trim();
  if (!key || !value || /^(待确认|未知|未找到|未检索到|N\/?A)$/i.test(value)) return;
  // A machine marker (YEAR=1989, TITLE_EN=..., IMDBID=tt...) is a field of its
  // own; storing it as a display value is how "YEAR=1989" became a title.
  if (/^[A-Z][A-Z0-9_]{2,}\s*[\uFF1A:=]/.test(value)) return;
  if (key === "imdbRating" || key === "doubanRating") {
    const rating = Number(/\d+(?:\.\d+)?/.exec(value)?.[0] ?? NaN);
    if (Number.isFinite(rating) && rating > 0) fields[key] = rating;
    if (key === "imdbRating") {
      const votes = Number(/[\d,]+\s*票/.exec(value)?.[0]?.replace(/[^\d]/g, "") ?? NaN);
      if (Number.isFinite(votes) && votes > 0) fields.imdbVotes = votes;
    }
  } else if (key === "director") {
    fields.director = value;
  } else if (key === "cast") {
    fields.cast = value.split(/[、,，;；]/)
      .map((item) => item.replace(/（[^）]*）/g, "").trim())
      .filter(Boolean)
      .slice(0, 12);
  } else if (key === "genres") {
    fields.genres = value;
  } else if (key === "runtimeMinutes") {
    const minutes = Number(/\d+/.exec(value)?.[0] ?? NaN);
    if (Number.isFinite(minutes) && minutes > 0) fields.runtimeMinutes = minutes;
  } else if (key === "imdbId") {
    const imdbId = /\btt\d{7,8}\b/i.exec(value)?.[0];
    if (imdbId) fields.imdbId = imdbId;
  } else if (key === "year") {
    const year = /\b((?:19|20)\d{2})\b/.exec(value)?.[1];
    if (year) fields.year = Number(year);
  } else if (key === "title") {
    const parts = value.split(/\s*\/\s*/).map((part) => part.trim()).filter(Boolean);
    if (parts.length >= 2) {
      fields.titleEn = fields.titleEn || parts[0];
      fields.title = parts.slice(1).join(" / ");
    } else {
      fields.title = value;
    }
  } else {
    fields.titleEn = value;
  }
}

/** Parse common LLM metadata layouts without allowing them to leak into prose. */
export function parseAssistantMetadataFields(raw: string | null | undefined): AssistantMetadataFields {
  if (!raw) return {};
  const lines = raw.replace(/\r/g, "").split("\n");
  const fields: AssistantMetadataFields = {};
  for (let index = 0; index < lines.length; index += 1) {
    const line = cleanMetadataLine(lines[index]);
    if (!line) continue;
    const inline = /^(.+?)\s*[:：=]\s*(.+)$/.exec(line);
    if (inline) {
      assignMetadataField(fields, fieldKey(inline[1]), inline[2]);
      continue;
    }
    const key = fieldKey(line);
    if (!key) continue;
    for (let next = index + 1; next < lines.length; next += 1) {
      const candidate = cleanMetadataLine(lines[next]);
      if (!candidate) continue;
      if (FIELD_LABELS.test(candidate.replace(/[：:]\s*$/, "").trim())) break;
      const candidateInline = /^(.+?)\s*[\uFF1A:=]\s*(.+)$/.exec(candidate);
      // A following TITLE_EN=/YEAR=/IMDBID= line belongs to its own field, not
      // to this bare label; consuming it here is the reported title bug.
      if (candidateInline && fieldKey(candidateInline[1])) break;
      assignMetadataField(fields, key, candidate);
      break;
    }
  }
  return fields;
}

/** Merge provider metadata with display-only fields returned by the assistant. */
export function mergeAssistantMetadata(
  metadata: AssistantMetadataSnapshot | null | undefined,
  fields: AssistantMetadataFields,
): AssistantMetadataSnapshot | null {
  if (!metadata && Object.keys(fields).length === 0) return null;
  const merged: AssistantMetadataSnapshot = {
    identityStatus: metadata?.identityStatus ?? "candidate",
    sourceLabels: metadata?.sourceLabels ?? [],
    ...metadata,
  };
  if (fields.title) merged.title = fields.title;
  if (fields.titleEn) merged.titleEn = fields.titleEn;
  if (fields.year) merged.year = fields.year;
  if (fields.imdbId) merged.imdb = { ...merged.imdb, id: fields.imdbId };
  if (fields.imdbRating != null || fields.imdbVotes != null || merged.imdb) {
    merged.imdb = { ...merged.imdb, rating: fields.imdbRating ?? merged.imdb?.rating, votes: fields.imdbVotes ?? merged.imdb?.votes };
  }
  if (fields.doubanRating != null || merged.douban) {
    merged.douban = { ...merged.douban, rating: fields.doubanRating ?? merged.douban?.rating };
  }
  if (fields.director) merged.director = fields.director;
  if (fields.cast?.length) merged.cast = fields.cast;
  if (fields.genres) merged.genres = fields.genres;
  if (fields.runtimeMinutes) merged.runtimeMinutes = fields.runtimeMinutes;
  return merged;
}

/** Combine the latest assistant fields with the persisted job metadata for display. */
export function buildAssistantDisplayMetadata(
  metadata: AssistantMetadataSnapshot | null | undefined,
  fields: AssistantMetadataFields,
  fallbacks: AssistantMetadataFallbacks = {},
): AssistantMetadataSnapshot | null {
  return mergeAssistantMetadata(metadata, {
    ...fields,
    title: fields.title ?? metadata?.title ?? fallbacks.title ?? undefined,
    titleEn: fields.titleEn ?? metadata?.titleEn ?? fallbacks.titleEn ?? undefined,
    year: fields.year ?? metadata?.year ?? fallbacks.year ?? undefined,
    imdbId: fields.imdbId ?? metadata?.imdb?.id ?? fallbacks.imdbId ?? undefined,
    imdbRating: fields.imdbRating ?? fallbacks.imdbRating ?? undefined,
    director: fields.director ?? fallbacks.director ?? undefined,
    genres: fields.genres ?? fallbacks.genres ?? undefined,
  });
}

function formatVotes(value?: number): string {
  return typeof value === "number" && Number.isFinite(value) && value > 0
    ? `（${Math.round(value).toLocaleString("zh-CN")} 票）`
    : "";
}

function formatRating(value?: number, scale = "/100"): string {
  return typeof value === "number" && Number.isFinite(value) && value > 0
    ? `${value.toFixed(1)}${scale}`
    : "";
}

/** Ordered, non-empty rows. Ratings stay first so long facts cannot push them below the fold. */
export function buildMetadataRows(metadata?: AssistantMetadataSnapshot | null): MetadataDisplayRow[] {
  if (!metadata) return [];
  const rows: MetadataDisplayRow[] = [];
  // The assistant toolbar already shows the poster, both titles, the year and an
  // IMDb input, so this table carries only what it does not: scores, crew,
  // genres, runtime and technical facts. Identity rows here duplicated it.
  if (metadata.imdb?.rating != null) {
    const rating = formatRating(metadata.imdb.rating, "/10");
    rows.push({ label: "IMDb", value: [rating, formatVotes(metadata.imdb.votes)].filter(Boolean).join(" "), priority: "rating" });
  }
  if (metadata.tmdb?.rating != null) rows.push({ label: "TMDb", value: [formatRating(metadata.tmdb.rating, "/10"), formatVotes(metadata.tmdb.votes)].filter(Boolean).join(" "), priority: "rating" });
  if (metadata.douban?.rating != null || metadata.douban?.id) {
    rows.push({ label: "豆瓣", value: [formatRating(metadata.douban.rating, "/10"), metadata.douban?.id ? `ID ${metadata.douban.id}` : ""].filter(Boolean).join(" "), priority: "rating" });
  }
  if (metadata.rottenTomatoes != null) rows.push({ label: "烂番茄", value: formatRating(metadata.rottenTomatoes), priority: "rating" });
  if (metadata.metacritic != null) rows.push({ label: "Metacritic", value: formatRating(metadata.metacritic), priority: "rating" });
  // No 片名 / 年份 rows: the assistant toolbar edits exactly those two fields.
  if (metadata.director) rows.push({ label: "导演", value: metadata.director, priority: "fact" });
  if (metadata.cast?.length) rows.push({ label: "主要演员", value: metadata.cast.join("、"), priority: "fact" });
  if (metadata.genres) rows.push({ label: "类型", value: metadata.genres, priority: "fact" });
  if (metadata.runtimeMinutes) rows.push({ label: "片长", value: `${metadata.runtimeMinutes} 分钟`, priority: "fact" });
  // Crew the reply credited separately stays in the same table as the rest,
  // instead of floating inside the prose block.
  for (const credit of metadata.credits ?? []) {
    if (credit.value.trim()) rows.push({ label: credit.label, value: credit.value, priority: "fact" });
  }
  return rows.filter((row) => row.value.trim().length > 0);
}

export function parseAssistantMetadata(raw: unknown): AssistantMetadataSnapshot | null {
  if (typeof raw !== "string" || !raw.trim()) return null;
  try {
    const parsed = JSON.parse(raw) as Partial<AssistantMetadataSnapshot>;
    if (!parsed || typeof parsed !== "object" || !Array.isArray(parsed.sourceLabels)) return null;
    return parsed as AssistantMetadataSnapshot;
  } catch {
    return null;
  }
}

/** A known IMDb identity may only use a poster URL carrying the same identity. */
export function isPosterIdentityBound(url: string | null | undefined, imdbId?: string | null, titleEn?: string | null, year?: number | null): boolean {
  if (!url) return false;
  const expected = imdbId?.trim().toLowerCase();
  const expectedTitle = (titleEn ?? "").trim().toLowerCase().replace(/[^a-z0-9\u3400-\u9fff]+/g, "");
  const hasIdentity = Boolean(expected || expectedTitle || year != null);
  // A remote URL without any identity is only a guess. Do not show it as the
  // poster for a different title just because the image happened to load.
  if (!hasIdentity) return false;
  try {
    const parsed = new URL(url, "http://localhost");
    if (expected && parsed.searchParams.get("imdbId")?.trim().toLowerCase() !== expected) return false;
    if (expectedTitle) {
      const actualTitle = (parsed.searchParams.get("titleEn") || parsed.searchParams.get("title") || "")
        .trim().toLowerCase().replace(/[^a-z0-9\u3400-\u9fff]+/g, "");
      if (!actualTitle || actualTitle !== expectedTitle) return false;
    }
    if (year != null && parsed.searchParams.get("year") !== String(year)) return false;
    return true;
  } catch {
    return false;
  }
}

/**
 * A poster served by this app's own endpoint comes from the media's directory
 * or from a poster this app saved for it, so its location already binds it to
 * that file. External URLs must still prove a matching identity.
 */
export function isLocalPosterUrl(url: string | null | undefined): boolean {
  if (!url) return false;
  try {
    return new URL(url, "http://localhost").pathname === "/api/media/poster";
  } catch {
    return false;
  }
}

/**
 * Local posters are gated server-side against the saved sidecar provenance; a
 * recorded identity that contradicts the current one still disqualifies the
 * candidate, and remote URLs keep the strict param check.
 */
export function isPosterCandidateUsable(
  url: string | null | undefined,
  imdbId?: string | null,
  titleEn?: string | null,
  year?: number | null,
): boolean {
  if (!url) return false;
  if (!isLocalPosterUrl(url)) return isPosterIdentityBound(url, imdbId, titleEn, year);
  try {
    const recordedImdb = new URL(url, "http://localhost").searchParams.get("imdbId")?.trim().toLowerCase() ?? "";
    const expectedImdb = (imdbId ?? "").trim().toLowerCase();
    return !(recordedImdb && expectedImdb && recordedImdb !== expectedImdb);
  } catch {
    return false;
  }
}
