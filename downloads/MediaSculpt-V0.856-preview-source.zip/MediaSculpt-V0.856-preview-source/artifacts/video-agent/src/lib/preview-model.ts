export type PreviewStreamHints = {
  fieldOrder?: string | null;
  frameRate?: string | null;
  height?: number | null;
};

export function isInterlacedStream(
  stream?: PreviewStreamHints | null,
): boolean {
  if (!stream) return false;
  const fieldOrder = stream.fieldOrder?.toLowerCase();
  if (
    ["tt", "bb", "tb", "bt", "top", "bottom", "interlaced"].includes(
      fieldOrder ?? "",
    )
  )
    return true;
  if (fieldOrder === "progressive") return false;
  const match = /^(\d+)\/(\d+)$/.exec(stream.frameRate ?? "");
  if (!match || Number(match[2]) === 0) return false;
  const fps = Number(match[1]) / Number(match[2]);
  const dvdTiming =
    Math.abs(fps - 29.97) < 0.05 ||
    Math.abs(fps - 25) < 0.05 ||
    Math.abs(fps - 30) < 0.05;
  return dvdTiming && [480, 576, 1080].includes(stream.height ?? 0);
}

export type PreviewLayoutState = {
  playing: boolean;
  expanded: boolean;
  assistantOpen: boolean;
  fill: boolean;
};

export type PreviewLayoutMode = "panel" | "viewport" | "ratio";

export function previewLayoutMode(
  state: PreviewLayoutState,
): PreviewLayoutMode {
  if (state.expanded || state.assistantOpen) return "panel";
  if (state.fill) return "viewport";
  return "ratio";
}
