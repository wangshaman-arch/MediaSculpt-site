/**
 * 安装任务在模块级保存，轮询循环独立于组件生命周期。
 * 这样用户从“工具状态与安装”界面切走再回来（甚至整页刷新），
 * 下载与进度都不会丢失：组件重新挂载时直接订阅同一份状态。
 */

export type InstallTask = {
  id: string;
  /** 可轮询的后台任务 ID（下载类工具）。Whisper 环境/模型安装为同步请求，没有 taskId。 */
  taskId?: string;
  /** null 表示不确定进度（例如 Whisper 环境安装）。 */
  progress: number | null;
  status: "running" | "done" | "error";
  message: string;
};

const STORAGE_KEY = "mediasculpt-active-installs";
const POLL_INTERVAL_MS = 1200;

const state = new Map<string, InstallTask>();
const timers = new Map<string, ReturnType<typeof setInterval>>();
const listeners = new Set<() => void>();

function emit(): void {
  for (const fn of listeners) fn();
}

function clearTimer(id: string): void {
  const timer = timers.get(id);
  if (timer) {
    clearInterval(timer);
    timers.delete(id);
  }
}

function persist(): void {
  try {
    const running = Object.fromEntries(
      [...state.entries()]
        .filter(([, task]) => task.status === "running" && task.taskId)
        .map(([id, task]) => [id, { taskId: task.taskId }]),
    );
    localStorage.setItem(STORAGE_KEY, JSON.stringify(running));
  } catch {
    // localStorage 不可用时不阻塞安装。
  }
}

function loadPersisted(): Array<{ id: string; taskId: string }> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Record<string, { taskId?: string }>;
    return Object.entries(parsed)
      .filter((entry): entry is [string, { taskId: string }] => Boolean(entry[1]?.taskId))
      .map(([id, saved]) => ({ id, taskId: saved.taskId }));
  } catch {
    return [];
  }
}

export function subscribeInstallTasks(fn: () => void): () => void {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

export function getInstallTask(id: string): InstallTask | undefined {
  return state.get(id);
}

export function getInstallTasks(): InstallTask[] {
  return [...state.values()];
}

async function poll(id: string, taskId: string): Promise<void> {
  try {
    const response = await fetch(`/api/runtime/tools/${encodeURIComponent(id)}/install-status?taskId=${encodeURIComponent(taskId)}`);
    const data = (await response.json().catch(() => null)) as { progress?: number; status?: string; message?: string } | null;
    if (!response.ok || !data) {
      if (response.status === 404) {
        // 任务已不存在（安装完成被清理、服务重启或旧任务号）：不是硬错误，
        // 提示后让界面刷新工具状态反映真实情况。
        updateTask(id, { status: "error", message: "安装任务已结束，正在刷新工具状态…" });
      } else {
        updateTask(id, { status: "error", message: "安装状态查询失败" });
      }
      return;
    }
    const status = data.status === "done" ? "done" : data.status === "error" ? "error" : "running";
    updateTask(id, { progress: data.progress ?? 0, status, message: data.message ?? "" });
  } catch {
    // 瞬时网络错误：保持轮询，不把安装判死。
  }
}

function updateTask(id: string, patch: Partial<InstallTask>): void {
  const current = state.get(id);
  if (!current) return;
  Object.assign(current, patch);
  if (current.status !== "running") {
    clearTimer(id);
    persist();
  }
  emit();
}

/** 绑定一个可轮询的后台安装任务（下载类工具）。同一工具只保留一个轮询循环。 */
export function attachInstallTask(id: string, taskId: string): void {
  const existing = state.get(id);
  if (existing?.status === "running" && existing.taskId === taskId && timers.has(id)) return;
  state.set(id, { id, taskId, progress: 0, status: "running", message: "准备安装…" });
  clearTimer(id);
  timers.set(id, setInterval(() => void poll(id, taskId), POLL_INTERVAL_MS));
  void poll(id, taskId);
  persist();
  emit();
}

/** 绑定一个没有百分比的运行中任务（Whisper 同步安装），完成后用 finishInstallTask 结束。 */
export function attachIndeterminateTask(id: string, message: string): void {
  const current = state.get(id);
  if (current?.status === "running") return;
  state.set(id, { id, progress: null, status: "running", message });
  persist();
  emit();
}

/** 更新运行中任务的文案/进度（Whisper 安装阶段推进）。 */
export function updateTaskProgress(id: string, message: string, progress: number | null): void {
  const current = state.get(id);
  if (!current || current.status !== "running") return;
  current.message = message;
  if (progress !== null) current.progress = progress;
  emit();
}

export function finishInstallTask(id: string, status: "done" | "error", message?: string): void {
  const current = state.get(id);
  if (!current) return;
  current.status = status;
  current.message = message ?? (status === "done" ? "安装完成" : "安装失败");
  if (status === "done") current.progress = 100;
  clearTimer(id);
  persist();
  emit();
}

/** 从状态表中移除任务（安装结束后调用，允许再次安装）。 */
export function detachInstallTask(id: string): void {
  clearTimer(id);
  state.delete(id);
  persist();
  emit();
}

// 整页刷新后重新接上仍在运行的后台安装任务。
for (const saved of loadPersisted()) {
  attachInstallTask(saved.id, saved.taskId);
}
