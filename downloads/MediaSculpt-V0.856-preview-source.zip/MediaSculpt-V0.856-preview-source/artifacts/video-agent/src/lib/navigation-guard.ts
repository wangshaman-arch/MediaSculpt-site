/**
 * 全局导航守卫：页面（如设置页）有未保存修改时注册一个守卫，
 * 菜单跳转 / 顶部工作区切换 / 窗口关闭都会先询问“保存 / 放弃 / 取消”。
 */

type NavigationGuard = (to: string) => Promise<boolean> | boolean;

let activeGuard: NavigationGuard | null = null;

export function setNavigationGuard(guard: NavigationGuard | null): void {
  activeGuard = guard;
}

export function hasNavigationGuard(): boolean {
  return activeGuard !== null;
}

export function runNavigationGuard(to: string): Promise<boolean> {
  return Promise.resolve(activeGuard ? activeGuard(to) : true);
}
