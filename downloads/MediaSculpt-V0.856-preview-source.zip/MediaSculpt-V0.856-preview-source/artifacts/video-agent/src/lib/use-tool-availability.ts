import { useCallback, useEffect, useState } from "react";

export type ToolHealth = "ok" | "broken" | "missing";
export type ToolInfo = { id: string; label: string; available: boolean; required: boolean; health?: ToolHealth };

type ToolsResponse = { tools?: ToolInfo[] };

/**
 * Subtitle/augmented feature -> tools required to run it.
 *  - whisper / transcribe_translate: speech recognition (faster-whisper)
 *  - ocr / bilingual / auto (graphic subs): tesseract or rapidocr
 *  Bilingual may fall back to Whisper when no Chinese text subtitle exists, so it
 *  also needs a speech/OCR tool for the Chinese side.
 */
export function toolsRequiredForSubtitle(mode: string): string[] {
  switch (mode) {
    case "whisper":
    case "transcribe_translate":
      return ["whisper"];
    case "ocr":
    case "bilingual":
      return ["whisper", "tesseract", "rapidocr"];
    case "auto":
      return ["tesseract", "rapidocr", "whisper"];
    default:
      return [];
  }
}

/** A mode is usable if every required tool is present, or (for OCR-ish modes) any one OCR tool is present. */
export function subtitleToolsAvailable(mode: string, isAvailable: (id: string) => boolean): { ok: boolean; missing: string[] } {
  const required = toolsRequiredForSubtitle(mode);
  if (required.length === 0) return { ok: true, missing: [] };
  if (mode === "ocr" || mode === "auto") {
    // Need at least one of the OCR engines (or Whisper as a last resort).
    const ocrOk = ["tesseract", "rapidocr"].some(isAvailable);
    if (ocrOk) return { ok: true, missing: [] };
    return { ok: false, missing: required.filter((id) => !isAvailable(id)) };
  }
  const missing = required.filter((id) => !isAvailable(id));
  return { ok: missing.length === 0, missing };
}

/**
 * Fetch the managed tool list once and cache it; expose a fast isAvailable(id)
 * and a refresh. Re-checks on window focus so a freshly installed tool is
 * picked up when the user returns from the Tool Manager.
 */
export function useToolAvailability() {
  const [tools, setTools] = useState<ToolInfo[]>([]);
  const [loaded, setLoaded] = useState(false);

  const load = useCallback(async () => {
    try {
      const response = await fetch("/api/runtime/tools");
      if (response.ok) {
        const body = (await response.json()) as ToolsResponse;
        setTools(body.tools ?? []);
      }
    } catch {
      // Non-fatal: fall back to "unknown" which we treat as available.
    } finally {
      setLoaded(true);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);
  useEffect(() => {
    const onFocus = () => void load();
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, [load]);

  const isAvailable = useCallback((id: string) => {
    const tool = tools.find((item) => item.id === id);
    if (!tool) return true; // unknown -> don't block
    return tool.available ?? false;
  }, [tools]);

  return { tools, isAvailable, isLoaded: loaded, refresh: load };
}
