import { describe, expect, it } from "vitest";
import { buildAssistantDisplayMetadata, buildMetadataRows, isPosterCandidateUsable, isPosterIdentityBound, mergeAssistantMetadata, parseAssistantMetadata, parseAssistantMetadataFields, type AssistantMetadataSnapshot } from "./assistant-metadata";
import { cleanAnalysisBody, resolveAnalysisOverview } from "./assistant-analysis";

describe("assistant metadata display model", () => {
  const metadata: AssistantMetadataSnapshot = {
    identityStatus: "confirmed",
    title: "Hamlet",
    titleEn: "Hamlet",
    year: 1996,
    imdb: { id: "tt0116477", rating: 7.8, votes: 123456 },
    douban: { id: "1295644", rating: 8.2 },
    rottenTomatoes: 85,
    metacritic: 72,
    director: "Kenneth Branagh",
    cast: ["Kenneth Branagh", "Derek Jacobi"],
    genres: "Drama",
    sourceLabels: ["IMDb", "豆瓣", "Rotten Tomatoes", "Metacritic"],
  };

  it("keeps ratings in a compact priority group", () => {
    const rows = buildMetadataRows(metadata);
    expect(rows.slice(0, 4).map((row) => row.label)).toEqual([
      "IMDb", "豆瓣", "烂番茄", "Metacritic",
    ]);
    expect(rows[0].value).toContain("7.8");
    expect(rows[0].value).toContain("123,456");
  });

  it("parses persisted snapshots defensively", () => {
    expect(parseAssistantMetadata(JSON.stringify(metadata))).toMatchObject({
      imdb: { rating: 7.8 },
      cast: ["Kenneth Branagh", "Derek Jacobi"],
    });
    expect(parseAssistantMetadata("not-json")).toBeNull();
  });

  it("does not accept an unbound remote poster after IMDb identity is known", () => {
    expect(isPosterIdentityBound("https://img.example/poster.jpg", "tt0116477")).toBe(false);
    expect(isPosterIdentityBound("/api/media/poster?imdbId=tt0116477&year=1996", "tt0116477")).toBe(true);
    expect(isPosterIdentityBound("https://img.example/poster.jpg", "")).toBe(false);
  });

  it("requires a local poster URL to carry title/year identity when IMDb is unavailable", () => {
    expect(isPosterIdentityBound(
      "/api/media/poster?titleEn=The%20Making%20of%20King%20Arthur&year=2010",
      "",
      "The Making of King Arthur",
      2010,
    )).toBe(true);
    expect(isPosterIdentityBound("https://img.example/related.jpg", "", "The Making of King Arthur", 2010)).toBe(false);
  });

  it("parses bold labels with values on the following line", () => {
    const raw = [
      "**IMDb**",
      "tt0108471",
      "**片名**",
      "Abraham's Valley / Abraham's Valley",
      "**年份**",
      "1993",
    ].join("\n");

    expect(parseAssistantMetadataFields(raw)).toMatchObject({
      imdbId: "tt0108471",
      titleEn: "Abraham's Valley",
      title: "Abraham's Valley",
      year: 1993,
    });
  });

  it("parses and displays rating, director, cast, genre, and runtime fields from an analysis reply", () => {
    const fields = parseAssistantMetadataFields([
      "IMDb 评分：7.3（约2000票）",
      "豆瓣评分：8.0（来源：豆瓣）",
      "导演：曼努埃尔·德·奥利维拉（Manoel de Oliveira）",
      "主要演员：塞西莉亚·卡瓦略、路易斯·米格尔·辛特拉、米歇尔·皮科利",
      "类型：剧情/爱情",
      "片长：163分钟",
    ].join("\n"));

    expect(fields).toMatchObject({
      imdbRating: 7.3,
      imdbVotes: 2000,
      doubanRating: 8,
      director: "曼努埃尔·德·奥利维拉（Manoel de Oliveira）",
      cast: ["塞西莉亚·卡瓦略", "路易斯·米格尔·辛特拉", "米歇尔·皮科利"],
      genres: "剧情/爱情",
      runtimeMinutes: 163,
    });

    const display = mergeAssistantMetadata({
      identityStatus: "confirmed",
      imdb: { id: "tt0108471" },
      sourceLabels: ["IMDb"],
    }, fields);
    const rows = buildMetadataRows(display);
    expect(rows.map((row) => row.label)).toEqual(["IMDb", "豆瓣", "导演", "主要演员", "类型", "片长"]);
    expect(rows[0]?.value).toContain("7.3");
    expect(rows[1]?.value).toContain("8.0");
  });

  it("keeps assistant rating and crew fields when building the panel display model", () => {
    const fields = parseAssistantMetadataFields([
      "IMDb 评分：7.3（约2000票）",
      "导演：曼努埃尔·德·奥利维拉（Manoel de Oliveira）",
      "主要演员：塞西莉亚·卡瓦略、路易斯·米格尔·辛特拉",
      "类型：剧情/爱情",
    ].join("\n"));

    const display = buildAssistantDisplayMetadata({
      identityStatus: "confirmed",
      imdb: { id: "tt0108471" },
      sourceLabels: ["IMDb"],
    }, fields);

    expect(buildMetadataRows(display).map((row) => row.label)).toEqual([
      "IMDb", "导演", "主要演员", "类型",
    ]);
    expect(buildMetadataRows(display)[0]?.value).toContain("7.3");
  });

  it("treats a generic rating line as the IMDb score in the analysis context", () => {
    const fields = parseAssistantMetadataFields([
      "评分：7.1（约 2000 票）",
      "Director: Manoel de Oliveira",
      "Cast: Leonor Silveira, Luís Miguel Cintra",
      "Genres: Drama / Romance",
      "Runtime: 163 minutes",
    ].join("\n"));

    expect(fields).toMatchObject({
      imdbRating: 7.1,
      imdbVotes: 2000,
      director: "Manoel de Oliveira",
      cast: ["Leonor Silveira", "Luís Miguel Cintra"],
      genres: "Drama / Romance",
      runtimeMinutes: 163,
    });
  });

  it("removes structured metadata without swallowing the overview", () => {
    const raw = [
      "**IMDb**",
      "tt0108471",
      "**片名**",
      "Abraham's Valley / Abraham's Valley",
      "**年份**",
      "1993",
      "",
      "**内容简介**：",
      "A family story unfolds in the Douro Valley.",
    ].join("\n");

    expect(cleanAnalysisBody(raw)).toBe("A family story unfolds in the Douro Valley.");
  });

  it("uses the verified provider overview when the assistant returns fields only", () => {
    expect(resolveAnalysisOverview("**IMDb**\ntt0108471\n**年份**\n1993", "Verified provider overview.")).toBe("Verified provider overview.");
  });

  it("keeps an overview written on the same line as its label", () => {
    expect(cleanAnalysisBody("内容简介：A family story unfolds in the Douro Valley.")).toBe("A family story unfolds in the Douro Valley.");
  });

  it("cleans legacy persisted metadata before displaying the overview", () => {
    const stored = [
      "Abrahams.Valley · 亚伯拉罕山谷 · 1993 · 剧情/爱情 · 葡萄牙 · 187分钟",
      "导演：曼努埃尔·德·奥利维拉",
      "影片改编自葡萄牙作家阿古斯蒂娜·贝萨-路易斯的同名小说。",
      "IMDb 编号：tt0108471",
    ].join("\n");

    expect(cleanAnalysisBody(stored)).toBe("影片改编自葡萄牙作家阿古斯蒂娜·贝萨-路易斯的同名小说。");
  });
});

describe("assistant metadata machine markers", () => {
  it("never accepts a machine marker as another field's display value", () => {
    // The assistant echoed the machine block under a bare label. "YEAR=1989"
    // used to be stored as the Chinese title, so the row rendered as
    // "11.Days.11.Nights.Part.3 / YEAR=1989".
    const fields = parseAssistantMetadataFields([
      "TITLE_EN=11.Days.11.Nights.Part.3",
      "片名",
      "YEAR=1989",
      "IMDBID=tt0095719",
    ].join("\n"));

    expect(fields.title).toBeUndefined();
    expect(fields.titleEn).toBe("11.Days.11.Nights.Part.3");
    expect(fields.year).toBe(1989);
    expect(fields.imdbId).toBe("tt0095719");
  });

  it("never accepts a machine marker written on the label's own line", () => {
    const fields = parseAssistantMetadataFields([
      "中文名：YEAR=1989",
      "年份：1989",
      "IMDb 编号：tt0095719",
    ].join("\n"));

    expect(fields.title).toBeUndefined();
    expect(fields.year).toBe(1989);
    expect(fields.imdbId).toBe("tt0095719");
  });

  it("ranks identity as correction, then verified snapshot, then fallbacks", () => {
    const snapshot: AssistantMetadataSnapshot = {
      identityStatus: "confirmed",
      title: "十一天十一夜",
      titleEn: "11.Days.11.Nights.Part.3",
      year: 1989,
      imdb: { id: "tt0095719" },
      sourceLabels: ["IMDb"],
    };

    // Prose scraped from the reply is only ever a fallback: the verified
    // snapshot answers the identity fields first.
    const fromSnapshot = buildAssistantDisplayMetadata(snapshot, {}, { title: "YEAR=1989", year: 1989 });
    expect(fromSnapshot?.title).toBe("十一天十一夜");
    expect(fromSnapshot?.titleEn).toBe("11.Days.11.Nights.Part.3");
    expect(fromSnapshot?.imdb?.id).toBe("tt0095719");
    // Identity lives in the assistant toolbar inputs, never as a duplicate row.
    const snapshotRows = buildMetadataRows(fromSnapshot).map((row) => row.label);
    expect(snapshotRows).not.toContain("片名");
    expect(snapshotRows).not.toContain("年份");

    // A manual correction still outranks the snapshot.
    const corrected = buildAssistantDisplayMetadata(snapshot, { title: "十一日十一夜" }, {});
    expect(corrected?.title).toBe("十一日十一夜");

    // With no snapshot to verify against, the fallback is what remains.
    const fallbackOnly = buildAssistantDisplayMetadata(null, {}, { title: "十一日十一夜", year: 1989 });
    expect(fallbackOnly?.title).toBe("十一日十一夜");
    expect(fallbackOnly?.year).toBe(1989);
  });
});

describe("assistant overview prose from a captured real reply", () => {
  const blowUpReply = [
    "IMDBID=tt0060176",
    "Blow-Up · 放大 · 1966 · 剧情/悬疑/惊悚 · 英国/意大利/美国 · 111分钟",
    "IMDb 编号：tt0060176",
    "IMDb 评分：7.5（约7.5万票）",
    "豆瓣评分：8.5（豆瓣，约4.5万票）",
    "主创：",
    "导演：米开朗基罗·安东尼奥尼（Michelangelo Antonioni）",
    "编剧：米开朗基罗·安东尼奥尼（Michelangelo Antonioni）、托尼诺·格拉（Tonino Guerra）",
    "主演：大卫·海明斯（David Hemmings）饰 托马斯（Thomas）",
    "摄影：卡洛·迪·帕尔马（Carlo Di Palma）",
    "配乐：赫伯特·汉考克（Herbie Hancock）",
    "制片：卡洛·庞蒂（Carlo Ponti）",
    "简介：",
    "《放大》是意大利导演米开朗基罗·安东尼奥尼于1966年执导的英语电影，讲述时尚摄影师托马斯在公园拍下一对男女的画面。",
  ].join("\n");

  it("keeps the plot paragraph instead of dropping it as a compact header", () => {
    const body = cleanAnalysisBody(blowUpReply);
    expect(body).toContain("《放大》是意大利导演米开朗基罗·安东尼奥尼于1966年执导");
    expect(body).not.toContain("基本信息");
    expect(body).not.toContain("摄影：");
    expect(body).not.toContain("简介");
  });

  it("finds the overview when the label is a bare heading with no colon", () => {
    expect(cleanAnalysisBody([
      "TITLE_EN=Blow-Up",
      "年份：1966",
      "基本信息",
      "摄影：卡洛·迪·帕尔马（Carlo Di Palma）",
      "简介",
      "《放大》讲述一位时尚摄影师放大底片后发现疑似谋杀线索的故事。",
    ].join("\n"))).toBe("《放大》讲述一位时尚摄影师放大底片后发现疑似谋杀线索的故事。");
  });

  it("keeps writer credits out of the director field", () => {
    const fields = parseAssistantMetadataFields([
      "导演：米开朗基罗·安东尼奥尼（Michelangelo Antonioni）",
      "编剧：米开朗基罗·安东尼奥尼（Michelangelo Antonioni）、托尼诺·格拉（Tonino Guerra）",
    ].join("\n"));
    expect(fields.director).toBe("米开朗基罗·安东尼奥尼（Michelangelo Antonioni）");
  });

  it("renders crew credits as their own rows", () => {
    const rows = buildMetadataRows({
      identityStatus: "confirmed",
      title: "放大",
      credits: [{ label: "编剧", value: "托尼诺·格拉（Tonino Guerra）" }],
      sourceLabels: ["AI助手"],
    });
    expect(rows.map((row) => row.label)).toContain("编剧");
  });
});

describe("poster candidate usability", () => {
  it("accepts a local poster whose sidecar predates the imdb id", () => {
    expect(isPosterCandidateUsable(
      "/api/media/poster?path=H%3A%5CBlow-Up&titleEn=Blow-Up&year=1966",
      "tt0060176",
      "Blow-Up",
      1966,
    )).toBe(true);
    expect(isPosterCandidateUsable(
      "/api/media/poster?path=H%3A%5CBlow-Up&imdbId=tt0060176&titleEn=Blow-Up&year=1966",
      "tt0060176",
      "Blow-Up",
      1966,
    )).toBe(true);
  });

  it("still refuses a local poster that records a contradicting identity", () => {
    expect(isPosterCandidateUsable(
      "/api/media/poster?path=H%3A%5CBlow-Up&imdbId=tt9999999",
      "tt0060176",
      "Blow-Up",
      1966,
    )).toBe(false);
  });

  it("keeps remote posters on the strict identity check", () => {
    expect(isPosterCandidateUsable("https://img.example/poster.jpg", "tt0060176", "Blow-Up", 1966)).toBe(false);
    expect(isPosterCandidateUsable(
      "https://img.example/poster.jpg?imdbId=tt0060176&titleEn=Blow-Up&year=1966",
      "tt0060176",
      "Blow-Up",
      1966,
    )).toBe(true);
  });
});
