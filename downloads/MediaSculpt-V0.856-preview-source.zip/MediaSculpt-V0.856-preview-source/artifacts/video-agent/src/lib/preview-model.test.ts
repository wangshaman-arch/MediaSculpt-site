import { describe, expect, it } from "vitest";
import { isInterlacedStream, previewLayoutMode } from "./preview-model";

describe("preview model", () => {
  it("treats explicit field order and common DVD timings as interlaced", () => {
    expect(
      isInterlacedStream({ fieldOrder: "tt", frameRate: "25/1", height: 576 }),
    ).toBe(true);
    expect(
      isInterlacedStream({
        fieldOrder: "progressive",
        frameRate: "25/1",
        height: 576,
      }),
    ).toBe(false);
    expect(
      isInterlacedStream({
        fieldOrder: null,
        frameRate: "30000/1001",
        height: 480,
      }),
    ).toBe(true);
  });

  it("keeps the player in a stable panel layout while assistant or details are open", () => {
    expect(
      previewLayoutMode({
        playing: true,
        expanded: true,
        assistantOpen: false,
        fill: false,
      }),
    ).toBe("panel");
    expect(
      previewLayoutMode({
        playing: false,
        expanded: false,
        assistantOpen: true,
        fill: false,
      }),
    ).toBe("panel");
    expect(
      previewLayoutMode({
        playing: true,
        expanded: false,
        assistantOpen: false,
        fill: false,
      }),
    ).toBe("ratio");
    expect(
      previewLayoutMode({
        playing: false,
        expanded: false,
        assistantOpen: false,
        fill: true,
      }),
    ).toBe("viewport");
    expect(
      previewLayoutMode({
        playing: false,
        expanded: false,
        assistantOpen: false,
        fill: false,
      }),
    ).toBe("ratio");
  });
});
