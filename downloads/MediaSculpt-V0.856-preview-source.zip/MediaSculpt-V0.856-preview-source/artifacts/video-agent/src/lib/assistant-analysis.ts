import { parseAssistantMetadataFields } from "./assistant-metadata";

/** Keep the prose preview separate from the structured information grid. */
export function hasVerifiedMetadataValue(value: unknown, unverifiedLabel: string): boolean {
  return value !== undefined
    && value !== null
    && String(value).trim() !== ""
    && String(value).trim() !== unverifiedLabel.trim();
}

const OVERVIEW_HEADING = /^(?:内容简介|剧情简介|影片简介|简介|overview)\s*[:：]?\s*$/i;
const OVERVIEW_INLINE = /^(?:内容简介|剧情简介|影片简介|简介|overview)\s*[:：]\s*(.*)$/i;
/** Crew lines are fields, never prose; they are gathered into the info table. */
/** Crew lines are fields, never prose; they are gathered into the info table. */
const CREW_LABELS_LIST = "编剧|编剧组|导演|摄影|摄影指导|配乐|作曲|音乐|制片|制片人|制片方|出品|出品方|发行|监制|剪辑|剪辑师|美术|艺术指导|服装设计|主持人|主持|旁白|解说|讲述|嘉宾|指挥|演奏|乐团|乐队|编舞|舞者|演唱";
// A reply often joins labels ("主持人/旁白"), so the label may be a short list.
const CREW_LINE = new RegExp(`^(?:${CREW_LABELS_LIST})(?:\\s*[/、]\\s*(?:${CREW_LABELS_LIST}))*\\s*[:：=]`, "i");
const SECTION_HEADING = /^(?:资料信息|基本信息|外部检索资料(?:（[^）]*）)?|主创栏|主创)\s*[:：]?$/i;

/**
 * A compact "Title · 中文名 · 1993 · genre · country · runtime" header is a
 * metadata line. It must be told apart from a plot sentence that merely
 * mentions a year and a dotted name — Blow-Up's overview says
 * "…米开朗基罗·安东尼奥尼于1966年执导…", and the old year+dot test dropped that
 * whole paragraph, which is why the overview showed up empty.
 */
function isCompactIdentityLine(line: string): boolean {
  if (!/\b(?:19|20)\d{2}\b/.test(line)) return false;
  if ((line.match(/[·•]/g) ?? []).length < 2) return false;
  if (/[。！？；]/.test(line)) return false;
  return line.length <= 120;
}

/** Keep the prose preview separate from the structured information grid. */
export function cleanAnalysisBody(value: string | null | undefined): string {
  if (!value) return "";
  const sourceLines = value.replace(/\r/g, "").split("\n");
  const stripMarkup = (line: string) => line
    .trim()
    .replace(/^#{1,6}\s*/, "")
    .replace(/^\s*(?:[-+*]|\d+[.)])\s+/, "")
    .replace(/^>\s*/, "")
    .replace(/^[*_]{1,3}/, "")
    .replace(/[*_]{1,3}([:：]?)$/, "$1")
    .replace(/^\x60|\x60$/g, "")
    .trim();
  // The label is a heading as often as it is a "简介：" field; a heading without
  // a colon used to leave the crew block in the prose with no plot at all.
  const contentIndex = sourceLines.findIndex((line) => {
    const stripped = stripMarkup(line);
    return OVERVIEW_HEADING.test(stripped) || OVERVIEW_INLINE.test(stripped);
  });
  const contentLine = contentIndex >= 0 ? stripMarkup(sourceLines[contentIndex]) : "";
  const inlineOverview = OVERVIEW_INLINE.exec(contentLine)?.[1]?.trim();
  const lines = contentIndex >= 0
    ? [...(inlineOverview ? [inlineOverview] : []), ...sourceLines.slice(contentIndex + 1)]
    : sourceLines;
  const kept: string[] = [];
  let structuredBlock = false;
  for (let index = 0; index < lines.length; index += 1) {
    const trimmed = stripMarkup(lines[index]);
    if (!trimmed) {
      if (!structuredBlock && kept.length > 0) kept.push("");
      continue;
    }
    if (SECTION_HEADING.test(trimmed) || CREW_LINE.test(trimmed)) {
      structuredBlock = true;
      continue;
    }
    if (/^(?:来源年份|英文名(?:\/原名)?|英文名|原名|中文名|片名|标题|年代|年份|类型|题材|国家|地区|片长|评分|豆瓣(?:号|评分)?|IMDb(?:\s*(?:编号|ID|评分))?|IMDB(?:\s*(?:编号|ID|评分))?|烂番茄|Metacritic)\s*[:：=]/i.test(trimmed)
      || /^\s*(?:IMDBID|TITLE_EN|TITLE_ZH|YEAR)\s*=/i.test(trimmed)) {
      structuredBlock = true;
      continue;
    }
    const inlineCredits = trimmed.match(/^.*?\s+(?:主创栏|主创)\s*[:：]\s*(.+)$/);
    if (inlineCredits?.[1]?.trim()) {
      kept.push(stripMarkup(inlineCredits[1]));
      structuredBlock = false;
      continue;
    }
    // Older tasks persisted a compact identity line and credits together
    // with the overview. Remove those legacy lines when displaying them, but
    // only when the line really is a compact identity header: a plot sentence
    // may also mention a year and a dotted name.
    if (isCompactIdentityLine(trimmed)
      || /^(?:导演|编剧|主要演员|主演)\s*[:：=]/i.test(trimmed)) {
      structuredBlock = true;
      continue;
    }
    if (/^(?:识别依据|综合判断|技术特征|结论|分析过程)\s*[:：]?/i.test(trimmed)) continue;
    if (/待确认|未检索到|未找到|未知|N\/?A/i.test(trimmed)) continue;
    const next = index + 1 < lines.length ? stripMarkup(lines[index + 1]) : "";
    const isLabelOnly = /^(?:片名|标题|英文名(?:\/原名)?|英文名|原名|中文名|IMDb|IMDB|IMDb\s*(?:编号|ID|评分)|IMDB\s*(?:编号|ID|评分)|年份|年代)\s*$/i.test(trimmed);
    if (isLabelOnly && next && Object.keys(parseAssistantMetadataFields(trimmed + "\n" + next)).length > 0) {
      index += 1;
      structuredBlock = true;
      continue;
    }
    if (Object.keys(parseAssistantMetadataFields(trimmed)).length > 0) {
      structuredBlock = true;
      continue;
    }
    if (structuredBlock) structuredBlock = false;
    kept.push(trimmed);
  }
  return kept.join("\n").replace(/\n{3,}/g, "\n\n").trim();
}

/** Prefer the assistant prose, then fall back to a verified provider overview. */
export function resolveAnalysisOverview(reply: string | null | undefined, providerOverview?: string | null): string {
  const cleaned = cleanAnalysisBody(reply).trim();
  const identityOnly = /^(?:IMDb|IMDB)\s*(?:编号|ID|评分)?\s*[:：=]\s*tt\d{7,8}$/i.test(cleaned);
  return !identityOnly && cleaned ? cleaned : providerOverview?.trim() || "";
}
