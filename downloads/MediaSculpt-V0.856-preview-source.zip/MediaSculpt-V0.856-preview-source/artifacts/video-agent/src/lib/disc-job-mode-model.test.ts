import { describe, expect, it } from "vitest";
import {
  hasExecutableDiscStreamSelection,
  canCreateDiscJobsWithMode,
  requiresExplicitDiscProcessingMode,
  resolveDiscCreateIndices,
  resolveDiscJobModes,
  assessDiscRemuxCapacity,
  selectableDiscTitleIndices,
  isClearlyInvalidDiscTrack,
  setDiscTitleSelection,
  selectCapacitySafeDiscTitles,
} from "../features/workbench/disc-job-mode-model";

describe("disc job mode model", () => {
  it("keeps compression when a stale bilingual subtitle choice is present", () => {
    expect(resolveDiscJobModes({ processingMode: "compress", subtitleMode: "bilingual" })).toEqual({
      processingMode: "compress",
      subtitleMode: "skip",
      outputMode: "compress",
    });
  });

  it("keeps remux independent from subtitle choices", () => {
    expect(resolveDiscJobModes({ processingMode: "remux", subtitleMode: "bilingual" })).toEqual({
      processingMode: "remux",
      subtitleMode: "skip",
      outputMode: "remux",
    });
  });

  it("keeps bilingual mode for subtitle-only DVD work", () => {
    expect(resolveDiscJobModes({ processingMode: "none", subtitleMode: "bilingual" })).toEqual({
      processingMode: "none",
      subtitleMode: "bilingual",
      outputMode: "subtitle",
    });
  });

  it("allows an empty stream selection to mean all streams while requiring video", () => {
    const streams = [
      { index: 0, codecType: "video" },
      { index: 1, codecType: "audio" },
    ];
    expect(hasExecutableDiscStreamSelection(streams, [])).toBe(true);
    expect(hasExecutableDiscStreamSelection(streams, [1])).toBe(false);
    expect(hasExecutableDiscStreamSelection(streams, [0, 1])).toBe(true);
  });

  it("uses the active title when no batch titles were checked", () => {
    expect(resolveDiscCreateIndices(new Set(), 3)).toEqual([3]);
    expect(resolveDiscCreateIndices(new Set([1, 3]), 3)).toEqual([1, 3]);
    expect(resolveDiscCreateIndices(new Set(), -1)).toEqual([]);
  });

  it("flags the empty workflow combination instead of submitting a no-op task", () => {
    expect(requiresExplicitDiscProcessingMode({ processingMode: "none", subtitleMode: "skip" })).toBe(true);
    expect(requiresExplicitDiscProcessingMode({ processingMode: "none", subtitleMode: "auto" })).toBe(false);
    expect(requiresExplicitDiscProcessingMode({ processingMode: "compress", subtitleMode: "skip" })).toBe(false);
  });

  it("blocks creating a disc job when there is no executable action", () => {
    expect(canCreateDiscJobsWithMode({ processingMode: "none", subtitleMode: "skip", selectedTitleCount: 1 })).toBe(false);
    expect(canCreateDiscJobsWithMode({ processingMode: "remux", subtitleMode: "skip", selectedTitleCount: 1 })).toBe(true);
    expect(canCreateDiscJobsWithMode({ processingMode: "none", subtitleMode: "auto", selectedTitleCount: 1 })).toBe(true);
    expect(canCreateDiscJobsWithMode({ processingMode: "remux", subtitleMode: "skip", selectedTitleCount: 0 })).toBe(false);
  });

  it("selects every visible and available title for an explicit batch action", () => {
    const tracks = [
      { availabilityStatus: "available", streams: [{ codecType: "video" }] },
      { availabilityStatus: "unavailable", streams: [{ codecType: "video" }] },
      { availabilityStatus: "available", streams: [{ codecType: "video" }] },
      { availabilityStatus: null },
      { availabilityStatus: "available", streams: [{ codecType: "audio" }] },
    ];
    expect(selectableDiscTitleIndices(tracks, [0, 1, 2, 3, 4])).toEqual([0, 2, 3]);
    expect(selectableDiscTitleIndices(tracks, [0, 2])).toEqual([0, 2]);
  });

  it("blocks a batch Remux when its physical estimate is unknown or too large", () => {
    expect(assessDiscRemuxCapacity({
      sourceBytes: 10_000,
      tracks: [{ sizeBytes: 4_000 }, { sizeBytes: 5_000 }],
      selectedIndexes: [0, 1],
    })).toMatchObject({ blocked: false, estimatedBytes: 9_000, unknownCount: 0 });
    expect(assessDiscRemuxCapacity({
      sourceBytes: 10_000,
      tracks: [{ sizeBytes: 6_000 }, { sizeBytes: 5_000 }],
      selectedIndexes: [0, 1],
    }).blocked).toBe(true);
    expect(assessDiscRemuxCapacity({
      sourceBytes: 10_000,
      tracks: [{ sizeBytes: 6_000 }, { sizeBytes: 0 }],
      selectedIndexes: [0, 1],
    }).blocked).toBe(true);
  });

  it("adds logical segments from one physical VTS instead of counting only the first", () => {
    expect(assessDiscRemuxCapacity({
      sourceBytes: 2_000,
      tracks: [
        { sizeBytes: 500, physicalVtsNumber: 5 },
        { sizeBytes: 1_500, physicalVtsNumber: 5 },
      ],
      selectedIndexes: [0, 1],
    })).toMatchObject({ blocked: false, estimatedBytes: 2_000, unknownCount: 0 });
  });

  it("uses the union of exact physical Cell ranges when titles overlap", () => {
    expect(assessDiscRemuxCapacity({
      sourceBytes: 1_000,
      tracks: [
        { sizeBytes: 700, physicalRanges: [{ path: "VTS_01_1.VOB", startByte: 0, endByte: 700 }] },
        { sizeBytes: 500, physicalRanges: [{ path: "VTS_01_1.VOB", startByte: 500, endByte: 1_000 }] },
      ],
      selectedIndexes: [0, 1],
    })).toMatchObject({ blocked: false, estimatedBytes: 1_000, unknownCount: 0 });
    expect(assessDiscRemuxCapacity({
      sourceBytes: 900,
      tracks: [
        { sizeBytes: 700, physicalRanges: [{ path: "VTS_01_1.VOB", startByte: 0, endByte: 700 }] },
        { sizeBytes: 500, physicalRanges: [{ path: "VTS_01_1.VOB", startByte: 500, endByte: 1_000 }] },
      ],
      selectedIndexes: [0, 1],
    }).blocked).toBe(true);
  });

  it("does not expose obviously invalid disc titles", () => {
    const valid = { sizeBytes: 100, durationSeconds: 60, streams: [{ codecType: "video" }] };
    expect(isClearlyInvalidDiscTrack(valid)).toBe(false);
    expect(isClearlyInvalidDiscTrack({ ...valid, availabilityStatus: "unavailable" })).toBe(true);
    expect(isClearlyInvalidDiscTrack({ ...valid, verificationStatus: "failed" })).toBe(true);
    expect(isClearlyInvalidDiscTrack({ ...valid, durationSeconds: 0 })).toBe(true);
    expect(isClearlyInvalidDiscTrack({ ...valid, streams: [{ codecType: "audio" }] })).toBe(true);
  });

  it("keeps Blu-ray titles visible when playlist size is not estimated", () => {
    expect(
      isClearlyInvalidDiscTrack({
        sizeBytes: 0,
        durationSeconds: 5089,
        streams: [{ codecType: "video" }],
      }),
    ).toBe(false);
  });

  it("applies title checkbox state idempotently", () => {
    const selected = new Set([0]);
    expect(setDiscTitleSelection(selected, 1, true)).toEqual(new Set([0, 1]));
    expect(setDiscTitleSelection(new Set([0, 1]), 1, true)).toEqual(new Set([0, 1]));
    expect(setDiscTitleSelection(new Set([0, 1]), 1, false)).toEqual(new Set([0]));
  });

  it("selects valid titles without exceeding the source VOB capacity", () => {
    const tracks = [
      { sizeBytes: 700, durationSeconds: 100, streams: [{ codecType: "video" }] },
      { sizeBytes: 500, durationSeconds: 80, streams: [{ codecType: "video" }] },
      { sizeBytes: 400, durationSeconds: 70, streams: [{ codecType: "video" }] },
    ];
    expect(selectCapacitySafeDiscTitles(tracks, [0, 1, 2], 1_000)).toEqual([0]);
    expect(selectCapacitySafeDiscTitles(tracks, [1, 2], 1_000)).toEqual([1, 2]);
  });
});
