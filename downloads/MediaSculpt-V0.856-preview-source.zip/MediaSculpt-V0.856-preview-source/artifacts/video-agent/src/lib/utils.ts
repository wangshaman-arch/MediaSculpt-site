import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatBytes(bytes?: number | null, decimals = 2) {
  if (bytes === undefined || bytes === null) return '0 B'
  if (!+bytes) return '0 B'
  const k = 1024
  const dm = decimals < 0 ? 0 : decimals
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`
}

export function formatDuration(seconds?: number | null) {
  if (seconds === undefined || seconds === null) return '0s';
  const totalSeconds = Math.max(0, Math.round(seconds));
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  
  if (h > 0) return `${h}h ${m}m ${s}s`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

export function formatCompressionRatio(before?: number | null, after?: number | null) {
  if (!before || !after || before <= 0) return null;
  const ratio = 1 - (after / before);
  if (ratio <= 0) return null;
  return `${(ratio * 100).toFixed(1)}%`;
}

/**
 * Convert a container-internal path to the Windows host path for display.
 * The container mounts are:
 *   /media/downloads → config.hostDownloadsPath  (e.g. H:\)
 *   /media/output    → config.hostOutputPath     (e.g. C:\Users\xxx\Videos)
 * watchDirectory / outputDirectory are used as the canonical container prefixes.
 */
export function toHostPath(
  containerPath: string | null | undefined,
  config?: {
    watchDirectory?: string;
    outputDirectory?: string;
    hostDownloadsPath?: string | null;
    hostOutputPath?: string | null;
  } | null
): string {
  if (!containerPath) return "";
  if (!config) return containerPath;

  const mappings: Array<{ container: string; host: string }> = [];

  if (config.hostDownloadsPath && config.watchDirectory) {
    mappings.push({ container: config.watchDirectory, host: config.hostDownloadsPath });
  }
  if (config.hostOutputPath && config.outputDirectory) {
    mappings.push({ container: config.outputDirectory, host: config.hostOutputPath });
  }
  // Also map well-known defaults in case config dirs differ
  if (config.hostDownloadsPath) {
    mappings.push({ container: "/media/downloads", host: config.hostDownloadsPath });
  }
  if (config.hostOutputPath) {
    mappings.push({ container: "/media/output", host: config.hostOutputPath });
  }

  for (const { container, host } of mappings) {
    const norm = container.endsWith("/") ? container : container + "/";
    if (containerPath === container) {
      return toWinSlash(host);
    }
    if (containerPath.startsWith(norm)) {
      const rel = containerPath.slice(norm.length);
      const base = host.endsWith("\\") || host.endsWith("/") ? host : host + "\\";
      return toWinSlash(base + rel);
    }
  }

  return containerPath;
}

function toWinSlash(p: string): string {
  return p.replace(/\//g, "\\");
}

function isLinuxAbsolutePath(p: string): boolean {
  return /^\/[^/]/.test(p);
}

/**
 * Reverse of toHostPath: convert a Windows host path back to the Docker container path.
 * e.g. "C:\Users\wangs\Videos\movie.mkv" → "/media/output/movie.mkv"
 */
export function fromHostPath(
  hostPath: string,
  config?: {
    watchDirectory?: string;
    outputDirectory?: string;
    hostDownloadsPath?: string | null;
    hostOutputPath?: string | null;
  } | null
): string {
  if (!hostPath || !config) return hostPath;

  const normalized = hostPath.replace(/\\/g, "/").replace(/\/$/, "");
  const hostDl  = (config.hostDownloadsPath || "").replace(/\\/g, "/").replace(/\/$/, "");
  const hostOut = (config.hostOutputPath    || "").replace(/\\/g, "/").replace(/\/$/, "");
  const dlDir   = (config.watchDirectory  || "/media/downloads").replace(/\/$/, "");
  const outDir  = (config.outputDirectory || "/media/output").replace(/\/$/, "");

  if (hostDl && isLinuxAbsolutePath(dlDir) && normalized.toLowerCase().startsWith(hostDl.toLowerCase())) {
    const rel = normalized.slice(hostDl.length).replace(/^[/\\]+/, "");
    return dlDir + (rel ? "/" + rel : "");
  }
  if (hostOut && isLinuxAbsolutePath(outDir) && normalized.toLowerCase().startsWith(hostOut.toLowerCase())) {
    const rel = normalized.slice(hostOut.length).replace(/^[/\\]+/, "");
    return outDir + (rel ? "/" + rel : "");
  }
  return hostPath; // already a Docker/Linux path or unmapped
}

export function formatDate(dateString?: string | null, locale?: string) {
  if (!dateString) return '';
  return new Date(dateString).toLocaleString(locale ?? undefined, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
}
