import { ARCHIVE_PRESET_LS_KEY } from "./brand-storage";

export type CompressionPresetValues = {
  encoder: string;
  crf: number;
  encoderPreset: string;
  encoderTune: string;
  encoderProfile: string;
  encoderLevel: string;
  frameRate: string;
  outputResolution?: string;
};

export type ArchivePreset = {
  id: string;
  labelKey: string;
  descriptionKey: string;
  icon: string;
  values: CompressionPresetValues;
};

export type CustomPreset = {
  id: string;
  name: string;
  values: CompressionPresetValues;
};

export const CUSTOM_COMPRESSION_PRESET_ID = "custom";

/** Output resolution choices rendered as a clickable dropdown. */
export const RESOLUTION_OPTIONS = [
  { value: "source", labelKey: "settings.resSource" },
  { value: "2160p", labelKey: "settings.res2160p" },
  { value: "1080p", labelKey: "settings.res1080p" },
  { value: "720p", labelKey: "settings.res720p" },
  { value: "576p", labelKey: "settings.res576p" },
  { value: "480p", labelKey: "settings.res480p" },
];

/** Shared option lists for the preset editors (same choices as the settings page). */
export const ENCODER_OPTIONS = [
  { value: "x264_10bit", labelKey: "settings.encoderX264" },
  { value: "x264", labelKey: "settings.encoderX264Plain" },
  { value: "x265_10bit", labelKey: "settings.encoderX265" },
  { value: "x265", labelKey: "settings.encoderX265Plain" },
  { value: "av1", labelKey: "settings.encoderAv1" },
];

export const PRESET_SPEED_OPTIONS = [
  { value: "ultrafast", labelKey: "settings.presetUltrafast" },
  { value: "superfast", labelKey: "settings.presetSuperfast" },
  { value: "veryfast", labelKey: "settings.presetVeryfast" },
  { value: "faster", labelKey: "settings.presetFaster" },
  { value: "fast", labelKey: "settings.presetFast" },
  { value: "medium", labelKey: "settings.presetMedium" },
  { value: "slow", labelKey: "settings.presetSlow" },
  { value: "slower", labelKey: "settings.presetSlower" },
  { value: "veryslow", labelKey: "settings.presetVeryslow" },
  { value: "placebo", labelKey: "settings.presetPlacebo" },
];

export const TUNE_OPTIONS = [
  { value: "none", labelKey: "settings.tuneNone" },
  { value: "film", labelKey: "settings.tuneFilm" },
  { value: "animation", labelKey: "settings.tuneAnimation" },
  { value: "grain", labelKey: "settings.tuneGrain" },
  { value: "stillimage", labelKey: "settings.tuneStillimage" },
  { value: "fastdecode", labelKey: "settings.tuneFastdecode" },
  { value: "zerolatency", labelKey: "settings.tuneZerolatency" },
];

export const PROFILE_OPTIONS = [
  { value: "auto", labelKey: "settings.profileAuto" },
  { value: "baseline", labelKey: "settings.profileBaseline" },
  { value: "main", labelKey: "settings.profileMain" },
  { value: "high", labelKey: "settings.profileHigh" },
  { value: "high10", labelKey: "settings.profileHigh10" },
];

export const LEVEL_OPTIONS = [
  { value: "auto", labelKey: "settings.levelAuto" },
  { value: "3.0", labelKey: "settings.level30" },
  { value: "3.1", labelKey: "settings.level31" },
  { value: "3.2", labelKey: "settings.level32" },
  { value: "4.0", labelKey: "settings.level40" },
  { value: "4.1", labelKey: "settings.level41" },
  { value: "4.2", labelKey: "settings.level42" },
  { value: "5.0", labelKey: "settings.level50" },
  { value: "5.1", labelKey: "settings.level51" },
];

export const FRAME_RATE_OPTIONS = [
  { value: "same", labelKey: "settings.frameSame" },
  { value: "23.976", labelKey: "settings.frame23976" },
  { value: "24", labelKey: "settings.frame24" },
  { value: "25", labelKey: "settings.frame25" },
  { value: "29.97", labelKey: "settings.frame2997" },
  { value: "30", labelKey: "settings.frame30" },
  { value: "50", labelKey: "settings.frame50" },
  { value: "60", labelKey: "settings.frame60" },
];

/** Map a built-in preset onto the app config fields used by the HandBrake executor. */
export function compressionConfigValues(values: CompressionPresetValues) {
  return {
    encoder: values.encoder,
    crf: values.crf,
    encoderPreset: values.encoderPreset || "slow",
    encoderTune: values.encoderTune || "none",
    encoderProfile: values.encoderProfile || "auto",
    encoderLevel: values.encoderLevel || "auto",
    frameRate: values.frameRate || "same",
    outputResolution: values.outputResolution || "source",
  };
}

/** Map a built-in preset onto the app config fields used by the HandBrake executor. */
export function presetConfigValues(preset: ArchivePreset) {
  return compressionConfigValues(preset.values);
}

export const DEFAULT_COMPRESSION_PRESETS: ArchivePreset[] = [
  {
    id: "bluray-collection",
    labelKey: "settings.presetBlurayLabel",
    descriptionKey: "settings.presetBlurayDesc",
    icon: "💎",
    values: {
      encoder: "x264_10bit",
      // Blu-ray collection default: the higher end of the requested RF22-23
      // range keeps the source intact while avoiding an unnecessarily large
      // H.264 encode. Users can still edit this preset or choose another one.
      crf: 23,
      encoderPreset: "slow",
      encoderTune: "film",
      encoderProfile: "high10",
      encoderLevel: "4.1",
      frameRate: "same",
      outputResolution: "source",
    },
  },
  {
    id: "dvd-convert",
    labelKey: "settings.presetDvdLabel",
    descriptionKey: "settings.presetDvdDesc",
    icon: "📀",
    values: {
      encoder: "x264_10bit",
      crf: 19,
      encoderPreset: "slow",
      encoderTune: "grain",
      encoderProfile: "high10",
      encoderLevel: "3.1",
      frameRate: "same",
      outputResolution: "source",
    },
  },
  {
    id: "documentary",
    labelKey: "settings.presetDocumentaryLabel",
    descriptionKey: "settings.presetDocumentaryDesc",
    icon: "🎞",
    values: {
      encoder: "x265_10bit",
      crf: 18,
      encoderPreset: "slow",
      encoderTune: "none",
      encoderProfile: "auto",
      encoderLevel: "auto",
      frameRate: "same",
      outputResolution: "source",
    },
  },
  {
    id: "episodic",
    labelKey: "settings.presetEpisodicLabel",
    descriptionKey: "settings.presetEpisodicDesc",
    icon: "📺",
    values: {
      encoder: "x265_10bit",
      crf: 20,
      encoderPreset: "medium",
      encoderTune: "film",
      encoderProfile: "auto",
      encoderLevel: "auto",
      frameRate: "same",
      outputResolution: "source",
    },
  },
  {
    id: "balanced",
    labelKey: "settings.presetBalancedLabel",
    descriptionKey: "settings.presetBalancedDesc",
    icon: "⚙️",
    values: {
      encoder: "x265_10bit",
      crf: 22,
      encoderPreset: "medium",
      encoderTune: "none",
      encoderProfile: "auto",
      encoderLevel: "auto",
      frameRate: "same",
      outputResolution: "1080p",
    },
  },
];

/** Preset ids saved by older versions under their Chinese display labels. */
const LEGACY_PRESET_LABELS: Record<string, string[]> = {
  "bluray-collection": ["蓝光收藏"],
  "dvd-convert": ["DVD 转制"],
  documentary: ["纪录片"],
  balanced: ["通用均衡"],
};

export { ARCHIVE_PRESET_LS_KEY, CUSTOM_PRESET_KEY, PRESET_CHANGED_EVENT } from "./brand-storage";

export const ARCHIVE_PRESETS = DEFAULT_COMPRESSION_PRESETS;

function isPresetValues(value: unknown): value is Partial<CompressionPresetValues> {
  return typeof value === "object" && value !== null;
}

export function loadCompressionPresets(): ArchivePreset[] {
  try {
    const raw = localStorage.getItem(ARCHIVE_PRESET_LS_KEY);
    if (!raw) return [...DEFAULT_COMPRESSION_PRESETS];
    const saved: Array<{ label: string; values: Partial<CompressionPresetValues> }> = JSON.parse(raw);
    return DEFAULT_COMPRESSION_PRESETS.map((def) => {
      const match = saved.find(
        (item) =>
          (item.label === def.id || (LEGACY_PRESET_LABELS[def.id] ?? []).includes(item.label)) &&
          isPresetValues(item.values)
      );
      return match ? { ...def, values: { ...def.values, ...match.values } } : def;
    });
  } catch {
    return [...DEFAULT_COMPRESSION_PRESETS];
  }
}

