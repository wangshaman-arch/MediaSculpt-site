type TauriInvoke = <T>(command: string, args?: Record<string, unknown>) => Promise<T>;

type TauriInternals = {
  invoke: TauriInvoke;
};

type TauriInternalsWithEvents = TauriInternals & {
  transformCallback?: (callback: (payload: unknown) => void) => number;
};

function tauriInternals(): TauriInternals | undefined {
  const internals = globalThis.__TAURI_INTERNALS__;
  return typeof internals?.invoke === "function" ? internals : undefined;
}

export function isTauriDesktop(): boolean {
  return tauriInternals() !== undefined;
}

/**
 * 监听 Tauri 后端事件（不依赖 @tauri-apps/api 包，直接走 __TAURI_INTERNALS__）。
 * 返回取消监听函数；非 Tauri 环境或无事件能力时返回空操作。
 */
export function onTauriEvent(event: string, handler: () => void): () => void {
  const internals = (globalThis as { __TAURI_INTERNALS__?: TauriInternalsWithEvents }).__TAURI_INTERNALS__;
  if (!internals?.invoke || typeof internals.transformCallback !== "function") return () => {};
  let unlisten: (() => void) | null = null;
  void internals.invoke<{ id?: number }>("plugin:event|listen", {
    event,
    target: { kind: "Any" },
    handler: internals.transformCallback(() => handler()),
  })
    .then((registered) => {
      const id = registered?.id;
      unlisten = () => {
        if (id != null) {
          void internals.invoke("plugin:event|unlisten", { event: id, target: { kind: "Any" } }).catch(() => {});
        }
      };
    })
    .catch(() => {});
  return () => { unlisten?.(); };
}

export async function openDesktopPath(path: string): Promise<void> {
  const internals = tauriInternals();
  if (internals) {
    await internals.invoke<void>("open_path", { path });
    return;
  }

  const response = await fetch("/api/runtime/open-path", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ path }),
  });
  if (!response.ok) {
    const body = await response.json().catch(() => null) as { error?: string } | null;
    throw new Error(body?.error ?? `HTTP ${response.status}`);
  }
}

export async function setDesktopTheme(theme: string): Promise<void> {
  const internals = tauriInternals();
  if (internals) {
    await internals.invoke<void>("set_theme", { theme });
  }
}

/** 任务完成通知：桌面壳闪烁任务栏图标并弹系统通知；浏览器环境退回 Web Notification。 */
export async function notifyTaskComplete(title: string, body: string): Promise<void> {
  const internals = tauriInternals();
  if (internals) {
    try {
      await internals.invoke<void>("notify_task_complete", { title, body });
      return;
    } catch {
      // Tauri 命令暂缺时静默降级。
    }
  }
  try {
    if (typeof Notification !== "undefined" && Notification.permission === "granted") {
      new Notification(title, { body });
    } else if (typeof Notification !== "undefined" && Notification.permission !== "denied") {
      const permission = await Notification.requestPermission();
      if (permission === "granted") new Notification(title, { body });
    }
  } catch {
    // 忽略通知失败（非关键功能）。
  }
}

async function invokeDesktopWindow(command: string): Promise<void> {
  const internals = tauriInternals();
  if (internals) await internals.invoke<void>(command);
}

export function minimizeDesktopWindow(): Promise<void> {
  return invokeDesktopWindow("minimize_window");
}

export function toggleMaximizeDesktopWindow(): Promise<void> {
  return invokeDesktopWindow("toggle_maximize_window");
}

export function closeDesktopWindow(): Promise<void> {
  return invokeDesktopWindow("close_window");
}

export function isMaximizedDesktopWindow(): Promise<boolean> {
  const internals = tauriInternals();
  if (internals) return internals.invoke<boolean>("is_window_maximized");
  return Promise.resolve(false);
}
