import { afterEach, describe, expect, it, vi } from "vitest";
import {
  closeDesktopWindow,
  isTauriDesktop,
  minimizeDesktopWindow,
  openDesktopPath,
  setDesktopTheme,
  toggleMaximizeDesktopWindow,
} from "./desktop-bridge";

const originalInternals = globalThis.__TAURI_INTERNALS__;

afterEach(() => {
  if (originalInternals) {
    globalThis.__TAURI_INTERNALS__ = originalInternals;
  } else {
    delete globalThis.__TAURI_INTERNALS__;
  }
  vi.restoreAllMocks();
});

describe("desktop bridge", () => {
  it("detects the Tauri renderer when internals are present", () => {
    globalThis.__TAURI_INTERNALS__ = { invoke: vi.fn() };

    expect(isTauriDesktop()).toBe(true);
  });

  it("does not detect Tauri in browser development", () => {
    delete globalThis.__TAURI_INTERNALS__;

    expect(isTauriDesktop()).toBe(false);
  });

  it("opens a desktop path through the native Tauri command", async () => {
    const invoke = vi.fn().mockResolvedValue(undefined);
    globalThis.__TAURI_INTERNALS__ = { invoke };

    await openDesktopPath("C:\\Media\\output.mp4");

    expect(invoke).toHaveBeenCalledWith("open_path", { path: "C:\\Media\\output.mp4" });
  });

  it("uses the browser runtime endpoint when Tauri is unavailable", async () => {
    delete globalThis.__TAURI_INTERNALS__;
    const fetchMock = vi.fn().mockResolvedValue(new Response(null, { status: 204 }));
    vi.stubGlobal("fetch", fetchMock);

    await openDesktopPath("C:\\Media\\output.mp4");

    expect(fetchMock).toHaveBeenCalledWith("/api/runtime/open-path", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ path: "C:\\Media\\output.mp4" }),
    });
  });

  it("synchronizes the Tauri window theme through the native command", async () => {
    const invoke = vi.fn().mockResolvedValue(undefined);
    globalThis.__TAURI_INTERNALS__ = { invoke };

    await setDesktopTheme("morning-light");

    expect(invoke).toHaveBeenCalledWith("set_theme", { theme: "morning-light" });
  });

  it("routes custom title-bar controls to the native desktop window", async () => {
    const invoke = vi.fn().mockResolvedValue(undefined);
    globalThis.__TAURI_INTERNALS__ = { invoke };

    await minimizeDesktopWindow();
    await toggleMaximizeDesktopWindow();
    await closeDesktopWindow();

    expect(invoke).toHaveBeenNthCalledWith(1, "minimize_window");
    expect(invoke).toHaveBeenNthCalledWith(2, "toggle_maximize_window");
    expect(invoke).toHaveBeenNthCalledWith(3, "close_window");
  });
});
