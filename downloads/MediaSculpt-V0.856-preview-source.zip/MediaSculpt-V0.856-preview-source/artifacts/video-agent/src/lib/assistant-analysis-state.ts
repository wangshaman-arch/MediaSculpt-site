export type AnalysisAction = "show-existing" | "analyze" | "noop";

export function hasExistingAnalysis({ analysisResult, persistedOverview }: { analysisResult?: string | null; persistedOverview?: string | null }): boolean {
  return Boolean(analysisResult?.trim() || persistedOverview?.trim());
}

export function getAnalysisAction({ hasResult, analyzing, retryRequested = false }: { hasResult: boolean; analyzing: boolean; retryRequested?: boolean }): AnalysisAction {
  if (analyzing) return "noop";
  if (retryRequested) return "analyze";
  return hasResult ? "show-existing" : "analyze";
}

export function getRetryPromptState(): { promptOpen: true; focusPrompt: true } {
  return { promptOpen: true, focusPrompt: true };
}

export function preserveAnalysisAfterFailure(result: string | null, error: string): { result: string | null; error: string } {
  return { result, error };
}
