import { useEffect, useMemo, useRef, useState } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { getListJobsQueryKey, useGetConfig, getGetConfigQueryKey } from "@workspace/api-client-react";
import { AssistantPanel, type ProcessingStep } from "@/components/AssistantPanel";
import { type PreviewPlayerHandle } from "@/components/PreviewPlayer";
import { PreviewPlayerCard } from "@/components/PreviewPlayerCard";
import { useAssistantAnalysis, type AssistantCorrection } from "@/hooks/useAssistantAnalysis";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useI18n } from "@/i18n";
import { loadCompressionPresets, presetConfigValues } from "@/lib/compression-presets";
import { cn, formatDuration } from "@/lib/utils";
import { Ban, Captions, FileText, Film, FolderOpen, Languages, Mic, Play, ScanText, Sparkles, XCircle } from "lucide-react";
import {
  isCompressionPresetSelected,
  isSubtitleChoiceSelected,
  selectCompressionPreset,
  selectSubtitleChoice,
  type BatchSelectionState,
  type BatchSubtitle,
} from "./batch-selection-model";

const IMAGE_SUBTITLE_CODECS = new Set([
  "dvd_subtitle",
  "dvdsub",
  "vobsub",
  "hdmv_pgs_subtitle",
  "pgssub",
  "xsub",
]);

function isImageSubtitleCodec(codecName?: string | null): boolean {
  return Boolean(codecName) && IMAGE_SUBTITLE_CODECS.has(codecName!.toLowerCase());
}

type BatchPlan = {
  processing: ProcessingStep[];
  subtitleMode: BatchSubtitle;
  presetId: string | null;
};

type BatchStream = {
  index: number;
  codecType: string;
  codecName?: string | null;
  language?: string | null;
  channels?: number | null;
  width?: number | null;
  height?: number | null;
  frameRate?: string | number | null;
};

export type BatchItem = {
  key: string;
  path: string;
  kind: "dvd" | "bluray" | "video";
  label: string;
  durationSeconds?: number | null;
  titleId?: string | null;
  analysisId?: string | null;
  sourceFingerprint?: string | null;
  handbrakeTitleNumber?: number | null;
  playlistId?: string | null;
  mappingStatus?: string | null;
  verificationStatus?: string | null;
  dvdVtsNumber?: number | null;
  streams: BatchStream[];
  chapterCount?: number;
  /** Selection made by the disc analyzer; undefined means all parsed streams/chapters. */
  selectedStreamIndices?: number[];
  selectedChapterIds?: number[];
  preview?: string | null;
};

const STORAGE_KEY = "vx-batch-items";

function loadBatchItems(): BatchItem[] {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as BatchItem[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function buildDiscBody(
  item: BatchItem,
  feature: ProcessingStep,
  subtitleMode: BatchSubtitle,
  presetId: string | null,
  keepSubtitles: boolean,
  keepChapters: boolean,
  subtitleSeparate: boolean,
  compressionSettings?: ReturnType<typeof presetConfigValues>,
): Record<string, unknown> | null {
  if (!item.titleId || !item.analysisId || !item.sourceFingerprint) return null;
  const selectedStreamIndices = new Set(item.selectedStreamIndices ?? item.streams.map((stream) => stream.index));
  const video = item.streams.filter((stream) => stream.codecType === "video" && selectedStreamIndices.has(stream.index)).map((stream) => stream.index);
  const audio = item.streams.filter((stream) => stream.codecType === "audio" && selectedStreamIndices.has(stream.index)).map((stream) => stream.index);
  const subtitle = keepSubtitles
    ? item.streams.filter((stream) => stream.codecType === "subtitle" && selectedStreamIndices.has(stream.index)).map((stream) => stream.index)
    : [];
  if (video.length === 0) return null;
  const chapterArr = keepChapters && item.selectedChapterIds
    ? [...item.selectedChapterIds]
    : keepChapters && item.chapterCount && item.chapterCount > 0
      ? Array.from({ length: item.chapterCount }, (_, index) => index)
    : [0];
  const outputMode = feature === "remux"
    ? "remux"
    : feature === "compress"
      ? "compress"
      : feature === "chapterPreview"
        ? "compress"
      : subtitleMode === "whisper"
        ? "whisper"
        : "subtitle";
  const selectionPlan = JSON.stringify({
    version: 1,
    analysis: {
      analysisId: item.analysisId,
      titleId: item.titleId,
      mappingStatus: item.mappingStatus ?? "not-required",
    },
    video,
    audio,
    audioStreams: item.streams
      .filter((stream) => stream.codecType === "audio" && selectedStreamIndices.has(stream.index))
      .map((stream) => ({ inputIndex: stream.index, codecName: stream.codecName ?? null, bitsPerRawSample: null })),
    subtitle,
    chapters: chapterArr,
    handbrake: item.handbrakeTitleNumber ? {
      titleNumber: item.handbrakeTitleNumber,
      titleSizeBytes: null,
      durationSeconds: item.durationSeconds,
      audioTrackNumbers: [],
      subtitleTrackNumbers: subtitle,
      chapterNumbers: [1],
    } : undefined,
    playlistId: item.playlistId ?? null,
    presetId: feature === "compress" ? presetId : null,
    ...(feature === "chapterPreview" ? { chapterSamplePosition: "middle" } : {}),
    dvdvideo: {
      titleNumber: item.dvdVtsNumber ?? null,
      verified: item.verificationStatus === "verified",
    },
    analyzer: "unified",
  });
  return {
    filePath: item.path,
    // 压缩与字幕同时选择时，压缩任务跳过字幕（由独立字幕任务负责），避免重复处理。
    subtitleMode: feature === "remux" || (feature === "compress" && subtitleSeparate) ? "skip" : subtitleMode,
    mediaType: item.kind,
    // 仅字幕模式在任务创建接口中对应 processingMode "none"（输出模式仍为字幕）。
    processingMode: feature === "subtitle" ? "none" : feature,
    mainTrackPath: item.path,
    selectedStreams: JSON.stringify([...video, ...audio, ...subtitle]),
    selectedChapters: JSON.stringify(chapterArr),
    selectionPlan,
    analysisId: item.analysisId,
    sourceFingerprint: item.sourceFingerprint,
    selectedTitleId: item.titleId,
    outputMode,
    ...(feature === "compress" && compressionSettings ? { compressionSettings } : {}),
    ...(feature === "compress" && presetId ? { presetId } : {}),
  };
}

function buildVideoBody(item: BatchItem, feature: ProcessingStep, subtitleMode: BatchSubtitle, presetId: string | null, subtitleSeparate: boolean, compressionSettings?: ReturnType<typeof presetConfigValues>): Record<string, unknown> | null {
  // Remux 仅对光盘源有效：视频文件不生成 Remux 任务（直接跳过，避免重复字幕任务）。
  if (feature === "remux") return null;
  const selectedStreamIndices = new Set(item.selectedStreamIndices ?? item.streams.map((stream) => stream.index));
  const video = item.streams.filter((stream) => stream.codecType === "video" && selectedStreamIndices.has(stream.index)).map((stream) => stream.index);
  const audio = item.streams.filter((stream) => stream.codecType === "audio" && selectedStreamIndices.has(stream.index)).map((stream) => stream.index);
  if (item.streams.length === 0 && video.length === 0) return null;
  const actualMode: "compress" | "subtitle" | "chapterPreview" = feature === "compress"
    ? "compress"
    : feature === "chapterPreview"
      ? "chapterPreview"
      : "subtitle";
  const outputMode = actualMode === "compress"
    ? "compress"
    : actualMode === "chapterPreview"
      ? "compress"
    : subtitleMode === "whisper"
      ? "whisper"
      : "subtitle";
  return {
    filePath: item.path,
    // 压缩与字幕同时选择时，压缩任务跳过字幕（由独立字幕任务负责），避免重复处理。
    subtitleMode: actualMode === "chapterPreview" || (actualMode === "compress" && subtitleSeparate) ? "skip" : subtitleMode,
    mediaType: "video",
    processingMode: actualMode === "subtitle" ? "none" : actualMode === "chapterPreview" ? "chapterPreview" : "compress",
    selectedStreams: item.streams.length > 0 ? JSON.stringify([...video, ...audio]) : undefined,
    selectedChapters: "[]",
    outputMode,
    ...(actualMode === "compress" && compressionSettings ? { compressionSettings } : {}),
    ...(actualMode === "chapterPreview" ? { selectionPlan: JSON.stringify({ version: 1, chapterSamplePosition: "middle" }) } : {}),
    ...(actualMode === "compress" && presetId ? { presetId } : {}),
  };
}

export default function BatchConfirmPage() {
  const { t } = useI18n();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { data: appConfig } = useGetConfig({ query: { queryKey: getGetConfigQueryKey(), refetchOnWindowFocus: false } });
  const aiAvailable = !!(appConfig?.deepseekApiKey || appConfig?.openaiApiKey || appConfig?.siliconflowApiKey || appConfig?.zhipuApiKey || appConfig?.moonshotApiKey || appConfig?.qwenApiKey || appConfig?.groqApiKey || appConfig?.geminiApiKey);
  const [items, setItems] = useState<BatchItem[]>(() => loadBatchItems());
  const [enabled, setEnabled] = useState<Set<string>>(() => new Set(loadBatchItems().map((item) => item.key)));
  const [selection, setSelection] = useState<BatchSelectionState>({ processing: [], subtitleMode: null, presetId: null });
  const { processing, subtitleMode, presetId } = selection;
  // 每项功能拥有独立的选项面板，打开压缩不会覆盖字幕或 Remux 的配置。
  const [openFeaturePanels, setOpenFeaturePanels] = useState<Set<"remux" | "subtitle" | "preset" | "chapterPreview">>(new Set());
  const [keepSubtitles, setKeepSubtitles] = useState(false);
  const [keepChapters, setKeepChapters] = useState(true);
  const [confirmedPlan, setConfirmedPlan] = useState<BatchPlan | null>(null);
  const [activeKey, setActiveKey] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [previewPlaying, setPreviewPlaying] = useState(false);
  const playerRef = useRef<PreviewPlayerHandle>(null);
  /** The analysis card is portaled onto the video area so it never displaces the list. */
  const [analysisOverlayTarget, setAnalysisOverlayTarget] =
    useState<HTMLDivElement | null>(null);
  const [subtitlePreviewKind, setSubtitlePreviewKind] = useState<"off" | `embedded:${number}`>("off");
  const [showAllTracks, setShowAllTracks] = useState(false);
  const presets = useMemo(() => loadCompressionPresets(), []);
  const presetOptions = useMemo(
    () => presets.map((preset) => ({ id: preset.id, label: t(preset.labelKey) })),
    [presets, t],
  );

  useEffect(() => {
    if (items.length > 0 && !activeKey) setActiveKey(items[0]!.key);
  }, [items, activeKey]);

  const activeItem = items.find((item) => item.key === activeKey) ?? null;
  const hasDisc = items.some((item) => item.kind !== "video");
  const enabledCount = items.filter((item) => enabled.has(item.key)).length;
  const batchPreviewAspectRatio = (() => {
    const video = activeItem?.streams.find((stream) => stream.codecType === "video");
    return video?.width && video?.height ? `${video.width} / ${video.height}` : undefined;
  })();
  const activeSubtitleTracks = activeItem?.streams.filter((stream) => stream.codecType === "subtitle") ?? [];
  const batchSubtitleControls = activeItem ? (
    <>
      <Button variant={subtitlePreviewKind === "off" ? "default" : "outline"} size="sm" className="h-7 shrink-0 px-1.5 text-[11px]" onClick={() => { setSubtitlePreviewKind("off"); playerRef.current?.rebuild(playerRef.current.getCurrentTime(), null); }}>{t("jobDetail.subtitleOff")}</Button>
      {activeSubtitleTracks.slice(0, showAllTracks ? undefined : 3).map((track) => (
        <Button
          key={track.index}
          variant={subtitlePreviewKind === `embedded:${track.index}` ? "default" : "outline"}
          size="sm"
          disabled={activeItem.kind === "dvd"}
          title={activeItem.kind === "dvd" ? t("batch.subtitleUnsupported") : track.codecName ? `#${track.index} · ${track.codecName}` : undefined}
          className="h-7 shrink-0 px-1.5 text-[11px]"
          onClick={() => {
            setSubtitlePreviewKind(`embedded:${track.index}`);
            playerRef.current?.rebuild(playerRef.current.getCurrentTime(), isImageSubtitleCodec(track.codecName) ? track.index : null);
          }}
        >
          {t("jobDetail.embeddedTrack", { index: track.index })}{track.language && track.language !== "und" ? ` · ${track.language.toUpperCase()}` : ""}
        </Button>
      ))}
      {activeSubtitleTracks.length > 3 && (
        <Button variant="ghost" size="sm" className="h-7 px-1.5 text-[11px]" onClick={() => setShowAllTracks((value) => !value)}>
          {showAllTracks ? t("jobDetail.embeddedTrackCollapse") : t("jobDetail.embeddedTrackMore", { count: activeSubtitleTracks.length - 3 })}
        </Button>
      )}
    </>
  ) : undefined;
  const analysisContextRef = useRef<Record<string, unknown>>({});
  analysisContextRef.current = {
    sourcePath: activeItem?.path ?? "",
    sourceType: activeItem?.kind ?? "",
    items: items.map((item) => ({ path: item.path, label: item.label, kind: item.kind })),
  };
  const [correction, setCorrection] = useState<AssistantCorrection | null>(null);
  const assistantAnalysis = useAssistantAnalysis({
    contextType: "workflow",
    contextRef: analysisContextRef,
    onCorrection: setCorrection,
  });
  const stepLabel = (step: ProcessingStep) => t(
    step === "remux" ? "assistant.optionRemux" : step === "compress" ? "assistant.optionCompress" : "assistant.optionSubtitleOnly",
  );
  const subtitleLabel = (m: BatchSubtitle) => t(
    m === "auto"
      ? "assistant.optionAuto"
      : m === "extract"
        ? "assistant.optionExtract"
        : m === "whisper"
          ? "assistant.optionWhisper"
        : m === "transcribe_translate"
          ? "assistant.optionTranscribeTranslate"
          : m === "ocr"
            ? "assistant.optionOcr"
          : m === "bilingual"
            ? "assistant.optionBilingual"
            : "assistant.optionSkip",
  );

  function confirmFeatures() {
    if (processing.length === 0) {
      toast({ title: t("batch.modeRequired"), variant: "destructive" });
      return;
    }
    setConfirmedPlan({ processing: [...processing], subtitleMode: subtitleMode ?? "skip", presetId });
    toast({ title: t("batch.paramConfirmed") });
  }

  const toggleItem = (key: string) => {
    setEnabled((current) => {
      const next = new Set(current);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });
  };

  async function runBatchConfirm() {
    if (creating) return;
    const plan = confirmedPlan;
    if (!plan || plan.processing.length === 0) {
      toast({ title: t("batch.confirmFeaturesFirst"), variant: "destructive" });
      return;
    }
    const buildable = items.filter((item) => enabled.has(item.key));
    if (buildable.length === 0) return;
    setCreating(true);
    let created = 0;
    let failed = 0;
    const selectedPreset = plan.presetId ? presets.find((preset) => preset.id === plan.presetId) : undefined;
    const compressionSettings = selectedPreset ? presetConfigValues(selectedPreset) : undefined;
    for (const item of buildable) {
      for (const feature of plan.processing) {
        // Remux 仅对光盘源有效：视频文件直接跳过该功能。
        if (feature === "remux" && item.kind === "video") continue;
        try {
          const subtitleSeparate = plan.processing.includes("subtitle");
          const body = item.kind === "video"
            ? buildVideoBody(item, feature, plan.subtitleMode ?? "skip", plan.presetId, subtitleSeparate, compressionSettings)
            : buildDiscBody(item, feature, plan.subtitleMode ?? "skip", plan.presetId, keepSubtitles, keepChapters, subtitleSeparate, compressionSettings);
          if (!body) {
            failed += 1;
            continue;
          }
          const response = await fetch("/api/jobs", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify(body),
          });
          const data = await response.json().catch(() => ({})) as { id?: number; error?: string };
          if (!response.ok || typeof data.id !== "number") {
            failed += 1;
            continue;
          }
          await fetch(`/api/jobs/${data.id}/start`, { method: "POST" }).catch(() => {});
          created += 1;
        } catch {
          failed += 1;
        }
      }
    }
    setCreating(false);
    const description = [created > 0 ? t("batch.createdCount", { count: created }) : null, failed > 0 ? t("batch.failedCount", { count: failed }) : null]
      .filter(Boolean)
      .join(" · ");
    toast({ title: t("batch.doneTitle"), description });
    queryClient.invalidateQueries({ queryKey: getListJobsQueryKey() });
    sessionStorage.removeItem(STORAGE_KEY);
    setLocation("/jobs");
  }

  const streamInfoBar = (
    <div className="shrink-0 space-y-1 border-t px-3 py-2 text-xs text-muted-foreground">
      <div className="flex items-center justify-between gap-2">
        <span className="truncate font-mono" title={activeItem?.path}>{activeItem?.path ?? ""}</span>
        {activeItem && (
          <span className="ml-2 shrink-0">
            {activeItem.kind === "video" ? "VIDEO" : activeItem.kind === "dvd" ? "DVD" : "BD"}
            {typeof activeItem.durationSeconds === "number" && activeItem.durationSeconds > 0
              ? ` · ${formatDuration(activeItem.durationSeconds)}`
              : ""}
          </span>
        )}
      </div>
      {activeItem && (() => {
        const video = activeItem.streams.filter((stream) => stream.codecType === "video");
        const audio = activeItem.streams.filter((stream) => stream.codecType === "audio");
        const subtitles = activeItem.streams.filter((stream) => stream.codecType === "subtitle");
        return (
          <div className="flex flex-wrap gap-x-3 gap-y-1" data-testid="batch-preview-streams">
            {video.map((stream) => (
              <span key={`v${stream.index}`}>
                {t("jobDetail.videoCodec", { value: stream.codecName ?? "?" })}
                {stream.width && stream.height ? ` · ${stream.width}×${stream.height}` : ""}
                {stream.frameRate ? ` · ${String(stream.frameRate)}fps` : ""}
              </span>
            ))}
            {audio.map((stream) => (
              <span key={`a${stream.index}`}>
                {t("jobDetail.audioTracks", { count: 1 })} · {stream.language ?? "?"}
                {stream.channels ? ` · ${stream.channels}ch` : ""}
                {stream.codecName ? ` · ${stream.codecName}` : ""}
              </span>
            ))}
            {subtitles.map((stream) => (
              <span key={`s${stream.index}`} className="font-mono">
                {t("jobDetail.subtitleTracks", { count: 1 })} · {stream.language ?? "?"}
                {stream.codecName ? ` · ${stream.codecName}` : ""}
              </span>
            ))}
            {video.length === 0 && audio.length === 0 && subtitles.length === 0 && (
              <span>{t("batch.noStreamInfo")}</span>
            )}
          </div>
        );
      })()}
    </div>
  );

  return (
    <div className="mx-auto flex h-full min-h-0 w-full min-w-0 max-w-full flex-col gap-3 overflow-hidden" data-testid="batch-confirm-page">
      <div className="flex items-center justify-between gap-2 rounded-xl border bg-card/80 px-3 py-2">
        <h2 className="text-base font-semibold">{t("batch.title")}</h2>
        <span className="text-sm text-muted-foreground">{t("scan.selectedCount", { count: enabledCount })}</span>
      </div>

      <AssistantPanel
        contextType="workflow"
        context={{ sourcePath: activeItem?.path ?? "", sourceType: activeItem?.kind ?? "" }}
        allowRemux={hasDisc}
        aiAvailable={aiAvailable}
        presets={presetOptions}
        selectedPresetId={presetId}
        expandMode="inline"
        analysisPlacement="video-overlay"
        analysisPortalTarget={analysisOverlayTarget}
        promptPlacement="toolbar"
        prompt={assistantAnalysis.prompt}
        promptOpen={assistantAnalysis.promptOpen}
        onPromptToggle={assistantAnalysis.setPromptOpen}
        onPromptChange={assistantAnalysis.setPrompt}
        onAnalyze={(fields) => void assistantAnalysis.analyze(fields)}
        analyzing={assistantAnalysis.analyzing}
        analysisResult={assistantAnalysis.analysisResult}
        analysisPosterUrl={assistantAnalysis.analysisPosterUrl}
        metadata={{ metadataSnapshot: assistantAnalysis.analysisMetadata }}
        analysisOpen={assistantAnalysis.analysisOpen}
        onAnalysisOpenChange={assistantAnalysis.setAnalysisOpen}
        correction={correction}
        preferences={{
          processing,
          subtitle: subtitleMode,
        }}
        onPreferencesChange={(prefs) => {
          setSelection((current) => ({
            ...current,
            processing: prefs.processing,
            subtitleMode: prefs.subtitle,
            presetId: prefs.processing.includes("compress") ? current.presetId : null,
          }));
        }}
        onPresetSelect={(id) => setSelection((current) => selectCompressionPreset(current, id))}
        batchMode
        batchCount={enabledCount}
        onFeatureClick={(feature) => {
          if (feature) setOpenFeaturePanels((current) => new Set(current).add(feature));
        }}
        onBatchConfirm={() => void runBatchConfirm()}
        onConfirm={confirmFeatures}
        confirmed={!!confirmedPlan}
      />

      <div className="grid min-h-0 min-w-0 flex-1 gap-3 md:grid-cols-[minmax(0,1fr)_minmax(16rem,22rem)] md:grid-rows-1">
        {/* 视频与字幕预览区 */}
        <div className="relative min-w-0 space-y-3 md:h-full md:min-h-0 md:space-y-0">
          <div
            ref={setAnalysisOverlayTarget}
            className={cn(
              "absolute inset-0 z-30 overflow-hidden p-2 md:p-3",
              assistantAnalysis.analysisOpen ? "bg-background/95" : "pointer-events-none",
            )}
            data-testid="batch-analysis-overlay"
          />
          {activeItem ? (
            <PreviewPlayerCard
              ref={playerRef}
              src={activeItem.kind === "video"
                ? `/api/media/preview.mp4?path=${encodeURIComponent(activeItem.path)}`
                : `/api/disc/title-preview.mp4?analysisId=${encodeURIComponent(activeItem.analysisId ?? "")}&titleId=${encodeURIComponent(activeItem.titleId ?? "")}`}
              metaUrl={activeItem.kind === "video"
                ? `/api/media/preview/meta?path=${encodeURIComponent(activeItem.path)}`
                : `/api/disc/title-preview/meta?analysisId=${encodeURIComponent(activeItem.analysisId ?? "")}&titleId=${encodeURIComponent(activeItem.titleId ?? "")}`}
              rawUrl={activeItem.kind === "video" && /\.(mp4|m4v|webm|mov)$/i.test(activeItem.path)
                ? `/api/media/preview?path=${encodeURIComponent(activeItem.path)}`
                : undefined}
              // 普通视频使用连续转码流，避免每 5 秒切换分段 src 造成画面跳动；
              // 浏览器可直接播放的格式则走原始流并使用原生 seek。
              nativeSeek={activeItem.kind === "video" && /\.(mp4|m4v|webm|mov)$/i.test(activeItem.path)}
              segmentMode={false}
              aspectRatio={batchPreviewAspectRatio}
              playing={previewPlaying}
              expanded
              onPlayingChange={setPreviewPlaying}
              extraControls={batchSubtitleControls}
              footer={streamInfoBar}
            />
          ) : (
            <Card className="flex h-[min(58vh,calc(100vh-19rem))] items-center justify-center rounded-lg border bg-black">
              <div className="px-6 py-10 text-center text-sm text-muted-foreground/70">
                <Play className="mx-auto mb-2 h-8 w-8 opacity-40" />
                <p>{t("batch.previewPlaceholder")}</p>
              </div>
            </Card>
          )}
        </div>

        {/* 批量项列表 */}
        <Card className="flex flex-col p-0">
          {openFeaturePanels.size > 0 && (
            <div className="space-y-1.5 border-b px-3 py-2" data-testid="batch-detail-options">
              {openFeaturePanels.has("chapterPreview") && (
                <div className="text-[11px] text-muted-foreground" data-testid="batch-chapter-preview-options">
                  {t("batch.chapterPreviewHint")}
                </div>
              )}
              {openFeaturePanels.has("remux") && (
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5" data-testid="batch-remux-options">
                  <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                    <span className="rounded bg-secondary px-1.5 py-0.5 font-mono text-[10px]">MKV</span>
                    {t("batch.remuxContainer")}
                  </span>
                  <label className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                    <Checkbox
                      checked={keepSubtitles}
                      onCheckedChange={(checked) => setKeepSubtitles(checked === true)}
                    />
                    {t("batch.keepSubtitles")}
                  </label>
                  <label className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                    <Checkbox
                      checked={keepChapters}
                      onCheckedChange={(checked) => setKeepChapters(checked === true)}
                    />
                    {t("batch.keepChapters")}
                  </label>
                </div>
              )}
              {openFeaturePanels.has("subtitle") && (
                <div className="grid gap-1.5 sm:grid-cols-2" data-testid="batch-subtitle-detail">
                  {([
                    { value: "auto", labelKey: "assistant.optionAuto", descKey: "assistant.optionAutoDesc", Icon: Sparkles },
                    { value: "extract", labelKey: "assistant.optionExtract", descKey: "assistant.optionExtractDesc", Icon: FileText },
                    { value: "whisper", labelKey: "assistant.optionWhisper", descKey: "assistant.optionWhisperDesc", Icon: Mic },
                    { value: "transcribe_translate", labelKey: "assistant.optionTranscribeTranslate", descKey: "assistant.optionTranscribeTranslateDesc", Icon: Languages },
                    { value: "ocr", labelKey: "assistant.optionOcr", descKey: "assistant.optionOcrDesc", Icon: ScanText },
                    { value: "bilingual", labelKey: "assistant.optionBilingual", descKey: "assistant.optionBilingualDesc", Icon: Captions },
                    { value: "skip", labelKey: "assistant.optionSkip", descKey: "assistant.optionSkipDesc", Icon: Ban },
                  ] as const).map((option) => (
                    <button
                      key={option.value}
                      type="button"
                      title={t(option.descKey)}
                      onClick={() => {
                        // 再次点击已选中的同一选项 = 取消选择字幕（一级高亮消失）。
                        setSelection((current) => selectSubtitleChoice(current, option.value));
                      }}
                      className={cn(
                        "rounded-lg border px-3 py-2 text-left transition-colors",
                        isSubtitleChoiceSelected(selection, option.value)
                          ? option.value === "auto" || option.value === "bilingual"
                            ? "border-amber-400/70 bg-amber-400/15"
                            : "border-primary/60 bg-primary/20"
                          : "border-border/70 hover:border-primary/40",
                      )}
                    >
                      <div className="flex items-center gap-1.5 text-xs font-medium text-foreground">
                        <option.Icon className={cn(
                          "h-4 w-4 shrink-0",
                          isSubtitleChoiceSelected(selection, option.value)
                            ? option.value === "auto" || option.value === "bilingual" ? "text-amber-400" : "text-primary"
                            : "text-violet-400",
                        )} />
                        {t(option.labelKey)}
                      </div>
                    </button>
                  ))}
                </div>
              )}
              {openFeaturePanels.has("preset") && (
                <div className="grid gap-1.5 sm:grid-cols-2" data-testid="batch-preset-detail">
                  {presets.map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      title={t(preset.descriptionKey)}
                      onClick={() => {
                        // 再次点击已选中的同一预设 = 取消选择压缩（一级高亮消失）。
                        setSelection((current) => selectCompressionPreset(current, preset.id));
                      }}
                      className={cn(
                        "rounded-lg border px-3 py-2 text-left transition-colors",
                        isCompressionPresetSelected(selection, preset.id)
                          ? "border-primary/60 bg-primary/20"
                          : "border-border/70 hover:border-primary/40",
                      )}
                    >
                      <div className="flex items-center gap-1.5 text-xs font-medium text-foreground">
                        <span className="text-sm leading-none">{preset.icon}</span>
                        {t(preset.labelKey)}
                      </div>
                      <p className="mt-0.5 text-[11px] text-muted-foreground">{t(preset.descriptionKey)}</p>
                      <p className="mt-1 font-mono text-[11px] text-muted-foreground/80">
                        {preset.values.encoder} · CRF {preset.values.crf} · {preset.values.encoderPreset}
                        {preset.values.outputResolution && preset.values.outputResolution !== "source"
                          ? ` · ${preset.values.outputResolution}`
                          : ""}
                        {preset.values.frameRate && preset.values.frameRate !== "same" ? ` · ${preset.values.frameRate}` : ""}
                      </p>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
          <div className="shrink-0 border-b px-3 py-2 text-xs font-medium text-muted-foreground">{t("batch.preview", { count: enabledCount })}</div>
          <div className="space-y-1 p-2">
            {items.length === 0 && (
              <div className="py-8 text-center text-xs text-muted-foreground">
                {t("batch.emptyItems")}
                <div className="mt-2">
                  <Button type="button" size="sm" variant="outline" onClick={() => setLocation("/workbench")}>
                    {t("batch.backToScan")}
                  </Button>
                </div>
              </div>
            )}
            {items.map((item) => (
              <div
                key={item.key}
                className={cn(
                  "flex w-full items-start gap-2 rounded-lg border px-2.5 py-2 text-left text-xs transition-colors",
                  activeKey === item.key ? "border-primary/50 bg-primary/5" : "border-border/70 bg-card/70 hover:border-primary/30",
                )}
              >
                <Checkbox
                  checked={enabled.has(item.key)}
                  onCheckedChange={() => toggleItem(item.key)}
                />
                <button
                  type="button"
                  onClick={() => setActiveKey(item.key)}
                  className="flex min-w-0 flex-1 items-start gap-2 text-left text-xs"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      {item.kind === "video"
                        ? <Film className="h-3 w-3 shrink-0 text-muted-foreground" />
                        : <FolderOpen className="h-3 w-3 shrink-0 text-amber-400" />}
                      <span className="truncate font-medium text-foreground">{item.label}</span>
                    </div>
                    <p className="mt-0.5 truncate font-mono text-[10px] text-muted-foreground/80" title={item.path}>{item.path}</p>
                    <p className="mt-0.5 flex flex-wrap gap-x-2 text-[10px] text-muted-foreground">
                      {processing.length > 0 && <span>{processing.map((s) => stepLabel(s)).join(" + ")}</span>}
                      {processing.includes("subtitle") && <span>{subtitleLabel(subtitleMode ?? "skip")}</span>}
                      {processing.includes("compress") && presetId && <span>{presetOptions.find((p) => p.id === presetId)?.label ?? presetId}</span>}
                    </p>
                  </div>
                  {!enabled.has(item.key) && <XCircle className="mt-0.5 h-3 w-3 shrink-0 text-muted-foreground/50" />}
                </button>
              </div>
            ))}
          </div>
        </Card>
      </div>

    </div>
  );
}
