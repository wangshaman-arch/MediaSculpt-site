import { useListJobs, getListJobsQueryKey, useStartJob, useCancelJob, useRetryJob, useDeleteJob, useGetConfig, getGetConfigQueryKey, type ListJobsStatus } from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { JobStatusBadge } from "@/components/JobStatusBadge";
import { parseBlockedJobCode, blockedReasonKey } from "@/lib/blocked-job";
import { ocrEngineLabel, ocrLanguageLabel } from "@/lib/ocr-languages";
import { cn, formatBytes, formatDate, toHostPath } from "@/lib/utils";
import { openDesktopPath } from "@/lib/desktop-bridge";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";
import { Play, Square, RotateCcw, Trash2, Search, Filter, FolderOpen, PauseCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useI18n } from "@/i18n";

type StatusFilter = "all" | "pending" | "scanning" | "transcribing" | "compressing" | "paused" | "done" | "error";

const RUNNING_JOB_STATUSES = new Set(["scanning", "transcribing", "compressing", "remuxing"]);
const BATCH_STARTABLE_STATUSES = new Set(["pending", "error", "paused"]);
const ROW_BUTTON_CLASS = "h-8 border-primary/70 bg-primary/5 text-primary hover:bg-primary/15 hover:text-primary disabled:pointer-events-none disabled:border-border disabled:bg-transparent disabled:text-white disabled:opacity-100";

function formatDurationCompact(seconds: number | null | undefined): string {
  const total = Math.max(0, Math.round(seconds ?? 0));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
}

/** Show the job duration; pending jobs fall back to the planned duration in the selection plan. */
function jobDurationSeconds(job: { durationSeconds?: number | null; selectionPlan?: string | null }): number | null {
  if (typeof job.durationSeconds === "number" && job.durationSeconds > 0) return job.durationSeconds;
  if (!job.selectionPlan) return null;
  try {
    const plan = JSON.parse(job.selectionPlan) as { handbrake?: { durationSeconds?: number | null } };
    return typeof plan.handbrake?.durationSeconds === "number" && plan.handbrake.durationSeconds > 0
      ? plan.handbrake.durationSeconds
      : null;
  } catch {
    return null;
  }
}

// Brand names stay literal; the three entries below have Chinese display names
// and must go through the language packs (product rule: no hard-coded visible
// text in components).
const PROVIDER_NAME_KEYS: Record<string, string> = {
  zhipu: "jobs.providerZhipu",
  qwen: "jobs.providerQwen",
  custom: "jobs.providerCustom",
};

const PROVIDER_BRAND_NAMES: Record<string, string> = {
  deepseek: "DeepSeek",
  openai: "OpenAI",
  groq: "Groq",
  gemini: "Gemini",
  libretranslate: "LibreTranslate",
  siliconflow: "SiliconFlow",
  moonshot: "Kimi",
};

function providerDisplayName(
  provider: string | null | undefined,
  t: (key: string) => string,
): string {
  const id = provider ?? "";
  if (PROVIDER_BRAND_NAMES[id]) return PROVIDER_BRAND_NAMES[id];
  if (PROVIDER_NAME_KEYS[id]) return t(PROVIDER_NAME_KEYS[id]);
  return id || "LLM";
}

function planLabelFor(
  job: {
    processingMode?: string | null;
    subtitleMode?: string | null;
    ocrEngine?: string | null;
    ocrLanguage?: string | null;
    subtitleSource?: string | null;
    translatedSubtitlePath?: string | null;
  },
  config: { aiProvider?: string | null } | undefined,
  t: (key: string, params?: Record<string, string>) => string,
): string {
  if (job.processingMode === "remux") return t("jobs.planRemux");
  if (job.processingMode === "audio") return t("jobs.planAudioExtract");
  const provider = providerDisplayName(config?.aiProvider, t);
  const parts: string[] = [];
  if (job.processingMode === "compress") parts.push(t("jobs.planCompress"));
  switch (job.subtitleMode) {
    case "auto":
      if (job.subtitleSource === "embedded-chinese" || job.subtitleSource === "external-chinese") {
        parts.push(t("jobs.planChineseSkip"));
      } else if (job.subtitleSource === "external" && job.translatedSubtitlePath) {
        parts.push(t("jobs.planExternalTranslate", { provider }));
      } else if (job.subtitleSource === "external") {
        parts.push(t("jobs.planExternal"));
      } else if (job.subtitleSource === "embedded" && job.translatedSubtitlePath) {
        parts.push(t("jobs.planExtractTranslate", { provider }));
      } else if (job.subtitleSource === "embedded") {
        parts.push(t("jobs.planExtract"));
      } else {
        parts.push(provider === "LibreTranslate" ? t("jobs.planAutoLocal") : t("jobs.planAuto", { provider }));
      }
      break;
    case "whisper":
      parts.push(t("jobs.planForceWhisper"));
      break;
    case "extract":
      parts.push(t("jobs.planExtract"));
      break;
    case "transcribe_translate":
      parts.push(t("jobs.planLocalTranslate"));
      break;
    case "bilingual":
      parts.push(t("jobs.planBilingual"));
      break;
    case "ocr":
      parts.push(t("jobs.planOcr", {
        engine: ocrEngineLabel(job.ocrEngine, t),
        language: ocrLanguageLabel(job.ocrLanguage, t),
      }));
      break;
    default:
      if (job.processingMode !== "compress") parts.push(t("jobs.planSkip"));
  }
  return parts.join(" + ");
}

export default function Jobs({ embedded = false }: { embedded?: boolean }) {
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [search, setSearch] = useState("");
  const [selectedJobIds, setSelectedJobIds] = useState<Set<number>>(new Set());
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [queuePaused, setQueuePaused] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { t, lang } = useI18n();
  const STATUS_OPTIONS = [
    { value: "all" as const,          label: t("jobs.all") },
    { value: "pending" as const,      label: t("jobs.pending") },
    { value: "scanning" as const,     label: t("jobs.scanning") },
    { value: "transcribing" as const, label: t("jobs.transcribing") },
    { value: "compressing" as const,  label: t("jobs.compressing") },
    { value: "paused" as const,       label: t("jobs.paused") },
    { value: "done" as const,         label: t("jobs.done") },
    { value: "error" as const,        label: t("jobs.error") },
  ];
  const { data: config } = useGetConfig({ query: { queryKey: getGetConfigQueryKey() } });

  useEffect(() => {
    fetch("/api/jobs/queue-status")
      .then((response) => response.ok ? response.json() : null)
      .then((body: { paused?: boolean } | null) => { if (body) setQueuePaused(body.paused === true); })
      .catch(() => {});
  }, []);

  const openOutputPath = async (p: string) => {
    const hostPath = toHostPath(p, config) || p;
    try {
      await openDesktopPath(hostPath);
      toast({ title: t("common.folderOpened") });
    } catch (e: unknown) {
      toast({ title: t("common.openFailed"), description: e instanceof Error ? e.message : t("common.unknownError"), variant: "destructive" });
    }
  };

  const { data: jobs } = useListJobs(
    { status: (statusFilter === "all" ? undefined : statusFilter) as ListJobsStatus | undefined, limit: 200 },
    { query: { refetchInterval: 3000, queryKey: getListJobsQueryKey({ status: (statusFilter === "all" ? undefined : statusFilter) as ListJobsStatus | undefined, limit: 200 }) } }
  );

  const startJob = useStartJob();
  const cancelJob = useCancelJob();
  const retryJob = useRetryJob();
  const deleteJob = useDeleteJob();

  const handleAction = async (action: { mutateAsync: (args: { id: number }) => Promise<unknown> }, id: number, message: string) => {
    try {
      await action.mutateAsync({ id });
      toast({ title: message });
      queryClient.invalidateQueries({ queryKey: getListJobsQueryKey() });
    } catch (e: unknown) {
      toast({ title: t("jobs.operationFailed"), description: e instanceof Error ? e.message : t("common.unknownError"), variant: "destructive" });
    }
  };

  const filteredJobs = jobs?.filter(job =>
    job.filePath.toLowerCase().includes(search.toLowerCase()) ||
    (job.movieTitle ?? "").toLowerCase().includes(search.toLowerCase())
  );
  const isDiscCompressionJob = (job: { processingMode?: string | null; mediaType?: string | null }) => (
    job.processingMode === "compress" && (job.mediaType === "dvd" || job.mediaType === "bluray" || job.mediaType === "iso")
  );
  const pendingJobs = filteredJobs?.filter(job => job.status === "pending") ?? [];
  const batchStartableJobs = filteredJobs?.filter(job => BATCH_STARTABLE_STATUSES.has(job.status)) ?? [];
  const selectedStartableJobs = (jobs ?? []).filter(job => selectedJobIds.has(job.id) && !RUNNING_JOB_STATUSES.has(job.status));
  const selectionHasRunning = (jobs ?? []).some(job => selectedJobIds.has(job.id) && RUNNING_JOB_STATUSES.has(job.status));
  const runningJobs = (jobs ?? []).filter(job => RUNNING_JOB_STATUSES.has(job.status));
  const allPendingJobs = (jobs ?? [])
    .filter(job => job.status === "pending")
    .sort((a, b) => {
      const createdDiff = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      return createdDiff || a.id - b.id;
    });
  const pendingQueuePositions = new Map(allPendingJobs.map((job, index) => [job.id, index + 1]));
  const visibleJobs = [...(filteredJobs ?? [])].sort((a, b) => {
    const aRunning = RUNNING_JOB_STATUSES.has(a.status);
    const bRunning = RUNNING_JOB_STATUSES.has(b.status);
    if (aRunning !== bRunning) return aRunning ? -1 : 1;
    if (a.status === "pending" && b.status === "pending") {
      return (pendingQueuePositions.get(a.id) ?? Number.MAX_SAFE_INTEGER) - (pendingQueuePositions.get(b.id) ?? Number.MAX_SAFE_INTEGER);
    }
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });
  const allVisibleSelected = visibleJobs.length > 0 && visibleJobs.every(job => selectedJobIds.has(job.id));
  const someVisibleSelected = visibleJobs.some(job => selectedJobIds.has(job.id));

  const toggleAllVisible = () => {
    setSelectedJobIds((current) => {
      const next = new Set(current);
      if (allVisibleSelected) {
        for (const job of visibleJobs) next.delete(job.id);
      } else {
        for (const job of visibleJobs) next.add(job.id);
      }
      return next;
    });
  };

  const toggleQueuePause = async () => {
    try {
      const response = await fetch(queuePaused ? "/api/jobs/queue/resume" : "/api/jobs/queue/pause", { method: "POST" });
      const body = await response.json().catch(() => ({})) as { paused?: boolean };
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      setQueuePaused(body.paused === true);
      toast({ title: t(queuePaused ? "jobs.queueResumedToast" : "jobs.queuePausedToast") });
      queryClient.invalidateQueries({ queryKey: getListJobsQueryKey() });
    } catch (e) {
      toast({ title: t("jobs.operationFailed"), description: e instanceof Error ? e.message : t("common.unknownError"), variant: "destructive" });
    }
  };

  const pauseJob = async (id: number) => {
    try {
      const response = await fetch(`/api/jobs/${id}/pause`, { method: "POST" });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      toast({ title: t("jobs.taskPaused") });
      queryClient.invalidateQueries({ queryKey: getListJobsQueryKey() });
    } catch (e) {
      toast({ title: t("jobs.operationFailed"), description: e instanceof Error ? e.message : t("common.unknownError"), variant: "destructive" });
    }
  };

  const setJobSelected = (id: number, checked: boolean) => {
    setSelectedJobIds((current) => {
      const next = new Set(current);
      if (checked) next.add(id);
      else next.delete(id);
      return next;
    });
  };

  const selectedRunningCount = (jobs ?? []).filter(
    (job) => selectedJobIds.has(job.id) && ["scanning", "transcribing", "compressing", "remuxing"].includes(job.status),
  ).length;

  const deleteSelectedJobs = async () => {
    const ids = [...selectedJobIds];
    if (ids.length === 0) return;
    setDeleteConfirmOpen(false);
    let deleted = 0;
    let failed = 0;
    for (const id of ids) {
      try {
        await deleteJob.mutateAsync({ id });
        deleted += 1;
      } catch {
        failed += 1;
      }
    }
    setSelectedJobIds(new Set());
    queryClient.invalidateQueries({ queryKey: getListJobsQueryKey() });
    const description = [
      deleted > 0 ? t("jobs.batchDeleted", { count: deleted }) : null,
      failed > 0 ? t("jobs.batchDeleteFailed", { count: failed }) : null,
    ].filter(Boolean).join(" · ");
    toast({ title: deleted > 0 ? t("jobs.taskDeleted") : t("jobs.operationFailed"), description });
  };

  const startJobsSequentially = async (jobs: Array<{ id: number; status?: string | null }>, successMessage: string) => {
    if (jobs.length === 0) {
      toast({ title: t("jobs.noPendingToStart") });
      return;
    }
    try {
      for (const job of jobs) {
        // paused / done 任务先经 retry 重置回 pending 再启动；pending / error 直接启动。
        if (job.status === "paused" || job.status === "done") {
          await retryJob.mutateAsync({ id: job.id });
        } else {
          await startJob.mutateAsync({ id: job.id });
        }
      }
      setSelectedJobIds(new Set());
      toast({ title: successMessage });
      queryClient.invalidateQueries({ queryKey: getListJobsQueryKey() });
    } catch (e: unknown) {
      toast({ title: t("jobs.queueStartFailed"), description: e instanceof Error ? e.message : t("common.unknownError"), variant: "destructive" });
      queryClient.invalidateQueries({ queryKey: getListJobsQueryKey() });
    }
  };

  return (
    <div data-testid="jobs-page" className={cn("space-y-4", embedded ? "" : "space-y-6")}>
      {!embedded && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">{t("jobs.sequentialDesc")}</p>
          <span className="text-sm text-muted-foreground">{t("jobs.taskCount", { count: filteredJobs?.length ?? 0 })}</span>
        </div>
      )}
      {embedded && (
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
          <h2 className="text-base font-semibold">{t("jobs.taskQueue")}</h2>
          <span className="text-sm text-muted-foreground">{t("jobs.taskCount", { count: filteredJobs?.length ?? 0 })}</span>
          <span className="ml-auto flex flex-wrap items-center gap-2 text-xs font-medium">
            <span className="inline-flex items-center gap-1.5 text-primary">
              <span className="h-2 w-2 rounded-full bg-primary shadow-[0_0_0_3px_hsl(var(--primary)/0.15)]" />
              {t("jobs.queueRunningCount", { count: runningJobs.length })}
            </span>
            <span className="text-muted-foreground">·</span>
            <span className="text-muted-foreground">{t("jobs.queuePendingCount", { count: allPendingJobs.length })}</span>
            {queuePaused && <span className="rounded border border-amber-400/40 bg-amber-400/10 px-1.5 py-0.5 text-amber-500">{t("jobs.queuePausedShort")}</span>}
          </span>
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={t("jobs.searchPlaceholder")}
            className="pl-8 bg-card"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            data-testid="input-search"
          />
        </div>
        <div className="w-full sm:w-44 flex items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground shrink-0" />
          <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as StatusFilter)}>
            <SelectTrigger className="bg-card" data-testid="select-status">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {STATUS_OPTIONS.map(opt => (
                <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2 rounded-lg border bg-card/60 p-3 text-sm">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => startJobsSequentially(batchStartableJobs.map(job => ({ id: job.id, status: job.status })), t("jobs.queueStarted"))}
          disabled={batchStartableJobs.length === 0 || startJob.isPending || retryJob.isPending || queuePaused}
          title={queuePaused ? t("jobs.queuePausedStartHint") : undefined}
          className={ROW_BUTTON_CLASS}
          data-testid="btn-batch-start-queue"
        >
          <Play className="mr-1 h-4 w-4" />
          {t("jobs.batchStartQueue", { count: batchStartableJobs.length })}
        </Button>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => void toggleQueuePause()}
          disabled={!queuePaused && pendingJobs.length === 0}
          className={ROW_BUTTON_CLASS}
          data-testid="btn-pause-queue"
        >
          {queuePaused ? <Play className="mr-1 h-4 w-4" /> : <PauseCircle className="mr-1 h-4 w-4" />}
          {t(queuePaused ? "jobs.resumeQueue" : "jobs.pauseQueue")}
        </Button>
        {selectedJobIds.size > 0 && (
          <>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => startJobsSequentially(selectedStartableJobs.map(job => ({ id: job.id, status: job.status })), t("jobs.selectedStarted"))}
              disabled={selectedStartableJobs.length === 0 || startJob.isPending || retryJob.isPending || queuePaused}
              title={queuePaused ? t("jobs.queuePausedStartHint") : undefined}
              className={ROW_BUTTON_CLASS}
              data-testid="btn-start-selected"
            >
              {t("jobs.startSelected", { count: selectedStartableJobs.length })}
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setDeleteConfirmOpen(true)}
              disabled={selectedJobIds.size === 0 || deleteJob.isPending || selectionHasRunning}
              title={selectionHasRunning ? t("jobs.runningDeleteBlockedHint") : undefined}
              className={ROW_BUTTON_CLASS}
              data-testid="btn-delete-selected"
            >
              <Trash2 className="mr-1 h-4 w-4" />
              {t("jobs.deleteSelected", { count: selectedJobIds.size })}
            </Button>
          </>
        )}
        <span className="text-xs text-muted-foreground">{queuePaused ? t("jobs.queuePausedStartHint") : t("jobs.sequentialHint")}</span>
      </div>

      <div className="space-y-2">
        {visibleJobs.length > 0 && (
          <div className="flex items-center text-xs text-muted-foreground">
            <div className="flex w-12 items-center justify-center border-r border-border/50">
              <Checkbox
                checked={allVisibleSelected}
                onCheckedChange={() => toggleAllVisible()}
                aria-label={t("jobs.selectAllVisible")}
                className={cn(someVisibleSelected && !allVisibleSelected ? "data-[state=unchecked]:opacity-60" : "")}
                data-testid="checkbox-select-all"
              />
            </div>
            <span className="pl-4">{t("jobs.selectAllVisible")}</span>
            <span className="ml-auto pr-4 font-mono">{selectedJobIds.size} / {visibleJobs.length}</span>
          </div>
        )}
        {!filteredJobs?.length ? (
          <div className="text-center py-12 text-muted-foreground border border-dashed rounded-lg text-sm">
            {t("jobs.noMatchingTasks")}
          </div>
        ) : (
          visibleJobs.map((job) => {
            const isRunning = RUNNING_JOB_STATUSES.has(job.status);
            const pendingPosition = pendingQueuePositions.get(job.id);
            return (
            <Card key={job.id} className={cn(
              "p-0 overflow-hidden flex flex-col sm:flex-row items-stretch sm:items-center group",
              isRunning && "border-primary/70 border-l-4 bg-primary/5 shadow-sm shadow-primary/10",
              job.status === "pending" && "border-l-4 border-l-muted-foreground/30",
            )} data-testid={`job-card-${job.id}`}>
              <div className="flex items-center justify-center px-4 pt-4 sm:pt-0 sm:border-r border-border/50">
                <Checkbox
                  checked={selectedJobIds.has(job.id)}
                  onCheckedChange={(checked) => setJobSelected(job.id, checked === true)}
                  aria-label={t("jobs.selectTaskAria", { id: job.id })}
                  data-testid={`checkbox-job-${job.id}`}
                />
              </div>
              <Link href={`/jobs/${job.id}`} className="flex-1 p-4 hover:bg-secondary/20 transition-colors flex items-center min-w-0">
                <div className="space-y-1 flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-1 flex-wrap">
                    {isRunning && (
                      <span className="inline-flex items-center gap-1 rounded border border-primary/35 bg-primary/10 px-1.5 py-0.5 text-[10px] font-medium text-primary">
                        <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary" />
                        {t("jobs.queueWorking")}
                      </span>
                    )}
                    {job.status === "pending" && pendingPosition != null && (
                      <span className="rounded border border-border bg-secondary px-1.5 py-0.5 text-[10px] font-mono text-muted-foreground">
                        {t("jobs.queuePosition", { position: String(pendingPosition) })}
                      </span>
                    )}
                    {job.movieTitle && (
                      <span className="text-sm font-medium text-foreground truncate">{job.movieTitle}</span>
                    )}
                    <span className="font-mono text-xs text-muted-foreground truncate">{job.filePath.split(/[/\\]/).pop()}</span>
<JobStatusBadge status={job.status} processingMode={job.processingMode} subtitleMode={job.subtitleMode} />
{(() => {
  const blocked = parseBlockedJobCode((job as { errorMessage?: string | null }).errorMessage);
  if (!blocked) return null;
  return (
    <span className="inline-flex items-center gap-1 rounded border border-amber-400/40 bg-amber-400/10 px-1.5 py-0.5 text-[10px] font-medium text-amber-400" data-testid="job-blocked-badge" title={t("jobDetail.blockedHint")}>
      {t("jobDetail.blockedLabel")}：{t(blockedReasonKey(blocked))}
    </span>
  );
})()}
{(job as { selectionPlan?: string | null }).selectionPlan?.includes("smart-workflow-v1") && (
                      <span className="text-[10px] font-mono bg-primary/10 text-primary border border-primary/25 rounded px-1.5 py-0.5" data-testid="workflow-job-badge">
                        {t("workflow.badge")}
                      </span>
                    )}
                    {jobDurationSeconds(job) != null && (
                      <span className="text-[10px] font-mono bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 rounded px-1.5 py-0.5">
                        {t("jobs.durationShort")}{formatDurationCompact(jobDurationSeconds(job))}
                      </span>
                    )}
                    <span className="text-[10px] font-mono bg-secondary text-muted-foreground border rounded px-1.5 py-0.5">
                      {planLabelFor(job, config, t)}
                    </span>
                  </div>

                  {['scanning', 'transcribing', 'compressing'].includes(job.status) ? (
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-3">
                        <Progress value={job.progress || 0} className="h-1.5 w-48" />
                        <span className="text-[10px] font-mono text-muted-foreground">{Math.round(job.progress || 0)}%</span>
                        {job.status === 'compressing' && job.avgFps != null && (
                          <span className="text-[10px] font-mono text-blue-400">{job.avgFps.toFixed(1)} fps</span>
                        )}
                        {job.startedAt && (
                          <span className="text-[10px] font-mono text-muted-foreground/70">
                            {(() => {
                              const sec = Math.floor((Date.now() - new Date(job.startedAt).getTime()) / 1000);
                              return sec >= 3600
                                ? t("jobs.elapsed", { text: `${Math.floor(sec / 3600)}h${Math.floor((sec % 3600) / 60)}m` })
                                : sec >= 60
                                ? t("jobs.elapsed", { text: `${Math.floor(sec / 60)}m${sec % 60}s` })
                                : t("jobs.elapsed", { text: `${sec}s` });
                            })()}
                          </span>
                        )}
                        {job.lastLog && (
                          <span className="text-[10px] font-mono text-muted-foreground/80 truncate max-w-[260px]" title={job.lastLog}>
                            {t("jobs.stage")}{job.lastLog}
                          </span>
                        )}
                        {job.status === 'compressing' && job.etaSeconds != null && job.etaSeconds > 0 && (
                          <span className="text-[10px] font-mono text-orange-400">
                            {t("jobs.remaining", { text: job.etaSeconds >= 3600
                              ? `${Math.floor(job.etaSeconds / 3600)}h${Math.floor((job.etaSeconds % 3600) / 60)}m`
                              : job.etaSeconds >= 60
                              ? `${Math.floor(job.etaSeconds / 60)}m${job.etaSeconds % 60}s`
                              : `${job.etaSeconds}s` })}
                          </span>
                        )}
                        {job.status === 'compressing' && job.etaSeconds != null && job.etaSeconds > 0 && (
                          <span className="text-[10px] font-mono text-muted-foreground/60">
                            {t("jobs.etaDone", { time: new Date(Date.now() + job.etaSeconds * 1000).toLocaleTimeString(lang === "en-US" ? "en-US" : "zh-CN", { hour: "2-digit", minute: "2-digit" }) })}
                          </span>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-4 text-xs text-muted-foreground font-mono">
                      {(job.status === "done" || job.status === "error") && job.startedAt && (
                        <span className="text-primary">
                          {t("jobs.totalDuration", {
                            text: formatDurationCompact(
                              ((job.completedAt ? new Date(job.completedAt).getTime() : Date.now()) - new Date(job.startedAt).getTime()) / 1000,
                            ),
                          })}
                        </span>
                      )}
                      {job.status === "pending" && job.createdAt && (
                        <span>
                          {t("jobs.queued", {
                            text: formatDurationCompact((Date.now() - new Date(job.createdAt).getTime()) / 1000),
                          })}
                        </span>
                      )}
                      <span>{formatDate(job.createdAt, lang)}</span>
                      {(job.status === "done" || job.status === "error") && jobDurationSeconds(job) != null && (
                        <span>{t("jobs.durationShort")}{formatDurationCompact(jobDurationSeconds(job))}</span>
                      )}
                      {job.fileSizeBefore != null && <span>{formatBytes(job.fileSizeBefore)}</span>}
                      {job.processingMode === "remux" && job.fileSizeAfter != null && (
                        <span className="text-primary">{t("jobs.afterRemux", { size: formatBytes(job.fileSizeAfter) })}</span>
                      )}
                      {toHostPath(job.filePath, config) !== job.filePath && (
                        <span className="text-[10px] text-primary/60 truncate max-w-[200px]" title={toHostPath(job.filePath, config)}>
                          {toHostPath(job.filePath, config)}
                        </span>
                      )}
                    </div>
                  )}
                  {job.processingMode === "compress" && config && (
                    <div className="mt-1 text-[10px] text-muted-foreground font-mono">
                      {t("jobs.compressionParamsTitle")}{config.encoder} · CRF {config.crf} · {config.encoderPreset || "slow"}
                      {config.encoderTune && config.encoderTune !== "none" ? ` · ${config.encoderTune}` : ""}
                      {isDiscCompressionJob(job) ? (
                        <span className="ml-2 text-blue-400">{t("jobs.discCompression")}</span>
                      ) : (
                        <span className="ml-2 text-primary/70">{t("jobs.detailPagePreview")}</span>
                      )}
                    </div>
                  )}
                </div>
              </Link>

              <div className="flex items-center gap-1 p-3 bg-secondary/10 sm:border-l border-t sm:border-t-0 justify-end">
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground" title={`${t("jobs.openOutputTitle")}${job.outputPath ? (toHostPath(job.outputPath, config) || job.outputPath) : (toHostPath(job.filePath, config) || job.filePath)}`} onClick={(e) => { e.preventDefault(); e.stopPropagation(); void openOutputPath(job.outputPath || job.filePath); }} data-testid={`btn-open-output-path-${job.id}`}>
                  <FolderOpen className="h-4 w-4" />
                </Button>
                {job.status === 'pending' && (
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-primary" title={t("jobs.startTitle")} onClick={() => handleAction(startJob, job.id, t("jobs.taskStarted"))} data-testid={`btn-start-${job.id}`}>
                    <Play className="h-4 w-4" />
                  </Button>
                )}
                {['scanning', 'transcribing', 'compressing', 'remuxing'].includes(job.status) && (
                  <>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-sky-500" title={t("jobs.pauseTitle")} onClick={() => void pauseJob(job.id)} data-testid={`btn-pause-${job.id}`}>
                    <PauseCircle className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-orange-500" title={t("jobs.cancelTitle")} onClick={() => handleAction(cancelJob, job.id, t("jobs.taskCancelled"))} data-testid={`btn-cancel-${job.id}`}>
                    <Square className="h-4 w-4" />
                  </Button>
                  </>
                )}
                {['error', 'done', 'paused'].includes(job.status) && (
                  <Button variant="ghost" size="icon" className="h-8 w-8" title={t("jobs.retryTitle")} onClick={() => handleAction(retryJob, job.id, t("jobs.taskRetried"))} data-testid={`btn-retry-${job.id}`}>
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                )}
                {!['scanning', 'transcribing', 'compressing', 'remuxing'].includes(job.status) && (
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10" title={t("jobs.deleteTitle")} onClick={() => handleAction(deleteJob, job.id, t("jobs.taskDeleted"))} data-testid={`btn-delete-${job.id}`}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </Card>
            );
          })
        )}
      </div>

      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("jobs.deleteConfirmTitle")}</AlertDialogTitle>
            <AlertDialogDescription>
              {t("jobs.deleteConfirmDescription", { count: selectedJobIds.size })}
              {selectedRunningCount > 0 && (
                <span className="mt-1 block text-destructive">{t("jobs.deleteRunningWarning", { count: selectedRunningCount })}</span>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction onClick={() => void deleteSelectedJobs()}>{t("jobs.deleteTitle")}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
