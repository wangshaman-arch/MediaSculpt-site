// Extracted from pages/Settings.tsx: the local directory settings section.
import {
  useGetConfig,
  getGetConfigQueryKey,
  useUpdateConfig,
  ConfigInputWhisperModel,
  ConfigInputOutputFormat,
} from "@workspace/api-client-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Slider } from "@/components/ui/slider";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useEffect, useState, useRef, useMemo } from "react";
import type { Resolver } from "react-hook-form";
import { useI18n } from "@/i18n";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import {
  Save,
  Settings2,
  ExternalLink,
  Languages,
  Zap,
  Star,
  ChevronDown,
  ChevronUp,
  Cpu,
  FolderSearch,
  Plus,
  Trash2,
  BookmarkCheck,
  Pencil,
  X,
  RefreshCw,
  RotateCcw,
  FileText,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { DirectoryPicker } from "@/components/DirectoryPicker";
import { ImdbDatasetCard } from "@/components/ImdbDatasetCard";
import { TuningLogicCard } from "@/components/TuningLogicCard";
import { TuningPromptsCard } from "@/components/TuningPromptsCard";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  parseCustomTuning,
  serializeCustomTuning,
  type CustomTuning,
} from "@/lib/custom-tuning";
import {
  useSettingsSections,
  type SettingsSection,
} from "@/hooks/useSettingsSections";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  ARCHIVE_PRESETS,
  ARCHIVE_PRESET_LS_KEY,
  CUSTOM_PRESET_KEY,
  PRESET_CHANGED_EVENT,
  loadCompressionPresets,
  ENCODER_OPTIONS,
  type ArchivePreset,
  type CustomPreset,
} from "@/lib/compression-presets";
import { compressionPresetSummary } from "@/features/workbench/compression-preset-model";
import { ToolManager } from "./settings-tool-manager";
import {
  previewOutputName,
  settingsAssColorToHex,
  settingsHexToAssColor,
} from "./settings-model";

import { type ConfigFormValues, SOURCE_DIRECTORY_VALUE } from "./settings-model";
import { useFormContext } from "react-hook-form";

type SectionKey =
  | "directories"
  | "encoding"
  | "subtitleWhisper"
  | "aiTranslation"
  | "tmdb"
  | "toolPaths"
  | "system";

type SectionProps = {
  openSections: Record<SectionKey, boolean>;
  toggle: (key: SectionKey) => void;
};

export function SettingsDirectoriesSection({
  openSections,
  toggle,
}: SectionProps) {
  const { t } = useI18n();
  const form = useFormContext<ConfigFormValues>();
  return (
              <Collapsible
                open={openSections.directories}
                onOpenChange={() => toggle("directories")}
              >
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>{t("settings.localDirsTitle")}</CardTitle>
                        <CardDescription className="mt-1">
                          {t("settings.localDirsHint")}
                        </CardDescription>
                      </div>
                      <CollapsibleTrigger asChild>
                        <button
                          type="button"
                          className="p-1 rounded hover:bg-secondary/60 transition-colors ml-3 shrink-0"
                        >
                          <ChevronDown
                            className={`h-4 w-4 text-muted-foreground transition-transform ${openSections.directories ? "rotate-180" : ""}`}
                          />
                        </button>
                      </CollapsibleTrigger>
                    </div>
                  </CardHeader>
                  <CollapsibleContent>
                    <CardContent
                      data-testid="settings-directories-form"
                      className="grid min-w-0 gap-6 overflow-hidden md:grid-cols-2"
                    >
                      <FormField
                        control={form.control}
                        name="hostDownloadsPath"
                        render={({ field }) => (
                          <FormItem className="min-w-0 overflow-hidden">
                            <FormLabel className="flex items-center gap-1.5">
                              {t("settings.watchDirLabel")}
                              <Badge
                                variant="secondary"
                                className="text-xs font-normal"
                              >
                                {t("settings.windowsPathBadge")}
                              </Badge>
                            </FormLabel>
                            <FormControl>
                              <DirectoryPicker
                                value={field.value ?? ""}
                                onChange={field.onChange}
                                placeholder="H:\"
                              />
                            </FormControl>
                            <FormDescription>
                              {t("settings.watchDirDesc")}
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="hostOutputPath"
                        render={({ field }) => (
                          <FormItem className="min-w-0 overflow-hidden">
                            <FormLabel className="flex items-center gap-1.5">
                              {t("settings.outputDirLabel")}
                              <Badge
                                variant="secondary"
                                className="text-xs font-normal"
                              >
                                {t("settings.windowsPathBadge")}
                              </Badge>
                            </FormLabel>
                            <FormControl>
                              <div className="space-y-2">
                                <DirectoryPicker
                                  value={
                                    field.value === SOURCE_DIRECTORY_VALUE
                                      ? ""
                                      : (field.value ?? "")
                                  }
                                  onChange={field.onChange}
                                  placeholder="C:\Users\xxx\Videos"
                                />
                                <Button
                                  type="button"
                                  variant={
                                    field.value === SOURCE_DIRECTORY_VALUE
                                      ? "default"
                                      : "outline"
                                  }
                                  size="sm"
                                  onClick={() =>
                                    field.onChange(SOURCE_DIRECTORY_VALUE)
                                  }
                                >
                                  {t("settings.sameAsSource")}
                                </Button>
                              </div>
                            </FormControl>
                            <FormDescription>
                              {t("settings.outputDirDesc")}
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="remuxOutputDirectory"
                        render={({ field }) => (
                          <FormItem className="min-w-0 overflow-hidden md:col-span-2">
                            <FormLabel className="flex items-center gap-1.5">
                              <FolderSearch className="h-3.5 w-3.5 text-primary" />
                              {t("settings.remuxDirLabel")}
                            </FormLabel>
                            <FormControl>
                              <div className="space-y-2">
                                <DirectoryPicker
                                  value={
                                    field.value === SOURCE_DIRECTORY_VALUE
                                      ? ""
                                      : (field.value ?? "")
                                  }
                                  onChange={field.onChange}
                                  placeholder={t("settings.sameAsSource")}
                                />
                                <Button
                                  type="button"
                                  variant={
                                    !field.value ||
                                    field.value === SOURCE_DIRECTORY_VALUE
                                      ? "default"
                                      : "outline"
                                  }
                                  size="sm"
                                  onClick={() =>
                                    field.onChange(SOURCE_DIRECTORY_VALUE)
                                  }
                                >
                                  {t("settings.restoreDefault")}
                                </Button>
                              </div>
                            </FormControl>
                            <FormDescription>
                              {t("settings.remuxDirDesc")}
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="subtitleDirectory"
                        render={({ field }) => (
                          <FormItem className="min-w-0 overflow-hidden md:col-span-2">
                            <FormLabel className="flex items-center gap-1.5">
                              <FolderSearch className="h-3.5 w-3.5 text-primary" />
                              {t("settings.subtitleDirLabel")}
                              <Badge
                                variant="secondary"
                                className="text-xs font-normal"
                              >
                                {t("settings.windowsPathBadge")}
                              </Badge>
                            </FormLabel>
                            <FormControl>
                              <div className="space-y-2">
                                <DirectoryPicker
                                  value={
                                    field.value === SOURCE_DIRECTORY_VALUE
                                      ? ""
                                      : (field.value ?? "")
                                  }
                                  onChange={field.onChange}
                                  placeholder={t(
                                    "settings.subtitleDirPlaceholder",
                                  )}
                                />
                                <Button
                                  type="button"
                                  variant={
                                    !field.value ||
                                    field.value === SOURCE_DIRECTORY_VALUE
                                      ? "default"
                                      : "outline"
                                  }
                                  size="sm"
                                  onClick={() =>
                                    field.onChange(SOURCE_DIRECTORY_VALUE)
                                  }
                                >
                                  {t("settings.subtitleDefaultHint")}
                                </Button>
                              </div>
                            </FormControl>
                            <FormDescription>
                              {t("settings.subtitleDirDesc")}
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="outputNameTemplate"
                        render={({ field }) => {
                          const dvdExample = previewOutputName(
                            field.value ?? "",
                            {
                              title: "All.Things.Fair",
                              year: "1995",
                              titleNo: "01",
                              source: "DVD",
                              kind: "Compress",
                              resolution: "",
                              encoder: "H264",
                              bitdepth: "10bit",
                              audio: "AC3",
                              crf: "24",
                              ext: "mkv",
                            },
                          );
                          const bdExample = previewOutputName(
                            field.value ?? "",
                            {
                              title: "Helene.Grimaud",
                              year: "2023",
                              titleNo: "03",
                              source: "BluRay",
                              kind: "Remux",
                              resolution: "",
                              encoder: "",
                              bitdepth: "",
                              audio: "",
                              crf: "",
                              ext: "mkv",
                            },
                          );
                          return (
                            <FormItem className="min-w-0 md:col-span-2">
                              <FormLabel className="flex items-center gap-1.5">
                                <FileText className="h-3.5 w-3.5 text-primary" />
                                {t("settings.outputNameTemplateLabel")}
                              </FormLabel>
                              <FormControl>
                                <Input
                                  {...field}
                                  value={field.value ?? ""}
                                  placeholder={t(
                                    "settings.outputNameTemplatePlaceholder",
                                  )}
                                  className="h-9 font-mono text-xs"
                                />
                              </FormControl>
                              <Button
                                type="button"
                                variant={!field.value ? "default" : "outline"}
                                size="sm"
                                className="mt-1"
                                onClick={() => field.onChange("")}
                              >
                                {t("settings.outputNameRestoreDefault")}
                              </Button>
                              <p className="text-[11px] leading-snug text-muted-foreground">
                                {t("settings.outputNameTemplateHint")}
                              </p>
                              {(dvdExample || bdExample) && (
                                <div className="space-y-1 rounded-lg border bg-background/50 px-2.5 py-2 font-mono text-[11px] text-muted-foreground">
                                  <p>
                                    <span className="text-primary">
                                      {t("settings.outputNamePreviewDvd")}
                                    </span>{" "}
                                    → {dvdExample || "—"}
                                  </p>
                                  <p>
                                    <span className="text-primary">
                                      {t("settings.outputNamePreviewBluray")}
                                    </span>{" "}
                                    → {bdExample || "—"}
                                  </p>
                                </div>
                              )}
                              <FormMessage />
                            </FormItem>
                          );
                        }}
                      />
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>
  );
}
