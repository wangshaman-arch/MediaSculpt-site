import { describe, expect, it } from "vitest";
import { describeProxyStatus } from "./metadata-capability-model";

describe("describeProxyStatus", () => {
  it("reports a manually configured proxy as configured", () => {
    expect(
      describeProxyStatus({
        configuredProxyUrl: "http://127.0.0.1:10809",
        detectedProxyUrl: null,
        effectiveProxyUrl: "http://127.0.0.1:10809",
      }),
    ).toEqual({ kind: "configured", url: "http://127.0.0.1:10809" });
  });

  // 开着 Hiddify 却报告"直连"正是这次要修掉的误导。
  it("reports an auto-detected proxy as detected", () => {
    expect(
      describeProxyStatus({
        configuredProxyUrl: null,
        detectedProxyUrl: "http://127.0.0.1:12334",
        effectiveProxyUrl: "http://127.0.0.1:12334",
      }),
    ).toEqual({ kind: "detected", url: "http://127.0.0.1:12334" });
  });

  it("keeps the configured proxy when one was also detected", () => {
    const status = describeProxyStatus({
      configuredProxyUrl: "http://127.0.0.1:10809",
      detectedProxyUrl: "http://127.0.0.1:12334",
      effectiveProxyUrl: "http://127.0.0.1:10809",
    });
    expect(status).toEqual({ kind: "configured", url: "http://127.0.0.1:10809" });
  });

  it("reports no proxy when nothing is effective", () => {
    expect(
      describeProxyStatus({ configuredProxyUrl: null, detectedProxyUrl: null, effectiveProxyUrl: null }),
    ).toEqual({ kind: "none" });
    expect(describeProxyStatus(undefined)).toEqual({ kind: "none" });
    expect(describeProxyStatus(null)).toEqual({ kind: "none" });
    expect(
      describeProxyStatus({ configuredProxyUrl: "   ", detectedProxyUrl: null, effectiveProxyUrl: "" }),
    ).toEqual({ kind: "none" });
  });
});
