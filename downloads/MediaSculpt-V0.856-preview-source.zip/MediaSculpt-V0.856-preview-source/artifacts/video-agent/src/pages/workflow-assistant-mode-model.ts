import type { ProcessingStep, SubtitleChoice } from "@/components/AssistantPanel";
import type { ProcessingMode, SubtitleMode } from "@/hooks/useWorkbenchState";

export function workflowModeFromAssistantPreferences(
  processing: ProcessingStep[],
  subtitle: SubtitleChoice | null,
): { mode: ProcessingMode; subtitleMode: SubtitleMode } {
  const mode: ProcessingMode = processing.includes("remux")
    ? "remux"
    : processing.includes("compress")
      ? "compress"
      : "none";
  const subtitleMode: SubtitleMode = mode === "none" && processing.includes("subtitle")
    ? subtitle && subtitle !== "skip"
      ? subtitle
      : "auto"
    : "skip";
  return { mode, subtitleMode };
}

export function workflowSubtitleModeForJob(
  plannedMode: "keep" | "translate-text" | "whisper" | "preserve-graphic" | "none" | "bilingual",
  processingMode: ProcessingMode | null | undefined,
  selectedSubtitleMode: SubtitleMode | null | undefined,
): SubtitleMode {
  if (
    processingMode === "none" &&
    selectedSubtitleMode &&
    selectedSubtitleMode !== "skip"
  ) {
    return selectedSubtitleMode;
  }
  if (plannedMode === "whisper") return "whisper";
  if (plannedMode === "translate-text") return "transcribe_translate";
  if (plannedMode === "bilingual") return "bilingual";
  return "extract";
}
