// Extracted from pages/JobDetail.tsx: compact source information bar.
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Link, useLocation, useParams } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  getGetConfigQueryKey,
  getGetJobLogsQueryKey,
  getGetJobQueryKey,
  useGetConfig,
  useGetJob,
  useGetJobLogs,
  useUpdateConfig,
} from "@workspace/api-client-react";
import {
  AlertTriangle,
  ArrowLeft,
  Ban,
  Bot,
  Captions,
  ChevronDown,
  Download,
  FileText,
  Film,
  FolderOpen,
  Info,
  Languages,
  MessageSquareText,
  Mic,
  PauseCircle,
  Pin,
  Play,
  RotateCcw,
  ScanText,
  SlidersHorizontal,
  Sparkles,
  Square,
  Terminal,
  Trash2,
  Workflow,
  X,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { JobStatusBadge } from "@/components/JobStatusBadge";
import { ocrEngineLabel, ocrLanguageLabel } from "@/lib/ocr-languages";
import {
  cn,
  formatBytes,
  formatCompressionRatio,
  formatDate,
  formatDuration,
  toHostPath,
} from "@/lib/utils";
import { openDesktopPath } from "@/lib/desktop-bridge";
import { useToast } from "@/hooks/use-toast";
import { useI18n } from "@/i18n";
import {
  AssistantPanel,
  type AssistantMetadata,
  type ProcessingStep,
  type SubtitleChoice,
} from "@/components/AssistantPanel";
import { type PreviewPlayerHandle } from "@/components/PreviewPlayer";
import { PreviewPlayerCard } from "@/components/PreviewPlayerCard";
import {
  useAssistantAnalysis,
  type AssistantCorrection,
} from "@/hooks/useAssistantAnalysis";
import { resolveAnalysisOverview } from "@/lib/assistant-analysis";
import { parseAssistantMetadata } from "@/lib/assistant-metadata";
import { parseBlockedJobCode, blockedReasonKey } from "@/lib/blocked-job";
import {
  PRESET_CHANGED_EVENT,
  loadCompressionPresets,
  presetConfigValues,
  RESOLUTION_OPTIONS,
  type ArchivePreset,
} from "@/lib/compression-presets";
import { useJobActions } from "@/hooks/useJobActions";
import {
  isImageSubtitleCodec,
  parseSubtitleCues,
  streamAspectRatio,
  type MediaStreamInfo,
} from "./job-detail-model";

import {
  type SourceInfo,
  type CompressionDisplayConfig,
  sourceKind,
  streamLanguage,
  streamCodec,
  formatFrameRateLabel,
} from "./job-detail-model";

export function SourceInfoCompactBar({
  sourceInfo,
  mediaType,
  fallbackDuration,
  detailsOpen,
  onToggleDetails,
  subtitleControls,
}: {
  sourceInfo: SourceInfo | null;
  mediaType?: string | null;
  fallbackDuration?: number | null;
  detailsOpen: boolean;
  onToggleDetails: () => void;
  subtitleControls?: ReactNode;
}) {
  const streams = sourceInfo?.streams ?? [];
  const videoStreams = streams.filter((stream) => stream.codecType === "video");
  const audioStreams = streams.filter((stream) => stream.codecType === "audio");
  const subtitleStreams = streams.filter(
    (stream) => stream.codecType === "subtitle",
  );
  const primaryVideo = videoStreams[0];
  const resolution =
    primaryVideo?.width && primaryVideo?.height
      ? `${primaryVideo.width}×${primaryVideo.height}`
      : "--";
  const duration = sourceInfo?.duration ?? fallbackDuration ?? null;
  const { t } = useI18n();

  return (
    <div
      className="rounded-lg border bg-secondary/15 px-3 py-2 text-xs"
      data-testid="source-info-panel"
    >
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-semibold text-foreground">
          {t("jobDetail.sourceInfo")}
        </span>
        <span className="rounded border border-primary/25 bg-primary/10 px-2 py-0.5 text-primary">
          {sourceKind(mediaType, t)}
        </span>
        <span className="font-mono">
          {t("jobDetail.resolution", { value: resolution })}
        </span>
        <span className="font-mono">
          {t("jobDetail.videoCodec", {
            value: primaryVideo ? streamCodec(primaryVideo) : "--",
          })}
        </span>
        <span className="font-mono">
          {t("jobDetail.frameRate", {
            value: formatFrameRateLabel(primaryVideo?.frameRate),
          })}
        </span>
        <span className="font-mono">
          {t("jobDetail.duration", {
            value: duration ? formatDuration(duration) : "--",
          })}
        </span>
        <span className="font-mono">
          {t("jobDetail.audioTracks", { count: audioStreams.length })}
        </span>
        <span className="font-mono">
          {t("jobDetail.subtitleTracks", { count: subtitleStreams.length })}
        </span>
        <span className="font-mono">
          {t("jobDetail.chapters", {
            count: sourceInfo?.chapters?.length ?? 0,
          })}
        </span>
        <div className="ml-auto flex flex-wrap items-center gap-1">
          {subtitleControls}
          <Button
            type="button"
            size="sm"
            variant="outline"
            className="h-7 px-2 text-[11px]"
            onClick={onToggleDetails}
          >
            {detailsOpen
              ? t("jobDetail.collapseDetails")
              : t("jobDetail.expandDetails")}
          </Button>
        </div>
      </div>
      {detailsOpen && (
        <div className="mt-2 grid grid-cols-1 gap-2 border-t pt-2">
          <div className="rounded-lg border bg-background/45 p-2">
            <div className="mb-1 font-medium">
              {t("jobDetail.audioSection", { count: audioStreams.length })}
            </div>
            <div className="space-y-1 text-muted-foreground">
              {audioStreams.length ? (
                audioStreams.slice(0, 6).map((stream) => (
                  <div
                    key={stream.index}
                    className="flex min-w-0 justify-between gap-2"
                  >
                    <span className="min-w-0 truncate">
                      #{stream.index} {streamLanguage(stream, t)}
                    </span>
                    <span className="shrink-0 font-mono">
                      {streamCodec(stream)}
                      {stream.channels ? ` · ${stream.channels}ch` : ""}
                    </span>
                  </div>
                ))
              ) : (
                <div>{t("jobDetail.noAudioDetected")}</div>
              )}
            </div>
          </div>
          <div className="rounded-lg border bg-background/45 p-2">
            <div className="mb-1 font-medium">
              {t("jobDetail.subtitleSection", {
                count: subtitleStreams.length,
              })}
            </div>
            <div className="space-y-1 text-muted-foreground">
              {subtitleStreams.length ? (
                subtitleStreams.slice(0, 6).map((stream) => (
                  <div
                    key={stream.index}
                    className="flex min-w-0 justify-between gap-2"
                  >
                    <span className="min-w-0 truncate">
                      #{stream.index} {streamLanguage(stream, t)}
                      {stream.forced ? " · Forced" : ""}
                    </span>
                    <span className="shrink-0 font-mono">
                      {streamCodec(stream)}
                    </span>
                  </div>
                ))
              ) : (
                <div>{t("jobDetail.noSubtitlesDetected")}</div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
