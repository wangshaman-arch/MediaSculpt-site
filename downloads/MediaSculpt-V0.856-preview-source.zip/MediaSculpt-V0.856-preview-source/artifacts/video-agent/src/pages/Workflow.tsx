import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { ArrowLeft, CheckCircle2, Film, FolderOpen, Loader2, Play, RefreshCw } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DEFAULT_COMPRESSION_PRESETS, loadCompressionPresets, presetConfigValues, type ArchivePreset } from "@/lib/compression-presets";
import { getGetConfigQueryKey, useGetConfig, useUpdateConfig } from "@workspace/api-client-react";
import { useI18n } from "@/i18n";
import { useLocation } from "wouter";
import { AssistantPanel, type ProcessingStep } from "@/components/AssistantPanel";
import { useAssistantAnalysis, type AssistantCorrection } from "@/hooks/useAssistantAnalysis";
import type { ProcessingMode, SubtitleMode } from "@/hooks/useWorkbenchState";
import { logicValue, parseCustomTuning } from "@/lib/custom-tuning";
import {
  clearWorkflowChoices,
  workflowChapterSelectionPayload,
  workflowPresetLabel,
} from "./workflow-plan-model";
import { allSelectionIds, toggleSelectionId } from "./workflow-stream-selection-model";
import { workflowModeFromAssistantPreferences, workflowSubtitleModeForJob } from "./workflow-assistant-mode-model";

type WorkflowStream = {
  id: string;
  index?: number;
  type: "video" | "audio" | "subtitle";
  codec?: string | null;
  profile?: string | null;
  description?: string | null;
  durationSeconds?: number | null;
  bitrate?: number | null;
  estimatedSizeBytes?: number | null;
  language?: string | null;
  title?: string | null;
  default?: boolean;
  handbrakeTrackNumber?: number | null;
  width?: number | null;
  height?: number | null;
  channels?: number | null;
  frameRate?: string | null;
  channelLayout?: string | null;
  sampleRate?: number | null;
  hdr?: boolean;
};
type WorkflowChapter = { id: string; startSeconds: number; endSeconds: number; title?: string | null };
type WorkflowMedia = {
  sourcePath: string;
  sourceType: "video" | "dvd" | "bluray" | "iso";
  sourceFingerprint: string;
  externalSubtitles?: Array<{ path: string; hasChinese: boolean; language?: string | null }>;
  analysisId?: string | null;
  titleId?: string | null;
  titleIndex?: number | null;
  handbrakeTitleNumber?: number | null;
  dvdVtsNumber?: number | null;
  physicalVtsNumber?: number | null;
  verificationStatus?: string | null;
  displayName?: string | null;
  durationSeconds?: number | null;
  sizeBytes?: number | null;
  streams: WorkflowStream[];
  chapters: WorkflowChapter[];
};
type WorkflowSubtitle = {
  mode: "keep" | "translate-text" | "whisper" | "preserve-graphic" | "none" | "bilingual";
  runWhisper: boolean;
  translate: boolean;
  sourceSubtitleId: string | null;
  sourceAudioId: string | null;
  sourceLanguage: string | null;
  targetLanguage: string;
  rationale: string;
};
type WorkflowItem = WorkflowMedia & {
  id: string;
  enabled: boolean;
  inferredUse: string;
  action: "remux" | "compress" | "subtitle" | "skip";
  /** 有序处理流水线（多选 压缩/Remux/仅字幕，默认 ① Remux → ② 字幕 → ③ 压缩） */
  pipeline?: ProcessingStep[];
  outputName: string;
  presetId: string | null;
  compression: { recommendation: string; rationale: string; estimated: boolean; estimatedOutputBytes: number | null };
  selectedStreamIds: string[];
  selectedChapterIds: string[];
  subtitle: WorkflowSubtitle;
  externalSubtitles?: Array<{ path: string; hasChinese: boolean; language?: string | null }>;
  warnings: string[];
  rationale: string;
  confidence: number;
};
type WorkflowIdentity = { title: string; titleEn?: string | null; imdbId?: string | null; displayName?: string | null; year?: number | null; poster?: string | null; overview?: string | null; source?: string | null; confidence?: number | null; matchReason?: string | null; technicalAssessment?: string | null; recommendedAction?: string | null };
type WorkflowPlan = {
  schemaVersion: 1;
  planId: string;
  createdAt: string;
  source: { path: string; type: WorkflowMedia["sourceType"]; fingerprint: string };
  identity: WorkflowIdentity;
  metadata: { poster: string | null; source: string | null; candidates: WorkflowIdentity[] };
  items: WorkflowItem[];
  warnings: string[];
  degraded: { aiUnavailable: boolean; metadataUnavailable: boolean };
};

type Stage = 1 | 2 | 3 | 4;

function formatDuration(seconds: number | null | undefined, t: (key: string) => string): string {
  if (!Number.isFinite(seconds ?? NaN)) return t("workflow.unknownDuration");
  const total = Math.max(0, Math.round(seconds ?? 0));
  return `${Math.floor(total / 3600)}:${String(Math.floor((total % 3600) / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
}

function formatSize(bytes: number | null | undefined, t: (key: string) => string): string {
  if (!Number.isFinite(bytes ?? NaN) || !bytes) return t("workflow.unknownSize");
  const units = ["B", "KB", "MB", "GB", "TB"];
  let value = bytes;
  let index = 0;
  while (value >= 1024 && index < units.length - 1) { value /= 1024; index += 1; }
  return `${value.toFixed(index === 0 ? 0 : 1)} ${units[index]}`;
}

function fileStem(value: string): string {
  return value.split(/[\\/]/).pop()?.replace(/\.[^.]+$/, "") || "media";
}

function candidateTitle(candidate: WorkflowIdentity): string {
  const title = candidate.title.trim();
  if (!candidate.year || /(?:19|20)\d{2}/.test(title)) return title;
  return `${title} (${candidate.year})`;
}

function hasChineseSubtitle(item: WorkflowItem): boolean {
  return item.subtitle.mode === "keep" || (item.externalSubtitles?.some((subtitle) => subtitle.hasChinese) ?? false);
}

function subtitleModeLabel(mode: WorkflowSubtitle["mode"], t: (key: string) => string): string {
  switch (mode) {
    case "keep": return t("workflow.subtitleKeep");
    case "translate-text": return t("workflow.subtitleTranslate");
    case "whisper": return t("workflow.subtitleWhisper");
    case "preserve-graphic": return t("workflow.subtitleGraphic");
    case "bilingual": return t("assistant.optionBilingual");
    default: return t("workflow.subtitleNone");
  }
}

function mediaFromProbe(body: Record<string, unknown>): WorkflowMedia {
  return {
    sourcePath: String(body.sourcePath ?? ""), sourceType: "video", sourceFingerprint: String(body.sourceFingerprint ?? ""),
    durationSeconds: typeof body.durationSeconds === "number" ? body.durationSeconds : null,
    sizeBytes: typeof body.sizeBytes === "number" ? body.sizeBytes : null,
    streams: Array.isArray(body.streams) ? body.streams as WorkflowStream[] : [],
    chapters: Array.isArray(body.chapters) ? body.chapters as WorkflowChapter[] : [],
    externalSubtitles: Array.isArray(body.externalSubtitles) ? body.externalSubtitles as WorkflowMedia["externalSubtitles"] : [],
    displayName: fileStem(String(body.sourcePath ?? "")),
  };
}

function redactWorkflowError(value: unknown): string {
  return String(value ?? "").replace(/(api[_-]?key|authorization|token|secret)\s*[:=]\s*[^,\s}]+/gi, "$1=[redacted]").slice(0, 1600);
}

function logWorkflowIssue(event: string, message: string, details?: unknown): void {
  void fetch("/api/smart-workflow/client-log", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ level: "error", event, message: redactWorkflowError(message), details: details ? redactWorkflowError(details) : undefined }),
  }).catch(() => {});
}

function mediaFromDisc(sourcePath: string, body: Record<string, unknown>): WorkflowMedia[] {
  const discType = body.discType === "bluray" ? "bluray" : "dvd";
  const analysisId = typeof body.analysisId === "string" ? body.analysisId : null;
  const sourceFingerprint = typeof body.sourceFingerprint === "string" ? body.sourceFingerprint : "";
  const tracks = Array.isArray(body.tracks) ? body.tracks as Array<Record<string, unknown>> : [];
  return tracks.map((track, position) => {
    const rawStreams = Array.isArray(track.streams) ? track.streams as Array<Record<string, unknown>> : [];
    const streams: WorkflowStream[] = rawStreams.flatMap((stream) => {
      const type = stream.codecType === "video" || stream.codecType === "audio" || stream.codecType === "subtitle" ? stream.codecType : null;
      if (!type) return [];
      const index = Number(stream.index ?? 0);
      return [{ id: `stream-${index}`, index, type, codec: typeof stream.codecName === "string" ? stream.codecName : null, profile: typeof stream.profile === "string" ? stream.profile : null, description: typeof stream.description === "string" ? stream.description : null, durationSeconds: typeof stream.durationSeconds === "number" ? stream.durationSeconds : null, bitrate: typeof stream.bitrate === "number" ? stream.bitrate : null, estimatedSizeBytes: typeof stream.estimatedSizeBytes === "number" ? stream.estimatedSizeBytes : null, language: typeof stream.language === "string" ? stream.language : null, title: typeof stream.title === "string" ? stream.title : null, default: stream.default === true, handbrakeTrackNumber: typeof stream.handbrakeTrackNumber === "number" ? stream.handbrakeTrackNumber : null, width: typeof stream.width === "number" ? stream.width : null, height: typeof stream.height === "number" ? stream.height : null, channels: typeof stream.channels === "number" ? stream.channels : null, frameRate: typeof stream.frameRate === "string" ? stream.frameRate : null, channelLayout: typeof stream.channelLayout === "string" ? stream.channelLayout : null, sampleRate: typeof stream.sampleRate === "number" ? stream.sampleRate : null, hdr: stream.hdr === true }];
    });
    const chapters = Array.isArray(track.chapters) ? (track.chapters as Array<Record<string, unknown>>).map((chapter, index) => ({ id: String(chapter.id ?? index), startSeconds: Number(chapter.startSeconds ?? 0), endSeconds: Number(chapter.endSeconds ?? 0), title: typeof chapter.title === "string" ? chapter.title : null })) : [];
    return {
      sourcePath, sourceType: discType, sourceFingerprint, analysisId,
      titleId: typeof track.titleId === "string" ? track.titleId : null,
      titleIndex: typeof track.titleIndex === "number" ? track.titleIndex : position,
      handbrakeTitleNumber: typeof track.handbrakeTitleNumber === "number" ? track.handbrakeTitleNumber : null,
      dvdVtsNumber: typeof track.dvdVtsNumber === "number" ? track.dvdVtsNumber : null,
      physicalVtsNumber: typeof track.physicalVtsNumber === "number" ? track.physicalVtsNumber : null,
      verificationStatus: typeof track.verificationStatus === "string" ? track.verificationStatus : null,
      displayName: typeof track.name === "string" ? track.name : `Title ${position + 1}`,
      durationSeconds: typeof track.durationSeconds === "number" ? track.durationSeconds : null,
      sizeBytes: typeof track.sizeBytes === "number" ? track.sizeBytes : null,
      streams, chapters,
    };
  });
}

function actionForSelectedMode(
  processingMode: ProcessingMode,
  subtitleMode: SubtitleMode,
): WorkflowItem["action"] {
  if (processingMode === "remux") return "remux";
  if (processingMode === "compress") return "compress";
  return subtitleMode === "skip" ? "skip" : "subtitle";
}

function pipelineForAction(action: WorkflowItem["action"]): ProcessingStep[] {
  return action === "remux" || action === "compress" || action === "subtitle"
    ? [action]
    : [];
}

function planJobBody(plan: WorkflowPlan, item: WorkflowItem, presets: ArchivePreset[], genOptions?: { generateReadme: boolean; generatePoster: boolean; generateReview: boolean }, overview?: string | null, modeWasConfirmed = false, selectedProcessingMode?: ProcessingMode | null, selectedSubtitleMode?: SubtitleMode) {
  const selected = item.streams.filter((stream) => item.selectedStreamIds.includes(stream.id)).map((stream) => stream.index ?? Number(stream.id.replace("stream-", ""))).filter((index) => Number.isFinite(index));
  const chapterIds = item.selectedChapterIds.map((id) => Number(id)).filter((id) => Number.isFinite(id));
  const processingMode = item.action === "remux" ? "remux" : item.action === "compress" ? "compress" : "none";
  const subtitleMode = item.action === "subtitle"
    ? workflowSubtitleModeForJob(item.subtitle.mode, selectedProcessingMode, selectedSubtitleMode)
    : "skip";
  const identity = plan.identity;
  const selectedPreset = item.action === "compress" && item.presetId
    ? presets.find((preset) => preset.id === item.presetId)
    : undefined;
  const pipeline: ProcessingStep[] = item.action === "remux" ? ["remux"] : item.action === "compress" ? ["compress"] : item.action === "subtitle" ? ["subtitle"] : [];
  const pipelineNames = pipelineNamesFor(plan, item, pipeline);
  return {
    filePath: item.sourcePath,
    mediaType: item.sourceType,
    processingMode,
    subtitleMode,
    pipelineSteps: pipeline,
    pipelineNames,
    movieTitle: identity?.title || undefined,
    movieTitleEn: identity?.titleEn || undefined,
    movieImdbId: identity?.imdbId || undefined,
    movieYear: identity?.year ?? undefined,
    movieOverview: (overview?.trim() ? overview.trim() : undefined) || identity?.overview || undefined,
    moviePoster: identity?.poster || undefined,
    generateReadme: genOptions?.generateReadme ?? false,
    generatePoster: genOptions?.generatePoster ?? false,
    generateReview: genOptions?.generateReview ?? false,
    outputMode: item.action === "remux" ? "remux" : item.action === "subtitle"
      ? (subtitleMode === "whisper" || subtitleMode === "transcribe_translate" ? "whisper" : "subtitle")
      : "compress",
    compressionSettings: selectedPreset ? presetConfigValues(selectedPreset) : undefined,
    selectedStreams: JSON.stringify(selected),
    selectedChapters: workflowChapterSelectionPayload(item),
    analysisId: item.analysisId ?? undefined,
    sourceFingerprint: item.sourceFingerprint || undefined,
    selectedTitleId: item.titleId ?? undefined,
    selectionPlan: JSON.stringify({
      version: 1,
      workflow: "smart-workflow-v1",
      needsUserSelection: !modeWasConfirmed,
      planId: plan.planId,
      itemId: item.id,
      outputName: item.outputName,
      presetId: item.presetId ?? null,
      video: item.streams.filter((stream) => stream.type === "video" && item.selectedStreamIds.includes(stream.id)).map((stream) => stream.index ?? Number(stream.id.replace("stream-", ""))),
      audio: item.streams.filter((stream) => stream.type === "audio" && item.selectedStreamIds.includes(stream.id)).map((stream) => stream.index ?? Number(stream.id.replace("stream-", ""))),
      subtitle: item.streams.filter((stream) => stream.type === "subtitle" && item.selectedStreamIds.includes(stream.id)).map((stream) => stream.index ?? Number(stream.id.replace("stream-", ""))),
      chapters: chapterIds,
      dvdvideo: item.sourceType === "dvd" ? {
        titleNumber: item.dvdVtsNumber ?? null,
        physicalVtsNumber: item.physicalVtsNumber ?? null,
        verified: item.verificationStatus === "verified",
      } : undefined,
      handbrake: item.handbrakeTitleNumber ? {
        titleNumber: item.handbrakeTitleNumber,
        durationSeconds: item.durationSeconds,
        titleSizeBytes: null,
        audioTrackNumbers: item.streams.filter((stream) => stream.type === "audio" && item.selectedStreamIds.includes(stream.id)).map((stream) => stream.handbrakeTrackNumber).filter((value): value is number => typeof value === "number" && value > 0),
        subtitleTrackNumbers: item.streams.filter((stream) => stream.type === "subtitle" && item.selectedStreamIds.includes(stream.id)).map((stream) => stream.handbrakeTrackNumber).filter((value): value is number => typeof value === "number" && value > 0),
        chapterNumbers: chapterIds.map((chapter) => chapter + 1),
      } : undefined,
      compressionRationale: item.compression.rationale,
      estimatedOutputBytes: item.compression.estimatedOutputBytes,
    }),
  };
}

/** 从输出名提取 “英文名.年份” 基名（不含压缩标签）。 */
function englishYearBase(outputName: string): string | null {
  const match = /^(.+\.(?:19|20)\d{2})(?:\..+)?$/.exec(outputName);
  return match?.[1] ?? null;
}

/** 按确认的命名模板生成流水线各阶段文件名（压缩版/Remux 版，文件名不含中文）。 */
function pipelineNamesFor(plan: WorkflowPlan, item: WorkflowItem, pipeline: ProcessingStep[]): { remux?: string; compress?: string } {
  const names: { remux?: string; compress?: string } = {};
  if (pipeline.includes("compress") && item.outputName) {
    names.compress = /\.(mkv|mp4)$/i.test(item.outputName) ? item.outputName : `${item.outputName}.mkv`;
  }
  if (pipeline.includes("remux")) {
    const base = englishYearBase(item.outputName)
      ?? (() => {
        const year = plan.identity.year ? String(plan.identity.year) : "";
        const rawTitle = plan.identity.titleEn
          || (plan.identity.title && !/[\u3400-\u9fff]/.test(plan.identity.title) ? plan.identity.title : "")
          || plan.identity.title
          || fileStem(item.sourcePath);
        const words = rawTitle.replace(/[^\p{L}\p{N}]+/gu, ".").replace(/^\.+|\.+$/g, "").replace(/\.{2,}/g, ".");
        return [words, year].filter(Boolean).join(".");
      })();
    const source = item.sourceType === "dvd" ? "DVD" : item.sourceType === "bluray" || item.sourceType === "iso" ? "BluRay" : "";
    names.remux = `${base}${source ? "." + source : ""}.Remux.mkv`;
  }
  return names;
}

export default function Workflow({
  sourcePath: externalSourcePath,
  onSourcePathChange,
  selectedProcessingMode = null,
  selectedSubtitleMode = "skip",
  onProcessingModeChange,
  children,
}: {
  sourcePath?: string;
  onSourcePathChange?: (value: string) => void;
  /** 光盘分析阶段确认的模式；进入工作流后与智能助手双向同步。 */
  selectedProcessingMode?: ProcessingMode | null;
  selectedSubtitleMode?: SubtitleMode;
  onProcessingModeChange?: (mode: ProcessingMode, subtitleMode: SubtitleMode) => void;
  children?: ((slot: { analyze: (pathOverride?: string) => Promise<void>; loading: boolean }) => ReactNode) | ReactNode;
} = {}) {
  const { t } = useI18n();
  const [, setLocation] = useLocation();
  const { data: appConfig } = useGetConfig({ query: { queryKey: getGetConfigQueryKey(), refetchOnWindowFocus: false } });
  const updateConfig = useUpdateConfig();
  const aiAvailable = !!(appConfig?.deepseekApiKey || appConfig?.openaiApiKey || appConfig?.siliconflowApiKey || appConfig?.zhipuApiKey || appConfig?.moonshotApiKey || appConfig?.qwenApiKey || appConfig?.groqApiKey || appConfig?.geminiApiKey);
  const tuningLogic = parseCustomTuning(appConfig?.customTuning).logic;
  const [stage, setStage] = useState<Stage>(1);
  const [internalSourcePath, setInternalSourcePath] = useState("");
  // When embedded in the workbench, the source directory is owned by the
  // parent (shared across all processing tabs). Standalone /workflow still
  // keeps its own local path state.
  const sourcePath = externalSourcePath ?? internalSourcePath;
  const analyzedSourceRef = useRef("");
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [media, setMedia] = useState<WorkflowMedia[]>([]);
  const [plan, setPlan] = useState<WorkflowPlan | null>(null);
  const [activeSelectionItemId, setActiveSelectionItemId] = useState<string | null>(null);
  const [metadataCandidates, setMetadataCandidates] = useState<WorkflowIdentity[]>([]);
  const [assistantGen, setAssistantGen] = useState<{ generateReadme: boolean; generatePoster: boolean; generateReview: boolean }>({ generateReadme: false, generatePoster: false, generateReview: false });
  const [createdJobs, setCreatedJobs] = useState<Array<{ id?: number; error?: string }>>([]);
  const [manualTitle, setManualTitle] = useState("");
  const presets = useMemo(() => loadCompressionPresets(), []);
  const presetIds = useMemo(() => (presets.length > 0 ? presets.map((preset) => preset.id) : DEFAULT_COMPRESSION_PRESETS.map((preset) => preset.id)), [presets]);
  const presetOptions = useMemo(
    () => presets.map((preset) => ({ id: preset.id, label: t(preset.labelKey) })),
    [presets, t],
  );
  const assistantContext = useMemo<Record<string, unknown>>(() => plan ? ({
    planId: plan.planId,
    identity: plan.identity,
    sourcePath: plan.source.path,
    sourceType: plan.source.type,
    items: plan.items.map((item) => ({
      id: item.id,
      displayName: item.displayName,
      action: item.action,
      pipeline: item.pipeline ?? null,
      presetId: item.presetId,
      outputName: item.outputName,
      enabled: item.enabled,
      inferredUse: item.inferredUse,
      durationSeconds: item.durationSeconds,
      sizeBytes: item.sizeBytes,
      audioTracks: item.streams.filter((stream) => stream.type === "audio").length,
      subtitleTracks: item.streams.filter((stream) => stream.type === "subtitle").length,
      externalSubtitles: item.externalSubtitles ?? [],
    })),
  }) : {}, [plan]);
  const analysisContextRef = useRef<Record<string, unknown>>({});
  analysisContextRef.current = assistantContext;
  const [correction, setCorrection] = useState<AssistantCorrection | null>(null);
  const assistantAnalysis = useAssistantAnalysis({
    contextType: "workflow",
    contextRef: analysisContextRef,
    onCorrection: setCorrection,
  });

  // If the shared source directory changes after an analysis was started,
  // reset the wizard so the plan can never point at a stale source.
  useEffect(() => {
    if (analyzedSourceRef.current && sourcePath.trim() && sourcePath.trim() !== analyzedSourceRef.current) {
      analyzedSourceRef.current = "";
      setStage(1);
      setPlan(null);
      setActiveSelectionItemId(null);
      setMedia([]);
      setCreatedJobs([]);
      setMetadataCandidates([]);
      setManualTitle("");
      setError(null);
      setStatus(t("workflow.chooseStart"));
    }
  }, [sourcePath]);

  const analyze = async (pathOverride?: string) => {
    const trimmed = (pathOverride ?? sourcePath).trim();
    if (!trimmed) { setError(t("workflow.enterPathFirst")); return; }
    analyzedSourceRef.current = trimmed;
    setLoading(true); setError(null); setMedia([]); setPlan(null); setActiveSelectionItemId(null); setStage(1); setStatus(t("workflow.identifyingSource"));
    try {
      let nextMedia: WorkflowMedia[] = [];
      const discResponse = await fetch(`/api/disc/analyze?path=${encodeURIComponent(trimmed)}`);
      if (discResponse.ok) {
        setStatus(t("workflow.analyzingTitles"));
        nextMedia = mediaFromDisc(trimmed, await discResponse.json() as Record<string, unknown>);
      } else {
        const discErrorBody = await discResponse.json().catch(() => ({})) as Record<string, unknown>;
        // A real BD/DVD folder must be analyzed as a disc. Never fall back to
        // probing the VOB/MKV files inside it as standalone videos.
        if (discResponse.status === 422 && discErrorBody.discType) {
          throw new Error(String(discErrorBody.error ?? t("workflow.discAnalysisFailed")));
        }
        setStatus(t("workflow.readingTech"));
        const probeResponse = await fetch("/api/smart-workflow/probe", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ sourcePath: trimmed }) });
        const body = await probeResponse.json().catch(() => ({})) as Record<string, unknown>;
        if (!probeResponse.ok) throw new Error(String(body.error ?? t("workflow.cannotAnalyze")));
        nextMedia = Array.isArray(body.files)
          ? (body.files as Array<Record<string, unknown>>).map((file) => mediaFromProbe(file))
          : [mediaFromProbe(body)];
      }
      if (nextMedia.length === 0) throw new Error(t("workflow.noFilesFound"));
      setMedia(nextMedia);
      setStatus(t("workflow.searchingMetadata"));
      const query = fileStem(trimmed);
      let candidates: WorkflowIdentity[] = [];
      let metadataUnavailable = true;
      // Prefer the configured LLM channel for identity confirmation. The
      // existing TMDb/OMDb/local lookup remains a transparent fallback when
      // the provider is unavailable, so traditional processing is unaffected.
      let metadataResponse = await fetch("/api/smart-workflow/metadata", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ query, language: "zh-CN", media: nextMedia }) });
      let metadataFromLlm = metadataResponse.ok;
      if (!metadataResponse.ok) {
        metadataResponse = await fetch("/api/metadata/lookup", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ query, language: "zh-CN" }) });
        metadataFromLlm = false;
      }
      if (metadataResponse.ok) {
        const metadataBody = await metadataResponse.json() as Array<Record<string, unknown>>;
        candidates = metadataBody.map((candidate) => ({
          title: String(candidate.title ?? query),
          titleEn: typeof candidate.titleEn === "string" ? candidate.titleEn : null,
          // LLM suggestions are not identity authorities. IMDb/poster fields
          // are filled only from the filtered metadata lookup below.
          imdbId: !metadataFromLlm && typeof candidate.imdbId === "string" && /^tt\d{7,8}$/i.test(candidate.imdbId.trim()) ? candidate.imdbId.trim() : null,
          year: typeof candidate.year === "number" ? candidate.year : null,
          poster: !metadataFromLlm && typeof candidate.poster === "string" ? candidate.poster : null,
          overview: typeof candidate.overview === "string" ? candidate.overview : null,
          source: typeof candidate.source === "string" ? candidate.source : null,
          confidence: typeof candidate.confidence === "number" ? Math.max(0, Math.min(1, candidate.confidence)) : 0.8,
          matchReason: typeof candidate.matchReason === "string" ? candidate.matchReason : null,
          technicalAssessment: typeof candidate.technicalAssessment === "string" ? candidate.technicalAssessment : null,
          recommendedAction: typeof candidate.recommendedAction === "string" ? candidate.recommendedAction : null,
        }));
        metadataUnavailable = candidates.length === 0;
        // LLMs provide the title suggestion; the configured metadata sources
        // enrich the first candidate with an authoritative IMDb id/poster.
        if (metadataFromLlm && candidates.length > 0) {
          try {
            const posterResponse = await fetch("/api/metadata/lookup", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ query, language: "zh-CN" }) });
            if (posterResponse.ok) {
              const posterBody = await posterResponse.json() as Array<Record<string, unknown>>;
              const firstTitle = candidates[0]?.titleEn || candidates[0]?.title || query;
              const compact = (value: string) => value.toLowerCase().replace(/[^a-z0-9\u3400-\u9fff]/g, "");
              const queryKey = compact(firstTitle);
              const matchedCandidate = posterBody.find((candidate) => {
                const candidateTitle = typeof candidate.titleEn === "string" ? candidate.titleEn : typeof candidate.title === "string" ? candidate.title : "";
                const candidateKey = compact(candidateTitle);
                const yearMatches = typeof candidates[0]?.year !== "number" || typeof candidate.year !== "number" || Math.abs(candidates[0].year - candidate.year) <= 1;
                return Boolean(candidateKey && yearMatches && (candidateKey === queryKey || candidateKey.includes(queryKey) || queryKey.includes(candidateKey)));
              });
              const posterCandidate = matchedCandidate && typeof matchedCandidate.poster === "string" && matchedCandidate.poster.length > 0 ? matchedCandidate : null;
              const posterUrl = typeof posterCandidate?.poster === "string" ? posterCandidate.poster : null;
              if (posterUrl) {
                candidates = candidates.map((candidate, index) => index === 0 ? { ...candidate, poster: posterUrl } : candidate);
              }
              const imdbCandidate = matchedCandidate && typeof matchedCandidate.imdbId === "string" && /^tt\d{7,8}$/i.test(matchedCandidate.imdbId.trim()) ? matchedCandidate : null;
              const imdbId = typeof imdbCandidate?.imdbId === "string" ? imdbCandidate.imdbId.trim() : null;
              if (imdbId) {
                candidates = candidates.map((candidate, index) => index === 0 ? { ...candidate, imdbId: candidate.imdbId ?? imdbId } : candidate);
              }
            }
          } catch {
            // Poster enrichment is optional and must not block local analysis.
          }
        }
      }
      setMetadataCandidates(candidates);
      setManualTitle(candidates[0]?.title ?? query);
      setStatus(t("workflow.generatingPlan"));
      const planResponse = await fetch("/api/smart-workflow/plan", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ media: nextMedia, identity: candidates[0] ?? { title: query }, candidates, presetIds, metadataUnavailable, aiUnavailable: !metadataFromLlm, requireExplicitAction: true }) });
      let planBody = await planResponse.json().catch(() => ({})) as WorkflowPlan & { error?: string };
      if (!planResponse.ok) throw new Error(planBody.error ?? t("workflow.cannotGeneratePlan"));
      // 后端返回的 action/preset 只是分析建议，不是用户确认；进入计划页时全部留空。
      const preparedItems = clearWorkflowChoices(planBody.items).map((item) => ({
        ...item,
        ...(selectedProcessingMode
          ? (() => {
              const action = actionForSelectedMode(selectedProcessingMode, selectedSubtitleMode);
              return { action, pipeline: pipelineForAction(action) };
            })()
          : {}),
        selectedStreamIds: allSelectionIds(item.streams.map((stream) => stream.id)),
        selectedChapterIds: allSelectionIds(item.chapters.map((chapter) => chapter.id)),
      }));
      const preparedPlan = { ...planBody, items: preparedItems };
      setPlan(preparedPlan); setActiveSelectionItemId(preparedItems[0]?.id ?? null); setStage(2); setStatus(metadataUnavailable ? t("workflow.metadataUnavailablePlan") : t("workflow.confirmIdentity"));
    } catch (reason) {
      logWorkflowIssue("analyze", reason instanceof Error ? reason.message : String(reason), { sourcePath: trimmed });
      setError(reason instanceof Error ? reason.message : String(reason));
      setStatus(t("workflow.analysisFailed"));
    } finally { setLoading(false); }
  };

  const updatePlanItem = (id: string, update: Partial<WorkflowItem>) => {
    setPlan((current) => current ? { ...current, items: current.items.map((item) => item.id === id ? { ...item, ...update } : item) } : current);
  };

  // A mode selected in the disc analysis dialog is authoritative for this
  // workflow. If the plan already exists, update it immediately so the
  // assistant and the final job request cannot drift apart.
  useEffect(() => {
    if (!selectedProcessingMode) return;
    const action = actionForSelectedMode(selectedProcessingMode, selectedSubtitleMode);
    setPlan((current) => current
      ? {
          ...current,
          items: current.items.map((item) => ({
            ...item,
            action,
            pipeline: pipelineForAction(action),
            presetId: action === "compress" ? item.presetId : null,
          })),
        }
      : current);
  }, [selectedProcessingMode, selectedSubtitleMode]);

  const updateStreamSelection = (item: WorkflowItem, streamId: string) => {
    updatePlanItem(item.id, { selectedStreamIds: toggleSelectionId(item.selectedStreamIds, streamId) });
  };

  const updateChapterSelection = (item: WorkflowItem, chapterId: string) => {
    updatePlanItem(item.id, { selectedChapterIds: toggleSelectionId(item.selectedChapterIds, chapterId) });
  };

  const setAllStreamsForItem = (item: WorkflowItem, selected: boolean) => {
    updatePlanItem(item.id, {
      selectedStreamIds: selected ? allSelectionIds(item.streams.map((stream) => stream.id)) : [],
    });
  };

  const setAllChaptersForItem = (item: WorkflowItem, selected: boolean) => {
    updatePlanItem(item.id, {
      selectedChapterIds: selected ? allSelectionIds(item.chapters.map((chapter) => chapter.id)) : [],
    });
  };

  const allPlanItemsEnabled = Boolean(plan && plan.items.length > 0 && plan.items.every((item) => item.enabled));
  const toggleAllPlanItems = () => {
    setPlan((current) => current ? { ...current, items: current.items.map((item) => ({ ...item, enabled: !current.items.every((candidate) => candidate.enabled) })) } : current);
  };

  const updatePlanAction = (item: WorkflowItem, action: WorkflowItem["action"]) => {
    updatePlanItem(item.id, { action, presetId: action === "compress" ? item.presetId : null });
  };

  const applyPresetToPlan = (presetId: string) => {
    if (!plan) return;
    for (const item of plan.items) {
      updatePlanItem(item.id, { presetId, action: item.action === "compress" ? "compress" : item.action });
    }
    const preset = presets.find((candidate) => candidate.id === presetId);
    if (preset) {
      void updateConfig.mutateAsync({ data: presetConfigValues(preset) }).catch(() => {});
    }
  };

  const activeSelectionItem = plan?.items.find((item) => item.id === activeSelectionItemId) ?? plan?.items[0] ?? null;

  const confirmAndCreate = async () => {
    if (!plan) return;
    setLoading(true); setError(null); setStatus(t("workflow.savingPlan"));
    try {
      const identity = { ...plan.identity, title: manualTitle.trim() || plan.identity.title };
      const finalPlan = { ...plan, identity };
      const validation = await fetch("/api/smart-workflow/validate", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ plan: finalPlan, availablePresetIds: presetIds }) });
      const validationBody = await validation.json().catch(() => ({})) as { errors?: string[] };
      if (!validation.ok) throw new Error((validationBody.errors ?? [t("workflow.planValidationFailed")]).join("；"));
      for (const item of finalPlan.items.filter((candidate) => candidate.enabled && candidate.action === "remux" && candidate.sourceType === "dvd")) {
        const verify = await fetch("/api/disc/verify-title", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ analysisId: item.analysisId, titleId: item.titleId }),
        });
        const verifyBody = await verify.json().catch(() => ({})) as { failureReason?: string; error?: string };
        if (!verify.ok) throw new Error(verifyBody.failureReason ?? verifyBody.error ?? t("workflow.dvdVerifyFailed"));
      }
      const saved = await fetch("/api/smart-workflow/save-plan", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ plan: finalPlan }) });
      if (!saved.ok) throw new Error(t("workflow.planSaveFailed"));
      const results: Array<{ id?: number; error?: string }> = [];
      for (const item of finalPlan.items.filter((candidate) => candidate.enabled && candidate.action !== "skip")) {
        const response = await fetch("/api/jobs", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(planJobBody(finalPlan, item, presets, assistantGen, assistantAnalysis.analysisResult, Boolean(selectedProcessingMode), selectedProcessingMode, selectedSubtitleMode)) });
        const body = await response.json().catch(() => ({})) as { id?: number; error?: string };
        if (!response.ok) throw new Error(body.error ?? t("workflow.createJobFailed", { status: response.status }));
        results.push({ id: body.id });
      }
      setPlan(finalPlan); setCreatedJobs(results); setStage(4); setStatus(t("workflow.jobsCreated", { count: results.length }));
      // 确认后自动跳到任务队列的视频与字幕预览界面（首个任务详情）
      if (results[0]?.id) setLocation(`/jobs/${results[0].id}`);
    } catch (reason) {
      logWorkflowIssue("create-job", reason instanceof Error ? reason.message : String(reason), { planId: plan.planId });
      setError(reason instanceof Error ? reason.message : String(reason));
      setStatus(t("workflow.noJobsCreated"));
    } finally { setLoading(false); }
  };

  const assistantProcessing: ProcessingStep[] = selectedProcessingMode === "remux"
    ? ["remux"]
    : selectedProcessingMode === "compress"
      ? ["compress"]
      : selectedProcessingMode === "none" && selectedSubtitleMode !== "skip"
        ? ["subtitle"]
        : [];
  const assistantSubtitle = selectedProcessingMode === "none" && selectedSubtitleMode !== "skip"
    ? selectedSubtitleMode
    : selectedProcessingMode === "none"
      ? "skip"
      : null;

  return (
    <div className="space-y-4" data-testid="smart-workflow-page">
      <div className="flex items-start justify-between gap-4">
        <p className="text-sm text-muted-foreground">{t("workflow.subtitle")}</p>
        <div className="flex flex-wrap justify-end gap-2 text-xs"><span className="rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-primary">{t("workflow.traditionalAvailable")}</span><span className="rounded-full border border-border/70 px-3 py-1 text-muted-foreground">{t("workflow.aiLabel")}{appConfig?.aiTranslationEnabled ? t("workflow.configured") : t("workflow.offline")}</span><span className="rounded-full border border-border/70 px-3 py-1 text-muted-foreground">{t("workflow.metadataLabel")}{appConfig?.tmdbApiKey || appConfig?.omdbApiKey ? t("workflow.configured") : t("workflow.manualOffline")}</span></div>
      </div>
      {/* Shared source directory card (rendered by the workbench above the wizard). */}
      {typeof children === "function" ? children({ analyze, loading }) : children}
      {(stage > 1 || error) && (
      <Card>
        <CardHeader><CardTitle className="flex items-center gap-2"><Film className="h-4 w-4 text-primary" />{stage === 1 ? t("workflow.stepChooseSource") : stage === 2 ? t("workflow.stepAnalyzeConfirm") : stage === 3 ? t("workflow.stepPlanConfirm") : t("workflow.stepResult")}</CardTitle><CardDescription>{status}</CardDescription></CardHeader>
        <CardContent className="space-y-4">
          {stage === 2 && plan && (
            <div className="space-y-4">
              <div className="grid items-start gap-4 md:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
                <div className="flex min-w-0 gap-4 rounded-lg border p-3">
                  {plan.identity.poster ? <img src={plan.identity.poster} alt={t("workflow.moviePoster")} className="h-36 w-24 shrink-0 rounded object-cover" /> : <div className="flex h-36 w-24 shrink-0 items-center justify-center rounded bg-secondary text-2xl">🎬</div>}
                  <div className="min-w-0 flex-1 space-y-2">
                    <p className="truncate font-mono text-xs text-primary" title={plan.identity.displayName ?? undefined}>{plan.identity.displayName}</p>
                    <Label>{t("workflow.movieNameEditable")}</Label>
                    <Input value={manualTitle} onChange={(event) => setManualTitle(event.target.value)} />
                    <p className="text-xs text-muted-foreground">{plan.degraded.metadataUnavailable ? t("workflow.metadataUnavailableHint") : <>{t("workflow.dataSourceLabel")}{plan.metadata.source ?? t("workflow.localCandidate")}</>}</p>
                  </div>
                </div>
                <div className="min-w-0 rounded-lg border border-primary/25 bg-primary/5 p-3">
                  <div className="mb-2 flex items-center justify-between gap-2"><span className="font-medium">{t("workflow.llmSuggestion")}</span><span className="text-xs text-muted-foreground">{t("workflow.doubanTitle")}</span></div>
                  {metadataCandidates.length > 0 ? <div className="grid gap-2">{metadataCandidates.slice(0, 4).map((candidate, index) => <button key={`${candidate.title}-${index}`} type="button" className="rounded border bg-background/45 p-3 text-left transition hover:border-primary/60" onClick={() => setManualTitle(candidate.title)}><div className="flex items-center justify-between gap-2"><span className="font-medium">{candidateTitle(candidate)}</span><span className="text-xs text-primary">{t("workflow.confidenceValue", { percent: Math.round((candidate.confidence ?? 0) * 100) })}</span></div>{candidate.overview && <p className="mt-1 text-xs text-muted-foreground">{candidate.overview}</p>}{candidate.matchReason && <p className="mt-2 text-xs"><span className="text-muted-foreground">{t("workflow.matchBasis")}</span>{candidate.matchReason}</p>}{candidate.technicalAssessment && <p className="mt-1 text-xs"><span className="text-muted-foreground">{t("workflow.technicalJudgment")}</span>{candidate.technicalAssessment}</p>}{candidate.recommendedAction && <p className="mt-1 text-xs text-primary"><span className="text-muted-foreground">{t("workflow.recommendation")}</span>{candidate.recommendedAction}</p>}</button>)}</div> : <p className="text-xs text-muted-foreground">{t("workflow.noReliableCandidates")}</p>}
                </div>
              </div>
              <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,0.82fr)_minmax(0,1.18fr)]">
                <div className="min-w-0 space-y-2">
                  <div className="flex items-center justify-between gap-2 text-sm font-medium"><span>{t("workflow.titleList")}</span><span className="text-xs text-muted-foreground">{t("workflow.titleListHint")}</span></div>
                  <div className="space-y-2">
                    {plan.items.map((item) => {
                      const active = activeSelectionItem?.id === item.id;
                      return <button key={item.id} type="button" onClick={() => setActiveSelectionItemId(item.id)} className={`w-full rounded-lg border p-3 text-left transition ${active ? "border-primary bg-primary/10" : "hover:border-primary/50"}`}>
                        <div className="flex flex-wrap items-center justify-between gap-2"><span className="min-w-0 truncate font-medium">{item.displayName}</span><span className="shrink-0 text-xs text-muted-foreground">{item.sourceType.toUpperCase()}</span></div>
                        <p className="mt-1 text-xs text-muted-foreground">{t("workflow.durationLabel")} {formatDuration(item.durationSeconds, t)} · {t("workflow.sizeLabel")} {formatSize(item.sizeBytes, t)}</p>
                        <p className="mt-1 text-xs text-muted-foreground">{item.streams.length} {t("workflow.streamsCount")} · {item.chapters.length} {t("workflow.chaptersCount")} · {t("workflow.selectedCount", { selected: item.selectedStreamIds.length, total: item.streams.length })}</p>
                      </button>;
                    })}
                  </div>
                </div>
                <div className="min-w-0 rounded-lg border border-primary/25 bg-primary/5 p-3">
                  {activeSelectionItem ? <>
                    <div className="mb-3 flex flex-wrap items-start justify-between gap-2"><div className="min-w-0"><p className="text-xs text-muted-foreground">{t("workflow.selectionSummary")}</p><p className="truncate font-medium" title={activeSelectionItem.displayName ?? undefined}>{activeSelectionItem.displayName}</p></div><span className="shrink-0 text-xs text-muted-foreground">{t("workflow.selectedCount", { selected: activeSelectionItem.selectedStreamIds.length, total: activeSelectionItem.streams.length })}</span></div>
                    <div className="mb-2 flex flex-wrap items-center justify-between gap-2"><span className="text-sm font-medium">{t("workflow.streamSelection")}</span><div className="flex gap-1"><Button type="button" variant="outline" size="sm" className="h-7 px-2 text-xs" onClick={() => setAllStreamsForItem(activeSelectionItem, true)}>{t("workflow.selectAllStreams")}</Button><Button type="button" variant="outline" size="sm" className="h-7 px-2 text-xs" onClick={() => setAllStreamsForItem(activeSelectionItem, false)}>{t("workflow.clearStreams")}</Button></div></div>
                    <div className="max-h-72 space-y-1 overflow-y-auto rounded-md border bg-background/50 p-1">
                      {activeSelectionItem.streams.length > 0 ? activeSelectionItem.streams.map((stream) => <label key={stream.id} className="flex cursor-pointer items-start gap-2 rounded px-2 py-2 text-xs hover:bg-secondary/50"><input type="checkbox" className="mt-0.5" checked={activeSelectionItem.selectedStreamIds.includes(stream.id)} onChange={() => updateStreamSelection(activeSelectionItem, stream.id)} /><span className="min-w-0"><span className="font-medium">{stream.type === "video" ? t("workflow.streamVideo") : stream.type === "audio" ? t("workflow.streamAudio") : t("workflow.streamSubtitle")}</span><span className="text-muted-foreground"> · {(stream.language || t("workflow.unknownLanguage")).toUpperCase()} · {stream.codec || t("workflow.unknownCodec")}{stream.profile ? ` (${stream.profile})` : ""}{stream.title ? ` · ${stream.title}` : ""}</span></span></label>) : <p className="p-2 text-xs text-muted-foreground">{t("workflow.noStreams")}</p>}
                    </div>
                    {activeSelectionItem.chapters.length > 0 && <><div className="mb-2 mt-4 flex flex-wrap items-center justify-between gap-2"><span className="text-sm font-medium">{t("workflow.chapterSelection")}</span><div className="flex gap-1"><Button type="button" variant="outline" size="sm" className="h-7 px-2 text-xs" onClick={() => setAllChaptersForItem(activeSelectionItem, true)}>{t("workflow.selectAllChapters")}</Button><Button type="button" variant="outline" size="sm" className="h-7 px-2 text-xs" onClick={() => setAllChaptersForItem(activeSelectionItem, false)}>{t("workflow.clearChapters")}</Button></div></div><div className="max-h-48 space-y-1 overflow-y-auto rounded-md border bg-background/50 p-1">{activeSelectionItem.chapters.map((chapter) => <label key={chapter.id} className="flex cursor-pointer items-center gap-2 rounded px-2 py-2 text-xs hover:bg-secondary/50"><input type="checkbox" checked={activeSelectionItem.selectedChapterIds.includes(chapter.id)} onChange={() => updateChapterSelection(activeSelectionItem, chapter.id)} /><span>#{Number(chapter.id) + 1}</span><span className="min-w-0 truncate text-muted-foreground">{chapter.title || `${formatDuration(chapter.startSeconds, t)} - ${formatDuration(chapter.endSeconds, t)}`}</span></label>)}</div></>}
                  </> : <p className="text-sm text-muted-foreground">{t("workflow.selectTitleFirst")}</p>}
                </div>
              </div>
              <div className="flex items-center justify-between">
                <Button type="button" variant="outline" onClick={() => setStage(1)}>{t("workflow.backToSource")}</Button>
                <Button onClick={() => setStage(3)}>{t("workflow.confirmIdentityViewPlan")}</Button>
              </div>
            </div>
          )}
          {stage === 3 && plan && <div className="space-y-3"><div className="rounded-lg border border-primary/20 bg-primary/5 p-3 text-sm flex items-center justify-between gap-3"><span>{t("workflow.planContains", { count: plan.items.length })}</span><label className="flex shrink-0 items-center gap-2 font-medium"><input type="checkbox" checked={allPlanItemsEnabled} onChange={toggleAllPlanItems} />{t("workflow.selectAllProcess")}</label></div>{plan.items.map((item) => <div key={item.id} className="rounded-lg border p-4"><div className="flex flex-wrap items-center gap-3"><label className="flex items-center gap-2"><input type="checkbox" checked={item.enabled} onChange={(event) => updatePlanItem(item.id, { enabled: event.target.checked })} />{t("workflow.process")}</label><span className="font-medium">{item.displayName}</span><span className="rounded bg-secondary px-2 py-0.5 text-xs">{item.inferredUse}</span><span className="text-xs text-muted-foreground">{t("workflow.confidenceValue", { percent: Math.round(item.confidence * 100) })}</span>{hasChineseSubtitle(item) && <span className="rounded bg-emerald-500/15 px-2 py-0.5 text-xs text-emerald-400">{t("workflow.chineseSubtitle")}</span>}</div><div className="mt-3 grid gap-3 md:grid-cols-3"><div><Label>{t("workflow.action")}</Label><select className="mt-1 h-9 w-full rounded-md border bg-background px-2 text-sm" value={item.action} disabled={Boolean(selectedProcessingMode)} onChange={(event) => updatePlanAction(item, event.target.value as WorkflowItem["action"])}><option value="compress">{t("workflow.videoCompression")}</option><option value="remux">{t("workflow.remuxLossless")}</option>{!hasChineseSubtitle(item) && <option value="subtitle">{t("workflow.subtitleSpeech")}</option>}<option value="skip">{t("workflow.skipSuggested")}</option></select>{hasChineseSubtitle(item) && <p className="mt-1 text-xs text-emerald-400/90">{t("workflow.chineseSubtitleHint")}</p>}</div><div><Label>{t("workflow.compressionPreset")}</Label><select className="mt-1 h-9 w-full rounded-md border bg-background px-2 text-sm" value={item.presetId ?? ""} disabled={item.action !== "compress" || Boolean(selectedProcessingMode)} onChange={(event) => updatePlanItem(item.id, { presetId: event.target.value || null })}><option value="">{t("workflow.skipCompression")}</option>{presetIds.map((id) => <option key={id} value={id}>{workflowPresetLabel(id, presetOptions)}</option>)}</select>{item.action === "remux" && <p className="mt-1 text-xs text-muted-foreground">{t("workflow.remuxNoReencode")}</p>}{item.action === "subtitle" && <p className="mt-1 text-xs text-muted-foreground">{t("workflow.subtitleOnlyHint")}</p>}</div><div><Label>{t("workflow.targetFileName")}</Label><Input className="mt-1" value={item.outputName} onChange={(event) => updatePlanItem(item.id, { outputName: event.target.value })} /></div></div><div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-muted-foreground"><span>{t("workflow.durationLabel")} {formatDuration(item.durationSeconds, t)}</span><span>{t("workflow.sizeLabel")} {formatSize(item.sizeBytes, t)}</span><span>{t("workflow.videoCount")} {item.selectedStreamIds.filter((id) => item.streams.find((stream) => stream.id === id)?.type === "video").length}</span><span>{t("workflow.audioCount")} {item.selectedStreamIds.filter((id) => item.streams.find((stream) => stream.id === id)?.type === "audio").length}</span><span className="flex flex-wrap items-center gap-1">{t("workflow.subtitleStrategy")}<span className="font-medium text-foreground">{subtitleModeLabel(item.subtitle.mode, t)}</span>{hasChineseSubtitle(item) && <span className="rounded bg-emerald-500/15 px-1.5 py-0.5 text-emerald-400">{t("workflow.chineseSubtitle")}</span>}</span><span>{item.compression.rationale}</span></div></div>)}<AssistantPanel
  contextType="workflow"
  context={assistantContext}
  allowRemux={plan.source.type !== "video"}
  aiAvailable={aiAvailable}
  posterUrl={plan.identity.poster ?? null}
  sourceName={fileStem(sourcePath)}
  presets={presetOptions}
  selectedPresetId={null}
  allowChapterPreview={false}
  generateOptions={assistantGen}
  onGenerateOptionsChange={setAssistantGen}
  promptPlacement="toolbar"
  prompt={assistantAnalysis.prompt}
  promptOpen={assistantAnalysis.promptOpen}
  promptFocusRequest={assistantAnalysis.promptFocusRequest}
  promptAttention={assistantAnalysis.promptAttention}
  onPromptToggle={assistantAnalysis.setPromptOpen}
  onPromptFocus={assistantAnalysis.requestPromptFocus}
  onPromptChange={assistantAnalysis.setPrompt}
  onAnalyze={(fields) => void assistantAnalysis.analyze(fields)}
  analyzing={assistantAnalysis.analyzing}
  analysisResult={assistantAnalysis.analysisResult}
  analysisError={assistantAnalysis.analysisError}
  analysisPosterUrl={assistantAnalysis.analysisPosterUrl}
  metadata={{ metadataSnapshot: assistantAnalysis.analysisMetadata }}
  analysisOpen={assistantAnalysis.analysisOpen}
  onAnalysisOpenChange={assistantAnalysis.setAnalysisOpen}
  correction={correction}
  preferences={{
    year: plan.identity.year ?? null,
    // The upper-level disc selection is mirrored here, and assistant edits are
    // sent back through onProcessingModeChange so the plan cannot drift.
    processing: assistantProcessing,
    subtitle: assistantSubtitle,
  }}
  onPreferencesChange={(prefs) => {
    // 外语名/中文名/年代 → 计划身份（确认时随任务落库）
    setPlan((current) => current ? {
      ...current,
      identity: {
        ...current.identity,
        title: prefs.titleZh.trim() || current.identity.title,
        titleEn: prefs.titleEn.trim() || current.identity.titleEn || null,
        year: prefs.year,
      },
    } : current);
    const nextSelection = workflowModeFromAssistantPreferences(prefs.processing, prefs.subtitle);
    onProcessingModeChange?.(nextSelection.mode, nextSelection.subtitleMode);
    // 点选压缩时，DVD 默认使用调优配置中的压缩预设（音字幕轨道全部保留）
    const dvdCompressPreset = logicValue(tuningLogic, "dvdCompressPreset", "dvd-convert");
    if (prefs.processing.includes("compress") && plan.source.type === "dvd" && plan.items.some((item) => item.presetId !== dvdCompressPreset)) {
      applyPresetToPlan(dvdCompressPreset);
    }
    // 处理 chips 只表示处理意图，不再自动改写每个条目的动作——
    // “下一步做什么（压缩 / Remux / 字幕 / 跳过）”完全由用户在计划里手动选择。
  }}
  onPresetSelect={applyPresetToPlan}
  onConfirm={() => void confirmAndCreate()}
/>
<div className="flex items-center justify-between"><Button type="button" variant="outline" onClick={() => setStage(2)}>{t("workflow.backToIdentity")}</Button><Button onClick={() => void confirmAndCreate()} disabled={loading || !plan.items.some((item) => item.enabled && item.action !== "skip")}>{loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Play className="mr-2 h-4 w-4" />}{t("workflow.confirmAndCreate")}</Button></div></div>}
          {stage === 4 && <div className="space-y-4"><div className="flex items-center gap-3 rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-4 text-emerald-300"><CheckCircle2 className="h-5 w-5" /><span>{status}</span></div><div className="rounded-lg border p-4"><p className="font-medium">{t("workflow.taskId")}</p><p className="mt-2 font-mono text-sm">{createdJobs.map((job) => job.id ?? job.error).join("、") || t("workflow.none")}</p><p className="mt-2 text-xs text-muted-foreground">{t("workflow.planSavedHint")}</p></div><Button variant="outline" onClick={() => { setStage(1); setPlan(null); setMedia([]); setCreatedJobs([]); setStatus(t("workflow.chooseStart")); }}><RefreshCw className="mr-2 h-4 w-4" />{t("workflow.startNew")}</Button></div>}
          {error && <div className="rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">{error}</div>}
        </CardContent>
      </Card>
      )}
    </div>
  );
}
