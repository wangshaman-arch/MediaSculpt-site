import {
  useGetConfig,
  getGetConfigQueryKey,
  useUpdateConfig,
  ConfigInputWhisperModel,
  ConfigInputOutputFormat,
} from "@workspace/api-client-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Slider } from "@/components/ui/slider";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useEffect, useState, useRef, useMemo } from "react";
import type { Resolver } from "react-hook-form";
import { useI18n } from "@/i18n";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import {
  Save,
  Settings2,
  ExternalLink,
  Languages,
  Zap,
  Star,
  ChevronDown,
  ChevronUp,
  Cpu,
  FolderSearch,
  Plus,
  Trash2,
  BookmarkCheck,
  Pencil,
  X,
  RefreshCw,
  RotateCcw,
  FileText,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { DirectoryPicker } from "@/components/DirectoryPicker";
import { ImdbDatasetCard } from "@/components/ImdbDatasetCard";
import { TuningLogicCard } from "@/components/TuningLogicCard";
import { TuningPromptsCard } from "@/components/TuningPromptsCard";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  parseCustomTuning,
  serializeCustomTuning,
  type CustomTuning,
} from "@/lib/custom-tuning";
import {
  useSettingsSections,
  type SettingsSection,
} from "@/hooks/useSettingsSections";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  ARCHIVE_PRESETS,
  ARCHIVE_PRESET_LS_KEY,
  CUSTOM_PRESET_KEY,
  PRESET_CHANGED_EVENT,
  loadCompressionPresets,
  ENCODER_OPTIONS,
  type ArchivePreset,
  type CustomPreset,
} from "@/lib/compression-presets";
import { compressionPresetSummary } from "@/features/workbench/compression-preset-model";
import { ToolManager } from "./settings-tool-manager";
import {
  previewOutputName,
  settingsAssColorToHex,
  settingsHexToAssColor,
} from "./settings-model";

import { SettingsCompressionSection } from "./settings-compression-section";
import { SettingsDirectoriesSection } from "./settings-directories-section";
import { SettingsToolsSection } from "./settings-tools-section";
import { SettingsSystemSection } from "./settings-system-section";
import { SettingsSubtitlesSection } from "./settings-subtitles-section";
import { SettingsAiSection } from "./settings-ai-section";
import {
  SOURCE_DIRECTORY_VALUE,
  SETTINGS_SECTION_TITLES,
  settingsOverviewItems,
  WHISPER_MODEL_LABELS,
  type AiProviderInfo,
  AI_PROVIDER_LIST,
  KEYED_PROVIDERS,
  TRANSLATION_LANGS,
  FRAME_RATES,
  OUTPUT_RESOLUTIONS,
  UI_LANGUAGES,
  THEME_MODES,
  ENCODER_PRESETS,
  ENCODER_TUNES,
  ENCODER_PROFILES,
  ENCODER_LEVELS,
  configSchema,
  type ConfigFormValues,
} from "./settings-model";

export default function Settings() {
  const {
    data: config,
    isLoading: configLoading,
    isError: configError,
  } = useGetConfig({
    query: { queryKey: getGetConfigQueryKey(), refetchOnWindowFocus: false },
  });
  const updateConfig = useUpdateConfig();
  const { toast } = useToast();
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const [tuning, setTuning] = useState<CustomTuning>(() =>
    parseCustomTuning(
      (config as { customTuning?: string | null } | undefined)?.customTuning,
    ),
  );
  useEffect(() => {
    setTuning(
      parseCustomTuning(
        (config as { customTuning?: string | null } | undefined)?.customTuning,
      ),
    );
  }, [config]);
  const saveTuning = async (next: CustomTuning) => {
    await updateConfig.mutateAsync({
      data: { customTuning: serializeCustomTuning(next) },
    });
    setTuningDirty(false);
    queryClient.invalidateQueries({ queryKey: getGetConfigQueryKey() });
  };

  const [tuningDirty, setTuningDirty] = useState(false);
  const saveSucceededRef = useRef(false);

  const hasLoadedRef = useRef(false);

  const resolver = useMemo<Resolver<ConfigFormValues>>(() => {
    const base = zodResolver(configSchema);
    return async (values, context, options) => {
      const result = await base(values, context, options);
      if (result.errors) {
        for (const error of Object.values(
          result.errors as Record<string, { message?: string }>,
        )) {
          if (error?.message?.startsWith("settings.")) {
            error.message = t(error.message);
          }
        }
      }
      return result;
    };
  }, [t]);

  const form = useForm<ConfigFormValues>({
    resolver,
    defaultValues: {
      watchDirectory: "",
      outputDirectory: "",
      remuxOutputDirectory: SOURCE_DIRECTORY_VALUE,
      outputNameTemplate: "",
      posterMirrorUrl: "",
      posterProxyUrl: "",
      handbrakePreset: "",
      whisperModel: ConfigInputWhisperModel.medium,
      subtitleLanguage: "auto",
      crf: 20,
      encoder: "x264_10bit",
      audioCopy: true,
      outputFormat: ConfigInputOutputFormat.mkv,
      subtitleDirectory: "",
      hostDownloadsPath: "",
      hostOutputPath: "",
      libreTranslateUrl: "",
      processHighPriority: false,
      shutdownAfterComplete: false,
      handbrakeCliPath: "",
      subtitleEditCliPath: "",
      tmdbApiKey: "",
      omdbApiKey: "",
      openaiApiKey: "",
      deepseekApiKey: "",
      siliconflowApiKey: "",
      zhipuApiKey: "",
      moonshotApiKey: "",
      qwenApiKey: "",
      groqApiKey: "",
      geminiApiKey: "",
      aiTranslationEnabled: false,
      translationTargetLang: "zh-CN",
      ocrBilingualCorrection: true,
      aiProvider: "deepseek",
      aiBaseUrl: "",
      aiModel: "",
      frameRate: "same",
      outputResolution: "source",
      encoderPreset: "slow",
      encoderTune: "film",
      encoderProfile: "high10",
      encoderLevel: "4.1",
      uiLanguage: "zh-CN",
      themeMode: "deep-ocean",
      deinterlace: false,
      bilingualLayout: "zh-top",
      bilingualOutlineWidth: 0.2,
      bilingualShadowWidth: 0,
      bilingualOutlineColor: "&H00404040",
      bilingualFontSizeTop: 16,
      bilingualFontSizeBottom: 9.6,
    },
  });

  const applyConfigToForm = (cfg: NonNullable<typeof config>) => {
    const nativeWatchDirectory =
      cfg.hostDownloadsPath || cfg.watchDirectory || "";
    const nativeOutputDirectory =
      cfg.hostOutputPath || cfg.outputDirectory || "";
    const nativeSubtitleDirectory = cfg.subtitleDirectory || "";
    form.reset({
      watchDirectory: nativeWatchDirectory,
      outputDirectory: nativeOutputDirectory,
      remuxOutputDirectory: cfg.remuxOutputDirectory || SOURCE_DIRECTORY_VALUE,
      outputNameTemplate: cfg.outputNameTemplate ?? "",
      posterMirrorUrl: cfg.posterMirrorUrl ?? "",
      posterProxyUrl: cfg.posterProxyUrl ?? "",
      handbrakePreset: cfg.handbrakePreset,
      whisperModel: cfg.whisperModel as ConfigInputWhisperModel,
      subtitleLanguage: cfg.subtitleLanguage,
      crf: cfg.crf,
      encoder: cfg.encoder,
      audioCopy: cfg.audioCopy ?? true,
      outputFormat:
        (cfg.outputFormat as ConfigInputOutputFormat) ??
        ConfigInputOutputFormat.mkv,
      subtitleDirectory: nativeSubtitleDirectory,
      hostDownloadsPath: nativeWatchDirectory,
      hostOutputPath: nativeOutputDirectory,
      libreTranslateUrl: cfg.libreTranslateUrl || "",
      processHighPriority: cfg.processHighPriority ?? false,
      shutdownAfterComplete: cfg.shutdownAfterComplete ?? false,
      handbrakeCliPath: cfg.handbrakeCliPath || "",
      subtitleEditCliPath: cfg.subtitleEditCliPath || "",
      // 密钥不再回填：已配置的 Key 只显示“已配置”，留空表示保持不变
      tmdbApiKey: "",
      omdbApiKey: "",
      openaiApiKey: "",
      deepseekApiKey: "",
      siliconflowApiKey: "",
      zhipuApiKey: "",
      moonshotApiKey: "",
      qwenApiKey: "",
      groqApiKey: "",
      geminiApiKey: "",
      aiTranslationEnabled: cfg.aiTranslationEnabled ?? false,
      translationTargetLang: cfg.translationTargetLang || "zh-CN",
      ocrBilingualCorrection: cfg.ocrBilingualCorrection ?? true,
      aiProvider: cfg.aiProvider || "deepseek",
      aiBaseUrl: cfg.aiBaseUrl || "",
      aiModel: cfg.aiModel || "",
      frameRate: cfg.frameRate || "same",
      outputResolution: cfg.outputResolution || "source",
      encoderPreset: cfg.encoderPreset || "slow",
      encoderTune: cfg.encoderTune || "film",
      encoderProfile: cfg.encoderProfile || "high10",
      encoderLevel: cfg.encoderLevel || "4.1",
      uiLanguage: cfg.uiLanguage === "en-US" ? "en-US" : "zh-CN",
      themeMode: cfg.themeMode || "deep-ocean",
      deinterlace: cfg.deinterlace ?? false,
      bilingualLayout:
        cfg.bilingualLayout === "foreign-top" ? "foreign-top" : "zh-top",
      bilingualOutlineWidth:
        typeof cfg.bilingualOutlineWidth === "number"
          ? cfg.bilingualOutlineWidth
          : 0.2,
      bilingualShadowWidth:
        typeof cfg.bilingualShadowWidth === "number"
          ? cfg.bilingualShadowWidth
          : 0,
      bilingualOutlineColor: cfg.bilingualOutlineColor || "&H00404040",
      bilingualFontSizeTop:
        typeof cfg.bilingualFontSizeTop === "number"
          ? cfg.bilingualFontSizeTop
          : 16,
      bilingualFontSizeBottom:
        typeof cfg.bilingualFontSizeBottom === "number"
          ? cfg.bilingualFontSizeBottom
          : 9.6,
    });
  };

  useEffect(() => {
    // Only reset the form on initial load, or when the server acknowledges a save
    // (i.e., the form is clean). Never reset while the user is actively editing.
    if (config && (!hasLoadedRef.current || !form.formState.isDirty)) {
      hasLoadedRef.current = true;
      applyConfigToForm(config);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [config]);

  const onSubmit = async (values: ConfigFormValues) => {
    try {
      const nativeWatchDirectory =
        values.hostDownloadsPath || values.watchDirectory || "";
      const nativeOutputDirectory =
        values.hostOutputPath || values.outputDirectory || "";
      const nativeSubtitleDirectory = values.subtitleDirectory || "";
      const submitValues = {
        ...values,
        watchDirectory: nativeWatchDirectory,
        outputDirectory: nativeOutputDirectory,
        remuxOutputDirectory:
          values.remuxOutputDirectory || SOURCE_DIRECTORY_VALUE,
        outputNameTemplate:
          (values.outputNameTemplate ?? "").trim() || undefined,
        posterMirrorUrl: (values.posterMirrorUrl ?? "").trim() || undefined,
        posterProxyUrl: (values.posterProxyUrl ?? "").trim() || undefined,
        hostDownloadsPath: nativeWatchDirectory,
        hostOutputPath: nativeOutputDirectory,
        subtitleDirectory: nativeSubtitleDirectory,
      };
      await updateConfig.mutateAsync({ data: submitValues });
      saveSucceededRef.current = true;
      // Reset form with the submitted display values to clear dirty state,
      // so that the next config refetch won't overwrite in-progress edits.
      form.reset(submitValues);
      toast({ title: t("settings.saveSuccess") });
      queryClient.invalidateQueries({ queryKey: getGetConfigQueryKey() });
    } catch (e: unknown) {
      saveSucceededRef.current = false;
      toast({
        title: t("settings.saveFailed"),
        description: e instanceof Error ? e.message : t("common.unknownError"),
        variant: "destructive",
      });
    }
  };

  // ── 未保存修改的“保存 / 放弃”守卫 ────────────────────────────────
  const dirty = form.formState.isDirty || tuningDirty;

  const performSave = async (): Promise<boolean> => {
    if (form.formState.isDirty) {
      saveSucceededRef.current = false;
      await form.handleSubmit(onSubmit)();
      if (!saveSucceededRef.current) return false;
    }
    if (tuningDirty) {
      try {
        await saveTuning(tuning);
      } catch {
        return false;
      }
    }
    return true;
  };

  const discardChanges = () => {
    if (config) applyConfigToForm(config);
    setTuningDirty(false);
  };

  const [activePreset, setActivePreset] = useState<string | null>(null);

  // ── Custom presets (localStorage) ────────────────────────────────────────────
  const [customPresets, setCustomPresets] = useState<CustomPreset[]>(() => {
    try {
      return JSON.parse(
        localStorage.getItem(CUSTOM_PRESET_KEY) || "[]",
      ) as CustomPreset[];
    } catch {
      return [];
    }
  });
  const [showSaveForm, setShowSaveForm] = useState(false);
  const [newPresetName, setNewPresetName] = useState("");
  const [archivePresets, setArchivePresets] = useState<ArchivePreset[]>(() =>
    loadCompressionPresets(),
  );
  const [editingPreset, setEditingPreset] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState<ArchivePreset["values"] | null>(
    null,
  );

  const applyArchivePreset = async (preset: ArchivePreset) => {
    const v = preset.values;
    form.setValue("encoder", v.encoder, { shouldDirty: true });
    form.setValue("crf", v.crf, { shouldDirty: true });
    form.setValue("encoderPreset", v.encoderPreset, { shouldDirty: true });
    form.setValue("encoderTune", v.encoderTune, { shouldDirty: true });
    form.setValue("encoderProfile", v.encoderProfile, { shouldDirty: true });
    form.setValue("encoderLevel", v.encoderLevel, { shouldDirty: true });
    form.setValue("frameRate", v.frameRate, { shouldDirty: true });
    if (v.outputResolution)
      form.setValue("outputResolution", v.outputResolution, {
        shouldDirty: true,
      });
    setActivePreset(preset.id);
    await form.handleSubmit(onSubmit)();
  };

  const applyCustomPreset = async (preset: CustomPreset) => {
    const v = preset.values;
    form.setValue("encoder", v.encoder, { shouldDirty: true });
    form.setValue("crf", v.crf, { shouldDirty: true });
    form.setValue("encoderPreset", v.encoderPreset, { shouldDirty: true });
    form.setValue("encoderTune", v.encoderTune, { shouldDirty: true });
    form.setValue("encoderProfile", v.encoderProfile, { shouldDirty: true });
    form.setValue("encoderLevel", v.encoderLevel, { shouldDirty: true });
    form.setValue("frameRate", v.frameRate, { shouldDirty: true });
    if (v.outputResolution)
      form.setValue("outputResolution", v.outputResolution, {
        shouldDirty: true,
      });
    setActivePreset(preset.id);
    await form.handleSubmit(onSubmit)();
  };

  const startEditPreset = (preset: ArchivePreset) => {
    if (editingPreset === preset.id) {
      setEditingPreset(null);
      setEditDraft(null);
      return;
    }
    setEditingPreset(preset.id);
    setEditDraft({ ...preset.values });
  };

  const saveEditedPreset = async () => {
    if (!editingPreset || !editDraft) return;
    const custom = customPresets.find((preset) => preset.id === editingPreset);
    if (custom) {
      const updated = customPresets.map((preset) =>
        preset.id === editingPreset ? { ...preset, values: editDraft } : preset,
      );
      setCustomPresets(updated);
      localStorage.setItem(CUSTOM_PRESET_KEY, JSON.stringify(updated));
      window.dispatchEvent(new Event(PRESET_CHANGED_EVENT));
      setEditingPreset(null);
      setEditDraft(null);
      await applyCustomPreset(
        updated.find((preset) => preset.id === editingPreset) ?? custom,
      );
      return;
    }
    const label = editingPreset;
    const updated = archivePresets.map((p) =>
      p.id === label ? { ...p, values: editDraft } : p,
    );
    setArchivePresets(updated);
    localStorage.setItem(
      ARCHIVE_PRESET_LS_KEY,
      JSON.stringify(updated.map((p) => ({ label: p.id, values: p.values }))),
    );
    window.dispatchEvent(new Event(PRESET_CHANGED_EVENT));
    setEditingPreset(null);
    setEditDraft(null);
    const saved = updated.find((p) => p.id === label);
    if (saved) await applyArchivePreset(saved);
  };

  const resetPresetToDefault = () => {
    if (!editingPreset) return;
    const custom = customPresets.find((preset) => preset.id === editingPreset);
    if (custom) {
      setEditDraft({ ...custom.values });
      return;
    }
    const def = ARCHIVE_PRESETS.find((p) => p.id === editingPreset);
    if (def) {
      setEditDraft({ ...def.values });
      toast({ title: t("settings.filledDefaults") });
    }
  };

  const saveCurrentAsPreset = () => {
    const name = newPresetName.trim();
    if (!name) return;
    const vals = form.getValues();
    const preset: CustomPreset = {
      id: crypto.randomUUID(),
      name,
      values: {
        encoder: vals.encoder ?? "x264_10bit",
        crf: vals.crf ?? 20,
        encoderPreset: vals.encoderPreset ?? "slow",
        encoderTune: vals.encoderTune ?? "film",
        encoderProfile: vals.encoderProfile ?? "high10",
        encoderLevel: vals.encoderLevel ?? "4.1",
        frameRate: vals.frameRate ?? "same",
        outputResolution: vals.outputResolution ?? "source",
      },
    };
    const updated = [...customPresets, preset];
    setCustomPresets(updated);
    localStorage.setItem(CUSTOM_PRESET_KEY, JSON.stringify(updated));
    window.dispatchEvent(new Event(PRESET_CHANGED_EVENT));
    setNewPresetName("");
    setShowSaveForm(false);
    toast({
      title: t("settings.customPresetSaved", { name }),
      description: t("settings.clickToApply"),
    });
  };

  const deleteCustomPreset = (id: string) => {
    const updated = customPresets.filter((p) => p.id !== id);
    setCustomPresets(updated);
    localStorage.setItem(CUSTOM_PRESET_KEY, JSON.stringify(updated));
    window.dispatchEvent(new Event(PRESET_CHANGED_EVENT));
    if (activePreset === id) setActivePreset(null);
  };

  const crfValue = form.watch("crf");
  const aiEnabled = form.watch("aiTranslationEnabled");
  const currentEncoder = form.watch("encoder");
  const isX264Family =
    currentEncoder?.startsWith("x264") || currentEncoder?.startsWith("x265");
  const selectedProvider = form.watch("aiProvider");
  const selectedProviderInfo =
    AI_PROVIDER_LIST.find((p) => p.id === selectedProvider) ??
    AI_PROVIDER_LIST[0];
  const [aiTestState, setAiTestState] = useState<{
    status: "idle" | "testing" | "ok" | "error";
    message: string;
    durationMs?: number;
  }>({ status: "idle", message: "" });
  const [tmdbTestState, setTmdbTestState] = useState<{
    status: "idle" | "testing" | "ok" | "error";
    message: string;
    durationMs?: number;
  }>({ status: "idle", message: "" });
  const [omdbTestState, setOmdbTestState] = useState<{
    status: "idle" | "testing" | "ok" | "error";
    message: string;
    durationMs?: number;
  }>({ status: "idle", message: "" });

  const testCurrentAiConnection = async () => {
    const values = form.getValues();
    const keyField =
      selectedProvider === "custom"
        ? "openaiApiKey"
        : `${selectedProvider}ApiKey`;
    const apiKey = (values as unknown as Record<string, unknown>)[keyField];
    setAiTestState({ status: "testing", message: t("settings.testingAi") });
    try {
      const response = await fetch("/api/runtime/ai/test", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          provider: selectedProvider,
          apiKey:
            typeof apiKey === "string" && apiKey.trim() ? apiKey : undefined,
          model: values.aiModel,
          baseUrl: values.aiBaseUrl,
          libreTranslateUrl: values.libreTranslateUrl,
        }),
      });
      const body = (await response.json().catch(() => ({}))) as {
        message?: string;
        durationMs?: number;
      };
      const message =
        body.message ??
        (response.ok
          ? t("settings.aiConnected")
          : t("settings.aiConnectFailed", { status: response.status }));
      setAiTestState({
        status: response.ok ? "ok" : "error",
        message,
        durationMs: body.durationMs,
      });
    } catch (error) {
      setAiTestState({
        status: "error",
        message: error instanceof Error ? error.message : String(error),
      });
    }
  };

  const testMetadataConnection = async (provider: "tmdb" | "omdb") => {
    const values = form.getValues();
    const key = (values as unknown as Record<string, unknown>)[
      `${provider}ApiKey`
    ];
    const setState = provider === "tmdb" ? setTmdbTestState : setOmdbTestState;
    const providerLabel = provider.toUpperCase();
    setState({
      status: "testing",
      message: t("settings.testingMetadata", { provider: providerLabel }),
    });
    try {
      const response = await fetch("/api/runtime/metadata/test", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          provider,
          apiKey: typeof key === "string" ? key : undefined,
        }),
      });
      const body = (await response.json().catch(() => ({}))) as {
        message?: string;
        durationMs?: number;
      };
      const message =
        body.message ??
        (response.ok
          ? t("settings.metadataConnected", { provider: providerLabel })
          : t("settings.metadataConnectFailed", {
              provider: providerLabel,
              status: response.status,
            }));
      setState({
        status: response.ok ? "ok" : "error",
        message,
        durationMs: body.durationMs,
      });
    } catch (error) {
      setState({
        status: "error",
        message: error instanceof Error ? error.message : String(error),
      });
    }
  };

  const crfLabel =
    crfValue <= 16
      ? t("settings.crfUltra")
      : crfValue <= 20
        ? t("settings.crfCollection")
        : crfValue <= 24
          ? t("settings.crfStorage")
          : t("settings.crfHighCompression");

  const [openSections, setOpenSections] = useState({
    directories: true,
    encoding: true,
    subtitleWhisper: true,
    aiTranslation: true,
    tmdb: false,
    toolPaths: false,
    system: true,
  });
  const [expandedKeyProvider, setExpandedKeyProvider] = useState<string | null>(
    null,
  );
  const [expandedMetadataProvider, setExpandedMetadataProvider] = useState<
    "tmdb" | "omdb" | null
  >(null);
  type SectionKey = keyof typeof openSections;
  const toggle = (k: SectionKey) =>
    setOpenSections((p) => ({ ...p, [k]: !p[k] }));
  const {
    section,
    requestSectionChange,
    leaveTarget,
    resolveLeave,
    clearLeaveRequest,
  } = useSettingsSections({
    dirty,
    save: performSave,
    discard: discardChanges,
  });
  const sectionCopy = SETTINGS_SECTION_TITLES[section];
  const isFormSection =
    section !== "overview" &&
    section !== "tuning" &&
    section !== "tuningPrompts";
  const openSettingsSection = (item: {
    id: Exclude<SettingsSection, "overview">;
  }) => {
    requestSectionChange(item.id);
  };
  return (
    <div
      data-testid="settings-page"
      className={cn("space-y-5", section === "overview" ? "" : "pb-24")}
    >
      {configLoading && (
        <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-secondary/40 border text-sm text-muted-foreground animate-pulse">
          <div className="h-2 w-2 rounded-full bg-primary animate-bounce" />
          {t("settings.loadingConfig")}
        </div>
      )}
      {configError && (
        <div className="px-4 py-3 rounded-lg bg-destructive/10 border border-destructive/30 text-sm text-destructive">
          {t("settings.configLoadFailed")}
        </div>
      )}
      <div
        data-testid="settings-section-strip"
        className={cn(
          "flex items-center gap-3 rounded-xl border bg-secondary/20 px-4 py-3",
          section !== "overview" && "cursor-pointer hover:border-primary/40",
        )}
        role={section !== "overview" ? "button" : undefined}
        tabIndex={section !== "overview" ? 0 : undefined}
        onClick={() => {
          if (section !== "overview") requestSectionChange("overview");
        }}
        onKeyDown={(event) => {
          if (
            section !== "overview" &&
            (event.key === "Enter" || event.key === " ")
          ) {
            event.preventDefault();
            requestSectionChange("overview");
          }
        }}
      >
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Settings2 className="h-4 w-4" />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-medium leading-tight">
            {t(sectionCopy.titleKey)}
          </p>
          <p className="mt-1 truncate text-xs text-muted-foreground">
            {t(sectionCopy.descriptionKey)}
          </p>
        </div>
      </div>

      {section === "overview" && (
        <div
          data-testid="settings-overview-grid"
          className="grid gap-3 md:grid-cols-2 xl:grid-cols-4"
        >
          {settingsOverviewItems.map((item) => {
            const copy = SETTINGS_SECTION_TITLES[item.id];
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => openSettingsSection(item)}
                className="rounded-xl border bg-secondary/15 p-4 text-left transition-colors hover:border-primary/45 hover:bg-primary/5"
              >
                <div className="mb-3 text-2xl">{item.icon}</div>
                <div className="text-sm font-semibold">{t(copy.titleKey)}</div>
                <div className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                  {t(copy.descriptionKey)}
                </div>
              </button>
            );
          })}
        </div>
      )}

      {section === "tools" && <ToolManager />}
      {section === "tuning" && (
        <TuningLogicCard
          tuning={tuning}
          onChange={(next) => {
            setTuning(next);
            setTuningDirty(true);
          }}
          onSave={saveTuning}
        />
      )}
      {section === "tuningPrompts" && (
        <TuningPromptsCard
          tuning={tuning}
          onChange={(next) => {
            setTuning(next);
            setTuningDirty(true);
          }}
          onSave={saveTuning}
        />
      )}
      {isFormSection && (
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="min-w-0 space-y-6"
          >
            {/* 本地目录设置 (Windows) */}
            {section === "directories" && (
              <SettingsDirectoriesSection
                openSections={openSections}
                toggle={toggle}
              />
            )}

            {/* 编码 — 收藏级预设 */}
            {section === "compression" && (
              <SettingsCompressionSection
                openSections={openSections}
                toggle={toggle}
                crfValue={crfValue}
                crfLabel={crfLabel}
                isX264Family={Boolean(isX264Family)}
                startEditPreset={startEditPreset}
                saveEditedPreset={saveEditedPreset}
                resetPresetToDefault={resetPresetToDefault}
                saveCurrentAsPreset={saveCurrentAsPreset}
                deleteCustomPreset={deleteCustomPreset}
                customPresets={customPresets}
                editingPreset={editingPreset}
                setEditingPreset={setEditingPreset}
                editDraft={editDraft}
                setEditDraft={setEditDraft}
                newPresetName={newPresetName}
                setNewPresetName={setNewPresetName}
                showSaveForm={showSaveForm}
                setShowSaveForm={setShowSaveForm}
                archivePresets={archivePresets}
                activePreset={activePreset}
                applyArchivePreset={applyArchivePreset}
                applyCustomPreset={applyCustomPreset}
              />
            )}

            {/* 字幕 & Whisper */}
            {section === "subtitles" && (
              <SettingsSubtitlesSection
                openSections={openSections}
                toggle={toggle}
              />
            )}

            {/* AI 智能翻译 */}
            {section === "ai" && (
              <SettingsAiSection
                openSections={openSections}
                toggle={toggle}
                config={config}
                aiEnabled={Boolean(aiEnabled)}
                selectedProvider={selectedProvider}
                selectedProviderInfo={selectedProviderInfo}
                aiTestState={aiTestState}
                tmdbTestState={tmdbTestState}
                omdbTestState={omdbTestState}
                testCurrentAiConnection={testCurrentAiConnection}
                testMetadataConnection={testMetadataConnection}
                expandedKeyProvider={expandedKeyProvider}
                setExpandedKeyProvider={setExpandedKeyProvider}
                expandedMetadataProvider={expandedMetadataProvider}
                setExpandedMetadataProvider={setExpandedMetadataProvider}
              />
            )}

            {/* 外部工具路径 */}
            {section === "tools" && (
              <SettingsToolsSection
                openSections={openSections}
                toggle={toggle}
              />
            )}

            {/* 系统行为 */}
            {section === "system" && (
              <SettingsSystemSection
                openSections={openSections}
                toggle={toggle}
              />
            )}

            <div className="pointer-events-none sticky bottom-6 z-10 flex justify-end p-0">
              <Button
                type="submit"
                size="lg"
                disabled={updateConfig.isPending}
                className="pointer-events-auto min-w-[160px]"
              >
                {updateConfig.isPending ? (
                  t("settings.saving")
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" /> {t("settings.saveConfig")}
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      )}

      <Dialog
        open={leaveTarget !== null}
        onOpenChange={(open) => {
          if (!open) clearLeaveRequest();
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t("settings.unsavedChangesTitle")}</DialogTitle>
            <DialogDescription>
              {t("settings.unsavedChangesDesc")}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={clearLeaveRequest}>
              {t("settings.cancelLeave")}
            </Button>
            <Button variant="outline" onClick={() => void resolveLeave(false)}>
              {t("settings.discardAndLeave")}
            </Button>
            <Button
              onClick={() => void resolveLeave(true)}
              disabled={updateConfig.isPending}
            >
              {updateConfig.isPending
                ? t("settings.saving")
                : t("settings.saveAndLeave")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
