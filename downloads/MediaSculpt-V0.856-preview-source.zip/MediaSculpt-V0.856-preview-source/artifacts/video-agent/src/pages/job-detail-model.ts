export type MediaStreamInfo = {
  index: number;
  codecType?: string | null;
  codecName?: string | null;
  profile?: string | null;
  description?: string | null;
  language?: string | null;
  title?: string | null;
  channels?: number | null;
  channelLayout?: string | null;
  width?: number | null;
  height?: number | null;
  displayAspectRatio?: string | null;
  sampleAspectRatio?: string | null;
  pixelAspectRatio?: string | null;
  frameRate?: string | null;
  default?: boolean | null;
  forced?: boolean | null;
};

const IMAGE_SUBTITLE_CODECS = new Set([
  "dvd_subtitle",
  "dvdsub",
  "vobsub",
  "hdmv_pgs_subtitle",
  "pgssub",
  "xsub",
]);

export function isImageSubtitleCodec(codecName?: string | null): boolean {
  return (
    Boolean(codecName) && IMAGE_SUBTITLE_CODECS.has(codecName!.toLowerCase())
  );
}

export function streamAspectRatio(
  stream?: MediaStreamInfo,
): string | undefined {
  if (!stream) return undefined;
  const candidate =
    stream.displayAspectRatio ||
    stream.sampleAspectRatio ||
    stream.pixelAspectRatio;
  if (candidate && /^\d+(?::|\/)\d+$/.test(candidate)) {
    const [width, height] = candidate.split(/[:/]/).map(Number);
    if (width > 0 && height > 0) return `${width} / ${height}`;
  }
  if (stream.width && stream.height)
    return `${stream.width} / ${stream.height}`;
  return undefined;
}

function cleanSubtitleText(text: string): string {
  return text
    .replace(/<[^>]+>/g, "")
    .replace(/\{[^}]*\}/g, "")
    .replace(/\\h/g, " ")
    .replace(/\\N/g, "\n")
    .replace(/\\n/g, "\n")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

export function parseSubtitleCues(
  content: string,
): Array<{ start: number; end: number; text: string }> {
  const cues: Array<{ start: number; end: number; text: string }> = [];
  const lines = content.replace(/\r/g, "").split("\n");
  const assTimeRe =
    /^Dialogue:\s*\d+\s*,\s*(\d+):(\d{2}):(\d{2})[.,](\d{1,2})\s*,\s*(\d+):(\d{2}):(\d{2})[.,](\d{1,2})/;
  if (lines.some((line) => assTimeRe.test(line))) {
    for (const line of lines) {
      const match = line.match(assTimeRe);
      if (!match) continue;
      const [h1, m1, s1, c1, h2, m2, s2, c2] = match.slice(1).map(Number);
      const start = h1 * 3600 + m1 * 60 + s1 + c1 / 100;
      const end = h2 * 3600 + m2 * 60 + s2 + c2 / 100;
      const text = cleanSubtitleText(line.split(",").slice(9).join(","));
      if (text) cues.push({ start, end, text });
    }
    return cues;
  }
  const timeRe =
    /(?:(\d{1,2}):)?(\d{1,2}):(\d{2})[,.](\d{1,3})\s*-->\s*(?:(\d{1,2}):)?(\d{1,2}):(\d{2})[,.](\d{1,3})/;
  const toSeconds = (
    hours: number | undefined,
    minutes: number,
    seconds: number,
    milliseconds: number,
  ) => (hours ?? 0) * 3600 + minutes * 60 + seconds + milliseconds / 1000;
  let index = 0;
  while (index < lines.length) {
    const match = lines[index].match(timeRe);
    if (match) {
      const start = toSeconds(
        match[1] !== undefined ? Number(match[1]) : undefined,
        Number(match[2]),
        Number(match[3]),
        Number(match[4].padEnd(3, "0")),
      );
      const end = toSeconds(
        match[5] !== undefined ? Number(match[5]) : undefined,
        Number(match[6]),
        Number(match[7]),
        Number(match[8].padEnd(3, "0")),
      );
      index += 1;
      const textLines: string[] = [];
      while (
        index < lines.length &&
        lines[index].trim() !== "" &&
        !lines[index].includes("-->")
      ) {
        textLines.push(lines[index]);
        index += 1;
      }
      const text = cleanSubtitleText(textLines.join("\n"));
      if (text) cues.push({ start, end, text });
    } else {
      index += 1;
    }
  }
  return cues;
}

import { toHostPath } from "../lib/utils";

export type EmbeddedSubtitleTrack = {
  index: number;
  codecName: string;
  language?: string | null;
  title?: string | null;
};

export type MediaChapterInfo = {
  id: number;
  startSeconds?: number | null;
  endSeconds?: number | null;
  title?: string | null;
};

export type SourceInfo = {
  streams: MediaStreamInfo[];
  chapters: MediaChapterInfo[];
  duration?: number | null;
  formatName?: string | null;
  bitRate?: string | null;
};

export type PathMappingConfig = Parameters<typeof toHostPath>[1];

export type CompressionDisplayConfig = {
  encoder?: string | null;
  crf?: number | null;
  encoderPreset?: string | null;
  outputResolution?: string | null;
};

export function isDiscMedia(mediaType: string | null | undefined) {
  return mediaType === "dvd" || mediaType === "bluray" || mediaType === "iso";
}

export function sourceKind(
  mediaType: string | null | undefined,
  t: (key: string) => string,
) {
  if (mediaType === "dvd") return t("jobDetail.mediaDvd");
  if (mediaType === "bluray") return t("jobDetail.mediaBluray");
  if (mediaType === "iso") return t("jobDetail.mediaIso");
  return t("jobDetail.mediaVideo");
}

export function outputFolderLabel(pathValue: string, config: PathMappingConfig) {
  const hostPath = toHostPath(pathValue, config) || pathValue;
  return hostPath.replace(/[/\\][^/\\]+$/, "");
}

export function streamLanguage(stream: MediaStreamInfo, t: (key: string) => string) {
  return stream.language && stream.language !== "und"
    ? stream.language.toUpperCase()
    : t("jobDetail.unknownLanguage");
}

export function streamCodec(stream: MediaStreamInfo) {
  const codec = (stream.codecName || "unknown").toUpperCase();
  const profile = stream.profile?.trim();
  if (profile) return `${codec} (${profile})`;
  const description = stream.description?.trim();
  if (description) {
    // "Unknown (DTS-HD MA, 5.1 ch)" -> "DTS-HD MA, 5.1 ch"
    const paren = /\(([^)]+)\)$/.exec(description);
    const label = paren ? paren[1] : description;
    return `${codec} (${label})`;
  }
  return codec;
}

export function formatFrameRateLabel(frameRate?: string | null) {
  if (!frameRate) return "--";
  const [num, den] = frameRate.split("/").map(Number);
  if (Number.isFinite(num) && Number.isFinite(den) && den > 0) {
    const value = num / den;
    return value > 0 ? value.toFixed(value % 1 === 0 ? 0 : 3) : frameRate;
  }
  return frameRate;
}

/** 该文件是否可以被浏览器原生解码（无需转码即可直接 Range 播放）。 */
export function isBrowserPlayablePreview(
  filePath: string,
  videoCodec?: string | null,
): boolean {
  const dot = filePath.lastIndexOf(".");
  const ext = dot >= 0 ? filePath.slice(dot).toLowerCase() : "";
  if (![".mp4", ".m4v", ".webm", ".mov"].includes(ext)) return false;
  // HEVC/H.265 在部分 Chromium 下需要额外解码支持，保守起见回退转码
  if (videoCodec && /hevc|h265|hvc1/i.test(videoCodec)) return false;
  return true;
}

