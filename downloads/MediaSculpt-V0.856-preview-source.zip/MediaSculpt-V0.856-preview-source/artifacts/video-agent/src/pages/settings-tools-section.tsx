// Extracted from pages/Settings.tsx: the external tool path settings section.
import {
  useGetConfig,
  getGetConfigQueryKey,
  useUpdateConfig,
  ConfigInputWhisperModel,
  ConfigInputOutputFormat,
} from "@workspace/api-client-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Slider } from "@/components/ui/slider";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useEffect, useState, useRef, useMemo } from "react";
import type { Resolver } from "react-hook-form";
import { useI18n } from "@/i18n";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import {
  Save,
  Settings2,
  ExternalLink,
  Languages,
  Zap,
  Star,
  ChevronDown,
  ChevronUp,
  Cpu,
  FolderSearch,
  Plus,
  Trash2,
  BookmarkCheck,
  Pencil,
  X,
  RefreshCw,
  RotateCcw,
  FileText,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { DirectoryPicker } from "@/components/DirectoryPicker";
import { ImdbDatasetCard } from "@/components/ImdbDatasetCard";
import { TuningLogicCard } from "@/components/TuningLogicCard";
import { TuningPromptsCard } from "@/components/TuningPromptsCard";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  parseCustomTuning,
  serializeCustomTuning,
  type CustomTuning,
} from "@/lib/custom-tuning";
import {
  useSettingsSections,
  type SettingsSection,
} from "@/hooks/useSettingsSections";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  ARCHIVE_PRESETS,
  ARCHIVE_PRESET_LS_KEY,
  CUSTOM_PRESET_KEY,
  PRESET_CHANGED_EVENT,
  loadCompressionPresets,
  ENCODER_OPTIONS,
  type ArchivePreset,
  type CustomPreset,
} from "@/lib/compression-presets";
import { compressionPresetSummary } from "@/features/workbench/compression-preset-model";
import { ToolManager } from "./settings-tool-manager";
import {
  previewOutputName,
  settingsAssColorToHex,
  settingsHexToAssColor,
} from "./settings-model";

import { type ConfigFormValues } from "./settings-model";
import { useFormContext } from "react-hook-form";

type SectionKey =
  | "directories"
  | "encoding"
  | "subtitleWhisper"
  | "aiTranslation"
  | "tmdb"
  | "toolPaths"
  | "system";

type SectionProps = {
  openSections: Record<SectionKey, boolean>;
  toggle: (key: SectionKey) => void;
};

export function SettingsToolsSection({
  openSections,
  toggle,
}: SectionProps) {
  const { t } = useI18n();
  const form = useFormContext<ConfigFormValues>();
  return (
              <Collapsible
                open={openSections.toolPaths}
                onOpenChange={() => toggle("toolPaths")}
              >
                <Card className="border-dashed">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-muted-foreground">
                          {t("settings.externalToolPaths")}
                        </CardTitle>
                        <CardDescription className="mt-1">
                          {t("settings.externalToolPathsDescA")}{" "}
                          <strong>
                            {t("settings.externalToolPathsDescB")}
                          </strong>
                          {t("settings.externalToolPathsDescC")}
                          <br />
                          {t("settings.externalToolPathsHint")}
                        </CardDescription>
                      </div>
                      <CollapsibleTrigger asChild>
                        <button
                          type="button"
                          className="p-1 rounded hover:bg-secondary/60 transition-colors ml-3 shrink-0"
                        >
                          <ChevronDown
                            className={`h-4 w-4 text-muted-foreground transition-transform ${openSections.toolPaths ? "rotate-180" : ""}`}
                          />
                        </button>
                      </CollapsibleTrigger>
                    </div>
                  </CardHeader>
                  <CollapsibleContent>
                    <CardContent className="space-y-6">
                      <div className="grid gap-3 md:grid-cols-2 text-xs">
                        <div className="rounded-lg border border-border bg-secondary/20 p-3 space-y-1.5">
                          <p className="font-semibold text-sm">HandBrakeCLI</p>
                          <p className="text-muted-foreground">
                            {t("settings.handbrakeToolDesc")}
                          </p>
                          <p className="text-muted-foreground">
                            {t("settings.windowsFrom")}{" "}
                            <a
                              href="https://handbrake.fr/downloads2.php"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-primary underline"
                            >
                              handbrake.fr
                            </a>{" "}
                            {t("settings.downloadCliPath")}{" "}
                            <code className="bg-secondary/60 px-1 rounded">
                              C:\Program Files\HandBrake\HandBrakeCLI.exe
                            </code>
                          </p>
                          <p className="text-muted-foreground">
                            {t("settings.handbrakeLinux")}
                          </p>
                        </div>
                        <div className="rounded-lg border border-border bg-secondary/20 p-3 space-y-1.5">
                          <p className="font-semibold text-sm">
                            {t("settings.subtitleEditOptional")}
                          </p>
                          <p className="text-muted-foreground">
                            {t("settings.subtitleEditDesc")}
                          </p>
                          <p className="text-muted-foreground">
                            {t("settings.windowsFrom")}{" "}
                            <a
                              href="https://github.com/SubtitleEdit/subtitleedit/releases"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-primary underline"
                            >
                              GitHub Releases
                            </a>{" "}
                            {t("settings.downloadFindSe")}
                            <code className="bg-secondary/60 px-1 rounded">
                              SubtitleEditCli.exe
                            </code>
                          </p>
                        </div>
                      </div>
                      <div className="grid gap-6 md:grid-cols-2">
                        <FormField
                          control={form.control}
                          name="handbrakeCliPath"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-muted-foreground">
                                {t("settings.handbrakePathLabel")}
                              </FormLabel>
                              <FormControl>
                                <Input
                                  {...field}
                                  className="font-mono bg-secondary/30 text-muted-foreground"
                                  placeholder={t(
                                    "settings.handbrakePathPlaceholder",
                                  )}
                                />
                              </FormControl>
                              <FormDescription>
                                {t("settings.handbrakePathDesc")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="subtitleEditCliPath"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-muted-foreground">
                                {t("settings.subtitleEditPathLabel")}
                              </FormLabel>
                              <FormControl>
                                <Input
                                  {...field}
                                  className="font-mono bg-secondary/30 text-muted-foreground"
                                  placeholder={t(
                                    "settings.subtitleEditPathPlaceholder",
                                  )}
                                />
                              </FormControl>
                              <FormDescription>
                                {t("settings.subtitleEditPathDesc")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>
  );
}
