// Extracted from pages/Settings.tsx: the subtitle & Whisper settings section.
import {
  useGetConfig,
  getGetConfigQueryKey,
  useUpdateConfig,
  ConfigInputWhisperModel,
  ConfigInputOutputFormat,
} from "@workspace/api-client-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Slider } from "@/components/ui/slider";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useEffect, useState, useRef, useMemo } from "react";
import type { Resolver } from "react-hook-form";
import { useI18n } from "@/i18n";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import {
  Save,
  Settings2,
  ExternalLink,
  Languages,
  Zap,
  Star,
  ChevronDown,
  ChevronUp,
  Cpu,
  FolderSearch,
  Plus,
  Trash2,
  BookmarkCheck,
  Pencil,
  X,
  RefreshCw,
  RotateCcw,
  FileText,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { DirectoryPicker } from "@/components/DirectoryPicker";
import { ImdbDatasetCard } from "@/components/ImdbDatasetCard";
import { TuningLogicCard } from "@/components/TuningLogicCard";
import { TuningPromptsCard } from "@/components/TuningPromptsCard";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  parseCustomTuning,
  serializeCustomTuning,
  type CustomTuning,
} from "@/lib/custom-tuning";
import {
  useSettingsSections,
  type SettingsSection,
} from "@/hooks/useSettingsSections";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  ARCHIVE_PRESETS,
  ARCHIVE_PRESET_LS_KEY,
  CUSTOM_PRESET_KEY,
  PRESET_CHANGED_EVENT,
  loadCompressionPresets,
  ENCODER_OPTIONS,
  type ArchivePreset,
  type CustomPreset,
} from "@/lib/compression-presets";
import { compressionPresetSummary } from "@/features/workbench/compression-preset-model";
import { ToolManager } from "./settings-tool-manager";
import {
  previewOutputName,
  settingsAssColorToHex,
  settingsHexToAssColor,
} from "./settings-model";

import {
  type ConfigFormValues,
  WHISPER_MODEL_LABELS,
} from "./settings-model";
import { useFormContext } from "react-hook-form";

type SectionKey =
  | "directories"
  | "encoding"
  | "subtitleWhisper"
  | "aiTranslation"
  | "tmdb"
  | "toolPaths"
  | "system";

type SettingsSubtitlesSectionProps = {
  openSections: Record<SectionKey, boolean>;
  toggle: (key: SectionKey) => void;
};

export function SettingsSubtitlesSection({
  openSections,
  toggle,
}: SettingsSubtitlesSectionProps) {
  const { t } = useI18n();
  const form = useFormContext<ConfigFormValues>();
  return (
              <Collapsible
                open={openSections.subtitleWhisper}
                onOpenChange={() => toggle("subtitleWhisper")}
              >
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>
                          {t("settings.subtitlesCardTitle")}
                        </CardTitle>
                        <CardDescription className="mt-1">
                          {t("settings.subtitlesCardDesc")}
                        </CardDescription>
                      </div>
                      <CollapsibleTrigger asChild>
                        <button
                          type="button"
                          className="p-1 rounded hover:bg-secondary/60 transition-colors ml-3 shrink-0"
                        >
                          <ChevronDown
                            className={`h-4 w-4 text-muted-foreground transition-transform ${openSections.subtitleWhisper ? "rotate-180" : ""}`}
                          />
                        </button>
                      </CollapsibleTrigger>
                    </div>
                  </CardHeader>
                  <CollapsibleContent>
                    <CardContent className="grid gap-6 md:grid-cols-2">
                      <FormField
                        control={form.control}
                        name="whisperModel"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t("settings.whisperModel")}</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger className="font-mono">
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {Object.values(ConfigInputWhisperModel).map(
                                  (val) => (
                                    <SelectItem key={val} value={val}>
                                      {t(WHISPER_MODEL_LABELS[val] ?? val)}
                                    </SelectItem>
                                  ),
                                )}
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              {t("settings.whisperModelDesc")}
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="subtitleLanguage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>
                              {t("settings.audioSourceLang")}
                            </FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger className="font-mono">
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="auto">
                                  {t("settings.whisperLangAuto")}
                                </SelectItem>
                                <SelectItem value="zh">
                                  {t("settings.whisperLangZh")}
                                </SelectItem>
                                <SelectItem value="en">
                                  {t("settings.whisperLangEn")}
                                </SelectItem>
                                <SelectItem value="ja">
                                  {t("settings.whisperLangJa")}
                                </SelectItem>
                                <SelectItem value="ko">
                                  {t("settings.whisperLangKo")}
                                </SelectItem>
                                <SelectItem value="fr">
                                  {t("settings.whisperLangFr")}
                                </SelectItem>
                                <SelectItem value="de">
                                  {t("settings.whisperLangDe")}
                                </SelectItem>
                                <SelectItem value="es">
                                  {t("settings.whisperLangEs")}
                                </SelectItem>
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              {t("settings.whisperSourceLangDesc")}
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="ocrBilingualCorrection"
                        render={({ field }) => (
                          <FormItem className="flex items-center justify-between rounded-lg border p-3">
                            <div className="space-y-0.5">
                              <FormLabel>
                                {t("settings.ocrBilingualCorrection")}
                              </FormLabel>
                              <FormDescription>
                                {t("settings.ocrBilingualCorrectionDesc")}
                              </FormDescription>
                            </div>
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />

                      <div className="md:col-span-2 space-y-3 rounded-lg border border-primary/20 bg-background/40 p-3">
                        <div>
                          <p className="text-sm font-semibold">
                            {t("settings.bilingualTitle")}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {t("settings.bilingualDesc")}
                          </p>
                        </div>
                        <div className="flex flex-wrap items-end gap-x-3 gap-y-1.5">
                          <div className="min-w-[215px] flex-1">
                            <FormField
                              control={form.control}
                              name="bilingualLayout"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>
                                    {t("settings.bilingualLayout")}
                                  </FormLabel>
                                  <div className="flex gap-0.5 pt-0.5">
                                    <button
                                      type="button"
                                      onClick={() => field.onChange("zh-top")}
                                      className={cn(
                                        "h-8 rounded-md border px-2.5 text-xs transition-colors",
                                        field.value === "zh-top"
                                          ? "border-primary bg-primary/10 text-primary"
                                          : "border-border hover:border-primary/50",
                                      )}
                                    >
                                      {t("scan.bilingualZhTop")}
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() =>
                                        field.onChange("foreign-top")
                                      }
                                      className={cn(
                                        "h-8 rounded-md border px-2.5 text-xs transition-colors",
                                        field.value === "foreign-top"
                                          ? "border-primary bg-primary/10 text-primary"
                                          : "border-border hover:border-primary/50",
                                      )}
                                    >
                                      {t("scan.bilingualForeignTop")}
                                    </button>
                                  </div>
                                </FormItem>
                              )}
                            />
                          </div>
                          <div className="min-w-[96px] flex-1">
                            <FormField
                              control={form.control}
                              name="bilingualOutlineWidth"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>
                                    {t("settings.bilingualOutlineWidth")}
                                  </FormLabel>
                                  <FormControl>
                                    <Input
                                      className="w-full"
                                      type="number"
                                      min={0}
                                      max={4}
                                      step={0.1}
                                      value={field.value}
                                      onChange={(event) =>
                                        field.onChange(
                                          Number(event.currentTarget.value),
                                        )
                                      }
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          <div className="min-w-[96px] flex-1">
                            <FormField
                              control={form.control}
                              name="bilingualShadowWidth"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>
                                    {t("settings.bilingualShadowWidth")}
                                  </FormLabel>
                                  <FormControl>
                                    <Input
                                      className="w-full"
                                      type="number"
                                      min={0}
                                      max={4}
                                      step={0.1}
                                      value={field.value}
                                      onChange={(event) =>
                                        field.onChange(
                                          Number(event.currentTarget.value),
                                        )
                                      }
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          <div className="min-w-[96px] flex-1">
                            <FormField
                              control={form.control}
                              name="bilingualFontSizeTop"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>
                                    {t("settings.bilingualFontSizeTop")}
                                  </FormLabel>
                                  <FormControl>
                                    <Input
                                      className="w-full"
                                      type="number"
                                      min={4}
                                      max={48}
                                      step={0.5}
                                      value={field.value}
                                      onChange={(event) =>
                                        field.onChange(
                                          Number(event.currentTarget.value),
                                        )
                                      }
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          <div className="min-w-[96px] flex-1">
                            <FormField
                              control={form.control}
                              name="bilingualFontSizeBottom"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>
                                    {t("settings.bilingualFontSizeBottom")}
                                  </FormLabel>
                                  <FormControl>
                                    <Input
                                      className="w-full"
                                      type="number"
                                      min={4}
                                      max={36}
                                      step={0.5}
                                      value={field.value}
                                      onChange={(event) =>
                                        field.onChange(
                                          Number(event.currentTarget.value),
                                        )
                                      }
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          <div className="min-w-[190px] flex-1">
                            <FormField
                              control={form.control}
                              name="bilingualOutlineColor"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>
                                    {t("settings.bilingualOutlineColor")}
                                  </FormLabel>
                                  <div className="flex w-full items-center gap-1">
                                    <input
                                      type="color"
                                      value={settingsAssColorToHex(field.value)}
                                      onChange={(event) =>
                                        field.onChange(
                                          settingsHexToAssColor(
                                            event.currentTarget.value,
                                          ),
                                        )
                                      }
                                      className="h-8 w-8 shrink-0 cursor-pointer rounded-md border border-border bg-transparent"
                                      aria-label={t(
                                        "settings.bilingualOutlineColor",
                                      )}
                                    />
                                    <FormControl>
                                      <Input
                                        className="w-full min-w-0 font-mono"
                                        value={field.value}
                                        onChange={(event) =>
                                          field.onChange(
                                            event.currentTarget.value,
                                          )
                                        }
                                      />
                                    </FormControl>
                                  </div>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          <div className="flex items-end pb-0.5">
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              className="h-8 w-8 px-0"
                              title={t("scan.bilingualRestoreDefaults")}
                              onClick={() => {
                                form.setValue("bilingualLayout", "zh-top", {
                                  shouldDirty: true,
                                });
                                form.setValue("bilingualOutlineWidth", 0.2, {
                                  shouldDirty: true,
                                });
                                form.setValue("bilingualShadowWidth", 0, {
                                  shouldDirty: true,
                                });
                                form.setValue(
                                  "bilingualOutlineColor",
                                  "&H00404040",
                                  { shouldDirty: true },
                                );
                                form.setValue("bilingualFontSizeTop", 16, {
                                  shouldDirty: true,
                                });
                                form.setValue("bilingualFontSizeBottom", 9.6, {
                                  shouldDirty: true,
                                });
                              }}
                            >
                              <RotateCcw className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>
  );
}
