import { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RefreshCw, ScrollText, Trash2 } from "lucide-react";
import { useI18n } from "@/i18n";
import { cn } from "@/lib/utils";

type SystemLogs = {
  diagnosticsLog: string;
  diagnostics: string;
  files?: Array<{ name: string; content: string }>;
};

type AppVersion = {
  releaseId: string;
  softwareVersion?: string;
};

export default function Logs() {
  const { t, lang } = useI18n();
  const [logs, setLogs] = useState<SystemLogs | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  const [version, setVersion] = useState<AppVersion | null>(null);
  const [activeTab, setActiveTab] = useState("diagnostics");

  const logTabs = logs?.files && logs.files.length > 0
    ? logs.files.map((file) => ({
        name: file.name,
        label: logTabLabel(file.name, t),
        content: file.content,
      }))
    : [];

  const activeLog = logTabs.find((tab) => tab.name === activeTab) ?? logTabs[0];

  const fetchLogs = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/system-logs");
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data: SystemLogs = await res.json();
      setLogs(data);
      setLastRefresh(new Date());
    } catch (e) {
      setError(e instanceof Error ? e.message : t("logs.fetchFailed"));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchLogs(); }, [fetchLogs]);
  useEffect(() => {
    fetch("/api/runtime/version")
      .then((res) => res.ok ? res.json() : null)
      .then((body) => { if (body?.releaseId) setVersion(body); })
      .catch(() => {});
  }, []);

  const hasAnyLog = logs && logs.diagnostics.trim();

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold flex items-center gap-2">
            <ScrollText className="h-5 w-5 text-primary" /> {t("logs.title")}
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {t("logs.desc")}
            {lastRefresh && <span className="ml-2 opacity-60">{t("logs.refreshedAt", { time: lastRefresh.toLocaleTimeString(lang) })}</span>}
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={fetchLogs} disabled={loading}>
          <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${loading ? "animate-spin" : ""}`} />
          {loading ? t("common.loading") : t("logs.refresh")}
        </Button>
      </div>

      {error && (
        <div className="rounded-lg border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          {error}
          <p className="mt-1 text-xs opacity-70">{t("logs.logFilePath")}</p>
        </div>
      )}

      {version && (
        <Card>
          <CardContent className="pt-4 text-sm">
            <div className="font-medium mb-2">{t("logs.softwareVersion")}</div>
            <div className="grid gap-1 text-xs text-muted-foreground">
              <div>{t("logs.versionNumber")}<span className="font-mono text-foreground">{version.softwareVersion ?? "V 0.856"}</span></div>
            </div>
          </CardContent>
        </Card>
      )}

      {!hasAnyLog && !loading && !error && (
        <Card>
          <CardContent className="pt-6 text-center text-sm text-muted-foreground py-12">
            <ScrollText className="h-8 w-8 mx-auto mb-3 opacity-30" />
            <p>{t("logs.noLogFile")}</p>
            <p className="text-xs mt-1 opacity-60">{t("logs.noLogHint")}</p>
          </CardContent>
        </Card>
      )}

      {logs && (
        <div className="grid gap-4">
          {logTabs.length > 0 ? (
            <>
              <div className="flex flex-wrap gap-1.5" data-testid="logs-tabs">
                {logTabs.map((tab) => (
                  <button
                    key={tab.name}
                    type="button"
                    onClick={() => setActiveTab(tab.name)}
                    className={cn(
                      "rounded-lg border px-2.5 py-1 text-xs transition-colors",
                      tab.name === activeLog?.name
                        ? "border-primary/60 bg-primary/15 text-primary"
                        : "border-border/70 text-muted-foreground hover:border-primary/40 hover:text-foreground",
                    )}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
              {activeLog && (
                <LogSection title={activeLog.label} content={activeLog.content} description={logs.diagnosticsLog} />
              )}
            </>
          ) : (
            <LogSection title={t("logs.unifiedLogTitle")} content={logs.diagnostics} description={logs.diagnosticsLog} />
          )}
        </div>
      )}
    </div>
  );
}

function logTabLabel(name: string, t: ReturnType<typeof useI18n>["t"]): string {
  const labels: Record<string, string> = {
    diagnostics: t("logs.tabDiagnostics"),
    "api-service-output.tmp.log": t("logs.tabApi"),
    "web-service-output.tmp.log": t("logs.tabWeb"),
    "desktop-window-output.tmp.log": t("logs.tabDesktop"),
    "job-events.tmp.log": t("logs.tabJobs"),
    "tool-events.tmp.log": t("logs.tabTools"),
  };
  return labels[name] ?? name;
}

function LogSection({ title, content, description }: { title: string; content: string; description?: string }) {
  const { t } = useI18n();
  const trimmed = content.trim();
  const lineCount = trimmed ? trimmed.split("\n").length : 0;

  return (
    <Card>
      <CardHeader className="py-3 pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium">{title}</CardTitle>
          <CardDescription className="text-xs">{description ? `${description} · ` : ""}{t("logs.lineCount", { count: lineCount })}</CardDescription>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        {trimmed ? (
          <pre className="text-xs font-mono bg-secondary/30 rounded p-3 overflow-auto max-h-72 whitespace-pre-wrap break-all leading-relaxed">
            {trimmed}
          </pre>
        ) : (
          <p className="text-xs text-muted-foreground italic flex items-center gap-1.5">
            <Trash2 className="h-3 w-3 opacity-40" /> {t("logs.logEmpty")}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
