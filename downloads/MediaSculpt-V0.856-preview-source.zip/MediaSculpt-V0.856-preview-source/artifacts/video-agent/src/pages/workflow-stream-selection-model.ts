export function allSelectionIds(ids: string[]): string[] {
  return [...ids];
}

export function normalizeSelectionIds(selectedIds: string[], knownIds: string[]): string[] {
  const selected = new Set(selectedIds);
  return knownIds.filter((id) => selected.has(id));
}

export function toggleSelectionId(selectedIds: string[], id: string): string[] {
  const selected = new Set(selectedIds);
  if (selected.has(id)) selected.delete(id);
  else selected.add(id);
  return [...selected];
}
