// 代理状态的展示模型。
//
// 用户最需要一眼看清的一件事是"VPN 到底有没有被识别到"，而这件事无法从能力
// 层级里读出来：层级只说明哪些来源可用。这里把自检报告里的三个代理字段收敛成
// 一个可渲染的状态：手填的配置优先于自动探测，与实际查询走的是同一条路。
export type CapabilityNetwork = {
  /** 用户在设置里填写的代理；为空表示留空、由程序自动探测。 */
  configuredProxyUrl: string | null;
  /** 本机自动探测到的本地代理；null 表示没探测到。 */
  detectedProxyUrl: string | null;
  /** 资料与海报实际使用的代理；null 表示直连。 */
  effectiveProxyUrl: string | null;
};

export type ProxyStatus =
  | { kind: "configured"; url: string }
  | { kind: "detected"; url: string }
  | { kind: "none" };

export function describeProxyStatus(network: CapabilityNetwork | undefined | null): ProxyStatus {
  const effective = network?.effectiveProxyUrl?.trim() || null;
  if (!effective) return { kind: "none" };
  const configured = network?.configuredProxyUrl?.trim() || null;
  return configured === effective
    ? { kind: "configured", url: effective }
    : { kind: "detected", url: effective };
}
