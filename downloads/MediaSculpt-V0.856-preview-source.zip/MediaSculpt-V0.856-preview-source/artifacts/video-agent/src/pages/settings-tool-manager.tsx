import { useEffect, useReducer, useRef, useState } from "react";
import { useI18n } from "@/i18n";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { Loader2, RefreshCw } from "lucide-react";
import {
  attachInstallTask,
  detachInstallTask,
  getInstallTask,
  getInstallTasks,
  subscribeInstallTasks,
} from "@/lib/install-tasks";

type ToolInfo = {
  id: string;
  label: string;
  available: boolean;
  required: boolean;
  sources: string[];
  version?: string | null;
  path?: string | null;
  health?: "ok" | "broken" | "missing";
  modelInfo?: Array<{ name: string; sizeMB: number }> | null;
};

const TOOL_DESC_KEYS: Record<string, string> = {
  ffmpeg: "settings.toolDescFfmpeg",
  ffprobe: "settings.toolDescFfprobe",
  handbrake: "settings.toolDescHandbrake",
  whisper: "settings.toolDescWhisper",
  libretranslate: "settings.toolDescLibretranslate",
  rapidocr: "settings.toolDescRapidocr",
  tesseract: "settings.toolDescTesseract",
};

/** Manages optional local media, OCR, speech and translation runtimes. */
export function ToolManager() {
  const { t } = useI18n();
  const [tools, setTools] = useState<ToolInfo[]>([]);
  const [toolLogPath, setToolLogPath] = useState<string | null>(null);
  const [busyTools, setBusyTools] = useState<Record<string, boolean>>({});
  const [refreshing, setRefreshing] = useState(false);
  const [progress, setProgress] = useState<Record<string, number>>({});
  const [statusText, setStatusText] = useState<Record<string, string>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [whisperModel, setWhisperModel] = useState("medium");
  const [tick, forceTick] = useReducer((value: number) => value + 1, 0);
  const installRequestingRef = useRef(new Set<string>());
  const handledTasksRef = useRef(new Set<string>());

  const isToolBusy = (id: string) => Boolean(busyTools[id]);
  const setToolBusy = (id: string, busy: boolean) => {
    setBusyTools((value) => {
      const next = { ...value };
      if (busy) next[id] = true;
      else delete next[id];
      return next;
    });
  };

  useEffect(() => subscribeInstallTasks(() => forceTick()), []);

  const readError = async (response: Response, fallback: string) => {
    try {
      const body = await response.json();
      return typeof body.error === "string" ? body.error : fallback;
    } catch {
      return fallback;
    }
  };

  const load = async () => {
    setRefreshing(true);
    setErrors((value) => ({ ...value, refresh: "" }));
    try {
      const response = await fetch("/api/runtime/tools");
      if (!response.ok)
        throw new Error(await readError(response, t("settings.refreshFailed")));
      const body = await response.json();
      setTools(body.tools ?? []);
      setToolLogPath(typeof body.logPath === "string" ? body.logPath : null);
      try {
        const activeResponse = await fetch(
          "/api/runtime/tools/installs/active",
        );
        const activeBody = (await activeResponse.json().catch(() => null)) as {
          tasks?: Array<{ id: string; taskId: string }>;
        } | null;
        for (const task of activeBody?.tasks ?? []) {
          if (typeof task.taskId === "string" && typeof task.id === "string")
            attachInstallTask(task.id, task.taskId);
        }
      } catch {
        // 活动任务查询失败不影响工具列表刷新。
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      setErrors((value) => ({ ...value, refresh: message }));
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  useEffect(() => {
    for (const task of getInstallTasks()) {
      if (task.status === "running") continue;
      const key = task.taskId ?? task.id;
      if (handledTasksRef.current.has(key)) continue;
      handledTasksRef.current.add(key);
      if (task.status === "done") {
        setProgress((value) => ({ ...value, [task.id]: 100 }));
        setStatusText((value) => ({
          ...value,
          [task.id]: task.message || t("settings.installSuccess"),
        }));
        void load();
      } else {
        setErrors((value) => ({
          ...value,
          [task.id]: task.message || t("settings.installFailedShort"),
        }));
        setStatusText((value) => ({
          ...value,
          [task.id]: t("settings.installFailed"),
        }));
      }
      window.setTimeout(() => detachInstallTask(task.id), 4000);
    }
  }, [tick, t, load]);

  const install = async (tool: ToolInfo) => {
    const canInstallWithoutSource =
      tool.id === "libretranslate" ||
      tool.id === "rapidocr" ||
      tool.id === "whisper";
    const installSources: Array<string | null> = tool.sources.length
      ? tool.sources
      : canInstallWithoutSource
        ? [null]
        : [];
    if (installSources.length === 0) {
      setErrors((value) => ({
        ...value,
        [tool.id]: t("settings.noInstallSource"),
      }));
      return;
    }
    if (
      getInstallTask(tool.id)?.status === "running" ||
      installRequestingRef.current.has(tool.id)
    )
      return;
    installRequestingRef.current.add(tool.id);
    setToolBusy(tool.id, true);
    setProgress((value) => ({ ...value, [tool.id]: 10 }));
    setStatusText((value) => ({
      ...value,
      [tool.id]: t("settings.installingRequest"),
    }));
    setErrors((value) => ({ ...value, [tool.id]: "" }));
    try {
      setProgress((value) => ({ ...value, [tool.id]: 25 }));
      setStatusText((value) => ({
        ...value,
        [tool.id]: t("settings.probingSources"),
      }));
      const response = await fetch(`/api/runtime/tools/${tool.id}/install`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({}),
      });
      if (response.status === 409) {
        const message = await readError(
          response,
          t("settings.installInProgress"),
        );
        setStatusText((value) => ({ ...value, [tool.id]: message }));
        window.setTimeout(() => void load(), 2500);
        return;
      }
      if (!response.ok)
        throw new Error(
          await readError(response, t("settings.installFailedShort")),
        );
      const body = await response.json();
      if (typeof body.logPath === "string") setToolLogPath(body.logPath);
      if (typeof body.taskId !== "string")
        throw new Error(t("settings.installFailedShort"));
      attachInstallTask(tool.id, body.taskId);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      setErrors((value) => ({ ...value, [tool.id]: message }));
      setStatusText((value) => ({
        ...value,
        [tool.id]: t("settings.installFailed"),
      }));
    } finally {
      setToolBusy(tool.id, false);
      installRequestingRef.current.delete(tool.id);
    }
  };

  const setupWhisper = async () => {
    if (getInstallTask("whisper")?.status === "running") return;
    setToolBusy("whisper", true);
    setErrors((value) => ({ ...value, whisper: "" }));
    try {
      const response = await fetch("/api/runtime/whisper/setup-model", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ model: whisperModel }),
      });
      if (!response.ok)
        throw new Error(
          await readError(response, t("settings.whisperSetupFailed")),
        );
      const body = (await response.json().catch(() => null)) as {
        taskId?: string;
        logPath?: string;
      } | null;
      if (typeof body?.logPath === "string") setToolLogPath(body.logPath);
      if (typeof body?.taskId !== "string")
        throw new Error(t("settings.installFailedShort"));
      attachInstallTask("whisper", body.taskId);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      setErrors((value) => ({ ...value, whisper: message }));
    } finally {
      setToolBusy("whisper", false);
    }
  };

  return (
    <Card className="border-primary/20">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>{t("settings.toolsCardTitle")}</CardTitle>
            <CardDescription>{t("settings.toolsCardDesc")}</CardDescription>
          </div>
          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={refreshing}
            onClick={() => void load()}
          >
            <RefreshCw
              className={cn("mr-1.5 h-3.5 w-3.5", refreshing && "animate-spin")}
            />
            {refreshing
              ? t("settings.refreshing")
              : t("settings.refreshStatus")}
          </Button>
        </div>
        {toolLogPath && (
          <p className="mt-2 break-all text-xs text-muted-foreground">
            {t("settings.diagnosticsLogLabel")}
            {toolLogPath}
          </p>
        )}
        {errors.refresh && (
          <p className="mt-2 break-all text-xs text-destructive">
            {errors.refresh}
          </p>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        {tools.map((tool) => {
          const canInstallWithoutSource = tool.id === "libretranslate";
          const canAutoInstall =
            tool.sources.length > 0 || canInstallWithoutSource;
          const health = tool.health ?? (tool.available ? "ok" : "missing");
          const healthLabel =
            health === "broken"
              ? t("settings.toolBroken")
              : health === "missing"
                ? t("settings.missing")
                : t("settings.installed");
          const task = getInstallTask(tool.id);
          const busy = task?.status === "running" || isToolBusy(tool.id);
          const statusLine = task?.message || statusText[tool.id];
          const venvTool =
            tool.id === "whisper" ||
            tool.id === "rapidocr" ||
            tool.id === "libretranslate";
          const displayPath = (() => {
            if (!tool.path) return null;
            if (venvTool) {
              const venvIndex = tool.path.indexOf("venv");
              if (venvIndex >= 0) return tool.path.slice(0, venvIndex + 4);
              const envIndex = tool.path.indexOf("-env");
              if (envIndex >= 0) return tool.path.slice(0, envIndex + 4);
            }
            return tool.path;
          })();
          return (
            <div
              key={tool.id}
              className="flex items-start gap-3 rounded-lg border p-3"
            >
              <div className="flex-1">
                <div className="font-medium">
                  {tool.label}{" "}
                  {tool.required && (
                    <Badge variant="secondary">{t("common.required")}</Badge>
                  )}
                </div>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  {t(TOOL_DESC_KEYS[tool.id] ?? "settings.toolsCardDesc")}
                </p>
                <div
                  className={cn(
                    "text-xs",
                    health === "broken"
                      ? "text-destructive"
                      : "text-muted-foreground",
                  )}
                >
                  {healthLabel}
                  {health === "ok" && tool.version && (
                    <span className="ml-2 font-mono opacity-70">
                      {tool.version}
                    </span>
                  )}
                </div>
                {displayPath && (
                  <div className="mt-1 break-all text-[11px] text-muted-foreground/80">
                    {t("settings.pathLabel")}
                    <span className="font-mono">{displayPath}</span>
                  </div>
                )}
                {busy && task?.progress == null && (
                  <div className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    <span>{task?.message || t("settings.installingWait")}</span>
                  </div>
                )}
                {task?.progress != null && (
                  <Progress value={task.progress ?? 0} className="mt-2" />
                )}
                {!task &&
                  (isToolBusy(tool.id) || progress[tool.id] === 100) &&
                  progress[tool.id] != null && (
                    <Progress value={progress[tool.id] ?? 0} className="mt-2" />
                  )}
                {statusLine && (
                  <p className="mt-2 break-all text-xs text-muted-foreground">
                    {statusLine}
                  </p>
                )}
                {errors[tool.id] && (
                  <p className="mt-2 break-all text-xs text-destructive">
                    {errors[tool.id]}
                  </p>
                )}
              </div>
              {tool.id === "whisper" ? (
                <div className="flex flex-col items-end gap-1">
                  <div className="flex items-center gap-2">
                    <Select
                      value={whisperModel}
                      onValueChange={setWhisperModel}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {["tiny", "base", "small", "medium", "large"].map(
                          (model) => (
                            <SelectItem key={model} value={model}>
                              {model}
                            </SelectItem>
                          ),
                        )}
                      </SelectContent>
                    </Select>
                    <Button
                      type="button"
                      disabled={busy}
                      onClick={() => void setupWhisper()}
                    >
                      {busy
                        ? t("settings.working")
                        : health === "broken"
                          ? t("settings.toolRepair")
                          : t("settings.installUpdate", {
                              model: whisperModel,
                            })}
                    </Button>
                  </div>
                  {(() => {
                    const info = tool.modelInfo?.find(
                      (model) => model.name === whisperModel,
                    );
                    if (!info)
                      return (
                        <span className="text-[10px] text-muted-foreground/70">
                          {t("settings.whisperModelNotDownloaded")}
                        </span>
                      );
                    const size =
                      info.sizeMB > 1024
                        ? `${(info.sizeMB / 1024).toFixed(1)} GB`
                        : `${info.sizeMB} MB`;
                    return (
                      <span className="text-[10px] text-muted-foreground">
                        {t("settings.whisperModelLabel")}
                        {info.name} · {size}
                      </span>
                    );
                  })()}
                </div>
              ) : (
                <Button
                  type="button"
                  variant={health === "ok" ? "outline" : "default"}
                  disabled={busy || !canAutoInstall}
                  onClick={() => void install(tool)}
                >
                  {busy
                    ? t("settings.working")
                    : health === "broken"
                      ? t("settings.toolRepair")
                      : health === "ok"
                        ? t("settings.reinstall")
                        : t("settings.install")}
                </Button>
              )}
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
