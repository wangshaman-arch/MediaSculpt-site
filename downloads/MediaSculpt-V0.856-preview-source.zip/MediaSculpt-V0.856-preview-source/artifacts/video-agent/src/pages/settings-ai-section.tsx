// Extracted from pages/Settings.tsx: the AI translation / metadata settings section.
import {
  useGetConfig,
  getGetConfigQueryKey,
  useUpdateConfig,
  ConfigInputWhisperModel,
  ConfigInputOutputFormat,
} from "@workspace/api-client-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Slider } from "@/components/ui/slider";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useEffect, useState, useRef, useMemo } from "react";
import type { Resolver } from "react-hook-form";
import { MetadataCapabilityPanel } from "./metadata-capability-panel";
import { useI18n } from "@/i18n";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import {
  Save,
  Settings2,
  ExternalLink,
  Languages,
  Zap,
  Star,
  ChevronDown,
  ChevronUp,
  Cpu,
  FolderSearch,
  Plus,
  Trash2,
  BookmarkCheck,
  Pencil,
  X,
  RefreshCw,
  RotateCcw,
  FileText,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { DirectoryPicker } from "@/components/DirectoryPicker";
import { ImdbDatasetCard } from "@/components/ImdbDatasetCard";
import { TuningLogicCard } from "@/components/TuningLogicCard";
import { TuningPromptsCard } from "@/components/TuningPromptsCard";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  parseCustomTuning,
  serializeCustomTuning,
  type CustomTuning,
} from "@/lib/custom-tuning";
import {
  useSettingsSections,
  type SettingsSection,
} from "@/hooks/useSettingsSections";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  ARCHIVE_PRESETS,
  ARCHIVE_PRESET_LS_KEY,
  CUSTOM_PRESET_KEY,
  PRESET_CHANGED_EVENT,
  loadCompressionPresets,
  ENCODER_OPTIONS,
  type ArchivePreset,
  type CustomPreset,
} from "@/lib/compression-presets";
import { compressionPresetSummary } from "@/features/workbench/compression-preset-model";
import { ToolManager } from "./settings-tool-manager";
import {
  previewOutputName,
  settingsAssColorToHex,
  settingsHexToAssColor,
} from "./settings-model";

import {
  type ConfigFormValues,
  type AiProviderInfo,
  AI_PROVIDER_LIST,
  KEYED_PROVIDERS,
  TRANSLATION_LANGS,
} from "./settings-model";
import { useFormContext } from "react-hook-form";
import type { Dispatch, SetStateAction } from "react";

type SectionKey =
  | "directories"
  | "encoding"
  | "subtitleWhisper"
  | "aiTranslation"
  | "tmdb"
  | "toolPaths"
  | "system";

type AiTestState = {
  status: "idle" | "testing" | "ok" | "error";
  message: string;
  durationMs?: number;
};

type SettingsAiSectionProps = {
  openSections: Record<SectionKey, boolean>;
  toggle: (key: SectionKey) => void;
  config: unknown;
  aiEnabled: boolean;
  selectedProvider: string | undefined;
  selectedProviderInfo: AiProviderInfo;
  aiTestState: AiTestState;
  tmdbTestState: AiTestState;
  omdbTestState: AiTestState;
  testCurrentAiConnection: () => Promise<void>;
  testMetadataConnection: (provider: "tmdb" | "omdb") => Promise<void>;
  expandedKeyProvider: string | null;
  setExpandedKeyProvider: Dispatch<SetStateAction<string | null>>;
  expandedMetadataProvider: "tmdb" | "omdb" | null;
  setExpandedMetadataProvider: Dispatch<SetStateAction<"tmdb" | "omdb" | null>>;
};

export function SettingsAiSection({
  openSections,
  toggle,
  config,
  aiEnabled,
  selectedProvider,
  selectedProviderInfo,
  aiTestState,
  tmdbTestState,
  omdbTestState,
  testCurrentAiConnection,
  testMetadataConnection,
  expandedKeyProvider,
  setExpandedKeyProvider,
  expandedMetadataProvider,
  setExpandedMetadataProvider,
}: SettingsAiSectionProps) {
  const { t } = useI18n();
  const form = useFormContext<ConfigFormValues>();
  return (
    <>
              <Collapsible
                open={openSections.aiTranslation}
                onOpenChange={() => toggle("aiTranslation")}
              >
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <Languages className="h-5 w-5 text-primary" />{" "}
                          {t("settings.aiCardTitle")}
                        </CardTitle>
                        <CardDescription className="mt-1">
                          {t("settings.aiIntro")}
                        </CardDescription>
                      </div>
                      <CollapsibleTrigger asChild>
                        <button
                          type="button"
                          className="p-1 rounded hover:bg-secondary/60 transition-colors ml-3 shrink-0"
                        >
                          <ChevronDown
                            className={`h-4 w-4 text-muted-foreground transition-transform ${openSections.aiTranslation ? "rotate-180" : ""}`}
                          />
                        </button>
                      </CollapsibleTrigger>
                    </div>
                  </CardHeader>
                  <CollapsibleContent>
                    <CardContent className="space-y-5">
                      {/* Provider selector */}
                      <FormField
                        control={form.control}
                        name="aiProvider"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t("settings.aiProvider")}</FormLabel>
                            <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mt-1">
                              {AI_PROVIDER_LIST.map((p) => (
                                <button
                                  key={p.id}
                                  type="button"
                                  onClick={() => field.onChange(p.id)}
                                  className={`flex flex-col items-start gap-1 rounded-lg border p-2.5 text-left transition-all ${
                                    field.value === p.id
                                      ? "border-primary bg-primary/10 ring-1 ring-primary"
                                      : "border-border bg-secondary/20 hover:border-primary/40 hover:bg-primary/5"
                                  }`}
                                >
                                  <div className="flex items-center gap-1.5 w-full">
                                    <span className="text-base leading-none">
                                      {p.icon}
                                    </span>
                                    <span className="text-xs font-semibold truncate">
                                      {t(p.labelKey)}
                                    </span>
                                  </div>
                                  <p className="text-[10px] text-muted-foreground leading-tight">
                                    {t(p.taglineKey)}
                                  </p>
                                  <Badge
                                    variant={
                                      p.freeNoteKey === "settings.aiPaid"
                                        ? "secondary"
                                        : "outline"
                                    }
                                    className={`text-[9px] px-1.5 py-0 ${p.freeNoteKey !== "settings.aiPaid" ? "border-green-500/40 text-green-400" : ""}`}
                                  >
                                    {t(p.freeNoteKey)}
                                  </Badge>
                                </button>
                              ))}
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* API Keys — 芯片默认收起，点击哪个展开哪个 */}
                      <div className="space-y-1">
                        <p className="text-sm font-medium leading-none">
                          {t("settings.apiKeys")}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {t("settings.apiKeysCollapsedHint")}
                        </p>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {KEYED_PROVIDERS.map((entry) => {
                          const p = AI_PROVIDER_LIST.find(
                            (x) => x.id === entry.id,
                          )!;
                          const isActive = selectedProvider === entry.id;
                          const isExpanded = expandedKeyProvider === entry.id;
                          const hasKey = Boolean(
                            (config as unknown as Record<string, unknown>)?.[
                              entry.fieldName
                            ],
                          );
                          return (
                            <button
                              key={entry.id}
                              type="button"
                              onClick={() =>
                                setExpandedKeyProvider(
                                  isExpanded ? null : entry.id,
                                )
                              }
                              className={cn(
                                "inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs transition-colors",
                                isExpanded
                                  ? "border-primary/60 bg-primary/10 text-primary"
                                  : isActive
                                    ? "border-primary/40 bg-secondary/30 text-foreground hover:border-primary/60"
                                    : "border-border bg-secondary/10 text-muted-foreground hover:border-primary/40 hover:text-foreground",
                              )}
                            >
                              <span className="text-sm leading-none">
                                {p.icon}
                              </span>
                              <span className="font-medium">
                                {t(p.labelKey)}
                              </span>
                              {hasKey && (
                                <span
                                  className="h-1.5 w-1.5 rounded-full bg-emerald-400"
                                  title={t("settings.apiKeyConfigured")}
                                />
                              )}
                              {isActive && (
                                <Badge
                                  variant="secondary"
                                  className="text-[9px] font-normal"
                                >
                                  {t("settings.current")}
                                </Badge>
                              )}
                            </button>
                          );
                        })}
                      </div>
                      {expandedKeyProvider &&
                        (() => {
                          const entry = KEYED_PROVIDERS.find(
                            (item) => item.id === expandedKeyProvider,
                          );
                          if (!entry) return null;
                          const p = AI_PROVIDER_LIST.find(
                            (item) => item.id === entry.id,
                          )!;
                          const configured = Boolean(
                            (config as unknown as Record<string, unknown>)?.[
                              entry.fieldName
                            ],
                          );
                          return (
                            <FormField
                              key={entry.id}
                              control={form.control}
                              name={entry.fieldName}
                              render={({ field }) => (
                                <FormItem className="rounded-lg border border-primary/40 bg-primary/5 px-3 py-2">
                                  <div className="flex items-center gap-2">
                                    <span className="text-base w-6 text-center shrink-0">
                                      {p.icon}
                                    </span>
                                    <span className="flex w-20 shrink-0 items-center gap-1">
                                      <span className="text-xs font-semibold text-primary">
                                        {t(p.labelKey)}
                                      </span>
                                      {configured && (
                                        <Badge
                                          variant="secondary"
                                          className="text-[9px] font-normal"
                                        >
                                          {t("settings.apiKeyConfigured")}
                                        </Badge>
                                      )}
                                    </span>
                                    <FormControl>
                                      <Input
                                        {...field}
                                        type="password"
                                        className="font-mono text-xs bg-transparent border-0 shadow-none h-7 focus-visible:ring-0 flex-1 placeholder:text-muted-foreground/40"
                                        placeholder={
                                          configured
                                            ? t(
                                                "settings.apiKeyKeepPlaceholder",
                                              )
                                            : p.registerUrl
                                              ? `${t(p.labelKey)} API Key`
                                              : "API Key"
                                        }
                                      />
                                    </FormControl>
                                    {p.registerUrl && (
                                      <a
                                        href={p.registerUrl}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="shrink-0 text-[10px] text-muted-foreground hover:text-primary flex items-center gap-0.5 whitespace-nowrap"
                                      >
                                        {t("settings.get")}{" "}
                                        <ExternalLink className="h-2.5 w-2.5" />
                                      </a>
                                    )}
                                  </div>
                                  <FormMessage className="ml-8 text-xs" />
                                </FormItem>
                              )}
                            />
                          );
                        })()}
                      <p className="text-[11px] text-muted-foreground/80">
                        {t("settings.apiKeysCustomHint")}
                      </p>

                      {/* LibreTranslate URL field */}
                      {selectedProvider === "libretranslate" && (
                        <div className="pl-1 border-l-2 border-primary/30">
                          <FormField
                            control={form.control}
                            name="libreTranslateUrl"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>
                                  {t("settings.libreTranslateUrl")}
                                </FormLabel>
                                <FormControl>
                                  <Input
                                    {...field}
                                    className="font-mono bg-secondary/30"
                                    placeholder="http://libretranslate:5000"
                                  />
                                </FormControl>
                                <FormDescription>
                                  {t("settings.libreTranslateDesc")}
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      )}

                      {/* Custom provider fields */}
                      {selectedProvider === "custom" && (
                        <div className="grid gap-4 md:grid-cols-2 pl-1 border-l-2 border-primary/30">
                          <FormField
                            control={form.control}
                            name="aiBaseUrl"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>API Base URL</FormLabel>
                                <FormControl>
                                  <Input
                                    {...field}
                                    className="font-mono bg-secondary/30"
                                    placeholder="https://api.example.com/v1"
                                  />
                                </FormControl>
                                <FormDescription>
                                  {t("settings.aiBaseUrlDesc")}
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="aiModel"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>{t("settings.aiModel")}</FormLabel>
                                <FormControl>
                                  <Input
                                    {...field}
                                    className="font-mono bg-secondary/30"
                                    placeholder="gpt-4o-mini"
                                  />
                                </FormControl>
                                <FormDescription>
                                  {t("settings.aiModelExamples")}
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      )}

                      {/* Model override (non-custom providers) */}
                      {selectedProvider !== "custom" && (
                        <FormField
                          control={form.control}
                          name="aiModel"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-muted-foreground">
                                {t("settings.modelOverride")}
                              </FormLabel>
                              <FormControl>
                                <Input
                                  {...field}
                                  className="font-mono bg-secondary/30 text-muted-foreground"
                                  placeholder={t(
                                    "settings.modelOverridePlaceholder",
                                    {
                                      model: selectedProviderInfo.defaultModel,
                                    },
                                  )}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}

                      <div className="flex flex-wrap items-center gap-3 rounded-lg border border-primary/20 bg-primary/5 p-3">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => void testCurrentAiConnection()}
                          disabled={aiTestState.status === "testing"}
                        >
                          {aiTestState.status === "testing" ? (
                            <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                          ) : (
                            <Zap className="mr-2 h-4 w-4" />
                          )}
                          {t("settings.testCurrentAi")}
                        </Button>
                        <span
                          className={cn(
                            "text-xs",
                            aiTestState.status === "ok"
                              ? "text-emerald-400"
                              : aiTestState.status === "error"
                                ? "text-destructive"
                                : "text-muted-foreground",
                          )}
                        >
                          {aiTestState.message || t("settings.aiTestHint")}
                          {aiTestState.durationMs
                            ? t("settings.testDuration", {
                                ms: aiTestState.durationMs,
                              })
                            : ""}
                        </span>
                      </div>

                      <FormField
                        control={form.control}
                        name="aiTranslationEnabled"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4 bg-secondary/10">
                            <div className="space-y-0.5">
                              <FormLabel className="text-base">
                                {t("settings.enableAiTranslation")}
                              </FormLabel>
                              <FormDescription>
                                {t("settings.enableAiTranslationDesc")}
                              </FormDescription>
                            </div>
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />

                      {/* Off by default: an LLM can fill fields no source
                          reaches, but it can also invent them, so this is an
                          explicit opt-in and every filled field is marked as
                          AI-sourced. */}
                      <FormField
                        control={form.control}
                        name="aiMetadataEnrichment"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4 bg-secondary/10">
                            <div className="space-y-0.5">
                              <FormLabel className="text-base">
                                {t("settings.aiMetadataEnrichment")}
                              </FormLabel>
                              <FormDescription>
                                {t("settings.aiMetadataEnrichmentDesc")}
                              </FormDescription>
                            </div>
                            <FormControl>
                              <Switch
                                checked={field.value === true}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />

                      {aiEnabled && (
                        <FormField
                          control={form.control}
                          name="translationTargetLang"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                {t("settings.translationTargetLang")}
                              </FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger className="font-mono">
                                    <SelectValue />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {TRANSLATION_LANGS.map((l) => (
                                    <SelectItem key={l.value} value={l.value}>
                                      {t(l.labelKey)}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                {t("settings.translationTargetLangDesc")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>

              <Collapsible
                open={openSections.tmdb}
                onOpenChange={() => toggle("tmdb")}
              >
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>{t("settings.metadataCardTitle")}</CardTitle>
                        <CardDescription className="mt-1 flex items-center gap-1">
                          {t("settings.metadataIntro")}
                          <a
                            href="https://www.themoviedb.org/settings/api"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-primary hover:underline ml-1"
                          >
                            {t("settings.freeRegisterGetKey")}{" "}
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        </CardDescription>
                      </div>
                      <CollapsibleTrigger asChild>
                        <button
                          type="button"
                          className="p-1 rounded hover:bg-secondary/60 transition-colors ml-3 shrink-0"
                        >
                          <ChevronDown
                            className={`h-4 w-4 text-muted-foreground transition-transform ${openSections.tmdb ? "rotate-180" : ""}`}
                          />
                        </button>
                      </CollapsibleTrigger>
                    </div>
                  </CardHeader>
                  <CollapsibleContent>
                    <CardContent>
                      <div className="space-y-4">
      <MetadataCapabilityPanel />
                        <p className="text-xs text-muted-foreground">
                          {t("settings.metadataKeysHint")}
                        </p>
                        <div className="space-y-2">
                          {[
                            {
                              id: "tmdb" as const,
                              registerUrl:
                                "https://www.themoviedb.org/settings/api",
                            },
                            {
                              id: "omdb" as const,
                              registerUrl:
                                "https://www.omdbapi.com/apikey.aspx",
                            },
                          ].map(({ id, registerUrl }) => {
                            const isExpanded = expandedMetadataProvider === id;
                            const fieldName =
                              id === "tmdb" ? "tmdbApiKey" : "omdbApiKey";
                            const testState =
                              id === "tmdb" ? tmdbTestState : omdbTestState;
                            const hasKey = Boolean(
                              (config as unknown as Record<string, unknown>)?.[
                                fieldName
                              ],
                            );
                            return (
                              <div
                                key={id}
                                className={cn(
                                  "rounded-lg border transition-colors",
                                  isExpanded
                                    ? "border-primary/40 bg-primary/5"
                                    : "border-border bg-secondary/10",
                                )}
                              >
                                <button
                                  type="button"
                                  onClick={() =>
                                    setExpandedMetadataProvider(
                                      isExpanded ? null : id,
                                    )
                                  }
                                  className="flex w-full items-center gap-2 px-3 py-2 transition-colors hover:bg-secondary/20"
                                >
                                  <span className="text-xs font-semibold w-24 shrink-0">
                                    {id === "tmdb" ? "TMDb" : "OMDb"} API Key
                                  </span>
                                  {hasKey && (
                                    <span
                                      className="h-1.5 w-1.5 rounded-full bg-emerald-400"
                                      title={t("settings.apiKeyConfigured")}
                                    />
                                  )}
                                  <span className="ml-auto text-muted-foreground">
                                    {isExpanded ? (
                                      <ChevronUp className="h-3.5 w-3.5" />
                                    ) : (
                                      <ChevronDown className="h-3.5 w-3.5" />
                                    )}
                                  </span>
                                </button>
                                {isExpanded && (
                                  <div className="space-y-2 border-t px-3 py-2">
                                    <FormField
                                      control={form.control}
                                      name={fieldName}
                                      render={({ field }) => (
                                        <FormItem>
                                          <FormControl>
                                            <Input
                                              {...field}
                                              type="password"
                                              className="font-mono bg-background/60"
                                              placeholder={
                                                hasKey
                                                  ? t(
                                                      "settings.apiKeyKeepPlaceholder",
                                                    )
                                                  : id === "tmdb"
                                                    ? t(
                                                        "settings.tmdbPlaceholder",
                                                      )
                                                    : t(
                                                        "settings.omdbPlaceholder",
                                                      )
                                              }
                                            />
                                          </FormControl>
                                          <FormDescription>
                                            {id === "tmdb"
                                              ? t("settings.tmdbDesc")
                                              : t("settings.omdbDesc")}
                                            <a
                                              href={registerUrl}
                                              target="_blank"
                                              rel="noopener noreferrer"
                                              className="inline-flex items-center gap-1 text-primary hover:underline ml-1"
                                            >
                                              {id === "tmdb"
                                                ? t("settings.freeRegister")
                                                : t("settings.freeApply")}{" "}
                                              <ExternalLink className="h-3 w-3" />
                                            </a>
                                          </FormDescription>
                                          <FormMessage />
                                        </FormItem>
                                      )}
                                    />
                                    <div className="flex items-center gap-2">
                                      <Button
                                        type="button"
                                        variant="outline"
                                        size="sm"
                                        onClick={() =>
                                          void testMetadataConnection(id)
                                        }
                                        disabled={
                                          testState.status === "testing"
                                        }
                                      >
                                        {testState.status === "testing" ? (
                                          <RefreshCw className="mr-1.5 h-3.5 w-3.5 animate-spin" />
                                        ) : (
                                          <Zap className="mr-1.5 h-3.5 w-3.5" />
                                        )}
                                        {t("settings.metadataTest", {
                                          provider:
                                            id === "tmdb" ? "TMDb" : "OMDb",
                                        })}
                                      </Button>
                                      <span
                                        className={cn(
                                          "text-xs",
                                          testState.status === "ok"
                                            ? "text-emerald-400"
                                            : testState.status === "error"
                                              ? "text-destructive"
                                              : "text-muted-foreground",
                                        )}
                                      >
                                        {testState.message ||
                                          t("settings.metadataTestHint")}
                                        {testState.durationMs
                                          ? t("settings.testDuration", {
                                              ms: testState.durationMs,
                                            })
                                          : ""}
                                      </span>
                                    </div>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                        <FormField
                          control={form.control}
                          name="posterMirrorUrl"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                {t("settings.posterMirrorLabel")}
                              </FormLabel>
                              <FormControl>
                                <Input
                                  {...field}
                                  value={field.value ?? ""}
                                  className="font-mono bg-secondary/30"
                                  placeholder="https://image.tmdb.org/t/p/original"
                                />
                              </FormControl>
                              <FormDescription>
                                {t("settings.posterMirrorDesc")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="posterProxyUrl"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                {t("settings.posterProxyLabel")}
                              </FormLabel>
                              <FormControl>
                                <Input
                                  {...field}
                                  value={field.value ?? ""}
                                  className="font-mono bg-secondary/30"
                                  placeholder="http://127.0.0.1:10809"
                                />
                              </FormControl>
                              <FormDescription>
                                {t("settings.posterProxyDesc")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <ImdbDatasetCard />
                      </div>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>
    </>
  );
}
