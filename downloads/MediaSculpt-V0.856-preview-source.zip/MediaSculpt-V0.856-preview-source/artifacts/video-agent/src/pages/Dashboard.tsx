import { useGetStats, getGetStatsQueryKey } from "@workspace/api-client-react";
import { formatBytes } from "@/lib/utils";
import { Clock, FileVideo, HardDrive, PlayCircle } from "lucide-react";
import Jobs from "./Jobs";
import { useI18n } from "@/i18n";
import { PreviewStatusBar } from "@/components/PreviewStatusBar";

export default function Dashboard() {
  const { t } = useI18n();
  const { data: stats } = useGetStats({ query: { refetchInterval: 3000, queryKey: getGetStatsQueryKey() } });

  const savedPct = stats?.avgCompressionRatio
    ? ((1 - stats.avgCompressionRatio) * 100).toFixed(1)
    : "0";

  return (
    <div data-testid="dashboard-page" className="space-y-3">
      <PreviewStatusBar />
      <div
        data-testid="compact-stats-strip"
        className="flex flex-wrap items-center gap-2 rounded-xl border bg-card/80 px-3 py-2 text-xs text-muted-foreground"
      >
        <span className="inline-flex items-center gap-1.5 rounded-lg border bg-secondary/25 px-2.5 py-1">
          <HardDrive className="h-3.5 w-3.5 text-primary" />
          <span>{t("dashboard.saved")}</span>
          <span className="font-mono text-foreground">{formatBytes(stats?.totalSavedBytes)}</span>
          <span className="font-mono text-primary">{savedPct}%</span>
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-lg border bg-secondary/25 px-2.5 py-1">
          <PlayCircle className="h-3.5 w-3.5 text-primary" />
          <span>{t("dashboard.running")}</span>
          <span className="font-mono text-foreground">{stats?.running || 0}</span>
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-lg border bg-secondary/25 px-2.5 py-1">
          <Clock className="h-3.5 w-3.5" />
          <span>{t("dashboard.waiting")}</span>
          <span className="font-mono text-foreground">{stats?.pending || 0}</span>
        </span>
        <span className="inline-flex items-center gap-1.5 rounded-lg border bg-secondary/25 px-2.5 py-1">
          <FileVideo className="h-3.5 w-3.5" />
          <span>{t("dashboard.done")}</span>
          <span className="font-mono text-foreground">{stats?.done || 0}</span>
        </span>
      </div>

      <Jobs embedded />
    </div>
  );
}
