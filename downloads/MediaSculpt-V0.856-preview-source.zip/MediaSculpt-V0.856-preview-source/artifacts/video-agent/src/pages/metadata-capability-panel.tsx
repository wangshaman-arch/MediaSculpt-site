// Metadata capability ladder shown in Settings.
//
// The point of this panel is that a user (or their customer) can see which
// capability tier is active without reading any documentation or asking a
// developer: no AI and no API keys must still mean "poster, cast, plot", and
// the panel states exactly what enabling the next tier would add.
import { useCallback, useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/i18n";
import { describeProxyStatus, type CapabilityNetwork } from "./metadata-capability-model";

type CapabilityTierId = "filename" | "keyless" | "keyed" | "ai";

type CapabilityReport = {
  health: "ok" | "degraded" | "broken";
  capability?: {
    current: CapabilityTierId;
    tiers: Array<{
      id: CapabilityTierId;
      available: boolean;
      provides: string[];
      requirement: string | null;
    }>;
  };
  network?: CapabilityNetwork;
  summary?: { total: number; identified: number; rejected: number; noCandidate: number; error: number };
};

type LoadState =
  | { status: "idle" }
  | { status: "loading" }
  | { status: "ready"; report: CapabilityReport }
  | { status: "error"; message: string };

/**
 * 代理状态行。
 *
 * 以前"填了代理却取不到海报"完全无法自查：面板只显示能力层级，完全不提网络
 * 路径。这里直接说明当前走的是手动代理、自动识别到的代理，还是直连。
 */
function ProxyStatusLine({ network }: { network?: CapabilityNetwork }) {
  const { t } = useI18n();
  if (!network) return null;
  const proxy = describeProxyStatus(network);
  const text = proxy.kind === "none"
    ? t("settings.capabilityProxyNone")
    : proxy.kind === "configured"
      ? t("settings.capabilityProxyConfigured", { url: proxy.url })
      : t("settings.capabilityProxyDetected", { url: proxy.url });
  return (
    <p className="text-xs text-muted-foreground" data-testid="metadata-proxy-status">
      {text}
    </p>
  );
}

export function MetadataCapabilityPanel() {
  const { t } = useI18n();
  const [state, setState] = useState<LoadState>({ status: "idle" });

  const load = useCallback(async () => {
    setState({ status: "loading" });
    try {
      const response = await fetch("/api/metadata/selfcheck");
      if (!response.ok) {
        setState({ status: "error", message: `HTTP ${response.status}` });
        return;
      }
      const report = (await response.json()) as CapabilityReport;
      setState({ status: "ready", report });
    } catch (error) {
      setState({ status: "error", message: error instanceof Error ? error.message : String(error) });
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const tierLabel = (id: CapabilityTierId) => t(`settings.capabilityTier.${id}`);
  const stateLabel = (status: CapabilityReport["health"]) => t(`settings.capabilityHealth.${status}`);

  return (
    <Card data-testid="metadata-capability-panel">
      <CardHeader>
        <CardTitle className="text-base">{t("settings.capabilityTitle")}</CardTitle>
        <CardDescription>{t("settings.capabilityHint")}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {state.status === "loading" && (
          <p className="text-xs text-muted-foreground">{t("settings.capabilityChecking")}</p>
        )}
        {state.status === "error" && (
          <div className="space-y-2">
            <p className="text-xs text-destructive">
              {t("settings.capabilityFailed", { reason: state.message })}
            </p>
            <Button type="button" size="sm" variant="outline" onClick={() => void load()}>
              {t("settings.capabilityRetry")}
            </Button>
          </div>
        )}
        {state.status === "ready" && state.report.capability && (
          <>
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="rounded border border-primary/30 bg-primary/10 px-2 py-0.5 font-medium text-primary">
                {t("settings.capabilityCurrent", {
                  tier: tierLabel(state.report.capability.current),
                })}
              </span>
              <span className="text-muted-foreground">
                {t("settings.capabilityHealthLabel", { status: stateLabel(state.report.health) })}
              </span>
              {state.report.summary && (
                <span className="text-muted-foreground">
                  {t("settings.capabilitySample", {
                    identified: String(state.report.summary.identified),
                    total: String(state.report.summary.total),
                  })}
                </span>
              )}
            </div>
            <ProxyStatusLine network={state.report.network} />
            <ul className="space-y-1.5">
              {state.report.capability.tiers.map((tier) => (
                <li key={tier.id} className="rounded-lg border bg-secondary/10 px-2.5 py-2 text-xs">
                  <div className="flex items-center gap-2">
                    <span className={tier.available ? "text-primary" : "text-muted-foreground"}>
                      {tier.available ? "●" : "○"}
                    </span>
                    <span className="font-medium">{tierLabel(tier.id)}</span>
                  </div>
                  <div className="mt-1 text-muted-foreground">{tier.provides.join(" · ")}</div>
                  {tier.requirement && (
                    <div className="mt-1 text-muted-foreground">
                      {t("settings.capabilityRequirement", { requirement: tier.requirement })}
                    </div>
                  )}
                </li>
              ))}
            </ul>
            <Button type="button" size="sm" variant="outline" onClick={() => void load()}>
              {t("settings.capabilityRefresh")}
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  );
}
