export function stableDiscTitleKey(
  sourceFingerprint: string | undefined,
  titleId: string,
): string {
  return `${sourceFingerprint ?? "unfingerprinted"}:${titleId}`;
}

/** Playlist-less Blu-ray titles can fall back to their direct M2TS stream. */
export function isDirectM2tsTitle(track: { titleId?: string | null }): boolean {
  return /^m2ts:\d+$/.test(track.titleId ?? "");
}

export function discFolderName(pathValue: string): string {
  const trimmed = pathValue.replace(/[\\/]+$/, "");
  return trimmed.split(/[\\/]/).pop() || pathValue;
}
