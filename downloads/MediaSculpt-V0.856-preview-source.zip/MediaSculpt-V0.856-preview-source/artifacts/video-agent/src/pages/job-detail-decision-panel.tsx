// Extracted from pages/JobDetail.tsx: decision parameter panel.
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Link, useLocation, useParams } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  getGetConfigQueryKey,
  getGetJobLogsQueryKey,
  getGetJobQueryKey,
  useGetConfig,
  useGetJob,
  useGetJobLogs,
  useUpdateConfig,
} from "@workspace/api-client-react";
import {
  AlertTriangle,
  ArrowLeft,
  Ban,
  Bot,
  Captions,
  ChevronDown,
  Download,
  FileText,
  Film,
  FolderOpen,
  Info,
  Languages,
  MessageSquareText,
  Mic,
  PauseCircle,
  Pin,
  Play,
  RotateCcw,
  ScanText,
  SlidersHorizontal,
  Sparkles,
  Square,
  Terminal,
  Trash2,
  Workflow,
  X,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { JobStatusBadge } from "@/components/JobStatusBadge";
import { ocrEngineLabel, ocrLanguageLabel } from "@/lib/ocr-languages";
import {
  cn,
  formatBytes,
  formatCompressionRatio,
  formatDate,
  formatDuration,
  toHostPath,
} from "@/lib/utils";
import { openDesktopPath } from "@/lib/desktop-bridge";
import { useToast } from "@/hooks/use-toast";
import { useI18n } from "@/i18n";
import {
  AssistantPanel,
  type AssistantMetadata,
  type ProcessingStep,
  type SubtitleChoice,
} from "@/components/AssistantPanel";
import { type PreviewPlayerHandle } from "@/components/PreviewPlayer";
import { PreviewPlayerCard } from "@/components/PreviewPlayerCard";
import {
  useAssistantAnalysis,
  type AssistantCorrection,
} from "@/hooks/useAssistantAnalysis";
import { resolveAnalysisOverview } from "@/lib/assistant-analysis";
import { parseAssistantMetadata } from "@/lib/assistant-metadata";
import { parseBlockedJobCode, blockedReasonKey } from "@/lib/blocked-job";
import {
  PRESET_CHANGED_EVENT,
  loadCompressionPresets,
  presetConfigValues,
  RESOLUTION_OPTIONS,
  type ArchivePreset,
} from "@/lib/compression-presets";
import { useJobActions } from "@/hooks/useJobActions";
import {
  isImageSubtitleCodec,
  parseSubtitleCues,
  streamAspectRatio,
  type MediaStreamInfo,
} from "./job-detail-model";

import {
  type SourceInfo,
  type CompressionDisplayConfig,
  sourceKind,
  streamLanguage,
  streamCodec,
  formatFrameRateLabel,
} from "./job-detail-model";

export function DecisionParameterPanel({
  processingMode,
  subtitleMode,
  ocrEngine,
  ocrLanguage,
  config,
  sourceInfo,
  compressionPresets,
  selectedPresetLabel,
  editableJobPreset,
  onCompressionPresetSelect,
  onEditableJobPresetChange,
}: {
  processingMode?: string | null;
  subtitleMode?: string | null;
  ocrEngine?: string | null;
  ocrLanguage?: string | null;
  config?: CompressionDisplayConfig | null;
  sourceInfo: SourceInfo | null;
  compressionPresets: ArchivePreset[];
  selectedPresetLabel: string;
  editableJobPreset: {
    encoder: string;
    crf: string;
    encoderPreset: string;
    outputResolution: string;
  };
  onCompressionPresetSelect: (preset: ArchivePreset) => void;
  onEditableJobPresetChange: (
    next: Partial<{
      encoder: string;
      crf: string;
      encoderPreset: string;
      outputResolution: string;
    }>,
  ) => void;
}) {
  const audioCount =
    sourceInfo?.streams.filter((stream) => stream.codecType === "audio")
      .length ?? 0;
  const subtitleCount =
    sourceInfo?.streams.filter((stream) => stream.codecType === "subtitle")
      .length ?? 0;
  const { t } = useI18n();
  const SUBTITLE_MODE_LABELS: Record<string, string> = {
    auto: t("jobDetail.subtitleModeAuto"),
    extract: t("jobDetail.subtitleModeExtract"),
    whisper: t("jobDetail.subtitleModeWhisper"),
    transcribe_translate: t("jobDetail.subtitleModeTranscribe"),
    ocr: t("jobDetail.subtitleModeOcr"),
    bilingual: t("jobDetail.subtitleModeBilingual"),
    skip: t("jobDetail.subtitleModeSkip"),
  };
  // 与压缩预设卡片同款：图标 + 名称 + 一行说明
  const SUBTITLE_MODE_ITEMS: Record<
    string,
    { Icon: typeof Sparkles; descKey: string }
  > = {
    auto: { Icon: Sparkles, descKey: "assistant.optionAutoDesc" },
    extract: { Icon: FileText, descKey: "assistant.optionExtractDesc" },
    whisper: { Icon: Mic, descKey: "assistant.optionWhisperDesc" },
    transcribe_translate: {
      Icon: Languages,
      descKey: "assistant.optionTranscribeTranslateDesc",
    },
    ocr: { Icon: ScanText, descKey: "assistant.optionOcrDesc" },
    bilingual: { Icon: Captions, descKey: "assistant.optionBilingualDesc" },
    skip: { Icon: Ban, descKey: "assistant.optionSkipDesc" },
  };

  if (processingMode === "remux") {
    return (
      <div className="rounded-xl border border-blue-500/25 bg-blue-500/5 p-3">
        <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-blue-200">
          <PackageIcon />
          {t("jobDetail.remuxSummary")}
        </div>
        <div className="text-xs text-muted-foreground">
          {t("jobDetail.remuxHint")}
        </div>
      </div>
    );
  }

  if (processingMode === "none") {
    return (
      <div className="rounded-xl border bg-secondary/15 p-3">
        <div className="mb-3 flex items-center gap-2 text-sm font-semibold">
          <SlidersHorizontal className="h-4 w-4 text-primary" />
          {t("jobDetail.currentSubtitleMode")}
        </div>
        <div className="grid grid-cols-1 gap-2">
          {Object.entries(SUBTITLE_MODE_LABELS).map(([value, label]) => {
            const item = SUBTITLE_MODE_ITEMS[value];
            const Icon = item?.Icon ?? Sparkles;
            return (
              <div
                key={value}
                className={cn(
                  "rounded-lg border p-2 text-left text-xs",
                  subtitleMode === value
                    ? "border-primary bg-primary/10 text-primary"
                    : "bg-background/55 text-muted-foreground",
                )}
              >
                <div className="flex items-center gap-1.5 font-medium">
                  <Icon className="h-4 w-4 shrink-0" />
                  {label}
                </div>
                {item && (
                  <p className="mt-1 text-[11px] leading-snug">
                    {t(item.descKey)}
                  </p>
                )}
              </div>
            );
          })}
        </div>
        {subtitleMode === "ocr" && (
          <p className="mt-2 text-xs font-mono text-muted-foreground">
            {t("jobs.ocrParamsTitle")}
            {ocrEngineLabel(ocrEngine, t)} · {ocrLanguageLabel(ocrLanguage, t)}
          </p>
        )}
        <div className="mt-2 text-xs text-muted-foreground">
          {t("jobDetail.subtitleDecisionHint", {
            audio: audioCount,
            subtitle: subtitleCount,
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-xl border bg-secondary/15 p-3">
      <div className="mb-3 flex items-center gap-2 text-sm font-semibold">
        <SlidersHorizontal className="h-4 w-4 text-primary" />
        {t("jobDetail.compressionPresetTitle")}
      </div>
      <div className="grid grid-cols-1 gap-2">
        {compressionPresets.map((preset) => (
          <button
            key={preset.id}
            type="button"
            data-testid="job-detail-compression-preset"
            onClick={() => onCompressionPresetSelect(preset)}
            className={cn(
              "rounded-lg border px-3 py-2 text-left transition hover:border-primary/50",
              selectedPresetLabel === preset.id &&
                "border-primary/60 bg-primary/20 text-primary",
            )}
          >
            <div className="flex min-w-0 items-center justify-between gap-2 text-xs font-medium">
              <span className="min-w-0 truncate">
                {preset.icon} {t(preset.labelKey)}
              </span>
              <span className="shrink-0 font-mono text-[11px] text-primary">
                {preset.values.encoder} · CRF {preset.values.crf} ·{" "}
                {preset.values.outputResolution ?? "source"}
              </span>
            </div>
            <div className="mt-1 text-[11px] text-muted-foreground">
              {t(preset.descriptionKey)}
            </div>
          </button>
        ))}
      </div>
      <div className="mt-3 rounded-lg border bg-background/55 p-2 text-xs text-muted-foreground">
        {t("jobDetail.currentConfig")}
        <span className="ml-1 font-mono text-foreground">
          {editableJobPreset.encoder || config?.encoder || "--"}
        </span>
        <span className="mx-1">· RF</span>
        <span className="font-mono text-foreground">
          {editableJobPreset.crf || config?.crf || "--"}
        </span>
        <span className="mx-1">·</span>
        <span className="font-mono text-foreground">
          {editableJobPreset.encoderPreset || config?.encoderPreset || "slow"}
        </span>
        <span className="mx-1">· {t("jobDetail.resolutionTag")}</span>
        <span className="font-mono text-foreground">
          {editableJobPreset.outputResolution ||
            config?.outputResolution ||
            "source"}
        </span>
      </div>
      <div className="mt-2 grid grid-cols-1 gap-2">
        <Input
          aria-label={t("jobDetail.encoderAria")}
          value={editableJobPreset.encoder}
          onChange={(event) =>
            onEditableJobPresetChange({ encoder: event.currentTarget.value })
          }
          className="h-8 text-xs"
        />
        <Input
          aria-label={t("jobDetail.crfAria")}
          value={editableJobPreset.crf}
          onChange={(event) =>
            onEditableJobPresetChange({ crf: event.currentTarget.value })
          }
          className="h-8 text-xs"
        />
        <Input
          aria-label={t("jobDetail.encoderPresetAria")}
          value={editableJobPreset.encoderPreset}
          onChange={(event) =>
            onEditableJobPresetChange({
              encoderPreset: event.currentTarget.value,
            })
          }
          className="h-8 text-xs"
        />
        <Select
          value={editableJobPreset.outputResolution}
          onValueChange={(value) =>
            onEditableJobPresetChange({ outputResolution: value })
          }
        >
          <SelectTrigger
            className="h-8 text-xs"
            aria-label={t("jobDetail.resolutionAria")}
          >
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {RESOLUTION_OPTIONS.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {t(option.labelKey)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}

function PackageIcon() {
  return <Workflow className="h-4 w-4 text-blue-300" />;
}
