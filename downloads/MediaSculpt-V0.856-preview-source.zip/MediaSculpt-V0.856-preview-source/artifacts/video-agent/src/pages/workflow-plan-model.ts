import type { ProcessingStep } from "../components/AssistantPanel";

export type WorkflowChoiceItem = {
  action: "remux" | "compress" | "subtitle" | "skip";
  pipeline?: ProcessingStep[];
  presetId: string | null;
};

export type WorkflowPresetOption = { id: string; label: string };

export function workflowChapterSelectionPayload(item: {
  sourceType: "video" | "dvd" | "bluray" | "iso";
  selectedChapterIds: string[];
  chapters: Array<{ id: string }>;
}): string | undefined {
  const availableIds = item.chapters.map((chapter) => chapter.id);
  const selectedIds = new Set(item.selectedChapterIds);
  const allDiscChaptersSelected =
    (item.sourceType === "dvd" || item.sourceType === "bluray" || item.sourceType === "iso") &&
    availableIds.length > 0 &&
    selectedIds.size === availableIds.length &&
    availableIds.every((id) => selectedIds.has(id));

  // The authoritative title verification may expose a different chapter list
  // than the initial disc scan. Leave “all chapters” unset so the server uses
  // the verified title's actual chapter IDs instead of stale scan indexes.
  if (allDiscChaptersSelected) return undefined;
  return JSON.stringify(
    item.selectedChapterIds
      .map((id) => Number(id))
      .filter((id) => Number.isInteger(id) && id >= 0),
  );
}

export function workflowPresetLabel(presetId: string, options: WorkflowPresetOption[]): string {
  return options.find((option) => option.id === presetId)?.label ?? presetId;
}

/**
 * 智能工作流的分析结果只提供建议；进入计划页时不应把建议当成用户选择。
 * 保留其余媒体/元数据字段，仅清空会直接执行处理的选择状态。
 */
export function clearWorkflowChoices<T extends WorkflowChoiceItem>(items: T[]): T[] {
  return items.map((item) => ({
    ...item,
    action: "skip",
    pipeline: [],
    presetId: null,
  }));
}
