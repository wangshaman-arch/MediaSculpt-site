// Extracted from pages/Settings.tsx: the compression / encoding settings section.
import {
  useGetConfig,
  getGetConfigQueryKey,
  useUpdateConfig,
  ConfigInputWhisperModel,
  ConfigInputOutputFormat,
} from "@workspace/api-client-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Slider } from "@/components/ui/slider";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useEffect, useState, useRef, useMemo } from "react";
import type { Resolver } from "react-hook-form";
import { useI18n } from "@/i18n";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import {
  Save,
  Settings2,
  ExternalLink,
  Languages,
  Zap,
  Star,
  ChevronDown,
  ChevronUp,
  Cpu,
  FolderSearch,
  Plus,
  Trash2,
  BookmarkCheck,
  Pencil,
  X,
  RefreshCw,
  RotateCcw,
  FileText,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { DirectoryPicker } from "@/components/DirectoryPicker";
import { ImdbDatasetCard } from "@/components/ImdbDatasetCard";
import { TuningLogicCard } from "@/components/TuningLogicCard";
import { TuningPromptsCard } from "@/components/TuningPromptsCard";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  parseCustomTuning,
  serializeCustomTuning,
  type CustomTuning,
} from "@/lib/custom-tuning";
import {
  useSettingsSections,
  type SettingsSection,
} from "@/hooks/useSettingsSections";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  ARCHIVE_PRESETS,
  ARCHIVE_PRESET_LS_KEY,
  CUSTOM_PRESET_KEY,
  PRESET_CHANGED_EVENT,
  loadCompressionPresets,
  ENCODER_OPTIONS,
  type ArchivePreset,
  type CustomPreset,
} from "@/lib/compression-presets";
import { compressionPresetSummary } from "@/features/workbench/compression-preset-model";
import { ToolManager } from "./settings-tool-manager";
import {
  previewOutputName,
  settingsAssColorToHex,
  settingsHexToAssColor,
  type ConfigFormValues,
  ENCODER_PRESETS,
  ENCODER_TUNES,
  ENCODER_PROFILES,
  ENCODER_LEVELS,
  FRAME_RATES,
  OUTPUT_RESOLUTIONS,
} from "./settings-model";
import { useFormContext } from "react-hook-form";
import type { Dispatch, SetStateAction } from "react";


type SectionKey =
  | "directories"
  | "encoding"
  | "subtitleWhisper"
  | "aiTranslation"
  | "tmdb"
  | "toolPaths"
  | "system";

type SettingsCompressionSectionProps = {
  openSections: Record<SectionKey, boolean>;
  toggle: (key: SectionKey) => void;
  crfValue: number;
  crfLabel: string;
  isX264Family: boolean;
  startEditPreset: (preset: ArchivePreset) => void;
  saveEditedPreset: () => Promise<void> | void;
  resetPresetToDefault: () => void;
  saveCurrentAsPreset: () => void;
  deleteCustomPreset: (id: string) => void;
  customPresets: CustomPreset[];
  editingPreset: string | null;
  setEditingPreset: Dispatch<SetStateAction<string | null>>;
  editDraft: ArchivePreset["values"] | null;
  setEditDraft: Dispatch<SetStateAction<ArchivePreset["values"] | null>>;
  newPresetName: string;
  setNewPresetName: Dispatch<SetStateAction<string>>;
  showSaveForm: boolean;
  setShowSaveForm: Dispatch<SetStateAction<boolean>>;
  archivePresets: ArchivePreset[];
  activePreset: string | null;
  applyArchivePreset: (preset: ArchivePreset) => Promise<void> | void;
  applyCustomPreset: (preset: CustomPreset) => Promise<void> | void;
};

export function SettingsCompressionSection({
  openSections,
  toggle,
  crfValue,
  crfLabel,
  isX264Family,
  startEditPreset,
  saveEditedPreset,
  resetPresetToDefault,
  saveCurrentAsPreset,
  deleteCustomPreset,
  customPresets,
  editingPreset,
  setEditingPreset,
  editDraft,
  setEditDraft,
  newPresetName,
  setNewPresetName,
  showSaveForm,
  setShowSaveForm,
  archivePresets,
  activePreset,
  applyArchivePreset,
  applyCustomPreset,
}: SettingsCompressionSectionProps) {
  const { t } = useI18n();
  const form = useFormContext<ConfigFormValues>();
  const updateConfig = useUpdateConfig();
  const queryClient = useQueryClient();
  return (
              <Collapsible
                open={openSections.encoding}
                onOpenChange={() => toggle("encoding")}
              >
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <Star className="h-5 w-5 text-yellow-400" />{" "}
                          {t("settings.compressionCardTitle")}
                        </CardTitle>
                        <CardDescription className="mt-1">
                          {t("settings.compressionCardDesc")}
                        </CardDescription>
                      </div>
                      <CollapsibleTrigger asChild>
                        <button
                          type="button"
                          className="p-1 rounded hover:bg-secondary/60 transition-colors ml-3 shrink-0"
                        >
                          <ChevronDown
                            className={`h-4 w-4 text-muted-foreground transition-transform ${openSections.encoding ? "rotate-180" : ""}`}
                          />
                        </button>
                      </CollapsibleTrigger>
                    </div>
                  </CardHeader>
                  <CollapsibleContent>
                    <CardContent className="space-y-6">
                      {/* 内置预设按钮组 */}
                      <div>
                        <p className="text-sm font-medium mb-3 text-muted-foreground">
                          {t("settings.builtinPresetsHint")}
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          {archivePresets.map((preset) => (
                            <div
                              key={preset.id}
                              className={cn(
                                "rounded-lg border transition-all overflow-hidden",
                                editingPreset === preset.id
                                  ? "border-primary ring-1 ring-primary/40"
                                  : activePreset === preset.id
                                    ? "border-primary bg-primary/10"
                                    : "border-border bg-secondary/20",
                              )}
                            >
                              <div className="flex items-stretch">
                                <button
                                  type="button"
                                  onClick={() => applyArchivePreset(preset)}
                                  className="flex-1 flex flex-col items-start gap-1.5 p-3 text-left hover:bg-primary/5 transition-colors"
                                >
                                  <div className="flex items-center gap-1.5 w-full">
                                    <span className="text-lg leading-none">
                                      {preset.icon}
                                    </span>
                                    <span className="text-xs font-semibold truncate flex-1">
                                      {t(preset.labelKey)}
                                    </span>
                                  </div>
                                  <Badge
                                    variant="outline"
                                    className="text-[10px] px-1.5 py-0 border-primary/30 text-primary/80"
                                  >
                                    {compressionPresetSummary(preset.values, t)}
                                  </Badge>
                                  <p className="text-[11px] text-muted-foreground leading-tight">
                                    {t(preset.descriptionKey)}
                                  </p>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => startEditPreset(preset)}
                                  className={cn(
                                    "px-2.5 border-l transition-colors shrink-0",
                                    editingPreset === preset.id
                                      ? "bg-primary/10 text-primary hover:bg-primary/20"
                                      : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground",
                                  )}
                                  title={t("settings.editPresetTitle")}
                                >
                                  {editingPreset === preset.id ? (
                                    <X className="h-3.5 w-3.5" />
                                  ) : (
                                    <Pencil className="h-3.5 w-3.5" />
                                  )}
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* 内联预设编辑器 */}
                        {editingPreset && editDraft && (
                          <div className="mt-3 border border-primary/30 rounded-lg p-4 bg-primary/5 space-y-3">
                            <div className="flex items-center justify-between">
                              <p className="text-sm font-semibold">
                                {t("settings.editingPreset", {
                                  name: t(
                                    archivePresets.find(
                                      (p) => p.id === editingPreset,
                                    )?.labelKey ??
                                      (customPresets.some(
                                        (preset) => preset.id === editingPreset,
                                      )
                                        ? "settings.customPreset"
                                        : ""),
                                  ),
                                })}
                              </p>
                              <button
                                type="button"
                                onClick={resetPresetToDefault}
                                className="text-xs text-muted-foreground hover:text-foreground transition-colors underline underline-offset-2"
                              >
                                {t("settings.resetDefaults")}
                              </button>
                            </div>
                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                              <div className="space-y-1">
                                <label className="text-xs font-medium block">
                                  {t("settings.crfQuality", {
                                    value: editDraft.crf,
                                  })}
                                </label>
                                <input
                                  type="range"
                                  min={0}
                                  max={51}
                                  step={1}
                                  value={editDraft.crf}
                                  onChange={(e) =>
                                    setEditDraft((d) =>
                                      d
                                        ? {
                                            ...d,
                                            crf: parseInt(e.target.value),
                                          }
                                        : d,
                                    )
                                  }
                                  className="vx-range w-full"
                                />
                                <div className="flex justify-between text-[10px] text-muted-foreground">
                                  <span>{t("settings.lossless")}</span>
                                  <span>{t("settings.worst")}</span>
                                </div>
                              </div>
                              <div className="space-y-1">
                                <label className="text-xs font-medium block">
                                  {t("settings.encoderLabel")}
                                </label>
                                <Select
                                  value={editDraft.encoder}
                                  onValueChange={(v) =>
                                    setEditDraft((d) =>
                                      d ? { ...d, encoder: v } : d,
                                    )
                                  }
                                >
                                  <SelectTrigger className="h-8 text-xs font-mono">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {ENCODER_OPTIONS.map((option) => (
                                      <SelectItem
                                        key={option.value}
                                        value={option.value}
                                      >
                                        {t(option.labelKey)}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-1">
                                <label className="text-xs font-medium block">
                                  {t("settings.speedPreset")}
                                </label>
                                <Select
                                  value={editDraft.encoderPreset}
                                  onValueChange={(v) =>
                                    setEditDraft((d) =>
                                      d ? { ...d, encoderPreset: v } : d,
                                    )
                                  }
                                >
                                  <SelectTrigger className="h-8 text-xs font-mono">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {ENCODER_PRESETS.map((p) => (
                                      <SelectItem key={p.value} value={p.value}>
                                        {t(p.labelKey)}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-1">
                                <label className="text-xs font-medium block">
                                  {t("settings.tuneLabel")}
                                </label>
                                <Select
                                  value={editDraft.encoderTune}
                                  onValueChange={(v) =>
                                    setEditDraft((d) =>
                                      d ? { ...d, encoderTune: v } : d,
                                    )
                                  }
                                >
                                  <SelectTrigger className="h-8 text-xs font-mono">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {ENCODER_TUNES.map((tune) => (
                                      <SelectItem
                                        key={tune.value}
                                        value={tune.value}
                                      >
                                        {t(tune.labelKey)}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-1">
                                <label className="text-xs font-medium block">
                                  {t("settings.profileLabel")}
                                </label>
                                <Select
                                  value={editDraft.encoderProfile}
                                  onValueChange={(v) =>
                                    setEditDraft((d) =>
                                      d ? { ...d, encoderProfile: v } : d,
                                    )
                                  }
                                >
                                  <SelectTrigger className="h-8 text-xs font-mono">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {ENCODER_PROFILES.map((p) => (
                                      <SelectItem key={p.value} value={p.value}>
                                        {t(p.labelKey)}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-1">
                                <label className="text-xs font-medium block">
                                  {t("settings.levelLabel")}
                                </label>
                                <Select
                                  value={editDraft.encoderLevel}
                                  onValueChange={(v) =>
                                    setEditDraft((d) =>
                                      d ? { ...d, encoderLevel: v } : d,
                                    )
                                  }
                                >
                                  <SelectTrigger className="h-8 text-xs font-mono">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {ENCODER_LEVELS.map((level) => (
                                      <SelectItem
                                        key={level.value}
                                        value={level.value}
                                      >
                                        {t(level.labelKey)}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                            <div className="flex gap-2 pt-1">
                              <Button
                                type="button"
                                size="sm"
                                className="h-8"
                                onClick={saveEditedPreset}
                              >
                                <Save className="h-3.5 w-3.5 mr-1.5" />{" "}
                                {t("settings.savePresetApply")}
                              </Button>
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                className="h-8"
                                onClick={() => {
                                  setEditingPreset(null);
                                  setEditDraft(null);
                                }}
                              >
                                {" "}
                                {t("common.cancel")}
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* 自定义预设 */}
                      <div className="border-t pt-4">
                        <div className="flex items-center justify-between mb-3">
                          <p className="text-sm font-medium text-muted-foreground flex items-center gap-1.5">
                            <BookmarkCheck className="h-4 w-4" />{" "}
                            {t("settings.customPresets")}
                            <span className="text-xs text-muted-foreground/60">
                              {t("settings.storedLocally")}
                            </span>
                          </p>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            className="h-8 px-3 text-xs gap-1"
                            onClick={() => setShowSaveForm((v) => !v)}
                          >
                            <Plus className="h-3.5 w-3.5" />{" "}
                            {t("settings.saveCurrentAsPreset")}
                          </Button>
                        </div>

                        {/* 保存表单 */}
                        {showSaveForm && (
                          <div className="flex gap-2 mb-3">
                            <Input
                              value={newPresetName}
                              onChange={(e) => setNewPresetName(e.target.value)}
                              placeholder={t("settings.presetNamePlaceholder")}
                              className="h-8 text-sm flex-1"
                              onKeyDown={(e) => {
                                if (e.key === "Enter") saveCurrentAsPreset();
                                if (e.key === "Escape") setShowSaveForm(false);
                              }}
                              autoFocus
                            />
                            <Button
                              type="button"
                              size="sm"
                              className="h-8 px-3"
                              onClick={saveCurrentAsPreset}
                              disabled={!newPresetName.trim()}
                            >
                              {t("common.save")}{" "}
                            </Button>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="h-8 px-2"
                              onClick={() => setShowSaveForm(false)}
                            >
                              {" "}
                              {t("common.cancel")}
                            </Button>
                          </div>
                        )}

                        {/* 自定义预设列表 */}
                        {customPresets.length === 0 ? (
                          <p className="text-xs text-muted-foreground/60 py-2">
                            {t("settings.noCustomPresets")}
                          </p>
                        ) : (
                          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                            {customPresets.map((preset) => (
                              <div
                                key={preset.id}
                                className={cn(
                                  "flex items-center gap-2 rounded-lg border px-3 py-2 transition-all",
                                  activePreset === preset.id
                                    ? "border-primary/60 bg-primary/20"
                                    : "border-border bg-secondary/10",
                                )}
                              >
                                <button
                                  type="button"
                                  className="flex-1 text-left min-w-0"
                                  onClick={() => applyCustomPreset(preset)}
                                >
                                  <p className="text-xs font-semibold truncate">
                                    {preset.name}
                                  </p>
                                  <p className="text-[11px] text-muted-foreground font-mono truncate">
                                    {compressionPresetSummary(preset.values, t)}
                                  </p>
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingPreset(preset.id);
                                    setEditDraft({ ...preset.values });
                                  }}
                                  className={cn(
                                    "shrink-0 p-1 rounded hover:bg-secondary/60 transition-colors",
                                    editingPreset === preset.id
                                      ? "text-primary"
                                      : "text-muted-foreground hover:text-foreground",
                                  )}
                                  title={t("settings.editCustomPreset")}
                                >
                                  {editingPreset === preset.id ? (
                                    <X className="h-3.5 w-3.5" />
                                  ) : (
                                    <Pencil className="h-3.5 w-3.5" />
                                  )}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => deleteCustomPreset(preset.id)}
                                  className="shrink-0 p-1 rounded hover:bg-destructive/10 hover:text-destructive transition-colors"
                                  title={t("common.delete")}
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      <div className="border-t pt-5 grid gap-6 md:grid-cols-2">
                        {/* 编码器 */}
                        <FormField
                          control={form.control}
                          name="encoder"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                {t("settings.encoderLabel")}
                              </FormLabel>
                              <Select
                                onValueChange={(value) => {
                                  field.onChange(value);
                                  // 语言选择即时生效：保存并刷新配置，界面立即切换语言（与顶部菜单不再重复）
                                  void updateConfig
                                    .mutateAsync({
                                      data: {
                                        uiLanguage: value as "zh-CN" | "en-US",
                                      },
                                    })
                                    .then(() =>
                                      queryClient.invalidateQueries({
                                        queryKey: getGetConfigQueryKey(),
                                      }),
                                    )
                                    .catch(() => {});
                                }}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger className="font-mono">
                                    <SelectValue />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {ENCODER_OPTIONS.map((option) => (
                                    <SelectItem
                                      key={option.value}
                                      value={option.value}
                                    >
                                      {t(option.labelKey)}
                                    </SelectItem>
                                  ))}
                                  <SelectItem value="vp9">
                                    {t("settings.encoderVp9")}
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                {t("settings.encoderDesc")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {/* RF/CRF */}
                        <FormField
                          control={form.control}
                          name="crf"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="flex items-center justify-between">
                                <span>{t("settings.rfQuality")}</span>
                                <span className="font-mono text-primary text-base font-bold">
                                  {crfValue}
                                </span>
                              </FormLabel>
                              <FormControl>
                                <div className="space-y-2">
                                  <Slider
                                    min={0}
                                    max={51}
                                    step={1}
                                    value={[field.value]}
                                    onValueChange={([v]) => field.onChange(v)}
                                    className="py-1"
                                  />
                                  <div className="flex justify-between text-[11px] text-muted-foreground">
                                    <span>{t("settings.lossless")}</span>
                                    <Badge
                                      variant="secondary"
                                      className="text-[10px] px-2 py-0"
                                    >
                                      {crfLabel}
                                    </Badge>
                                    <span>{t("settings.worst")}</span>
                                  </div>
                                </div>
                              </FormControl>
                              <FormDescription>
                                {t("settings.crfDesc")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {/* 帧率 */}
                        <FormField
                          control={form.control}
                          name="frameRate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t("settings.frameRate")}</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger className="font-mono">
                                    <SelectValue />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {FRAME_RATES.map((f) => (
                                    <SelectItem key={f.value} value={f.value}>
                                      {t(f.labelKey)}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                {t("settings.frameRateDesc")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {/* 输出分辨率 */}
                        <FormField
                          control={form.control}
                          name="outputResolution"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                {t("settings.outputResolution")}
                              </FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger className="font-mono">
                                    <SelectValue />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {OUTPUT_RESOLUTIONS.map((r) => (
                                    <SelectItem key={r.value} value={r.value}>
                                      {t(r.labelKey)}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                {t("settings.outputResolutionDesc")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {/* 编码预设（速度/压缩比权衡） */}
                        <FormField
                          control={form.control}
                          name="encoderPreset"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="flex items-center gap-1">
                                <Zap className="h-3.5 w-3.5" />{" "}
                                {t("settings.encodingPreset")}
                              </FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger className="font-mono">
                                    <SelectValue />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {ENCODER_PRESETS.map((p) => (
                                    <SelectItem key={p.value} value={p.value}>
                                      {t(p.labelKey)}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                {t("settings.encodingPresetDesc")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {/* 编码微调 */}
                        <FormField
                          control={form.control}
                          name="encoderTune"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t("settings.encoderTune")}</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger className="font-mono">
                                    <SelectValue />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {ENCODER_TUNES.map((tune) => (
                                    <SelectItem
                                      key={tune.value}
                                      value={tune.value}
                                    >
                                      {t(tune.labelKey)}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              {!isX264Family && (
                                <p className="text-xs text-yellow-500 mt-1">
                                  {t("settings.tuneHint")}
                                </p>
                              )}
                              <FormDescription>
                                {t("settings.tuneDesc")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {/* 编码配置（Profile） */}
                        <FormField
                          control={form.control}
                          name="encoderProfile"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                {t("settings.encoderProfile")}
                              </FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger className="font-mono">
                                    <SelectValue />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {ENCODER_PROFILES.map((p) => (
                                    <SelectItem key={p.value} value={p.value}>
                                      {t(p.labelKey)}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                {t("settings.profileDesc")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {/* 编码级别（Level） */}
                        <FormField
                          control={form.control}
                          name="encoderLevel"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                {t("settings.encoderLevel")}
                              </FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger className="font-mono">
                                    <SelectValue />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {ENCODER_LEVELS.map((l) => (
                                    <SelectItem key={l.value} value={l.value}>
                                      {t(l.labelKey)}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormDescription>
                                {t("settings.levelDesc")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {/* 容器格式 */}
                        <FormField
                          control={form.control}
                          name="outputFormat"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                {t("settings.containerFormat")}
                              </FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                value={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger className="font-mono">
                                    <SelectValue />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="mkv">
                                    {t("settings.containerMkv")}
                                  </SelectItem>
                                  <SelectItem value="mp4">
                                    {t("settings.containerMp4")}
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {/* HandBrake 预设 */}
                        <FormField
                          control={form.control}
                          name="handbrakePreset"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                {t("settings.handbrakePreset")}
                              </FormLabel>
                              <FormControl>
                                <Input
                                  {...field}
                                  className="font-mono"
                                  placeholder="HQ 1080p30 Surround"
                                />
                              </FormControl>
                              <FormDescription>
                                {t("settings.handbrakePresetDesc")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        {/* 音轨 */}
                        <FormField
                          control={form.control}
                          name="audioCopy"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4 bg-secondary/10 md:col-span-2">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">
                                  {t("settings.audioPassthrough")}
                                </FormLabel>
                                <FormDescription>
                                  {t("settings.audioPassthroughDesc")}
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        {/* 去隔行 */}
                        <FormField
                          control={form.control}
                          name="deinterlace"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4 bg-secondary/10 md:col-span-2">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">
                                  {t("settings.deinterlace")}
                                </FormLabel>
                                <FormDescription>
                                  {t("settings.deinterlaceDesc")}
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>
  );
}
