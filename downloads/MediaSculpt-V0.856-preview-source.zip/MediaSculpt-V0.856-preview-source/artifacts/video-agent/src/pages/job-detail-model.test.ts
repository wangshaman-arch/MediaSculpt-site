import { describe, expect, it } from "vitest";
import { parseSubtitleCues, streamAspectRatio } from "./job-detail-model";

describe("job detail model helpers", () => {
  it("parses SRT cues without changing their timestamps", () => {
    expect(
      parseSubtitleCues("1\n00:00:01,250 --> 00:00:02,500\nHello\n"),
    ).toEqual([{ start: 1.25, end: 2.5, text: "Hello" }]);
  });

  it("prefers a valid display aspect ratio", () => {
    expect(
      streamAspectRatio({
        displayAspectRatio: "16:9",
        width: 720,
        height: 576,
      }),
    ).toBe("16 / 9");
  });
});
