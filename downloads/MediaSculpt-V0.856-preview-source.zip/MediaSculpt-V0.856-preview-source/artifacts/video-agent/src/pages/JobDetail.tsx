import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Link, useLocation, useParams } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  getGetConfigQueryKey,
  getGetJobLogsQueryKey,
  getGetJobQueryKey,
  useGetConfig,
  useGetJob,
  useGetJobLogs,
  useUpdateConfig,
} from "@workspace/api-client-react";
import {
  AlertTriangle,
  ArrowLeft,
  Ban,
  Bot,
  Captions,
  ChevronDown,
  Download,
  FileText,
  Film,
  FolderOpen,
  Info,
  Languages,
  MessageSquareText,
  Mic,
  PauseCircle,
  Pin,
  Play,
  RotateCcw,
  ScanText,
  SlidersHorizontal,
  Sparkles,
  Square,
  Terminal,
  Trash2,
  Workflow,
  X,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { JobStatusBadge } from "@/components/JobStatusBadge";
import { ocrEngineLabel, ocrLanguageLabel } from "@/lib/ocr-languages";
import {
  cn,
  formatBytes,
  formatCompressionRatio,
  formatDate,
  formatDuration,
  toHostPath,
} from "@/lib/utils";
import { openDesktopPath } from "@/lib/desktop-bridge";
import { useToast } from "@/hooks/use-toast";
import { useI18n } from "@/i18n";
import {
  AssistantPanel,
  type AssistantMetadata,
  type ProcessingStep,
  type SubtitleChoice,
} from "@/components/AssistantPanel";
import { type PreviewPlayerHandle } from "@/components/PreviewPlayer";
import { PreviewPlayerCard } from "@/components/PreviewPlayerCard";
import {
  useAssistantAnalysis,
  type AssistantCorrection,
} from "@/hooks/useAssistantAnalysis";
import { resolveAnalysisOverview } from "@/lib/assistant-analysis";
import { parseAssistantMetadata } from "@/lib/assistant-metadata";
import { parseBlockedJobCode, blockedReasonKey } from "@/lib/blocked-job";
import {
  PRESET_CHANGED_EVENT,
  loadCompressionPresets,
  presetConfigValues,
  RESOLUTION_OPTIONS,
  type ArchivePreset,
} from "@/lib/compression-presets";
import { useJobActions } from "@/hooks/useJobActions";
import {
  isImageSubtitleCodec,
  parseSubtitleCues,
  streamAspectRatio,
  type MediaStreamInfo,
} from "./job-detail-model";

import {
  type EmbeddedSubtitleTrack,
  type MediaChapterInfo,
  type SourceInfo,
  type PathMappingConfig,
  type CompressionDisplayConfig,
  isDiscMedia,
  sourceKind,
  outputFolderLabel,
  streamLanguage,
  streamCodec,
  formatFrameRateLabel,
  isBrowserPlayablePreview,
} from "./job-detail-model";
import { SourceInfoCompactBar } from "./job-detail-source-bar";
import { DecisionParameterPanel } from "./job-detail-decision-panel";


export default function JobDetail() {
  const { id } = useParams();
  const jobId = parseInt(id || "0", 10);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { t, lang } = useI18n();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [subtitlePreviewKind, setSubtitlePreviewKind] = useState<
    "off" | "subtitle" | "translated" | `embedded:${number}` | `file:${string}`
  >("off");
  const [showAllTracks, setShowAllTracks] = useState(false);
  const [embeddedSubtitleTracks, setEmbeddedSubtitleTracks] = useState<
    EmbeddedSubtitleTrack[]
  >([]);
  const [externalSubtitleFiles, setExternalSubtitleFiles] = useState<
    Array<{
      name: string;
      path: string;
      kind: "original" | "translated" | "other";
    }>
  >([]);
  const [sourceInfo, setSourceInfo] = useState<SourceInfo | null>(null);
  const [previewPlaying, setPreviewPlaying] = useState(false);
  const [subtitleCues, setSubtitleCues] = useState<
    Array<{ start: number; end: number; text: string }>
  >([]);
  const playerRef = useRef<PreviewPlayerHandle>(null);
  const [detailsDrawerOpen, setDetailsDrawerOpen] = useState(true);
  const [analysisOverlayTarget, setAnalysisOverlayTarget] =
    useState<HTMLDivElement | null>(null);
  const [detailsPinned, setDetailsPinned] = useState(false);
  const [overviewOpen, setOverviewOpen] = useState(false);
  const [paramsOpen, setParamsOpen] = useState(false);
  const [assistantOpen, setAssistantOpen] = useState(true);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [fileDetailsOpen, setFileDetailsOpen] = useState(false);
  const [jobLogsOpen, setJobLogsOpen] = useState(false);
  const [logsCardOpen, setLogsCardOpen] = useState(false);
  const [compressionPresets, setCompressionPresets] = useState<ArchivePreset[]>(
    () => loadCompressionPresets(),
  );
  const [selectedPresetLabel, setSelectedPresetLabel] = useState("");
  const [editableJobPreset, setEditableJobPreset] = useState({
    encoder: "",
    crf: "",
    encoderPreset: "",
    outputResolution: "",
  });
  const editableJobPresetRef = useRef(editableJobPreset);
  const presetSaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [assistantGoal, setAssistantGoal] = useState("");
  const [assistantIssue, setAssistantIssue] = useState("");
  const [assistantQuality, setAssistantQuality] = useState("");
  const [assistantSubtitleLang, setAssistantSubtitleLang] = useState("");
  const [assistantAudioPlan, setAssistantAudioPlan] = useState("");
  const [assistantNotes, setAssistantNotes] = useState("");
  const [subtitleModeOverride, setSubtitleModeOverride] = useState<
    string | null
  >(null);
  const [chapterSamplePosition, setChapterSamplePosition] = useState<
    "middle" | "start" | "end"
  >("middle");
  // 助手流水线 chips 的实时选择：详情栏“点击什么出现什么”以它为准（null=用任务冻结的流水线）
  const [effectivePipeline, setEffectivePipeline] = useState<string[] | null>(
    null,
  );
  const [correction, setCorrection] = useState<AssistantCorrection | null>(
    null,
  );
  const assistantPrefsRef = useRef<{
    titleEn: string;
    titleZh: string;
    year: number | null;
    imdbId: string;
  } | null>(null);
  // 智能助手面板中确认要应用的处理流程 / 字幕策略；只有用户实际改动过才会提交。
  const assistantExecutionRef = useRef<{
    processing: ProcessingStep[];
    subtitle: SubtitleChoice | null;
  }>({ processing: [], subtitle: null });
  const assistantGenRef = useRef<{
    generateReadme: boolean;
    generatePoster: boolean;
    generateReview: boolean;
  }>({ generateReadme: false, generatePoster: false, generateReview: false });
  const assistantExecutionDirtyRef = useRef(false);
  // 记录上一次同步给详情区的处理流程/字幕策略，用于区分“用户改步骤”与“标题等无关编辑”。
  const lastAssistantPrefsRef = useRef<{
    processing: ProcessingStep[];
    subtitle: SubtitleChoice | null;
  } | null>(null);
  const presetDirtyRef = useRef(false);
  const analysisContextRef = useRef<Record<string, unknown>>({});
  const assistantAnalysis = useAssistantAnalysis({
    contextType: "job",
    contextRef: analysisContextRef,
    onCorrection: (correction) => {
      setCorrection(correction);
      // 概要预览成功即把识别信息（含 IMDb 号）记录到任务，无需等手动确认。
      const patch: Record<string, unknown> = {};
      if (correction.titleZh?.trim())
        patch.movieTitle = correction.titleZh.trim();
      if (correction.titleEn?.trim())
        patch.movieTitleEn = correction.titleEn.trim();
      if (
        typeof correction.year === "number" &&
        Number.isFinite(correction.year) &&
        correction.year >= 1920
      )
        patch.movieYear = correction.year;
      if (correction.imdbId?.trim())
        patch.movieImdbId = correction.imdbId.trim();
      if (Object.keys(patch).length === 0 || !jobId) return;
      // 不主动刷新任务查询，避免把用户在分析期间的选择重置回任务基线。
      void fetch(`/api/jobs/${jobId}/metadata`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch),
      })
        .then(async (response) => {
          if (!response.ok) return;
          const updated = await response.json().catch(() => null);
          if (updated && typeof updated === "object") {
            // 分析回写后立即同步当前查询缓存，避免基本信息栏继续显示旧的 null IMDb。
            queryClient.setQueryData(getGetJobQueryKey(jobId), updated);
          }
        })
        .catch(() => {});
    },
  });
  const promptInputRef = useRef<HTMLTextAreaElement>(null);
  const promptFocusSeenRef = useRef(assistantAnalysis.promptFocusRequest);

  useEffect(() => {
    if (assistantAnalysis.promptFocusRequest === promptFocusSeenRef.current)
      return;
    promptFocusSeenRef.current = assistantAnalysis.promptFocusRequest;
    const frame = window.requestAnimationFrame(() =>
      promptInputRef.current?.focus(),
    );
    return () => window.cancelAnimationFrame(frame);
  }, [assistantAnalysis.promptFocusRequest]);

  // wouter 在 /jobs/:id 之间切换不会重新挂载 JobDetail，所有 useState/ref 都会
  // 残留到下一个任务（例如上个任务点过的字幕策略高亮、助手面板、分析结果）。
  // 这里在任务切换时统一重置，保证字幕策略区严格显示当前任务的实际模式。
  useEffect(() => {
    setSubtitleModeOverride(null);
    setEffectivePipeline(null);
    lastAssistantPrefsRef.current = null;
    assistantPrefsRef.current = null;
    assistantExecutionRef.current = { processing: [], subtitle: null };
    assistantExecutionDirtyRef.current = false;
    presetDirtyRef.current = false;
    setAssistantOpen(true);
    setCorrection(null);
    setChapterSamplePosition("middle");
    setDetailsDrawerOpen(true);
    setDetailsOpen(false);
    setOverviewOpen(false);
    setParamsOpen(false);
    assistantAnalysis.setPrompt("");
    assistantAnalysis.setPromptOpen(false);
    assistantAnalysis.setAnalysisResult(null);
    assistantAnalysis.setAnalysisMetadata(null);
    assistantAnalysis.setAnalysisOpen(false);
    assistantAnalysis.setAnalysisPosterUrl(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [jobId]);

  useEffect(() => {
    setEffectivePipeline(null);
  }, [jobId]);

  const presetOptions = useMemo(
    () =>
      compressionPresets.map((preset) => ({
        id: preset.id,
        label: t(preset.labelKey),
      })),
    [compressionPresets, t],
  );

  const scrollToDrawerSection = (testId: string) => {
    requestAnimationFrame(() => {
      document
        .querySelector(`[data-testid="${testId}"]`)
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  };
  const openQualityPanel = () => {
    setDetailsDrawerOpen(true);
    setParamsOpen(true);
    setTimeout(() => scrollToDrawerSection("job-params-section"), 80);
  };

  // 章节预览与其他步骤同时选择时，为当前任务源创建独立的章节预览任务。
  const buildChapterPreviewJobBody = (
    position: "middle" | "start" | "end",
  ): Record<string, unknown> => {
    let plan: Record<string, unknown> = {};
    try {
      plan = job?.selectionPlan
        ? (JSON.parse(job.selectionPlan) as Record<string, unknown>)
        : {};
    } catch {
      /* 使用空计划 */
    }
    const analysis = (plan.analysis ?? {}) as Record<string, unknown>;
    if (job?.mediaType && job.mediaType !== "video") {
      const video = Array.isArray(plan.video) ? plan.video : [];
      const audio = Array.isArray(plan.audio) ? plan.audio : [];
      const subtitle = Array.isArray(plan.subtitle) ? plan.subtitle : [];
      const chapterCount = Array.isArray(plan.chapters)
        ? plan.chapters.length
        : 0;
      const chapterArr =
        chapterCount > 0
          ? Array.from({ length: chapterCount }, (_, index) => index)
          : [0];
      return {
        filePath: job.filePath,
        subtitleMode: "skip",
        mediaType: job.mediaType,
        processingMode: "chapterPreview",
        outputMode: "compress",
        mainTrackPath: job.mainTrackPath ?? undefined,
        selectedStreams: JSON.stringify([...video, ...audio, ...subtitle]),
        selectedChapters: JSON.stringify(chapterArr),
        selectionPlan: JSON.stringify({
          ...plan,
          chapterSamplePosition: position,
        }),
        analysisId:
          typeof analysis.analysisId === "string"
            ? analysis.analysisId
            : undefined,
        sourceFingerprint:
          typeof plan.sourceFingerprint === "string"
            ? plan.sourceFingerprint
            : undefined,
        selectedTitleId:
          typeof analysis.titleId === "string" ? analysis.titleId : undefined,
      };
    }
    return {
      filePath: job?.filePath ?? "",
      subtitleMode: "skip",
      mediaType: "video",
      processingMode: "chapterPreview",
      outputMode: "compress",
      selectedStreams: job?.selectedStreams ?? undefined,
      selectedChapters: "[]",
      selectionPlan: JSON.stringify({
        version: 1,
        chapterSamplePosition: position,
      }),
    };
  };
  const updateJobSubtitleMode = async (mode: string) => {
    try {
      const response = await fetch(`/api/jobs/${jobId}/subtitle-mode`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subtitleMode: mode }),
      });
      const body = (await response.json().catch(() => ({}))) as {
        error?: string;
      };
      if (!response.ok)
        throw new Error(body.error ?? `HTTP ${response.status}`);
      setSubtitleModeOverride(mode);
      queryClient.invalidateQueries({ queryKey: getGetJobQueryKey(jobId) });
      toast({
        title: t("jobDetail.subtitleModeSaved", {
          mode: t(
            mode === "auto"
              ? "assistant.optionAuto"
              : mode === "extract"
                ? "assistant.optionExtract"
                : mode === "whisper"
                  ? "assistant.optionWhisper"
                  : mode === "transcribe_translate"
                    ? "assistant.optionTranscribeTranslate"
                    : mode === "ocr"
                      ? "assistant.optionOcr"
                      : mode === "bilingual"
                        ? "assistant.optionBilingual"
                        : "assistant.optionSkip",
          ),
        }),
        description: t("jobDetail.subtitleModeRerunHint"),
      });
    } catch (error) {
      toast({
        title: t("jobDetail.subtitleModeFailed"),
        description: error instanceof Error ? error.message : String(error),
      });
    }
  };

  const { data: job } = useGetJob(jobId, {
    query: {
      refetchInterval: 3000,
      enabled: !!jobId,
      queryKey: getGetJobQueryKey(jobId),
    },
  });
  const { data: config } = useGetConfig({
    query: { queryKey: getGetConfigQueryKey() },
  });
  const aiAvailable = !!(
    config?.deepseekApiKey ||
    config?.openaiApiKey ||
    config?.siliconflowApiKey ||
    config?.zhipuApiKey ||
    config?.moonshotApiKey ||
    config?.qwenApiKey ||
    config?.groqApiKey ||
    config?.geminiApiKey
  );
  const { data: logs } = useGetJobLogs(jobId, {
    query: {
      refetchInterval: 3000,
      enabled: !!jobId,
      queryKey: getGetJobLogsQueryKey(jobId),
    },
  });
  const updateConfig = useUpdateConfig();

  const genFlags = useMemo(() => {
    const raw = job as
      | {
          generateReadme?: boolean;
          generatePoster?: boolean;
          generateReview?: boolean;
        }
      | undefined;
    return {
      generateReadme: raw?.generateReadme === true,
      generatePoster: raw?.generatePoster === true,
      generateReview: raw?.generateReview === true,
    };
  }, [job]);

  const selectionPlan = useMemo(() => {
    if (!job?.selectionPlan) return null;
    try {
      return JSON.parse(job.selectionPlan) as {
        compressionRationale?: string;
        estimatedOutputBytes?: number | null;
        presetId?: string | null;
        chapterSamplePosition?: "middle" | "start" | "end";
      };
    } catch {
      return null;
    }
  }, [job?.selectionPlan]);

  useEffect(() => {
    if (
      selectionPlan?.chapterSamplePosition === "start" ||
      selectionPlan?.chapterSamplePosition === "end"
    ) {
      setChapterSamplePosition(selectionPlan.chapterSamplePosition);
    }
  }, [selectionPlan?.chapterSamplePosition]);

  // 详情默认选中压缩预设：工作流计划带出的 presetId 优先，其次按来源类型（DVD→DVD转制）
  useEffect(() => {
    if (!job) return;
    if (
      typeof job.selectionPlan === "string" &&
      job.selectionPlan.includes("smart-workflow-v1")
    ) {
      setSelectedPresetLabel("");
      return;
    }
    setSelectedPresetLabel(
      (current) =>
        current ||
        selectionPlan?.presetId ||
        (job.mediaType === "dvd"
          ? "dvd-convert"
          : job.mediaType === "bluray" || job.mediaType === "iso"
            ? "bluray-collection"
            : "balanced"),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [job?.id, job?.mediaType]);

  const isWorkflowJob = useMemo(
    () =>
      typeof job?.selectionPlan === "string" &&
      job.selectionPlan.includes("smart-workflow-v1"),
    [job?.selectionPlan],
  );

  // Smart-workflow jobs are review drafts: show the controls immediately, without
  // restoring the workflow's recommendation as an active execution choice.
  useEffect(() => {
    if (isWorkflowJob) {
      setAssistantOpen(true);
      setDetailsDrawerOpen(true);
    }
  }, [isWorkflowJob, jobId]);

  const pipelineSteps = useMemo(() => {
    if (!job?.pipelineSteps) return [] as string[];
    try {
      const parsed = JSON.parse(job.pipelineSteps) as { steps?: string[] };
      return Array.isArray(parsed?.steps) ? parsed.steps : [];
    } catch {
      return [];
    }
  }, [job?.pipelineSteps]);

  // 智能助手面板的初始值（与任务当前状态一致），用于判断用户是否真的改过。
  const assistantBaselineProcessing = useMemo<ProcessingStep[]>(() => {
    if (pipelineSteps.length > 0) {
      return pipelineSteps.filter(
        (step): step is ProcessingStep =>
          step === "compress" ||
          step === "remux" ||
          step === "subtitle" ||
          step === "chapterPreview",
      );
    }
    if (job?.processingMode === "remux") return ["remux"];
    if (job?.processingMode === "compress") return ["compress"];
    if (job?.processingMode === "chapterPreview") return ["chapterPreview"];
    if (job?.processingMode === "none") return ["subtitle"];
    return [];
  }, [job?.processingMode, pipelineSteps]);
  const assistantBaselineSubtitle: SubtitleChoice | null = isWorkflowJob
    ? null
    : job?.subtitleMode === "whisper"
      ? "whisper"
      : job?.subtitleMode === "skip"
        ? "skip"
        : job?.subtitleMode === "extract"
          ? "extract"
          : job?.subtitleMode === "transcribe_translate"
            ? "transcribe_translate"
            : job?.subtitleMode === "ocr"
              ? "ocr"
              : job?.subtitleMode === "bilingual"
                ? "bilingual"
                : "auto";

  // 点击什么出现什么：详情栏只展示与任务流水线相关的区块（压缩预设 / 字幕策略）
  const activePipeline = effectivePipeline ?? pipelineSteps;
  // 用户在智能助手中调整过流程（effectivePipeline 非 null）后，以用户选择为准；
  // 未调整过才回退到任务原始状态（processingMode / subtitleMode）。
  const pipelineHasCompress =
    effectivePipeline !== null
      ? activePipeline.includes("compress")
      : activePipeline.length > 0
        ? activePipeline.includes("compress")
        : job?.processingMode === "compress";
  const pipelineHasSubtitle =
    effectivePipeline !== null
      ? activePipeline.includes("subtitle")
      : activePipeline.length > 0
        ? activePipeline.includes("subtitle")
        : (job?.processingMode === "none" && job?.subtitleMode !== "skip") ||
          (!!job?.subtitleMode && job.subtitleMode !== "skip");
  const pipelineHasChapterPreview =
    effectivePipeline !== null
      ? activePipeline.includes("chapterPreview")
      : activePipeline.length > 0
        ? activePipeline.includes("chapterPreview")
        : job?.processingMode === "chapterPreview";
  const pipelineHasRemux =
    effectivePipeline !== null
      ? activePipeline.includes("remux")
      : activePipeline.length > 0
        ? activePipeline.includes("remux")
        : job?.processingMode === "remux";
  // 任务参数面板跟随智能助手实时选择：点压缩显示压缩预设；只选字幕/未选压缩时显示字幕说明。
  const decisionProcessingMode =
    activePipeline.length > 0
      ? activePipeline.includes("chapterPreview")
        ? "chapterPreview"
        : activePipeline.includes("compress")
          ? "compress"
          : activePipeline.includes("remux")
            ? "remux"
            : "none"
      : (job?.processingMode ?? "none");

  const pipelineStepLabel = (step: string) =>
    step === "remux"
      ? t("assistant.optionRemux")
      : step === "chapterPreview"
        ? t("assistant.optionChapterPreview")
        : step === "subtitle"
          ? t("assistant.optionSubtitleOnly")
          : t("assistant.optionCompress");

  const applyAiOptionsToAll = async () => {
    try {
      const response = await fetch("/api/jobs/ai-options/apply-all", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(genFlags),
      });
      const body = (await response.json().catch(() => ({}))) as {
        applied?: number;
        error?: string;
      };
      if (!response.ok)
        throw new Error(body.error ?? `HTTP ${response.status}`);
      toast({
        title: t("jobDetail.applyToAllDone", { count: body.applied ?? 0 }),
      });
    } catch (error) {
      toast({
        title: t("jobDetail.applyToAllFailed"),
        description: error instanceof Error ? error.message : String(error),
      });
    }
  };

  const { startJob, cancelJob, retryJob, deleteJob, handleAction, pauseJob } =
    useJobActions(jobId);

  useEffect(() => {
    const reloadPresets = () => setCompressionPresets(loadCompressionPresets());
    window.addEventListener("storage", reloadPresets);
    window.addEventListener(PRESET_CHANGED_EVENT, reloadPresets);
    return () => {
      window.removeEventListener("storage", reloadPresets);
      window.removeEventListener(PRESET_CHANGED_EVENT, reloadPresets);
      if (presetSaveTimerRef.current) clearTimeout(presetSaveTimerRef.current);
    };
  }, []);

  useEffect(() => {
    editableJobPresetRef.current = editableJobPreset;
  }, [editableJobPreset]);

  useEffect(() => {
    if (!config) return;
    if (isWorkflowJob) {
      // A workflow job owns its preset choice. Do not erase the user's
      // selection when the preset also updates the global config query.
      if (!presetDirtyRef.current) setSelectedPresetLabel("");
      return;
    }
    // 同组任务统一：本任务未被手动修改时，预设显示跟随全局压缩配置（改一个 → 全组同步）
    if (presetDirtyRef.current) return;
    const match = compressionPresets.find(
      (preset) =>
        preset.values.encoder === config.encoder &&
        preset.values.crf === config.crf &&
        (preset.values.encoderPreset || "slow") ===
          (config.encoderPreset || "slow") &&
        (preset.values.outputResolution || "source") ===
          (config.outputResolution || "source"),
    );
    setSelectedPresetLabel(match?.id ?? "");
    setEditableJobPreset({
      encoder: config.encoder || "",
      crf: String(config.crf ?? ""),
      encoderPreset: config.encoderPreset || "slow",
      outputResolution: config.outputResolution || "source",
    });
  }, [config, compressionPresets]);

  // 切换任务时重置“本任务已手动修改”标记，回到跟随全局配置
  useEffect(() => {
    presetDirtyRef.current = false;
  }, [jobId]);

  const onCompressionPresetSelect = (preset: ArchivePreset) => {
    presetDirtyRef.current = true;
    setSelectedPresetLabel(preset.id);
    setEditableJobPreset({
      encoder: preset.values.encoder,
      crf: String(preset.values.crf),
      encoderPreset: preset.values.encoderPreset || "slow",
      outputResolution: preset.values.outputResolution || "source",
    });
    void updateConfig
      .mutateAsync({ data: presetConfigValues(preset) })
      .catch(() => {});
  };

  const onEditableJobPresetChange = (
    next: Partial<typeof editableJobPreset>,
  ) => {
    presetDirtyRef.current = true;
    setSelectedPresetLabel(t("jobDetail.customPreset"));
    setEditableJobPreset((current) => ({ ...current, ...next }));
    if (presetSaveTimerRef.current) clearTimeout(presetSaveTimerRef.current);
    presetSaveTimerRef.current = setTimeout(() => {
      const merged = { ...editableJobPresetRef.current, ...next };
      void updateConfig
        .mutateAsync({
          data: {
            encoder: merged.encoder || undefined,
            crf: merged.crf ? Number(merged.crf) : undefined,
            encoderPreset: merged.encoderPreset || undefined,
            outputResolution: merged.outputResolution || undefined,
          },
        })
        .catch(() => {});
    }, 500);
  };

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    // The log grows inside the details drawer; scroll the drawer (or nearest
    // scrollable ancestor) to the newest entry so only one scrollbar is used.
    const scroller =
      el.closest<HTMLElement>('[data-testid="job-details-drawer"]') ??
      el.parentElement;
    if (scroller) scroller.scrollTop = scroller.scrollHeight;
  }, [logs]);

  useEffect(() => {
    if (!job) return;
    let cancelled = false;
    fetch(`/api/jobs/${jobId}/streams`)
      .then((response) => (response.ok ? response.json() : null))
      .then((data) => {
        if (cancelled) return;
        const tracks: EmbeddedSubtitleTrack[] = Array.isArray(data?.streams)
          ? data.streams
              .filter(
                (stream: { codecType?: string }) =>
                  stream.codecType === "subtitle",
              )
              .map(
                (stream: {
                  index: number;
                  codecName?: string;
                  language?: string | null;
                  title?: string | null;
                }) => ({
                  index: stream.index,
                  codecName: stream.codecName ?? "subtitle",
                  language: stream.language,
                  title: stream.title,
                }),
              )
          : [];
        setEmbeddedSubtitleTracks(tracks);
        setSourceInfo({
          streams: Array.isArray(data?.streams) ? data.streams : [],
          chapters: Array.isArray(data?.chapters) ? data.chapters : [],
          duration: typeof data?.duration === "number" ? data.duration : null,
          formatName:
            typeof data?.formatName === "string" ? data.formatName : null,
          bitRate: typeof data?.bitRate === "string" ? data.bitRate : null,
        });
      })
      .catch(() => {
        if (!cancelled) {
          setEmbeddedSubtitleTracks([]);
          setSourceInfo(null);
        }
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [jobId, job?.id]);

  useEffect(() => {
    if (!job) return;
    let cancelled = false;
    fetch(`/api/jobs/${jobId}/subtitles`)
      .then((response) => (response.ok ? response.json() : null))
      .then(
        (
          body: {
            files?: Array<{
              name: string;
              path: string;
              kind: "original" | "translated" | "other";
            }>;
          } | null,
        ) => {
          if (cancelled) return;
          const files = Array.isArray(body?.files) ? body.files : [];
          setExternalSubtitleFiles(files);
          setSubtitlePreviewKind((current) => {
            if (current !== "off") return current;
            const preferred =
              files.find((file) => file.kind === "translated") ??
              files.find((file) => file.kind === "original") ??
              files[0];
            return preferred ? `file:${preferred.name}` : current;
          });
        },
      )
      .catch(() => {
        if (!cancelled) setExternalSubtitleFiles([]);
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [jobId, job?.id]);

  // Compression jobs auto-open the details drawer so the preset picker is visible.
  useEffect(() => {
    if (job?.processingMode === "compress" && !detailsDrawerOpen) {
      setDetailsDrawerOpen(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [job?.processingMode]);

  useEffect(() => {
    let cancelled = false;
    if (subtitlePreviewKind === "off") {
      setSubtitleCues([]);
      return;
    }
    if (subtitlePreviewKind.startsWith("embedded:")) {
      const trackIndex = Number(subtitlePreviewKind.split(":")[1] ?? "-1");
      const track = embeddedSubtitleTracks.find(
        (item) => item.index === trackIndex,
      );
      if (track && isImageSubtitleCodec(track.codecName)) {
        // Image-based tracks are burned into the preview stream, not overlaid as text.
        setSubtitleCues([]);
        return;
      }
    }
    const url = subtitlePreviewKind.startsWith("embedded:")
      ? `/api/jobs/${jobId}/subtitle-vtt?stream=${encodeURIComponent(subtitlePreviewKind.split(":")[1] ?? "")}`
      : subtitlePreviewKind.startsWith("file:")
        ? `/api/jobs/${jobId}/subtitle-preview?file=${encodeURIComponent(subtitlePreviewKind.slice("file:".length))}`
        : `/api/jobs/${jobId}/subtitle-preview?kind=${subtitlePreviewKind === "translated" ? "translated" : "subtitle"}`;
    fetch(url)
      .then((response) => (response.ok ? response.text() : ""))
      .then((text) => {
        if (!cancelled) setSubtitleCues(parseSubtitleCues(text));
      })
      .catch(() => {
        if (!cancelled) setSubtitleCues([]);
      });
    return () => {
      cancelled = true;
    };
  }, [subtitlePreviewKind, embeddedSubtitleTracks, jobId]);

  const openOutputPath = async (p: string) => {
    const hostPath = toHostPath(p, config) || p;
    try {
      await openDesktopPath(hostPath);
      toast({ title: t("common.folderOpened") });
    } catch (e: unknown) {
      toast({
        title: t("common.openFailed"),
        description: e instanceof Error ? e.message : t("common.unknownError"),
        variant: "destructive",
      });
    }
  };

  const selectEmbeddedTrack = (track: EmbeddedSubtitleTrack) => {
    const burnIndex = isImageSubtitleCodec(track.codecName)
      ? track.index
      : null;
    setSubtitlePreviewKind(`embedded:${track.index}`);
    const player = playerRef.current;
    if (player) player.rebuild(player.getCurrentTime(), burnIndex);
  };

  const clearBurnedSubtitleIfNeeded = () => {
    const player = playerRef.current;
    if (player) player.rebuild(player.getCurrentTime(), null);
  };

  // 打开助手时，以任务当前 AI 生成开关为初始值
  useEffect(() => {
    if (assistantOpen) {
      const raw = job as
        | {
            generateReadme?: boolean;
            generatePoster?: boolean;
            generateReview?: boolean;
          }
        | undefined;
      assistantGenRef.current = {
        generateReadme: raw?.generateReadme === true,
        generatePoster: raw?.generatePoster === true,
        generateReview: raw?.generateReview === true,
      };
    }
  }, [assistantOpen, job]);

  if (!job)
    return (
      <div className="p-8 text-center text-muted-foreground">
        {t("jobDetail.loading")}
      </div>
    );

  const filename = job.filePath.split(/[/\\]/).pop() ?? job.filePath;
  const sourceStem = filename.replace(/\.[^.]+$/, "");
  const persistedMetadata = parseAssistantMetadata(
    (job as typeof job & { movieMetadata?: string | null }).movieMetadata,
  );
  // Older tasks may have an invalid movieOverview column (for example, only an
  // IMDb identity line). The structured snapshot is the durable fallback.
  const persistedOverview = resolveAnalysisOverview(
    job.movieOverview,
    persistedMetadata?.overview,
  );
  analysisContextRef.current = {
    jobId,
    status: job.status,
    processingMode: job.processingMode,
    mediaType: job.mediaType,
    filePath: job.filePath,
    outputPath: job.outputPath,
    durationSeconds: job.durationSeconds,
    errorMessage: job.errorMessage,
  };
  const isRunning = [
    "scanning",
    "transcribing",
    "compressing",
    "remuxing",
  ].includes(job.status);
  const previewVideoStream = sourceInfo?.streams.find(
    (stream) => stream.codecType === "video",
  );
  const previewAspectRatio = streamAspectRatio(previewVideoStream);
  const rawPlayable = isBrowserPlayablePreview(
    job.filePath,
    previewVideoStream?.codecName,
  );
  const previewTranscodeSrc = `/api/jobs/${jobId}/preview.mp4`;
  const previewRawSrc = `/api/jobs/${jobId}/preview/raw`;
  const subtitleControls = (
    <>
      <Button
        variant={subtitlePreviewKind === "off" ? "default" : "outline"}
        size="sm"
        className="h-7 shrink-0 px-1.5 text-[11px]"
        onClick={() => {
          setSubtitlePreviewKind("off");
          clearBurnedSubtitleIfNeeded();
        }}
      >
        {t("jobDetail.subtitleOff")}
      </Button>
      {externalSubtitleFiles.length > 0 ? (
        externalSubtitleFiles.map((file) => (
          <Button
            key={file.name}
            variant={
              subtitlePreviewKind === `file:${file.name}`
                ? "default"
                : "outline"
            }
            size="sm"
            className="h-7 max-w-[12rem] shrink-0 truncate px-1.5 text-[11px]"
            title={file.path}
            onClick={() => {
              setSubtitlePreviewKind(`file:${file.name}`);
              clearBurnedSubtitleIfNeeded();
            }}
          >
            {file.kind === "translated"
              ? t("jobDetail.translatedSubtitle")
              : file.kind === "original"
                ? t("jobDetail.originalSubtitle")
                : file.name}
          </Button>
        ))
      ) : (
        <>
          {job.subtitlePath && (
            <Button
              variant={
                subtitlePreviewKind === "subtitle" ? "default" : "outline"
              }
              size="sm"
              className="h-7 shrink-0 px-1.5 text-[11px]"
              onClick={() => {
                setSubtitlePreviewKind("subtitle");
                clearBurnedSubtitleIfNeeded();
              }}
            >
              {t("jobDetail.originalSubtitle")}
            </Button>
          )}
          {job.translatedSubtitlePath && (
            <Button
              variant={
                subtitlePreviewKind === "translated" ? "default" : "outline"
              }
              size="sm"
              className="h-7 shrink-0 px-1.5 text-[11px]"
              onClick={() => {
                setSubtitlePreviewKind("translated");
                clearBurnedSubtitleIfNeeded();
              }}
            >
              {t("jobDetail.translatedSubtitle")}
            </Button>
          )}
        </>
      )}
      {embeddedSubtitleTracks
        .slice(0, showAllTracks ? undefined : 3)
        .map((track) => (
          <Button
            key={track.index}
            variant={
              subtitlePreviewKind === `embedded:${track.index}`
                ? "default"
                : "outline"
            }
            size="sm"
            className="h-7 max-w-[12rem] shrink-0 truncate px-1.5 text-[11px]"
            title={
              track.language && track.language !== "und"
                ? `${track.index} · ${track.language}`
                : String(track.index)
            }
            onClick={() => selectEmbeddedTrack(track)}
          >
            {t("jobDetail.embeddedTrack", { index: track.index })}
            {track.language && track.language !== "und"
              ? ` · ${track.language.toUpperCase()}`
              : ""}
          </Button>
        ))}
      {embeddedSubtitleTracks.length > 3 && (
        <Button
          variant="ghost"
          size="sm"
          className="h-7 px-1.5 text-[11px]"
          onClick={() => setShowAllTracks((value) => !value)}
        >
          {showAllTracks
            ? t("jobDetail.embeddedTrackCollapse")
            : t("jobDetail.embeddedTrackMore", {
                count: embeddedSubtitleTracks.length - 3,
              })}
        </Button>
      )}
    </>
  );

  return (
    <div className="mx-auto flex h-full min-h-0 w-full min-w-0 max-w-full flex-col gap-4 overflow-hidden">
      <div
        className="flex flex-nowrap items-center justify-between gap-3 rounded-xl border bg-card/80 px-3 py-2"
        data-testid="job-detail-toolbar"
      >
        <div className="flex min-w-0 flex-1 items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            asChild
            className="h-8 w-8 shrink-0"
          >
            <Link href="/jobs">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="truncate text-lg font-bold tracking-tight">
                {job.movieTitle || filename}
              </h2>
              {job.movieYear && (
                <span className="text-sm text-muted-foreground">
                  ({job.movieYear})
                </span>
              )}
              <span>
                <JobStatusBadge
                  status={job.status}
                  processingMode={job.processingMode}
                  subtitleMode={job.subtitleMode}
                />
              </span>
              <span className="inline-flex items-center gap-1 rounded-full border border-primary/30 bg-primary/10 px-2 py-0.5 text-xs text-primary">
                <Film className="h-3.5 w-3.5" />
                {t("jobDetail.videoSubtitlePreview")}
              </span>
            </div>
            <p
              className="mt-0.5 max-w-3xl truncate font-mono text-xs text-muted-foreground"
              title={job.filePath}
            >
              {filename}
            </p>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2 overflow-x-auto scrollbar-none">
          {isWorkflowJob && (
            <span className="inline-flex shrink-0 items-center gap-1.5 rounded-md border border-amber-400/30 bg-amber-400/5 px-2.5 py-1.5 text-[11px] text-amber-400">
              <Workflow className="h-3.5 w-3.5" />
              {t("workflow.badge")}
            </span>
          )}
          <Button
            size="sm"
            variant="outline"
            onClick={() => setAssistantOpen((open) => !open)}
            data-testid="job-toolbar-assistant"
            className={cn(
              "border-amber-400/40 text-amber-400 hover:text-amber-300",
              assistantOpen && "bg-amber-400/15",
            )}
          >
            <Bot className="mr-1.5 h-4 w-4" />
            {t("jobDetail.intelligentAssistant")}
          </Button>
          <Button
            size="sm"
            variant={detailsDrawerOpen ? "default" : "outline"}
            onClick={() => setDetailsDrawerOpen((open) => !open)}
            data-testid="job-details-toggle"
          >
            <Info className="mr-1.5 h-4 w-4" />
            {t("jobDetail.details")}
          </Button>
          {job.status === "pending" && (
            <Button
              size="sm"
              disabled={isWorkflowJob && pipelineSteps.length === 0}
              title={
                isWorkflowJob && pipelineSteps.length === 0
                  ? t("jobs.selectProcessingFirst")
                  : undefined
              }
              onClick={() => handleAction(startJob, t("jobs.taskStarted"))}
              data-testid="btn-start"
            >
              <Play className="mr-1.5 h-4 w-4" />
              {t("jobs.startTitle")}
            </Button>
          )}
          {isRunning && (
            <>
              <Button
                size="sm"
                variant="outline"
                className="text-sky-500"
                onClick={() => void pauseJob()}
                data-testid="btn-pause"
              >
                <PauseCircle className="mr-1.5 h-4 w-4" />
                {t("jobs.pauseTitle")}
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="text-orange-500"
                onClick={() => handleAction(cancelJob, t("jobs.taskCancelled"))}
                data-testid="btn-cancel"
              >
                <Square className="mr-1.5 h-4 w-4" />
                {t("jobs.cancelTitle")}
              </Button>
            </>
          )}
          {["error", "done"].includes(job.status) && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleAction(retryJob, t("jobs.taskRetried"))}
              data-testid="btn-retry"
            >
              <RotateCcw className="mr-1.5 h-4 w-4" />
              {t("jobs.retryTitle")}
            </Button>
          )}
          {!isRunning && (
            <Button
              size="sm"
              variant="destructive"
              onClick={() => handleAction(deleteJob, t("jobs.taskDeleted"), true)}
              data-testid="btn-delete"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>

      {isWorkflowJob && (
        <div
          className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-400/25 bg-amber-400/5 px-3 py-2"
          data-testid="workflow-confirm-banner"
        >
          <span className="flex flex-wrap items-center gap-2">
            <Workflow className="h-4 w-4 text-amber-400" />
            <span className="text-sm font-medium text-amber-400">
              {t("workflow.badge")}
            </span>
            <span className="text-xs text-muted-foreground">
              {t("workflow.confirmHint")}
            </span>
          </span>
          <Button
            type="button"
            size="sm"
            onClick={() => setLocation("/jobs")}
            data-testid="btn-workflow-confirm"
          >
            {t("workflow.confirmBackQueue")}
          </Button>
        </div>
      )}

      {assistantOpen && (
        <AssistantPanel
          contextType="job"
          jobId={jobId}
          generateOptions={genFlags}
          onGenerateOptionsChange={(options) => {
            assistantGenRef.current = options;
          }}
          allowRemux={job?.mediaType !== "video"}
          aiAvailable={aiAvailable}
          posterUrl={job?.moviePoster ?? null}
          sourceName={sourceStem}
          presets={presetOptions}
          selectedPresetId={selectedPresetLabel || undefined}
          expandMode="external"
          analysisPlacement="video-overlay"
          analysisPortalTarget={analysisOverlayTarget}
          promptPlacement="drawer"
          prompt={assistantAnalysis.prompt}
          promptOpen={assistantAnalysis.promptOpen}
          promptFocusRequest={assistantAnalysis.promptFocusRequest}
          promptAttention={assistantAnalysis.promptAttention}
          onPromptToggle={assistantAnalysis.setPromptOpen}
          onPromptFocus={assistantAnalysis.requestPromptFocus}
          onPromptChange={assistantAnalysis.setPrompt}
          onAnalyze={(fields) => void assistantAnalysis.analyze(fields)}
          analyzing={assistantAnalysis.analyzing}
          analysisResult={assistantAnalysis.analysisResult}
          analysisError={assistantAnalysis.analysisError}
          analysisPosterUrl={assistantAnalysis.analysisPosterUrl}
          metadata={
            job
              ? ({
                  movieTitle: job.movieTitle,
                  movieTitleEn: job.movieTitleEn,
                  movieYear: job.movieYear,
                  movieImdbId:
                    correction?.imdbId ??
                    (job as typeof job & { movieImdbId?: string | null })
                      .movieImdbId,
                  movieRating: job.movieRating,
                  movieDirector: job.movieDirector,
                  movieGenres: job.movieGenres,
                  metadataSnapshot:
                    assistantAnalysis.analysisMetadata ??
                    parseAssistantMetadata(
                      (job as typeof job & { movieMetadata?: string | null })
                        .movieMetadata,
                    ),
                } satisfies AssistantMetadata)
              : undefined
          }
          analysisOpen={assistantAnalysis.analysisOpen}
          onAnalysisOpenChange={(open) => {
            assistantAnalysis.setAnalysisOpen(open);
            if (open) setOverviewOpen(false);
          }}
          correction={correction}
          preferences={{
            year: job?.movieYear ?? null,
            imdbId:
              (job as typeof job & { movieImdbId?: string | null })
                ?.movieImdbId ?? "",
            processing: (() => {
              try {
                const parsed = job?.pipelineSteps
                  ? (JSON.parse(job.pipelineSteps) as { steps?: string[] })
                  : null;
                if (Array.isArray(parsed?.steps) && parsed.steps.length > 0) {
                  return parsed.steps.filter(
                    (
                      step,
                    ): step is
                      | "compress"
                      | "remux"
                      | "subtitle"
                      | "chapterPreview" =>
                      step === "compress" ||
                      step === "remux" ||
                      step === "subtitle" ||
                      step === "chapterPreview",
                  );
                }
              } catch {
                /* fall through to mode-based default */
              }
              return job?.processingMode === "remux"
                ? ["remux"]
                : job?.processingMode === "compress"
                  ? ["compress"]
                  : job?.processingMode === "chapterPreview"
                    ? ["chapterPreview"]
                    : [];
            })(),
            subtitle: assistantBaselineSubtitle,
          }}
          context={analysisContextRef.current}
          onFeatureClick={(feature) => {
            // 点选步骤 → 打开详情抽屉并滚动到对应区块；取消（null）不动作。
            // 详情区跟随多选显示所有已选区块，不再“只显示最后点击的一块”。
            if (!feature) return;
            setDetailsDrawerOpen(true);
            if (feature === "preset") {
              setParamsOpen(true);
              setTimeout(() => scrollToDrawerSection("job-params-section"), 80);
            } else if (feature === "subtitle") {
              setTimeout(
                () => scrollToDrawerSection("job-subtitle-section"),
                80,
              );
            } else if (feature === "chapterPreview") {
              setDetailsOpen(true);
              setTimeout(
                () => scrollToDrawerSection("job-chapter-preview-section"),
                80,
              );
            } else if (feature === "remux") {
              setDetailsOpen(true);
              setTimeout(() => scrollToDrawerSection("job-remux-section"), 80);
            }
          }}
          onPreferencesChange={(prefs) => {
            // 标题/年代/IMDb 等编辑也会走到这里，但它们不应联动详情；
            // 只有处理流程或字幕策略真正变化时才打开详情抽屉。
            const prev = lastAssistantPrefsRef.current;
            const processingChanged =
              !prev ||
              JSON.stringify(prev.processing) !==
                JSON.stringify(prefs.processing);
            const subtitleChanged = !prev || prev.subtitle !== prefs.subtitle;
            // 首次同步（打开面板时的源名回填）不算用户操作，不联动详情。
            lastAssistantPrefsRef.current = {
              processing: [...prefs.processing],
              subtitle: prefs.subtitle,
            };
            assistantPrefsRef.current = {
              titleEn: prefs.titleEn,
              titleZh: prefs.titleZh,
              year: prefs.year,
              imdbId: prefs.imdbId,
            };
            const baselineChanged =
              JSON.stringify(prefs.processing) !==
                JSON.stringify(assistantBaselineProcessing) ||
              prefs.subtitle !== assistantBaselineSubtitle;
            assistantExecutionRef.current = {
              processing: [...prefs.processing],
              subtitle: prefs.subtitle,
            };
            if (baselineChanged) assistantExecutionDirtyRef.current = true;
            setEffectivePipeline(prefs.processing);
            if (!processingChanged && !subtitleChanged) return;
            // 只负责“步骤变化时打开详情抽屉”；展开/滚动由 onFeatureClick 精确处理，
            // 否则点字幕时会强制展开压缩参数区，与字幕区块的切换互相干扰。
            setDetailsDrawerOpen(true);
          }}
          onOpenQualityPanel={openQualityPanel}
          onConfirm={async () => {
            // 确认：把校对后的片名/年代、处理流程、字幕策略、画质预设真正应用到任务。
            const p = assistantPrefsRef.current;
            const execution = assistantExecutionRef.current;
            const processing = execution.processing;
            // 章节预览与其他步骤同时选择：主任务执行其余步骤，章节预览另建独立预览任务。
            const previewPlusOthers =
              processing.includes("chapterPreview") &&
              processing.some((step) => step !== "chapterPreview");
            const mainSteps = previewPlusOthers
              ? processing.filter((step) => step !== "chapterPreview")
              : processing;
            const body: Record<string, unknown> = {};
            if (p) {
              // 只有片名/年代确实改动过才提交，否则已完成任务会被“重建重跑”并跳过立即生成
              const titleZh = p.titleZh.trim() || job?.movieTitle || null;
              const titleEn = p.titleEn.trim() || job?.movieTitleEn || null;
              const year = p.year || null;
              const imdbId = p.imdbId.trim() || null;
              if (titleZh !== (job?.movieTitle ?? null))
                body.movieTitle = titleZh;
              if (titleEn !== (job?.movieTitleEn ?? null))
                body.movieTitleEn = titleEn;
              if (year !== (job?.movieYear ?? null)) body.movieYear = year;
              if (
                (imdbId ?? null) !==
                ((job as typeof job & { movieImdbId?: string | null })
                  ?.movieImdbId ?? null)
              )
                body.movieImdbId = imdbId;
            }
            if (assistantExecutionDirtyRef.current) {
              // 处理流程变化（含清空=不做任何视频处理）都提交：
              // 空数组也必须传给后端，否则任务会保留原处理模式继续压缩。
              if (
                JSON.stringify(processing) !==
                JSON.stringify(assistantBaselineProcessing)
              ) {
                body.pipelineSteps = mainSteps;
                if (processing.includes("chapterPreview")) {
                  body.chapterSamplePosition = chapterSamplePosition;
                }
              }
              if (execution.subtitle !== assistantBaselineSubtitle) {
                body.subtitleMode = execution.subtitle;
              }
            }
            if (presetDirtyRef.current) {
              body.presetId = selectedPresetLabel || null;
              const selectedPreset = compressionPresets.find(
                (preset) => preset.id === selectedPresetLabel,
              );
              if (selectedPreset) {
                body.compressionSettings = presetConfigValues(selectedPreset);
              } else if (selectedPresetLabel === "custom" && config) {
                body.compressionSettings = {
                  encoder: config.encoder,
                  crf: config.crf,
                  encoderPreset: config.encoderPreset,
                  encoderTune: config.encoderTune,
                  encoderProfile: config.encoderProfile,
                  encoderLevel: config.encoderLevel,
                  frameRate: config.frameRate,
                  outputResolution: config.outputResolution,
                };
              }
            }
            const gen = assistantGenRef.current;
            try {
              // 1) 持久化 AI 生成开关（任何状态的任务都可更新）
              await fetch(`/api/jobs/${jobId}/ai-options`, {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(gen),
              });
              // 2) 其他执行选项（片名/流程/字幕/预设）仅在确实改动时才提交，
              //    避免只勾选 AI 生成时把已完成任务重建成新任务重跑。
              if (Object.keys(body).length > 0) {
                const response = await fetch(`/api/jobs/${jobId}/execution`, {
                  method: "PATCH",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify(body),
                });
                const data = (await response.json().catch(() => ({}))) as {
                  id?: number;
                  recreated?: boolean;
                  error?: string;
                };
                if (!response.ok)
                  throw new Error(data.error ?? `HTTP ${response.status}`);
                queryClient.invalidateQueries({
                  queryKey: getGetJobQueryKey(jobId),
                });
                queryClient.invalidateQueries({
                  queryKey: getGetJobLogsQueryKey(jobId),
                });
                // 章节预览与其他步骤并存：主任务已应用，另建独立章节预览任务。
                if (previewPlusOthers) {
                  try {
                    const previewResponse = await fetch("/api/jobs", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify(
                        buildChapterPreviewJobBody(chapterSamplePosition),
                      ),
                    });
                    if (previewResponse.ok) {
                      const previewData = (await previewResponse
                        .json()
                        .catch(() => null)) as { id?: number } | null;
                      toast({
                        title: t("assistant.chapterPreviewJobCreated", {
                          id: previewData?.id ?? "",
                        }),
                      });
                    } else {
                      const previewError = (await previewResponse
                        .json()
                        .catch(() => null)) as { error?: string } | null;
                      toast({
                        title: t("assistant.chapterPreviewJobFailed"),
                        description: previewError?.error,
                        variant: "destructive",
                      });
                    }
                  } catch (error) {
                    toast({
                      title: t("assistant.chapterPreviewJobFailed"),
                      description:
                        error instanceof Error ? error.message : String(error),
                      variant: "destructive",
                    });
                  }
                }
                if (data.recreated && typeof data.id === "number") {
                  toast({
                    title: t("assistant.executionRecreated", { id: data.id }),
                  });
                  setAssistantOpen(false);
                  setLocation(`/jobs/${data.id}`);
                  startJob.mutateAsync({ id: data.id }).catch(() => {});
                  return;
                }
              }
              // 3) 已完成任务：立即生成所勾选的 Readme / 影评 / 海报
              if (job?.status === "done") {
                const tasks: Array<Promise<Response>> = [];
                if (gen.generateReadme)
                  tasks.push(
                    fetch(`/api/jobs/${jobId}/readme`, { method: "POST" }),
                  );
                if (gen.generateReview)
                  tasks.push(
                    fetch(`/api/jobs/${jobId}/review`, { method: "POST" }),
                  );
                if (gen.generatePoster)
                  tasks.push(
                    fetch(`/api/jobs/${jobId}/poster`, { method: "POST" }),
                  );
                if (tasks.length > 0) {
                  const results = await Promise.allSettled(tasks);
                  const okCount = results.filter(
                    (r) => r.status === "fulfilled" && (r.value as Response).ok,
                  ).length;
                  toast({
                    title: t("jobDetail.aiGenerateStarted"),
                    description:
                      okCount > 0
                        ? t("jobDetail.aiGenerateDone", { count: okCount })
                        : t("jobDetail.aiGenerateFailed"),
                  });
                  queryClient.invalidateQueries({
                    queryKey: getGetJobQueryKey(jobId),
                  });
                }
              }
              toast({ title: t("assistant.executionApplied") });
              setAssistantOpen(false);
            } catch (error) {
              toast({
                title: t("assistant.executionFailed"),
                description:
                  error instanceof Error ? error.message : String(error),
              });
            }
          }}
        />
      )}

      <div
        className={cn(
          "grid min-h-0 min-w-0 flex-1 gap-4",
          detailsDrawerOpen
            ? "md:grid-cols-[minmax(0,1fr)_minmax(16rem,22rem)] md:grid-rows-1"
            : "grid-cols-1 md:grid-rows-1",
        )}
      >
        <div className="relative min-w-0 space-y-4 md:h-full md:min-h-0">
          <div
            ref={setAnalysisOverlayTarget}
            className={cn(
              "absolute inset-0 z-30 overflow-hidden p-2 md:p-3",
              assistantAnalysis.analysisOpen
                ? "bg-background/95"
                : "pointer-events-none",
            )}
            data-testid="job-analysis-overlay"
          />
          <PreviewPlayerCard
            ref={playerRef}
            src={rawPlayable ? previewRawSrc : previewTranscodeSrc}
            metaUrl={`/api/jobs/${jobId}/preview/meta`}
            rawUrl={previewRawSrc}
            transcodeUrl={previewTranscodeSrc}
            nativeSeek={rawPlayable}
            // 详情预览也使用连续转码流，避免非原生格式按 5 秒片段换源造成卡顿。
            segmentMode={false}
            assistantOpen={assistantOpen}
            aspectRatio={previewAspectRatio}
            playing={previewPlaying}
            expanded={detailsDrawerOpen}
            fill={!detailsDrawerOpen}
            onPlayingChange={setPreviewPlaying}
            extraControls={subtitleControls}
            subtitleCues={subtitleCues}
          />
        </div>

        {detailsDrawerOpen && (
          <aside
            className="min-w-0 space-y-1.5 md:min-h-0 md:overflow-y-auto"
            data-testid="job-details-drawer"
          >
            {/* 提示词（默认收起，点击展开与详情栏同宽；分析按钮在助手条确认左侧） */}
            <div
              className="rounded-lg border bg-card/80"
              data-testid="job-prompt-section"
            >
              <button
                type="button"
                className="flex w-full items-center gap-1.5 px-3 py-2 text-left text-xs font-medium text-muted-foreground hover:text-foreground"
                onClick={() => assistantAnalysis.setPromptOpen((open) => !open)}
              >
                <span className="text-primary">
                  {assistantAnalysis.promptOpen ? "▾" : "▸"}
                </span>
                {t("assistant.promptLabel")}
                <span className="ml-auto text-[10px] text-muted-foreground/60">
                  {t("assistant.promptHint")}
                </span>
              </button>
              {assistantAnalysis.promptOpen && (
                <div className="border-t p-3">
                  <textarea
                    ref={promptInputRef}
                    autoFocus
                    disabled={!aiAvailable}
                    value={assistantAnalysis.prompt}
                    onChange={(e) =>
                      assistantAnalysis.setPrompt(e.currentTarget.value)
                    }
                    placeholder={t("assistant.placeholder")}
                    rows={2}
                    className={cn(
                      "w-full rounded-md border bg-background px-2 py-1.5 text-xs outline-none focus:border-primary/60 disabled:cursor-not-allowed disabled:opacity-50",
                      assistantAnalysis.promptAttention &&
                        "border-amber-400 ring-2 ring-amber-400/40",
                    )}
                  />
                </div>
              )}
            </div>
            <div className="flex items-center justify-between rounded-lg border bg-card/90 px-3 py-2 text-sm">
              <span className="font-semibold">
                {t("jobDetail.taskDetails")}
              </span>
              <div className="flex items-center gap-1">
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  className="h-7 px-2 text-[11px]"
                  onClick={() => void applyAiOptionsToAll()}
                  data-testid="btn-apply-ai-all"
                >
                  {t("jobDetail.applyToAll")}
                </Button>
                <Button
                  type="button"
                  variant={detailsPinned ? "default" : "ghost"}
                  size="icon"
                  className="h-7 w-7"
                  onClick={() => setDetailsPinned((value) => !value)}
                  aria-label={t("jobDetail.pinDetailsAria")}
                >
                  <Pin className="h-3.5 w-3.5" />
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7"
                  onClick={() => setDetailsDrawerOpen(false)}
                  aria-label={t("jobDetail.closeDetailsAria")}
                >
                  <X className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
            {/* Compact task meta — key info on top */}
            <div className="grid grid-cols-2 gap-x-3 gap-y-1 rounded-lg border bg-secondary/15 px-3 py-2 text-[11px] font-mono text-muted-foreground">
              <span
                className="truncate"
                title={`${t("jobDetail.createdAt")} ${formatDate(job.createdAt, lang)}`}
              >
                {t("jobDetail.createdAt")} {formatDate(job.createdAt, lang)}
              </span>
              {job.startedAt && (
                <span
                  className="truncate"
                  title={`${t("jobDetail.startedAt")} ${formatDate(job.startedAt, lang)}`}
                >
                  {t("jobDetail.startedAt")} {formatDate(job.startedAt, lang)}
                </span>
              )}
              {job.completedAt && (
                <span
                  className="truncate text-primary"
                  title={`${t("jobDetail.completedAt")} ${formatDate(job.completedAt, lang)}`}
                >
                  {t("jobDetail.completedAt")}{" "}
                  {formatDate(job.completedAt, lang)}
                </span>
              )}
              {job.progress !== null && job.progress !== undefined && (
                <span>
                  {t("jobDetail.progress")} {Math.round(job.progress)}%
                </span>
              )}
              {job.subtitleSource && (
                <span
                  className="col-span-2 truncate"
                  title={job.subtitleSource}
                >
                  {t("jobDetail.subtitleSource")} {job.subtitleSource}
                </span>
              )}
            </div>
            {persistedOverview && (
              <details
                className="group rounded-lg border border-amber-400/20 bg-amber-400/5"
                open={overviewOpen}
                data-testid="job-overview-section"
              >
                <summary
                  className="flex cursor-pointer list-none items-center gap-2 px-3 py-2.5 text-sm font-semibold text-amber-300 [&::-webkit-details-marker]:hidden"
                  onClick={(event) => {
                    event.preventDefault();
                    const next = !overviewOpen;
                    setOverviewOpen(next);
                    if (next) assistantAnalysis.setAnalysisOpen(false);
                  }}
                >
                  <FileText className="h-4 w-4" />
                  <span>{t("jobDetail.overviewTitle")}</span>
                  <ChevronDown className="ml-auto h-4 w-4 transition-transform group-open:rotate-180" />
                </summary>
                <p className="border-t border-amber-400/15 px-3 py-2.5 whitespace-pre-wrap text-xs leading-relaxed text-muted-foreground">
                  {persistedOverview}
                </p>
              </details>
            )}
            {selectionPlan?.compressionRationale && (
              <div
                className="rounded-lg border border-primary/20 bg-primary/5 px-3 py-2 text-xs text-muted-foreground leading-relaxed"
                data-testid="job-decision-basis"
              >
                <span className="font-medium text-foreground">
                  {t("jobDetail.decisionBasis")}：
                </span>
                {selectionPlan.compressionRationale}
                {selectionPlan.estimatedOutputBytes
                  ? `（${t("jobDetail.estimatedOutput")} ≈ ${(selectionPlan.estimatedOutputBytes / 1_000_000_000).toFixed(2)} GB）`
                  : ""}
              </div>
            )}
            {activePipeline.length > 0 && (
              <div
                className="rounded-lg border border-cyan-500/25 bg-cyan-500/5 px-3 py-2 text-xs leading-relaxed"
                data-testid="job-pipeline-steps"
              >
                <span className="font-medium text-cyan-200">
                  {t("jobDetail.pipelineSteps")}：
                </span>
                <span className="ml-1 text-muted-foreground">
                  {activePipeline.map((step, index) => (
                    <span key={step}>
                      {index > 0 ? (
                        <span className="mx-1 text-cyan-300/60">→</span>
                      ) : null}
                      <span className="font-mono">{index + 1}</span>.{" "}
                      {pipelineStepLabel(step)}
                    </span>
                  ))}
                </span>
              </div>
            )}
            {pipelineHasChapterPreview && (
              <div
                className="rounded-lg border bg-card/80"
                data-testid="job-chapter-preview-section"
              >
                <div className="flex items-center gap-2 px-3 py-2 text-sm">
                  <span className="flex items-center gap-2 font-semibold">
                    <Film className="h-4 w-4 text-primary" />
                    {t("jobDetail.chapterPreviewTitle")}
                  </span>
                </div>
                <div className="border-t p-3">
                  <p className="mb-3 text-xs text-muted-foreground">
                    {t("jobDetail.chapterPreviewHint")}
                  </p>
                  <div className="grid gap-1.5 sm:grid-cols-3">
                    {[
                      {
                        value: "middle" as const,
                        labelKey: "jobDetail.sampleMiddle",
                      },
                      {
                        value: "start" as const,
                        labelKey: "jobDetail.sampleStart",
                      },
                      {
                        value: "end" as const,
                        labelKey: "jobDetail.sampleEnd",
                      },
                    ].map((option) => (
                      <button
                        key={option.value}
                        type="button"
                        onClick={() => setChapterSamplePosition(option.value)}
                        className={cn(
                          "rounded-lg border px-3 py-2 text-left text-xs",
                          chapterSamplePosition === option.value
                            ? "border-primary bg-primary/10 text-primary"
                            : "bg-background/55 text-muted-foreground",
                        )}
                      >
                        {t(option.labelKey)}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
            {pipelineHasCompress && (
              <>
                {/* Decision parameters — collapsed by default, expand on demand */}
                <div
                  className="rounded-lg border bg-card/80"
                  data-testid="job-params-section"
                >
                  <div className="flex items-center justify-between gap-2 px-3 py-2 text-sm">
                    <span className="flex items-center gap-2 font-semibold">
                      <SlidersHorizontal className="h-4 w-4 text-primary" />
                      {t("jobDetail.taskParams")}
                    </span>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="h-7 px-2 text-[11px]"
                      onClick={() => setParamsOpen((open) => !open)}
                    >
                      {paramsOpen
                        ? t("jobDetail.collapseDetails")
                        : t("jobDetail.expandDetails")}
                    </Button>
                  </div>
                  {paramsOpen && (
                    <div className="border-t p-3">
                      <DecisionParameterPanel
                        processingMode={decisionProcessingMode}
                        subtitleMode={job.subtitleMode}
                        ocrEngine={job.ocrEngine}
                        ocrLanguage={job.ocrLanguage}
                        config={config}
                        sourceInfo={sourceInfo}
                        compressionPresets={compressionPresets}
                        selectedPresetLabel={selectedPresetLabel}
                        editableJobPreset={editableJobPreset}
                        onCompressionPresetSelect={onCompressionPresetSelect}
                        onEditableJobPresetChange={onEditableJobPresetChange}
                      />
                    </div>
                  )}
                </div>
              </>
            )}

            {pipelineHasSubtitle && (
              <>
                {/* 字幕策略：仅显示任务已明确选择的模式，不在详情页自动预选。 */}
                <div
                  className="rounded-lg border bg-card/80"
                  data-testid="job-subtitle-section"
                >
                  <div className="flex items-center justify-between gap-2 px-3 py-2 text-sm">
                    <span className="flex items-center gap-2 font-semibold">
                      <Languages className="h-4 w-4 text-primary" />
                      {t("jobDetail.subtitleStrategy")}
                    </span>
                  </div>
                  <div className="border-t p-2">
                    <div className="grid grid-cols-3 gap-1">
                      {(
                        [
                          {
                            value: "auto",
                            labelKey: "assistant.optionAuto",
                            descKey: "assistant.optionAutoDesc",
                            Icon: Sparkles,
                          },
                          {
                            value: "extract",
                            labelKey: "assistant.optionExtract",
                            descKey: "assistant.optionExtractDesc",
                            Icon: FileText,
                          },
                          {
                            value: "whisper",
                            labelKey: "assistant.optionWhisper",
                            descKey: "assistant.optionWhisperDesc",
                            Icon: Mic,
                          },
                          {
                            value: "transcribe_translate",
                            labelKey: "assistant.optionTranscribeTranslate",
                            descKey: "assistant.optionTranscribeTranslateDesc",
                            Icon: Languages,
                          },
                          {
                            value: "ocr",
                            labelKey: "assistant.optionOcr",
                            descKey: "assistant.optionOcrDesc",
                            Icon: ScanText,
                          },
                          {
                            value: "bilingual",
                            labelKey: "assistant.optionBilingual",
                            descKey: "assistant.optionBilingualDesc",
                            Icon: Captions,
                          },
                          {
                            value: "skip",
                            labelKey: "assistant.optionSkip",
                            descKey: "assistant.optionSkipDesc",
                            Icon: Ban,
                          },
                        ] as const
                      ).map((option) => {
                        const current =
                          subtitleModeOverride ?? job.subtitleMode ?? "auto";
                        // 精确匹配：当前是什么策略就只亮哪个按钮，不再把提取/转译/OCR 归并到“自动”下。
                        const active = current === option.value;
                        return (
                          <button
                            key={option.value}
                            type="button"
                            disabled={[
                              "scanning",
                              "transcribing",
                              "compressing",
                            ].includes(job.status)}
                            title={t(option.descKey)}
                            onClick={() =>
                              void updateJobSubtitleMode(option.value)
                            }
                            className={cn(
                              "min-w-0 rounded-lg border px-2 py-1 text-left transition-colors disabled:opacity-50",
                              active
                                ? option.value === "auto" ||
                                  option.value === "bilingual"
                                  ? "border-amber-400/70 bg-amber-400/15"
                                  : "border-primary/60 bg-primary/20"
                                : "border-border/70 hover:border-primary/40",
                            )}
                          >
                            <div className="flex items-center gap-1 text-[11px] font-medium text-foreground">
                              <option.Icon
                                className={cn(
                                  "h-3.5 w-3.5 shrink-0",
                                  active
                                    ? option.value === "auto" ||
                                      option.value === "bilingual"
                                      ? "text-amber-400"
                                      : "text-primary"
                                    : "text-violet-400",
                                )}
                              />
                              <span className="truncate">
                                {t(option.labelKey)}
                              </span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                    <p
                      className="mt-1 line-clamp-1 text-[10px] text-muted-foreground"
                      title={t("jobDetail.subtitleStrategyHint")}
                    >
                      {t("jobDetail.subtitleStrategyHint")}
                    </p>
                  </div>
                </div>
              </>
            )}

            {pipelineHasRemux && (
              <div
                className="rounded-lg border border-blue-500/25 bg-blue-500/5 p-3"
                data-testid="job-remux-section"
              >
                <div className="mb-1 flex items-center gap-2 text-sm font-semibold text-blue-200">
                  <Workflow className="h-4 w-4 text-blue-300" />
                  {t("jobDetail.remuxSummary")}
                </div>
                <div className="text-xs text-muted-foreground">
                  {t("jobDetail.remuxHint")}
                </div>
              </div>
            )}

            <SourceInfoCompactBar
              sourceInfo={sourceInfo}
              mediaType={job.mediaType}
              fallbackDuration={job.durationSeconds}
              detailsOpen={detailsOpen}
              onToggleDetails={() => setDetailsOpen((open) => !open)}
            />

            <Card>
              <CardHeader
                className="cursor-pointer select-none px-3 py-2"
                onClick={() => setLogsCardOpen((open) => !open)}
              >
                <CardTitle className="flex items-center gap-2 text-sm">
                  <Info className="h-4 w-4 text-primary" />
                  {t("jobDetail.logsAndFiles")}
                  <span
                    className={cn(
                      "ml-auto text-xs text-muted-foreground transition-transform",
                      logsCardOpen && "rotate-180",
                    )}
                  >
                    ▾
                  </span>
                </CardTitle>
              </CardHeader>
              {logsCardOpen && (
                <CardDescription className="-mt-2 line-clamp-2 px-6 pb-3">
                  {t("jobDetail.logsAndFilesDesc")}
                </CardDescription>
              )}
              {logsCardOpen && (
                <CardContent className="max-h-[60vh] space-y-3 overflow-y-auto text-sm">
                  <div className="flex flex-wrap gap-2">
                    <Button
                      type="button"
                      size="sm"
                      variant={fileDetailsOpen ? "default" : "outline"}
                      onClick={() => setFileDetailsOpen((open) => !open)}
                    >
                      {t("jobDetail.fileDetails")}
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant={jobLogsOpen ? "default" : "outline"}
                      onClick={() => setJobLogsOpen((open) => !open)}
                    >
                      {t("jobDetail.processingLog")}
                    </Button>
                  </div>

                  {fileDetailsOpen && (
                    <div>
                      <div className="mb-1 text-xs text-muted-foreground">
                        {t("jobDetail.sourceFilePath")}
                      </div>
                      <div className="rounded bg-secondary/50 p-2 font-mono text-xs break-all">
                        {toHostPath(job.filePath, config) || job.filePath}
                      </div>
                    </div>
                  )}

                  {job.outputPath && (
                    <div>
                      <div className="mb-1 text-xs text-muted-foreground">
                        {t("jobDetail.outputFile")}
                      </div>
                      <div className="rounded bg-secondary/50 p-2 font-mono text-xs break-all">
                        {toHostPath(job.outputPath, config) || job.outputPath}
                      </div>
                      {job.status === "done" && (
                        <div className="mt-1 text-xs text-green-500">
                          {t("jobDetail.outputVerified")}
                        </div>
                      )}
                      <div className="mt-2 flex flex-wrap gap-3">
                        <a
                          className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                          href={`/api/jobs/${jobId}/download`}
                        >
                          <Download className="h-3 w-3" />
                          {t("jobDetail.saveFinalVideo")}
                        </a>
                        <button
                          type="button"
                          className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                          onClick={() => void openOutputPath(job.outputPath!)}
                        >
                          <FolderOpen className="h-3 w-3" />
                          {t("common.openOutputFolder")}
                        </button>
                      </div>
                      <div
                        className="mt-1 truncate text-[10px] text-muted-foreground"
                        title={outputFolderLabel(job.outputPath, config)}
                      >
                        {t("jobDetail.outputDirectory")}
                        {outputFolderLabel(job.outputPath, config)}
                      </div>
                    </div>
                  )}

                  {job.subtitlePath && (
                    <div>
                      <div className="mb-1 flex items-center gap-1 text-xs text-muted-foreground">
                        <Languages className="h-3 w-3" />
                        {t("jobDetail.subtitleFile")}
                      </div>
                      <div className="rounded bg-secondary/50 p-2 font-mono text-xs break-all">
                        {toHostPath(job.subtitlePath, config) ||
                          job.subtitlePath}
                      </div>
                      <div className="mt-2 flex flex-wrap gap-3">
                        <a
                          className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                          href={`/api/jobs/${jobId}/download?kind=subtitle`}
                        >
                          <Download className="h-3 w-3" />
                          {t("jobDetail.saveSubtitle")}
                        </a>
                        <button
                          type="button"
                          className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                          onClick={() => void openOutputPath(job.subtitlePath!)}
                        >
                          <FolderOpen className="h-3 w-3" />
                          {t("jobDetail.openSubtitleFolder")}
                        </button>
                      </div>
                    </div>
                  )}

                  {job.translatedSubtitlePath && (
                    <div>
                      <div className="mb-1 flex items-center gap-1 text-xs text-muted-foreground">
                        <Languages className="h-3 w-3 text-primary" />
                        {t("jobDetail.translatedSubtitle")}
                      </div>
                      <div className="rounded border border-primary/20 bg-primary/10 p-2 font-mono text-xs break-all">
                        {toHostPath(job.translatedSubtitlePath, config) ||
                          job.translatedSubtitlePath}
                      </div>
                      <div className="mt-2 flex flex-wrap gap-3">
                        <a
                          className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                          href={`/api/jobs/${jobId}/download?kind=translated`}
                        >
                          <Download className="h-3 w-3" />
                          {t("jobDetail.saveTranslatedSubtitle")}
                        </a>
                        <button
                          type="button"
                          className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                          onClick={() =>
                            void openOutputPath(job.translatedSubtitlePath!)
                          }
                        >
                          <FolderOpen className="h-3 w-3" />
                          {t("jobDetail.openSubtitleFolder")}
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-3 border-t pt-3">
                    <div>
                      <div className="text-xs text-muted-foreground">
                        {t("jobDetail.originalSize")}
                      </div>
                      <div className="font-mono">
                        {formatBytes(job.fileSizeBefore)}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground">
                        {job.processingMode === "remux"
                          ? t("jobDetail.remuxedSize")
                          : t("jobDetail.compressedSize")}
                      </div>
                      <div className="font-mono">
                        {job.fileSizeAfter
                          ? formatBytes(job.fileSizeAfter)
                          : "--"}
                      </div>
                    </div>
                    {job.processingMode !== "remux" &&
                      job.fileSizeBefore &&
                      job.fileSizeAfter && (
                        <div className="col-span-2">
                          <div className="text-xs text-muted-foreground">
                            {t("jobDetail.savedRatio")}
                          </div>
                          <div className="font-mono text-green-500">
                            {formatCompressionRatio(
                              job.fileSizeBefore,
                              job.fileSizeAfter,
                            ) ?? "--"}
                          </div>
                        </div>
                      )}
                    <div className="col-span-2">
                      <div className="text-xs text-muted-foreground">
                        {t("jobDetail.durationLabel")}
                      </div>
                      <div className="font-mono">
                        {formatDuration(job.durationSeconds)}
                      </div>
                    </div>
                  </div>

                  {jobLogsOpen && (
                    <div className="border-t pt-3">
                      <div className="mb-2 flex items-center gap-1 text-xs text-muted-foreground">
                        <Terminal className="h-3.5 w-3.5" />
                        {t("jobDetail.processingLog")}
                      </div>
                      <div
                        className="rounded-lg border bg-black/50 p-3 font-mono text-[11px] leading-relaxed"
                        ref={scrollRef}
                      >
                        {!logs?.length ? (
                          <div className="text-muted-foreground/50 italic">
                            {t("jobDetail.waitingLogs")}
                          </div>
                        ) : (
                          logs.map((log) => (
                            <div
                              key={log.id}
                              className={cn(
                                "mb-1",
                                log.level === "error"
                                  ? "text-destructive"
                                  : log.level === "warn"
                                    ? "text-orange-400"
                                    : "text-zinc-400",
                              )}
                            >
                              <span className="mr-3 text-zinc-600">
                                [
                                {new Date(log.createdAt)
                                  .toISOString()
                                  .split("T")[1]
                                  .slice(0, 8)}
                                ]
                              </span>
                              {log.message}
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}

                  {job.errorMessage &&
                    (() => {
                      const blocked = parseBlockedJobCode(job.errorMessage);
                      if (blocked) {
                        return (
                          <div
                            className="rounded-lg border border-amber-400/30 bg-amber-400/10 p-3"
                            data-testid="job-blocked-banner"
                          >
                            <div className="mb-1 flex items-center gap-1.5 text-xs font-medium text-amber-400">
                              <AlertTriangle className="h-3.5 w-3.5" />
                              {t("jobDetail.blockedLabel")}：
                              {t(blockedReasonKey(blocked))}
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {t("jobDetail.blockedHint")}
                            </p>
                            <div className="mt-2 font-mono text-[11px] text-amber-400/70">
                              {job.errorMessage}
                            </div>
                          </div>
                        );
                      }
                      return (
                        <div className="rounded-lg border border-destructive/20 bg-destructive/10 p-3">
                          <div className="mb-1 text-xs font-medium text-destructive">
                            {t("jobDetail.errorInfo")}
                          </div>
                          <div className="font-mono text-xs text-destructive/80">
                            {job.errorMessage}
                          </div>
                        </div>
                      );
                    })()}
                </CardContent>
              )}
            </Card>
          </aside>
        )}
      </div>
    </div>
  );
}
