import { describe, expect, it } from "vitest";
import { workflowModeFromAssistantPreferences, workflowSubtitleModeForJob } from "./workflow-assistant-mode-model";

describe("workflow assistant mode synchronization", () => {
  it("maps a changed assistant choice back to the shared workflow mode", () => {
    expect(workflowModeFromAssistantPreferences(["compress"], "skip")).toEqual({
      mode: "compress",
      subtitleMode: "skip",
    });
    expect(workflowModeFromAssistantPreferences(["subtitle"], "bilingual")).toEqual({
      mode: "none",
      subtitleMode: "bilingual",
    });
  });

  it("keeps video processing authoritative when subtitle is selected alongside it", () => {
    expect(workflowModeFromAssistantPreferences(["remux", "subtitle"], "ocr")).toEqual({
      mode: "remux",
      subtitleMode: "skip",
    });
  });

  it("carries an explicit bilingual choice into the created subtitle job", () => {
    expect(workflowSubtitleModeForJob("translate-text", "none", "bilingual")).toBe("bilingual");
  });
});
