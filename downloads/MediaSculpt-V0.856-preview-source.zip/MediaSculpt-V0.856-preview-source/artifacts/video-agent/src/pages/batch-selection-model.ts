import type { ProcessingStep } from "../components/AssistantPanel";

export type BatchSubtitle = "auto" | "extract" | "whisper" | "transcribe_translate" | "skip" | "ocr" | "bilingual";

export type BatchSelectionState = {
  processing: ProcessingStep[];
  subtitleMode: BatchSubtitle | null;
  presetId: string | null;
};

export const EMPTY_BATCH_SELECTION: BatchSelectionState = {
  processing: [],
  subtitleMode: null,
  presetId: null,
};

const STEP_ORDER: ProcessingStep[] = ["remux", "subtitle", "compress", "chapterPreview"];

function addStep(processing: ProcessingStep[], step: ProcessingStep): ProcessingStep[] {
  return Array.from(new Set([...processing, step])).sort((a, b) => STEP_ORDER.indexOf(a) - STEP_ORDER.indexOf(b));
}

export function selectSubtitleChoice(state: BatchSelectionState, mode: BatchSubtitle): BatchSelectionState {
  const selected = state.processing.includes("subtitle") && state.subtitleMode === mode;
  return selected
    ? { ...state, processing: state.processing.filter((step) => step !== "subtitle"), subtitleMode: null }
    : { ...state, processing: addStep(state.processing, "subtitle"), subtitleMode: mode };
}

export function selectCompressionPreset(state: BatchSelectionState, presetId: string): BatchSelectionState {
  const selected = state.processing.includes("compress") && state.presetId === presetId;
  return selected
    ? { ...state, processing: state.processing.filter((step) => step !== "compress"), presetId: null }
    : { ...state, processing: addStep(state.processing, "compress"), presetId };
}

export function isSubtitleChoiceSelected(state: BatchSelectionState, mode: BatchSubtitle): boolean {
  return state.processing.includes("subtitle") && state.subtitleMode === mode;
}

export function isCompressionPresetSelected(state: BatchSelectionState, presetId: string): boolean {
  return state.processing.includes("compress") && state.presetId === presetId;
}
