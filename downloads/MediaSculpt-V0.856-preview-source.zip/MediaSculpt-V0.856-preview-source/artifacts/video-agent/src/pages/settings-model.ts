/** Pure presentation helpers used by the settings form. */
export function previewOutputName(
  template: string,
  example: Record<string, string>,
): string {
  if (!template.trim()) return "";
  const hasExtToken = template.includes("{ext}");
  let name = template;
  for (const [key, value] of Object.entries(example)) {
    name = name.split(`{${key}}`).join(value);
  }
  const rendered = name
    .split(/[._\- ]+/)
    .filter((segment) => segment.length > 0)
    .join(".")
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, "");
  if (!rendered) return "";
  const withExt = hasExtToken
    ? rendered
    : `${rendered}.${example.ext ?? "mkv"}`;
  return withExt.replace(/\.+/g, ".").replace(/^\.|\.$/g, "");
}

export function settingsAssColorToHex(
  assColor: string | null | undefined,
): string {
  const raw = (assColor ?? "").trim();
  const hex = raw.replace(/^&H/i, "").slice(-6);
  if (!/^[0-9a-fA-F]{6}$/.test(hex)) return "#404040";
  return `#${hex.slice(4, 6)}${hex.slice(2, 4)}${hex.slice(0, 2)}`;
}

export function settingsHexToAssColor(hexColor: string): string {
  const raw = (hexColor ?? "").replace(/^#/, "").replace(/^0x/i, "").slice(-6);
  if (!/^[0-9a-fA-F]{6}$/.test(raw)) return "&H00404040";
  return `&H00${raw.slice(4, 6)}${raw.slice(2, 4)}${raw.slice(0, 2)}`;
}

import * as z from "zod";
import {
  ConfigInputWhisperModel,
  ConfigInputOutputFormat,
} from "@workspace/api-client-react";
import type { SettingsSection } from "../hooks/useSettingsSections";

// Settings option tables and the config form schema (moved out of Settings.tsx).
export const SOURCE_DIRECTORY_VALUE = "__source__";

export const SETTINGS_SECTION_TITLES: Record<
  SettingsSection,
  { titleKey: string; descriptionKey: string }
> = {
  overview: {
    titleKey: "settings.overviewTitle",
    descriptionKey: "settings.overviewDesc",
  },
  tools: {
    titleKey: "settings.toolsTitle",
    descriptionKey: "settings.toolsDesc",
  },
  directories: {
    titleKey: "settings.directoriesTitle",
    descriptionKey: "settings.directoriesDesc",
  },
  compression: {
    titleKey: "settings.compressionTitle",
    descriptionKey: "settings.compressionDesc",
  },
  subtitles: {
    titleKey: "settings.subtitlesTitle",
    descriptionKey: "settings.subtitlesDesc",
  },
  ai: { titleKey: "settings.aiTitle", descriptionKey: "settings.aiDesc" },
  system: {
    titleKey: "settings.systemTitle",
    descriptionKey: "settings.systemDesc",
  },
  tuning: {
    titleKey: "settings.tuningTitle",
    descriptionKey: "settings.tuningDesc",
  },
  tuningPrompts: {
    titleKey: "settings.tuningPromptsTitle",
    descriptionKey: "settings.tuningPromptsDesc",
  },
};

export const settingsOverviewItems: Array<{
  id: Exclude<SettingsSection, "overview">;
  icon: string;
}> = [
  { id: "directories", icon: "📁" },
  { id: "compression", icon: "🎚️" },
  { id: "subtitles", icon: "🎙️" },
  { id: "ai", icon: "🤖" },
  { id: "system", icon: "⚙️" },
  { id: "tuning", icon: "🧪" },
  { id: "tuningPrompts", icon: "💬" },
  // 工具（本地 + 外部调用合并）放在最后 = 概览右下角（不常用）
  { id: "tools", icon: "🧰" },
];

export const WHISPER_MODEL_LABELS: Record<string, string> = {
  tiny: "settings.whisperModelTiny",
  base: "settings.whisperModelBase",
  small: "settings.whisperModelSmall",
  medium: "settings.whisperModelMedium",
  large: "settings.whisperModelLarge",
};

export type AiProviderInfo = {
  id: string;
  labelKey: string;
  icon: string;
  taglineKey: string;
  freeNoteKey: string;
  registerUrl: string;
  defaultModel: string;
};

export const AI_PROVIDER_LIST: AiProviderInfo[] = [
  {
    id: "libretranslate",
    labelKey: "settings.aiLabelLocal",
    icon: "🖥️",
    taglineKey: "settings.aiTaglineLocal",
    freeNoteKey: "settings.aiFreeLocal",
    registerUrl: "",
    defaultModel: "",
  },
  {
    id: "deepseek",
    labelKey: "settings.aiLabelDeepSeek",
    icon: "🐋",
    taglineKey: "settings.aiTaglineDeepSeek",
    freeNoteKey: "settings.aiFreeNewUser",
    registerUrl: "https://platform.deepseek.com/api_keys",
    defaultModel: "deepseek-chat",
  },
  {
    id: "siliconflow",
    labelKey: "settings.aiLabelSiliconflow",
    icon: "🌊",
    taglineKey: "settings.aiTaglineSiliconflow",
    freeNoteKey: "settings.aiFreeRegister",
    registerUrl: "https://cloud.siliconflow.cn/account/ak",
    defaultModel: "deepseek-ai/DeepSeek-V3",
  },
  {
    id: "zhipu",
    labelKey: "settings.aiLabelZhipu",
    icon: "💫",
    taglineKey: "settings.aiTaglineZhipu",
    freeNoteKey: "settings.aiFreeForever",
    registerUrl: "https://open.bigmodel.cn/usercenter/apikeys",
    defaultModel: "glm-4-flash",
  },
  {
    id: "moonshot",
    labelKey: "settings.aiLabelKimi",
    icon: "🌙",
    taglineKey: "settings.aiTaglineMoonshot",
    freeNoteKey: "settings.aiFreeNewUser",
    registerUrl: "https://platform.moonshot.cn/console/api-keys",
    defaultModel: "moonshot-v1-8k",
  },
  {
    id: "qwen",
    labelKey: "settings.aiLabelQwen",
    icon: "🟠",
    taglineKey: "settings.aiTaglineQwen",
    freeNoteKey: "settings.aiFreeQuota",
    registerUrl: "https://dashscope.console.aliyun.com/apiKey",
    defaultModel: "qwen-plus",
  },
  {
    id: "groq",
    labelKey: "settings.aiLabelGroq",
    icon: "⚡",
    taglineKey: "settings.aiTaglineGroq",
    freeNoteKey: "settings.aiFreePlan",
    registerUrl: "https://console.groq.com/keys",
    defaultModel: "llama-3.3-70b-versatile",
  },
  {
    id: "gemini",
    labelKey: "settings.aiLabelGemini",
    icon: "✨",
    taglineKey: "settings.aiTaglineGemini",
    freeNoteKey: "settings.aiFreePlan",
    registerUrl: "https://aistudio.google.com/apikey",
    defaultModel: "gemini-2.0-flash",
  },
  {
    id: "openai",
    labelKey: "settings.aiLabelOpenAI",
    icon: "🤖",
    taglineKey: "settings.aiTaglineOpenAI",
    freeNoteKey: "settings.aiPaid",
    registerUrl: "https://platform.openai.com/api-keys",
    defaultModel: "gpt-4o-mini",
  },
  {
    id: "custom",
    labelKey: "settings.aiLabelCustom",
    icon: "🔧",
    taglineKey: "settings.aiTaglineCustom",
    freeNoteKey: "settings.aiFreeCustom",
    registerUrl: "",
    defaultModel: "",
  },
];

export const KEYED_PROVIDERS: Array<{
  id: string;
  fieldName:
    | "deepseekApiKey"
    | "siliconflowApiKey"
    | "zhipuApiKey"
    | "moonshotApiKey"
    | "qwenApiKey"
    | "groqApiKey"
    | "geminiApiKey"
    | "openaiApiKey";
}> = [
  { id: "deepseek", fieldName: "deepseekApiKey" },
  { id: "siliconflow", fieldName: "siliconflowApiKey" },
  { id: "zhipu", fieldName: "zhipuApiKey" },
  { id: "moonshot", fieldName: "moonshotApiKey" },
  { id: "qwen", fieldName: "qwenApiKey" },
  { id: "groq", fieldName: "groqApiKey" },
  { id: "gemini", fieldName: "geminiApiKey" },
  { id: "openai", fieldName: "openaiApiKey" },
];

export const TRANSLATION_LANGS = [
  { value: "zh-CN", labelKey: "settings.langZhCN" },
  { value: "zh-TW", labelKey: "settings.langZhTW" },
  { value: "ja", labelKey: "settings.langJa" },
  { value: "ko", labelKey: "settings.langKo" },
  { value: "fr", labelKey: "settings.langFr" },
  { value: "de", labelKey: "settings.langDe" },
  { value: "es", labelKey: "settings.langEs" },
];

export const FRAME_RATES = [
  { value: "same", labelKey: "settings.frameSame" },
  { value: "23.976", labelKey: "settings.frame23976" },
  { value: "24", labelKey: "settings.frame24" },
  { value: "25", labelKey: "settings.frame25" },
  { value: "29.97", labelKey: "settings.frame2997" },
  { value: "30", labelKey: "settings.frame30" },
  { value: "50", labelKey: "settings.frame50" },
  { value: "60", labelKey: "settings.frame60" },
];

export const OUTPUT_RESOLUTIONS = [
  { value: "source", labelKey: "settings.resSource" },
  { value: "2160p", labelKey: "settings.res2160p" },
  { value: "1080p", labelKey: "settings.res1080p" },
  { value: "720p", labelKey: "settings.res720p" },
  { value: "576p", labelKey: "settings.res576p" },
  { value: "480p", labelKey: "settings.res480p" },
];

export const UI_LANGUAGES = [
  { value: "zh-CN", labelKey: "settings.chinese" },
  { value: "en-US", labelKey: "settings.english" },
];

export const THEME_MODES = [
  { value: "deep-ocean", labelKey: "settings.themeDeepOcean" },
  { value: "morning-light", labelKey: "settings.themeMorningLight" },
];

export const ENCODER_PRESETS = [
  { value: "ultrafast", labelKey: "settings.presetUltrafast" },
  { value: "superfast", labelKey: "settings.presetSuperfast" },
  { value: "veryfast", labelKey: "settings.presetVeryfast" },
  { value: "faster", labelKey: "settings.presetFaster" },
  { value: "fast", labelKey: "settings.presetFast" },
  { value: "medium", labelKey: "settings.presetMedium" },
  { value: "slow", labelKey: "settings.presetSlow" },
  { value: "slower", labelKey: "settings.presetSlower" },
  { value: "veryslow", labelKey: "settings.presetVeryslow" },
  { value: "placebo", labelKey: "settings.presetPlacebo" },
];

export const ENCODER_TUNES = [
  { value: "none", labelKey: "settings.tuneNone" },
  { value: "film", labelKey: "settings.tuneFilm" },
  { value: "animation", labelKey: "settings.tuneAnimation" },
  { value: "grain", labelKey: "settings.tuneGrain" },
  { value: "stillimage", labelKey: "settings.tuneStillimage" },
  { value: "fastdecode", labelKey: "settings.tuneFastdecode" },
  { value: "zerolatency", labelKey: "settings.tuneZerolatency" },
];

export const ENCODER_PROFILES = [
  { value: "auto", labelKey: "settings.profileAuto" },
  { value: "baseline", labelKey: "settings.profileBaseline" },
  { value: "main", labelKey: "settings.profileMain" },
  { value: "high", labelKey: "settings.profileHigh" },
  { value: "high10", labelKey: "settings.profileHigh10" },
];

export const ENCODER_LEVELS = [
  { value: "auto", labelKey: "settings.levelAuto" },
  { value: "3.0", labelKey: "settings.level30" },
  { value: "3.1", labelKey: "settings.level31" },
  { value: "3.2", labelKey: "settings.level32" },
  { value: "4.0", labelKey: "settings.level40" },
  { value: "4.1", labelKey: "settings.level41" },
  { value: "4.2", labelKey: "settings.level42" },
  { value: "5.0", labelKey: "settings.level50" },
  { value: "5.1", labelKey: "settings.level51" },
];

export const configSchema = z.object({
  watchDirectory: z.string().optional(),
  outputDirectory: z.string().optional(),
  remuxOutputDirectory: z.string().optional(),
  outputNameTemplate: z.string().optional(),
  posterMirrorUrl: z.string().optional(),
  posterProxyUrl: z.string().optional(),
  subtitleDirectory: z.string().optional(),
  hostDownloadsPath: z.string().optional(),
  hostOutputPath: z.string().optional(),
  libreTranslateUrl: z.string().optional(),
  processHighPriority: z.boolean(),
  shutdownAfterComplete: z.boolean(),
  handbrakePreset: z.string(),
  whisperModel: z.nativeEnum(ConfigInputWhisperModel),
  subtitleLanguage: z.string().min(1, "settings.requiredField"),
  crf: z.coerce.number().min(0).max(51),
  encoder: z.string().min(1, "settings.requiredField"),
  audioCopy: z.boolean(),
  outputFormat: z.nativeEnum(ConfigInputOutputFormat),
  handbrakeCliPath: z.string().optional(),
  subtitleEditCliPath: z.string().optional(),
  tmdbApiKey: z.string().optional(),
  omdbApiKey: z.string().optional(),
  openaiApiKey: z.string().optional(),
  deepseekApiKey: z.string().optional(),
  siliconflowApiKey: z.string().optional(),
  zhipuApiKey: z.string().optional(),
  moonshotApiKey: z.string().optional(),
  qwenApiKey: z.string().optional(),
  groqApiKey: z.string().optional(),
  geminiApiKey: z.string().optional(),
  aiTranslationEnabled: z.boolean(),
  translationTargetLang: z.string().min(1, "settings.requiredField"),
  ocrBilingualCorrection: z.boolean(),
  aiMetadataEnrichment: z.boolean(),
  aiProvider: z.string().min(1),
  aiBaseUrl: z.string().optional(),
  aiModel: z.string().optional(),
  frameRate: z.string().min(1),
  outputResolution: z.string().min(1),
  encoderPreset: z.string().min(1),
  encoderTune: z.string().min(1),
  encoderProfile: z.string().min(1),
  encoderLevel: z.string().min(1),
  uiLanguage: z.enum(["zh-CN", "en-US"]),
  themeMode: z.string().min(1),
  deinterlace: z.boolean(),
  bilingualLayout: z.enum(["zh-top", "foreign-top"]),
  bilingualOutlineWidth: z.coerce.number().min(0).max(4),
  bilingualShadowWidth: z.coerce.number().min(0).max(4),
  bilingualOutlineColor: z.string(),
  bilingualFontSizeTop: z.coerce.number().min(4).max(48),
  bilingualFontSizeBottom: z.coerce.number().min(4).max(36),
});

export type ConfigFormValues = z.infer<typeof configSchema>;
