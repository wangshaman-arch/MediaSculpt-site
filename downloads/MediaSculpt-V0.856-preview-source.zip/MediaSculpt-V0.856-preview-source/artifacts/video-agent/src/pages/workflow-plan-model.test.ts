import { describe, expect, it } from "vitest";
import {
  clearWorkflowChoices,
  workflowChapterSelectionPayload,
  workflowPresetLabel,
} from "./workflow-plan-model";

describe("workflow plan choices", () => {
  it("does not carry analysis recommendations into executable selections", () => {
    const items = clearWorkflowChoices([
      { id: "a", action: "compress" as const, pipeline: ["compress" as const], presetId: "balanced" },
      { id: "b", action: "remux" as const, pipeline: ["remux" as const], presetId: null },
    ]);

    expect(items).toEqual([
      { id: "a", action: "skip", pipeline: [], presetId: null },
      { id: "b", action: "skip", pipeline: [], presetId: null },
    ]);
  });

  it("renders a translated preset label instead of its internal id", () => {
    expect(workflowPresetLabel("dvd-convert", [
      { id: "dvd-convert", label: "DVD 转制" },
      { id: "balanced", label: "通用均衡" },
    ])).toBe("DVD 转制");
    expect(workflowPresetLabel("unknown", [])).toBe("unknown");
  });

  it("lets the server resolve all disc chapters from the verified title", () => {
    expect(
      workflowChapterSelectionPayload({
        sourceType: "dvd",
        selectedChapterIds: ["0", "1"],
        chapters: [{ id: "0" }, { id: "1" }],
      }),
    ).toBeUndefined();
    expect(
      workflowChapterSelectionPayload({
        sourceType: "dvd",
        selectedChapterIds: ["0"],
        chapters: [{ id: "0" }, { id: "1" }],
      }),
    ).toBe("[0]");
  });
});
