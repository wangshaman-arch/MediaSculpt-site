import { describe, expect, it } from "vitest";
import {
  allSelectionIds,
  normalizeSelectionIds,
  toggleSelectionId,
} from "./workflow-stream-selection-model";

describe("workflow stream selection", () => {
  it("defaults streams and chapters to all known ids", () => {
    expect(allSelectionIds(["video-0", "audio-1", "subtitle-2"])).toEqual([
      "video-0",
      "audio-1",
      "subtitle-2",
    ]);
  });

  it("normalizes selections without inventing ids or changing order", () => {
    expect(
      normalizeSelectionIds(["audio-1", "missing", "video-0"], ["video-0", "audio-1"]),
    ).toEqual(["video-0", "audio-1"]);
  });

  it("toggles one id without duplicating it", () => {
    expect(toggleSelectionId(["video-0", "audio-1"], "audio-1")).toEqual(["video-0"]);
    expect(toggleSelectionId(["video-0"], "audio-1")).toEqual(["video-0", "audio-1"]);
  });
});
