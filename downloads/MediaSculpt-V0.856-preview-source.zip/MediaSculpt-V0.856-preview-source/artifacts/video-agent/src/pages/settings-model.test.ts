import { describe, expect, it } from "vitest";
import {
  previewOutputName,
  settingsAssColorToHex,
  settingsHexToAssColor,
} from "./settings-model";

describe("settings model helpers", () => {
  it("renders a stable output name preview from a template", () => {
    expect(
      previewOutputName("{title}_{year}_{kind}", {
        title: "A/B",
        year: "1995",
        kind: "Remux",
        ext: "mkv",
      }),
    ).toBe("AB.1995.Remux.mkv");
  });

  it("converts ASS colors to and from the UI hex format", () => {
    expect(settingsAssColorToHex("&H00112233")).toBe("#332211");
    expect(settingsHexToAssColor("#332211")).toBe("&H00112233");
  });
});
