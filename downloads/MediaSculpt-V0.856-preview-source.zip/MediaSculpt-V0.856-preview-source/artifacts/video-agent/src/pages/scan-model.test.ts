import { describe, expect, it } from "vitest";
import {
  discFolderName,
  isDirectM2tsTitle,
  stableDiscTitleKey,
} from "./scan-model";

describe("scan model helpers", () => {
  it("creates a stable preview key for a disc title", () => {
    expect(stableDiscTitleKey("disc-1", "1")).toBe("disc-1:1");
  });

  it("recognizes direct M2TS titles", () => {
    expect(isDirectM2tsTitle({ titleId: "m2ts:1" })).toBe(true);
    expect(isDirectM2tsTitle({ titleId: "playlist-1" })).toBe(false);
  });

  it("uses the folder name as the disc display name", () => {
    expect(discFolderName("H:/Movies/Example DVD")).toBe("Example DVD");
  });
});
