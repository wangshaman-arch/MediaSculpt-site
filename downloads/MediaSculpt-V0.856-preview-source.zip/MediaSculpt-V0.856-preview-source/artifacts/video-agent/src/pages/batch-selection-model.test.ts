import { describe, expect, it } from "vitest";
import {
  EMPTY_BATCH_SELECTION,
  isCompressionPresetSelected,
  isSubtitleChoiceSelected,
  selectCompressionPreset,
  selectSubtitleChoice,
  type BatchSelectionState,
} from "./batch-selection-model";

describe("batch selection model", () => {
  it("starts with no processing feature, subtitle choice, or compression preset selected", () => {
    expect(EMPTY_BATCH_SELECTION).toEqual({ processing: [], subtitleMode: null, presetId: null });
  });

  it("keeps subtitle and compression selections independent", () => {
    const withSubtitle = selectSubtitleChoice(EMPTY_BATCH_SELECTION, "whisper");
    const withBoth = selectCompressionPreset(withSubtitle, "balanced");

    expect(withBoth.processing).toEqual(["subtitle", "compress"]);
    expect(withBoth.subtitleMode).toBe("whisper");
    expect(withBoth.presetId).toBe("balanced");
    expect(isSubtitleChoiceSelected(withBoth, "whisper")).toBe(true);
    expect(isCompressionPresetSelected(withBoth, "balanced")).toBe(true);

    const subtitleRemoved = selectSubtitleChoice(withBoth, "whisper");
    expect(subtitleRemoved.processing).toEqual(["compress"]);
    expect(subtitleRemoved.presetId).toBe("balanced");
  });

  it("does not select compression when only a subtitle choice is made", () => {
    const next: BatchSelectionState = selectSubtitleChoice(EMPTY_BATCH_SELECTION, "auto");
    expect(next.processing).toEqual(["subtitle"]);
    expect(next.presetId).toBeNull();
    expect(isCompressionPresetSelected(next, "balanced")).toBe(false);
  });
});
