import {
  Profiler,
  useState,
  useCallback,
  useEffect,
  useMemo,
  useRef,
} from "react";
import {
  useCreateJob,
  useBrowseDirectory,
  useGetConfig,
  getGetConfigQueryKey,
  useUpdateConfig,
  useAnalyzeDisc,
  useListJobs,
  getListJobsQueryKey,
} from "@workspace/api-client-react";
import type { DiscTrack, DiscStream } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import { ToastAction } from "@/components/ui/toast";
import {
  Loader2,
  Play,
  ArrowLeft,
  SquareCheck,
  Square,
  Disc,
  X,
  Video,
  Music,
  Subtitles,
  HelpCircle,
  ChevronDown,
  ChevronsUpDown,
  Save,
  ScanText,
  Sparkles,
  Layers,
  List,
  Wand2,
  Mic,
  Languages,
  Captions,
  Settings2,
  RotateCcw,
} from "lucide-react";
import { useLocation } from "wouter";
import {
  useToolAvailability,
  toolsRequiredForSubtitle,
} from "@/lib/use-tool-availability";
import { cn, formatDate } from "@/lib/utils";
import {
  ARCHIVE_PRESETS,
  ARCHIVE_PRESET_LS_KEY,
  compressionConfigValues,
  CUSTOM_COMPRESSION_PRESET_ID,
  PRESET_CHANGED_EVENT,
  loadCompressionPresets,
  presetConfigValues,
  type ArchivePreset,
  type CompressionPresetValues,
} from "@/lib/compression-presets";
import { useI18n, useScanCopy } from "@/i18n";
import {
  useWorkbenchState,
  type ProcessingMode,
  type SubtitleMode,
  type WorkbenchTab,
} from "@/hooks/useWorkbenchState";
import { WorkbenchModeTabs } from "../features/workbench/WorkbenchModeTabs";
import { SubtitleModeSelector } from "../features/workbench/SubtitleModeSelector";
import { CompressionPresetPanel } from "../features/workbench/CompressionPresetPanel";
import { DiscTitleRow } from "../features/workbench/DiscTitleRow";
import { WorkbenchSourceEntry } from "../features/workbench/WorkbenchSourceEntry";
import {
  browserStorage,
  readLastBrowsePath,
  readNetworkPathHistory,
  rememberBrowsePath,
  rememberNetworkPath,
} from "../features/workbench/source-browser-storage";
import {
  lastPathSegment,
  normalizeBatchStreams,
  sortBrowserEntries,
} from "../features/workbench/source-browser-model";
import { SourceBrowserNetworkPanel } from "../features/workbench/SourceBrowserNetworkPanel";
import { SourceBrowserDirectoryList } from "../features/workbench/SourceBrowserDirectoryList";
import {
  formatDiscBytes as fmtBytes,
  formatDiscChapterDuration as fmtChapterDuration,
  formatDiscDuration as fmtDuration,
  handBrakeTrackNumbers,
  streamLanguageDisplay as languageLabel,
  streamDisplayLabel as streamLabel,
  streamTechnicalBadges,
  trackLanguageDisplay as trackLanguageSummary,
  type DiscStreamWithHandBrake,
  type DiscTrackWithMakeMkv,
} from "../features/workbench/disc-display-model";
import Workflow from "@/pages/Workflow";
import type { BatchItem } from "@/pages/BatchConfirmPage";
import {
  OCR_ENGINE_KEY,
  OCR_LANGUAGE_KEY,
  OCR_LANGUAGE_CODES,
  ocrLanguageLabel,
} from "@/lib/ocr-languages";
import {
  discFolderName,
  isDirectM2tsTitle,
  stableDiscTitleKey,
} from "./scan-model";
import { DiscAnalyzeDialog } from "../features/workbench/DiscAnalyzeDialog";

// ── Subtitle modes ─────────────────────────────────────────────────────────────
// "ocr" is a workbench-only mode: it never becomes a queue job's subtitleMode
// (the API enum has no "ocr"); it only arms the OCR dialog against the source
// chosen in the browser below.
const SUBTITLE_MODES: SubtitleMode[] = [
  "auto",
  "extract",
  "whisper",
  "transcribe_translate",
  "skip",
];

/** ASS 颜色（&HBBGGRR / &HAABBGGRR）与网页 hex（#RRGGBB）互转，供样式设置面板使用。 */
function assColorToHex(assColor: string | null | undefined): string {
  const raw = (assColor ?? "").trim();
  const hex = raw.replace(/^&H/i, "").slice(-6);
  if (!/^[0-9a-fA-F]{6}$/.test(hex)) return "#404040";
  const b = hex.slice(0, 2);
  const g = hex.slice(2, 4);
  const r = hex.slice(4, 6);
  return `#${r}${g}${b}`;
}

function hexToAssColor(hexColor: string): string {
  const raw = (hexColor ?? "").replace(/^#/, "").replace(/^0x/i, "").slice(-6);
  if (!/^[0-9a-fA-F]{6}$/.test(raw)) return "&H00404040";
  const r = raw.slice(0, 2);
  const g = raw.slice(2, 4);
  const b = raw.slice(4, 6);
  return `&H00${b}${g}${r}`;
}

type BilingualStyleDraft = {
  layout: "zh-top" | "foreign-top";
  outlineWidth: number;
  shadowWidth: number;
  outlineColor: string;
  fontSizeTop: number;
  fontSizeBottom: number;
};

function defaultBilingualDraft(): BilingualStyleDraft {
  return {
    layout: "zh-top",
    outlineWidth: 0.2,
    shadowWidth: 0,
    outlineColor: "#404040",
    fontSizeTop: 16,
    fontSizeBottom: 9.6,
  };
}

/**
 * Searchable OCR language picker. A plain Select with 50+ entries overflows
 * the viewport and cannot scroll, so this uses a Command combobox with a
 * viewport-safe max height and keyboard search.
 */
function OcrLanguagePicker({
  value,
  onChange,
  t,
}: {
  value: string;
  onChange: (value: string) => void;
  t: (key: string) => string;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return OCR_LANGUAGE_CODES;
    return OCR_LANGUAGE_CODES.filter((code) => {
      const label = t(`ocr.languageNames.${code}`).toLowerCase();
      return code.includes(q) || label.includes(q);
    });
  }, [query, t]);
  const select = (next: string) => {
    onChange(next);
    setOpen(false);
    setQuery("");
  };
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="h-9 w-full justify-between font-normal"
          data-testid="ocr-language-select"
        >
          {ocrLanguageLabel(value, t)}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" sideOffset={4} className="w-[280px] p-0">
        <Command>
          <CommandInput
            placeholder={t("ocr.languageSearchPlaceholder")}
            value={query}
            onValueChange={setQuery}
          />
          <CommandList className="max-h-[min(50vh,360px)] overflow-y-auto">
            <CommandEmpty>{t("ocr.languageSearchEmpty")}</CommandEmpty>
            <CommandItem value="auto" onSelect={() => select("auto")}>
              {t("ocr.languageAuto")}
            </CommandItem>
            {filtered.map((code) => (
              <CommandItem
                key={code}
                value={code}
                onSelect={() => select(code)}
              >
                {t(`ocr.languageNames.${code}`)}
              </CommandItem>
            ))}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

// ── Tab type ──────────────────────────────────────────────────────────────────
export type ScanCopy = ReturnType<typeof useScanCopy>;

function WorkbenchHint({ text }: { text: string }) {
  const { t } = useI18n();
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          type="button"
          className="inline-flex h-6 w-6 items-center justify-center rounded-full text-muted-foreground hover:bg-secondary hover:text-foreground"
          aria-label={t("scan.helpAria")}
        >
          <HelpCircle className="h-3.5 w-3.5" />
        </button>
      </TooltipTrigger>
      <TooltipContent side="top" className="max-w-xs leading-relaxed">
        {text}
      </TooltipContent>
    </Tooltip>
  );
}

function loadOcrDefault(key: string, fallback: string): string {
  try {
    return localStorage.getItem(key) || fallback;
  } catch {
    return fallback;
  }
}

function persistOcrOption(key: string, value: string): void {
  try {
    localStorage.setItem(key, value);
  } catch {
    // ignore storage errors
  }
}

type DiscPreviewMetric = {
  renders: number;
  totalDurationMs: number;
  lastDurationMs: number;
  lastPhase: "mount" | "update" | "nested-update";
};

type DiscPreviewInteractionMetric = {
  count: number;
  totalDurationMs: number;
  lastDurationMs: number;
};

export type DiscTitlePreviewState = {
  status: "idle" | "loading" | "ready" | "failed";
  url?: string;
  previews?: string[];
  message?: string;
  warning?: string;
};

const discPreviewMetrics: Record<string, DiscPreviewMetric> = {};
const discPreviewInteractionMetrics: Record<
  string,
  DiscPreviewInteractionMetric
> = {};

function recordDiscPreviewMetric(
  id: string,
  phase: "mount" | "update" | "nested-update",
  actualDuration: number,
) {
  const previous = discPreviewMetrics[id] ?? {
    renders: 0,
    totalDurationMs: 0,
    lastDurationMs: 0,
    lastPhase: phase,
  };
  const next = {
    renders: previous.renders + 1,
    totalDurationMs: previous.totalDurationMs + actualDuration,
    lastDurationMs: actualDuration,
    lastPhase: phase,
  } satisfies DiscPreviewMetric;
  discPreviewMetrics[id] = next;
  if (typeof window !== "undefined") {
    (
      window as Window & {
        __VX_AGENT_DISC_PREVIEW_METRICS__?: Record<string, DiscPreviewMetric>;
      }
    ).__VX_AGENT_DISC_PREVIEW_METRICS__ = discPreviewMetrics;
  }
}

export function onDiscPreviewRender(
  id: string,
  phase: "mount" | "update" | "nested-update",
  actualDuration: number,
) {
  recordDiscPreviewMetric(id, phase, actualDuration);
}

function recordDiscPreviewInteraction(id: string, durationMs: number) {
  const previous = discPreviewInteractionMetrics[id] ?? {
    count: 0,
    totalDurationMs: 0,
    lastDurationMs: 0,
  };
  const next = {
    count: previous.count + 1,
    totalDurationMs: previous.totalDurationMs + durationMs,
    lastDurationMs: durationMs,
  } satisfies DiscPreviewInteractionMetric;
  discPreviewInteractionMetrics[id] = next;
  if (typeof window !== "undefined") {
    const target = window as Window & {
      __VX_AGENT_DISC_PREVIEW_METRICS__?: Record<string, DiscPreviewMetric>;
      __VX_AGENT_DISC_PREVIEW_INTERACTIONS__?: Record<
        string,
        DiscPreviewInteractionMetric
      >;
    };
    target.__VX_AGENT_DISC_PREVIEW_INTERACTIONS__ =
      discPreviewInteractionMetrics;
  }
}

export function measureDiscPreviewInteraction(id: string, startedAt: number) {
  const finish = () =>
    recordDiscPreviewInteraction(
      id,
      Math.max(0, performance.now() - startedAt),
    );
  if (
    typeof window !== "undefined" &&
    typeof window.requestAnimationFrame === "function"
  ) {
    window.requestAnimationFrame(finish);
  } else {
    finish();
  }
}

export function streamKindLabel(
  type: DiscStream["codecType"],
  t: (key: string) => string,
) {
  if (type === "video") return t("scan.streamVideo");
  if (type === "audio") return t("scan.streamAudio");
  return t("scan.streamSubtitle");
}

export function fileHoverTitle(
  entry: {
    name: string;
    path: string;
    sizeBytes?: number;
    modifiedAt?: string;
  },
  t: (key: string) => string,
  lang: string,
): string {
  return [
    `${t("scan.fileName")}: ${entry.name}`,
    `${t("common.path")}: ${entry.path}`,
    entry.sizeBytes != null
      ? `${t("scan.fileSize")}: ${fmtBytes(entry.sizeBytes)}`
      : null,
    entry.modifiedAt
      ? `${t("scan.modifiedTime")}: ${formatDate(entry.modifiedAt, lang)}`
      : null,
  ]
    .filter(Boolean)
    .join("\n");
}

import { SourceBrowserPanel } from "../features/workbench/SourceBrowserPanel";
import { RemuxPanel } from "../features/workbench/RemuxPanel";

// ── Main Scan page ────────────────────────────────────────────────────────────
export default function Scan() {
  const { t } = useI18n();
  const { toast } = useToast();
  const [location, setLocation] = useLocation();
  const toolAvail = useToolAvailability();
  const missingFor = (mode: string) =>
    toolsRequiredForSubtitle(mode).filter((id) => !toolAvail.isAvailable(id));
  const toolLabel = (id: string) => {
    const found = toolAvail.tools.find((item) => item.id === id);
    return (
      found?.label ??
      (id === "tesseract"
        ? "Tesseract"
        : id === "rapidocr"
          ? "RapidOCR"
          : id === "whisper"
            ? "Whisper"
            : id)
    );
  };
  const promptMissing = (mode: string) => {
    const missing = missingFor(mode);
    if (missing.length === 0) return true;
    toast({
      title: t("scan.missingToolTitle"),
      description: t("scan.missingToolDesc", {
        tools: missing.map(toolLabel).join("、"),
      }),
      variant: "destructive",
      action: (
        <ToastAction
          altText={t("scan.goInstallTools")}
          onClick={() => setLocation("/settings#tools")}
        >
          {t("scan.goInstallTools")}
        </ToastAction>
      ),
    });
    return false;
  };

  const [bilingualLayout, setBilingualLayout] = useState<
    "zh-top" | "foreign-top"
  >("zh-top");
  const [bilingualSettingsOpen, setBilingualSettingsOpen] = useState(false);
  const [bilingualDraft, setBilingualDraft] =
    useState<BilingualStyleDraft | null>(null);
  const { data: config } = useGetConfig({
    query: { queryKey: getGetConfigQueryKey(), refetchOnWindowFocus: false },
  });
  const workbench = useWorkbenchState({ location, config });
  const {
    tab,
    subtitleMode,
    setSubtitleMode,
    directory,
    setDirectory,
    browseCreated,
    setBrowseCreated,
    watchDir,
  } = workbench;
  // 智能工作流中的 DVD 模式由光盘分析弹窗确认一次，并贯穿后续助手与建任务步骤。
  const [workflowProcessingMode, setWorkflowProcessingMode] =
    useState<ProcessingMode | null>(null);
  const [workflowSubtitleMode, setWorkflowSubtitleMode] =
    useState<SubtitleMode>("skip");

  const selectWorkflowProcessingMode = (
    mode: ProcessingMode,
    subtitleMode: SubtitleMode = mode === "none" ? "auto" : "skip",
  ) => {
    setWorkflowProcessingMode(mode);
    setWorkflowSubtitleMode(subtitleMode);
  };
  const updateConfig = useUpdateConfig();
  const [compressionPresets, setCompressionPresets] = useState<ArchivePreset[]>(
    () => loadCompressionPresets(),
  );
  const [selectedPresetLabel, setSelectedPresetLabel] = useState("");
  const workflowAnalyzeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(
    null,
  );

  useEffect(() => {
    const reloadPresets = () => setCompressionPresets(loadCompressionPresets());
    window.addEventListener("storage", reloadPresets);
    window.addEventListener(PRESET_CHANGED_EVENT, reloadPresets);
    return () => {
      window.removeEventListener("storage", reloadPresets);
      window.removeEventListener(PRESET_CHANGED_EVENT, reloadPresets);
      if (workflowAnalyzeTimerRef.current)
        clearTimeout(workflowAnalyzeTimerRef.current);
    };
  }, []);

  useEffect(() => {
    if (!config) return;
    setBilingualLayout(
      config.bilingualLayout === "foreign-top" ? "foreign-top" : "zh-top",
    );
  }, [config]);

  const openBilingualSettings = () => {
    setBilingualDraft({
      layout:
        config?.bilingualLayout === "foreign-top" ? "foreign-top" : "zh-top",
      outlineWidth:
        typeof config?.bilingualOutlineWidth === "number"
          ? config.bilingualOutlineWidth
          : 0.2,
      shadowWidth:
        typeof config?.bilingualShadowWidth === "number"
          ? config.bilingualShadowWidth
          : 0,
      outlineColor: assColorToHex(config?.bilingualOutlineColor),
      fontSizeTop:
        typeof config?.bilingualFontSizeTop === "number"
          ? config.bilingualFontSizeTop
          : 16,
      fontSizeBottom:
        typeof config?.bilingualFontSizeBottom === "number"
          ? config.bilingualFontSizeBottom
          : 9.6,
    });
    setBilingualSettingsOpen((open) => !open);
  };

  const saveBilingualSettings = async () => {
    if (!bilingualDraft) return;
    try {
      await updateConfig.mutateAsync({
        data: {
          bilingualLayout: bilingualDraft.layout,
          bilingualOutlineWidth: bilingualDraft.outlineWidth,
          bilingualShadowWidth: bilingualDraft.shadowWidth,
          bilingualOutlineColor: hexToAssColor(bilingualDraft.outlineColor),
          bilingualFontSizeTop: bilingualDraft.fontSizeTop,
          bilingualFontSizeBottom: bilingualDraft.fontSizeBottom,
        },
      });
      setBilingualLayout(bilingualDraft.layout);
      setBilingualSettingsOpen(false);
      toast({ title: t("scan.bilingualSettingsSaved") });
    } catch (error) {
      toast({
        title: t("scan.bilingualSettingsSaveFailed"),
        description: error instanceof Error ? error.message : String(error),
        variant: "destructive",
      });
    }
  };

  const onCompressionPresetSelect = (preset: ArchivePreset) => {
    setSelectedPresetLabel(preset.id);
    void updateConfig
      .mutateAsync({ data: presetConfigValues(preset) })
      .catch(() => {});
  };

  const [editingPresetId, setEditingPresetId] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState<CompressionPresetValues | null>(
    null,
  );

  const startEditPreset = (preset: ArchivePreset) => {
    if (editingPresetId === preset.id) {
      setEditingPresetId(null);
      setEditDraft(null);
      return;
    }
    setEditingPresetId(preset.id);
    setEditDraft({ ...preset.values });
  };

  const startEditCustomPreset = () => {
    setEditingPresetId(CUSTOM_COMPRESSION_PRESET_ID);
    setEditDraft({ ...customCompression });
  };

  const updateEditDraft = (next: Partial<CompressionPresetValues>) => {
    setEditDraft((current) => (current ? { ...current, ...next } : current));
  };

  const resetEditedPreset = () => {
    if (!editingPresetId) return;
    if (editingPresetId === CUSTOM_COMPRESSION_PRESET_ID) {
      setEditDraft({ ...customCompression });
      return;
    }
    const def = ARCHIVE_PRESETS.find((p) => p.id === editingPresetId);
    if (def) setEditDraft({ ...def.values });
  };

  const saveEditedPreset = async () => {
    if (!editingPresetId || !editDraft) return;
    if (editingPresetId === CUSTOM_COMPRESSION_PRESET_ID) {
      await updateConfig.mutateAsync({
        data: compressionConfigValues(editDraft),
      });
      setSelectedPresetLabel(CUSTOM_COMPRESSION_PRESET_ID);
      setEditingPresetId(null);
      setEditDraft(null);
      return;
    }
    const updated = compressionPresets.map((p) =>
      p.id === editingPresetId ? { ...p, values: editDraft } : p,
    );
    setCompressionPresets(updated);
    localStorage.setItem(
      ARCHIVE_PRESET_LS_KEY,
      JSON.stringify(updated.map((p) => ({ label: p.id, values: p.values }))),
    );
    window.dispatchEvent(new Event(PRESET_CHANGED_EVENT));
    const saved = updated.find((p) => p.id === editingPresetId);
    setEditingPresetId(null);
    setEditDraft(null);
    if (saved) onCompressionPresetSelect(saved);
  };

  const [ocrEngine, setOcrEngine] = useState(() =>
    loadOcrDefault(OCR_ENGINE_KEY, "auto"),
  );
  const [ocrLanguage, setOcrLanguage] = useState(() =>
    loadOcrDefault(OCR_LANGUAGE_KEY, "auto"),
  );

  const uiText = useScanCopy();

  const customCompression: CompressionPresetValues = {
    encoder: config?.encoder || "",
    crf: config?.crf ?? 20,
    encoderPreset: config?.encoderPreset || "slow",
    encoderTune: config?.encoderTune || "film",
    encoderProfile: config?.encoderProfile || "high10",
    encoderLevel: config?.encoderLevel || "4.1",
    frameRate: config?.frameRate || "same",
    outputResolution: config?.outputResolution || "source",
  };

  const selectCustomCompression = () => {
    setSelectedPresetLabel(CUSTOM_COMPRESSION_PRESET_ID);
  };

  function selectTab(next: WorkbenchTab) {
    workbench.selectTab(next);
    setBilingualSettingsOpen(false);
    setBilingualDraft(null);
  }

  return (
    <div
      data-testid="workbench-page"
      className="mx-auto flex h-full min-h-0 w-full max-w-[1680px] flex-col gap-3 sm:gap-4 overflow-hidden"
    >
      <div className="flex items-start justify-between gap-4">
        <p className="text-sm text-muted-foreground">{uiText.description}</p>
        <WorkbenchHint text={uiText.workbenchHintText} />
      </div>

      <WorkbenchModeTabs
        activeTab={tab}
        title={uiText.processingMode}
        description={uiText.processingModeDescription}
        workflow={{ label: t("nav.workflow"), desc: t("nav.workflowHint") }}
        modes={uiText.modes}
        onSelect={selectTab}
        hint={<WorkbenchHint text={uiText.processingModeDescription} />}
      />

      <div className="min-h-0 flex-1 space-y-4 overflow-y-auto">
        {tab === "workflow" && (
          <Workflow
            sourcePath={directory}
            onSourcePathChange={setDirectory}
            selectedProcessingMode={workflowProcessingMode}
            selectedSubtitleMode={workflowSubtitleMode}
            onProcessingModeChange={selectWorkflowProcessingMode}
          >
            {({ analyze }) => (
              <WorkbenchSourceEntry
                title={t("scan.sourceDirectoryAnalyzeTitle")}
                description={t("scan.sourceDirectoryAnalyzeDesc")}
                directory={directory}
                configReady={!!config}
                processingMode="none"
                defaultExpanded={true}
                hideModeBadge
                uiText={uiText}
                onDirectoryChange={(value) => {
                  setDirectory(value);
                  // 用户主动选择/修改来源目录后才自动分析（打开工作台的配置同步不触发）
                  if (workflowAnalyzeTimerRef.current)
                    clearTimeout(workflowAnalyzeTimerRef.current);
                  workflowAnalyzeTimerRef.current = setTimeout(
                    () => analyze(value),
                    600,
                  );
                }}
                browser={
                  <SourceBrowserPanel
                    key={directory || watchDir}
                    onJobsCreated={(n, firstId) => {
                      setBrowseCreated((current) => current + n);
                      if (n > 0)
                        setLocation(firstId ? `/jobs/${firstId}` : "/jobs");
                    }}
                    subtitleMode={workflowSubtitleMode}
                    ocrEngine={ocrEngine}
                    ocrLanguage={ocrLanguage}
                    bilingualLayout={bilingualLayout}
                    processingMode={workflowProcessingMode ?? "none"}
                    defaultPath={directory || watchDir}
                    uiText={uiText}
                    defaultOpen={true}
                    analysisOnly={true}
                    onAnalysisConfirmed={(items) => {
                      // Disc analysis is selection-only in Smart Workflow. Hand
                      // the verified, user-selected titles to the existing
                      // pre-queue preview page; it must not create jobs here.
                      sessionStorage.setItem("vx-batch-items", JSON.stringify(items));
                      setLocation("/batch");
                    }}
                    onSelectMode={selectWorkflowProcessingMode}
                  />
                }
              />
            )}
          </Workflow>
        )}

        {tab !== "workflow" && (
          <>
            {tab === "compress" && (
              <CompressionPresetPanel
                presets={compressionPresets}
                selectedPresetLabel={selectedPresetLabel}
                customCompression={customCompression}
                editingPresetId={editingPresetId}
                editDraft={editDraft}
                t={t}
                onSelectPreset={onCompressionPresetSelect}
                onSelectCustomPreset={selectCustomCompression}
                onStartEditCustomPreset={startEditCustomPreset}
                onStartEdit={startEditPreset}
                onResetEditedPreset={resetEditedPreset}
                onUpdateEditDraft={updateEditDraft}
                onSaveEditedPreset={saveEditedPreset}
                onCancelEdit={() => {
                  setEditingPresetId(null);
                  setEditDraft(null);
                }}
              />
            )}

            {tab === "none" && (
              <>
                <SubtitleModeSelector
                  title={uiText.subtitleMode}
                  activeMode={subtitleMode}
                  labels={{
                    auto: uiText.subtitleModes.auto.label,
                    ocr: t("scan.ocrTileLabel"),
                    extract: uiText.subtitleModes.extract.label,
                    whisper: uiText.subtitleModes.whisper.label,
                    transcribe_translate:
                      uiText.subtitleModes.transcribe_translate.label,
                    bilingual: uiText.subtitleModes.bilingual.label,
                  }}
                  onSelect={(mode) => {
                    setSubtitleMode(mode);
                    if (mode !== "bilingual") {
                      setBilingualSettingsOpen(false);
                      setBilingualDraft(null);
                    }
                  }}
                  missingFor={missingFor}
                  promptMissing={promptMissing}
                  toolLabel={toolLabel}
                  missingToolText={(tools) =>
                    t("scan.missingToolInline", { tools })
                  }
                  installToolsText={t("scan.goInstallTools")}
                  bilingualEditTitle={t("scan.bilingualEditTitle")}
                  bilingualSettingsOpen={bilingualSettingsOpen}
                  onOpenBilingualSettings={openBilingualSettings}
                  onOpenToolSettings={() => setLocation("/settings#tools")}
                />
                {subtitleMode === "ocr" && (
                  <div
                    className="mt-3 rounded-lg border border-primary/25 bg-primary/5 p-3 space-y-3"
                    data-testid="ocr-options-panel"
                  >
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {t("scan.ocrModeHint")}
                    </p>
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <div className="space-y-1.5">
                        <label className="text-xs font-medium">
                          {t("ocr.engine")}
                        </label>
                        <Select
                          value={ocrEngine}
                          onValueChange={(value) => {
                            setOcrEngine(value);
                            persistOcrOption(OCR_ENGINE_KEY, value);
                          }}
                          data-testid="ocr-engine-select"
                        >
                          <SelectTrigger className="h-9">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="auto">
                              {t("ocr.engineAuto")}
                            </SelectItem>
                            <SelectItem value="llm">
                              {t("ocr.engineLlm")}
                            </SelectItem>
                            <SelectItem value="tesseract">
                              {t("ocr.engineTesseract")}
                            </SelectItem>
                            <SelectItem value="rapidocr">
                              {t("ocr.engineRapidOcr")}
                            </SelectItem>
                            <SelectItem value="subtitleedit" disabled>
                              {t("ocr.engineSubtitleEdit")}（
                              {t("ocr.comingSoon")}）
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-xs font-medium">
                          {t("ocr.language")}
                        </label>
                        <OcrLanguagePicker
                          value={ocrLanguage}
                          onChange={(value) => {
                            setOcrLanguage(value);
                            persistOcrOption(OCR_LANGUAGE_KEY, value);
                          }}
                          t={t}
                        />
                      </div>
                    </div>
                  </div>
                )}
                {bilingualSettingsOpen && bilingualDraft && (
                  <div
                    className="mt-3 rounded-lg border border-primary/25 bg-primary/5 p-2.5"
                    data-testid="bilingual-settings-panel"
                  >
                    <div className="flex flex-wrap items-end gap-x-3 gap-y-1.5">
                      <div className="min-w-[215px] flex-1 space-y-0.5">
                        <label className="block text-[11px] font-medium text-muted-foreground">
                          {t("scan.bilingualLayoutOption")}
                        </label>
                        <div className="flex gap-0.5">
                          <button
                            type="button"
                            onClick={() =>
                              setBilingualDraft((current) =>
                                current
                                  ? { ...current, layout: "zh-top" }
                                  : current,
                              )
                            }
                            className={cn(
                              "h-8 rounded-md border px-2.5 text-xs transition-colors",
                              bilingualDraft.layout === "zh-top"
                                ? "border-primary bg-primary/10 text-primary"
                                : "border-border hover:border-primary/50",
                            )}
                          >
                            {t("scan.bilingualZhTop")}
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setBilingualDraft((current) =>
                                current
                                  ? { ...current, layout: "foreign-top" }
                                  : current,
                              )
                            }
                            className={cn(
                              "h-8 rounded-md border px-2.5 text-xs transition-colors",
                              bilingualDraft.layout === "foreign-top"
                                ? "border-primary bg-primary/10 text-primary"
                                : "border-border hover:border-primary/50",
                            )}
                          >
                            {t("scan.bilingualForeignTop")}
                          </button>
                        </div>
                      </div>
                      <div className="min-w-[96px] flex-1 space-y-0.5">
                        <label className="block text-[11px] font-medium text-muted-foreground">
                          {t("scan.bilingualOutlineWidth")}
                        </label>
                        <Input
                          type="number"
                          min={0}
                          max={4}
                          step={0.1}
                          value={bilingualDraft.outlineWidth}
                          onChange={(event) =>
                            setBilingualDraft((current) =>
                              current
                                ? {
                                    ...current,
                                    outlineWidth: Number(
                                      event.currentTarget.value,
                                    ),
                                  }
                                : current,
                            )
                          }
                          className="h-8 w-full text-xs"
                        />
                      </div>
                      <div className="min-w-[96px] flex-1 space-y-0.5">
                        <label className="block text-[11px] font-medium text-muted-foreground">
                          {t("scan.bilingualShadowWidth")}
                        </label>
                        <Input
                          type="number"
                          min={0}
                          max={4}
                          step={0.1}
                          value={bilingualDraft.shadowWidth}
                          onChange={(event) =>
                            setBilingualDraft((current) =>
                              current
                                ? {
                                    ...current,
                                    shadowWidth: Number(
                                      event.currentTarget.value,
                                    ),
                                  }
                                : current,
                            )
                          }
                          className="h-8 w-full text-xs"
                        />
                      </div>
                      <div className="min-w-[96px] flex-1 space-y-0.5">
                        <label className="block text-[11px] font-medium text-muted-foreground">
                          {t("scan.bilingualFontSizeTop")}
                        </label>
                        <Input
                          type="number"
                          min={6}
                          max={48}
                          step={0.5}
                          value={bilingualDraft.fontSizeTop}
                          onChange={(event) =>
                            setBilingualDraft((current) =>
                              current
                                ? {
                                    ...current,
                                    fontSizeTop: Number(
                                      event.currentTarget.value,
                                    ),
                                  }
                                : current,
                            )
                          }
                          className="h-8 w-full text-xs"
                        />
                      </div>
                      <div className="min-w-[96px] flex-1 space-y-0.5">
                        <label className="block text-[11px] font-medium text-muted-foreground">
                          {t("scan.bilingualFontSizeBottom")}
                        </label>
                        <Input
                          type="number"
                          min={4}
                          max={36}
                          step={0.5}
                          value={bilingualDraft.fontSizeBottom}
                          onChange={(event) =>
                            setBilingualDraft((current) =>
                              current
                                ? {
                                    ...current,
                                    fontSizeBottom: Number(
                                      event.currentTarget.value,
                                    ),
                                  }
                                : current,
                            )
                          }
                          className="h-8 w-full text-xs"
                        />
                      </div>
                      <div className="min-w-[180px] flex-1 space-y-0.5">
                        <label className="block text-[11px] font-medium text-muted-foreground">
                          {t("scan.bilingualOutlineColor")}
                        </label>
                        <div className="flex w-full items-center gap-1">
                          <input
                            type="color"
                            value={bilingualDraft.outlineColor}
                            onChange={(event) =>
                              setBilingualDraft((current) =>
                                current
                                  ? {
                                      ...current,
                                      outlineColor: event.currentTarget.value,
                                    }
                                  : current,
                              )
                            }
                            className="h-8 w-8 shrink-0 cursor-pointer rounded-md border border-border bg-transparent"
                            aria-label={t("scan.bilingualOutlineColor")}
                          />
                          <Input
                            value={bilingualDraft.outlineColor}
                            onChange={(event) =>
                              setBilingualDraft((current) =>
                                current
                                  ? {
                                      ...current,
                                      outlineColor: event.currentTarget.value,
                                    }
                                  : current,
                              )
                            }
                            className="h-8 w-full min-w-0 font-mono text-xs"
                          />
                        </div>
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="h-8 w-8 shrink-0 px-0"
                        title={t("scan.bilingualRestoreDefaults")}
                        onClick={() =>
                          setBilingualDraft(defaultBilingualDraft())
                        }
                      >
                        <RotateCcw className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        className="h-8 shrink-0"
                        onClick={() => void saveBilingualSettings()}
                      >
                        <Save className="mr-1 h-3.5 w-3.5" />
                        {t("scan.bilingualSettingsSave")}
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="h-8 shrink-0"
                        onClick={() => {
                          setBilingualSettingsOpen(false);
                          setBilingualDraft(null);
                        }}
                      >
                        {t("common.cancel")}
                      </Button>
                    </div>
                  </div>
                )}
              </>
            )}

            <WorkbenchSourceEntry
              directory={directory}
              configReady={!!config}
              processingMode={tab}
              uiText={uiText}
              onDirectoryChange={(value) => setDirectory(value)}
              browser={
                <SourceBrowserPanel
                  key={directory || watchDir}
                  onJobsCreated={(n, firstId) => {
                    setBrowseCreated((current) => current + n);
                    if (n > 0)
                      setLocation(firstId ? `/jobs/${firstId}` : "/jobs");
                  }}
                  subtitleMode={subtitleMode}
                  ocrEngine={ocrEngine}
                  ocrLanguage={ocrLanguage}
                  bilingualLayout={bilingualLayout}
                  processingMode={tab}
                  defaultPath={directory || watchDir}
                  uiText={uiText}
                  isRemuxMode={tab === "remux"}
                  embedded
                  onSelectMode={selectTab}
                />
              }
            />
          </>
        )}
        {browseCreated > 0 && (
          <div className="flex items-center justify-between rounded-lg border border-primary/20 bg-primary/5 px-3 py-2 text-sm text-primary">
            <span>{t("scan.jobsAdded", { count: browseCreated })}</span>
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() => setLocation("/jobs")}
            >
              {uiText.viewQueue}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
