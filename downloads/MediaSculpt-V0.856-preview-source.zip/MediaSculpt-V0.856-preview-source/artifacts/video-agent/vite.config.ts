import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";

const rawPort = process.env.PORT ?? "5173";

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const basePath = process.env.BASE_PATH ?? "/";

export default defineConfig({
  base: basePath,
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "src"),
      "@assets": path.resolve(
        import.meta.dirname,
        "..",
        "..",
        "attached_assets",
      ),
      "@workspace/api-client-react": path.resolve(
        import.meta.dirname,
        "..",
        "..",
        "lib",
        "api-client-react",
        "src",
        "index.ts",
      ),
    },
    dedupe: ["react", "react-dom"],
  },
  root: path.resolve(import.meta.dirname),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
    sourcemap: process.env.MEDIASCULPT_RELEASE !== "1",
  },
  server: {
    port,
    strictPort: true,
    host: "127.0.0.1",
    allowedHosts: true,
    fs: {
      strict: true,
    },
    proxy: {
      "/api": {
        // The native sidecar listens on 18080. Keep this fallback aligned with
        // the desktop runtime so direct Vite starts do not silently proxy to a
        // dead development port.
        target: `http://localhost:${process.env.API_PORT ?? "18080"}`,
        changeOrigin: true,
      },
    },
  },
  preview: {
    port,
    host: "127.0.0.1",
    allowedHosts: true,
  },
});
