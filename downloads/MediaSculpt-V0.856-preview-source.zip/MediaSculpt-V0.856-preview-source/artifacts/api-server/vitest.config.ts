import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: ["src/**/*.test.ts"],
    env: {
      // @workspace/db throws at import time without this; unit tests never
      // actually open a connection.
      DATABASE_URL: "postgres://test:test@localhost:5432/test",
      // Route tests through the same local SQLite dialect as the packaged
      // application; no test should require a developer PostgreSQL server.
      DATABASE_DRIVER: "sqlite",
      MEDIASCULPT_DATABASE_PATH: ":memory:",
      PORT: "0",
    },
  },
});
