import type { ChildProcess } from "node:child_process";
import { describe, expect, it, vi } from "vitest";

const { execFile } = vi.hoisted(() => ({
  execFile: vi.fn(
    (
      _file: string,
      _args: string[],
      _options: object,
      callback: (error: Error | null) => void,
    ) => {
      callback(null);
      return undefined;
    },
  ),
}));

vi.mock("node:child_process", () => ({ execFile }));

import { terminateProcessTree } from "./process-termination";

describe("terminateProcessTree", () => {
  it("kills the direct Windows child immediately and requests tree termination", () => {
    const child = { pid: 4321, kill: vi.fn() } as unknown as ChildProcess;

    terminateProcessTree(child, "SIGKILL", "win32");

    expect(child.kill).toHaveBeenCalledWith("SIGKILL");
    expect(execFile).toHaveBeenCalledWith(
      "taskkill",
      ["/F", "/T", "/PID", "4321"],
      { windowsHide: true },
      expect.any(Function),
    );
  });
});
