import { EventEmitter } from "node:events";
import type { ChildProcess } from "node:child_process";
import { describe, expect, it, vi } from "vitest";
import { JobProcessRegistry } from "./job-process-registry";

function fakeProcess(autoClose = false) {
  const process = new EventEmitter() as EventEmitter & {
    kill: ReturnType<typeof vi.fn>;
    pid?: number;
  };
  process.kill = vi.fn(() => {
    if (autoClose) queueMicrotask(() => process.emit("close"));
  });
  return process;
}

describe("JobProcessRegistry", () => {
  it("tracks processes and removes them after normal close", () => {
    const registry = new JobProcessRegistry();
    const process = fakeProcess();

    registry.track(7, process as unknown as ChildProcess);
    expect(registry.size(7)).toBe(1);
    process.emit("close");
    expect(registry.size(7)).toBe(0);
  });

  it("kills and clears every process for a cancelled job", () => {
    const registry = new JobProcessRegistry();
    const first = fakeProcess(true);
    const second = fakeProcess(true);
    registry.track(7, first as unknown as ChildProcess);
    registry.track(7, second as unknown as ChildProcess);

    registry.kill(7);

    expect(first.kill).toHaveBeenCalledWith("SIGKILL");
    expect(second.kill).toHaveBeenCalledWith("SIGKILL");
    expect(registry.size(7)).toBe(0);
  });

  it("uses a process-tree terminator on Windows so grandchildren cannot survive cancellation", async () => {
    const registryTerminator = vi.fn();
    const registry = new JobProcessRegistry("win32", registryTerminator);
    const process = fakeProcess();
    process.pid = 1234;

    registry.track(9, process as unknown as ChildProcess);
    const stopped = registry.kill(9);
    process.emit("close");
    await expect(stopped).resolves.toBe(true);

    expect(registryTerminator).toHaveBeenCalledWith(process, "SIGKILL");
    expect(process.kill).not.toHaveBeenCalled();
  });
});
