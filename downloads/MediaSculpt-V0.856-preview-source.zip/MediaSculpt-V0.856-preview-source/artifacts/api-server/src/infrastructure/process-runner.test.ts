import { describe, expect, it } from "vitest";
import { NodeProcessRunner } from "./process-runner";

const runner = new NodeProcessRunner();

describe("NodeProcessRunner", () => {
  it("returns stdout, stderr, exit code, and duration for a successful process", async () => {
    const result = await runner.run({
      executable: process.execPath,
      args: [
        "-e",
        "process.stdout.write('ready'); process.stderr.write('notice')",
      ],
      stage: "test-success",
    });

    expect(result.code).toBe(0);
    expect(result.stdout).toBe("ready");
    expect(result.stderr).toBe("notice");
    expect(result.durationMs).toBeGreaterThanOrEqual(0);
  });

  it("keeps a non-zero exit code and stderr instead of hiding the tool failure", async () => {
    const result = await runner.run({
      executable: process.execPath,
      args: ["-e", "process.stderr.write('bad input'); process.exit(7)"],
      stage: "test-failure",
    });

    expect(result.code).toBe(7);
    expect(result.stderr).toBe("bad input");
  });

  it("rejects an executable that cannot be started", async () => {
    await expect(
      runner.run({
        executable: "definitely-not-a-real-mediasculpt-tool",
        args: [],
        stage: "test-spawn-error",
      }),
    ).rejects.toThrow();
  });

  it("terminates a running child when the request is aborted", async () => {
    const controller = new AbortController();
    const pending = runner.run({
      executable: process.execPath,
      args: ["-e", "setTimeout(() => process.stdout.write('late'), 30000)"],
      signal: controller.signal,
      stage: "test-abort",
    });

    controller.abort();
    await expect(pending).rejects.toMatchObject({ name: "AbortError" });
  });

  it("bounds captured output while still draining a chatty process", async () => {
    const result = await runner.run({
      executable: process.execPath,
      args: [
        "-e",
        "process.stdout.write('HEAD'); const chunk='x'.repeat(65536); for (let i=0;i<64;i++) process.stdout.write(chunk); process.stdout.write('TAIL');",
      ],
      maxOutputBytes: 1024,
      stage: "test-bounded-output",
    });

    expect(result.code).toBe(0);
    expect(result.stdout).toContain("[output truncated");
    expect(result.stdout.endsWith("TAIL")).toBe(true);
    expect(Buffer.byteLength(result.stdout, "utf8")).toBeLessThan(2_000);
  });

  it("writes optional stdin and closes the pipe", async () => {
    const result = await runner.run({
      executable: process.execPath,
      args: [
        "-e",
        "process.stdin.setEncoding('utf8'); let value=''; process.stdin.on('data', d => value += d); process.stdin.on('end', () => process.stdout.write(value));",
      ],
      stdin: "secret-input",
      stage: "test-stdin",
    });

    expect(result.code).toBe(0);
    expect(result.stdout).toBe("secret-input");
  });

  it("rejects and terminates a process that exceeds its timeout", async () => {
    await expect(
      runner.run({
        executable: process.execPath,
        args: ["-e", "setTimeout(() => {}, 1000)"],
        timeoutMs: 50,
        stage: "test-timeout",
      }),
    ).rejects.toMatchObject({ name: "TimeoutError" });
  });
});
