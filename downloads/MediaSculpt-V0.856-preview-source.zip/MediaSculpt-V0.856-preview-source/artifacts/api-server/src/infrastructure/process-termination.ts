import { execFile, type ChildProcess } from "node:child_process";

export type ProcessTerminator = (
  child: ChildProcess,
  signal?: NodeJS.Signals,
) => void;

/**
 * Stop a process and, on Windows, its complete descendant tree.
 * `ChildProcess.kill()` only targets the immediate process on Windows; media
 * tools commonly start helper processes, so cancellation must use taskkill's
 * tree mode there. We still kill the direct child immediately: taskkill is
 * asynchronous and a failed/delayed taskkill must not leave the encoder
 * consuming CPU while the HTTP cancellation request has already returned.
 */
export function terminateProcessTree(
  child: ChildProcess,
  signal: NodeJS.Signals = "SIGKILL",
  platform: NodeJS.Platform = process.platform,
): void {
  if (platform === "win32" && typeof child.pid === "number" && child.pid > 0) {
    try {
      child.kill(signal);
    } catch {
      /* process already exited */
    }
    execFile(
      "taskkill",
      ["/F", "/T", "/PID", String(child.pid)],
      { windowsHide: true },
      (error) => {
        if (error) {
          try {
            child.kill(signal);
          } catch {
            /* process already exited */
          }
        }
      },
    );
    return;
  }
  try {
    child.kill(signal);
  } catch {
    /* process already exited */
  }
}
