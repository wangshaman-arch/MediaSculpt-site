import type { ChildProcess } from "node:child_process";
import { JobProcessRegistry } from "./job-process-registry";
import { processRunner } from "./process-runner";
import type { ProcessRunner } from "./process-types";

export class JobProcessController {
  readonly activeChildren = new Set<ChildProcess>();

  constructor(
    private readonly runner: ProcessRunner = processRunner,
    private readonly jobs = new JobProcessRegistry(),
    private readonly platform: NodeJS.Platform = process.platform,
  ) {}

  spawn(executable: string, args: string[]): ChildProcess {
    const child = this.runner.spawn({ executable, args }).child;
    this.activeChildren.add(child);
    child.once("close", () => this.activeChildren.delete(child));
    child.once("error", () => this.activeChildren.delete(child));
    return child;
  }

  spawnForJob(jobId: number, executable: string, args: string[], highPriority = false): ChildProcess {
    let command = executable;
    let commandArgs = args;
    if (this.platform !== "win32") {
      command = "nice";
      commandArgs = ["-n", highPriority ? "-5" : "10", executable, ...args];
    }
    return this.jobs.track(jobId, this.spawn(command, commandArgs));
  }

  killJob(jobId: number): Promise<boolean> {
    return this.jobs.kill(jobId);
  }

  clearJob(jobId: number): void {
    this.jobs.clear(jobId);
  }
}

export const jobProcessController = new JobProcessController();
