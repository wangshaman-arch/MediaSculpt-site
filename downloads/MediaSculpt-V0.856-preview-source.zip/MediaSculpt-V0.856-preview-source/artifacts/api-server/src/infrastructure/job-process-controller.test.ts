import { EventEmitter } from "node:events";
import type { ChildProcess } from "node:child_process";
import { describe, expect, it, vi } from "vitest";
import { JobProcessController } from "./job-process-controller";
import { JobProcessRegistry } from "./job-process-registry";
import type { ProcessRunner } from "./process-types";

function fakeProcess() {
  return new EventEmitter() as EventEmitter & { kill: ReturnType<typeof vi.fn> };
}

describe("JobProcessController", () => {
  it("applies Linux priority through nice while preserving the original arguments", () => {
    const child = fakeProcess();
    const runner = { spawn: vi.fn(() => ({ child })) } as unknown as ProcessRunner;
    const controller = new JobProcessController(runner, new JobProcessRegistry(), "linux");

    controller.spawnForJob(12, "ffmpeg", ["-i", "input.mkv"], true);

    expect(runner.spawn).toHaveBeenCalledWith({
      executable: "nice",
      args: ["-n", "-5", "ffmpeg", "-i", "input.mkv"],
    });
    expect(controller.activeChildren.has(child as unknown as ChildProcess)).toBe(true);
  });

  it("does not wrap commands with nice on Windows", () => {
    const child = fakeProcess();
    const runner = { spawn: vi.fn(() => ({ child })) } as unknown as ProcessRunner;
    const controller = new JobProcessController(runner, new JobProcessRegistry(), "win32");

    controller.spawnForJob(12, "ffmpeg.exe", ["-version"]);

    expect(runner.spawn).toHaveBeenCalledWith({ executable: "ffmpeg.exe", args: ["-version"] });
  });
});
