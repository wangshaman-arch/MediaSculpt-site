import type { ChildProcess } from "node:child_process";
import {
  terminateProcessTree,
  type ProcessTerminator,
} from "./process-termination";

export class JobProcessRegistry {
  private readonly processes = new Map<number, Set<ChildProcess>>();
  private readonly pendingKills = new Map<number, Promise<boolean>>();

  private readonly terminate: ProcessTerminator;

  constructor(
    private readonly platform: NodeJS.Platform = process.platform,
    terminate?: ProcessTerminator,
  ) {
    this.terminate =
      terminate ??
      ((child, signal) => terminateProcessTree(child, signal, this.platform));
  }

  track(jobId: number, child: ChildProcess): ChildProcess {
    let active = this.processes.get(jobId);
    if (!active) {
      active = new Set();
      this.processes.set(jobId, active);
    }
    active.add(child);
    child.once("close", () => this.remove(jobId, child));
    child.once("error", () => this.remove(jobId, child));
    return child;
  }

  async kill(jobId: number): Promise<boolean> {
    const pending = this.pendingKills.get(jobId);
    if (pending) return pending;

    const active = this.processes.get(jobId);
    if (!active || active.size === 0) return true;
    const children = [...active];
    // Remove the set before waiting so a second cancel request cannot send
    // another kill signal to the same process. The close listeners below still
    // remove their individual children safely.
    const stopping = this.stopChildren(jobId, children);
    this.pendingKills.set(jobId, stopping);
    try {
      return await stopping;
    } finally {
      if (this.pendingKills.get(jobId) === stopping) this.pendingKills.delete(jobId);
    }
  }

  size(jobId: number): number {
    return this.processes.get(jobId)?.size ?? 0;
  }

  clear(jobId: number): void {
    this.processes.delete(jobId);
  }

  private waitForExit(child: ChildProcess, timeoutMs = 10_000): Promise<boolean> {
    if (child.exitCode !== null || child.signalCode !== null) return Promise.resolve(true);
    return new Promise((resolve) => {
      let settled = false;
      const finish = (exited: boolean) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(exited);
      };
      const timer = setTimeout(() => finish(false), timeoutMs);
      child.once("close", () => finish(true));
      child.once("error", () => finish(true));
    });
  }

  private async stopChildren(jobId: number, children: ChildProcess[]): Promise<boolean> {
    for (const child of children) {
      try {
        this.terminate(child, "SIGKILL");
      } catch {
        // The process may already have exited; the exit wait below decides
        // whether cancellation can be reported as confirmed.
      }
    }
    this.processes.delete(jobId);
    const results = await Promise.all(children.map((child) => this.waitForExit(child)));
    return results.every(Boolean);
  }

  private remove(jobId: number, child: ChildProcess): void {
    const active = this.processes.get(jobId);
    if (!active) return;
    active.delete(child);
    if (active.size === 0) this.processes.delete(jobId);
  }
}
