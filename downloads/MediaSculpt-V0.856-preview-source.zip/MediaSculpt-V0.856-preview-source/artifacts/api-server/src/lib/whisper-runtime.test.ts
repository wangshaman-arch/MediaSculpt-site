import { describe, expect, it } from "vitest";
import { pipIndexCandidates, pipInstallCommand, pythonInstallDirectory, whisperEnvironment } from "./whisper-runtime";

describe("whisper runtime", () => {
  it("keeps Python and Whisper inside user-scoped MediaSculpt directories", () => {
    expect(pythonInstallDirectory("C:\\Users\\tester", "win32")).toContain("MediaSculpt");
    expect(pythonInstallDirectory("C:\\Users\\tester", "win32")).toContain("python");
    expect(whisperEnvironment("C:\\Users\\tester")).toContain("whisper-env");
  });

  it("upgrades and installs pip packages through python -m pip on Windows venvs", () => {
    const command = pipInstallCommand("C:\\Users\\tester\\.vx-agent\\whisper-env", "win32");

    expect(command.command).toBe("C:\\Users\\tester\\.vx-agent\\whisper-env\\Scripts\\python.exe");
    expect(command.prefixArgs).toEqual(["-m", "pip"]);
    expect(command.command).not.toContain("pip.exe");
  });

  it("provides domestic and official pip indexes in fallback order", () => {
    expect(pipIndexCandidates()).toEqual([
      "https://pypi.tuna.tsinghua.edu.cn/simple",
      "https://mirrors.aliyun.com/pypi/simple",
      "https://mirrors.cloud.tencent.com/pypi/simple",
      "https://pypi.org/simple",
    ]);
  });
});
