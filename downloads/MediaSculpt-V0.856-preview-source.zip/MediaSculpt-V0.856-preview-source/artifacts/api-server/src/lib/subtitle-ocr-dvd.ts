// Extracted from subtitle-ocr.ts: DVD VobSub OCR (HandBrake passthrough + ffmpeg frame decode).
import { deflateSync, inflateSync } from "node:zlib";
import { createHash } from "node:crypto";
import path from "node:path";
import { access } from "node:fs/promises";
import { resolveAiEndpoint, resolveApiKey, type AiProviderConfig } from "./ai-provider";
import { resolveToolPath } from "./tool-runtime";
import { findDvdTitles, resolveDvdVideoTsDir } from "./disc";
import { isGraphicSubtitleCodec } from "./subtitle-utils";
import { encodePng, toBlackOnWhite, decodePngRgba } from "./subtitle-ocr-png";
import { parsePgsSup } from "./subtitle-ocr-pgs";
import {
  type OcrEvent,
  type OcrEngine,
  type OcrResult,
  isDirectFrameGraphicCodec,
  computeOcrQuality,
  detectScriptLanguage,
  languageMatchesRequest,
  detectAutoTesseractLanguage,
  resolveOcrEngineAndLanguage,
  ocrWithTesseract,
  ocrWithRapidOcr,
  formatSrtTime,
  assembleSrt,
  validateOcrCompleteness,
  detectChineseVariant,
  ISO_TO_TESSERACT,
  ocrWithLlm,
  writeSrtBesideSource,
} from "./subtitle-ocr";

// ── DVD VobSub OCR (HandBrake passthrough → ffmpeg frame decode) ─────────────
type DvdOcrTarget = {
  discRoot: string;
  handbrakeTitleNumber: number;
  subtitleTrackNumber: number;
  subtitleLanguage: string | null;
};

type VobFrame = { ptsMs: number; png: Buffer; hash: string; size: number };

/** Resolve a DVD disc root from a folder (or an .IFO file), searching one
 *  level down so a parent folder containing several disc folders still works. */
async function resolveDiscRootForOcr(sourcePath: string): Promise<string | null> {
  const { stat, readdir } = await import("node:fs/promises");
  const { join, dirname } = await import("node:path");
  if (/\.ifo$/i.test(sourcePath)) {
    const videoTs = await resolveDvdVideoTsDir(dirname(sourcePath));
    return videoTs ? dirname(videoTs) : null;
  }
  if (await resolveDvdVideoTsDir(sourcePath)) return sourcePath;
  let entries: string[] = [];
  try {
    entries = await readdir(sourcePath);
  } catch {
    return null;
  }
  const candidates: string[] = [];
  for (const entry of entries) {
    const child = join(sourcePath, entry);
    try {
      const childStat = await stat(child);
      if (!childStat.isDirectory()) continue;
    } catch {
      continue;
    }
    if (await resolveDvdVideoTsDir(child)) candidates.push(child);
  }
  if (candidates.length === 0) return null;
  // Multiple disc folders: pick the one with the most VOB/IFO bytes.
  let best = candidates[0];
  let bestSize = -1;
  for (const disc of candidates) {
    const videoTs = await resolveDvdVideoTsDir(disc);
    if (!videoTs) continue;
    const discEntries = await readdir(videoTs).catch(() => [] as string[]);
    let size = 0;
    for (const name of discEntries) {
      if (!/\.(vob|ifo)$/i.test(name)) continue;
      try {
        size += (await stat(join(videoTs, name))).size;
      } catch {
        // ignore unreadable files
      }
    }
    if (size > bestSize) {
      bestSize = size;
      best = disc;
    }
  }
  return best;
}

async function resolveDvdSubtitleTrack(
  discRoot: string,
  titleNumber: number,
  preferredLanguage: string,
): Promise<{ trackNumber: number; language: string | null }> {
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const execFileAsync = promisify(execFile);
  const handbrake = await resolveToolPath("handbrake");
  if (!handbrake) return { trackNumber: 1, language: null };
  try {
    const { stdout } = await execFileAsync(handbrake, ["--input", discRoot, "--title", String(titleNumber), "--scan", "--json"], { timeout: 120_000 });
    const parsed = extractHandBrakeJson(stdout) as {
      TitleList?: Array<{ SubtitleList?: Array<{ TrackNumber?: number; LanguageCode?: string }> }>;
    };
    const list = parsed?.TitleList?.[0]?.SubtitleList ?? [];
    if (!Array.isArray(list) || list.length === 0) return { trackNumber: 1, language: null };
    const requested = (preferredLanguage || "auto").trim().toLowerCase();
    const languageOf = (sub: { LanguageCode?: string } | undefined): string => String(sub?.LanguageCode ?? "").trim().toLowerCase();
    const pick = requested === "auto"
      ? list.find((sub) => ["zho", "chi", "zh", "cmn"].includes(languageOf(sub)))
        ?? list.find((sub) => languageOf(sub) === "eng")
        ?? list.find((sub) => languageOf(sub).length > 0)
        ?? list[0]
      : list.find((sub) => languageMatchesRequest(String(sub.LanguageCode ?? ""), requested)) ?? list[0];
    return {
      trackNumber: Number(pick?.TrackNumber) > 0 ? Number(pick.TrackNumber) : 1,
      language: languageOf(pick) || null,
    };
  } catch {
    return { trackNumber: 1, language: null };
  }
}

/**
 * HandBrake CLI prints a version banner and libdvdnav messages before the JSON
 * document, so raw `JSON.parse` always throws. Extract the outermost JSON
 * object instead (HandBrake wraps it as `JSON Title Set: { ... }`).
 */
export function extractHandBrakeJson(output: string): Record<string, unknown> | null {
  const ranges: Array<[number, number]> = [];
  // HandBrake prints a "Progress: {...}" object before the final scan JSON, so
  // anchor on the explicit "JSON Title Set:" marker when present.
  const marker = output.indexOf("JSON Title Set:");
  if (marker >= 0) {
    const start = output.indexOf("{", marker);
    const end = output.lastIndexOf("}");
    if (start >= 0 && end > start) ranges.push([start, end]);
  }
  const fallbackStart = output.indexOf("{");
  const fallbackEnd = output.lastIndexOf("}");
  if (fallbackStart >= 0 && fallbackEnd > fallbackStart) ranges.push([fallbackStart, fallbackEnd]);
  for (const [start, end] of ranges) {
    try {
      const parsed = JSON.parse(output.slice(start, end + 1));
      if (parsed && typeof parsed === "object") return parsed as Record<string, unknown>;
    } catch {
      // Try the next candidate range.
    }
  }
  return null;
}

export async function detectDvdOcrTarget(sourcePath: string, requestedTitleId?: string | null, preferredLanguage = "auto"): Promise<DvdOcrTarget | null> {
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const execFileAsync = promisify(execFile);
  const discRoot = await resolveDiscRootForOcr(sourcePath);
  if (!discRoot) return null;
  const handbrake = await resolveToolPath("handbrake");
  if (!handbrake) {
    throw new Error("未找到 HandBrakeCLI。DVD VobSub 字幕 OCR 需要 HandBrake 完成字幕轨直通提取，请先在工具管理器安装 HandBrake。");
  }
  // The job snapshot stores the selected title as "handbrake:1" / "hb:1" /
  // "dvd:1" or a bare number. Always honor the user's choice instead of
  // re-picking the longest title (which can be a menu or short extra).
  const titleMatch = /^(?:handbrake|hb|dvd)[:_ ](\d+)$/i.exec(requestedTitleId ?? "");
  const bareTitle = requestedTitleId && /^\d+$/.test(requestedTitleId) ? Number(requestedTitleId) : null;
  if (titleMatch || bareTitle !== null) {
    const titleNumber = titleMatch ? Number(titleMatch[1]) : bareTitle as number;
    const subtitleTrack = await resolveDvdSubtitleTrack(discRoot, titleNumber, preferredLanguage);
    return { discRoot, handbrakeTitleNumber: titleNumber, subtitleTrackNumber: subtitleTrack.trackNumber, subtitleLanguage: subtitleTrack.language };
  }
  try {
    const { stdout } = await execFileAsync(handbrake, ["--input", discRoot, "--title", "0", "--scan", "--json"], { timeout: 120_000 });
    const parsed = extractHandBrakeJson(stdout) as { TitleList?: Array<{ Index?: number; Duration?: { Seconds?: number } }> } | null;
    const titles = (parsed?.TitleList ?? []).filter((title) => typeof title.Index === "number" && title.Index > 0);
    const longest = titles.sort((a, b) => (b.Duration?.Seconds ?? 0) - (a.Duration?.Seconds ?? 0))[0];
    if (longest?.Index) {
      const subtitleTrack = await resolveDvdSubtitleTrack(discRoot, longest.Index, preferredLanguage);
      return { discRoot, handbrakeTitleNumber: longest.Index, subtitleTrackNumber: subtitleTrack.trackNumber, subtitleLanguage: subtitleTrack.language };
    }
  } catch {
    // scan failed — fall through to the IFO-based title number
  }
  const ifoTitles = await findDvdTitles(discRoot);
  const largest = ifoTitles.sort((a, b) => b.sizeBytes - a.sizeBytes)[0];
  if (!largest) return null;
  const subtitleTrack = await resolveDvdSubtitleTrack(discRoot, largest.titleNumber, preferredLanguage);
  return { discRoot, handbrakeTitleNumber: largest.titleNumber, subtitleTrackNumber: subtitleTrack.trackNumber, subtitleLanguage: subtitleTrack.language };
}

async function extractDvdSubtitleMkv(target: DvdOcrTarget): Promise<string> {
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const { mkdir, stat } = await import("node:fs/promises");
  const { tmpdir } = await import("node:os");
  const { join } = await import("node:path");
  const execFileAsync = promisify(execFile);
  const handbrake = await resolveToolPath("handbrake");
  if (!handbrake) throw new Error("未找到 HandBrakeCLI");
  const cacheDir = join(tmpdir(), "MediaSculpt", "ocr-cache");
  await mkdir(cacheDir, { recursive: true });
  // Include the subtitle track so switching tracks never reuses a cache built
  // from a different track.
  const key = createHash("sha256").update(`${target.discRoot.toLowerCase()}|${target.handbrakeTitleNumber}|${target.subtitleTrackNumber ?? 1}`).digest("hex").slice(0, 16);
  const mkvPath = join(cacheDir, `dvd-${key}-t${target.handbrakeTitleNumber}.mkv`);
  try {
    await stat(mkvPath);
    return mkvPath;
  } catch {
    // cache miss — encode once
  }
  await execFileAsync(handbrake, [
    "--input", target.discRoot,
    "--title", String(target.handbrakeTitleNumber),
    "--output", mkvPath,
    "-e", "x264",
    "--encoder-preset", "ultrafast",
    "--quality", "51",
    "--audio", "1",
    "--aencoder", "copy",
    "--subtitle", String(target.subtitleTrackNumber ?? 1),
    "--no-deinterlace",
    "--no-detelecine",
    "--no-comb-detect",
  ], { timeout: 60 * 60_000 });
  return mkvPath;
}

/**
 * 一次转换把标题的全部字幕轨带进 MKV（用于逐轨统计行数后择优识别），
 * 缓存按“标题”区分，不再绑定单条字幕轨。
 */
async function extractDvdSubtitleMkvAll(target: DvdOcrTarget): Promise<string> {
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const { mkdir, stat } = await import("node:fs/promises");
  const { tmpdir } = await import("node:os");
  const { join } = await import("node:path");
  const execFileAsync = promisify(execFile);
  const handbrake = await resolveToolPath("handbrake");
  if (!handbrake) throw new Error("未找到 HandBrakeCLI");
  const scanOut = await execFileAsync(
    handbrake,
    ["--input", target.discRoot, "--title", String(target.handbrakeTitleNumber), "--scan", "--json"],
    { timeout: 120_000 },
  );
  const parsed = extractHandBrakeJson(scanOut.stdout) as {
    TitleList?: Array<{ SubtitleList?: Array<{ TrackNumber?: number }> }>;
  };
  const subList = parsed?.TitleList?.[0]?.SubtitleList ?? [];
  const trackNumbers = subList
    .map((sub) => Number(sub.TrackNumber))
    .filter((num) => Number.isFinite(num) && num > 0);
  const subtitleArg = trackNumbers.length > 0 ? trackNumbers.join(",") : String(target.subtitleTrackNumber ?? 1);
  const cacheDir = join(tmpdir(), "MediaSculpt", "ocr-cache");
  await mkdir(cacheDir, { recursive: true });
  const key = createHash("sha256").update(`${target.discRoot.toLowerCase()}|${target.handbrakeTitleNumber}|all`).digest("hex").slice(0, 16);
  const mkvPath = join(cacheDir, `dvd-${key}-t${target.handbrakeTitleNumber}-all.mkv`);
  try {
    await stat(mkvPath);
    return mkvPath;
  } catch {
    // cache miss — encode once
  }
  await execFileAsync(handbrake, [
    "--input", target.discRoot,
    "--title", String(target.handbrakeTitleNumber),
    "--output", mkvPath,
    "-e", "x264",
    "--encoder-preset", "ultrafast",
    "--quality", "51",
    "--audio", "1",
    "--aencoder", "copy",
    "--subtitle", subtitleArg,
    "--no-deinterlace",
    "--no-detelecine",
    "--no-comb-detect",
  ], { timeout: 60 * 60_000 });
  return mkvPath;
}

/**
 * 逐轨统计 VobSub 字幕事件数，选行数最多的一轨用于识别；
 * 默认偏好：西方语言轨（英/西/法/德/意/葡等）优先，
 * 与首选轨行数差 ≤10% 或 ≤20 条时以首选轨为准；默认不识别日语/韩语字幕轨（跳过）。
 */
const BLOCKED_OCR_LANGUAGES = new Set(["jpn", "ja", "kor", "ko"]);
/** 西方语言（拉丁字母欧洲语言）ISO 639-1/2/3 代码。 */
const WESTERN_OCR_LANGUAGES = new Set([
  "en", "eng", "es", "spa", "fr", "fra", "de", "deu", "it", "ita", "pt", "por",
  "nl", "nld", "da", "dan", "sv", "swe", "no", "nor", "fi", "fin", "pl", "pol",
  "cs", "ces", "sk", "slk", "hu", "hun", "ro", "ron", "rum", "el", "ell",
]);

async function pickBestDvdSubtitleTrack(
  mkvPath: string,
  target: DvdOcrTarget,
  progress: (message: string) => Promise<void>,
  preferredLanguage?: string,
): Promise<{ frames: VobFrame[]; subTypeIndex: number; streamLanguage: string | null }> {
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const execFileAsync = promisify(execFile);
  const ffprobe = (await resolveToolPath("ffprobe")) ?? "ffprobe";
  const probeOut = await execFileAsync(ffprobe, ["-v", "error", "-print_format", "json", "-show_streams", mkvPath], { timeout: 30_000 });
  const parsed = JSON.parse(probeOut.stdout) as { streams?: Array<{ codec_type?: string; duration?: string; tags?: { language?: string } }> };
  const vStream = (parsed.streams ?? []).find((stream) => stream.codec_type === "video");
  const videoDurationMs = Number(vStream?.duration) > 0 ? Number(vStream?.duration) * 1000 : 0;
  const subStreams = (parsed.streams ?? []).filter((stream) => stream.codec_type === "subtitle");
  if (subStreams.length === 0) throw new Error("HandBrake 提取的 MKV 中没有字幕轨");
  const tracks: Array<{ subTypeIndex: number; count: number; language: string | null; frames: VobFrame[]; coverage: number }> = [];
  for (let i = 0; i < subStreams.length; i += 1) {
    let frames: VobFrame[] = [];
    try {
      frames = await decodeVobSubToFrames(mkvPath, i);
    } catch {
      frames = [];
    }
    const built = buildEventsFromVobFrames(frames);
    const count = built.events.length;
    const lastEndMs = built.events.length ? built.events[built.events.length - 1].endMs : 0;
    const coverage = videoDurationMs > 0 ? lastEndMs / videoDurationMs : 0;
    const language = String(subStreams[i]?.tags?.language ?? "").trim().toLowerCase() || null;
    const blocked = language !== null && BLOCKED_OCR_LANGUAGES.has(language);
    tracks.push({ subTypeIndex: i, count, language, frames, coverage });
    await progress(
      `字幕轨 ${i + 1}：${language ? language.toUpperCase() : "无语言标记"}，共 ${count} 条${blocked ? "（默认跳过日语/韩语）" : ""}`,
    );
  }
  const candidates = tracks.filter((track) => track.count > 0 && !BLOCKED_OCR_LANGUAGES.has(track.language ?? ""));
  const poolBase = candidates.length > 0 ? candidates : tracks.filter((track) => track.count > 0);
  if (poolBase.length === 0) throw new Error("DVD 中未解析到任何 VobSub 字幕事件");
  // 优先选「足够长」（字幕覆盖到尾端）的轨：残缺/只到前段的轨（如 39%）清出候选，
  // 避免浪费时间识别后再因覆盖率不足校验失败；无完整轨时回退原逻辑（不回归）。
  const longEnough = videoDurationMs >= 10 * 60_000 ? poolBase.filter((track) => track.coverage >= 0.8) : [];
  const pool = longEnough.length > 0 ? longEnough : poolBase;
  const best = pool.reduce((a, b) => (b.count > a.count ? b : a));
  // Honour an explicitly requested OCR language before the Western-language
  // default, so a Chinese target does not silently OCR the Spanish track.
  const requested = (preferredLanguage ?? "").trim().toLowerCase();
  const wantsSpecific = requested !== "" && requested !== "auto";
  const languageMatches = (language: string | null): boolean => {
    if (!language) return false;
    const value = language.toLowerCase();
    if (value === requested || value.startsWith(requested)) return true;
    const requestedTess = ISO_TO_TESSERACT[requested] ?? requested;
    const valueTess = ISO_TO_TESSERACT[value] ?? value;
    return requestedTess === valueTess;
  };
  const requestedTracks = wantsSpecific ? pool.filter((track) => languageMatches(track.language)) : [];
  const westernTracks = pool.filter((track) => WESTERN_OCR_LANGUAGES.has(track.language ?? ""));
  const preferred = westernTracks.length > 0
    ? westernTracks.reduce((a, b) => (b.count > a.count ? b : a))
    : undefined;
  const closeEnough = (candidate: typeof best) => best.count - candidate.count <= Math.max(best.count * 0.1, 20);
  const chosen = requestedTracks.length > 0
    ? requestedTracks.reduce((a, b) => (b.count > a.count ? b : a))
    : preferred !== undefined && (best === preferred || closeEnough(preferred)) ? preferred : best;
  await progress(`已选字幕轨：Track ${chosen.subTypeIndex + 1}（${chosen.language ? chosen.language.toUpperCase() : "无语言标记"}，${chosen.count} 条，覆盖 ${Math.round(chosen.coverage * 100)}%）`);
  return { frames: chosen.frames, subTypeIndex: chosen.subTypeIndex, streamLanguage: chosen.language };
}

async function decodeVobSubToFrames(mkvPath: string, preferredSubTypeIndex?: number): Promise<VobFrame[]> {
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const { mkdtemp, readdir, readFile, rm } = await import("node:fs/promises");
  const { tmpdir } = await import("node:os");
  const { join } = await import("node:path");
  const execFileAsync = promisify(execFile);
  const ffprobe = (await resolveToolPath("ffprobe")) ?? "ffprobe";
  const ffmpeg = (await resolveToolPath("ffmpeg")) ?? "ffmpeg";
  const probeOut = await execFileAsync(ffprobe, ["-v", "error", "-print_format", "json", "-show_streams", mkvPath], { timeout: 30_000 });
  const parsed = JSON.parse(probeOut.stdout) as { streams?: Array<{ index: number; codec_type?: string; codec_name?: string; width?: number; height?: number }> };
  const parsedStreams = parsed.streams ?? [];
  const subtitleStreams = parsedStreams.filter((stream) => stream.codec_type === "subtitle");
  const graphic = parsedStreams.find((stream) => isDirectFrameGraphicCodec(String(stream.codec_name ?? "")));
  if (!graphic) throw new Error("HandBrake 提取的 MKV 中没有可直接解码的图形字幕轨");
  // Filtergraph stream specifiers use the type-relative index (0-based among
  // subtitle streams), not the container stream index.
  const subTypeIndex = preferredSubTypeIndex ?? subtitleStreams.findIndex((stream) => stream.index === graphic.index);
  if (subTypeIndex < 0) throw new Error("无法定位图形字幕轨序号");
  const video = parsedStreams.find((stream) => stream.codec_type === "video");
  const videoWidth = Number(video?.width) > 0 ? Number(video?.width) : 720;
  const videoHeight = Number(video?.height) > 0 ? Number(video?.height) : 480;
  const scaleW = videoWidth * 2;
  const scaleH = videoHeight * 2;
  const dir = await mkdtemp(join(tmpdir(), "vx-vob-"));
  try {
    await execFileAsync(ffmpeg, [
      "-v", "error", "-y",
      "-i", mkvPath,
      "-filter_complex", `[0:s:${subTypeIndex}]format=rgba,scale=${scaleW}:${scaleH}:flags=lanczos,settb=AVTB[s]`,
      "-map", "[s]",
      "-fps_mode", "vfr",
      "-frame_pts", "1",
      "-c:v", "png",
      "-f", "image2",
      join(dir, "frame_%d.png"),
    ], { timeout: 10 * 60_000 });
    const files = await readdir(dir);
    const frames: VobFrame[] = [];
    for (const name of files) {
      const match = /^frame_(\d+)\.png$/.exec(name);
      if (!match) continue;
      const full = join(dir, name);
      const rawPng = await readFile(full);
      const decoded = decodePngRgba(rawPng);
      const png = encodePng(toBlackOnWhite(decoded.rgba, decoded.width, decoded.height), decoded.width, decoded.height);
      frames.push({
        ptsMs: Math.round(Number(match[1]) / 1000),
        png,
        hash: createHash("md5").update(png).digest("hex"),
        size: png.length,
      });
    }
    frames.sort((a, b) => a.ptsMs - b.ptsMs);
    return frames;
  } finally {
    await rm(dir, { recursive: true, force: true }).catch(() => {});
  }
}

function buildEventsFromVobFrames(frames: VobFrame[]): { events: OcrEvent[]; images: Array<{ index: number; png: Buffer }> } {
  if (frames.length === 0) return { events: [], images: [] };
  // The transparent "clear" bitmap is always the smallest identical frame set.
  const emptyHash = frames.reduce((min, frame) => (frame.size < min.size ? frame : min), frames[0]).hash;
  const events: OcrEvent[] = [];
  const images: Array<{ index: number; png: Buffer }> = [];
  let current: { startMs: number; hash: string; png: Buffer } | null = null;
  for (const frame of frames) {
    if (frame.hash === emptyHash) {
      if (current) {
        events.push({ index: events.length, startMs: current.startMs, endMs: frame.ptsMs, text: "" });
        images.push({ index: events.length - 1, png: current.png });
        current = null;
      }
      continue;
    }
    if (!current) {
      current = { startMs: frame.ptsMs, hash: frame.hash, png: frame.png };
    } else if (current.hash !== frame.hash) {
      events.push({ index: events.length, startMs: current.startMs, endMs: frame.ptsMs, text: "" });
      images.push({ index: events.length - 1, png: current.png });
      current = { startMs: frame.ptsMs, hash: frame.hash, png: frame.png };
    }
  }
  if (current) {
    events.push({ index: events.length, startMs: current.startMs, endMs: current.startMs + 3000, text: "" });
    images.push({ index: events.length - 1, png: current.png });
  }
  return { events, images };
}

export async function runDvdVobSubOcr(
  params: {
    sourcePath: string;
    config: AiProviderConfig;
    engine?: OcrEngine;
    language?: string;
    titleId?: string | null;
    onProgress?: (message: string) => void;
  },
  target: DvdOcrTarget,
): Promise<OcrResult> {
  const progress = async (message: string) => { await params.onProgress?.(message); };
  await progress("检测到 DVD 目录，正在提取全部 VobSub 字幕轨（首次需 HandBrake 转码，可能需 10-20 分钟）…");
  const mkvPath = await extractDvdSubtitleMkvAll(target);
  const picked = await pickBestDvdSubtitleTrack(mkvPath, target, progress, params.language);
  return runVobSubOcr(params, mkvPath, picked.subTypeIndex, picked.streamLanguage, {
    frames: picked.frames,
    streamLanguage: picked.streamLanguage,
  });
}

export async function runVobSubOcr(
  params: {
    sourcePath: string;
    config: AiProviderConfig;
    engine?: OcrEngine;
    language?: string;
    titleId?: string | null;
    outputBaseName?: string;
    onProgress?: (message: string) => void;
  },
  videoPath: string,
  preferredSubTypeIndex?: number,
  streamLanguage?: string | null,
  preDecoded?: { frames: VobFrame[]; streamLanguage: string | null },
): Promise<OcrResult> {
  const progress = async (message: string) => { await params.onProgress?.(message); };
  const language = params.language ?? "auto";
  await progress("图形字幕轨已就绪，正在解码字幕画面…");
  const frames = preDecoded?.frames ?? await decodeVobSubToFrames(videoPath, preferredSubTypeIndex);
  const effectiveStreamLanguage = preDecoded?.streamLanguage ?? streamLanguage;
  const { events, images } = buildEventsFromVobFrames(frames);
  if (images.length === 0) throw new Error("图形字幕中未解析到字幕事件");
  const coverageStart = formatSrtTime(events[0]?.startMs ?? 0);
  const coverageEnd = formatSrtTime(events[events.length - 1]?.endMs ?? 0);
  await progress(`解析到 ${images.length} 条图形字幕（时间范围 ${coverageStart} → ${coverageEnd}），正在识别…`);

  const { engine, ocrLanguage: preflightOcrLanguage } = await resolveOcrEngineAndLanguage({
    config: params.config,
    engine: params.engine,
    language,
    streamLanguage: effectiveStreamLanguage,
  });
  let ocrLanguage = preflightOcrLanguage;
  if (effectiveStreamLanguage && language === "auto") {
    await progress(`字幕轨语言标记：${effectiveStreamLanguage.toUpperCase()}，自动使用对应 OCR 语言`);
  }
  if (engine === "tesseract" && language === "auto" && !effectiveStreamLanguage) {
    const tesseractPath = await resolveToolPath("tesseract");
    if (tesseractPath) {
      ocrLanguage = await detectAutoTesseractLanguage(tesseractPath, images);
      await progress(`字幕轨无语言标记，自动检测 OCR 语言：${ocrLanguage}`);
    }
  }
  if (engine === "tesseract" && (ocrLanguage === "chi_sim" || ocrLanguage === "chi_tra")) {
    const tesseractPath = await resolveToolPath("tesseract");
    if (tesseractPath) {
      const variant = await detectChineseVariant(tesseractPath, images);
      if (variant !== ocrLanguage) {
        ocrLanguage = variant;
        await progress(`中文字幕检测为${variant === "chi_tra" ? "繁体" : "简体"}，切换 OCR 语言：${variant}`);
      }
    }
  }
  let recognized: Array<{ index: number; text: string; language: string; confidence?: number | null }>;
  if (engine === "tesseract") {
    await progress(`正在使用本地 Tesseract（${ocrLanguage}）识别 ${images.length} 条字幕…`);
    recognized = await ocrWithTesseract(images, ocrLanguage);
  } else if (engine === "llm") {
    await progress(`正在调用大模型识别 ${images.length} 条字幕…`);
    recognized = await ocrWithLlm(images, params.config, language);
  } else if (engine === "rapidocr") {
    await progress(`正在使用 RapidOCR（中文优化）识别 ${images.length} 条字幕…`);
    recognized = await ocrWithRapidOcr(images);
  } else {
    throw new Error(`OCR 引擎 "${engine}" 尚未实现`);
  }

  const filled = events.map((event) => {
    const item = recognized.find((entry) => entry.index === event.index);
    return { ...event, text: item?.text ?? "" };
  });
  const detectedLanguage = language !== "auto"
    ? language
    : (recognized.find((item) => item.language !== "unknown")?.language ?? detectScriptLanguage(filled.map((event) => event.text).join("\n")));
  const srtContent = assembleSrt(filled);
  if (!srtContent.trim()) throw new Error("OCR 识别结果为空");
  await validateOcrCompleteness({ events: filled, videoPath, label: "该字幕轨", onProgress: progress });
  const quality = computeOcrQuality(recognized, images.length);
  const srtPath = await writeSrtBesideSource(params.sourcePath, srtContent, params.outputBaseName);
  await progress(`已完成，生成 ${srtPath}`);
  return { srtPath, srtContent, events: filled, language: detectedLanguage, engine, qualityScore: quality.score, qualityConfidenceBased: quality.confidenceBased };
}
