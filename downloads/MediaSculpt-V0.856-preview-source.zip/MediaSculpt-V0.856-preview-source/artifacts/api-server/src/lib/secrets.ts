import { processRunner } from "../infrastructure/process-runner";

const DPAPI_PREFIX = "dpapi:";
const isWindows = process.platform === "win32";

function runPowerShell(script: string, input: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const child = processRunner.spawn({
      executable: "powershell",
      args: ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script],
      stdin: input,
      maxOutputBytes: 64 * 1024,
      timeoutMs: 60_000,
      stage: "secret-protection",
    }).child;
    let out = "";
    let err = "";
    child.stdout?.on("data", (d: Buffer) => { out += d.toString(); });
    child.stderr?.on("data", (d: Buffer) => { err += d.toString(); });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) resolve(out.trim());
      else reject(new Error(err.trim() || `powershell exit ${code}`));
    });
  });
}

/** 加密秘密：Windows 用当前用户的 DPAPI，非 Windows 暂返回原样（后续接入 Keychain）。 */
export async function encryptSecret(plain: string): Promise<string> {
  if (!plain) return "";
  if (!isWindows) return plain;
  const script =
    "Add-Type -AssemblyName System.Security; " +
    "$b=[Text.Encoding]::UTF8.GetBytes(([Console]::In.ReadToEnd())); " +
    "[Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Protect($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser))";
  const b64 = await runPowerShell(script, plain);
  return `${DPAPI_PREFIX}${b64}`;
}

/** 解密秘密：dpapi: 前缀按 DPAPI 解密；否则视为旧明文原样返回（迁移前兼容）。 */
export async function decryptSecret(stored: string | null | undefined): Promise<string> {
  if (!stored) return "";
  if (stored.startsWith(DPAPI_PREFIX)) {
    if (!isWindows) return stored.slice(DPAPI_PREFIX.length);
    const script =
      "Add-Type -AssemblyName System.Security; " +
      "$b=[Convert]::FromBase64String(([Console]::In.ReadToEnd())); " +
      "[Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser))";
    return runPowerShell(script, stored.slice(DPAPI_PREFIX.length));
  }
  return stored;
}

export function isEncryptedSecret(stored: string | null | undefined): boolean {
  return Boolean(stored && stored.startsWith(DPAPI_PREFIX));
}
