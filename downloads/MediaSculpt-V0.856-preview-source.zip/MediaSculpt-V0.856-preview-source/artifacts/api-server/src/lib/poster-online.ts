// Extracted from poster.ts: online poster candidate search (IMDb / TMDb / OMDb / Douban).
import fs from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { resolveToolPath } from "./tool-runtime";
import { fetchLike, resolvePosterProxyUrl, type FetchLike } from "./http-client";
import {
  posterSearchIdentityMatches,
  fetchJson,
  doubanPosterUrl,
  type PosterCandidate,
} from "./poster";

export async function findPosterCandidatesByOnline(params: {
  title?: string | null;
  titleEn?: string | null;
  year?: string | number | null;
  tmdbId?: number | null;
  tmdbApiKey?: string | null;
  omdbApiKey?: string | null;
  imdbId?: string | null;
  posterMirrorUrl?: string | null;
  proxyUrl?: string | null;
}): Promise<PosterCandidate[]> {
  const proxyUrl = await resolvePosterProxyUrl(params.proxyUrl ?? null);
  const zhTitle = params.title || params.titleEn || "";
  const enTitle = params.titleEn || params.title || "";
  const verifiedImdbId = params.imdbId && /^tt\d{7,8}$/i.test(params.imdbId.trim()) ? params.imdbId.trim() : null;
  const year = typeof params.year === "number"
    ? params.year
    : params.year && /^\d{4}$/.test(String(params.year))
      ? Number(params.year)
      : undefined;

  const queryVariants: string[] = [];
  const pushQuery = (value: string) => {
    const trimmed = value.trim();
    if (trimmed && !queryVariants.includes(trimmed)) queryVariants.push(trimmed);
  };
  // A verified IMDb id is the strongest identity signal, but it must not
  // disable title/year fallbacks: a local IMDb mirror may know the id while
  // having no poster of its own.
  pushQuery(zhTitle);
  pushQuery(enTitle);
  if (enTitle && year) pushQuery(`${enTitle} ${year}`);
  if (enTitle) pushQuery(enTitle.replace(/[.'’`]/g, "").replace(/\./g, " "));
  if (zhTitle && year) pushQuery(`${zhTitle} ${year}`);
  // 最多保留前 4 个变体，避免分析链路被过多查询拖慢
  queryVariants.splice(4);
  if (queryVariants.length === 0 && !params.tmdbId && !verifiedImdbId) return [];

  const attempts: Promise<PosterCandidate | null>[] = [];
  for (const variant of queryVariants) {
    attempts.push(
      (async (): Promise<PosterCandidate | null> => {
        try {
          const data = await fetchJson<{
            d?: Array<{
              id?: string;
              l?: string;
              y?: number | string;
              i?: { imageUrl?: string };
            }>;
          }>(`https://v3.sg.media-imdb.com/suggestion/x/${encodeURIComponent(variant)}.json`, proxyUrl, 10_000);
          const matches = (data?.d ?? [])
            .map((item) => ({
              item,
              exactId: Boolean(verifiedImdbId && item.id?.toLowerCase() === verifiedImdbId.toLowerCase()),
              exactIdentity: posterSearchIdentityMatches({
                actualTitle: item.l,
                actualYear: item.y,
                expectedTitle: params.title,
                expectedTitleEn: params.titleEn,
                expectedYear: year,
              }),
            }))
            .filter(({ item, exactId, exactIdentity }) =>
              /^tt\d{7,8}$/i.test(item.id ?? "")
              && /^https?:\/\//i.test(item.i?.imageUrl ?? "")
              && (exactId || exactIdentity),
            )
            .sort((a, b) => Number(b.exactId) - Number(a.exactId));
          const match = matches[0];
          if (!match?.item.i?.imageUrl) return null;
          return {
            url: match.item.i.imageUrl,
            source: "imdb",
            confidence: match.exactId ? "high" : "medium",
            matchedBy: match.exactId ? "imdb" : "title-year",
          } satisfies PosterCandidate;
        } catch {
          return null;
        }
      })(),
    );
    attempts.push(
      doubanPosterUrl(variant, {
        title: params.title,
        titleEn: params.titleEn,
        year,
      }, proxyUrl)
        .then((url) => url ? {
          url,
          source: "douban",
          confidence: "medium",
          matchedBy: "title-year",
        } satisfies PosterCandidate : null)
        .catch(() => null),
    );
  }

  if (params.tmdbApiKey && verifiedImdbId) {
    attempts.push(
      (async (): Promise<PosterCandidate | null> => {
        try {
          const data = await fetchJson<{
            movie_results?: Array<{ poster_path?: string | null }>;
            tv_results?: Array<{ poster_path?: string | null }>;
          }>(`https://api.themoviedb.org/3/find/${encodeURIComponent(verifiedImdbId)}?api_key=${encodeURIComponent(params.tmdbApiKey as string)}&external_source=imdb_id`, proxyUrl, 10_000);
          const item = [...(data?.movie_results ?? []), ...(data?.tv_results ?? [])].find((candidate) => candidate.poster_path);
          if (!item?.poster_path) return null;
          const base = params.posterMirrorUrl?.trim()
            ? params.posterMirrorUrl.replace(/\/+$/, "")
            : "https://image.tmdb.org/t/p/original";
          return { url: `${base}${item.poster_path}`, source: "tmdb", confidence: "high", matchedBy: "imdb" };
        } catch {
          return null;
        }
      })(),
    );
  }

  if (params.tmdbApiKey && params.tmdbId) {
    attempts.push(
      (async (): Promise<PosterCandidate | null> => {
        try {
          const data = await fetchJson<{ poster_path?: string | null }>(
            `https://api.themoviedb.org/3/movie/${encodeURIComponent(String(params.tmdbId))}?api_key=${encodeURIComponent(params.tmdbApiKey as string)}&language=en-US`,
            proxyUrl,
            10_000,
          );
          if (!data?.poster_path) return null;
          const base = params.posterMirrorUrl?.trim()
            ? params.posterMirrorUrl.replace(/\/+$/, "")
            : "https://image.tmdb.org/t/p/original";
          return { url: `${base}${data.poster_path}`, source: "tmdb", confidence: "high", matchedBy: "tmdb" };
        } catch {
          return null;
        }
      })(),
    );
  }

  if (params.tmdbApiKey && (enTitle || zhTitle)) {
    attempts.push(
      (async (): Promise<PosterCandidate | null> => {
        try {
          const paramsUrl = new URLSearchParams({ api_key: params.tmdbApiKey as string, query: enTitle || zhTitle, language: "en-US" });
          if (year) paramsUrl.set("year", String(year));
          const data = await fetchJson<{ results?: Array<{
            poster_path?: string | null;
            title?: string;
            original_title?: string;
            release_date?: string;
          }> }>(`https://api.themoviedb.org/3/search/movie?${paramsUrl}`, proxyUrl, 10_000);
          const first = (data?.results ?? []).find((item) => item.poster_path && posterSearchIdentityMatches({
            actualTitle: item.original_title || item.title,
            actualYear: item.release_date?.slice(0, 4),
            expectedTitle: params.title,
            expectedTitleEn: params.titleEn,
            expectedYear: year,
          }));
          if (!first?.poster_path) return null;
          const base = params.posterMirrorUrl?.trim()
            ? params.posterMirrorUrl.replace(/\/+$/, "")
            : "https://image.tmdb.org/t/p/original";
          return { url: `${base}${first.poster_path}`, source: "tmdb", confidence: verifiedImdbId ? "medium" : "high", matchedBy: "title-year" };
        } catch {
          return null;
        }
      })(),
    );
  }

  if (params.omdbApiKey && (enTitle || zhTitle || verifiedImdbId)) {
    attempts.push(
      (async (): Promise<PosterCandidate | null> => {
        try {
          const paramsUrl = verifiedImdbId
            ? new URLSearchParams({ apikey: params.omdbApiKey as string, i: verifiedImdbId })
            : new URLSearchParams({ apikey: params.omdbApiKey as string, t: enTitle || zhTitle });
          if (year) paramsUrl.set("y", String(year));
          const data = await fetchJson<{
            Poster?: string;
            Title?: string;
            Year?: string;
            imdbID?: string;
          }>(`https://www.omdbapi.com/?${paramsUrl}`, proxyUrl, 10_000);
          if (!data) return null;
          const identityMatches = verifiedImdbId
            ? data.imdbID?.trim().toLowerCase() === verifiedImdbId.toLowerCase()
            : posterSearchIdentityMatches({
              actualTitle: data.Title,
              actualYear: data.Year,
              expectedTitle: params.title,
              expectedTitleEn: params.titleEn,
              expectedYear: year,
            });
          return identityMatches && data.Poster && data.Poster !== "N/A"
            ? { url: data.Poster, source: "omdb", confidence: "high", matchedBy: verifiedImdbId ? "imdb" : "title-year" }
            : null;
        } catch {
          return null;
        }
      })(),
    );
  }

  const settled = await Promise.allSettled(attempts);
  const seen = new Set<string>();
  return settled.flatMap((entry) => {
    const candidate = entry.status === "fulfilled" ? entry.value : null;
    if (!candidate || !/^https?:\/\//i.test(candidate.url) || seen.has(candidate.url)) return [];
    seen.add(candidate.url);
    return [candidate];
  }).sort((a, b) => Number(b.confidence === "high") - Number(a.confidence === "high"));
}
