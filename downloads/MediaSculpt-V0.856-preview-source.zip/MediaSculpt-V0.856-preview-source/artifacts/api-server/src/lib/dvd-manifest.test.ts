import { describe, expect, it } from "vitest";
import { buildDvdStreamUid, buildDvdTitleUid } from "./dvd-manifest";

describe("DVD manifest identities", () => {
  it("keeps title identity independent from analysis array order", () => {
    const sourceFingerprint = "source-123";

    expect(buildDvdTitleUid({ sourceFingerprint, handbrakeTitleNumber: 3 }))
      .toBe(buildDvdTitleUid({ sourceFingerprint, handbrakeTitleNumber: 3 }));
    expect(buildDvdTitleUid({ sourceFingerprint, handbrakeTitleNumber: 3 }))
      .not.toBe(buildDvdTitleUid({ sourceFingerprint, handbrakeTitleNumber: 4 }));
  });

  it("gives same-type streams distinct stable identities by relative ordinal", () => {
    const titleUid = buildDvdTitleUid({ sourceFingerprint: "source-123", handbrakeTitleNumber: 3 });
    const first = buildDvdStreamUid({ titleUid, type: "audio", ordinal: 0, codecName: "ac3", language: "und", channels: 2 });
    const second = buildDvdStreamUid({ titleUid, type: "audio", ordinal: 1, codecName: "ac3", language: "und", channels: 2 });

    expect(first).not.toBe(second);
    expect(first).toBe(buildDvdStreamUid({ titleUid, type: "audio", ordinal: 0, codecName: "ac3", language: "und", channels: 2 }));
  });
});
