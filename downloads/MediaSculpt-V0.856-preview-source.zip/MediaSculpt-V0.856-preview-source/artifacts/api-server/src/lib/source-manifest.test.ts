import { describe, expect, it } from "vitest";
import { buildSourceManifest } from "./source-manifest";

describe("source manifest", () => {
  it("normalizes a regular media file", () => {
    expect(buildSourceManifest({ filePath: "/media/movie.mkv", mediaType: "video" })).toEqual({
      version: 1,
      kind: "file",
      mediaType: "video",
      path: "/media/movie.mkv",
    });
  });

  it("keeps selected disc title metadata", () => {
    expect(buildSourceManifest({ filePath: "/disc", mediaType: "dvd", mainTrackPath: "/disc/VIDEO_TS/VTS_01_0.IFO" })).toEqual({
      version: 1,
      kind: "disc",
      mediaType: "dvd",
      path: "/disc",
      mainTrackPath: "/disc/VIDEO_TS/VTS_01_0.IFO",
    });
  });
});
