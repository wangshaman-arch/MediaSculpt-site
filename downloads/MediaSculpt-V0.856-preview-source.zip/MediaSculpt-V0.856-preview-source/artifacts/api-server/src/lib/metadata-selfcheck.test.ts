import { describe, expect, it, vi } from "vitest";
import {
  runMetadataSelfCheck,
  SELF_CHECK_DEFAULT_CASES,
  type SelfCheckOptions,
} from "./metadata-selfcheck";
import type { LookupOutcome, MetadataResult } from "./metadata";

function candidate(overrides: Partial<MetadataResult> = {}): MetadataResult {
  return {
    title: "A Beautiful Mind",
    titleEn: "A Beautiful Mind",
    year: 2001,
    imdbId: "tt0268978",
    poster: "https://example.com/poster.jpg",
    mediaType: "movie",
    source: "imdb",
    ...overrides,
  } as MetadataResult;
}

function stubLookup(outcomeFor: (query: string) => LookupOutcome) {
  return vi.fn(async ({ rawQuery }: { rawQuery: string }) => outcomeFor(rawQuery));
}

/**
 * 自检必须与开发机无关：真实探测会去连本机的代理端口，所以默认注入"没有
 * 代理"，需要代理行为的用例自己覆盖 detectProxy。
 */
function run(options: SelfCheckOptions) {
  return runMetadataSelfCheck({ detectProxy: async () => null, ...options });
}

const baseConfig = { tmdbApiKey: null, omdbApiKey: null, imdbTitleCount: 0 };

describe("metadata self-check", () => {
  it("reports an identified case as identified and carries the poster flag", async () => {
    const options: SelfCheckOptions = {
      cases: [{ query: "A Beautiful Mind", year: 2001, expect: "A Beautiful Mind" }],
      config: baseConfig,
      lookup: stubLookup(() => ({ results: [candidate()], errors: [] })),
      now: () => new Date("2026-09-25T00:00:00.000Z"),
    };
    const report = await runMetadataSelfCheck(options);
    expect(report.health).toBe("ok");
    expect(report.checkedAt).toBe("2026-09-25T00:00:00.000Z");
    expect(report.summary).toMatchObject({ total: 1, identified: 1, rejected: 0, noCandidate: 0, error: 0 });
    expect(report.cases[0].outcome).toBe("identified");
    expect(report.cases[0].candidate).toMatchObject({
      imdbId: "tt0268978",
      hasPoster: true,
      source: "imdb",
    });
  });

  // The distinction that matters: a provider DID answer, but the identity gate
  // refused it. Reporting that as "no candidate" would hide a matching bug.
  it("distinguishes a rejected candidate from an absent one", async () => {
    const options: SelfCheckOptions = {
      cases: [
        { query: "A Better Tomorrow", year: 1986 },
        { query: "Nonexistent Film Title", year: 1899 },
      ],
      config: baseConfig,
      lookup: stubLookup((query) =>
        query === "A Better Tomorrow"
          ? {
              results: [candidate({ title: "A Better Tomorrow II", titleEn: "A Better Tomorrow II", year: 1987 })],
              errors: [],
            }
          : { results: [], errors: [] },
      ),
    };
    const report = await runMetadataSelfCheck(options);
    expect(report.cases[0].outcome).toBe("rejected");
    expect(report.cases[0].rejectedCount).toBe(1);
    expect(report.cases[0].candidate).toBeNull();
    expect(report.cases[1].outcome).toBe("no-candidate");
    expect(report.summary).toMatchObject({ rejected: 1, noCandidate: 1, identified: 0 });
    // Something answered but nothing survived: that is degraded, not broken.
    expect(report.health).toBe("degraded");
  });

  it("reports provider errors instead of swallowing them", async () => {
    const options: SelfCheckOptions = {
      cases: [{ query: "A Beautiful Mind", year: 2001 }],
      config: baseConfig,
      lookup: stubLookup(() => ({ results: [], errors: ["IMDb在线: HTTP 503"] })),
    };
    const report = await runMetadataSelfCheck(options);
    expect(report.cases[0].outcome).toBe("error");
    expect(report.cases[0].errors).toContain("IMDb在线: HTTP 503");
    expect(report.health).toBe("broken");
  });

  it("survives a lookup that throws and still returns a full report", async () => {
    const options: SelfCheckOptions = {
      cases: [{ query: "A Beautiful Mind", year: 2001 }],
      config: baseConfig,
      lookup: vi.fn(async () => {
        throw new Error("connection reset");
      }),
    };
    const report = await runMetadataSelfCheck(options);
    expect(report.cases[0].outcome).toBe("error");
    expect(report.cases[0].errors[0]).toContain("connection reset");
    expect(report.summary.total).toBe(1);
  });

  // A configured-but-unusable source must be visible, not silently skipped.
  it("lists which sources are enabled, disabled, or unavailable", async () => {
    const noKeys = await run({
      cases: [],
      config: baseConfig,
      lookup: stubLookup(() => ({ results: [], errors: [] })),
    });
    const byId = Object.fromEntries(noKeys.sources.map((source) => [source.id, source]));
    expect(byId["imdb-suggestion"].status).toBe("enabled");
    expect(byId.douban.status).toBe("enabled");
    expect(byId.douban.detail).toContain("bridge");
    expect(byId.wikipedia.status).toBe("enabled");
    expect(byId.tmdb.status).toBe("disabled");
    expect(byId.tmdb.detail).toContain("no API key");
    expect(byId.omdb.status).toBe("disabled");
    expect(byId["imdb-local"].status).toBe("disabled");

    const withKeys = await run({
      cases: [],
      config: { tmdbApiKey: "x", omdbApiKey: "y", imdbTitleCount: 1234 },
      lookup: stubLookup(() => ({ results: [], errors: [] })),
    });
    const keyed = Object.fromEntries(withKeys.sources.map((source) => [source.id, source]));
    expect(keyed.tmdb.status).toBe("enabled");
    expect(keyed.omdb.status).toBe("enabled");
    expect(keyed["imdb-local"].status).toBe("enabled");
    expect(keyed["imdb-local"].detail).toContain("1234");
  });

  it("passes the query year through to the lookup and to the identity gate", async () => {
    const lookup = stubLookup(() => ({
      results: [candidate({ title: "Simply Anne Sophie", titleEn: "Simply Anne Sophie", year: 2006 })],
      errors: [],
    }));
    const report = await run({
      cases: [{ query: "Simply Anne Sophie", year: 2007 }],
      config: baseConfig,
      lookup,
    });
    expect(lookup).toHaveBeenCalledWith(expect.objectContaining({ rawQuery: "Simply Anne Sophie", year: 2007 }));
    // ±1 year is tolerated by the gate, so a one-year offset still identifies.
    expect(report.cases[0].outcome).toBe("identified");
  });

  it("ships default cases that cover the three filename shapes that broke", () => {
    expect(SELF_CHECK_DEFAULT_CASES.map((entry) => entry.query)).toEqual([
      "A Beautiful Mind",
      "The Age of Innocence",
      "2046",
    ]);
  });

  // The capability ladder is the user-facing half of graceful degradation: a
  // customer with no AI must be able to see which tier is active and what
  // enabling the next one would add, instead of guessing why fields are empty.
  it("reports the active capability tier and what the next one adds", async () => {
    const report = await run({
      cases: [],
      config: baseConfig,
      lookup: stubLookup(() => ({ results: [], errors: [] })),
    });
    expect(report.capability.current).toBe("keyless");
    const byId = Object.fromEntries(report.capability.tiers.map((tier) => [tier.id, tier]));
    expect(byId.filename.available).toBe(true);
    expect(byId.keyless.available).toBe(true);
    expect(byId.keyed.available).toBe(false);
    expect(byId.keyed.requirement).toContain("TMDb");
    expect(byId.keyed.provides).toContain("multiple directors");
    expect(byId.ai.available).toBe(false);
    expect(byId.ai.provides).toContain("generated synopsis");
  });

  it("moves the active tier up as keys are added", async () => {
    const lookup = stubLookup(() => ({ results: [], errors: [] }));
    const keyed = await run({
      cases: [],
      config: { tmdbApiKey: "k", omdbApiKey: null, imdbTitleCount: 0 },
      lookup,
    });
    expect(keyed.capability.current).toBe("keyed");
    expect(keyed.capability.tiers.find((tier) => tier.id === "keyed")?.requirement).toBeNull();

    const withAi = await run({
      cases: [],
      config: { tmdbApiKey: null, omdbApiKey: null, imdbTitleCount: 0, aiAvailable: true },
      lookup,
    });
    expect(withAi.capability.current).toBe("ai");
    expect(withAi.capability.tiers.find((tier) => tier.id === "ai")?.available).toBe(true);
  });

  // A DeepSeek-only setup is a supported configuration: the AI tier must be
  // reported as available even though no TMDb/OMDb key exists, otherwise a user
  // with a working LLM key is told the top tier is out of reach.
  it("reports the AI tier for a user who only configured an LLM provider", async () => {
    const report = await run({
      cases: [],
      config: { tmdbApiKey: null, omdbApiKey: null, imdbTitleCount: 0, aiAvailable: true },
      lookup: stubLookup(() => ({ results: [], errors: [] })),
    });
    expect(report.capability.current).toBe("ai");
    const keyed = report.capability.tiers.find((tier) => tier.id === "keyed");
    expect(keyed?.available).toBe(false);
    expect(keyed?.requirement).toContain("TMDb");
  });

  // "我填了代理却还是空的" 曾经完全无法从报告里看出来：报告里没有任何一行
  // 说明代理是否生效。分开报告配置值、探测值与实际生效值，用户才能一眼判断
  // VPN 到底有没有被识别到。
  it("reports which proxy is configured, which was detected, and which is used", async () => {
    const configured = await run({
      cases: [],
      config: baseConfig,
      lookup: stubLookup(() => ({ results: [], errors: [] })),
      proxyUrl: "  http://127.0.0.1:10809  ",
      detectProxy: async () => "http://127.0.0.1:12334",
    });
    expect(configured.network).toEqual({
      configuredProxyUrl: "http://127.0.0.1:10809",
      detectedProxyUrl: "http://127.0.0.1:12334",
      effectiveProxyUrl: "http://127.0.0.1:10809",
    });

    const autoDetected = await run({
      cases: [],
      config: baseConfig,
      lookup: stubLookup(() => ({ results: [], errors: [] })),
      detectProxy: async () => "http://127.0.0.1:12334",
    });
    expect(autoDetected.network).toEqual({
      configuredProxyUrl: null,
      detectedProxyUrl: "http://127.0.0.1:12334",
      effectiveProxyUrl: "http://127.0.0.1:12334",
    });
  });

  it("hands the effective proxy to the lookup so the report matches the query", async () => {
    const lookup = stubLookup(() => ({ results: [], errors: [] }));
    await run({
      cases: [{ query: "A Beautiful Mind", year: 2001 }],
      config: baseConfig,
      lookup,
      detectProxy: async () => "http://127.0.0.1:12334",
    });
    expect(lookup).toHaveBeenCalledWith(
      expect.objectContaining({ proxyUrl: "http://127.0.0.1:12334" }),
    );
  });

  // 探测失败只说明"没有代理可用"，绝不能让整份自检变成失败。
  it("reports no proxy when detection throws instead of failing the whole check", async () => {
    const report = await run({
      cases: [],
      config: baseConfig,
      lookup: stubLookup(() => ({ results: [], errors: [] })),
      detectProxy: async () => {
        throw new Error("probe exploded");
      },
    });
    expect(report.network).toEqual({
      configuredProxyUrl: null,
      detectedProxyUrl: null,
      effectiveProxyUrl: null,
    });
    expect(report.health).toBe("broken");
  });
});
