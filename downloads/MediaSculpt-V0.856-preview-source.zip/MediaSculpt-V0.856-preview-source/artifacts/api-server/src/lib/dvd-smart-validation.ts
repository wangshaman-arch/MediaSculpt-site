export type DvdCandidateAvailability = "confirmed" | "unavailable";
export type DvdCandidateValidationStatus = "passed" | "failed" | "unverified";

export type DvdSmartCandidateInput = {
  titleId: string;
  titleNumber: number;
  durationSeconds: number | null;
  chapterStarts: number[];
  videoSignature: string;
  audioSignature: string;
  subtitleSignature: string;
  availabilityStatus: DvdCandidateAvailability;
  validationStatus: DvdCandidateValidationStatus;
  validationFailureReason?: string | null;
  physicalVtsNumbers?: number[];
  contentFingerprint?: string | null;
};

export type DvdSmartCandidateVerdict = {
  titleId: string;
  titleNumber: number;
  status: "selected" | "duplicate" | "rejected";
  reason: string;
  fingerprint: string | null;
};

export type DvdSmartCapacity = {
  physicalBytes: number | null;
  countedPhysicalBytes: number;
  coveragePercent: number | null;
  mappingComplete: boolean;
  warnings: string[];
};

export type DvdSmartDecision = {
  selectedTitleIds: string[];
  candidates: DvdSmartCandidateVerdict[];
  confidence: "high" | "medium" | "low";
  requiresUserSelection: boolean;
  reasons: string[];
  capacity: DvdSmartCapacity;
};

export type DvdSmartValidationInput = {
  candidates: DvdSmartCandidateInput[];
  physicalBytes: number | null;
  vtsSizes: ReadonlyMap<number, number>;
};

const MIN_FEATURE_SECONDS = 300;
const DURATION_TOLERANCE_SECONDS = 1.5;
const CHAPTER_TOLERANCE_SECONDS = 2;

function normalizedNumber(value: number, precision = 1): string {
  const factor = 10 ** precision;
  return (Math.round(value * factor) / factor).toFixed(precision);
}

function buildFingerprint(candidate: DvdSmartCandidateInput): string | null {
  if (candidate.durationSeconds == null || candidate.durationSeconds <= 0) return null;
  const chapters = candidate.chapterStarts.map((value) => normalizedNumber(value, 0)).join(",");
  return [
    normalizedNumber(candidate.durationSeconds, 1),
    chapters,
    candidate.videoSignature.trim().toLowerCase(),
    candidate.audioSignature.trim().toLowerCase(),
    candidate.subtitleSignature.trim().toLowerCase(),
  ].join("|");
}

function sameStrongFingerprint(left: DvdSmartCandidateInput, right: DvdSmartCandidateInput): boolean {
  if (left.durationSeconds == null || right.durationSeconds == null) return false;
  if (Math.abs(left.durationSeconds - right.durationSeconds) > DURATION_TOLERANCE_SECONDS) return false;
  if (left.videoSignature.trim().toLowerCase() !== right.videoSignature.trim().toLowerCase()) return false;
  if (left.audioSignature.trim().toLowerCase() !== right.audioSignature.trim().toLowerCase()) return false;
  if (left.subtitleSignature.trim().toLowerCase() !== right.subtitleSignature.trim().toLowerCase()) return false;
  if (left.chapterStarts.length !== right.chapterStarts.length) return false;
  if (!left.chapterStarts.every((value, index) => Math.abs(value - right.chapterStarts[index]) <= CHAPTER_TOLERANCE_SECONDS)) return false;
  const leftVts = new Set(left.physicalVtsNumbers ?? []);
  const sharesPhysicalUnit = (right.physicalVtsNumbers ?? []).some((value) => leftVts.has(value));
  const sharesContentFingerprint = Boolean(left.contentFingerprint && right.contentFingerprint && left.contentFingerprint === right.contentFingerprint);
  // Metadata-only equality is not enough: independent films often share the
  // same MPEG-2/AC-3/chapters shape. Require physical or content evidence.
  return sharesPhysicalUnit || sharesContentFingerprint;
}

function physicalCapacity(input: DvdSmartValidationInput, selected: DvdSmartCandidateInput[]): DvdSmartCapacity {
  const warnings: string[] = [];
  const claimed = new Set<number>();
  let counted = 0;
  let mappingComplete = true;
  for (const candidate of selected) {
    const mappings = candidate.physicalVtsNumbers?.filter((value) => Number.isInteger(value) && value > 0) ?? [];
    if (mappings.length === 0) {
      mappingComplete = false;
      continue;
    }
    for (const vtsNumber of mappings) {
      if (claimed.has(vtsNumber)) continue;
      const size = input.vtsSizes.get(vtsNumber);
      if (typeof size !== "number" || !Number.isFinite(size) || size <= 0) {
        mappingComplete = false;
        continue;
      }
      claimed.add(vtsNumber);
      counted += size;
    }
  }
  if (input.physicalBytes != null && Number.isFinite(input.physicalBytes) && input.physicalBytes >= 0 && counted > input.physicalBytes) {
    warnings.push(`映射后的物理容量 ${counted} 字节超过物理容量上限（源盘 ${input.physicalBytes} 字节），已限制为源盘容量`);
    counted = input.physicalBytes;
  }
  const physicalBytes = input.physicalBytes != null && Number.isFinite(input.physicalBytes) && input.physicalBytes >= 0
    ? input.physicalBytes
    : null;
  return {
    physicalBytes,
    countedPhysicalBytes: counted,
    coveragePercent: physicalBytes && physicalBytes > 0 ? Math.min(100, Number(((counted / physicalBytes) * 100).toFixed(2))) : null,
    mappingComplete,
    warnings,
  };
}

export function validateDvdCandidates(input: DvdSmartValidationInput): DvdSmartDecision {
  const longCandidates = input.candidates.filter((candidate) => (
    candidate.availabilityStatus === "confirmed"
    && candidate.validationStatus === "passed"
    && (candidate.durationSeconds ?? 0) >= MIN_FEATURE_SECONDS
  ));
  const hasLongFeature = longCandidates.length > 0;
  let selected: DvdSmartCandidateInput[] = [];
  const verdicts: DvdSmartCandidateVerdict[] = [];
  const reasons: string[] = [];
  let hasRejectedEvidence = false;
  let requiresManualPhysicalSelection = false;

  for (const candidate of input.candidates) {
    const fingerprint = buildFingerprint(candidate);
    const base = { titleId: candidate.titleId, titleNumber: candidate.titleNumber, fingerprint };
    if (candidate.availabilityStatus === "unavailable") {
      hasRejectedEvidence = true;
      verdicts.push({ ...base, status: "rejected", reason: candidate.validationFailureReason ?? "标题无法读取" });
      continue;
    }
    if (candidate.validationStatus !== "passed") {
      hasRejectedEvidence = true;
      verdicts.push({ ...base, status: "rejected", reason: candidate.validationFailureReason ?? "标题尚未通过完整读取校验" });
      continue;
    }
    if (hasLongFeature && (candidate.durationSeconds ?? 0) < MIN_FEATURE_SECONDS) {
      verdicts.push({ ...base, status: "rejected", reason: "短标题/菜单，不作为正片自动选择" });
      continue;
    }
    const duplicate = selected.find((item) => sameStrongFingerprint(item, candidate));
    if (duplicate) {
      verdicts.push({ ...base, status: "duplicate", reason: `与 ${duplicate.titleId} 的章节、流轨和时长指纹一致`, fingerprint });
      continue;
    }
    selected.push(candidate);
    verdicts.push({ ...base, status: "selected", reason: "通过读取校验，作为独立标题保留", fingerprint });
  }

  // A logical DVD title can be a different PGC over the same VTS payload.
  // Without an exact physical mapping, selecting several long titles by
  // default can count the same bytes and duration more than once. Keep the
  // longest verified title as the safe automatic choice and require the user
  // to confirm any additional title explicitly.
  if (selected.length > 1 && selected.some((candidate) => !candidate.physicalVtsNumbers?.length)) {
    const primary = selected
      .slice()
      .sort((left, right) => (right.durationSeconds ?? 0) - (left.durationSeconds ?? 0) || left.titleNumber - right.titleNumber)[0];
    if (primary) {
      const primaryId = primary.titleId;
      for (const verdict of verdicts) {
        if (verdict.status === "selected" && verdict.titleId !== primaryId) {
          verdict.status = "rejected";
          verdict.reason = "多个长标题没有可靠的物理 VTS 映射，为避免容量和时长重复，需手动确认";
        }
      }
      selected = [primary];
      requiresManualPhysicalSelection = true;
      reasons.push("多个长标题缺少可靠的物理 VTS 映射，已只自动选择最长标题；其余标题需手动确认，避免重复计算容量和总时长");
    }
  }

  if (selected.length === 0) {
    reasons.push("没有找到通过完整读取校验的可用长标题");
  } else if (selected.length > 1) {
    reasons.push(`发现 ${selected.length} 个互不重复的长标题，按合集模式全部选择`);
  } else {
    reasons.push("发现一个通过校验的长标题");
  }
  if (hasRejectedEvidence) reasons.push("存在读取失败或不可用标题，已从自动选择中排除");
  if (selected.some((candidate) => !candidate.physicalVtsNumbers?.length)) reasons.push("部分标题没有可靠的物理 VTS 映射，容量覆盖仅作已知部分统计");
  const capacity = physicalCapacity(input, selected);
  reasons.push(...capacity.warnings);
  const confidence = selected.length === 0
    ? "low"
    : hasRejectedEvidence || !capacity.mappingComplete
      ? "medium"
      : "high";
  return {
    selectedTitleIds: selected.map((candidate) => candidate.titleId),
    candidates: verdicts,
    confidence,
    requiresUserSelection: requiresManualPhysicalSelection || selected.length === 0 || confidence === "low",
    reasons,
    capacity,
  };
}
