import type { configTable } from "@workspace/db";

export type AiProviderConfig = {
  provider?: string | null;
  // Database config rows use aiProvider; request payloads use provider.
  aiProvider?: string | null;
  apiKey?: string | null;
  model?: string | null;
  baseUrl?: string | null;
  // Database config rows use the persisted aiBaseUrl/aiModel names. Keep the
  // resolver compatible with both request-shaped and database-shaped config.
  aiBaseUrl?: string | null;
  aiModel?: string | null;
  libreTranslateUrl?: string | null;
};

export type AiEndpoint = { baseUrl: string; model: string; label: string; provider: string };

export const AI_PROVIDERS: Record<string, { baseUrl: string; model: string; label: string }> = {
  openai:      { baseUrl: "https://api.openai.com/v1",                                         model: "gpt-4o-mini",             label: "OpenAI" },
  deepseek:    { baseUrl: "https://api.deepseek.com/v1",                                       model: "deepseek-chat",           label: "DeepSeek" },
  siliconflow: { baseUrl: "https://api.siliconflow.cn/v1",                                     model: "deepseek-ai/DeepSeek-V3", label: "SiliconFlow" },
  zhipu:       { baseUrl: "https://open.bigmodel.cn/api/paas/v4",                              model: "glm-4-flash",              label: "Zhipu GLM" },
  moonshot:    { baseUrl: "https://api.moonshot.cn/v1",                                        model: "moonshot-v1-8k",           label: "Moonshot" },
  qwen:        { baseUrl: "https://dashscope.aliyuncs.com/compatible-mode/v1",                 model: "qwen-plus",                 label: "Qwen" },
  groq:        { baseUrl: "https://api.groq.com/openai/v1",                                    model: "llama-3.3-70b-versatile",   label: "Groq" },
  gemini:      { baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai",           model: "gemini-2.0-flash",          label: "Gemini" },
};

const keyFieldByProvider: Record<string, keyof typeof configTable.$inferSelect> = {
  deepseek: "deepseekApiKey",
  siliconflow: "siliconflowApiKey",
  zhipu: "zhipuApiKey",
  moonshot: "moonshotApiKey",
  qwen: "qwenApiKey",
  groq: "groqApiKey",
  gemini: "geminiApiKey",
  openai: "openaiApiKey",
  custom: "openaiApiKey",
};

export function resolveAiEndpoint(config: AiProviderConfig): AiEndpoint {
  const provider = config.provider || config.aiProvider || "deepseek";
  const preset = AI_PROVIDERS[provider] ?? AI_PROVIDERS.deepseek;
  const configuredBaseUrl = config.baseUrl || config.aiBaseUrl;
  const configuredModel = config.model || config.aiModel;
  return {
    provider,
    baseUrl: (provider === "custom" ? configuredBaseUrl : null) || preset.baseUrl,
    model: configuredModel || preset.model,
    label: provider === "custom" ? "Custom" : preset.label,
  };
}

export function resolveApiKey(config: AiProviderConfig & Partial<Record<keyof typeof configTable.$inferSelect, string | null>>): string | null | undefined {
  const provider = config.provider || config.aiProvider || "deepseek";
  const field = keyFieldByProvider[provider] ?? "openaiApiKey";
  return config.apiKey ?? config[field];
}

export type AiConnectionResult = {
  connected: boolean;
  provider: string;
  model: string;
  durationMs: number;
  message: string;
  statusCode: number | null;
};

/** Send a minimal request so the user can verify the active provider without running a media job. */
export async function testAiConnection(
  config: AiProviderConfig,
  fetchImpl: typeof fetch = fetch,
): Promise<AiConnectionResult> {
  const endpoint = resolveAiEndpoint(config);
  const startedAt = Date.now();
  const key = resolveApiKey(config);
  if (endpoint.provider === "libretranslate") {
    const baseUrl = config.libreTranslateUrl || "http://libretranslate:5000";
    try {
      const response = await fetchImpl(`${baseUrl.replace(/\/$/, "")}/languages`, { method: "GET" });
      return { connected: response.ok, provider: "LibreTranslate", model: "本地服务", durationMs: Date.now() - startedAt, message: response.ok ? "本地翻译服务可访问" : `服务返回 HTTP ${response.status}`, statusCode: response.status };
    } catch (error) {
      return { connected: false, provider: "LibreTranslate", model: "本地服务", durationMs: Date.now() - startedAt, message: error instanceof Error ? error.message : String(error), statusCode: null };
    }
  }
  if (!key) {
    return { connected: false, provider: endpoint.label, model: endpoint.model, durationMs: Date.now() - startedAt, message: "未提供当前 AI 提供商的 API Key", statusCode: null };
  }
  try {
    const response = await fetchImpl(`${endpoint.baseUrl.replace(/\/$/, "")}/chat/completions`, {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: endpoint.model, temperature: 0, max_tokens: 1, messages: [{ role: "user", content: "ping" }] }),
    });
    if (!response.ok) {
      const body = await response.text().catch(() => "");
      return { connected: false, provider: endpoint.label, model: endpoint.model, durationMs: Date.now() - startedAt, message: `服务返回 HTTP ${response.status}${body ? `：${body.slice(0, 240)}` : ""}`, statusCode: response.status };
    }
    return { connected: true, provider: endpoint.label, model: endpoint.model, durationMs: Date.now() - startedAt, message: "连接成功，模型已响应", statusCode: response.status };
  } catch (error) {
    return { connected: false, provider: endpoint.label, model: endpoint.model, durationMs: Date.now() - startedAt, message: error instanceof Error ? error.message : String(error), statusCode: null };
  }
}
