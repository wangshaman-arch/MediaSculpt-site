import { describe, expect, it, vi } from "vitest";
import { resolveAiEndpoint, testAiConnection } from "./ai-provider";

describe("AI provider connection test", () => {
  it("sends a minimal authenticated request without exposing the API key in diagnostics", async () => {
    const fetchMock = vi.fn(async () => new Response(JSON.stringify({ choices: [{ message: { content: "pong" } }] }), { status: 200, headers: { "content-type": "application/json" } }));
    const result = await testAiConnection({ provider: "gemini", apiKey: "secret-gemini-key", model: "gemini-2.0-flash" }, fetchMock as unknown as typeof fetch);

    expect(result.connected).toBe(true);
    expect(result.provider).toBe("Gemini");
    expect(fetchMock).toHaveBeenCalledWith(
      "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
      expect.objectContaining({
        method: "POST",
        headers: expect.objectContaining({ Authorization: "Bearer secret-gemini-key" }),
      }),
    );
    expect(JSON.stringify(result)).not.toContain("secret-gemini-key");
  });

  it("resolves database-shaped custom endpoint fields", () => {
    expect(resolveAiEndpoint({
      aiProvider: "custom",
      aiBaseUrl: "http://127.0.0.1:19090/v1",
      aiModel: "local-mock",
    })).toMatchObject({
      baseUrl: "http://127.0.0.1:19090/v1",
      model: "local-mock",
    });
  });
});
