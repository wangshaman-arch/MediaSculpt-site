import { execFile } from "node:child_process";
import { promisify } from "node:util";
import os from "node:os";
import path from "node:path";
import fs from "node:fs/promises";
import { createWriteStream } from "node:fs";
import { pipeline } from "node:stream/promises";
import { managedToolDirectory, type RuntimePlatform } from "./tool-runtime";
import { downloadSegmentedParallel } from "./tool-downloader";

const exec = promisify(execFile);
const LONG_TIMEOUT_MS = 30 * 60 * 1000;
const MAX_BUFFER = 20 * 1024 * 1024;

type PythonCommand = { command: string; args: string[] };
type RuntimeLog = (message: string) => void | Promise<void>;

/** 全局 Python 安装串行化：并发工具安装时只下载/安装一次 Python，其余等待同一结果。 */
let pythonSetupPromise: Promise<PythonCommand> | null = null;

export function pipIndexCandidates(): string[] {
  const configured = (process.env.MEDIASCULPT_PIP_INDEX_URL ?? process.env.VX_AGENT_PIP_INDEX_URL)?.trim();
  return [
    configured,
    "https://pypi.tuna.tsinghua.edu.cn/simple",
    "https://mirrors.aliyun.com/pypi/simple",
    "https://mirrors.cloud.tencent.com/pypi/simple",
    "https://pypi.org/simple",
  ].filter((value, index, values): value is string => Boolean(value) && values.indexOf(value) === index);
}

export function whisperEnvironment(home = os.homedir()): string {
  // 打包版（Tauri sidecar 设置了 MEDIASCULPT_TOOLS_DIR）使用托管工具目录，自包含；
  // 开发版（只有 VX_AGENT_TOOLS_DIR）保留旧 ~/.vx-agent 路径以复用已有环境。
  if (process.env.MEDIASCULPT_TOOLS_DIR) {
    return path.join(managedToolDirectory(process.platform as RuntimePlatform, home), "whisper-env");
  }
  return path.join(home, ".vx-agent", "whisper-env");
}

export function pythonInstallDirectory(home = os.homedir(), platform: RuntimePlatform = process.platform as RuntimePlatform): string {
  return path.join(managedToolDirectory(platform, home), "python");
}

function venvPython(env: string, platform: RuntimePlatform = process.platform as RuntimePlatform): string {
  return platform === "win32" ? path.win32.join(env, "Scripts", "python.exe") : path.join(env, "bin", "python");
}

/**
 * CLI wrapper that mimics the openai-whisper command line but runs on
 * faster-whisper (CTranslate2 + int8). The job executor invokes the managed
 * venv python with this script and the same arguments it used for `whisper`.
 */
const FASTER_WHISPER_CLI = `import argparse, os, sys
import numpy as np
import av
from faster_whisper import WhisperModel
from faster_whisper.vad import VadOptions, get_speech_timestamps

def fmt(t):
    h = int(t // 3600); m = int(t % 3600 // 60); s = int(t % 60); ms = int(round((t - int(t)) * 1000))
    if ms >= 1000: ms = 999
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

def load_audio(path, sample_rate=16000):
    container = av.open(path)
    stream = next((s for s in container.streams if s.type == "audio"), None)
    if stream is None:
        return np.zeros(0, dtype=np.float32)
    resampler = av.AudioResampler(format="s16", layout="mono", rate=sample_rate)
    chunks = []
    for frame in container.decode(stream):
        for r in resampler.resample(frame):
            chunks.append(r.to_ndarray().reshape(-1))
    for r in resampler.resample(None):
        chunks.append(r.to_ndarray().reshape(-1))
    if not chunks:
        return np.zeros(0, dtype=np.float32)
    return np.concatenate(chunks).astype(np.float32) / 32768.0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("audio")
    ap.add_argument("--model", default="small")
    ap.add_argument("--output_format", default="all")
    ap.add_argument("--output_dir", default=".")
    ap.add_argument("--language", default=None)
    ap.add_argument("--task", default="transcribe")
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--compute_type", default="int8")
    ap.add_argument("--beam_size", type=int, default=5)
    args = ap.parse_args()
    model = WhisperModel(args.model, device=args.device, compute_type=args.compute_type)
    base = os.path.splitext(os.path.basename(args.audio))[0]
    os.makedirs(args.output_dir, exist_ok=True)
    explicit_lang = args.language if args.language and args.language != "auto" else None
    if explicit_lang:
        # Single-language fast path.
        segments, info = model.transcribe(args.audio, language=explicit_lang, task=args.task, beam_size=args.beam_size, vad_filter=False)
        lang = explicit_lang
        print(f"Detected language: {lang}", file=sys.stderr)
        total = max(1, info.duration or 1)
        entries = []
        for seg in segments:
            entries.append((seg.start, seg.end, seg.text.strip()))
            pct = int(seg.end / total * 100)
            print(f"{pct}%|", file=sys.stderr, flush=True)
    else:
        # Auto: VAD split + per-segment language detection, so mixed-language
        # audio is transcribed in each speaker's language.
        audio = load_audio(args.audio)
        total = max(1, len(audio) / 16000.0)
        vad = VadOptions(min_silence_duration_ms=500, speech_pad_ms=300)
        speech = get_speech_timestamps(audio, vad)
        if not speech:
            speech = [{"start": 0, "end": len(audio)}]
        entries = []
        langs = set()
        seg_count = 0
        for seg in speech:
            s, e = seg["start"], seg["end"]
            if e - s < 3200:
                continue
            seg_audio = audio[s:e]
            lang, _prob, _langs = model.detect_language(seg_audio)
            langs.add(lang)
            seg_count += 1
            sub_segments, _info = model.transcribe(seg_audio, language=lang, task=args.task, beam_size=args.beam_size, vad_filter=False)
            for sub in sub_segments:
                start = s / 16000.0 + sub.start
                end = s / 16000.0 + sub.end
                text = sub.text.strip()
                if text:
                    entries.append((start, end, text))
                pct = int(end / total * 100)
                print(f"{pct}%|", file=sys.stderr, flush=True)
        lang = "mixed" if len(langs) > 1 else (next(iter(langs)) if langs else "en")
        print(f"Detected language: {lang}", file=sys.stderr)
        print(f"Segments: {seg_count} (languages: {','.join(sorted(langs))})", file=sys.stderr)
    entries.sort(key=lambda item: item[0])
    if args.output_format in ("srt", "all"):
        out = os.path.join(args.output_dir, f"{base}.{lang}.srt")
        with open(out, "w", encoding="utf-8") as f:
            for i, (start, end, text) in enumerate(entries, 1):
                f.write(f"{i}\\n{fmt(start)} --> {fmt(end)}\\n{text}\\n\\n")
        print(f"Saved SRT to {out}")
    else:
        out = os.path.join(args.output_dir, f"{base}.txt")
        with open(out, "w", encoding="utf-8") as f:
            f.write("\\n".join(text for _s, _e, text in entries))
        print(f"Saved text to {out}")

if __name__ == "__main__":
    main()
`;

export function whisperCliScriptPath(env = whisperEnvironment()): string {
  return process.platform === "win32"
    ? path.win32.join(env, "Scripts", "vx_faster_whisper_cli.py")
    : path.join(env, "bin", "vx_faster_whisper_cli.py");
}

export function fasterWhisperModelName(model: string): string {
  return model === "large" ? "large-v3" : model;
}

export function fasterWhisperModelDirectory(model: string, home = os.homedir()): string {
  return path.join(managedToolDirectory(process.platform as RuntimePlatform, home), "faster-whisper-models", fasterWhisperModelName(model));
}

/**
 * Download a faster-whisper model through Node's fetch (plain HTTP, allowed by
 * most firewalls/antivirus that block python outbound). huggingface_hub's own
 * downloader is unreliable in China and can be blocked by security software,
 * so the app downloads the four model files itself into the managed tools dir.
 */
export async function ensureFasterWhisperModel(model: string, onLog?: RuntimeLog): Promise<string> {
  const modelName = fasterWhisperModelName(model);
  if (!/^[a-z0-9.-]+$/i.test(modelName)) throw new Error("Whisper 模型名称无效");
  const modelDir = fasterWhisperModelDirectory(modelName);
  const files = ["config.json", "model.bin", "tokenizer.json", "vocabulary.txt"];
  // 安装包内自带的模型（<cwd>/tools/faster-whisper-models/<model>）优先复制到托管目录，
  // 首次使用无需联网下载（cwd 在打包应用里是 sidecar 的 api-server/dist）。
  const bundledModelDir = path.join(process.cwd(), "tools", "faster-whisper-models", modelName);
  try {
    const bundledFiles = await fs.readdir(bundledModelDir);
    if (bundledFiles.length >= 3) {
      await fs.mkdir(modelDir, { recursive: true });
      let copied = 0;
      for (const file of bundledFiles) {
        const source = path.join(bundledModelDir, file);
        const target = path.join(modelDir, file);
        const [sourceStat, targetStat] = await Promise.all([
          fs.stat(source),
          fs.stat(target).catch(() => null),
        ]);
        if (!targetStat || targetStat.size !== sourceStat.size) {
          await fs.copyFile(source, target);
          copied += 1;
        }
      }
      if (copied > 0) await onLog?.(`whisper: copied bundled model ${modelName} to ${modelDir}`);
    }
  } catch {
    // 没有打包模型时忽略，走下面的联网下载。
  }
  const mirrors = [
    `https://hf-mirror.com/Systran/faster-whisper-${modelName}/resolve/main/`,
    `https://huggingface.co/Systran/faster-whisper-${modelName}/resolve/main/`,
  ];
  await fs.mkdir(modelDir, { recursive: true });
  // 大文件优先走多线程分段下载（Range 分片并行，绕开单连接截断/限速）；
  // 源不支持 Range 或文件较小时返回 false，由调用方回退单连接下载。
  const trySegmentedDownload = async (url: string, target: string): Promise<boolean> => {
    const temp = `${target}.download`;
    try {
      const probeResponse = await fetch(url, {
        headers: { Range: "bytes=0-0" },
        signal: AbortSignal.timeout(30_000),
        redirect: "follow",
      });
      const contentRangeTotal = /\/\s*(\d+)\s*$/.exec(probeResponse.headers.get("content-range") ?? "")?.[1];
      if (probeResponse.status === 206 && contentRangeTotal && Number(contentRangeTotal) >= 8 * 1024 * 1024) {
        await probeResponse.body?.cancel().catch(() => {});
        await downloadSegmentedParallel({
          id: "whisper",
          url,
          totalBytes: Number(contentRangeTotal),
          temp,
          onProgress: () => {},
          log: async (message) => { await onLog?.(message); },
        });
        await fs.rm(target, { force: true }).catch(() => {});
        await fs.rename(temp, target);
        await onLog?.(`whisper: model file ${path.basename(target)} segmented-downloaded (${Number(contentRangeTotal)} bytes)`);
        return true;
      }
      await probeResponse.body?.cancel().catch(() => {});
    } catch (error) {
      await onLog?.(`whisper: segmented download failed for ${path.basename(target)}：${error instanceof Error ? error.message : String(error)}`);
    }
    return false;
  };
  for (let fileIndex = 0; fileIndex < files.length; fileIndex += 1) {
    const file = files[fileIndex]!;
    const target = path.join(modelDir, file);
    try {
      const stat = await fs.stat(target);
      if (stat.size > 100) continue; // already downloaded
    } catch {
      // download below
    }
    let lastError: unknown = null;
    let downloaded = false;
    for (const mirror of mirrors) {
      const url = `${mirror}${file}`;
      try {
        await onLog?.(`whisper: downloading ${url}`);
        if (await trySegmentedDownload(url, target)) {
          downloaded = true;
          await onLog?.(`whisper model download progress: ${Math.round(((fileIndex + 1) / files.length) * 100)}%`);
          break;
        }
        const response = await fetch(url, { signal: AbortSignal.timeout(600_000), redirect: "follow" });
        if (!response.ok || !response.body) throw new Error(`HTTP ${response.status}`);
        const temp = `${target}.download`;
        const handle = await fs.open(temp, "w");
        try {
          for await (const chunk of response.body as AsyncIterable<Uint8Array>) await handle.write(chunk);
        } finally {
          await handle.close();
        }
        await fs.rename(temp, target);
        downloaded = true;
        await onLog?.(`whisper: model file ${file} saved (${(await fs.stat(target)).size} bytes)`);
        // 四个文件按顺序推进模型下载进度（前端据此显示真实百分比）。
        await onLog?.(`whisper model download progress: ${Math.round(((fileIndex + 1) / files.length) * 100)}%`);
        break;
      } catch (error) {
        lastError = error;
        await onLog?.(`whisper: download failed from ${url}: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    if (!downloaded) {
      throw new Error(`下载 Whisper 模型 ${modelName}/${file} 失败：${lastError instanceof Error ? lastError.message : String(lastError)}`);
    }
  }
  return modelDir;
}

export async function ensureWhisperCliScript(env = whisperEnvironment(), onLog?: RuntimeLog): Promise<string> {
  const script = whisperCliScriptPath(env);
  try {
    const existing = await fs.readFile(script, "utf8");
    if (existing === FASTER_WHISPER_CLI) return script;
  } catch {
    // write below
  }
  await fs.mkdir(path.dirname(script), { recursive: true });
  await fs.writeFile(script, FASTER_WHISPER_CLI, "utf8");
  await onLog?.(`whisper: wrote CLI wrapper ${script}`);
  return script;
}

export function pipInstallCommand(env: string, platform: RuntimePlatform = process.platform as RuntimePlatform): { command: string; prefixArgs: string[] } {
  return { command: venvPython(env, platform), prefixArgs: ["-m", "pip"] };
}

async function exists(filePath: string): Promise<boolean> {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function run(command: string, args: string[], onLog?: RuntimeLog): Promise<void> {
  await onLog?.(`run: ${command} ${args.join(" ")}`);
  try {
    const result = await exec(command, args, { timeout: LONG_TIMEOUT_MS, maxBuffer: MAX_BUFFER });
    const output = `${result.stdout}\n${result.stderr}`.trim();
    if (output) await onLog?.(`output: ${output.slice(-4000)}`);
  } catch (error) {
    await onLog?.(`failed: ${command} ${args.join(" ")} :: ${error instanceof Error ? error.message : String(error)}`);
    throw error;
  }
}

async function findPython(): Promise<PythonCommand | null> {
  const configured = process.env.MEDIASCULPT_PYTHON_PATH ?? process.env.VX_AGENT_PYTHON_PATH;
  const candidates: PythonCommand[] = [];
  if (configured) candidates.push({ command: configured, args: [] });
  // 托管目录与旧版 VX-Agent 目录下可能已经装过 Python：python 官方安装器
  // 一旦检测到“已注册”（WixBundleInstalled=1）就会静默退出而不重装到新 TargetDir，
  // 因此必须直接复用这些已存在的 python.exe，否则会误报“Python 安装完成但未找到”。
  candidates.push(
    { command: path.join(managedToolDirectory(), "python", "python.exe"), args: [] },
    { command: path.join(os.homedir(), "AppData", "Local", "VX-Agent", "tools", "python", "python.exe"), args: [] },
  );
  try {
    const programsPython = path.join(os.homedir(), "AppData", "Local", "Programs", "Python");
    const pythonDirs = await fs.readdir(programsPython);
    for (const dir of pythonDirs.sort().reverse()) {
      candidates.push({ command: path.join(programsPython, dir, "python.exe"), args: [] });
    }
  } catch {
    // 没有 %LOCALAPPDATA%\Programs\Python，忽略。
  }
  if (process.platform === "win32") candidates.push({ command: "py", args: ["-3"] });
  candidates.push({ command: "python", args: [] }, { command: "python3", args: [] });

  for (const candidate of candidates) {
    try {
      await exec(candidate.command, [...candidate.args, "--version"], { timeout: 10000, maxBuffer: MAX_BUFFER });
      return candidate;
    } catch {
      // Try the next common launcher.
    }
  }
  return null;
}

async function downloadFile(url: string, destination: string, onLog?: RuntimeLog): Promise<void> {
  await onLog?.(`download: ${url}`);
  const response = await fetch(url);
  if (!response.ok || !response.body) throw new Error(`Python 下载失败：HTTP ${response.status}`);
  await fs.mkdir(path.dirname(destination), { recursive: true });
  const totalBytes = Number(response.headers.get("content-length")) || null;
  let receivedBytes = 0;
  let lastLoggedPercent = -1;
  const reader = response.body.getReader();
  // 写临时文件再改名，并对被占用（EBUSY，例如杀软扫描）做重试，避免“下载失败/文件被锁”。
  const tempDestination = `${destination}.download`;
  await fs.rm(tempDestination, { force: true }).catch(() => {});
  let openAttempts = 0;
  let file: Awaited<ReturnType<typeof fs.open>> | null = null;
  while (file === null) {
    try {
      file = await fs.open(tempDestination, "w");
    } catch (error) {
      openAttempts += 1;
      if (openAttempts >= 3) throw error;
      await new Promise((resolve) => setTimeout(resolve, 1000 * openAttempts));
    }
  }
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      if (value && value.byteLength > 0) {
        await file.write(value);
        receivedBytes += value.byteLength;
        // 下载过程节流记录进度（每 5%），避免长下载看起来“无进展/卡死”。
        if (totalBytes) {
          const percent = Math.floor((receivedBytes / totalBytes) * 100);
          if (percent >= lastLoggedPercent + 5) {
            lastLoggedPercent = percent;
            await onLog?.(`download progress: ${percent}% (${receivedBytes}/${totalBytes} bytes)`);
          }
        }
      }
    }
  } finally {
    await file.close();
  }
  await fs.rm(destination, { force: true }).catch(() => {});
  await fs.rename(tempDestination, destination).catch(() => {
    // 目标被占用时保留临时文件，后续 ensurePython 的探测仍能找到可用 python。
  });
  await onLog?.(`downloaded: ${destination} (${receivedBytes} bytes)`);
}

async function ensurePython(onLog?: RuntimeLog): Promise<PythonCommand> {
  const found = await findPython();
  if (found) {
    await onLog?.(`python found: ${found.command} ${found.args.join(" ")}`.trim());
    return found;
  }

  if (process.platform !== "win32") {
    throw new Error("未找到 Python。请先安装 Python 3.11 或更新版本。");
  }

  const installDir = pythonInstallDirectory();
  const pythonExe = path.join(installDir, "python.exe");
  if (await exists(pythonExe)) return { command: pythonExe, args: [] };

  // 并发安装（Whisper/RapidOCR/LibreTranslate 同时装）时，Python 的下载与安装
  // 只能进行一次：其余任务等待同一份结果，避免同一安装器被并发执行导致 EBUSY/ENOENT。
  if (pythonSetupPromise) {
    await onLog?.("python setup already in progress; waiting for it to finish");
    return pythonSetupPromise;
  }
  pythonSetupPromise = (async () => {
    const installer = path.join(installDir, "python-3.11.9-amd64.exe");
    const pythonMirrors = [
      "https://registry.npmmirror.com/-/binary/python/3.11.9/python-3.11.9-amd64.exe",
      "https://mirrors.huaweicloud.com/python/3.11.9/python-3.11.9-amd64.exe",
      "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe",
    ];
    let lastDownloadError: unknown = null;
    for (const mirror of pythonMirrors) {
      try {
        await downloadFile(mirror, installer, onLog);
        lastDownloadError = null;
        break;
      } catch (error) {
        lastDownloadError = error;
        await onLog?.(`python 安装包下载失败（${mirror}）：${error instanceof Error ? error.message : String(error)}`);
      }
    }
    if (lastDownloadError) throw lastDownloadError;
    await run(installer, [
      "/quiet",
      "InstallAllUsers=0",
      `TargetDir=${installDir}`,
      "Include_pip=1",
      "Include_launcher=0",
      "PrependPath=0",
    ], onLog);
    if (!await exists(pythonExe)) {
      // 安装器可能把 Python 装到默认 per-user 目录（例如注册表里已有旧版本时），
      // 探测常见位置，找到即可复用。
      const probeCandidates = [
        pythonExe,
        path.join(os.homedir(), "AppData", "Local", "Programs", "Python", "Python311", "python.exe"),
        path.join(os.homedir(), "AppData", "Local", "Programs", "Python", "Python312", "python.exe"),
        path.join(os.homedir(), "AppData", "Local", "Programs", "Python", "Python313", "python.exe"),
        path.join(os.homedir(), "AppData", "Local", "VX-Agent", "tools", "python", "python.exe"),
        "C:\\Program Files\\Python311\\python.exe",
        "C:\\Program Files\\Python312\\python.exe",
        "C:\\Program Files (x86)\\Python311-32\\python.exe",
      ];
      for (const candidate of probeCandidates) {
        if (await exists(candidate)) {
          await onLog?.(`python found after install at alternate path: ${candidate}`);
          return { command: candidate, args: [] };
        }
      }
      throw new Error(`Python 安装完成但未找到 ${pythonExe}（已探测常见安装路径）`);
    }
    return { command: pythonExe, args: [] };
  })();
  try {
    return await pythonSetupPromise;
  } finally {
    pythonSetupPromise = null;
  }
}

async function ensureVenv(env: string, onLog?: RuntimeLog): Promise<void> {
  if (await exists(venvPython(env))) return;
  await fs.mkdir(path.dirname(env), { recursive: true });
  const python = await ensurePython(onLog);
  await run(python.command, [...python.args, "-m", "venv", env], onLog);
}

async function installPipPackages(env: string, packages: string[], onLog?: RuntimeLog): Promise<void> {
  const pip = pipInstallCommand(env);
  let alreadyInstalled = true;
  for (const packageName of packages) {
    try {
      await exec(pip.command, [...pip.prefixArgs, "show", packageName], { timeout: 30000, maxBuffer: MAX_BUFFER });
    } catch {
      alreadyInstalled = false;
      break;
    }
  }
  if (alreadyInstalled) {
    await onLog?.(`pip packages already installed: ${packages.join(", ")}; reusing local environment`);
    return;
  }
  let lastError: unknown;
  for (const indexUrl of pipIndexCandidates()) {
    try {
      const common = ["--index-url", indexUrl, "--timeout", "120", "--retries", "3"];
      await onLog?.(`pip index: ${indexUrl}`);
      await run(pip.command, [...pip.prefixArgs, "install", "--upgrade", ...common, "pip", "setuptools", "wheel"], onLog);
      await run(pip.command, [...pip.prefixArgs, "install", "--upgrade", ...common, ...packages], onLog);
      return;
    } catch (error) {
      lastError = error;
      await onLog?.(`pip index failed: ${indexUrl}; trying next source`);
    }
  }
  throw lastError instanceof Error ? lastError : new Error("所有 Python 包源均安装失败");
}

export async function setupWhisperEnvironment(home = os.homedir(), onLog?: RuntimeLog): Promise<string> {
  const env = whisperEnvironment(home);
  await onLog?.(`whisper: setup environment ${env}`);
  await ensureVenv(env, onLog);
  // faster-whisper (CTranslate2, int8) is the CPU-optimized replacement for
  // openai-whisper; models auto-download from HuggingFace on first use.
  process.env.HF_ENDPOINT ||= "https://hf-mirror.com";
  await installPipPackages(env, ["faster-whisper"], onLog);
  await ensureWhisperCliScript(env, onLog);
  return env;
}

export async function installWhisperModel(model: string, home = os.homedir(), onLog?: RuntimeLog): Promise<string> {
  await onLog?.(`whisper: install model ${model}`);
  return ensureFasterWhisperModel(model, onLog);
}

export async function setupLibreTranslateEnvironment(home = os.homedir(), onLog?: RuntimeLog): Promise<string> {
  const env = path.join(managedToolDirectory(process.platform as RuntimePlatform, home), "libretranslate", "venv");
  await onLog?.(`libretranslate: setup environment ${env}`);
  await ensureVenv(env, onLog);
  await installPipPackages(env, ["libretranslate"], onLog);
  return env;
}

export async function setupRapidOcrEnvironment(home = os.homedir(), onLog?: RuntimeLog): Promise<string> {
  const env = path.join(managedToolDirectory(process.platform as RuntimePlatform, home), "rapidocr", "venv");
  await onLog?.(`rapidocr: setup environment ${env}`);
  await ensureVenv(env, onLog);
  await installPipPackages(env, ["rapidocr_onnxruntime"], onLog);
  return env;
}
