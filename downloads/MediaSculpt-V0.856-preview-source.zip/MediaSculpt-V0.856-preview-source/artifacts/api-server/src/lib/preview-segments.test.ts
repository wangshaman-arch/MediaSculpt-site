import { describe, expect, it } from "vitest";
import { SEGMENT_SECONDS, shouldPreemptActiveSegment, shouldUseFastPreviewPath } from "./preview-segments";

describe("preview segment scheduling", () => {
  it("uses five-second segments to keep random seeks responsive", () => {
    expect(SEGMENT_SECONDS).toBe(5);
  });

  it("preempts an active segment when a different target is requested", () => {
    expect(shouldPreemptActiveSegment(null, 3)).toBe(false);
    expect(shouldPreemptActiveSegment(3, 3)).toBe(false);
    expect(shouldPreemptActiveSegment(3, 8)).toBe(true);
  });

  it("uses the fast preview path only for browser-compatible video without burned subtitles", () => {
    expect(shouldUseFastPreviewPath("h264", null)).toBe(true);
    expect(shouldUseFastPreviewPath("H.264", null)).toBe(true);
    expect(shouldUseFastPreviewPath("h264", 2)).toBe(false);
    expect(shouldUseFastPreviewPath("hevc", null)).toBe(false);
    expect(shouldUseFastPreviewPath("mpeg2video", null)).toBe(false);
  });
});
