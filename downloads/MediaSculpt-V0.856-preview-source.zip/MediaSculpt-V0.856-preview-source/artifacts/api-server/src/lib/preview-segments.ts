/**
 * 分段预览转码：把视频源切成固定秒数的独立 MP4 片段，按需/优先后台转码。
 * 已生成的片段是完整文件，浏览器可 Range 随机访问——拖动/快进到已生成区域零等待；
 * 未生成的片段（如快进到很靠后的位置）由前端请求后优先转码该段，转完即播。
 * 取代旧的“实时转码流 + 每次 seek 杀掉重启”模型，消除拖动/快进卡顿。
 */
import fs from "node:fs/promises";
import fsSync from "node:fs";
import os from "node:os";
import path from "node:path";
import { type ChildProcess, type ChildProcessWithoutNullStreams } from "node:child_process";
import { execFile } from "node:child_process";
import { createHash } from "node:crypto";
import { resolveToolPath } from "./tool-runtime";
import { processRunner } from "../infrastructure/process-runner";
import { terminateProcessTree } from "../infrastructure/process-termination";
import type { Response } from "express";

// Five-second segments bound the wait for an uncached random seek while still
// leaving enough time for the next segment to be prepared during playback.
export const SEGMENT_SECONDS = 5;
const SEGMENTS_ROOT = path.join(os.tmpdir(), "vx-preview-segments");
let lastSweepAt = 0;

// 启动时清理残留/损坏片段：空文件或缺少 .done 的片段会让浏览器解码失败（错误码 3）。
void (async () => {
  try {
    const keys = await fs.readdir(SEGMENTS_ROOT).catch(() => []);
    for (const key of keys) {
      const dir = path.join(SEGMENTS_ROOT, key);
      const names = await fs.readdir(dir).catch(() => []);
      for (const name of names) {
        if (!/^seg-\d+\.mp4$/.test(name)) continue;
        const full = path.join(dir, name);
        const done = `${full}.done`;
        try {
          const stat = await fs.stat(full);
          const hasDone = await fs.access(done).then(() => true).catch(() => false);
          if (stat.size < 64 * 1024 || !hasDone) {
            await fs.rm(full, { force: true });
            await fs.rm(done, { force: true });
          }
        } catch { /* 单个文件清理失败不影响其他 */ }
      }
    }
  } catch { /* 清理失败不影响服务启动 */ }
})();

type SegmentSession = {
  proc: ChildProcessWithoutNullStreams | null;
  /** 正在探测/生成的片段索引；进程尚未 spawn 时也必须视为占用。 */
  activeIndex: number | null;
  priorityIndex: number | null;
  lastActivity: number;
  /** 后台预生成队列：按 index 升序转码，用户请求的目标段永远优先打断。 */
  queue: Set<number>;
  /** 已确认无法生成的段（如 seek 超出视频时长），直接失败不再重转。 */
  failed: Set<number>;
  /** 被其它预览抢占的时间：抢占后短暂冷却，避免多客户端互相 kill 死循环。 */
  killedAt: number;
  filePath: string | null;
  subIndex: number | null;
};

const sessions = new Map<string, SegmentSession>();
const managedKillers = new WeakMap<ChildProcess, (signal?: NodeJS.Signals) => boolean>();

function killPreviewProcess(child: ChildProcess, signal: NodeJS.Signals = "SIGKILL"): void {
  const managedKill = managedKillers.get(child);
  if (managedKill) {
    managedKill(signal);
    return;
  }
  terminateProcessTree(child, signal);
}
/** 全局互斥：同一时间只允许一个片段转码进程，避免多个预览互相抢 CPU。 */
let globalActiveKey: string | null = null;
/** 全局最近活跃的预览 key：后台预生成队列只服务它，切走后的旧视频队列立即暂停。 */
let globalLatestKey: string | null = null;
let globalLatestAt = 0;
/** 源视频信息探测缓存：决定片段用流拷贝（h264）还是重编码。 */
const videoInfoCache = new Map<string, { at: number; codec: string | null; fps: number | null }>();

async function probeVideoInfo(filePath: string): Promise<{ codec: string | null; fps: number | null }> {
  const cached = videoInfoCache.get(filePath);
  if (cached && Date.now() - cached.at < 10 * 60_000) return { codec: cached.codec, fps: cached.fps };
  const ffprobeExecutable = (await resolveToolPath("ffprobe").catch(() => null)) ?? "ffprobe";
  const info = await new Promise<{ codec: string | null; fps: number | null }>((resolve) => {
    const proc = processRunner.spawn({
      executable: ffprobeExecutable,
      args: [
        "-v", "quiet",
        "-print_format", "json",
        "-show_entries", "stream=codec_type,codec_name,avg_frame_rate",
        ffmpegPath(filePath),
      ],
      stage: "preview-probe",
      timeoutMs: 30_000,
    }).child;
    let stdout = "";
    proc.stdout?.on("data", (chunk: Buffer) => { stdout += String(chunk); });
    proc.on("error", () => resolve({ codec: null, fps: null }));
    proc.on("close", () => {
      try {
        const parsed = JSON.parse(stdout) as { streams?: Array<{ codec_type?: string; codec_name?: string; avg_frame_rate?: string }> };
        const video = (parsed.streams ?? []).find((stream) => stream.codec_type === "video");
        let fps: number | null = null;
        const rate = video?.avg_frame_rate;
        if (rate) {
          const [num, den] = rate.split("/").map((part) => Number(part));
          if (Number.isFinite(num) && Number.isFinite(den) && num > 0 && den > 0) fps = num / den;
        }
        resolve({ codec: video?.codec_name ?? null, fps });
      } catch {
        resolve({ codec: null, fps: null });
      }
    });
  });
  videoInfoCache.set(filePath, { at: Date.now(), codec: info.codec, fps: info.fps });
  return info;
}

/**
 * 判断是否可以走浏览器兼容的快速预览路径。
 * 字幕烧录必须重编码；H.264 无字幕预览只复制视频，音频统一转为 AAC。
 */
export function shouldUseFastPreviewPath(codec: string | null, subIndex: number | null): boolean {
  if (subIndex !== null) return false;
  const normalized = (codec ?? "").toLowerCase().replace(/[.\s-]/g, "");
  return normalized === "h264" || normalized === "avc1";
}

/** 判断新请求是否应该抢占当前正在生成的片段。 */
export function shouldPreemptActiveSegment(activeIndex: number | null, requestedIndex: number): boolean {
  return activeIndex !== null && activeIndex !== requestedIndex;
}

async function canStreamCopy(filePath: string, subIndex: number | null): Promise<boolean> {
  if (subIndex !== null) return false;
  const info = await probeVideoInfo(filePath);
  return shouldUseFastPreviewPath(info.codec, subIndex);
}

function ffmpegPath(filePath: string): string {
  // 盘符后补一个反斜杠，避免 ffmpeg 把 "C:/x" 当成协议
  return /^[A-Za-z]:\//.test(filePath) ? `${filePath.slice(0, 2)}\\${filePath.slice(2)}` : filePath;
}

export function previewSegmentKey(filePath: string, subIndex: number | null): string {
  const seed = `${filePath}\u0000${subIndex ?? ""}\u0000${SEGMENT_SECONDS}`;
  return createHash("sha1").update(seed).digest("hex").slice(0, 20);
}

export function segmentIndexFor(seconds: number): number {
  return Math.max(0, Math.floor(seconds / SEGMENT_SECONDS));
}

export function segmentDir(key: string): string {
  return path.join(SEGMENTS_ROOT, key);
}

export function segmentFile(key: string, index: number): string {
  return path.join(segmentDir(key), `seg-${String(index).padStart(5, "0")}.mp4`);
}

function segmentDoneFile(key: string, index: number): string {
  return `${segmentFile(key, index)}.done`;
}

export async function segmentReady(key: string, index: number): Promise<boolean> {
  try {
    await fs.access(segmentDoneFile(key, index));
    const stat = await fs.stat(segmentFile(key, index));
    return stat.size > 64 * 1024;
  } catch {
    return false;
  }
}

/** 列出已生成的片段索引。 */
export async function readySegmentIndices(key: string): Promise<number[]> {
  try {
    const entries = await fs.readdir(segmentDir(key));
    const indices: number[] = [];
    for (const name of entries) {
      const match = /^seg-(\d+)\.mp4$/.exec(name);
      if (!match) continue;
      try {
        const index = Number(match[1]);
        await fs.access(`${path.join(segmentDir(key), name)}.done`);
        const stat = await fs.stat(path.join(segmentDir(key), name));
        if (stat.size > 64 * 1024) indices.push(index);
      } catch { /* 忽略损坏/未完成的片段 */ }
    }
    return indices.sort((a, b) => a - b);
  } catch {
    return [];
  }
}

export async function generatedSeconds(key: string): Promise<number> {
  const indices = await readySegmentIndices(key);
  return indices.length > 0 ? (Math.max(...indices) + 1) * SEGMENT_SECONDS : 0;
}

/**
 * 确保某一片段已转码或正在转码。同一 key 同一时间只允许一条转码进程；
 * 前端跳转到新位置时把该片段设为优先，正在转的旧片段会被中止（目标片段优先）。
 */
export async function ensurePreviewSegment(
  filePath: string,
  subIndex: number | null,
  index: number,
  options: { seekFrom?: number } = {},
): Promise<"ready" | "transcoding" | "failed"> {
  maybeSweep();
  const key = previewSegmentKey(filePath, subIndex);
  await fs.mkdir(segmentDir(key), { recursive: true });
  if (await segmentReady(key, index)) return "ready";

  let session = sessions.get(key);
  if (!session) {
    session = { proc: null, activeIndex: null, priorityIndex: null, lastActivity: Date.now(), queue: new Set(), failed: new Set(), killedAt: 0, filePath, subIndex };
    sessions.set(key, session);
  }
  session.filePath = filePath;
  session.subIndex = subIndex;
  if (session.failed.has(index)) return "failed";
  // 冷却期：刚被其它预览抢占的 key 暂缓 3 秒，让当前查看的预览先转完，防止来回 kill。
  if (session.killedAt && Date.now() - session.killedAt < 3000) return "transcoding";
  session.lastActivity = Date.now();
  session.priorityIndex = index;
  touchLatest(key);
  // 用户明确请求这一段：移出后台队列（转完后由 pump 继续队列）。
  session.queue.delete(index);

  // 正在转的是别的片段且目标不同：中止当前进程，让目标片段优先。
  if (session.proc && shouldPreemptActiveSegment(session.activeIndex, index)) {
    killPreviewProcess(session.proc, "SIGKILL");
  }
  if (session.activeIndex !== null) return "transcoding";

  session.activeIndex = index;
  void startSegmentTranscode(filePath, subIndex, key, index, options.seekFrom ?? index * SEGMENT_SECONDS);
  return "transcoding";
}

/** 把某段之后的若干后台预生成段加入队列（连续播放/短距离快进秒开）。 */
export function queueBackgroundSegments(filePath: string, subIndex: number | null, fromIndex: number, count: number): void {
  const key = previewSegmentKey(filePath, subIndex);
  let session = sessions.get(key);
  if (!session) {
    session = { proc: null, activeIndex: null, priorityIndex: null, lastActivity: Date.now(), queue: new Set(), failed: new Set(), killedAt: 0, filePath, subIndex };
    sessions.set(key, session);
  }
  session.filePath = filePath;
  session.subIndex = subIndex;
  if (session.killedAt && Date.now() - session.killedAt < 3000) return;
  session.lastActivity = Date.now();
  touchLatest(key);
  for (let i = fromIndex + 1; i <= fromIndex + count; i += 1) session.queue.add(i);
  void pumpQueue(key).catch(() => {});
}

/** 空闲时按队列顺序转下一个未就绪片段。 */
async function pumpQueue(key: string): Promise<void> {
  const session = sessions.get(key);
  if (!session || session.proc || session.activeIndex !== null) return;
  // 后台预生成只服务最近活跃的预览：避免切走后旧视频的队列持续转码吃 CPU。
  if (globalLatestKey !== key) return;
  session.lastActivity = Date.now();
  const candidates = [...session.queue].sort((a, b) => a - b);
  for (const index of candidates) {
    if (await segmentReady(key, index)) {
      session.queue.delete(index);
      continue;
    }
    session.priorityIndex = index;
    if (session.filePath !== null && session.activeIndex === null) {
      session.activeIndex = index;
      void startSegmentTranscode(session.filePath, session.subIndex, key, index, index * SEGMENT_SECONDS);
      return;
    }
    session.queue.delete(index);
  }
}

/** 标记某预览为最近活跃（用户请求/预取命中）。 */
function touchLatest(key: string): void {
  globalLatestKey = key;
  globalLatestAt = Date.now();
}

function redirectToLatestSegment(key: string, index: number): boolean {
  const session = sessions.get(key);
  if (session?.activeIndex === index) session.activeIndex = null;
  if (globalActiveKey === key) globalActiveKey = null;
  const latest = session?.priorityIndex;
  if (latest !== null && latest !== undefined && latest !== index && session?.filePath) {
    session.activeIndex = latest;
    void startSegmentTranscode(session.filePath, session.subIndex, key, latest, latest * SEGMENT_SECONDS);
    return true;
  }
  return false;
}

async function startSegmentTranscode(
  filePath: string,
  subIndex: number | null,
  key: string,
  index: number,
  seekFrom: number,
): Promise<void> {
  const initialSession = sessions.get(key);
  if (!initialSession || initialSession.activeIndex !== index || initialSession.priorityIndex !== index) {
    redirectToLatestSegment(key, index);
    return;
  }
  // 全局互斥：若别的 key 正在转码，中止它（用户当前查看的预览优先）。
  if (globalActiveKey && globalActiveKey !== key) {
    const other = sessions.get(globalActiveKey);
    if (other?.proc) {
      killPreviewProcess(other.proc, "SIGKILL");
      other.killedAt = Date.now();
      // 不立即置 proc=null：等 close 回调清理，避免残留进程与新进程写同一文件冲突。
    }
    globalActiveKey = null;
  }
  const ffmpegExecutable = (await resolveToolPath("ffmpeg").catch(() => null)) ?? "ffmpeg";
  const session = sessions.get(key);
  if (!session || session.activeIndex !== index || session.priorityIndex !== index) {
    redirectToLatestSegment(key, index);
    return;
  }
  globalActiveKey = key;
  const target = segmentFile(key, index);
  void fs.rm(target, { force: true }).catch(() => {});
  void fs.rm(segmentDoneFile(key, index), { force: true }).catch(() => {});
  const start = Math.max(0, seekFrom);
  const copyStream = await canStreamCopy(filePath, subIndex);
  if (!session || session.activeIndex !== index || session.priorityIndex !== index) {
    redirectToLatestSegment(key, index);
    return;
  }
  const args = copyStream
    ? [
        "-hide_banner",
        "-loglevel", "error",
        "-fflags", "+genpts",
        "-ss", String(start),
        "-i", ffmpegPath(filePath),
        "-map", "0:v:0",
        "-map", "0:a:0?",
        "-c:v", "copy",
        "-c:a", "aac",
        "-ac", "2",
        "-b:a", "96k",
        "-avoid_negative_ts", "make_zero",
        "-max_muxing_queue_size", "1024",
        "-t", String(SEGMENT_SECONDS),
        "-sn",
        "-movflags", "+faststart",
        "-y",
        ffmpegPath(target),
      ]
    : [
    "-hide_banner",
    "-loglevel", "error",
    "-fflags", "+genpts",
    "-ss", String(start),
    "-i", ffmpegPath(filePath),
    ...(subIndex !== null
      ? [
          "-filter_complex",
          `[0:v:0]scale=trunc(min(960\\,iw)/2)*2:-2[v];[0:s:${subIndex}]format=rgba[sraw];[sraw][v]scale2ref[s][vmain];[vmain][s]overlay=0:0:eof_action=pass[vout]`,
          "-map", "[vout]",
          "-map", "0:a:0?",
        ]
      : [
          "-map", "0:v:0",
          "-map", "0:a:0?",
          "-vf", "scale=trunc(min(960\\,iw)/2)*2:-2",
        ]),
    "-c:v", "libx264",
    "-preset", "ultrafast",
    "-threads", "4",
    "-g", "24",
    "-keyint_min", "24",
    "-sc_threshold", "0",
    "-pix_fmt", "yuv420p",
    "-b:v", "2500k",
    "-maxrate", "3200k",
    "-bufsize", "4000k",
    "-c:a", "aac",
    "-ac", "2",
    "-b:a", "96k",
    "-avoid_negative_ts", "make_zero",
    "-max_muxing_queue_size", "1024",
    "-fps_mode", "cfr",
    "-t", String(SEGMENT_SECONDS),
    "-movflags", "+faststart",
    "-y",
    ffmpegPath(target),
  ];

  const managed = processRunner.spawn({ executable: ffmpegExecutable, args, stage: "preview-segment", timeoutMs: 90_000 });
  const proc = managed.child as ChildProcessWithoutNullStreams;
  managedKillers.set(proc, managed.kill);
  session.proc = proc;
  let stderr = "";
  // 重编码以低优先级运行：拖动/操作界面时系统响应不卡顿。
  if (!copyStream && typeof proc.pid === "number") {
    void execFile(
      "powershell",
      ["-NoProfile", "-Command", `(Get-Process -Id ${proc.pid}).PriorityClass='BelowNormal'`],
      { windowsHide: true },
      () => {},
    );
  }
  // 超时保护：单段转码最多 90 秒，防止进程挂死导致前端永远 425。
  const timeout = setTimeout(() => {
    if (sessions.get(key)?.proc === proc) {
      killPreviewProcess(proc, "SIGKILL");
    }
  }, 90_000);
  proc.stderr.on("data", (chunk: Buffer) => { stderr += String(chunk); });
  proc.on("error", () => {
    clearTimeout(timeout);
    if (globalActiveKey === key) globalActiveKey = null;
    const current = sessions.get(key);
    if (current?.proc === proc) current.proc = null;
    if (current?.activeIndex === index) current.activeIndex = null;
    if (current?.priorityIndex !== null && current?.priorityIndex !== index && current?.filePath) {
      void startSegmentTranscode(current.filePath, current.subIndex, key, current.priorityIndex, current.priorityIndex * SEGMENT_SECONDS);
    }
  });
  proc.on("close", (code) => {
    clearTimeout(timeout);
    if (globalActiveKey === key) globalActiveKey = null;
    const current = sessions.get(key);
    if (current?.proc === proc) current.proc = null;
    if (current?.activeIndex === index) current.activeIndex = null;
    const restartLatest = () => {
      return redirectToLatestSegment(key, index);
    };
    if (code !== 0) {
      current?.queue.delete(index);
      void fs.rm(target, { force: true }).catch(() => {});
      void fs.rm(segmentDoneFile(key, index), { force: true }).catch(() => {});
      void fs.appendFile(
        path.join(os.tmpdir(), "vx-preview-segment-errors.log"),
        `[${new Date().toISOString()}] seg=${index} key=${key} exit=${code}\n${stderr.slice(0, 800)}\n`,
        "utf8",
      ).catch(() => {});
      restartLatest();
    } else {
      // 空输出（如 seek 超出视频时长）视为失败：不写 .done，避免 64KB 阈值下无限重转。
      void fs.stat(target).then((stat) => {
        if (stat.size > 64 * 1024) {
          void fs.writeFile(segmentDoneFile(key, index), "1", "utf8").catch(() => {});
          if (!restartLatest()) {
            // 一段完成后继续后台队列，保证连续播放/短距快进不等待。
            void pumpQueue(key).catch(() => {});
          }
        } else {
          void fs.rm(target, { force: true }).catch(() => {});
          current?.failed.add(index);
          void fs.appendFile(
            path.join(os.tmpdir(), "vx-preview-segment-errors.log"),
            `[${new Date().toISOString()}] seg=${index} key=${key} empty-output\n`,
            "utf8",
          ).catch(() => {});
          restartLatest();
        }
      }).catch(() => {});
    }
  });
}

/** 对完整片段文件提供 Range 响应（浏览器可在片段内随机访问）。 */
export function serveRangeFile(res: Response, file: string, size: number): void {
  const range = res.req.headers.range;
  if (!range) {
    res.setHeader("Content-Length", size);
    res.setHeader("Content-Type", "video/mp4");
    res.setHeader("Accept-Ranges", "bytes");
    fsSync.createReadStream(file).pipe(res);
    return;
  }
  const match = range.match(/bytes=(\d*)-(\d*)/);
  if (!match) { res.status(416).end(); return; }
  const start = match[1] ? Number(match[1]) : 0;
  const end = match[2] ? Math.min(Number(match[2]), size - 1) : Math.min(start + 1024 * 1024 - 1, size - 1);
  if (start >= size || end < start) { res.status(416).end(); return; }
  res.status(206).set({
    "Content-Range": `bytes ${start}-${end}/${size}`,
    "Accept-Ranges": "bytes",
    "Content-Length": String(end - start + 1),
    "Content-Type": "video/mp4",
  });
  fsSync.createReadStream(file, { start, end }).pipe(res);
}

/**
 * 预览路由入口：确保目标片段已转码/正在转码；已就绪则返回片段文件（Range），
 * 未就绪返回 425 供前端轮询。
 */
export async function servePreviewSegment(
  res: Response,
  filePath: string,
  subTypeIndex: number | null,
  seekSeconds: number,
): Promise<void> {
  const key = previewSegmentKey(filePath, subTypeIndex);
  const index = segmentIndexFor(seekSeconds);
  // 片段永远从 5s 边界开始转码，与前端 #t= 偏移/自动续播对齐。
  const status = await ensurePreviewSegment(filePath, subTypeIndex, index, { seekFrom: index * SEGMENT_SECONDS });
  // 顺带把后续 4 段加入后台预生成队列（短提前量，避免长时后台转码让风扇持续高速运转）。
  queueBackgroundSegments(filePath, subTypeIndex, index, 4);
  if (status === "ready") {
    const segPath = segmentFile(key, index);
    const size = await fs.stat(segPath).then((s) => s.size).catch(() => 0);
    if (size > 0) {
      res.setHeader("X-Preview-Mode", "segment");
      res.setHeader("Cache-Control", "no-store");
      serveRangeFile(res, segPath, size);
      return;
    }
  }
  if (status === "failed") {
    res.status(404).json({ error: "预览片段无法生成（可能超出视频时长）" });
    return;
  }
  res.status(425).json({ status: "transcoding", index, segmentSeconds: SEGMENT_SECONDS });
}

/** 停止某任务/媒体的全部预览转码并清理片段目录（任务删除时调用）。 */
export async function cleanupPreviewSegments(filePath: string, subIndex: number | null = null): Promise<void> {
  const key = previewSegmentKey(filePath, subIndex);
  const session = sessions.get(key);
  if (session?.proc) {
    killPreviewProcess(session.proc, "SIGKILL");
    session.proc = null;
  }
  if (session && session.activeIndex !== null) session.activeIndex = null;
  sessions.delete(key);
  await fs.rm(segmentDir(key), { recursive: true, force: true }).catch(() => {});
}

/** 定时清理闲置会话与过期片段，防止临时目录膨胀。 */
export function sweepPreviewSegments(now = Date.now()): void {
  for (const [key, session] of sessions) {
    if (now - session.lastActivity > 10 * 60_000 && !session.proc && session.activeIndex === null) {
      sessions.delete(key);
      void fs.rm(segmentDir(key), { recursive: true, force: true }).catch(() => {});
    }
  }
}

/** 惰性触发：转码/请求路径上每 10 分钟清理一次，无需额外定时器。 */
function maybeSweep(): void {
  const now = Date.now();
  if (now - lastSweepAt < 10 * 60_000) return;
  lastSweepAt = now;
  sweepPreviewSegments(now);
}
