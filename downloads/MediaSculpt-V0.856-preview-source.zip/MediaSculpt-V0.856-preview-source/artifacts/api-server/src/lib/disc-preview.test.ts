import { describe, expect, it } from "vitest";
import {
  buildDiscPreviewInputArgs,
  extractLastJpegFrame,
} from "./disc-preview";

describe("disc preview input", () => {
  it("drives Blu-ray previews from the MPLS playlist instead of a raw M2TS", () => {
    const args = buildDiscPreviewInputArgs({
      mediaType: "bluray",
      sourcePath: "H:\\La_Bayadere",
      previewSourcePath: "H:\\La_Bayadere\\BDMV\\STREAM\\00003.m2ts",
      playlistId: "01003",
      offsetSeconds: 1972.25,
    });

    expect(args).toEqual([
      "-playlist",
      "01003",
      "-ss",
      "1972.25",
      "-i",
      "bluray:H:/La_Bayadere",
    ]);
    expect(args).not.toContain("H:/La_Bayadere/BDMV/STREAM/00003.m2ts");
  });

  it("selects the Blu-ray segment containing the requested playlist time", () => {
    const args = buildDiscPreviewInputArgs({
      mediaType: "bluray",
      sourcePath: "H:\\National Ballet",
      previewSourcePath: "H:\\National Ballet\\BDMV\\STREAM\\00002.m2ts",
      playlistId: "00006",
      offsetSeconds: 792.87,
      previewSegments: [
        {
          sourcePath: "H:\\National Ballet\\BDMV\\STREAM\\00002.m2ts",
          startSeconds: 0,
          endSeconds: 136.77,
        },
        {
          sourcePath: "H:\\National Ballet\\BDMV\\STREAM\\00000.m2ts",
          startSeconds: 136.77,
          endSeconds: 3163.09,
        },
      ],
    });

    expect(args).toEqual([
      "-ss",
      "656.1",
      "-i",
      "H:/National Ballet/BDMV/STREAM/00000.m2ts",
    ]);
    expect(args).not.toContain("bluray:H:/National Ballet");
  });

  it("keeps DVD previews on the validated dvdvideo input", () => {
    const args = buildDiscPreviewInputArgs({
      mediaType: "dvd",
      sourcePath: "H:\\DVD\\VIDEO_TS",
      previewSourcePath: null,
      playlistId: null,
      offsetSeconds: 12,
      handbrakeTitleNumber: 3,
    });

    expect(args).toEqual([
      "-ss",
      "12",
      "-f",
      "dvdvideo",
      "-title",
      "3",
      "-i",
      "H:/DVD/VIDEO_TS",
    ]);
  });

  it("uses the verified DVD VOB concat source when one is available", () => {
    const args = buildDiscPreviewInputArgs({
      mediaType: "dvd",
      sourcePath: "H:\\DVD\\VIDEO_TS",
      previewSourcePath:
        "concat:H:/DVD/VIDEO_TS/VTS_01_1.VOB|H:/DVD/VIDEO_TS/VTS_01_2.VOB",
      playlistId: null,
      offsetSeconds: 12,
      handbrakeTitleNumber: 3,
    });

    expect(args).toEqual([
      "-ss",
      "12",
      "-i",
      "concat:H:/DVD/VIDEO_TS/VTS_01_1.VOB|H:/DVD/VIDEO_TS/VTS_01_2.VOB",
    ]);
    expect(args).not.toContain("dvdvideo");
  });

  it("returns the last decoded JPEG when a VC-1 preview needs decoder warmup", () => {
    const first = Buffer.from([0xff, 0xd8, 1, 0xff, 0xd9]);
    const last = Buffer.from([0xff, 0xd8, 2, 3, 0xff, 0xd9]);

    expect(extractLastJpegFrame(Buffer.concat([first, last]))).toEqual(last);
  });
});
