import { describe, expect, it } from "vitest";
import { gradeCompressionOutput, type CompressionOutputProbe } from "./compression-validation";

const probe: CompressionOutputProbe = {
  durationSeconds: 600,
  streams: [
    { codecType: "video" },
    { codecType: "audio" },
  ],
  chapters: [],
};

describe("DVD compression output grading", () => {
  it("treats chapter and subtitle loss as warnings when video and required audio are valid", () => {
    const result = gradeCompressionOutput({
      probe: { ...probe, chapters: [] },
      expectedDurationSeconds: 600,
      expectedVideoCount: 1,
      expectedAudioCount: 2,
      requiredAudioCount: 1,
      expectedSubtitleCount: 2,
      expectedChapterCount: 8,
    });

    expect(result.errors).toEqual([]);
    expect(result.warnings.join(" ")).toContain("章节");
    expect(result.warnings.join(" ")).toContain("字幕");
    expect(result.warnings.join(" ")).toContain("可选音轨");
  });

  it("fails when the selected title output has no video or required main audio", () => {
    const result = gradeCompressionOutput({
      probe: { durationSeconds: 600, streams: [{ codecType: "video" }], chapters: [] },
      expectedDurationSeconds: 600,
      expectedVideoCount: 1,
      expectedAudioCount: 1,
      requiredAudioCount: 1,
      expectedSubtitleCount: 0,
      expectedChapterCount: 0,
    });

    expect(result.errors.join(" ")).toContain("主音轨");
  });

  it("does not require audio when the user selected no audio tracks", () => {
    const result = gradeCompressionOutput({
      probe: { durationSeconds: 600, streams: [{ codecType: "video" }], chapters: [] },
      expectedDurationSeconds: 600,
      expectedVideoCount: 1,
      expectedAudioCount: 0,
      requiredAudioCount: 0,
      expectedSubtitleCount: 0,
      expectedChapterCount: 0,
    });

    expect(result.errors).toEqual([]);
  });
});
