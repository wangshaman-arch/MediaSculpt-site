import { ffmpegPath } from "./runtime-paths";
import type { DiscPreviewSegment } from "./disc-analysis";

export type DiscPreviewInput = {
  mediaType: "dvd" | "bluray";
  sourcePath: string;
  previewSourcePath?: string | null;
  previewSegments?: DiscPreviewSegment[];
  playlistId?: string | null;
  handbrakeTitleNumber?: number | null;
  offsetSeconds?: number;
};

export function extractLastJpegFrame(data: Buffer): Buffer {
  const jpegStart = Buffer.from([0xff, 0xd8]);
  const jpegEnd = Buffer.from([0xff, 0xd9]);
  const start = data.lastIndexOf(jpegStart);
  if (start < 0) return data;
  const end = data.indexOf(jpegEnd, start + jpegStart.length);
  return end >= 0
    ? data.subarray(start, end + jpegEnd.length)
    : data.subarray(start);
}

/** Build the input side of a disc preview command from the same title authority used for jobs. */
export function buildDiscPreviewInputArgs(
  input: DiscPreviewInput,
  platform = process.platform,
): string[] {
  const offsetSeconds =
    Number.isFinite(input.offsetSeconds) && (input.offsetSeconds ?? 0) > 0
      ? String(input.offsetSeconds)
      : null;

  if (input.mediaType === "dvd") {
    const args = offsetSeconds ? ["-ss", offsetSeconds] : [];
    const previewSourcePath = input.previewSourcePath?.trim();
    if (previewSourcePath) {
      args.push("-i", ffmpegPath(previewSourcePath, platform));
      return args;
    }
    if (
      typeof input.handbrakeTitleNumber === "number" &&
      input.handbrakeTitleNumber > 0
    ) {
      args.push("-f", "dvdvideo", "-title", String(input.handbrakeTitleNumber));
    }
    args.push("-i", ffmpegPath(input.sourcePath, platform));
    return args;
  }

  const previewSegments = (input.previewSegments ?? [])
    .filter(
      (segment) =>
        segment.sourcePath &&
        Number.isFinite(segment.startSeconds) &&
        Number.isFinite(segment.endSeconds) &&
        segment.endSeconds > segment.startSeconds,
    )
    .sort((a, b) => a.startSeconds - b.startSeconds);
  if (previewSegments.length > 0) {
    const offset = Math.max(0, input.offsetSeconds ?? 0);
    const segment =
      previewSegments.find(
        (candidate) =>
          offset >= candidate.startSeconds && offset < candidate.endSeconds,
      ) ?? previewSegments[previewSegments.length - 1];
    const localOffset = Math.max(0, offset - segment.startSeconds);
    const args = localOffset > 0 ? ["-ss", String(localOffset)] : [];
    args.push("-i", ffmpegPath(segment.sourcePath, platform));
    return args;
  }

  const playlistId = input.playlistId?.trim();
  if (playlistId) {
    const args = ["-playlist", playlistId];
    if (offsetSeconds) args.push("-ss", offsetSeconds);
    args.push("-i", `bluray:${ffmpegPath(input.sourcePath, platform)}`);
    return args;
  }

  const args = offsetSeconds ? ["-ss", offsetSeconds] : [];
  args.push(
    "-i",
    ffmpegPath(input.previewSourcePath ?? input.sourcePath, platform),
  );
  return args;
}
