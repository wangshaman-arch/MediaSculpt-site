/**
 * Public, side-effect-free policy and plan model for the first smart-workflow
 * stage.  This module deliberately contains no process spawning.  It produces
 * data that the existing /jobs endpoint can consume after user confirmation.
 */

import path from "node:path";
import { bitDepthTag, buildRemuxOutputName, encoderBitDepth, normalizeAudioCodec, resolutionTag, selectBestAudioTrack } from "./output-naming";
import { logicValue, type CustomTuningLogic } from "./custom-tuning";

export const SMART_WORKFLOW_SCHEMA_VERSION = 1 as const;

export type SmartWorkflowMediaType = "video" | "dvd" | "bluray" | "iso";
export type SmartWorkflowStreamType = "video" | "audio" | "subtitle";
export type CompressionRecommendation = "recommend-compress" | "optional-compress" | "do-not-compress";
export type SubtitlePlanMode = "keep" | "translate-text" | "whisper" | "ocr-graphic" | "preserve-graphic" | "none";
export type SmartWorkflowAction = "remux" | "compress" | "subtitle" | "skip";

export type SmartWorkflowStream = {
  id: string;
  index?: number;
  type: SmartWorkflowStreamType;
  codec?: string | null;
  bitrate?: number | null;
  estimatedSizeBytes?: number | null;
  language?: string | null;
  title?: string | null;
  default?: boolean;
  forced?: boolean;
  width?: number | null;
  height?: number | null;
  channels?: number | null;
  handbrakeTrackNumber?: number | null;
};

export type SmartWorkflowChapter = {
  id: string;
  startSeconds: number;
  endSeconds: number;
  title?: string | null;
};

export type SmartWorkflowMediaInput = {
  sourcePath: string;
  sourceType: SmartWorkflowMediaType;
  sourceFingerprint: string;
  analysisId?: string | null;
  selectedTitleId?: string | null;
  titleId?: string | null;
  titleIndex?: number | null;
  displayName?: string | null;
  durationSeconds?: number | null;
  sizeBytes?: number | null;
  streams: SmartWorkflowStream[];
  chapters: SmartWorkflowChapter[];
  /** Subtitle files found next to a loose video file (name pair or Chinese content). */
  externalSubtitles?: Array<{ path: string; hasChinese: boolean; language?: string | null }>;
  /** Existing DVD/BD analysis uses the HandBrake title number as its identity. */
  handbrakeTitleNumber?: number | null;
  /** Existing taskSnapshot uses numeric global stream indexes. */
  streamIndexes?: Record<string, number>;
};

export type CompressionDecision = {
  recommendation: CompressionRecommendation;
  estimated: boolean;
  rationale: string;
  presetId: string | null;
  estimatedOutputBytes: number | null;
  /** Whether the source looks like a documentary (genre/filename heuristic). */
  documentary?: boolean;
};

export type SubtitleDecision = {
  mode: SubtitlePlanMode;
  runWhisper: boolean;
  runOcr: boolean;
  translate: boolean;
  sourceSubtitleId: string | null;
  sourceAudioId: string | null;
  sourceLanguage: string | null;
  targetLanguage: string;
  rationale: string;
};

export type SmartWorkflowIdentity = {
  title: string;
  titleEn?: string | null;
  imdbId?: string | null;
  /** Composed display name: English.Name.1995.中文名 */
  displayName?: string | null;
  year?: number | null;
  mediaType?: "movie" | "tv";
  poster?: string | null;
  source?: string | null;
  confidence?: number | null;
  overview?: string | null;
};

export type SmartWorkflowItem = {
  id: string;
  sourcePath: string;
  sourceFingerprint: string;
  sourceType: SmartWorkflowMediaType;
  analysisId: string | null;
  titleId: string | null;
  titleIndex: number | null;
  handbrakeTitleNumber: number | null;
  displayName: string;
  durationSeconds: number | null;
  enabled: boolean;
  inferredUse: "main-feature" | "featurette" | "interview" | "trailer" | "video" | "unknown";
  action: SmartWorkflowAction;
  outputName: string;
  presetId: string | null;
  compression: CompressionDecision;
  streams: SmartWorkflowStream[];
  chapters: SmartWorkflowChapter[];
  selectedStreamIds: string[];
  selectedChapterIds: string[];
  subtitle: SubtitleDecision;
  /** Mirror of the input's external subtitle companions for the plan UI. */
  externalSubtitles?: Array<{ path: string; hasChinese: boolean; language?: string | null }>;
  warnings: string[];
  rationale: string;
  confidence: number;
};

export type SmartWorkflowPlan = {
  schemaVersion: typeof SMART_WORKFLOW_SCHEMA_VERSION;
  planId: string;
  createdAt: string;
  source: {
    path: string;
    type: SmartWorkflowMediaType;
    fingerprint: string;
  };
  identity: SmartWorkflowIdentity;
  metadata: {
    poster: string | null;
    source: string | null;
    candidates: SmartWorkflowIdentity[];
  };
  items: SmartWorkflowItem[];
  warnings: string[];
  degraded: {
    aiUnavailable: boolean;
    metadataUnavailable: boolean;
  };
};

export type CreateJobInput = {
  filePath: string;
  subtitleMode: "auto" | "extract" | "whisper" | "transcribe_translate" | "ocr" | "skip";
  processingMode: "compress" | "remux" | "none";
  mediaType?: SmartWorkflowMediaType;
  mainTrackPath?: string;
  selectedStreams?: string;
  selectedChapters?: string;
  selectionPlan: string;
  analysisId?: string;
  sourceFingerprint?: string;
  selectedTitleId?: string;
  outputMode: "compress" | "remux" | "subtitle" | "whisper";
};

/** DVD Remux requires the exact title to be verified before the immutable snapshot is built. */
export function workflowItemRequiresTitleVerification(item: Pick<SmartWorkflowItem, "sourceType" | "action">): boolean {
  return item.sourceType === "dvd" && item.action === "remux";
}

function stableId(value: string): string {
  // A deterministic, human-readable identifier is sufficient here.  The
  // source fingerprint and title ID remain in the plan and taskSnapshot.
  let hash = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return `sw-${(hash >>> 0).toString(16).padStart(8, "0")}`;
}

export function lower(value: unknown): string {
  return String(value ?? "").trim().toLowerCase();
}

export function isTextSubtitle(stream: SmartWorkflowStream): boolean {
  return ["subrip", "srt", "ass", "ssa", "webvtt", "mov_text", "text", "tx3g"].includes(lower(stream.codec));
}

export function isGraphicSubtitle(stream: SmartWorkflowStream): boolean {
  return ["dvd_subtitle", "hdmv_pgs_subtitle", "pgssub", "dvb_subtitle", "vobsub", "sup"].includes(lower(stream.codec));
}

export function isChinese(value: string | null | undefined): boolean {
  const normalized = lower(value);
  return ["zh", "zho", "chi", "cmn", "yue", "chinese"].includes(normalized) || normalized.startsWith("zh-");
}

function looksLikeCommentary(stream: SmartWorkflowStream): boolean {
  return /commentary|director|audio description|description|解说|评论/i.test(`${stream.title ?? ""} ${stream.language ?? ""}`);
}

export function chooseMainAudio(streams: SmartWorkflowStream[]): SmartWorkflowStream | undefined {
  const audio = streams.filter((stream) => stream.type === "audio" && !looksLikeCommentary(stream));
  return audio.find((stream) => stream.default) ?? audio[0] ?? streams.find((stream) => stream.type === "audio");
}

import { decideCompression, decideSubtitlePlan, decideAutomaticSubtitleStrategy } from "./smart-workflow-decisions";
export { decideCompression, decideSubtitlePlan, decideAutomaticSubtitleStrategy, type AutomaticSubtitleStrategy, type AutomaticSubtitleDecision } from "./smart-workflow-decisions";

function containsCjk(value: string): boolean {
  return /[\u3400-\u9fff]/.test(value);
}

/**
 * 从源路径推导一个"更像真片名"的标题，优先使用父目录名。
 * 很多视频文件名是发布组代号/分辨率标签（如 `qsp-kad1080.mkv`、`Movie.2020.1080p`），
 * 而所在目录名才是真正的片名（如 `Knight.And.Day.2010.危情谍战`）。
 * 当文件主名没有空格、没有中文、且带分辨率/来源标签时可判定为代号，转而用目录名。
 */
export function inferTitleFromSource(sourcePath: string, displayName?: string | null): string {
  const stemFallback = (value: string): string => value
    .replace(/\.[^.]+$/, "")
    .replace(/[._]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (displayName && hasCleanTitle(displayName)) return stemFallback(displayName);
  const fileStem = path.basename(sourcePath, path.extname(sourcePath));
  if (hasCleanTitle(fileStem)) return stemFallback(fileStem);
  const parent = path.basename(path.dirname(sourcePath));
  if (parent && parent !== path.dirname(sourcePath) && hasCleanTitle(parent)) return stemFallback(parent);
  return stemFallback(fileStem) || "未命名媒体";
}

/** 判定字符串看起来像一个"真实标题"（含空格/中文/真实年份），而非发布代号。 */
function hasCleanTitle(value: string): boolean {
  const raw = String(value ?? "").trim();
  if (!raw) return false;
  return /\s/.test(raw) || /[\u3400-\u9fff]/.test(raw) || /\b(?:19|20)\d{2}\b/.test(raw);
}

function normalizeNameWords(value: string): string {
  return value
    .replace(/[^\p{L}\p{N}]+/gu, ".")
    .replace(/^\.+|\.+$/g, "")
    .replace(/\.{2,}/g, ".")
    .trim();
}

/** English name first; falls back to the source-language title when no English name exists. */
export function englishNameBase(identity: SmartWorkflowIdentity): string {
  const title = String(identity.title ?? "").trim();
  const titleEn = String(identity.titleEn ?? "").trim();
  const candidate = titleEn || (title && !containsCjk(title) ? title : "");
  if (candidate) return normalizeNameWords(candidate);
  return normalizeNameWords(title) || "media";
}

/** Display name shown in the confirmation panel: English.Name.1995.中文名 */
export function buildDisplayName(identity: SmartWorkflowIdentity): string {
  const base = englishNameBase(identity);
  const year = identity.year ? String(identity.year) : "";
  const title = String(identity.title ?? "").trim();
  const chineseName = !containsCjk(base) && title && containsCjk(title) ? title : "";
  return [base, year, chineseName].filter(Boolean).join(".");
}

function videoCodecTag(codec: string | null | undefined): string {
  const map: Record<string, string> = {
    h264: "H264", avc1: "H264", hevc: "H265", h265: "H265", av1: "AV1",
    vp9: "VP9", vp8: "VP8", mpeg2video: "MPEG2", mpeg1video: "MPEG1",
    mpeg4: "MPEG4", msmpeg4: "MPEG4", vc1: "VC1", wmv3: "VC1",
  };
  return map[lower(codec)] ?? (codec ? String(codec).toUpperCase() : "");
}

function audioCodecTag(codec: string | null | undefined): string {
  const map: Record<string, string> = {
    ac3: "AC3", eac3: "EAC3", dts: "DTS", dts_hd_ma: "DTS-HD.MA", dtshd_ma: "DTS-HD.MA",
    truehd: "TrueHD", aac: "AAC", flac: "FLAC", mp3: "MP3", vorbis: "Vorbis",
    opus: "Opus", pcm_s16le: "PCM", pcm_s24le: "PCM",
  };
  return map[lower(codec)] ?? (codec ? String(codec).toUpperCase() : "");
}

function outputNameFor(input: SmartWorkflowMediaInput, identity: SmartWorkflowIdentity, action: SmartWorkflowAction, encoder?: string): string {
  // Disc titles share the movie identity, so they keep the identity name plus
  // a title suffix. Loose video files use their own file stem as the name
  // base; using the shared identity here made every item produce the same
  // output name ("output path conflicts" during plan validation).
  const base = input.titleId
    ? englishNameBase(identity)
    : normalizeNameWords(
        inferTitleFromSource(input.sourcePath, input.displayName) || "media",
      );
  const year = identity.year ? String(identity.year) : "";
  const baseWithYear = [base, year].filter(Boolean).join(".");
  // Remux 无损版：英文名.年份.来源.Remux.mkv（DVD / BluRay）
  if (action === "remux") {
    return buildRemuxOutputName(baseWithYear, input.sourceType, "mkv");
  }
  if (action === "subtitle" || action === "skip") {
    return `${baseWithYear || "media"}.mkv`;
  }
  const video = input.streams.find((stream) => stream.type === "video");
  const audio = selectBestAudioTrack(input.streams.filter((stream) => stream.type === "audio"));
  const codecTag = videoCodecTag(video?.codec);
  const sourceTag = input.sourceType === "dvd"
    ? "DVDrip"
    : input.sourceType === "bluray" || input.sourceType === "iso"
      ? "BluRay"
      : "";
  const depthTag = bitDepthTag(encoderBitDepth(encoder));
  const audioTag = normalizeAudioCodec(audio?.codec ?? null);
  // 压缩版：英文名.年份.[分辨率.][来源.][编码.]位深.音频格式.扩展名（不含码率）
  const tags = [
    resolutionTag(video?.height),
    sourceTag,
    input.sourceType === "bluray" || input.sourceType === "iso" ? "" : codecTag,
    depthTag,
    audioTag,
  ].filter(Boolean).join(".");
  const suffix = input.titleId ? `.${input.titleIndex ?? input.handbrakeTitleNumber ?? "title"}` : "";
  const name = [baseWithYear, tags].filter(Boolean).join(".");
  const sanitized = name
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, "_")
    .replace(/\.{2,}/g, ".")
    .replace(/^\.+|\.+$/g, "")
    .trim() || "media";
  return `${sanitized}${suffix}.mkv`;
}

function inferUse(input: SmartWorkflowMediaInput): SmartWorkflowItem["inferredUse"] {
  const seconds = Number(input.durationSeconds ?? 0);
  if (input.sourceType === "video") return "video";
  if (seconds >= 45 * 60) return "main-feature";
  const text = lower(input.displayName);
  if (/trailer|预告/.test(text)) return "trailer";
  if (/interview|访谈/.test(text)) return "interview";
  return "featurette";
}

export function buildSmartWorkflowPlan(
  input: SmartWorkflowMediaInput,
  options: { identity?: Partial<SmartWorkflowIdentity>; candidates?: SmartWorkflowIdentity[]; presetIds?: string[]; aiUnavailable?: boolean; metadataUnavailable?: boolean; encoder?: string; tuning?: CustomTuningLogic; requireExplicitAction?: boolean } = {},
): SmartWorkflowPlan {
  const identity: SmartWorkflowIdentity = {
    title: options.identity?.title || input.displayName || inferTitleFromSource(input.sourcePath, input.displayName) || "未命名媒体",
    titleEn: options.identity?.titleEn ?? null,
    imdbId: options.identity?.imdbId ?? null,
    displayName: null,
    year: options.identity?.year ?? null,
    mediaType: options.identity?.mediaType ?? "movie",
    poster: options.identity?.poster ?? null,
    source: options.identity?.source ?? null,
    confidence: options.identity?.confidence ?? null,
    overview: options.identity?.overview ?? null,
  };
  const compression = decideCompression({ ...input, mediaType: identity.mediaType ?? null }, options.tuning);
  const subtitle = decideSubtitlePlan(input.streams, undefined, input.externalSubtitles);
  const selectedStreamIds = input.streams.map((stream) => stream.id);
  const selectedChapterIds = input.chapters.map((chapter) => chapter.id);
  const itemId = stableId(`${input.sourceFingerprint}:${input.titleId ?? input.sourcePath}`);
  const recommendedAction: SmartWorkflowAction = compression.recommendation === "do-not-compress"
    ? input.sourceType === "video"
      ? subtitle.runWhisper || subtitle.translate ? "subtitle" : "skip"
      : "remux"
    : "compress";
  const action: SmartWorkflowAction = options.requireExplicitAction ? "skip" : recommendedAction;
  // 按来源类型默认压缩预设：DVD→DVD转制，蓝光/ISO→蓝光收藏，其余→综合均衡
  const defaultPreset = action === "compress"
    ? input.sourceType === "dvd" && options.presetIds?.includes("dvd-convert")
      ? "dvd-convert"
      : (input.sourceType === "bluray" || input.sourceType === "iso") && options.presetIds?.includes("bluray-collection")
        ? "bluray-collection"
        : options.presetIds?.includes("balanced")
          ? "balanced"
          : options.presetIds?.[0] ?? null
    : null;
  const item: SmartWorkflowItem = {
    id: itemId,
    sourcePath: input.sourcePath,
    sourceFingerprint: input.sourceFingerprint,
    sourceType: input.sourceType,
    analysisId: input.analysisId ?? null,
    titleId: input.titleId ?? input.selectedTitleId ?? null,
    titleIndex: input.titleIndex ?? null,
    handbrakeTitleNumber: input.handbrakeTitleNumber ?? null,
    displayName: input.displayName || identity.title,
    durationSeconds: input.durationSeconds ?? null,
    enabled: true,
    inferredUse: inferUse(input),
    action,
    outputName: outputNameFor(input, identity, action, options.encoder),
    presetId: defaultPreset,
    compression: { ...compression, presetId: defaultPreset },
    streams: input.streams,
    chapters: input.chapters,
    selectedStreamIds,
    selectedChapterIds,
    subtitle,
    externalSubtitles: input.externalSubtitles ?? [],
    warnings: [],
    rationale: compression.rationale,
    confidence: input.sourceType === "video" ? 0.7 : 0.65,
  };
  identity.displayName = buildDisplayName(identity);
  return {
    schemaVersion: SMART_WORKFLOW_SCHEMA_VERSION,
    planId: stableId(`${input.sourceFingerprint}:plan`),
    createdAt: new Date().toISOString(),
    source: { path: input.sourcePath, type: input.sourceType, fingerprint: input.sourceFingerprint },
    identity,
    metadata: { poster: identity.poster ?? null, source: identity.source ?? null, candidates: options.candidates ?? [] },
    items: [item],
    warnings: [],
    degraded: { aiUnavailable: options.aiUnavailable ?? true, metadataUnavailable: options.metadataUnavailable ?? true },
  };
}

function isSafeOutputName(name: string): boolean {
  return Boolean(name) && name === name.trim() && !/[\\/]/.test(name) && name !== "." && name !== ".." && !name.includes("..\\") && !name.includes("../");
}

export function validateSmartWorkflowPlan(plan: SmartWorkflowPlan, options: { availablePresetIds?: string[] } = {}): string[] {
  const errors: string[] = [];
  if (plan.schemaVersion !== SMART_WORKFLOW_SCHEMA_VERSION) errors.push("unsupported schema version");
  if (!plan.source.path || !plan.source.fingerprint) errors.push("source is missing");
  if (plan.items.length === 0) errors.push("plan has no items");
  const ids = new Set<string>();
  const outputs = new Set<string>();
  for (const item of plan.items) {
    if (ids.has(item.id)) errors.push("duplicate item identity");
    ids.add(item.id);
    if (!item.sourcePath || !item.sourceFingerprint) errors.push(`item ${item.id} source is missing`);
    if (!isSafeOutputName(item.outputName)) errors.push(`item ${item.id} output name is invalid`);
    const outputKey = item.outputName.toLowerCase();
    if (outputs.has(outputKey)) errors.push("output path conflicts");
    outputs.add(outputKey);
    if (options.availablePresetIds && item.presetId && !options.availablePresetIds.includes(item.presetId)) errors.push(`item ${item.id} preset ID is invalid`);
    const streamIds = new Set(item.streams.map((stream) => stream.id));
    if (item.selectedStreamIds.some((id) => !streamIds.has(id))) errors.push(`item ${item.id} selects a missing stream`);
    const chapterIds = new Set(item.chapters.map((chapter) => chapter.id));
    if (item.selectedChapterIds.some((id) => !chapterIds.has(id))) errors.push(`item ${item.id} selects a missing chapter`);
    if (item.subtitle.runWhisper && (!item.subtitle.sourceAudioId || !streamIds.has(item.subtitle.sourceAudioId))) errors.push(`item ${item.id} Whisper source audio is missing`);
    if (item.subtitle.mode === "translate-text" && (!item.subtitle.sourceSubtitleId || !streamIds.has(item.subtitle.sourceSubtitleId))) errors.push(`item ${item.id} translation source subtitle is missing`);
    if (item.subtitle.mode === "ocr-graphic" && (!item.subtitle.runOcr || !item.subtitle.sourceSubtitleId || !streamIds.has(item.subtitle.sourceSubtitleId))) errors.push(`item ${item.id} OCR source subtitle is missing`);
    if (item.subtitle.mode === "preserve-graphic" && item.subtitle.translate) errors.push(`item ${item.id} graphical subtitle cannot be directly translated`);
    if (item.action === "remux" && item.sourceType !== "video" && !item.titleId) errors.push(`item ${item.id} disc title is missing`);
  }
  return errors;
}

function toNumericIndexes(item: SmartWorkflowItem, type: SmartWorkflowStreamType): number[] {
  return item.streams
    .filter((stream) => stream.type === type && item.selectedStreamIds.includes(stream.id))
    .map((stream, index) => Number.isFinite((stream as SmartWorkflowStream & { index?: number }).index) ? Number((stream as SmartWorkflowStream & { index?: number }).index) : index)
    .filter((value) => Number.isFinite(value));
}

export function planToJobInput(plan: SmartWorkflowPlan, item: SmartWorkflowItem): CreateJobInput {
  const subtitleMode = item.subtitle.mode === "whisper" ? "whisper" : item.subtitle.mode === "ocr-graphic" ? "ocr" : item.subtitle.mode === "translate-text" ? "transcribe_translate" : item.subtitle.mode === "none" ? "skip" : item.subtitle.mode === "keep" || item.subtitle.mode === "preserve-graphic" ? "extract" : "auto";
  const processingMode = item.action === "remux" ? "remux" : item.action === "skip" || item.action === "subtitle" ? "none" : "compress";
  const selectedStreams = item.selectedStreamIds.length > 0 ? JSON.stringify([
    ...toNumericIndexes(item, "video"),
    ...toNumericIndexes(item, "audio"),
    ...toNumericIndexes(item, "subtitle"),
  ]) : undefined;
  const selectedChapters = JSON.stringify(item.selectedChapterIds.map((id, index) => Number.isFinite(Number(id)) ? Number(id) : index));
  const outputMode = processingMode === "remux" ? "remux" : item.action === "subtitle" ? (subtitleMode === "whisper" || subtitleMode === "transcribe_translate" ? "whisper" : "subtitle") : "compress";
  return {
    filePath: item.sourcePath,
    subtitleMode,
    processingMode,
    mediaType: item.sourceType,
    selectedStreams,
    selectedChapters,
    selectionPlan: JSON.stringify({
      version: 1,
      workflow: "smart-workflow-v1",
      schemaVersion: plan.schemaVersion,
      planId: plan.planId,
      itemId: item.id,
      outputName: item.outputName,
      video: item.streams.filter((stream) => stream.type === "video" && item.selectedStreamIds.includes(stream.id)).map((stream) => stream.index ?? Number(stream.id.replace("stream-", ""))),
      audio: item.streams.filter((stream) => stream.type === "audio" && item.selectedStreamIds.includes(stream.id)).map((stream) => stream.index ?? Number(stream.id.replace("stream-", ""))),
      subtitle: item.streams.filter((stream) => stream.type === "subtitle" && item.selectedStreamIds.includes(stream.id)).map((stream) => stream.index ?? Number(stream.id.replace("stream-", ""))),
      chapters: item.selectedChapterIds.map((id) => Number(id)).filter((id) => Number.isFinite(id)),
      handbrake: item.handbrakeTitleNumber ? {
        titleNumber: item.handbrakeTitleNumber,
        durationSeconds: item.durationSeconds,
        titleSizeBytes: null,
        audioTrackNumbers: item.streams.filter((stream) => stream.type === "audio" && item.selectedStreamIds.includes(stream.id)).map((stream) => stream.handbrakeTrackNumber).filter((value): value is number => typeof value === "number" && value > 0),
        subtitleTrackNumbers: item.streams.filter((stream) => stream.type === "subtitle" && item.selectedStreamIds.includes(stream.id)).map((stream) => stream.handbrakeTrackNumber).filter((value): value is number => typeof value === "number" && value > 0),
        chapterNumbers: item.selectedChapterIds.map((id) => Number(id) + 1).filter((id) => Number.isFinite(id)),
      } : undefined,
      audioStreams: item.streams.filter((stream) => stream.type === "audio" && item.selectedStreamIds.includes(stream.id)).map((stream) => ({ inputIndex: stream.index ?? Number(stream.id.replace("stream-", "")), codecName: stream.codec ?? null })),
    }),
    ...(item.analysisId ? { analysisId: item.analysisId } : {}),
    ...(item.sourceFingerprint ? { sourceFingerprint: item.sourceFingerprint } : {}),
    ...(item.titleId ? { selectedTitleId: item.titleId } : {}),
    outputMode,
  };
}
