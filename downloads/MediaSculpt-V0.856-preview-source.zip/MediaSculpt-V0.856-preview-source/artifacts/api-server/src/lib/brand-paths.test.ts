import { afterEach, describe, expect, it } from "vitest";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { legacyVxAgentDataRoot, mediaSculptDataRoot, migrateLegacyDirectory } from "../../../../lib/db/src/brand-paths";

describe("MediaSculpt runtime paths", () => {
  const temporaryDirectories: string[] = [];

  afterEach(async () => {
    await Promise.all(temporaryDirectories.splice(0).map((directory) => fs.rm(directory, { recursive: true, force: true })));
  });

  it("uses a MediaSculpt Windows data root instead of the legacy product directory", () => {
    expect(mediaSculptDataRoot("win32", "C:\\Users\\tester", "C:\\Users\\tester\\AppData\\Local"))
      .toBe("C:\\Users\\tester\\AppData\\Local\\MediaSculpt");
    expect(legacyVxAgentDataRoot("win32", "C:\\Users\\tester", "C:\\Users\\tester\\AppData\\Local"))
      .toBe("C:\\Users\\tester\\AppData\\Local\\VX-Agent");
    expect(mediaSculptDataRoot("win32", "C:\\Users\\tester")).toBe("C:\\Users\\tester\\AppData\\Local\\MediaSculpt");
    expect(mediaSculptDataRoot("darwin", "/Users/tester")).toBe("/Users/tester/Library/Application Support/MediaSculpt");
  });

  it("copies legacy data and verifies it without deleting the source", async () => {
    const root = await fs.mkdtemp(path.join(os.tmpdir(), "mediasculpt-migration-"));
    temporaryDirectories.push(root);
    const source = path.join(root, "VX-Agent");
    const destination = path.join(root, "MediaSculpt");
    await fs.mkdir(path.join(source, "tools", "ffmpeg"), { recursive: true });
    await fs.writeFile(path.join(source, "vx-agent.db"), "database fixture");
    await fs.writeFile(path.join(source, "tools", "ffmpeg", "ffmpeg.exe"), "tool fixture");

    await expect(migrateLegacyDirectory({ source, destination })).resolves.toEqual({ migrated: true, verified: true, reason: "copied" });
    await expect(fs.readFile(path.join(destination, "vx-agent.db"), "utf8")).resolves.toBe("database fixture");
    await expect(fs.readFile(path.join(source, "vx-agent.db"), "utf8")).resolves.toBe("database fixture");
  });
});
