import {
  PreviewLimitError,
  previewErrorCode,
  type PreviewStatus,
} from "./preview-entitlement";
import {
  createPreviewEntitlementRepository,
  resolveRuntimeEdition,
} from "./preview-entitlement-repository";
import {
  createPreviewJobSettlement,
  type PreviewJobSettlementInput,
} from "./preview-job-settlement";

export const previewRepository = createPreviewEntitlementRepository({
  edition: resolveRuntimeEdition(),
});

const settlePreviewJob = createPreviewJobSettlement(previewRepository);

function blockedMessage(status: PreviewStatus): string {
  switch (status.blockedReason) {
    case "expired": return "预览版有效期已结束";
    case "quota_exhausted": return "预览版成功任务次数已用完";
    case "clock_invalid": return "检测到系统时间回拨，请校准系统时间后重试";
    default: return "预览版暂时不能启动新的完整任务";
  }
}

export async function getPreviewStatus(now = new Date()): Promise<PreviewStatus> {
  return previewRepository.getStatus(now);
}

export async function assertPreviewTaskAllowed(now = new Date()): Promise<void> {
  const status = await getPreviewStatus(now);
  if (!status.isActive && status.blockedReason) {
    throw new PreviewLimitError(previewErrorCode(status.blockedReason), blockedMessage(status), status);
  }
}

export async function settlePreviewTask(input: PreviewJobSettlementInput) {
  return settlePreviewJob(input);
}

export async function recordPreviewAiCall(_kind: string, now = new Date()): Promise<number> {
  return previewRepository.recordAiCall(now);
}
