import { describe, expect, it } from "vitest";
import { readProjectFile } from "./windows-contract-helpers";

describe("V0.840 release metadata", () => {
  it("does not publish MIT as the MediaSculpt product license", () => {
    const license = readProjectFile("LICENSE");
    const packageJson = JSON.parse(readProjectFile("package.json")) as { license?: string };

    expect(license).toContain("MediaSculpt Proprietary Preview License");
    expect(license).not.toMatch(/^MIT License/m);
    expect(packageJson.license).toBe("UNLICENSED");
  });

  it("lists the actual runtime components without a removed disc-tool dependency", () => {
    const notices = readProjectFile("THIRD-PARTY-NOTICES.md");

    expect(notices).toContain("FFmpeg");
    expect(notices).toContain("HandBrakeCLI");
    expect(notices).toContain("Whisper");
    expect(notices).not.toMatch(/MakeMKV|makemkv/i);
  });
});
