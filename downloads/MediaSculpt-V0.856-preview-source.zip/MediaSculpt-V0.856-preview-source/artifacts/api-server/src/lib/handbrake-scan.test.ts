import { describe, expect, it } from "vitest";
import { consolidateDvdHandBrakeTitles, mergeHandBrakeChapters, parseHandBrakeScanOutput, parseHandBrakeScanSummaries } from "./handbrake-scan";

describe("HandBrake scan parsing", () => {
  it("parses every DVD title summary from the text scan when JSON contains only the main title", () => {
    const summaries = parseHandBrakeScanSummaries([
      "scan: DVD has 3 title(s)",
      "scan: duration is 01:00:00 (3600000 ms)",
      "scan: title 1 has 12 chapters",
      "scan: chap 1, 120000 ms",
      "scan: chap 2, 180000 ms",
      "scan: duration is 00:59:58 (3598000 ms)",
      "scan: title 2 has 12 chapters",
      "scan: duration is 01:00:02 (3602000 ms)",
      "scan: title 3 has 12 chapters",
      "JSON Title Set: {\"TitleList\":[{\"Index\":1}]} ",
    ].join("\n"));

    expect(summaries).toEqual([
      { titleNumber: 1, durationSeconds: 3600, chapterCount: 12, chapterDurationsSeconds: [120, 180] },
      { titleNumber: 2, durationSeconds: 3598, chapterCount: 12 },
      { titleNumber: 3, durationSeconds: 3602, chapterCount: 12 },
    ]);
  });

  it("collapses repeated logical titles when duration, chapters, and streams are identical", () => {
    const makeTitle = (titleNumber: number) => ({
      titleNumber,
      durationSeconds: 3600,
      chapters: [
        { id: 0, startSeconds: 0, endSeconds: 1200, title: "Chapter 1" },
        { id: 1, startSeconds: 1200, endSeconds: 2400, title: "Chapter 2" },
        { id: 2, startSeconds: 2400, endSeconds: 3600, title: "Chapter 3" },
      ],
      streams: [
        { index: 0, codecType: "video" as const, codecName: "mpeg2video" },
        { index: 1, codecType: "audio" as const, codecName: "ac3", language: "und", channels: 2, bitrate: 192000 },
      ],
    });

    const result = consolidateDvdHandBrakeTitles([makeTitle(1), makeTitle(2), makeTitle(3)]);

    expect(result.map((title) => title.titleNumber)).toEqual([1]);
  });

  it("keeps independent titles when their chapter layouts differ", () => {
    const makeTitle = (titleNumber: number, chapterDurations: number[]) => ({
      titleNumber,
      durationSeconds: chapterDurations.reduce((sum, duration) => sum + duration, 0),
      chapters: chapterDurations.map((duration, index) => ({
        id: index,
        startSeconds: chapterDurations.slice(0, index).reduce((sum, value) => sum + value, 0),
        endSeconds: chapterDurations.slice(0, index + 1).reduce((sum, value) => sum + value, 0),
      })),
      streams: [
        { index: 0, codecType: "video" as const, codecName: "mpeg2video" },
        { index: 1, codecType: "audio" as const, codecName: "ac3", language: "und", channels: 2, bitrate: 192000 },
      ],
    });

    const result = consolidateDvdHandBrakeTitles([
      makeTitle(1, [1200, 1200, 1200]),
      makeTitle(2, [900, 1500, 1200]),
    ]);

    expect(result.map((title) => title.titleNumber)).toEqual([1, 2]);
  });

  it("keeps different chapter layouts while collapsing repeated records", () => {
    const makeTitle = (titleNumber: number, durations: number[]) => ({
      titleNumber,
      durationSeconds: durations.reduce((sum, duration) => sum + duration, 0),
      chapters: durations.map((duration, index) => ({ id: index, startSeconds: 0, endSeconds: duration, title: `Chapter ${index + 1}` })),
      streams: [
        { index: 0, codecType: "video" as const, codecName: "mpeg2video" },
        { index: 1, codecType: "audio" as const, codecName: "ac3", language: "fra", channels: 2, bitrate: 192000 },
      ],
    });
    const raw = [
      makeTitle(1, [238, 191, 313, 294, 189, 199, 186, 184, 155, 177, 127, 179]),
      makeTitle(2, [238, 191, 313, 294, 189, 199, 186, 184, 155, 177, 127, 179]),
      makeTitle(3, [81, 204, 200, 452, 240, 424, 302, 465, 525, 183, 176, 230, 468, 209, 284, 393]),
      makeTitle(4, [204, 200, 452, 240, 424, 302, 465, 525, 183, 176, 230, 468, 209, 284, 393]),
      makeTitle(5, [45, 501, 366, 402, 312, 436, 418, 451, 63, 451, 426, 241, 320]),
      makeTitle(6, [501, 366, 402, 312, 436, 418, 451, 63, 451, 426, 241, 320]),
    ];
    const notes: string[] = [];
    const result = consolidateDvdHandBrakeTitles(raw, (message) => notes.push(message));
    expect(result.map((title) => title.titleNumber)).toEqual([1, 3, 4, 5, 6]);
    expect(notes[0]).toContain("折叠 1 条重复逻辑播放链");
  });

  it("drops titles without an explicit HandBrake Index instead of inventing index + 1", () => {
    const output = `JSON Title Set: ${JSON.stringify({ TitleList: [{ Duration: { Hours: 0, Minutes: 1, Seconds: 0 }, ChapterList: [] }] })}`;
    expect(parseHandBrakeScanOutput(output)).toEqual([]);
  });

  it("parses JSON title set chapters from HandBrakeCLI scan output", () => {
    const output = [
      "scan: DVD has 2 title(s)",
      "JSON Title Set:",
      JSON.stringify({
        TitleList: [
          {
            Index: 1,
            Duration: { Hours: 1, Minutes: 30, Seconds: 0 },
            ChapterList: [
              { Name: "Chapter 1", Duration: { Hours: 0, Minutes: 10, Seconds: 0 } },
              { Name: "Chapter 2", Duration: { Hours: 0, Minutes: 5, Seconds: 30 } },
            ],
          },
        ],
      }),
    ].join("\n");

    const titles = parseHandBrakeScanOutput(output);

    expect(titles).toEqual([
      expect.objectContaining({
        titleNumber: 1,
        durationSeconds: 5400,
        chapters: [
          { id: 0, startSeconds: 0, endSeconds: 600, title: "Chapter 1" },
          { id: 1, startSeconds: 600, endSeconds: 930, title: "Chapter 2" },
        ],
      }),
    ]);
  });

  it("parses HandBrake video, audio, subtitle, language, and track numbers for professional disc compression choices", () => {
    const output = [
      "scan: DVD has 1 title(s)",
      "JSON Title Set:",
      JSON.stringify({
        TitleList: [
          {
            Index: 3,
            Duration: { Hours: 2, Minutes: 1, Seconds: 9 },
            Geometry: { Width: 720, Height: 480, PAR: { Num: 8, Den: 9 } },
            FrameRate: { Num: 30000, Den: 1001 },
            VideoCodec: "mpeg2video",
            AudioList: [
              { TrackNumber: 1, CodecName: "AC3", Language: "English", LanguageCode: "eng", ChannelLayout: "5.1(side)", SampleRate: 48000 },
              { TrackNumber: 2, CodecName: "AC3", Language: "Chinese", LanguageCode: "zho", ChannelLayout: "stereo", SampleRate: 48000 },
            ],
            SubtitleList: [
              { TrackNumber: 1, Format: "VOBSUB", Language: "English", LanguageCode: "eng" },
              { TrackNumber: 2, Format: "VOBSUB", Language: "Chinese", LanguageCode: "zho" },
            ],
            ChapterList: [
              { Name: "Opening", Duration: { Hours: 0, Minutes: 5, Seconds: 0 } },
            ],
          },
        ],
      }),
    ].join("\n");

    const [title] = parseHandBrakeScanOutput(output);

    expect(title.streams).toEqual([
      {
        index: 0,
        codecType: "video",
        codecName: "mpeg2video",
        width: 720,
        height: 480,
        frameRate: "30000/1001",
        handbrakeTrackNumber: 0,
      },
      {
        index: 1,
        codecType: "audio",
        codecName: "AC3",
        language: "eng",
        title: "English",
        channels: 6,
        channelLayout: "5.1(side)",
        sampleRate: 48000,
        handbrakeTrackNumber: 1,
      },
      {
        index: 2,
        codecType: "audio",
        codecName: "AC3",
        language: "zho",
        title: "Chinese",
        channels: 2,
        channelLayout: "stereo",
        sampleRate: 48000,
        handbrakeTrackNumber: 2,
      },
      {
        index: 3,
        codecType: "subtitle",
        codecName: "VOBSUB",
        language: "eng",
        title: "English",
        handbrakeTrackNumber: 1,
      },
      {
        index: 4,
        codecType: "subtitle",
        codecName: "VOBSUB",
        language: "zho",
        title: "Chinese",
        handbrakeTrackNumber: 2,
      },
    ]);
  });

  it("preserves HandBrake audio bitrate so the UI can estimate stream size", () => {
    const output = `JSON Title Set: ${JSON.stringify({ TitleList: [{ Index: 1, Duration: { Hours: 0, Minutes: 10, Seconds: 0 }, AudioList: [{ TrackNumber: 1, CodecName: "AC3", BitRate: 192000 }] }] })}`;
    const [title] = parseHandBrakeScanOutput(output);
    expect(title.streams.find((stream) => stream.codecType === "audio")).toMatchObject({ bitrate: 192000 });
  });

  it("merges HandBrake chapters into MakeMKV tracks by title number first", () => {
    const tracks = [
      { handbrakeTitleNumber: 1, chapters: [] as unknown[], name: "Title 1" },
      { handbrakeTitleNumber: 2, chapters: [] as unknown[], name: "Title 2" },
    ];
    const merged = mergeHandBrakeChapters(tracks, [
      { titleNumber: 2, durationSeconds: 120, streams: [], chapters: [{ id: 0, startSeconds: 0, endSeconds: 120, title: "Only" }] },
    ]);

    expect(merged[1].chapters).toEqual([{ id: 0, startSeconds: 0, endSeconds: 120, title: "Only" }]);
    expect(merged[0].chapters).toEqual([]);
  });

  it("does not infer a MakeMKV-to-HandBrake title mapping from duration alone", () => {
    const tracks = [
      { titleNumber: 1, durationSeconds: 6000, chapters: [] as unknown[], streams: [] as unknown[], name: "MakeMKV title 0" },
      { titleNumber: 2, durationSeconds: 1800, chapters: [] as unknown[], streams: [] as unknown[], name: "MakeMKV title 1" },
    ];

    const merged = mergeHandBrakeChapters(tracks, [
      { titleNumber: 1, durationSeconds: 1800, streams: [{ index: 0, codecType: "video", codecName: "mpeg2video", handbrakeTrackNumber: 0 }], chapters: [{ id: 0, startSeconds: 0, endSeconds: 1800, title: "Short" }] },
      { titleNumber: 7, durationSeconds: 6000, streams: [{ index: 0, codecType: "video", codecName: "mpeg2video", handbrakeTrackNumber: 0 }], chapters: [{ id: 0, startSeconds: 0, endSeconds: 6000, title: "Feature" }] },
    ]);

    expect(merged[0]).toEqual(expect.objectContaining({
      titleNumber: 1,
      chapters: [],
    }));
    expect(merged[0]).not.toHaveProperty("handbrakeTitleNumber");
    expect(merged[1]).toEqual(expect.objectContaining({
      titleNumber: 2,
      chapters: [],
    }));
    expect(merged[1]).not.toHaveProperty("handbrakeTitleNumber");
  });
});
