import { createHash } from "node:crypto";
import path from "node:path";
import type { DiscAnalysisResult, UnifiedDiscTitle } from "./disc-analysis";
import { buildCompressionOutputName, buildRemuxOutputName, cleanSegment, encoderBitDepth, selectBestAudioTrack } from "./output-naming";
import { dvdOutputBaseName } from "./dvd-source-identity";

export type TaskSnapshotOutputMode = "compress" | "remux" | "both" | "subtitle" | "whisper" | "audio";
export type CompressionSourceStrategy = "auto" | "direct-disc" | "remux-output" | "temporary-remux";
export type TaskSnapshotSourceType = "video" | "dvd" | "bluray" | "iso";
export type TaskSnapshotSubtitleInput = "original-title" | "remux-output" | "compression-output" | "media-file";

export type TaskSnapshotToolSelections = {
  handbrakeTitleNumber: number | null;
  makemkvTitleIndex: number | null;
  playlistId?: string | null;
  dvdVtsNumber: number | null;
  /** Physical VTS payload group; distinct from the logical dvdvideo title. */
  physicalVtsNumber?: number | null;
  remuxExportCandidateIndex: number | null;
};

export type TaskSnapshotStreamSelection = {
  videoTrackIds: string[];
  audioTrackIds: string[];
  subtitleTrackIds: string[];
};

export type TaskSnapshotChapterSelection = {
  mode: "all" | "range" | "selected";
  start: number | null;
  end: number | null;
  chapterIds: string[];
};

export type TaskSnapshotRemux = {
  container: "mkv" | "mp4";
};

export type TaskSnapshotCompression = {
  encoder: string;
  crf: number;
  resolution: string;
  preset: string;
  /** Frozen encoder tuning; optional for snapshots created before V0.842. */
  encoderTune?: string;
  encoderProfile?: string;
  encoderLevel?: string;
  audioCopy: boolean;
  frameRate: string;
  outputFormat: string;
  deinterlace: boolean;
};

export type TaskSnapshotWhisper = {
  inputSource: TaskSnapshotSubtitleInput;
  language: string | null;
  model: string;
};

export type TaskSnapshotOutput = {
  directory: string;
  fileName: string;
  format: string;
  subtitleDirectory: string | null;
};

export type TaskSnapshotToolVersions = {
  handbrake: string | null;
  makemkv: string | null;
  ffmpeg: string | null;
  whisper: string | null;
  configVersion: string;
};

export type TaskSnapshotV1 = {
  snapshotVersion: 1;
  analysisId: string;
  sourcePath: string;
  sourceFingerprint: string;
  sourceType: TaskSnapshotSourceType;
  selectedTitleId: string;
  /** Identifier of the deterministic DVD smart-analysis decision, when used. */
  smartManifestId?: string | null;
  outputMode: TaskSnapshotOutputMode;
  /** Frozen source policy for DVD compression; auto is resolved at creation time. */
  compressionSourceStrategy?: CompressionSourceStrategy;
  toolSelections: TaskSnapshotToolSelections;
  streamSelection: TaskSnapshotStreamSelection;
  chapterSelection: TaskSnapshotChapterSelection;
  remux: TaskSnapshotRemux;
  compression: TaskSnapshotCompression;
  whisper: TaskSnapshotWhisper;
  output: TaskSnapshotOutput;
  toolVersions: TaskSnapshotToolVersions;
  createdAt: string;
};

export type TaskSnapshotSettings = {
  encoder: string;
  crf: number;
  outputResolution: string;
  encoderPreset: string;
  encoderTune?: string | null;
  encoderProfile?: string | null;
  encoderLevel?: string | null;
  audioCopy: boolean;
  outputDirectory: string;
  /** Remux-only output directory; __source__ means the disc's containing directory. */
  remuxOutputDirectory?: string | null;
  subtitleDirectory?: string | null;
  whisperModel: string;
  subtitleLanguage: string;
  outputFormat: string;
  frameRate?: string | null;
  deinterlace?: boolean | null;
};

export type CreateTaskSnapshotInput = {
  analysis: DiscAnalysisResult | null | undefined;
  analysisId: string;
  selectedTitleId: string;
  smartManifestId?: string | null;
  outputMode: TaskSnapshotOutputMode;
  compressionSourceStrategy?: CompressionSourceStrategy;
  remuxExportCandidateIndex?: number | null;
  physicalVtsNumber?: number | null;
  streamSelection: TaskSnapshotStreamSelection;
  chapterSelection: Partial<TaskSnapshotChapterSelection> & Pick<TaskSnapshotChapterSelection, "mode">;
  settings: TaskSnapshotSettings;
  remux?: Partial<TaskSnapshotRemux>;
  whisper?: Partial<TaskSnapshotWhisper>;
  output: Pick<TaskSnapshotOutput, "directory" | "fileName"> & Partial<TaskSnapshotOutput>;
  toolVersions?: Partial<Omit<TaskSnapshotToolVersions, "configVersion">>;
  createdAt?: string;
};

export type TaskSnapshotJobCreationRequest = {
  analysisId: string;
  sourcePath: string;
  sourceFingerprint: string;
  selectedTitleId: string;
  smartManifestId?: string | null;
  outputMode: TaskSnapshotOutputMode;
  remuxExportCandidateIndex?: number | null;
  selectedStreamIndexes?: number[] | null;
  selectedChapterIds?: number[] | null;
  chapterRange?: { start: number; end: number } | null;
  /** Optional user-confirmed name from the smart workflow; legacy callers omit it. */
  outputFileName?: string | null;
  /** Persist the exact physical VTS group alongside the logical DVD title. */
  physicalVtsNumber?: number | null;
  /**
   * 复杂光碟由 LLM 校验后的流选择（仅同标题时生效，用于 remux 精确选流）。
   * 其中的数字是该标题内的绝对流 index，只引用真实存在的流。
   */
  llmRemuxPlan?: { videoIndex: number; audioIndices: number[]; subtitleIndices: number[]; reason?: string } | null;
};

export class DiscAnalysisRegistry {
  private readonly analyses = new Map<string, { analysis: DiscAnalysisResult; rememberedAtMs: number }>();

  constructor(
    private readonly maxAgeMs = 5 * 60_000,
    private readonly now: () => number = () => Date.now(),
  ) {}

  remember(analysis: DiscAnalysisResult): void {
    this.analyses.set(analysis.analysisId, { analysis, rememberedAtMs: this.now() });
  }

  find(analysisId: string): DiscAnalysisResult | null {
    const entry = this.analyses.get(analysisId);
    if (!entry) return null;
    if (this.now() - entry.rememberedAtMs > this.maxAgeMs) {
      this.analyses.delete(analysisId);
      return null;
    }
    return entry.analysis;
  }

  clear(): void {
    this.analyses.clear();
  }
}

export class TaskSnapshotError extends Error {
  constructor(public readonly code:
    | "TASK_SNAPSHOT_ANALYSIS_NOT_FOUND"
    | "TASK_SNAPSHOT_TITLE_NOT_FOUND"
    | "TASK_SNAPSHOT_TITLE_UNAVAILABLE"
    | "TASK_SNAPSHOT_HANDBRAKE_TITLE_REQUIRED"
    | "TASK_SNAPSHOT_REMUX_TITLE_REQUIRED"
    | "TASK_SNAPSHOT_INVALID"
    | "TASK_SNAPSHOT_UNSUPPORTED_VERSION"
    | "TASK_SNAPSHOT_MISSING",
  ) {
    super(code);
    this.name = "TaskSnapshotError";
  }
}

export function deepFreeze<T>(value: T): T {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const nested of Object.values(value as Record<string, unknown>)) deepFreeze(nested);
  }
  return value;
}

function cloneStrings(value: string[] | undefined): string[] {
  return Array.isArray(value) ? [...value] : [];
}

export function configVersion(settings: TaskSnapshotSettings): string {
  const normalized = JSON.stringify({
    encoder: settings.encoder,
    crf: settings.crf,
    outputResolution: settings.outputResolution,
    encoderPreset: settings.encoderPreset,
    encoderTune: settings.encoderTune ?? "none",
    encoderProfile: settings.encoderProfile ?? "auto",
    encoderLevel: settings.encoderLevel ?? "auto",
    audioCopy: settings.audioCopy,
    outputDirectory: settings.outputDirectory,
    remuxOutputDirectory: settings.remuxOutputDirectory ?? null,
    subtitleDirectory: settings.subtitleDirectory ?? null,
    whisperModel: settings.whisperModel,
    subtitleLanguage: settings.subtitleLanguage,
    outputFormat: settings.outputFormat,
    frameRate: settings.frameRate ?? "same",
    deinterlace: settings.deinterlace ?? false,
  });
  return `config-${createHash("sha256").update(normalized).digest("hex").slice(0, 16)}`;
}

function selectedTitleFrom(input: CreateTaskSnapshotInput): UnifiedDiscTitle {
  if (!input.analysis || input.analysis.analysisId !== input.analysisId) {
    throw new TaskSnapshotError("TASK_SNAPSHOT_ANALYSIS_NOT_FOUND");
  }
  const title = input.analysis.titles.find((candidate) => candidate.titleId === input.selectedTitleId);
  if (!title) throw new TaskSnapshotError("TASK_SNAPSHOT_TITLE_NOT_FOUND");
  if (input.analysis.mediaType === "dvd" && title.availabilityStatus === "unavailable") {
    throw new TaskSnapshotError("TASK_SNAPSHOT_TITLE_UNAVAILABLE");
  }
  return title;
}

function compressionSourceStrategyFor(input: CreateTaskSnapshotInput, title: UnifiedDiscTitle): CompressionSourceStrategy {
  if (input.outputMode !== "compress" && input.outputMode !== "both") return "auto";
  if (input.compressionSourceStrategy && input.compressionSourceStrategy !== "auto") return input.compressionSourceStrategy;
  const warnings = title.verificationWarnings ?? [];
  return input.analysis?.mediaType === "dvd" && warnings.length > 0 ? "temporary-remux" : "direct-disc";
}

function explicitRemuxCandidate(input: CreateTaskSnapshotInput): number | null {
  if (typeof input.remuxExportCandidateIndex !== "number") return null;
  const candidate = input.analysis?.exportCandidates.find(
    (item) => item.makemkvTitleIndex === input.remuxExportCandidateIndex,
  );
  if (!candidate) throw new TaskSnapshotError("TASK_SNAPSHOT_REMUX_TITLE_REQUIRED");
  return candidate.makemkvTitleIndex;
}

function resolveToolSelections(input: CreateTaskSnapshotInput, title: UnifiedDiscTitle): TaskSnapshotToolSelections {
  const handbrakeTitleNumber = title.toolMappings.handbrakeTitleNumber;
  const explicitCandidate = explicitRemuxCandidate(input);
  const makemkvTitleIndex = explicitCandidate ?? title.toolMappings.makemkvTitleIndex;
  const playlistId = title.toolMappings.playlistId;
  const needsHandBrake = input.outputMode === "compress" || input.outputMode === "both";
  const needsRemuxTitle = input.outputMode === "remux" || input.outputMode === "both";
  const needsVerifiedDvdTitle = input.analysis?.mediaType === "dvd" && needsRemuxTitle;
  // Playlist-less Blu-ray titles (m2ts fallback) are remuxed directly from their
  // BDMV/STREAM file, so they do not require an mpls playlist mapping.
  const isM2tsFallbackTitle = /^m2ts:\d+$/.test(title.titleId);
  const needsBlurayPlaylist = needsRemuxTitle && input.analysis?.mediaType !== "dvd" && !isM2tsFallbackTitle;

  if (needsHandBrake && (typeof handbrakeTitleNumber !== "number" || handbrakeTitleNumber <= 0)) {
    throw new TaskSnapshotError("TASK_SNAPSHOT_HANDBRAKE_TITLE_REQUIRED");
  }
  if (needsBlurayPlaylist && !playlistId) {
    throw new TaskSnapshotError("TASK_SNAPSHOT_REMUX_TITLE_REQUIRED");
  }
  if (needsVerifiedDvdTitle && (
    title.verificationStatus !== "verified"
    || typeof title.toolMappings.dvdVtsNumber !== "number"
    || title.toolMappings.dvdVtsNumber <= 0
  )) {
    throw new TaskSnapshotError("TASK_SNAPSHOT_REMUX_TITLE_REQUIRED");
  }
  return {
    handbrakeTitleNumber: typeof handbrakeTitleNumber === "number" ? handbrakeTitleNumber : null,
    makemkvTitleIndex: typeof makemkvTitleIndex === "number" ? makemkvTitleIndex : null,
    playlistId: typeof playlistId === "string" ? playlistId : null,
    dvdVtsNumber: typeof title.toolMappings.dvdVtsNumber === "number" ? title.toolMappings.dvdVtsNumber : null,
    physicalVtsNumber: typeof input.physicalVtsNumber === "number"
      ? input.physicalVtsNumber
      : typeof title.toolMappings.physicalVtsNumber === "number"
        ? title.toolMappings.physicalVtsNumber
        : null,
    remuxExportCandidateIndex: explicitCandidate,
  };
}

function llmRemuxPlanFitsTitle(plan: NonNullable<TaskSnapshotJobCreationRequest["llmRemuxPlan"]>, title: UnifiedDiscTitle): boolean {
  const inVideo = (title.videoTracks ?? []).some((s) => s.index === plan.videoIndex);
  const inAudio = (plan.audioIndices ?? []).every((i) => (title.audioTracks ?? []).some((s) => s.index === i));
  const inSubtitle = (plan.subtitleIndices ?? []).every((i) => (title.subtitleTracks ?? []).some((s) => s.index === i));
  return inVideo && inAudio && inSubtitle;
}

function streamIdsForSelection(
  title: UnifiedDiscTitle,
  selected: number[] | null | undefined,
  requireVideo = false,
): TaskSnapshotStreamSelection {
  const realIndexes = [...new Set(title.streams.map((stream) => stream.index))];
  let selectedSet = selected === null || selected === undefined
    ? new Set(realIndexes)
    : new Set(selected);
  // Result-oriented reconciliation: HandBrake and ffprobe dvdvideo can report
  // different stream structures for the SAME disc title (audio/subtitle counts).
  // Never fail on that — map the user's selection onto the REAL disc streams:
  // keep selected indices that exist here; if the selection is empty or most of
  // it doesn't line up with the real streams, fall back to all real streams
  // (remux copies everything losslessly anyway).
  const clean = [...selectedSet].filter((index) => realIndexes.includes(index));
  if (clean.length === 0 || clean.length !== selectedSet.size) {
    selectedSet = new Set(realIndexes);
  } else {
    selectedSet = new Set(clean);
  }
  // A DVD Remux without video is never executable. Older UI versions could
  // carry an audio-only selection from subtitle mode into the Remux dialog;
  // retain the user's audio/subtitle choices but always restore the real video
  // stream before freezing the task snapshot.
  if (requireVideo && !title.streams.some((stream) => stream.codecType === "video" && selectedSet.has(stream.index))) {
    for (const stream of title.streams) {
      if (stream.codecType === "video") selectedSet.add(stream.index);
    }
  }
  const toIds = (type: "video" | "audio" | "subtitle") => title.streams
    .filter((stream) => stream.codecType === type && selectedSet.has(stream.index))
    .map((stream) => `stream:${stream.index}`);
  return { videoTrackIds: toIds("video"), audioTrackIds: toIds("audio"), subtitleTrackIds: toIds("subtitle") };
}

function reconcileFrozenStreamSelection(
  title: UnifiedDiscTitle,
  selection: TaskSnapshotStreamSelection,
  requireVideo: boolean,
): TaskSnapshotStreamSelection {
  const selectedIndexes = [
    ...selection.videoTrackIds,
    ...selection.audioTrackIds,
    ...selection.subtitleTrackIds,
  ]
    .map((id) => /^stream:(\d+)$/.exec(id)?.[1])
    .filter((value): value is string => Boolean(value))
    .map(Number);

  // Older task snapshots can retain an audio-only Remux selection. Rebuild the
  // typed selection from the verified title so the real video stream is always
  // present before the snapshot becomes immutable.
  if (requireVideo) return streamIdsForSelection(title, selectedIndexes, true);
  return {
    videoTrackIds: cloneStrings(selection.videoTrackIds),
    audioTrackIds: cloneStrings(selection.audioTrackIds),
    subtitleTrackIds: cloneStrings(selection.subtitleTrackIds),
  };
}

function chapterSelectionFor(title: UnifiedDiscTitle, request: TaskSnapshotJobCreationRequest): TaskSnapshotChapterSelection {
  if (request.chapterRange) {
    if (!Number.isInteger(request.chapterRange.start) || !Number.isInteger(request.chapterRange.end)
      || request.chapterRange.start < 1 || request.chapterRange.end < request.chapterRange.start) {
      throw new TaskSnapshotError("TASK_SNAPSHOT_INVALID");
    }
    return { mode: "range", start: request.chapterRange.start, end: request.chapterRange.end, chapterIds: [] };
  }
  if (request.selectedChapterIds === null || request.selectedChapterIds === undefined) {
    return { mode: "all", start: null, end: null, chapterIds: title.chapters.map((chapter) => `chapter:${chapter.id}`) };
  }
  const ids = new Set(request.selectedChapterIds);
  // Result-oriented reconciliation: the analyzed view and the verified
  // (ffprobe dvdvideo) view can number chapters differently. If the user's
  // selection doesn't line up, select all REAL chapters instead of failing.
  const matched = title.chapters.filter((chapter) => ids.has(chapter.id));
  if (matched.length === 0 || matched.length !== ids.size) {
    return { mode: "all", start: null, end: null, chapterIds: title.chapters.map((chapter) => `chapter:${chapter.id}`) };
  }
  return { mode: "selected", start: null, end: null, chapterIds: matched.map((chapter) => `chapter:${chapter.id}`) };
}

function baseNameForSource(sourcePath: string): string {
  const api = /^[A-Za-z]:[\\/]/.test(sourcePath) || sourcePath.includes("\\") ? path.win32 : path;
  const base = api.basename(sourcePath.replace(/[\\/]+$/, ""));
  return /^(VIDEO_TS|BDMV)$/i.test(base) ? api.basename(api.dirname(sourcePath)) : base;
}

function outputFileName(input: { sourcePath: string; analysis: DiscAnalysisResult; title: UnifiedDiscTitle; mode: TaskSnapshotOutputMode; settings: TaskSnapshotSettings; selectedAudioTrackIds: string[] }): string {
  const baseName = input.analysis.mediaType === "dvd"
    ? dvdOutputBaseName({
      sourcePath: input.sourcePath,
      mediaType: "dvd",
      titleNumber: input.title.toolMappings.handbrakeTitleNumber ?? input.title.toolMappings.dvdVtsNumber,
      titleCount: input.analysis.titles.length,
    })
    : baseNameForSource(input.sourcePath);
  if (input.mode === "remux") {
    const blurayHandbrakeNumber = input.title.toolMappings.handbrakeTitleNumber;
    const blurayTitleSuffix = input.analysis.mediaType === "bluray" && typeof blurayHandbrakeNumber === "number" && blurayHandbrakeNumber > 0
      ? `.Title${String(blurayHandbrakeNumber).padStart(2, "0")}`
      : input.analysis.mediaType === "bluray" && input.title.titleIndex > 0
        ? `.Title${String(input.title.titleIndex + 1).padStart(2, "0")}`
        : "";
    const remuxBaseName = input.analysis.mediaType === "bluray"
        ? `${baseName}${blurayTitleSuffix}`
      : baseName;
    return buildRemuxOutputName(remuxBaseName, input.analysis.mediaType, input.analysis.mediaType === "dvd" ? "mkv" : input.settings.outputFormat);
  }
  if (input.mode === "subtitle" || input.mode === "whisper") return `${cleanSegment(baseName)}.MediaSculpt.srt`;
  if (input.mode === "audio") return `${cleanSegment(baseName)}.mka`;
  const selectedAudioTracks = input.selectedAudioTrackIds.length > 0
    ? input.title.audioTracks.filter((track) => input.selectedAudioTrackIds.includes(`stream:${track.index}`))
    : input.title.audioTracks;
  const selectedAudio = selectBestAudioTrack(selectedAudioTracks);
  const compressionBaseName = input.analysis.mediaType === "bluray" && input.title.titleIndex > 0
      ? `${baseName}.Title${String(input.title.titleIndex + 1).padStart(2, "0")}`
    : baseName;
  return buildCompressionOutputName({
    baseName: compressionBaseName,
    mediaType: input.analysis.mediaType,
    outputFormat: input.settings.outputFormat,
    encoder: input.settings.encoder,
    crf: input.settings.crf,
    primaryAudioCodec: selectedAudio?.codec ?? null,
    height: input.title.videoTracks[0]?.height ?? null,
    bitDepth: encoderBitDepth(input.settings.encoder) ?? input.title.videoTracks[0]?.bitsPerRawSample ?? null,
  });
}

export function prepareTaskSnapshotForJobCreation(input: {
  registry: DiscAnalysisRegistry;
  request: TaskSnapshotJobCreationRequest;
  settings: TaskSnapshotSettings;
  createdAt?: string;
  toolVersions?: Partial<Omit<TaskSnapshotToolVersions, "configVersion">>;
}): { request: TaskSnapshotJobCreationRequest; snapshot: TaskSnapshotV1 } {
  const analysis = input.registry.find(input.request.analysisId);
  if (!analysis) throw new TaskSnapshotError("TASK_SNAPSHOT_ANALYSIS_NOT_FOUND");
  if (analysis.sourceFingerprint !== input.request.sourceFingerprint || analysis.sourcePath !== input.request.sourcePath) {
    throw new TaskSnapshotError("TASK_SNAPSHOT_ANALYSIS_NOT_FOUND");
  }
  const title = analysis.titles.find((candidate) => candidate.titleId === input.request.selectedTitleId);
  if (!title) throw new TaskSnapshotError("TASK_SNAPSHOT_TITLE_NOT_FOUND");
  // 复杂光碟：LLM 已校验的流选择优先于用户选择（仅限同一标题），让 remux 依真实/正确流精确选流。
  const effectiveStreamIndexes = input.request.llmRemuxPlan && llmRemuxPlanFitsTitle(input.request.llmRemuxPlan, title)
    ? [input.request.llmRemuxPlan.videoIndex, ...input.request.llmRemuxPlan.audioIndices, ...input.request.llmRemuxPlan.subtitleIndices]
    : input.request.selectedStreamIndexes;
  const streamSelection = streamIdsForSelection(
    title,
    effectiveStreamIndexes,
    input.request.outputMode === "remux" || input.request.outputMode === "both",
  );
  const chapterSelection = chapterSelectionFor(title, input.request);
  const output = {
    directory: input.request.outputMode === "remux"
      ? (input.settings.remuxOutputDirectory ?? input.settings.outputDirectory)
      : input.settings.outputDirectory,
    fileName: input.request.outputFileName?.trim() || outputFileName({
        sourcePath: input.request.sourcePath,
        analysis,
        title,
        mode: input.request.outputMode,
        settings: input.settings,
        selectedAudioTrackIds: streamSelection.audioTrackIds,
      }),
  };
  return {
    request: { ...input.request, selectedStreamIndexes: input.request.selectedStreamIndexes ? [...input.request.selectedStreamIndexes] : input.request.selectedStreamIndexes, selectedChapterIds: input.request.selectedChapterIds ? [...input.request.selectedChapterIds] : input.request.selectedChapterIds },
    snapshot: createTaskSnapshotV1({
      analysis,
      analysisId: input.request.analysisId,
      selectedTitleId: input.request.selectedTitleId,
      outputMode: input.request.outputMode,
      remuxExportCandidateIndex: input.request.remuxExportCandidateIndex,
      physicalVtsNumber: input.request.physicalVtsNumber,
      streamSelection,
      chapterSelection,
      settings: input.settings,
      output,
      toolVersions: input.toolVersions,
      createdAt: input.createdAt,
    }),
  };
}

export function createStandaloneTaskSnapshotV1(input: {
  sourcePath: string;
  sourceType: "video" | "iso";
  outputMode: Exclude<TaskSnapshotOutputMode, "both">;
  selectedStreamIndexes?: number[] | null;
  selectedChapterIds?: number[] | null;
  settings: TaskSnapshotSettings;
  createdAt?: string;
  toolVersions?: Partial<Omit<TaskSnapshotToolVersions, "configVersion">>;
  outputFileName?: string | null;
}): TaskSnapshotV1 {
  const streamIndexes = input.selectedStreamIndexes === null || input.selectedStreamIndexes === undefined
    ? []
    : [...new Set(input.selectedStreamIndexes)].sort((a, b) => a - b);
  const chapterIds = input.selectedChapterIds === null || input.selectedChapterIds === undefined
    ? []
    : [...new Set(input.selectedChapterIds)].sort((a, b) => a - b);
  if (streamIndexes.some((index) => !Number.isInteger(index) || index < 0)
    || chapterIds.some((id) => !Number.isInteger(id) || id < 0)) {
    throw new TaskSnapshotError("TASK_SNAPSHOT_INVALID");
  }
  const fingerprint = createHash("sha256").update(`${input.sourceType}\n${input.sourcePath}`).digest("hex");
  const baseName = baseNameForSource(input.sourcePath);
  const output = input.outputFileName?.trim() || (input.outputMode === "audio"
    ? `${baseName}.mka`
    : input.outputMode === "remux"
    ? buildRemuxOutputName(baseName, input.sourceType, input.settings.outputFormat)
    : input.outputMode === "subtitle" || input.outputMode === "whisper"
      ? `${baseName}.MediaSculpt.srt`
      : buildCompressionOutputName({
        baseName,
        mediaType: input.sourceType,
        outputFormat: input.settings.outputFormat,
        encoder: input.settings.encoder,
        crf: input.settings.crf,
        primaryAudioCodec: null,
        bitDepth: encoderBitDepth(input.settings.encoder),
      }));
  return deepFreeze({
    snapshotVersion: 1,
    analysisId: `media-${fingerprint.slice(0, 24)}`,
    sourcePath: input.sourcePath,
    sourceFingerprint: fingerprint,
    sourceType: input.sourceType,
    selectedTitleId: "media:source",
    outputMode: input.outputMode,
    compressionSourceStrategy: input.outputMode === "compress" ? "auto" : undefined,
    toolSelections: { handbrakeTitleNumber: null, makemkvTitleIndex: null, dvdVtsNumber: null, remuxExportCandidateIndex: null },
    // A direct file has no analysis-time codec classification. Preserve exactly the user-selected indices.
    streamSelection: { videoTrackIds: streamIndexes.map((index) => `stream:${index}`), audioTrackIds: [], subtitleTrackIds: [] },
    chapterSelection: { mode: chapterIds.length > 0 ? "selected" : "all", start: null, end: null, chapterIds: chapterIds.map((id) => `chapter:${id}`) },
    remux: { container: "mkv" },
    compression: {
      encoder: input.settings.encoder,
      crf: input.settings.crf,
      resolution: input.settings.outputResolution,
      preset: input.settings.encoderPreset,
      encoderTune: input.settings.encoderTune ?? undefined,
      encoderProfile: input.settings.encoderProfile ?? undefined,
      encoderLevel: input.settings.encoderLevel ?? undefined,
      audioCopy: input.settings.audioCopy,
      frameRate: input.settings.frameRate ?? "same",
      outputFormat: input.settings.outputFormat,
      deinterlace: input.settings.deinterlace ?? false,
    },
    whisper: { inputSource: "media-file", language: input.settings.subtitleLanguage ?? null, model: input.settings.whisperModel },
    output: {
      directory: input.outputMode === "remux"
        ? (input.settings.remuxOutputDirectory ?? input.settings.outputDirectory)
        : input.settings.outputDirectory,
      fileName: output,
      format: input.settings.outputFormat,
      subtitleDirectory: input.settings.subtitleDirectory ?? null,
    },
    toolVersions: {
      handbrake: input.toolVersions?.handbrake ?? null,
      makemkv: input.toolVersions?.makemkv ?? null,
      ffmpeg: input.toolVersions?.ffmpeg ?? null,
      whisper: input.toolVersions?.whisper ?? null,
      configVersion: configVersion(input.settings),
    },
    createdAt: input.createdAt ?? new Date().toISOString(),
  });
}

export function createTaskSnapshotV1(input: CreateTaskSnapshotInput): TaskSnapshotV1 {
  const title = selectedTitleFrom(input);
  const toolSelections = resolveToolSelections(input, title);
  const settings = input.settings;
  const streamSelection = reconcileFrozenStreamSelection(
    title,
    input.streamSelection,
    input.outputMode === "remux" || input.outputMode === "both",
  );
  const snapshot: TaskSnapshotV1 = {
    snapshotVersion: 1,
    analysisId: input.analysisId,
    sourcePath: input.analysis!.sourcePath,
    sourceFingerprint: input.analysis!.sourceFingerprint,
    sourceType: input.analysis!.mediaType,
    selectedTitleId: title.titleId,
    smartManifestId: input.smartManifestId ?? null,
    outputMode: input.outputMode,
    compressionSourceStrategy: compressionSourceStrategyFor(input, title),
    toolSelections,
    streamSelection,
    chapterSelection: {
      mode: input.chapterSelection.mode,
      start: input.chapterSelection.start ?? null,
      end: input.chapterSelection.end ?? null,
      chapterIds: cloneStrings(input.chapterSelection.chapterIds),
    },
    remux: { container: input.remux?.container ?? "mkv" },
    compression: {
      encoder: settings.encoder,
      crf: settings.crf,
      resolution: settings.outputResolution,
      preset: settings.encoderPreset,
      encoderTune: settings.encoderTune ?? undefined,
      encoderProfile: settings.encoderProfile ?? undefined,
      encoderLevel: settings.encoderLevel ?? undefined,
      audioCopy: settings.audioCopy,
      frameRate: settings.frameRate ?? "same",
      outputFormat: settings.outputFormat,
      deinterlace: settings.deinterlace ?? false,
    },
    whisper: {
      inputSource: input.whisper?.inputSource ?? "original-title",
      language: input.whisper?.language ?? settings.subtitleLanguage ?? null,
      model: input.whisper?.model ?? settings.whisperModel,
    },
    output: {
      directory: input.output.directory,
      fileName: input.output.fileName,
      format: input.output.format ?? settings.outputFormat,
      subtitleDirectory: input.output.subtitleDirectory ?? settings.subtitleDirectory ?? null,
    },
    toolVersions: {
      handbrake: input.toolVersions?.handbrake ?? null,
      makemkv: input.toolVersions?.makemkv ?? null,
      ffmpeg: input.toolVersions?.ffmpeg ?? null,
      whisper: input.toolVersions?.whisper ?? null,
      configVersion: configVersion(settings),
    },
    createdAt: input.createdAt ?? new Date().toISOString(),
  };
  return deepFreeze(snapshot);
}

import { serializeTaskSnapshot, parseTaskSnapshot, loadTaskSnapshot, taskSnapshotSummary } from "./task-snapshot-codec";
export { serializeTaskSnapshot, parseTaskSnapshot, loadTaskSnapshot, taskSnapshotSummary } from "./task-snapshot-codec";
