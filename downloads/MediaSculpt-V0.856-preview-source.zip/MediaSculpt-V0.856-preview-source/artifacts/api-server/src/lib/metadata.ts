import path from "path";
import { db, imdbTitlesTable, configTable } from "@workspace/db";
import { and, or, between, desc, eq, sql } from "drizzle-orm";
import { fetchLike, resolvePosterProxyUrl } from "./http-client";

/**
 * Multi-source movie/TV metadata lookup.
 *
 * Three sources are queried IN PARALLEL so a single failing provider never
 * blocks the others (the old code returned 502 as soon as TMDb failed and the
 * OMDb fallback was unreachable):
 *   - TMDb  (online, needs tmdbApiKey; richest data + Chinese titles)
 *   - OMDb  (online, needs omdbApiKey; IMDb-derived data)
 *   - Local IMDb dataset mirror (offline, populated from the free IMDb TSV
 *     dumps by the /imdb/import job)
 */

export interface MetadataResult {
  tmdbId?: number;
  imdbId?: string;
  doubanId?: string;
  doubanRating?: number;
  title: string;
  titleEn?: string;
  year?: number;
  rating?: number;
  ratingSource?: "imdb" | "tmdb" | "douban";
  ratingVotes?: number;
  rottenTomatoesRating?: number;
  metacriticRating?: number;
  runtimeMinutes?: number;
  director?: string;
  cast?: string;
  genres?: string;
  overview?: string;
  poster?: string;
  /** 合并多个资料源时记录海报实际来自哪个可核验 provider。 */
  posterSource?: "tmdb" | "omdb" | "imdb";
  mediaType: "movie" | "tv";
  standardizedName?: string;
  source: "tmdb" | "omdb" | "imdb" | "wikipedia" | "tvmaze" | "douban";
}

export interface LookupOutcome {
  results: MetadataResult[];
  /** Human-readable per-provider failures (empty when everything worked) */
  errors: string[];
}

/**
 * Select and enrich the candidate that matches the requested identity.
 * Providers intentionally return different subsets (IMDb suggestion usually
 * has the tconst/poster while OMDb/TMDb/local IMDb carry rating/crew/genres),
 * so selecting the first match silently drops useful fields. This helper
 * merges only same-identity candidates and never lets a conflicting IMDb id
 * overwrite the canonical one.
 */
export function mergeMetadataByIdentity(
  candidates: MetadataResult[],
  queryTitle: string,
  queryYear?: number | null,
): MetadataResult | null {
  const matches = candidates.filter((candidate) => metadataIdentityMatches({
    candidate,
    queryTitle,
    queryYear,
  }));
  if (matches.length === 0) return null;

  const fieldCount = (candidate: MetadataResult) => [
    candidate.imdbId,
    candidate.rating,
    candidate.ratingVotes,
    candidate.rottenTomatoesRating,
    candidate.metacriticRating,
    candidate.runtimeMinutes,
    candidate.director,
    candidate.genres,
    candidate.overview,
    candidate.poster,
    candidate.doubanId,
    candidate.doubanRating,
  ].filter((value) => value !== undefined && value !== null && value !== "").length;

  // Prefer a richer candidate, preserving provider order for ties. A result
  // with a verified IMDb id is preferred over a title-only result when both
  // otherwise contain the same amount of information.
  const ranked = [...matches].sort((a, b) => (
    fieldCount(b) - fieldCount(a)
    || Number(Boolean(b.imdbId)) - Number(Boolean(a.imdbId))
  ));
  const canonical = { ...ranked[0] };
  if (canonical.poster && canonical.source !== "tmdb" && canonical.source !== "omdb" && canonical.source !== "imdb") {
    delete canonical.poster;
  } else if (canonical.poster && !canonical.posterSource) {
    canonical.posterSource = canonical.source === "tmdb" || canonical.source === "omdb" || canonical.source === "imdb"
      ? canonical.source
      : undefined;
  }
  for (const candidate of matches) {
    const compatible = !canonical.imdbId || !candidate.imdbId
      || canonical.imdbId.toLowerCase() === candidate.imdbId.toLowerCase();
    if (!compatible) continue;
    for (const [key, value] of Object.entries(candidate)) {
      if (value === undefined || value === null || value === "") continue;
      if (key === "poster") {
        if (candidate.source !== "tmdb" && candidate.source !== "omdb" && candidate.source !== "imdb") continue;
        if (canonical.poster === undefined) {
          canonical.poster = value as string;
          canonical.posterSource = candidate.source;
        }
        continue;
      }
      const current = (canonical as Record<string, unknown>)[key];
      if (current === undefined || current === null || current === "") {
        (canonical as Record<string, unknown>)[key] = value;
      }
    }
  }
  return canonical;
}

/**
 * Decide whether a provider result is safe to attach to the requested title.
 * Fuzzy providers frequently return a similarly named work (for example
 * "Simply Red" for "Simply Anne Sophie"). An IMDb id from such a result
 * must never overwrite the requested identity.
 */
/** Words that carry no identity; a shared "the/with/of" must not imply a match. */
const IDENTITY_STOPWORDS = new Set([
  "the", "a", "an", "of", "and", "or", "with", "in", "on", "at", "to", "for",
  "de", "la", "le", "el", "los", "las", "der", "die", "das", "und", "y",
]);

/** Tokens that distinguish one work from another: no stopwords, no bare numbers. */
function distinctiveTokens(tokens: string[]): string[] {
  return tokens.filter((token) => !IDENTITY_STOPWORDS.has(token) && !/^\d+$/.test(token));
}
export function metadataIdentityMatches(params: {
  candidate: Pick<MetadataResult, "title" | "titleEn" | "year">;
  queryTitle: string;
  queryYear?: number | null;
}): boolean {
  // Same presentation folding as the poster identity gate: accents and numeral
  // spelling are not identity differences, so `La Bayadere` matches
  // `La Bayadère` instead of being silently rejected.
  const normalized = (value: string) => (normalizeTitleEn(value) || value)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\u3400-\u9fff]+/gu, " ")
    .trim();
  const query = normalized(params.queryTitle);
  const candidate = normalized(params.candidate.titleEn || params.candidate.title);
  if (!query || !candidate) return false;
  const queryTokens: string[] = query.split(/\s+/).filter(Boolean);
  const candidateTokens: string[] = candidate.split(/\s+/).filter(Boolean);
  const overlap = new Set(queryTokens.filter((token) => candidateTokens.includes(token)));
  // Two shared words are not enough to establish identity: "The Making of
  // King Arthur" and "King Arthur" would otherwise merge and can import the
  // wrong poster/rating.  Permit fuzzy matching only when almost all tokens
  // participate and the candidate is not materially shorter.
  const overlapRatio = overlap.size / Math.max(queryTokens.length, candidateTokens.length);
  const titleMatches = query === candidate
    || (queryTokens.length >= 2
      && candidateTokens.length >= 2
      && overlap.size >= 2
      && overlapRatio >= 0.75
      && Math.abs(queryTokens.length - candidateTokens.length) <= 1);
  if (!titleMatches) return false;
  // A high overlap ratio is not identity: "The Odyssey with Dan Snow" and "The
  // Colosseum with Dan Snow" share four of five tokens yet are different works.
  // Every distinctive query token must appear in the candidate.
  const candidateDistinctive = new Set(distinctiveTokens(candidateTokens));
  if (!distinctiveTokens(queryTokens).every((token) => candidateDistinctive.has(token))) return false;
  // A sequel marker is an identity difference, not a token to be dropped:
  // normalizeTitleEn discards a trailing `II`, which made the exact-match
  // branch treat "A Better Tomorrow II" as "A Better Tomorrow". The markers
  // must agree before any match is accepted.
  const querySequence = sequenceMarkers(params.queryTitle);
  const candidateSequence = sequenceMarkers(params.candidate.titleEn || params.candidate.title || "");
  if (querySequence.join(",") !== candidateSequence.join(",")) return false;
  if (params.queryYear && params.candidate.year && Math.abs(params.queryYear - params.candidate.year) > 1) return false;
  return true;
}

const ROMAN_SEQUENCE = /^(?<![a-z0-9])(?<roman>[ivx]{1,4})$/i;

/**
 * Sequence markers that distinguish entries of the same series: a bare Roman
 * numeral, `Part N`, or `Chapter N`. The Roman form must not be preceded by a
 * letter or digit, so the `iv` inside `survivor` is not read as a sequel.
 */
export function sequenceMarkers(title: string): string[] {
  const text = (title ?? "").toLowerCase();
  const markers: string[] = [];
  // `Part N` / `Chapter N` arrive as two tokens once punctuation is stripped.
  for (const hit of text.matchAll(/\b(part|chapter)\s*(\d{1,3})\b/g)) {
    markers.push(`${hit[1]}${hit[2]}`);
  }
  // A standalone Roman numeral is a sequence marker; the same letters inside a
  // word (`survivor`) are not, which the lookbehind guarantees.
  for (const token of text.replace(/[^\p{L}\p{N}]+/gu, " ").split(/\s+/).filter(Boolean)) {
    const hit = ROMAN_SEQUENCE.exec(token);
    if (hit?.groups?.roman) markers.push(hit.groups.roman);
  }
  return markers;
}

export const FETCH_TIMEOUT_MS = 10_000;

/**
 * Build a fetch implementation for metadata providers.
 *
 * A proxy is *optional*: it is auto-detected from a listening local port (see
 * `resolvePosterProxyUrl`), so it can be picked up merely because an unrelated
 * process happens to own 10809. When that proxy cannot serve the request the
 * lookup must not fail outright — the whole provider set previously went dark
 * with "代理请求失败" while a direct request to the same URL succeeded. Fail
 * over to a direct request and only report an error when both paths fail.
 */
export function proxyAwareFetch(proxyUrl: string | null): typeof fetch {
  return async (input, init) => {
    const url = typeof input === "string" ? input : String(input);
    const response = await fetchLike(url, proxyUrl, FETCH_TIMEOUT_MS);
    if (response?.ok) {
      return new Response(response.body as ReadableStream, { status: 200 });
    }
    if (proxyUrl) {
      const direct = await fetchLike(url, null, FETCH_TIMEOUT_MS).catch(() => null);
      if (direct?.ok) {
        return new Response(direct.body as ReadableStream, { status: 200 });
      }
      throw new Error(`代理与直连均失败: ${url.slice(0, 120)}`);
    }
    throw new Error(`请求失败: ${url.slice(0, 120)}`);
  };
}

/**
 * 清洗英文片名：只保留片名 token，剔除年份、季集号、分辨率、编码、音轨、
 * 发布标签与发布组（供智能助手展示、任务元数据落库与命名使用）。
 */
export function normalizeTitleEn(value: string): string {
  const raw = (value ?? "").trim();
  if (!raw) return "";
  // 先剥离方括号/圆括号/花括号（发布标签常以 [2007]、[rutracker] 等形式出现），
  // 再按点/空格/下划线切分，避免残留 "[]" 或 "August.Rush.[2007]" 这类碎片。
  const tokens = raw.replace(/[\[\](){}]/g, " ").split(/[.\s_]+/).filter(Boolean);
  const tagPatterns = [
    /^\d{3,4}p$/i,
    /^(s\d{1,2}(e\d{1,4})?)$/i,
    /^(season|seasons|episode|episodes|series)$/i,
    /^第?\d{1,2}季$/,
    /^(x264|x265|h264|h265|hevc|avc|av1|10bit|8bit)$/i,
    /^(aac|ac3|dts|truehd|flac|mp3|pcm|eac3|atmos)$/i,
    /^(bluray|bdrip|dvdrip|webdl|web-dl|webrip|hdtv|hdtvrip|pdtv|remux|hdr|dv|uhd|4k|2160p|1080p|720p|480p|576p|amzn|amazon)$/i,
    /^(mvgroup|rutracker|kinosvalka|yify|rarbg|fgt|ctrlhd|nzb|deflate)$/i,
    /^(org|com|net|info)$/i,
    // NOTE: standalone numbers and `Part N` are deliberately NOT stripped.
    // They are title content far more often than release noise — "Apollo 13",
    // "Catch 22", "The 39 Steps", "Symphony No. 5", "Symphonies Nos. 1 & 2",
    // "11 Days 11 Nights Part 3" — and removing them emptied year-titled works
    // ("1923", "1917", "2001") completely. Disc/audio channel forms stay listed
    // explicitly below so real tags such as "5.1" and "2ch" are still dropped.
    /^\d\.\d$/,
    /^\dch$/i,
    /^p\d{1,2}$/i,
    /^(x26[45]|h26[45]|hevc|avc|av1|web|bd|bluray|dvdrip|webrip|hdtv|remux|uhd|2160p|1080p|720p|480p|576p)-[a-z0-9]+$/i,
    /^\d{1,2}of\d{1,2}$/i,
    /^\d{1,2}x\d{1,4}$/i,
    /^(dvd5|dvd9|2dvd5|2dvd9|dvdr|bd25|bd50|bdr)$/i,
    /^(complete|proper|repack)$/i,
    /^(mkv|mp4|avi|mov|wmv|flv|m4v|ts|m2ts|vob|iso|srt|ass|idx|sub)$/i,
  ];
  // 发布标记：片名之后出现的分辨率/编码/音轨/来源/发布组，一律从此截断，
  // 避免 "Panic.Room.AMZN.Silence" 这类未知组名残留在片名里。
  // 年份不在其中：parseFilename 已经剥离了年份及其后的内容，而标题里的
  // 年份（1923 / 1917 / 2001）必须保留。
  const releaseMarkerPatterns = [
    /^\d{3,4}p$/i,
    /^(s\d{1,2}(e\d{1,4})?)$/i,
    /^\d{1,2}x\d{1,4}$/i,
    /^\d{1,2}of\d{1,2}$/i,
    /^(amzn|amazon|bluray|bdrip|dvdrip|webdl|web-dl|webrip|hdtv|hdtvrip|pdtv|remux|uhd|4k|2160p|1080p|720p|480p|576p|hdr|dv|x264|x265|h264|h265|hevc|avc|av1|10bit|8bit|aac|ac3|dts|truehd|flac|mp3|pcm|eac3|atmos|dvd5|dvd9|2dvd5|2dvd9|complete|proper|repack)$/i,
  ];
  const isReleaseYear = (token: string): boolean => /^(19|20)\d{2}$/.test(token);
  const isTag = (token: string): boolean => {
    if (tagPatterns.some((pattern) => pattern.test(token))) return true;
    // 处理 "A&B&C" 形式的组合发布标签（如 Kinosvalka&rutracker）
    if (token.includes("&")) {
      const parts = token.split("&").filter(Boolean);
      return parts.length >= 2 && parts.every((part) => tagPatterns.some((pattern) => pattern.test(part)));
    }
    return false;
  };
  // Language / region / edition codes are tags only inside the trailing tag
  // cluster. `dan` is the Danish code, but "Dan" is a person's name: dropping it
  // turned "The.Odyssey.with.Dan.Snow" into "The.Odyssey.with.Snow", which both
  // searched for the wrong work and made two different documentaries look alike.
  const trailingCodePatterns = [
    /^(multi|rus|eng|chi|zho|ger|deu|fre|fra|spa|jpn|kor|ita|pol|cze|hun|nld|swe|nor|dan|fin|por|ara|heb|tur|tha|vie|ind)$/i,
    /^(cc|uk|us|criterion|criterioncollection)$/i,
  ];
  const isTrailingCode = (token: string): boolean => trailingCodePatterns.some((pattern) => pattern.test(token));
  const isTrailingTag = (token: string): boolean => isTag(token) || isTrailingCode(token);
  const markerIndex = tokens.findIndex((token, index) => {
    if (releaseMarkerPatterns.some((pattern) => pattern.test(token))) return true;
    // A year truncates the title only when it follows the title (a release
    // year such as `Kronprinz.Rudolf.2006`). A leading year is the title
    // itself — `1923`, `1917`, `2001 A Space Odyssey` — and must survive.
    return isReleaseYear(token) && index > 0;
  });
  const titleTokens = markerIndex >= 0 ? tokens.slice(0, markerIndex) : tokens;
  const clean = titleTokens
    .filter((token) => !/[\u3400-\u9fff]/.test(token))
    // A code-like token survives unless everything after it is also a tag, so a
    // name such as "Dan" stays inside the title while a trailing "ENG" is still
    // dropped and a one-word title like "Us" is never emptied.
    .filter((token, index, all) => !isTag(token)
      && !(isTrailingCode(token) && index > 0 && all.slice(index + 1).every(isTrailingTag)))
    .join(".");
  return clean.replace(/\.{2,}/g, ".").replace(/^\.+|\.+$/g, "");
}

/** Parse a filename to extract a search-friendly title and optional year */
export function parseFilename(filename: string): { title: string; year?: number } {
  // path.extname treats the last dotted title token as an extension when the
  // caller passes a search title rather than a real media filename (for
  // example `In.the.Opinion.of.the.Censor`).  Only strip extensions that are
  // known media/subtitle containers; preserve dotted titles intact.
  const knownExtensions = new Set([
    ".mkv", ".mp4", ".m4v", ".webm", ".mov", ".avi", ".wmv", ".flv", ".ts",
    ".m2ts", ".vob", ".mpg", ".mpeg", ".3gp", ".ogv", ".iso", ".srt", ".ass",
    ".vtt", ".sub", ".idx",
  ]);
  const extension = path.extname(filename).toLowerCase();
  const base = knownExtensions.has(extension)
    ? path.basename(filename, path.extname(filename))
    : path.basename(filename);
  // A release year follows the title and may be:
  //   - wrapped in a separator on both sides: `.1993.`
  //   - followed directly by CJK text: `.1993纯真年代`
  //   - a range: `.2003-2018.`
  //   - at the end of the name: `.2000`
  // Occurrences are collected with their offsets instead of a single match so
  // that year-titled works stay intact: in `2046.2004` the first year IS the
  // title and only the second one is the release year, while `1917.2019` and
  // `1984.1984.一九八四` follow the same shape.
  const yearOccurrences: Array<{ token: string; index: number }> = [];
  const yearScan = /[.([\s]((19|20)\d{2})(?![0-9])/g;
  for (let hit = yearScan.exec(base); hit; hit = yearScan.exec(base)) {
    yearOccurrences.push({ token: hit[1], index: hit.index });
  }
  const releaseYear = yearOccurrences.length > 1
    ? yearOccurrences[yearOccurrences.length - 1]
    : yearOccurrences[0];
  const year = releaseYear ? parseInt(releaseYear.token) : undefined;
  let title = base;
  if (releaseYear) {
    // Never cut from offset 0; the leading token cannot be a release year.
    const cut = releaseYear.index === 0 ? base.length : releaseYear.index;
    title = base.slice(0, cut);
    // The year may be wrapped in ASCII or full-width parentheses.
    title = title.replace(/[（(][^)）]*$/, "");
    if (title === base) title = base;
  }
  title = title
    .replace(/[（(][^)）]*?((19|20)\d{2})[^)）]*?[)）].*$/, "")
    .replace(/\b(S\d{2}E\d{2}|Season\s?\d+|Episode\s?\d+)\b.*/i, "")
    .replace(/[._]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return { title, year };
}

/** Build a standardized filename from metadata + original file */
export function buildStandardizedName(
  title: string,
  titleEn: string | undefined,
  year: number | undefined,
  originalFile: string,
  encoder: string,
  outputFormat: string
): string {
  const resMatch = originalFile.match(/\b(4K|2160p|1080p|720p|480p)\b/i);
  const res = resMatch ? resMatch[1].toLowerCase() : "1080p";
  const srcMatch = originalFile.match(/\b(BluRay|BDRip|WEB-DL|WEBRip|HDTV|DVDRip|Remux)\b/i);
  const src = srcMatch ? srcMatch[1] : "BluRay";
  const parts: string[] = [];
  if (title) parts.push(title.replace(/[/\\:*?"<>|]/g, ""));
  if (titleEn && titleEn !== title) parts.push(titleEn.replace(/[/\\:*?"<>|]/g, "").replace(/\s+/g, "."));
  const titleAlreadyContainsYear = [title, titleEn].some((value) => /(?:19|20)\d{2}/.test(value ?? ""));
  if (year && !titleAlreadyContainsYear) parts.push(String(year));
  parts.push(res);
  parts.push(src);
  parts.push(encoder.replace(/_/g, "-"));
  return parts.join(".") + "." + outputFormat;
}

export function stdName(r: Pick<MetadataResult, "title" | "titleEn" | "year">, originalQuery: string): string {
  return buildStandardizedName(r.title, r.titleEn, r.year, originalQuery, "x264-10bit", "mkv");
}

import { searchTmdb, searchOmdb, searchWikipediaPoster, searchDouban } from "./metadata-providers";
export { searchTmdb, searchOmdb, searchWikipediaPoster, searchDouban } from "./metadata-providers";
import { searchImdbSuggestion, searchImdbTitlePage, searchImdbLocal, searchImdbByTconst } from "./metadata-imdb";
export { searchImdbSuggestion, searchImdbTitlePage, searchImdbLocal, searchImdbByTconst } from "./metadata-imdb";

// ─── Merge ────────────────────────────────────────────────────────────────────

function dedupeKey(r: MetadataResult): string {
  if (r.imdbId) return `id:${r.imdbId}`;
  const t = (r.titleEn || r.title).toLowerCase().replace(/[^a-z0-9一-鿿]/g, "");
  return `ty:${t}:${r.year ?? "?"}`;
}

function normalizedIdentityTitle(r: MetadataResult): string {
  return (r.titleEn || r.title).toLowerCase().replace(/[^a-z0-9一-鿿]/g, "");
}

/** Providers frequently disagree on whether an IMDb id is available. Treat
 * the same normalized title/year as one candidate so a later provider can
 * backfill the missing identity fields on the richer first result. */
function sameIdentityCandidate(a: MetadataResult, b: MetadataResult): boolean {
  if (a.mediaType !== b.mediaType) return false;
  if (normalizedIdentityTitle(a) !== normalizedIdentityTitle(b)) return false;
  if (a.year === undefined || b.year === undefined) return true;
  return Math.abs(a.year - b.year) <= 1;
}

/**
 * Merge provider result lists. Earlier lists win on duplicates (pass TMDb
 * first — it has the richest data and localized titles), but missing fields
 * on the winner are backfilled from the duplicates it shadows.
 */
export function mergeResults(...lists: MetadataResult[][]): MetadataResult[] {
  const merged = new Map<string, MetadataResult>();
  for (const list of lists) {
    for (const r of list) {
      const key = dedupeKey(r);
      const existing = merged.get(key) ?? [...merged.values()].find((candidate) => (
        (!candidate.imdbId || !r.imdbId) && sameIdentityCandidate(candidate, r)
      ));
      if (!existing) {
        merged.set(key, { ...r });
      } else {
        const target = existing as unknown as Record<string, unknown>;
        for (const [k, v] of Object.entries(r)) {
          const cur = target[k];
          if (v !== undefined && v !== "" && (cur === undefined || cur === "")) {
            target[k] = v;
          }
        }
      }
    }
  }
  return [...merged.values()].slice(0, 10);
}

// ─── Top-level lookup ─────────────────────────────────────────────────────────

export async function lookupAll(opts: {
  rawQuery: string;
  year?: number;
  language: string;
  config: typeof configTable.$inferSelect;
  /** 数据源代理（http://127.0.0.1:10809 等），适配国内网络；为空走系统默认。 */
  proxyUrl?: string | null;
}): Promise<LookupOutcome> {
  const { title, year: parsedYear } = parseFilename(opts.rawQuery);
  // Scene/release prefixes such as `RTE.` are not part of the work title and
  // make IMDb's suggestion endpoint return no candidate.  Remove a short
  // all-caps prefix only when a normal title token follows it; legitimate
  // mixed-case titles remain untouched.
  const parsedSearchTitle = title || opts.rawQuery;
  const searchTitle = parsedSearchTitle
    .replace(/^[A-Z]{2,5}\s+(?=[A-Z][a-z])/u, "")
    .trim();
  const searchYear = opts.year ?? parsedYear;
  const proxyUrl = await resolvePosterProxyUrl(opts.proxyUrl ?? null);
  const fetchFn = proxyAwareFetch(proxyUrl);

  const errors: string[] = [];
  const empty: MetadataResult[] = [];

  const imdbEnabled = (opts.config.imdbTitleCount ?? 0) > 0;

  // Douban is keyless and is queried with both the parsed title and the raw
  // query: a library folder may be named in Chinese while the parsed title is
  // English (or the reverse), and Douban's suggest feed answers either.
  const doubanQuery = opts.rawQuery.trim() && opts.rawQuery.trim() !== searchTitle
    ? [searchTitle, opts.rawQuery.trim()]
    : [searchTitle];

  const [tmdb, omdb, imdbLocal, wikipedia, imdbSuggestion, douban] = await Promise.all([
    opts.config.tmdbApiKey
      ? searchTmdb(searchTitle, {
          year: searchYear, language: opts.language,
          apiKey: opts.config.tmdbApiKey, originalQuery: opts.rawQuery,
        }, fetchFn).catch((e: unknown) => { errors.push(`TMDb: ${e instanceof Error ? e.message : String(e)}`); return empty; })
      : empty,
    opts.config.omdbApiKey
      ? searchOmdb(searchTitle, {
          year: searchYear, apiKey: opts.config.omdbApiKey, originalQuery: opts.rawQuery,
        }, fetchFn).catch((e: unknown) => { errors.push(`OMDb: ${e instanceof Error ? e.message : String(e)}`); return empty; })
      : empty,
    imdbEnabled
      ? searchImdbLocal(searchTitle, { year: searchYear, originalQuery: opts.rawQuery })
          .catch((e: unknown) => { errors.push(`IMDb本地: ${e instanceof Error ? e.message : String(e)}`); return empty; })
      : empty,
    searchWikipediaPoster(searchTitle, { year: searchYear, originalQuery: opts.rawQuery, proxyUrl })
      .catch((e: unknown) => { errors.push(`Wikipedia: ${e instanceof Error ? e.message : String(e)}`); return empty; }),
    searchImdbSuggestion(searchTitle, { year: searchYear, originalQuery: opts.rawQuery }, fetchFn)
      .catch((e: unknown) => { errors.push(`IMDb在线: ${e instanceof Error ? e.message : String(e)}`); return empty; }),
    Promise.all(doubanQuery.map((query) => searchDouban(query, {
      year: searchYear, originalQuery: opts.rawQuery, fetchFn,
    }).catch((e: unknown) => { errors.push(`豆瓣: ${e instanceof Error ? e.message : String(e)}`); return empty; })))
      .then((lists) => lists.flat()),
  ]);

  // Retry without the year filter if it produced nothing — filename year
  // guesses are frequently wrong for disc rips, and movie/TV sources often
  // differ by ±1 year (or more for official recordings released long after
  // the actual performance).  Re-run every provider without the year so the
  // same-titled work is still found.
  // The IMDb suggestion result is the only no-key source that supplies the
  // tconst and poster together, so put it first.  Richer keyed/local providers
  // still backfill missing fields through mergeResults.
  let results = mergeResults(imdbSuggestion, tmdb, omdb, imdbLocal, wikipedia, douban);
  if (results.length === 0 && searchYear) {
    const [retryTmdb, retryOmdb, retryWikipedia, retryImdbLocal, retryImdbSuggestion, retryDouban] = await Promise.all([
      opts.config.tmdbApiKey
        ? searchTmdb(searchTitle, { language: opts.language, apiKey: opts.config.tmdbApiKey, originalQuery: opts.rawQuery }, fetchFn)
            .catch(() => empty)
        : empty,
      opts.config.omdbApiKey
        ? searchOmdb(searchTitle, { apiKey: opts.config.omdbApiKey, originalQuery: opts.rawQuery }, fetchFn)
            .catch(() => empty)
        : empty,
      searchWikipediaPoster(searchTitle, { originalQuery: opts.rawQuery, proxyUrl })
        .catch(() => empty),
      imdbEnabled
        ? searchImdbLocal(searchTitle, { originalQuery: opts.rawQuery }).catch(() => empty)
        : empty,
      searchImdbSuggestion(searchTitle, { originalQuery: opts.rawQuery }, fetchFn).catch(() => empty),
      Promise.all(doubanQuery.map((query) => searchDouban(query, { originalQuery: opts.rawQuery, fetchFn }).catch(() => empty)))
        .then((lists) => lists.flat()),
    ]);
    results = mergeResults(retryImdbSuggestion, retryTmdb, retryOmdb, retryImdbLocal, retryWikipedia, retryDouban);
  }

  return { results, errors };
}
