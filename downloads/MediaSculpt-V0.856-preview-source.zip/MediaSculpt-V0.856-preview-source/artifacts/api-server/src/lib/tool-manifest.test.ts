import { describe, expect, it } from "vitest";
import path from "node:path";
import { toolPackages } from "./tool-manifest";

describe("tool manifest", () => {
  it("creates isolated per-tool directories", () => {
    const packages = toolPackages("darwin", "/Users/tester");
    expect(packages.find((pkg) => pkg.id === "ffmpeg")?.installDirectory).toBe(path.join("/Users/tester", "Library", "Application Support", "MediaSculpt", "tools", "ffmpeg"));
    expect(packages.find((pkg) => pkg.id === "whisper")?.required).toBe(false);
    expect(packages.find((pkg) => pkg.id === "tesseract")?.required).toBe(false);
    expect(packages.find((pkg) => pkg.id === "rapidocr")?.required).toBe(false);
    expect(packages.find((pkg) => pkg.id === "tesseract")?.installDirectory).toBe(path.join("/Users/tester", "Library", "Application Support", "MediaSculpt", "tools", "tesseract"));
  });

  it("exposes platform-specific official sources when no override is configured", () => {
    const packages = toolPackages("win32", "C:\\Users\\tester");
    expect(packages.find((pkg) => pkg.id === "ffmpeg")?.sources[0]).toContain("ffmpeg-master-latest-win64-gpl.zip");
    expect(packages.find((pkg) => pkg.id === "ffprobe")?.sources[0]).toContain("ffmpeg-master-latest-win64-gpl.zip");
    expect(packages.find((pkg) => pkg.id === "ffmpeg")?.sources.length).toBeGreaterThan(1);
    expect(packages.find((pkg) => pkg.id === "handbrake")?.sources[0]).toMatch(/HandBrakeCLI-.+-win-x86_64\.zip$/);
    expect(packages.some((pkg) => String(pkg.id).includes("makemkv"))).toBe(false);
    expect(packages.find((pkg) => pkg.id === "libretranslate")?.sources[0]).toBe("https://pypi.org/project/libretranslate/");
    expect(packages.find((pkg) => pkg.id === "tesseract")?.sources[0]).toMatch(/tesseract-ocr-w64-setup-.+\.exe$/);
    expect(packages.find((pkg) => pkg.id === "rapidocr")?.sources[0]).toBe("https://pypi.org/project/rapidocr_onnxruntime/");
  });
});
