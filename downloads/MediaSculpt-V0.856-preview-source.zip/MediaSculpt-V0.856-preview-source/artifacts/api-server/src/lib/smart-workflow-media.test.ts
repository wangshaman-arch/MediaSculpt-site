import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { afterEach, describe, expect, it } from "vitest";
import { detectExternalSubtitles, listSmartWorkflowMediaFiles } from "./smart-workflow-media";

describe("smart workflow directory media discovery", () => {
  let temporaryDirectory: string | undefined;

  afterEach(async () => {
    if (temporaryDirectory) await fs.rm(temporaryDirectory, { recursive: true, force: true });
    temporaryDirectory = undefined;
  });

  it("discovers supported media files recursively and ignores unsupported files", async () => {
    temporaryDirectory = await fs.mkdtemp(path.join(os.tmpdir(), "vx-smart-workflow-media-"));
    await fs.mkdir(path.join(temporaryDirectory, "Season 1"), { recursive: true });
    await fs.writeFile(path.join(temporaryDirectory, "movie.mkv"), "video");
    await fs.writeFile(path.join(temporaryDirectory, "readme.txt"), "ignore");
    await fs.writeFile(path.join(temporaryDirectory, "Season 1", "episode 01.MP4"), "video");

    await expect(listSmartWorkflowMediaFiles(temporaryDirectory)).resolves.toEqual([
      path.join(temporaryDirectory, "movie.mkv"),
      path.join(temporaryDirectory, "Season 1", "episode 01.MP4"),
    ]);
  });

  it("detects companion subtitle files and flags Chinese content", async () => {
    temporaryDirectory = await fs.mkdtemp(path.join(os.tmpdir(), "vx-smart-workflow-subs-"));
    const video = path.join(temporaryDirectory, "Movie.mkv");
    await fs.writeFile(video, "video");
    await fs.writeFile(path.join(temporaryDirectory, "Movie.zh.srt"), "1\n00:00:01,000 --> 00:00:03,000\n你好，世界\n");
    await fs.writeFile(path.join(temporaryDirectory, "Movie.en.srt"), "1\n00:00:01,000 --> 00:00:03,000\nHello world\n");
    await fs.writeFile(path.join(temporaryDirectory, "readme.txt"), "ignore me");

    const subtitles = await detectExternalSubtitles(video);
    expect(subtitles.map((subtitle) => path.basename(subtitle.path))).toEqual(["Movie.en.srt", "Movie.zh.srt"]);
    expect(subtitles.find((subtitle) => subtitle.path.endsWith("Movie.zh.srt"))?.hasChinese).toBe(true);
    expect(subtitles.find((subtitle) => subtitle.path.endsWith("Movie.en.srt"))?.hasChinese).toBe(false);
  });

  it("ignores an unmatched subtitle file even when its content is Chinese", async () => {
    temporaryDirectory = await fs.mkdtemp(path.join(os.tmpdir(), "vx-smart-workflow-subs-"));
    const video = path.join(temporaryDirectory, "Video A.mkv");
    await fs.writeFile(video, "video");
    await fs.writeFile(path.join(temporaryDirectory, "字幕.srt"), "1\n00:00:01,000 --> 00:00:03,000\n中文内容\n");

    const subtitles = await detectExternalSubtitles(video);
    expect(subtitles).toHaveLength(0);
  });
});
