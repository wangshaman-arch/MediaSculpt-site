import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { access } from "node:fs/promises";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { ensureLibdvdcss, isLibdvdcssInstalled, LIBDVDCSS_PROBE_MIRRORS } from "./libdvdcss";
import {
  ensureAacsDecryption,
  isAacsLibraryInstalled,
  isKeydbInstalled,
  KEYDB_PROBE_MIRRORS,
} from "./libaacs";
import { mediaSculptDataRoot } from "../../../../lib/db/src/brand-paths";
const execFileAsync = promisify(execFile);

export type RuntimePlatform = "win32" | "darwin" | "linux";
export type ToolId = "ffmpeg" | "ffprobe" | "handbrake" | "whisper" | "libretranslate" | "tesseract" | "rapidocr";

export type ToolStatus = {
  id: ToolId;
  label: string;
  executable: string;
  path: string | null;
  available: boolean;
  required: boolean;
  version: string | null;
  /** 真实健康状态：ok=可用，broken=已安装但关键组件缺失/损坏，missing=未安装 */
  health: "ok" | "broken" | "missing";
  sourceDirectory?: string | null;
  /** Windows only: whether libdvdcss-2.dll is ready next to ffmpeg/ffprobe. */
  dvdCssReady?: boolean | null;
  /**
   * Windows only: whether Blu-ray decryption is usable, i.e. libaacs.dll +
   * libbdplus.dll are installed AND a KEYDB.cfg key database is present.
   */
  blurayAacsReady?: boolean | null;
  /** Whisper 已下载模型列表（名称 + 体积 MB），供界面显示“模型 + 大小”。 */
  modelInfo?: Array<{ name: string; sizeMB: number }> | null;
};

async function probeToolHealth(id: ToolId, resolved: string | null): Promise<{ health: "ok" | "broken" | "missing"; version: string | null; dvdCssReady?: boolean | null; blurayAacsReady?: boolean | null }> {
  if (!resolved) return { health: "missing", version: null, dvdCssReady: null, blurayAacsReady: null };
  try {
    if (id === "whisper" || id === "rapidocr") {
      // Whisper / RapidOCR 的“可执行文件”是 venv 的 python.exe，只验证路径存在
      // 没有任何意义——必须实际导入关键包，缺包即视为损坏。
      const importName = id === "whisper" ? "faster_whisper, av" : "rapidocr_onnxruntime";
      const packageName = id === "whisper" ? "faster-whisper" : "rapidocr_onnxruntime";
      await execFileAsync(resolved, ["-c", `import ${importName}`], { timeout: 20_000, windowsHide: true });
      let version: string | null = null;
      try {
        const result = await execFileAsync(
          resolved,
          ["-c", `import importlib.metadata as m; print(m.version(${JSON.stringify(packageName)}))`],
          { timeout: 20_000, windowsHide: true },
        );
        version = result.stdout.trim() || null;
      } catch {
        version = null;
      }
      return { health: "ok", version, dvdCssReady: null };
    }
    if (id === "libretranslate") {
      // LibreTranslate 的 CLI 不一定支持 --version；可执行文件存在即视为可用。
      return { health: "ok", version: null, dvdCssReady: null };
    }
    // 部分 FFmpeg 构建只支持单横线 `-version`，`--version` 会非零退出导致误报“异常”，
    // 因此 ffmpeg/ffprobe 优先用 `-version`，失败再回退 `--version`。
    const candidates = id === "ffmpeg" || id === "ffprobe" ? [["-version"], ["--version"]] : [["--version"]];
    for (const args of candidates) {
      try {
        const result = await execFileAsync(resolved, args, { timeout: 5000, windowsHide: true });
        const version = `${result.stdout}\n${result.stderr}`.trim().split(/\r?\n/)[0] ?? null;
        let dvdCssReady: boolean | null = null;
        let blurayAacsReady: boolean | null = null;
        if (process.platform === "win32" && (id === "ffmpeg" || id === "ffprobe")) {
          if (await isLibdvdcssInstalled(resolved)) {
            dvdCssReady = true;
          } else {
            // Best-effort auto-provision with a short budget so the settings
            // page stays responsive. A missing DLL does not break regular
            // media, so health remains "ok" even if the download fails.
            const status = await ensureLibdvdcss(resolved, {
              mirrors: LIBDVDCSS_PROBE_MIRRORS,
              timeoutMs: 10_000,
            }).catch(() => "failed" as const);
            dvdCssReady = status === "installed" || status === "already";
          }
          // Blu-ray AACS/BD+: install libaacs + libbdplus and fetch a key
          // database. Both halves are needed — the engines contain no keys of
          // their own — so readiness requires the engines AND a KEYDB.cfg.
          if (await isAacsLibraryInstalled(resolved)) {
            blurayAacsReady = await isKeydbInstalled(resolved);
          } else {
            const aacs = await ensureAacsDecryption(resolved, {
              keydbMirrors: KEYDB_PROBE_MIRRORS,
              timeoutMs: 20_000,
            }).catch(() => ({ libraries: "failed" as const, keydb: "failed" as const }));
            blurayAacsReady =
              (aacs.libraries === "installed" || aacs.libraries === "already") &&
              (aacs.keydb === "installed" || aacs.keydb === "already");
          }
        }
        return { health: "ok", version: version || null, dvdCssReady, blurayAacsReady };
      } catch {
        // 尝试下一个参数形式。
      }
    }
    return { health: "broken", version: null, dvdCssReady: null };
  } catch {
    return { health: "broken", version: null, dvdCssReady: null };
  }
}

const labels: Record<ToolId, string> = {
  ffmpeg: "FFmpeg",
  ffprobe: "FFprobe",
  handbrake: "HandBrakeCLI",
  whisper: "Whisper",
  libretranslate: "LibreTranslate",
  tesseract: "Tesseract",
  rapidocr: "RapidOCR（中文 OCR）",
};

export function managedToolDirectory(platform: RuntimePlatform = process.platform as RuntimePlatform, home = os.homedir()): string {
  if (process.env.MEDIASCULPT_TOOLS_DIR) return process.env.MEDIASCULPT_TOOLS_DIR;
  // Compatibility with installations created before the MediaSculpt rename.
  if (process.env.VX_AGENT_TOOLS_DIR) return process.env.VX_AGENT_TOOLS_DIR;
  return path.join(mediaSculptDataRoot(platform, home, process.env.LOCALAPPDATA), "tools");
}

export function executableName(id: ToolId, platform: RuntimePlatform = process.platform as RuntimePlatform): string {
  if (id === "handbrake") return platform === "win32" ? "HandBrakeCLI.exe" : "HandBrakeCLI";
  if (id === "libretranslate") return platform === "win32" ? "libretranslate.exe" : "libretranslate";
  // faster-whisper has no console script; the whisper tool resolves to the
  // managed venv python and jobs run the bundled vx_faster_whisper_cli.py.
  if (id === "whisper") return platform === "win32" ? "python.exe" : "python";
  if (id === "tesseract") return platform === "win32" ? "tesseract.exe" : "tesseract";
  if (id === "rapidocr") return platform === "win32" ? "python.exe" : "python";
  return platform === "win32" ? `${id}.exe` : id;
}

export function candidatePaths(id: ToolId, platform: RuntimePlatform = process.platform as RuntimePlatform): string[] {
  const executable = executableName(id, platform);
  const root = managedToolDirectory(platform);
  const projectRoot = process.cwd();
  const candidates = [
    path.join(root, executable),
    path.join(root, id, executable),
    path.join(projectRoot, "tools", executable),
    path.join(projectRoot, "tools", id, executable),
    path.join(projectRoot, "tools", "ffmpeg", "bin", executable),
    path.join(projectRoot, "tools", "handbrake", executable),
  ];
  if (platform === "darwin" && id === "handbrake") candidates.push("/Applications/HandBrakeCLI");
  if (id === "whisper") {
    candidates.push(
      platform === "win32"
        ? path.join(root, "whisper-env", "Scripts", executable)
        : path.join(root, "whisper-env", "bin", executable),
    );
    // 开发版（未设置 MEDIASCULPT_TOOLS_DIR）才回退到旧 ~/.vx-agent 环境；
    // 打包版必须使用自己的托管环境，保持自包含。
    if (!process.env.MEDIASCULPT_TOOLS_DIR) {
      candidates.push(
        platform === "win32"
          ? path.join(os.homedir(), ".vx-agent", "whisper-env", "Scripts", executable)
          : path.join(os.homedir(), ".vx-agent", "whisper-env", "bin", executable),
      );
    }
  }
  if (id === "libretranslate") {
    candidates.push(
      platform === "win32"
        ? path.join(root, "libretranslate", "venv", "Scripts", executable)
        : path.join(root, "libretranslate", "venv", "bin", executable),
    );
  }
  if (id === "rapidocr") {
    candidates.push(
      platform === "win32"
        ? path.join(root, "rapidocr", "venv", "Scripts", executable)
        : path.join(root, "rapidocr", "venv", "bin", executable),
    );
  }
  return candidates;
}

function pathCandidates(id: ToolId, platform: RuntimePlatform = process.platform as RuntimePlatform): string[] {
  const executable = executableName(id, platform);
  const pathValue = process.env.PATH ?? "";
  return pathValue.split(path.delimiter).filter(Boolean).map((entry) => path.join(entry, executable));
}

async function canExecute(filePath: string): Promise<boolean> {
  try {
    await access(filePath);
    return (await fs.stat(filePath)).isFile();
  } catch {
    return false;
  }
}

/**
 * Locate a system-wide Tesseract install on Windows (registry InstallPath or
 * the conventional Program Files locations). The UB-Mannheim installer often
 * installs there even when /D is not honored, so the app should discover it.
 */
async function systemTesseractPath(): Promise<string | null> {
  if (process.platform !== "win32") return null;
  const registryKeys = [
    "HKLM\\SOFTWARE\\Tesseract-OCR",
    "HKCU\\SOFTWARE\\Tesseract-OCR",
    "HKLM\\SOFTWARE\\WOW6432Node\\Tesseract-OCR",
  ];
  for (const key of registryKeys) {
    try {
      const { stdout } = await execFileAsync("reg", ["query", key, "/v", "InstallPath"], { timeout: 5000, windowsHide: true });
      const match = /InstallPath\s+REG_SZ\s+(.+)/i.exec(stdout);
      if (match) {
        const candidate = path.join(match[1].trim(), "tesseract.exe");
        if (await canExecute(candidate)) return candidate;
      }
    } catch {
      // Try the next registry key.
    }
  }
  for (const root of ["C:\\Program Files\\Tesseract-OCR", "C:\\Program Files (x86)\\Tesseract-OCR"]) {
    const candidate = path.join(root, "tesseract.exe");
    if (await canExecute(candidate)) return candidate;
  }
  return null;
}

export async function findExecutableInDirectory(directory: string, executable: string): Promise<string | null> {
  const entries = await fs.readdir(directory, { withFileTypes: true }).catch(() => []);
  for (const entry of entries) {
    const entryPath = path.join(directory, entry.name);
    if (entry.isFile() && entry.name.toLowerCase() === executable.toLowerCase() && await canExecute(entryPath)) {
      return entryPath;
    }
    if (entry.isDirectory()) {
      const nested = await findExecutableInDirectory(entryPath, executable);
      if (nested) return nested;
    }
  }
  return null;
}

export async function resolveToolPath(id: ToolId, platform: RuntimePlatform = process.platform as RuntimePlatform): Promise<string | null> {
  const executable = executableName(id, platform);
  const envKey = `MEDIASCULPT_${id.toUpperCase()}_PATH`;
  const legacyEnvKey = `VX_AGENT_${id.toUpperCase()}_PATH`;
  const configured = process.env[envKey] ?? process.env[legacyEnvKey];
  if (configured && await canExecute(configured)) return configured;

  if (id !== "rapidocr" && id !== "whisper") {
    // whisper and rapidocr resolve to managed venv pythons; PATH may contain
    // unrelated python stubs (e.g. the Microsoft Store alias).
    for (const candidate of pathCandidates(id, platform)) {
      if (await canExecute(candidate)) return candidate;
    }
  }
  for (const candidate of candidatePaths(id, platform)) {
    if (await canExecute(candidate)) return candidate;
  }
  if (id !== "rapidocr" && id !== "whisper") {
    // rapidocr/whisper 都解析到 venv 里的 python；递归搜索会把托管目录里
    // 任意一个 python.exe（如 libretranslate 的 venv）当作 Whisper 运行时，
    // 导致 import av 失败。只允许通过上面的精确 candidatePaths 找到
    // whisper-env/rapidocr 自己的 venv python。
    const managed = await findExecutableInDirectory(managedToolDirectory(platform), executable);
    if (managed && await canExecute(managed)) return managed;
  }
  if (id === "tesseract") {
    const systemPath = await systemTesseractPath();
    if (systemPath) return systemPath;
  }
  return null;
}

export async function getToolStatuses(): Promise<ToolStatus[]> {
  const ids: Array<[ToolId, boolean]> = [["ffmpeg", true], ["ffprobe", true], ["handbrake", true], ["whisper", false], ["libretranslate", false], ["tesseract", false], ["rapidocr", false]];
  return Promise.all(ids.map(async ([id, required]) => {
    const executable = executableName(id);
    const resolved = await resolveToolPath(id);
    const probe = await probeToolHealth(id, resolved);
    const status: ToolStatus = {
      id,
      label: labels[id],
      executable,
      path: resolved,
      available: probe.health !== "missing",
      required,
      version: probe.version,
      health: probe.health,
      dvdCssReady: probe.dvdCssReady ?? null,
    };
    if (id === "whisper") {
      const modelsRoot = path.join(managedToolDirectory(), "faster-whisper-models");
      const modelInfo: Array<{ name: string; sizeMB: number }> = [];
      const modelDirs = await fs.readdir(modelsRoot).catch(() => [] as string[]);
      for (const model of modelDirs) {
        const sizeMB = await (async () => {
          try {
            const files = await fs.readdir(path.join(modelsRoot, model));
            const sizes = await Promise.all(files.map((file) => fs.stat(path.join(modelsRoot, model, file)).then((s) => s.size).catch(() => 0)));
            return sizes.reduce((sum, size) => sum + size, 0) / (1024 * 1024);
          } catch {
            return 0;
          }
        })();
        if (sizeMB > 1) modelInfo.push({ name: model, sizeMB: Math.round(sizeMB) });
      }
      status.modelInfo = modelInfo;
    }
    return status;
  }));
}

export async function ensureRuntimeDirectories(): Promise<void> {
  await fs.mkdir(managedToolDirectory(), { recursive: true });
}

/**
 * Seed the managed tools directory from the tools bundled into the installer
 * (a subfolder of the app's resource dir). This lets a fresh install work
 * immediately for the bundled tools (ffmpeg/ffprobe/HandBrakeCLI) without the
 * user reaching the Tool Manager first. Existing managed tools are never
 * overwritten, so upgrades/services that already have their own tools are left
 * untouched. No-op when the installer did not bundle tools (dev/source runs).
 */
export async function seedBundledTools(): Promise<void> {
  const resourceDir = process.env.MEDIASCULPT_RESOURCE_DIR;
  if (!resourceDir) return;
  const bundled = path.join(resourceDir, "tools");
  const exists = await fs.stat(bundled).then(() => true).catch(() => false);
  if (!exists) return;
  const managed = managedToolDirectory();
  await fs.mkdir(managed, { recursive: true });
  const entries = await fs.readdir(bundled);
  for (const entry of entries) {
    const src = path.join(bundled, entry);
    const dst = path.join(managed, entry);
    const srcIsDir = await fs.stat(src).then((s) => s.isDirectory()).catch(() => false);
    const dstExists = await fs.stat(dst).then(() => true).catch(() => false);
    if (dstExists) continue;
    if (srcIsDir) await fs.cp(src, dst, { recursive: true });
    else await fs.copyFile(src, dst);
    // 捆绑的 Python 虚拟环境（rapidocr/libretranslate）依赖 pyvenv.cfg 里的
    // home 指向基础 Python。安装路径与打包机不同，必须把 home/executable 改写成
    // 托管目录下的 python，否则 venv 的 python.exe 无法启动。
    const venvCfg = path.join(dst, "venv", "pyvenv.cfg");
    if (await fs.stat(venvCfg).then(() => true).catch(() => false)) {
      const managedPython = path.join(managed, "python");
      const pythonExe = path.join(managedPython, "python.exe");
      const rewritten = (await fs.readFile(venvCfg, "utf8"))
        .replace(/^home\s*=.*$/m, `home = ${managedPython}`)
        .replace(/^executable\s*=.*$/m, `executable = ${pythonExe}`)
        .replace(/^command\s*=.*$/m, `command = ${pythonExe} -m venv ${dst}`);
      await fs.writeFile(venvCfg, rewritten);
      // 记录“已由捆绑种子补齐”，避免重复改写/复制。
      await fs.writeFile(path.join(dst, "venv", ".bundled-seed"), new Date().toISOString());
    }
  }
}

/** Make managed tools discoverable by existing child-process calls. */
export function activateManagedToolDirectory(): void {
  const root = managedToolDirectory();
  const current = process.env.PATH ?? "";
  if (!current.split(path.delimiter).includes(root)) {
    process.env.PATH = `${root}${path.delimiter}${current}`;
  }
}
