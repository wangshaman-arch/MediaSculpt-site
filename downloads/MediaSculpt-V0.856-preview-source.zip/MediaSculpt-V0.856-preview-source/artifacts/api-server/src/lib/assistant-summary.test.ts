import { describe, expect, it } from "vitest";
import { buildAuthoritativeMetadataBlock } from "./assistant-summary";

describe("buildAuthoritativeMetadataBlock", () => {
  it("keeps identity ids and ratings in the visible summary", () => {
    expect(buildAuthoritativeMetadataBlock({
      imdbId: "tt0116477",
      doubanId: "1295644",
      rating: 7.8,
      doubanRating: 8.5,
      rottenTomatoesRating: 91,
      metacriticRating: 83,
    })).toContain("IMDb：tt0116477");
    expect(buildAuthoritativeMetadataBlock({
      imdbId: "tt0116477",
      doubanId: "1295644",
      rating: 7.8,
      doubanRating: 8.5,
    })).toContain("豆瓣：1295644");
    expect(buildAuthoritativeMetadataBlock({
      imdbId: "tt0116477",
      doubanId: "1295644",
      rating: 7.8,
      doubanRating: 8.5,
    })).toContain("豆瓣评分：8.5");
    expect(buildAuthoritativeMetadataBlock({ rottenTomatoesRating: 91, metacriticRating: 83 })).toContain("烂番茄：91%");
    expect(buildAuthoritativeMetadataBlock({ rottenTomatoesRating: 91, metacriticRating: 83 })).toContain("Metacritic：83");
  });

  it("returns an empty string when no authoritative metadata exists", () => {
    expect(buildAuthoritativeMetadataBlock({})).toBe("");
  });
});
