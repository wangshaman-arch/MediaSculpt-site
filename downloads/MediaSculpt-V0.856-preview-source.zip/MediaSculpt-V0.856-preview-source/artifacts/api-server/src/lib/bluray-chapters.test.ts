import { describe, expect, it } from "vitest";
import { mapBlurayChaptersToSegments } from "./bluray-chapters";

describe("blu-ray chapter mapping", () => {
  it("maps global chapter time to segment-relative ranges", () => {
    const result = mapBlurayChaptersToSegments([
      { clipId: "00001", streamPath: "a.m2ts", inTime45k: 0, outTime45k: 450000 },
      { clipId: "00002", streamPath: "b.m2ts", inTime45k: 450000, outTime45k: 900000 },
    ], [{ startSeconds: 8, endSeconds: 12 }]);
    expect(result).toEqual([
      { file: "a.m2ts", startSeconds: 8, endSeconds: 10 },
      { file: "b.m2ts", startSeconds: 0, endSeconds: 2 },
    ]);
  });
});
