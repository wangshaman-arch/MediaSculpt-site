import { describe, expect, it } from "vitest";
import {
  buildSmartWorkflowPlan,
  decideCompression,
  decideSubtitlePlan,
  decideAutomaticSubtitleStrategy,
  validateSmartWorkflowPlan,
  planToJobInput,
  type SmartWorkflowMediaInput,
} from "./smart-workflow";

const baseMedia: SmartWorkflowMediaInput = {
  sourcePath: "/media/Movies/Movie.mkv",
  sourceType: "video",
  sourceFingerprint: "fp-1",
  durationSeconds: 7200,
  sizeBytes: 18_000_000_000,
  streams: [
    { id: "v0", type: "video", codec: "mpeg2video", bitrate: 9_000_000, width: 1920, height: 1080 },
    { id: "a0", type: "audio", codec: "ac3", language: "en", title: "English", default: true },
    { id: "s0", type: "subtitle", codec: "subrip", language: "zh", title: "简体中文" },
  ],
  chapters: [{ id: "c1", startSeconds: 0, endSeconds: 3600 }],
};

describe("smart workflow policies", () => {
  it("carries a confirmed IMDb id into the workflow identity", () => {
    const plan = buildSmartWorkflowPlan(baseMedia, {
      identity: { title: "Movie", imdbId: "tt1234567" },
      presetIds: ["balanced"],
    });
    expect(plan.identity.imdbId).toBe("tt1234567");
  });

  it("prefers an external subtitle file for automatic LLM translation", () => {
    expect(decideAutomaticSubtitleStrategy({ streams: baseMedia.streams, externalSubtitleFiles: ["Movie.en.srt"] })).toMatchObject({
      strategy: "external-translate",
      sourcePath: "Movie.en.srt",
      runWhisper: false,
      translate: true,
    });
  });

  it("extracts an embedded subtitle before automatic LLM translation", () => {
    expect(decideAutomaticSubtitleStrategy({ streams: baseMedia.streams, externalSubtitleFiles: [] })).toMatchObject({
      strategy: "embedded-extract-translate",
      sourceSubtitleId: "s0",
      runWhisper: false,
      translate: true,
    });
  });

  it("falls back to original-language Whisper plus LLM translation when no subtitle exists", () => {
    expect(decideAutomaticSubtitleStrategy({ streams: baseMedia.streams.filter((stream) => stream.type !== "subtitle"), externalSubtitleFiles: [] })).toMatchObject({
      strategy: "whisper-original-translate",
      sourceAudioId: "a0",
      runWhisper: true,
      preserveOriginal: true,
      translate: true,
    });
  });

  it("degrades automatic subtitle processing without inventing an executor", () => {
    expect(decideAutomaticSubtitleStrategy({ streams: [], externalSubtitleFiles: [] })).toMatchObject({
      strategy: "none",
      runWhisper: false,
      translate: false,
    });
  });

  it("recommends compression for a large high-bitrate legacy source", () => {
    expect(decideCompression(baseMedia)).toMatchObject({
      recommendation: "recommend-compress",
      estimated: true,
    });
  });

  it("routes video at or below 2GB per hour to subtitle processing with no compression preset", () => {
    const plan = buildSmartWorkflowPlan({
      ...baseMedia,
      durationSeconds: 3600,
      sizeBytes: 1_800_000_000,
      streams: baseMedia.streams.filter((stream) => stream.type !== "subtitle").map((stream) => stream.type === "video" ? { ...stream, bitrate: 3_500_000 } : stream),
    }, { presetIds: ["收藏级"] });
    expect(plan.items[0].compression.recommendation).toBe("do-not-compress");
    expect(plan.items[0].action).toBe("subtitle");
    expect(plan.items[0].presetId).toBeNull();
  });

  it("leaves the action and preset blank when the caller requires explicit confirmation", () => {
    const plan = buildSmartWorkflowPlan(baseMedia, {
      presetIds: ["dvd-convert", "balanced"],
      requireExplicitAction: true,
    });
    expect(plan.items[0].action).toBe("skip");
    expect(plan.items[0].presetId).toBeNull();
  });

  it("does not recommend a second encode for an efficient low-bitrate HEVC source", () => {
    expect(decideCompression({ ...baseMedia, sizeBytes: 3_000_000_000, streams: [{ ...baseMedia.streams[0], codec: "hevc", bitrate: 2_000_000 }] })).toMatchObject({
      recommendation: "do-not-compress",
    });
  });

  it("does not recommend a second encode for a low-bitrate H.264 source", () => {
    expect(decideCompression({
      ...baseMedia,
      sizeBytes: 12_000_000_000,
      streams: [{ ...baseMedia.streams[0], codec: "h264", bitrate: 4_500_000 }],
    })).toMatchObject({
      recommendation: "do-not-compress",
    });
  });

  it("keeps Chinese text subtitles without Whisper or translation", () => {
    expect(decideSubtitlePlan(baseMedia.streams)).toMatchObject({
      mode: "keep",
      runWhisper: false,
      translate: false,
    });
  });

  it("keeps an external Chinese subtitle file and never enters speech recognition or translation", () => {
    expect(
      decideSubtitlePlan(
        baseMedia.streams.filter((stream) => stream.type !== "subtitle"),
        undefined,
        [{ path: "/media/Movies/Movie.zh.srt", hasChinese: true, language: "chi" }],
      ),
    ).toMatchObject({
      mode: "keep",
      runWhisper: false,
      translate: false,
      sourceSubtitleId: null,
    });
  });

  it("ignores a non-Chinese external subtitle file and still binds Whisper to the main audio", () => {
    expect(
      decideSubtitlePlan(
        baseMedia.streams.filter((stream) => stream.type !== "subtitle"),
        undefined,
        [{ path: "/media/Movies/Movie.en.srt", hasChinese: false, language: "eng" }],
      ),
    ).toMatchObject({
      mode: "whisper",
      runWhisper: true,
      sourceAudioId: "a0",
    });
  });

  it("exposes external Chinese subtitles on plan items so the UI can hide speech options", () => {
    const plan = buildSmartWorkflowPlan({
      ...baseMedia,
      durationSeconds: 3600,
      sizeBytes: 1_800_000_000,
      streams: baseMedia.streams.filter((stream) => stream.type !== "subtitle").map((stream) => stream.type === "video" ? { ...stream, bitrate: 3_500_000 } : stream),
      externalSubtitles: [{ path: "/media/Movies/Movie.zh.srt", hasChinese: true, language: "chi" }],
    });
    expect(plan.items[0].action).toBe("skip");
    expect(plan.items[0].subtitle.mode).toBe("keep");
    expect(plan.items[0].subtitle.translate).toBe(false);
    expect(plan.items[0].externalSubtitles?.[0].hasChinese).toBe(true);
  });

  it("translates foreign text subtitles without Whisper", () => {
    expect(decideSubtitlePlan(baseMedia.streams.map((stream) => stream.id === "s0" ? { ...stream, language: "en", title: "English" } : stream))).toMatchObject({
      mode: "translate-text",
      runWhisper: false,
      translate: true,
      sourceSubtitleId: "s0",
    });
  });

  it("binds Whisper to a real main audio stream when text subtitles are absent", () => {
    const result = decideSubtitlePlan(baseMedia.streams.filter((stream) => stream.type !== "subtitle"));
    expect(result).toMatchObject({ mode: "whisper", runWhisper: true, sourceAudioId: "a0" });
  });

  it("routes graphical subtitles to OCR instead of speech recognition", () => {
    const streams = baseMedia.streams.map((stream) => stream.id === "s0" ? { ...stream, codec: "hdmv_pgs_subtitle", language: "en" } : stream);
    expect(decideSubtitlePlan(streams)).toMatchObject({
      mode: "ocr-graphic",
      runOcr: true,
      runWhisper: false,
      translate: true,
    });
    const plan = buildSmartWorkflowPlan({ ...baseMedia, streams }, { presetIds: ["balanced"] });
    expect(planToJobInput(plan, plan.items[0]).subtitleMode).toBe("ocr");
  });

  it("rejects path conflicts and invalid preset IDs before jobs are created", () => {
    const plan = buildSmartWorkflowPlan(baseMedia, { presetIds: ["preset-dvd"] });
    plan.items.push({ ...plan.items[0], id: "duplicate", outputName: plan.items[0].outputName });
    expect(validateSmartWorkflowPlan(plan, { availablePresetIds: ["preset-dvd"] })).toContain("output path conflicts");
  });

  it("converts a confirmed item to an existing job input without embedding a command", () => {
    const plan = buildSmartWorkflowPlan(baseMedia, { presetIds: ["preset-dvd"] });
    const input = planToJobInput(plan, plan.items[0]);
    expect(input.filePath).toBe(baseMedia.sourcePath);
    expect(input).not.toHaveProperty("command");
    expect(input.selectionPlan).toContain("smart-workflow-v1");
  });

  it("preserves a selected disc title and HandBrake stream-selection payload", () => {
    const media: SmartWorkflowMediaInput = {
      ...baseMedia,
      sourceType: "dvd",
      analysisId: "analysis-1",
      titleId: "dvd-title-7",
      titleIndex: 2,
      handbrakeTitleNumber: 7,
      streams: baseMedia.streams.map((stream, index) => ({ ...stream, index, handbrakeTrackNumber: stream.type === "audio" ? 1 : stream.type === "subtitle" ? 1 : null })),
    };
    const plan = buildSmartWorkflowPlan(media, { presetIds: ["preset-dvd"] });
    const input = planToJobInput(plan, plan.items[0]);
    const selection = JSON.parse(input.selectionPlan) as { handbrake?: { titleNumber?: number }; video?: number[]; audio?: number[]; subtitle?: number[] };
    expect(input.selectedTitleId).toBe("dvd-title-7");
    expect(input.analysisId).toBe("analysis-1");
    expect(selection.handbrake?.titleNumber).toBe(7);
    expect(selection.video).toEqual([0]);
    expect(selection.audio).toEqual([1]);
    expect(selection.subtitle).toEqual([2]);
  });
});

describe("decideCompression capacity model", () => {
  it("never triggers compression for clips under 5 minutes", () => {
    const decision = decideCompression({
      ...baseMedia,
      durationSeconds: 240,
      sizeBytes: 800_000_000,
      mediaType: "movie",
    });
    expect(decision.recommendation).toBe("do-not-compress");
    expect(decision.estimatedOutputBytes).toBeNull();
  });

  it("estimates output size from the capacity model (movie 8GB, H.265 -30%)", () => {
    const decision = decideCompression({
      ...baseMedia,
      durationSeconds: 7200,
      sizeBytes: 18_000_000_000,
      mediaType: "movie",
    });
    expect(decision.recommendation).toBe("recommend-compress");
    expect(decision.estimatedOutputBytes).toBeCloseTo(8_000_000_000, -6);

    const h265 = decideCompression({
      ...baseMedia,
      durationSeconds: 7200,
      sizeBytes: 14_000_000_000,
      streams: [{ id: "v0", type: "video", codec: "hevc", bitrate: 9_000_000 }],
      mediaType: "movie",
    });
    expect(h265.estimatedOutputBytes).toBeCloseTo(8_000_000_000 * 0.7, -6);
  });

  it("marks documentary sources by filename keywords", () => {
    const decision = decideCompression({
      ...baseMedia,
      displayName: "BBC Planet Earth Documentary",
      durationSeconds: 3000,
      sizeBytes: 5_000_000_000,
    });
    expect(decision.documentary).toBe(true);
  });
});
