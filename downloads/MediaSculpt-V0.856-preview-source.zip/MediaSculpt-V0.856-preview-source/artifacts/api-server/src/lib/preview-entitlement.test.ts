import { describe, expect, it } from "vitest";
import {
  createPreviewState,
  evaluatePreviewStatus,
  previewErrorCode,
  type PreviewPolicy,
} from "./preview-entitlement";

const policy: PreviewPolicy = { taskLimit: 20, trialDays: 30 };
const date = (value: string) => new Date(value);

describe("preview entitlement policy", () => {
  it("starts a preview at 20 tasks and expires after 30 days", () => {
    const state = createPreviewState(date("2026-09-14T04:00:00.000Z"), "install-1", policy);

    expect(state.edition).toBe("preview");
    expect(state.successfulTaskCount).toBe(0);
    expect(state.expiresAt.toISOString()).toBe("2026-10-14T04:00:00.000Z");
    expect(evaluatePreviewStatus(state, date("2026-09-20T04:00:00.000Z"), policy)).toMatchObject({
      isActive: true,
      taskLimit: 20,
      remainingTasks: 20,
      daysRemaining: 24,
      blockedReason: null,
    });
  });

  it("blocks on quota and expiry", () => {
    const state = createPreviewState(date("2026-09-14T00:00:00.000Z"), "install-1", policy);

    expect(evaluatePreviewStatus({ ...state, successfulTaskCount: 20 }, date("2026-09-20T00:00:00.000Z"), policy)).toMatchObject({
      isActive: false,
      remainingTasks: 0,
      blockedReason: "quota_exhausted",
    });
    expect(evaluatePreviewStatus(state, date("2026-10-14T00:00:00.000Z"), policy)).toMatchObject({
      isActive: false,
      daysRemaining: 0,
      blockedReason: "expired",
    });
  });

  it("detects a clock moving backwards", () => {
    const state = {
      ...createPreviewState(date("2026-09-14T00:00:00.000Z"), "install-1", policy),
      lastSeenAt: date("2026-09-20T00:00:00.000Z"),
    };

    expect(evaluatePreviewStatus(state, date("2026-09-19T00:00:00.000Z"), policy)).toMatchObject({
      isActive: false,
      blockedReason: "clock_invalid",
    });
    expect(previewErrorCode("clock_invalid")).toBe("PREVIEW_LIMIT_CLOCK_INVALID");
  });

  it("leaves the development channel unlimited", () => {
    const preview = createPreviewState(date("2026-09-14T00:00:00.000Z"), "install-1", policy);
    const development = { ...preview, edition: "development" as const, successfulTaskCount: 999 };

    expect(evaluatePreviewStatus(development, date("2030-01-01T00:00:00.000Z"), policy)).toMatchObject({
      edition: "development",
      isActive: true,
      taskLimit: null,
      remainingTasks: null,
      blockedReason: null,
    });
  });
});
