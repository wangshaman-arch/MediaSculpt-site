import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { describe, expect, it } from "vitest";
import {
  AACS_DIRECTORY,
  AACS_UNIT_KEY_FILE,
  BDSVM_DIRECTORY,
  BLURAY_ENCRYPTED_WARNING_CODE,
  detectBlurayEncryption,
} from "./bluray-encryption";

async function makeDisc(files: string[]): Promise<string> {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), "vx-bd-enc-"));
  for (const relative of files) {
    const target = path.join(root, relative);
    if (relative.endsWith("/")) {
      await fs.mkdir(target, { recursive: true });
    } else {
      await fs.mkdir(path.dirname(target), { recursive: true });
      await fs.writeFile(target, "x");
    }
  }
  return root;
}

describe("Blu-ray AACS encryption detection", () => {
  it("flags a disc that carries the AACS directory and its unit key", async () => {
    const root = await makeDisc([`${AACS_DIRECTORY}/${AACS_UNIT_KEY_FILE}`, "BDMV/PLAYLIST/"]);
    const result = await detectBlurayEncryption(root);
    expect(result.encrypted).toBe(true);
    expect(result.evidence).toContain(AACS_UNIT_KEY_FILE);
    await fs.rm(root, { recursive: true, force: true });
  });

  it("flags a disc that carries only the AACS directory", async () => {
    const root = await makeDisc([`${AACS_DIRECTORY}/`]);
    const result = await detectBlurayEncryption(root);
    expect(result.encrypted).toBe(true);
    expect(result.evidence).toBe(`${AACS_DIRECTORY}/`);
    await fs.rm(root, { recursive: true, force: true });
  });

  it("flags a BD+ disc through the BDSVM directory", async () => {
    const root = await makeDisc([`${BDSVM_DIRECTORY}/`]);
    const result = await detectBlurayEncryption(root);
    expect(result.encrypted).toBe(true);
    expect(result.evidence).toBe(`${BDSVM_DIRECTORY}/`);
    await fs.rm(root, { recursive: true, force: true });
  });

  // Regression guard for false positives: real unencrypted retail rips carry
  // CERTIFICATE/ but neither AACS/ nor BDSVM/, and must stay unflagged.
  it("does not flag an unencrypted disc that only has CERTIFICATE and BDMV", async () => {
    const root = await makeDisc(["CERTIFICATE/", "BDMV/PLAYLIST/", "BDMV/STREAM/"]);
    const result = await detectBlurayEncryption(root);
    expect(result.encrypted).toBe(false);
    expect(result.evidence).toBeNull();
    await fs.rm(root, { recursive: true, force: true });
  });

  it("accepts the BDMV directory itself and resolves the disc root", async () => {
    const root = await makeDisc([`${AACS_DIRECTORY}/${AACS_UNIT_KEY_FILE}`, "BDMV/PLAYLIST/"]);
    const viaBdmv = await detectBlurayEncryption(path.join(root, "BDMV"));
    expect(viaBdmv.encrypted).toBe(true);
    await fs.rm(root, { recursive: true, force: true });
  });

  it("treats an unreadable or empty path as not encrypted instead of throwing", async () => {
    expect(await detectBlurayEncryption("")).toEqual({ encrypted: false, evidence: null });
    const missing = path.join(os.tmpdir(), "vx-does-not-exist-" + Date.now());
    expect(await detectBlurayEncryption(missing)).toEqual({ encrypted: false, evidence: null });
  });

  it("exposes a stable warning code so the UI can localise the message", () => {
    expect(BLURAY_ENCRYPTED_WARNING_CODE).toBe("bluray-aacs-encrypted");
  });
});
