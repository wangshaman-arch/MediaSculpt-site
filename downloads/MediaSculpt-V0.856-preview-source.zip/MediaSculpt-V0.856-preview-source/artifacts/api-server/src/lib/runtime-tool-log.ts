import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";

export function diagnosticsLogPath(): string {
  return process.env.MEDIASCULPT_DIAGNOSTICS_LOG ?? process.env.VX_AGENT_DIAGNOSTICS_LOG ??
    path.resolve(process.cwd(), "..", "..", "mediasculpt-diagnostics.log");
}

export function serviceLogDirectory(): string {
  return process.env.MEDIASCULPT_SERVICE_LOG_DIR ?? process.env.VX_AGENT_SERVICE_LOG_DIR ?? path.join(os.tmpdir(), "MediaSculpt", "logs");
}

export function runtimeToolLogPath(): string {
  return process.env.MEDIASCULPT_RUNTIME_TOOLS_LOG_PATH ?? process.env.VX_AGENT_RUNTIME_TOOLS_LOG_PATH ??
    path.join(serviceLogDirectory(), "tool-events.tmp.log");
}

export type RuntimeToolOutput = {
  tool: string;
  executable: string;
  args: string[];
  exitCode: number | null;
  durationMs: number;
  stdout: string;
  stderr: string;
};

export async function appendRuntimeToolLog(message: string): Promise<void> {
  const logPath = runtimeToolLogPath();
  await fs.mkdir(path.dirname(logPath), { recursive: true });
  const timestamp = new Date().toISOString();
  const line = `[${timestamp}] ${message}\n`;
  await fs.appendFile(logPath, line, "utf8");
  const diagnosticsPath = diagnosticsLogPath();
  if (path.resolve(diagnosticsPath) !== path.resolve(logPath)) {
    await fs.mkdir(path.dirname(diagnosticsPath), { recursive: true }).catch(() => {});
    await fs.appendFile(diagnosticsPath, `===== RUNTIME TOOL =====\n${line}`, "utf8").catch(() => {});
  }
}

/** Preserve raw external-tool output in the one file users upload for diagnosis. */
export async function appendRuntimeToolOutput(output: RuntimeToolOutput): Promise<void> {
  const section = [
    `===== TOOL OUTPUT ${output.tool.toUpperCase()} =====`,
    `timestamp=${new Date().toISOString()}`,
    `executable=${output.executable}`,
    `args=${JSON.stringify(output.args)}`,
    `exitCode=${output.exitCode ?? "null"}`,
    `durationMs=${output.durationMs}`,
    "--- stdout ---",
    output.stdout || "(empty)",
    "--- stderr ---",
    output.stderr || "(empty)",
    "--- end tool output ---",
    "",
  ].join("\n");
  const logPath = runtimeToolLogPath();
  await fs.mkdir(path.dirname(logPath), { recursive: true });
  await fs.appendFile(logPath, section, "utf8");
  const diagnosticsPath = diagnosticsLogPath();
  if (path.resolve(diagnosticsPath) !== path.resolve(logPath)) {
    await fs.mkdir(path.dirname(diagnosticsPath), { recursive: true }).catch(() => {});
    await fs.appendFile(diagnosticsPath, section, "utf8").catch(() => {});
  }
}

export function formatError(error: unknown): string {
  if (error instanceof Error) return `${error.name}: ${error.message}\n${error.stack ?? ""}`.trim();
  return String(error);
}
