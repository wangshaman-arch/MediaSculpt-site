// Extracted from disc-analysis.ts: DVD analysis with ffprobe fallback.
import { createHash } from "node:crypto";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs/promises";
import type { Dirent } from "node:fs";
import os from "node:os";
import path from "node:path";
import { consolidateDvdHandBrakeTitles, parseHandBrakeScanOutput, type HandBrakeChapter, type HandBrakeStream, type HandBrakeTitle } from "./handbrake-scan";
import { dvdTitleInputArgs, resolveDvdVideoTsDir, scanBlurayPlaylists, type BlurayPlaylistInfo } from "./disc";
import { resolveToolPath } from "./tool-runtime";
import { analyzeDvdWithHandBrake, type ExternalToolRunner } from "./dvd-remux";
import { buildDvdStreamUid, buildDvdTitleUid } from "./dvd-manifest";


const execFileAsync = promisify(execFile);
const MAX_TOOL_BUFFER = 32 * 1024 * 1024;
import {
  safeNumber,
  MIN_DISC_TITLE_SECONDS,
  MAX_DISC_TITLES,
  type DiscAnalysisTrackType,
  type DiscAnalysisStream,
  type DiscAnalysisChapter,
  type DiscToolDiagnostic,
  type UnifiedDiscTitle,
} from "./disc-analysis";

/** Resolve the VIDEO_TS folder for a disc root (accepts the root or the folder itself). */
function findVideoTsDirSync(discRoot: string): string {
  return /[\\/]VIDEO_TS$/i.test(discRoot) ? discRoot : path.join(discRoot, "VIDEO_TS");
}

/**
 * Fallback for DVDs that HandBrakeCLI cannot parse to a usable title set.
 * Probe the logical dvdvideo title namespace directly. VTS_XX is a physical
 * title-set number and must never be passed as a logical -title value.
 * Only runs when HandBrakeCLI returned no usable title, so discs that
 * HandBrakeCLI parses successfully are left completely untouched.
 */
export async function analyzeDvdWithFfprobeFallback(
  discRoot: string,
  sourceFingerprint: string,
): Promise<{ titles: UnifiedDiscTitle[]; diagnostic: DiscToolDiagnostic | null }> {
  const ffprobe = (await resolveToolPath("ffprobe")) ?? "ffprobe";
  const dvdTitles = Array.from({ length: 32 }, (_v, index) => ({
    titleNumber: index + 1,
    discRoot,
    videoTsDir: findVideoTsDirSync(discRoot),
    ifoPath: "",
    vobFiles: [] as string[],
    sizeBytes: 0,
  }));
  const titles: UnifiedDiscTitle[] = [];
  let representative: DiscToolDiagnostic | null = null;
  for (const dvd of dvdTitles) {
    if (dvd.titleNumber <= 0) continue;
    const args = ["-v", "error", "-show_streams", "-show_format", "-show_chapters", "-print_format", "json", ...dvdTitleInputArgs(dvd)];
    const startedAt = new Date();
    let stdout = "";
    let stderr = "";
    let exitCode: number | null = null;
    try {
      const result = await execFileAsync(ffprobe, args, { timeout: 60_000, maxBuffer: MAX_TOOL_BUFFER, windowsHide: true });
      stdout = String(result.stdout ?? "");
      stderr = String(result.stderr ?? "");
      exitCode = 0;
    } catch (error) {
      const e = error as { code?: unknown; stdout?: unknown; stderr?: unknown };
      exitCode = typeof e.code === "number" ? e.code : null;
      stdout = String(e.stdout ?? "");
      stderr = String(e.stderr ?? "");
    }
    if (!representative) {
      representative = {
        tool: "ffprobe", executable: ffprobe, args,
        startedAt: startedAt.toISOString(), finishedAt: new Date().toISOString(),
        durationMs: Date.now() - startedAt.getTime(), exitCode, stdout, stderr,
        failureReason: exitCode === 0 ? null : "ffprobe dvdvideo 探测失败",
      };
    }
    if (exitCode !== 0) continue;
    const info = (() => {
      try { return JSON.parse(stdout) as { streams?: Array<Record<string, unknown>>; format?: { duration?: string }; chapters?: Array<Record<string, unknown>> }; } catch { return {}; }
    })();
    const rawStreams: DiscAnalysisStream[] = (info.streams ?? []).map((s) => ({
      index: Number(s.index),
      codecType: (["video", "audio", "subtitle"].includes(String(s.codec_type)) ? String(s.codec_type) as DiscAnalysisTrackType : "unknown"),
      codecName: s.codec_name != null ? String(s.codec_name) : null,
      profile: s.profile != null ? String(s.profile) : null,
      language: (s.tags as Record<string, unknown> | undefined)?.language != null ? String((s.tags as Record<string, unknown>).language) : null,
      title: (s.tags as Record<string, unknown> | undefined)?.title != null ? String((s.tags as Record<string, unknown>).title) : null,
      width: s.width != null ? Number(s.width) : null,
      height: s.height != null ? Number(s.height) : null,
      channels: s.channels != null ? Number(s.channels) : null,
      channelLayout: s.channel_layout != null ? String(s.channel_layout) : null,
      sampleRate: s.sample_rate != null ? Number(s.sample_rate) : null,
      frameRate: s.avg_frame_rate != null ? String(s.avg_frame_rate) : null,
      ...(s.bits_per_raw_sample != null ? { bitsPerRawSample: Number(s.bits_per_raw_sample) } : {}),
    }));
    const titleUid = buildDvdTitleUid({ sourceFingerprint, handbrakeTitleNumber: dvd.titleNumber });
    const streams = rawStreams.map((stream, index) => ({
      ...stream,
      trackUid: buildDvdStreamUid({
        titleUid,
        type: stream.codecType === "unknown" ? "video" : stream.codecType,
        ordinal: rawStreams.slice(0, index).filter((candidate) => candidate.codecType === stream.codecType).length,
        codecName: stream.codecName,
        language: stream.language,
        channels: stream.channels,
      }),
    }));
    const duration = info.format?.duration != null ? safeNumber(info.format.duration) : null;
    const chapters: DiscAnalysisChapter[] = (info.chapters ?? []).map((c, i) => ({
      id: Number(c.id ?? i + 1),
      startSeconds: safeNumber(c.start_time) ?? 0,
      endSeconds: safeNumber(c.end_time) ?? safeNumber(c.start_time) ?? 0,
      title: (c.tags as Record<string, unknown> | undefined)?.title != null ? String((c.tags as Record<string, unknown>).title) : null,
    }));
    // dvdvideo title numbers are global logical PGC numbers; they are not VTS
    // file-group numbers. Do not pair a fallback title with VTS_NN merely
    // because the numeric values happen to be equal.
    const previewSourcePath = null;
    if (!duration || duration < MIN_DISC_TITLE_SECONDS || !streams.some((stream) => stream.codecType === "video")) continue;
      titles.push({
        titleId: `dvd-title:${dvd.titleNumber}`,
        titleUid,
        titleIndex: titles.length,
        sourcePath: discRoot,
        titleKind: null,
        previewSourcePath,
        displayName: `Title ${titles.length + 1}`,
        durationSeconds: duration,
        chapterCount: chapters.length,
        chapters,
        videoTracks: streams.filter((stream) => stream.codecType === "video"),
        audioTracks: streams.filter((stream) => stream.codecType === "audio"),
        subtitleTracks: streams.filter((stream) => stream.codecType === "subtitle"),
        estimatedSize: null,
        streams,
        toolMappings: { handbrakeTitleNumber: dvd.titleNumber, makemkvTitleIndex: null, dvdVtsNumber: null },
        mappingStatus: "not-required",
        verificationStatus: "pending",
        verificationFailureReason: null,
      });
  }
  return { titles, diagnostic: representative };
}
