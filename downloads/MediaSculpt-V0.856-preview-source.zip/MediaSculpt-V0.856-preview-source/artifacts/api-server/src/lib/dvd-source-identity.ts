import path from "node:path";

export type DiscOutputMediaType = "dvd" | "bluray" | "iso" | string | null | undefined;

function sourcePathApi(sourcePath: string): typeof path | typeof path.win32 {
  return /^[A-Za-z]:[\\/]/.test(sourcePath) || sourcePath.includes("\\") ? path.win32 : path;
}

function sourceDirectoryName(sourcePath: string): string {
  const api = sourcePathApi(sourcePath);
  const normalized = sourcePath.replace(/[\\/]+$/, "");
  const base = api.basename(normalized);
  if (/^(VIDEO_TS|BDMV)$/i.test(base)) return api.basename(api.dirname(normalized));
  if (/^(?:VTS_\d{2}_\d|VIDEO_TS)\.(?:IFO|BUP|VOB)$/i.test(base)) {
    const container = api.basename(api.dirname(normalized));
    return /^(VIDEO_TS|BDMV)$/i.test(container)
      ? api.basename(api.dirname(api.dirname(normalized)))
      : container;
  }
  return base;
}

/** Remove disc/container labels from the human identity encoded by a DVD path. */
export function dvdSourceBaseName(sourcePath: string): string {
  const raw = sourceDirectoryName(sourcePath).trim();
  if (!raw) return "Untitled";
  const withoutTechnicalSuffix = raw
    .replace(/[ ._-]+Title\d+$/i, "")
    .replace(/[ ._-]+(?:VIDEO_TS|DVD(?:[- ]?[59])?|DVD-?ROM|ISO)$/i, "")
    .trim();
  return (withoutTechnicalSuffix
    .replace(/[（(]\s*((?:19|20)\d{2})\s*[)）]/g, " $1")
    .replace(/\s+/g, " ")
    .trim()) || raw;
}

/** Use a logical title number only when multiple usable DVD titles need disambiguation. */
export function dvdTitleSuffix(input: {
  mediaType: DiscOutputMediaType;
  titleNumber?: number | null;
  titleCount?: number | null;
}): string {
  if (input.mediaType !== "dvd") return "";
  const titleNumber = input.titleNumber ?? 0;
  const titleCount = input.titleCount ?? 0;
  if (!Number.isInteger(titleNumber) || titleNumber <= 0 || titleCount <= 1) return "";
  return `.Title${String(titleNumber).padStart(2, "0")}`;
}

export function dvdOutputBaseName(input: {
  sourcePath: string;
  mediaType: DiscOutputMediaType;
  titleNumber?: number | null;
  titleCount?: number | null;
}): string {
  const base = input.mediaType === "dvd" ? dvdSourceBaseName(input.sourcePath) : sourceDirectoryName(input.sourcePath);
  return `${base}${dvdTitleSuffix(input)}`;
}
