import { deflateSync, inflateSync } from "node:zlib";
import { createHash } from "node:crypto";
import path from "node:path";
import { access } from "node:fs/promises";
import { resolveAiEndpoint, resolveApiKey, type AiProviderConfig } from "./ai-provider";
import { resolveToolPath } from "./tool-runtime";
import { findDvdTitles, resolveDvdVideoTsDir } from "./disc";
import { isGraphicSubtitleCodec } from "./subtitle-utils";

// ── Types ─────────────────────────────────────────────────────────────────────
export type OcrEvent = {
  index: number;
  startMs: number;
  endMs: number;
  text: string;
};

export type OcrEngine = "llm" | "tesseract" | "subtitleedit" | "rapidocr" | "auto";

const PGS_SUBTITLE_CODECS = new Set(["hdmv_pgs_subtitle", "pgssub", "sup"]);

/**
 * Build a lossless sidecar export for a graphic subtitle track. PGS has a
 * native SUP carrier; DVD VobSub must stay in a Matroska stream because FFmpeg
 * can demux VobSub but does not provide a VobSub pair muxer.
 */
export function buildGraphicSubtitleExportArgs(input: {
  sourceInputArgs: readonly string[];
  subtitleTypeIndex: number;
  codec: string;
  outputBasePath: string;
}): string[] | null {
  if (!Number.isInteger(input.subtitleTypeIndex) || input.subtitleTypeIndex < 0) return null;
  const codec = input.codec.trim().toLowerCase();
  const isPgs = PGS_SUBTITLE_CODECS.has(codec);
  const isVobSub = codec === "dvd_subtitle" || codec === "vobsub";
  if (!isPgs && !isVobSub) return null;
  const extension = isPgs ? ".sup" : ".mkv";
  const format = isPgs ? "sup" : "matroska";
  return [
    "-y", "-hide_banner",
    ...input.sourceInputArgs,
    "-map", `0:s:${input.subtitleTypeIndex}`,
    "-c:s", "copy",
    "-f", format,
    `${input.outputBasePath}${extension}`,
  ];
}

/** Codecs that FFmpeg can expose directly as timed bitmap frames. */
export function isDirectFrameGraphicCodec(codec: string): boolean {
  const normalized = codec.trim().toLowerCase();
  return isGraphicSubtitleCodec(normalized) && !PGS_SUBTITLE_CODECS.has(normalized);
}

/** Resolve media tools through the managed tool directory before falling back to PATH. */
export async function resolveSubtitleToolPath(
  tool: "ffmpeg" | "ffprobe",
  resolver: (name: "ffmpeg" | "ffprobe") => Promise<string | null> = resolveToolPath,
): Promise<string> {
  try {
    const resolved = await resolver(tool);
    return resolved?.trim() || tool;
  } catch {
    return tool;
  }
}

export type OcrResult = {
  srtPath: string;
  srtContent: string;
  events: OcrEvent[];
  language: string;
  engine: OcrEngine;
  /** 0-100 recognition quality estimate (confidence-based or heuristic). */
  qualityScore: number;
  /** Whether the score came from engine confidence (vs text heuristics). */
  qualityConfidenceBased: boolean;
};

export function computeOcrQuality(
  recognized: Array<{ text: string; confidence?: number | null }>,
  totalEvents: number,
): { score: number; confidenceBased: boolean } {
  const nonEmpty = recognized.filter((item) => item.text.trim().length > 0);
  const emptyRatio = totalEvents > 0 ? 1 - nonEmpty.length / totalEvents : 1;
  const confidences = recognized
    .map((item) => item.confidence)
    .filter((value): value is number => typeof value === "number" && Number.isFinite(value));
  if (confidences.length > 0) {
    const average = confidences.reduce((sum, value) => sum + value, 0) / confidences.length;
    // rapidocr reports 0..1, tesseract tsv reports 0..100.
    const normalized = average <= 1 ? average * 100 : average;
    return { score: Math.round(Math.max(0, Math.min(100, normalized * (1 - emptyRatio * 0.5)))), confidenceBased: true };
  }
  let score = (1 - emptyRatio) * 80;
  const shortLines = nonEmpty.filter((item) => item.text.trim().length <= 1).length;
  score -= (shortLines / Math.max(nonEmpty.length, 1)) * 30;
  return { score: Math.round(Math.max(0, Math.min(100, score))), confidenceBased: false };
}

import { detectScriptLanguage, OCR_LANGUAGE_CODES, ISO_TO_TESSERACT, mapTesseractLanguage, languageMatchesRequest, findTessdataDirectoryForTesseract, ensureTesseractLanguageData, HAN, KANA, HANGUL, CYRILLIC, GREEK, THAI, ARABIC, HEBREW, DEVANAGARI, LATIN } from "./subtitle-ocr-language";
export { detectScriptLanguage, OCR_LANGUAGE_CODES, ISO_TO_TESSERACT, mapTesseractLanguage, languageMatchesRequest, findTessdataDirectoryForTesseract, ensureTesseractLanguageData, type OcrLanguageCode } from "./subtitle-ocr-language";
/**
 * Candidate languages used when the subtitle track has no language tag and the
 * OCR preset is "auto". Only languages whose traineddata is actually installed
 * are tried, and the script that scores highest on the sampled frame wins.
 */
const AUTO_LANGUAGE_CANDIDATES = ["rus", "eng", "chi_sim", "chi_tra", "jpn", "kor", "deu", "fra", "spa", "ara"];

export async function detectAutoTesseractLanguage(
  tesseractPath: string,
  images: Array<{ index: number; png: Buffer }>,
): Promise<string> {
  const tessdata = await findTessdataDirectoryForTesseract(tesseractPath);
  const available: string[] = [];
  if (tessdata) {
    for (const lang of AUTO_LANGUAGE_CANDIDATES) {
      try {
        await access(path.join(tessdata, `${lang}.traineddata`));
        available.push(lang);
      } catch {
        // Language data not installed - skip this candidate.
      }
    }
  }
  if (available.length === 0) return "eng";
  const samples = [
    images[0],
    images[Math.floor(images.length / 2)],
    images[images.length - 1],
  ].filter((image): image is { index: number; png: Buffer } => Boolean(image));
  if (samples.length === 0) return "eng";
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const { mkdtemp, writeFile, rm } = await import("node:fs/promises");
  const { tmpdir } = await import("node:os");
  const { join } = await import("node:path");
  const execFileAsync = promisify(execFile);
  const dir = await mkdtemp(join(tmpdir(), "vx-tess-detect-"));
  try {
    const scores = new Map<string, number>(available.map((lang) => [lang, 0]));
    let sampleIndex = 0;
    for (const sample of samples) {
      sampleIndex += 1;
      const input = join(dir, `sample-${sampleIndex}.png`);
      await writeFile(input, sample.png);
      const texts = new Map<string, string>();
      let sampleTextChars = 0;
      for (const lang of available) {
        let text = "";
        try {
          const { stdout } = await execFileAsync(tesseractPath, [input, "stdout", "-l", lang, "--psm", "6"], { timeout: 30_000 });
          text = stdout;
        } catch {
          // Keep an empty sample for this candidate.
        }
        texts.set(lang, text);
        sampleTextChars += text.length;
      }
      // Skip ambiguous frames (no text recognized by any candidate).
      if (sampleTextChars < 4) continue;
      for (const [lang, text] of texts) {
        const cyr = (text.match(CYRILLIC) || []).length;
        const han = (text.match(HAN) || []).length;
        const kana = (text.match(KANA) || []).length;
        const hangul = (text.match(HANGUL) || []).length;
        const arabic = (text.match(ARABIC) || []).length;
        const latin = (text.match(LATIN) || []).length;
        let score: number;
        if (lang === "rus") score = cyr * 3 - latin;
        else if (lang === "chi_sim" || lang === "chi_tra") score = han * 3 - latin;
        else if (lang === "jpn") score = kana * 3 + han - latin;
        else if (lang === "kor") score = hangul * 3 - latin;
        else if (lang === "ara") score = arabic * 3 - latin;
        else score = latin * 2 - cyr - han - kana - hangul - arabic;
        scores.set(lang, (scores.get(lang) ?? 0) + score);
      }
    }
    let best = "eng";
    let bestScore = -Infinity;
    for (const [lang, score] of scores) {
      if (score > bestScore || (score === bestScore && lang === "eng" && best !== "eng")) {
        bestScore = score;
        best = lang;
      }
    }
    return bestScore > 0 ? best : "eng";
  } finally {
    await rm(dir, { recursive: true, force: true }).catch(() => {});
  }
}

/**
 * Resolve the effective OCR engine and language before any heavy extraction.
 * "auto" prefers the local Tesseract and falls back to a vision-capable LLM;
 * any missing dependency raises an actionable error immediately so the queue
 * fails in seconds instead of after a 10-20 minute DVD transcode.
 */
export async function resolveOcrEngineAndLanguage(params: {
  config: AiProviderConfig;
  engine?: OcrEngine;
  language?: string;
  streamLanguage?: string | null;
}): Promise<{ engine: OcrEngine; ocrLanguage: string }> {
  const requested: OcrEngine = params.engine ?? "auto";
  const language = params.language ?? "auto";
  let engine: OcrEngine = requested;
  if (engine === "auto") {
    const tesseract = await resolveToolPath("tesseract");
    const rapidOcr = await resolveToolPath("rapidocr");
    const isChineseTrack = params.streamLanguage
      ? ["zho", "chi", "zh", "cmn"].includes(params.streamLanguage.toLowerCase())
      : false;
    // Chinese tracks strongly prefer RapidOCR (PP-OCRv4) over Tesseract.
    if (isChineseTrack && rapidOcr) {
      engine = "rapidocr";
    } else if (tesseract) {
      engine = "tesseract";
    } else if (rapidOcr) {
      engine = "rapidocr";
    } else {
      const endpoint = resolveAiEndpoint(params.config);
      const key = resolveApiKey(params.config);
      if (key && isVisionCapable(endpoint.provider, endpoint.model)) {
        engine = "llm";
      } else {
        throw new Error(
          "OCR 引擎不可用：本机未安装 Tesseract / RapidOCR，且当前 AI 模型不支持图片输入。请先在「设置 → 工具」中安装 Tesseract OCR 或 RapidOCR（推荐），" +
          "或在 AI 设置中配置支持视觉的模型（如 gpt-4o / qwen-vl / glm-4v / gemini）。",
        );
      }
    }
  }
  if (engine === "tesseract") {
    const tesseractPath = await resolveToolPath("tesseract");
    if (!tesseractPath) {
      throw new Error("未找到本地 Tesseract。请先在「设置 → 工具」中安装 Tesseract OCR（含语言数据），或改选“大模型识别”。");
    }
    const ocrLanguage = mapTesseractLanguage(language, params.streamLanguage ?? null);
    await ensureTesseractLanguageData(tesseractPath, ocrLanguage);
    return { engine, ocrLanguage };
  }
  if (engine === "llm") {
    const endpoint = resolveAiEndpoint(params.config);
    const key = resolveApiKey(params.config);
    if (!key) throw new Error("未配置当前 AI 提供商的 API Key，无法使用大模型 OCR");
    if (!isVisionCapable(endpoint.provider, endpoint.model)) {
      throw new Error(
        `当前模型 ${endpoint.model} 不支持图片输入，请在设置中切换到支持视觉的模型（如 gpt-4o / qwen-vl / glm-4v / gemini），` +
        "或安装本地 Tesseract。",
      );
    }
    return { engine, ocrLanguage: language };
  }
  if (engine === "rapidocr") {
    const python = await resolveToolPath("rapidocr");
    if (!python) {
      throw new Error("未找到 RapidOCR。请先在「设置 → 工具」中安装 RapidOCR（中文识别推荐），或改选其它引擎。");
    }
    return { engine, ocrLanguage: language };
  }
  throw new Error(`OCR 引擎 "${engine}" 尚未实现，当前支持 "llm"（大模型视觉识别）、"tesseract"（本地 OCR）和 "rapidocr"（中文 OCR）`);
}

import { tesseractLanguageToIso, ocrWithTesseract, parseTesseractTsv } from "./subtitle-ocr-tesseract";
export { tesseractLanguageToIso, ocrWithTesseract, parseTesseractTsv } from "./subtitle-ocr-tesseract";

/** Batch OCR script executed by the RapidOCR venv python. */
const RAPID_OCR_BATCH_SCRIPT = `import sys, os, json, glob
from rapidocr_onnxruntime import RapidOCR
engine = RapidOCR()
input_dir = sys.argv[1]
output_file = sys.argv[2]
out = {}
for path in glob.glob(os.path.join(input_dir, "frame_*.png")):
    idx = os.path.splitext(os.path.basename(path))[0].replace("frame_", "")
    try:
        result, _ = engine(path)
        lines = [item[1] for item in result] if result else []
        confs = [float(item[2]) for item in result if len(item) > 2]
        out[idx] = {"text": "\\n".join(lines), "conf": (sum(confs) / len(confs)) if confs else None}
    except Exception:
        out[idx] = {"text": "", "conf": None}
with open(output_file, "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False)
`;

/**
 * OCR subtitle frames with RapidOCR (PP-OCRv4, strong Chinese support). All
 * frames are processed by a single Python process to avoid per-frame startup
 * cost, then mapped back by index.
 */
export async function ocrWithRapidOcr(
  images: Array<{ index: number; png: Buffer }>,
): Promise<Array<{ index: number; text: string; language: string; confidence?: number | null }>> {
  const { mkdtemp, writeFile, readFile, rm } = await import("node:fs/promises");
  const { tmpdir } = await import("node:os");
  const { join } = await import("node:path");
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const execFileAsync = promisify(execFile);
  const python = await resolveToolPath("rapidocr");
  if (!python) {
    throw new Error("未找到 RapidOCR（中文 OCR）。请先在「设置 → 工具」中安装 RapidOCR，或改用其它 OCR 引擎。");
  }
  const dir = await mkdtemp(join(tmpdir(), "vx-rapid-"));
  const scriptPath = join(dir, "batch.py");
  const outPath = join(dir, "out.json");
  try {
    await writeFile(scriptPath, RAPID_OCR_BATCH_SCRIPT, "utf8");
    for (const image of images) {
      await writeFile(join(dir, `frame_${image.index}.png`), image.png);
    }
    await execFileAsync(python, [scriptPath, dir, outPath], { timeout: 30 * 60_000, maxBuffer: 20 * 1024 * 1024 });
    const raw = await readFile(outPath, "utf8");
    const parsed = JSON.parse(raw) as Record<string, { text?: string; conf?: number | null }>;
    return images.map((image) => {
      const entry = parsed[String(image.index)] ?? {};
      const text = cleanupCjkSpacing((entry.text ?? "").trim());
      const language = /[\u3400-\u9fff]/.test(text) ? "zh" : /[a-zA-Z]/.test(text) ? "en" : "unknown";
      return { index: image.index, text, language, confidence: typeof entry.conf === "number" ? entry.conf : null };
    });
  } finally {
    await rm(dir, { recursive: true, force: true }).catch(() => {});
  }
}

// ── SRT assembly ──────────────────────────────────────────────────────────────
export function formatSrtTime(ms: number): string {
  const total = Math.max(0, Math.round(ms));
  const h = Math.floor(total / 3_600_000);
  const m = Math.floor((total % 3_600_000) / 60_000);
  const s = Math.floor((total % 60_000) / 1000);
  const millis = total % 1000;
  const pad = (v: number, n = 2) => String(v).padStart(n, "0");
  return `${pad(h)}:${pad(m)}:${pad(s)},${pad(millis, 3)}`;
}

export function assembleSrt(events: OcrEvent[]): string {
  return events
    .filter((event) => event.text.trim().length > 0)
    .map((event, index) => `${index + 1}\n${formatSrtTime(event.startMs)} --> ${formatSrtTime(event.endMs)}\n${event.text.trim()}`)
    .join("\n\n") + (events.length > 0 ? "\n" : "");
}

/** Tesseract inserts spaces between CJK glyphs; remove them for readability. */
export function cleanupCjkSpacing(text: string): string {
  return text.replace(
    /([\u3400-\u4dbf\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af])\s+(?=[\u3400-\u4dbf\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af])/g,
    "$1",
  );
}

/** Expected minimum dialog-subtitle lines for a video duration. */
async function probeVideoDurationMs(videoPath: string): Promise<number | null> {
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const execFileAsync = promisify(execFile);
  try {
    const ffprobe = (await resolveToolPath("ffprobe")) ?? "ffprobe";
    const { stdout } = await execFileAsync(ffprobe, ["-v", "error", "-print_format", "json", "-show_entries", "format=duration", videoPath], { timeout: 30_000 });
    const parsed = JSON.parse(stdout) as { format?: { duration?: string } };
    const seconds = Number(parsed.format?.duration);
    return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1000) : null;
  } catch {
    return null;
  }
}

/**
 * OCR 结果双向校验（以源字幕轨为真值，不再按时长估算行数）：
 * 1. 源轨完整性：时间覆盖 <80%（能探测时长且 ≥10 分钟时）→ 源字幕轨疑似残缺/损坏；
 * 2. OCR 完整性：已识别非空条数 < 源条数的 90% → OCR 漏识/失败。
 * 源条数在识别前即可统计，音乐/纪录片等对白稀疏但字幕完整的内容不再被误杀。
 */
export async function validateOcrCompleteness(params: {
  events: OcrEvent[];
  videoPath: string;
  label?: string;
  onProgress?: (message: string) => void;
}): Promise<void> {
  const sourceCount = params.events.length;
  const lines = params.events.filter((event) => event.text.trim().length > 0).length;
  const lastEndMs = params.events[params.events.length - 1]?.endMs ?? 0;
  const videoDurationMs = await probeVideoDurationMs(params.videoPath);
  const coverageRatio = videoDurationMs && videoDurationMs > 0 ? lastEndMs / videoDurationMs : null;
  await params.onProgress?.(
    `识别结果校验：已识别 ${lines} / ${sourceCount} 条` +
    (videoDurationMs ? `，覆盖 ${formatSrtTime(lastEndMs)} / ${formatSrtTime(videoDurationMs)}` : ""),
  );
  if (sourceCount === 0) {
    throw new Error(
      `字幕识别结果校验失败：${params.label ?? "该字幕轨"}源字幕轨无任何字幕事件，结果不可用。`,
    );
  }
  if (coverageRatio !== null && videoDurationMs !== null && videoDurationMs >= 10 * 60_000 && coverageRatio < 0.8) {
    throw new Error(
      `字幕识别结果校验失败：${params.label ?? "该字幕轨"}时间覆盖仅 ${Math.round(coverageRatio * 100)}%` +
      `（覆盖至 ${formatSrtTime(lastEndMs)} / ${formatSrtTime(videoDurationMs)}），源字幕轨疑似不完整或损坏，结果不可用。`,
    );
  }
  const recognizedRatio = lines / sourceCount;
  if (recognizedRatio < 0.9) {
    throw new Error(
      `字幕识别结果校验失败：${params.label ?? "该字幕轨"}仅识别出 ${lines} / ${sourceCount} 条非空字幕` +
      `（${Math.round(recognizedRatio * 100)}%），疑似 OCR 漏识，结果不可用。`,
    );
  }
}

import { encodePng, toBlackOnWhite, decodePngRgba } from "./subtitle-ocr-png";
import { parsePgsSup } from "./subtitle-ocr-pgs";
export { encodePng, toBlackOnWhite, decodePngRgba } from "./subtitle-ocr-png";
export { parsePgsSup } from "./subtitle-ocr-pgs";

// ── Chinese simplified/traditional detection ───────────────────────────────────
const TRADITIONAL_ONLY = new Set(
  "這那個們時後來為與開關國會對讓學東長門問電話嗎麼覺識譯錯誤隨音樂廳館體說當點兒裡寫讀聽請進過還這那都沒有這個樣應該現在知道時候問題甚麼邊誰幾種陳謝師爺飯館臺灣臺灣英語漢字簡體繁體中華人民共和國".split(""),
);
const SIMPLIFIED_ONLY = new Set(
  "这那个们时后为与开关国会对让学长门问电话吗么觉识译错误随音乐厅馆体说当点儿里写读听请进过还这那都没有这个样应该现在知道时候问题什么边谁几种陈谢师爷饭馆台湾台湾英语汉字简体繁体中华人民共和国".split(""),
);

function countVariantChars(text: string, chars: Set<string>): number {
  let count = 0;
  for (const ch of text) {
    if (chars.has(ch)) count += 1;
  }
  return count;
}

/**
 * Decide chi_sim vs chi_tra for a Chinese subtitle track by OCR-ing up to
 * three sample frames with both models and comparing how many traditional-only
 * characters each output contains (the correct model keeps them coherent).
 */
export async function detectChineseVariant(
  tesseractPath: string,
  images: Array<{ index: number; png: Buffer }>,
): Promise<"chi_sim" | "chi_tra"> {
  const samples = [
    images[0],
    images[Math.floor(images.length / 2)],
    images[images.length - 1],
  ].filter((image): image is { index: number; png: Buffer } => Boolean(image));
  if (samples.length === 0) return "chi_sim";
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const { mkdtemp, writeFile, rm } = await import("node:fs/promises");
  const { tmpdir } = await import("node:os");
  const { join } = await import("node:path");
  const execFileAsync = promisify(execFile);
  const dir = await mkdtemp(join(tmpdir(), "vx-chi-variant-"));
  let traScore = 0;
  let simScore = 0;
  try {
    let n = 0;
    for (const sample of samples) {
      n += 1;
      const input = join(dir, `s${n}.png`);
      await writeFile(input, sample.png);
      const run = async (lang: string): Promise<string> => {
        try {
          const { stdout } = await execFileAsync(tesseractPath, [input, "stdout", "-l", lang, "--psm", "6"], { timeout: 30_000 });
          return stdout;
        } catch {
          return "";
        }
      };
      const simText = await run("chi_sim");
      const traText = await run("chi_tra");
      simScore += countVariantChars(simText, TRADITIONAL_ONLY);
      traScore += countVariantChars(traText, TRADITIONAL_ONLY);
    }
    return traScore > simScore ? "chi_tra" : "chi_sim";
  } finally {
    await rm(dir, { recursive: true, force: true }).catch(() => {});
  }
}


// ── LLM vision OCR ────────────────────────────────────────────────────────────
export function isVisionCapable(provider: string, model: string): boolean {
  const p = (provider || "").toLowerCase();
  const m = (model || "").toLowerCase();
  if (p.includes("deepseek")) return false;
  return /gemini|gpt-4o|gpt-4\.1|gpt-4-vision|qwen.*vl|glm-4v|glm-4\.1v|vision|claude/i.test(`${p} ${m}`);
}

export async function ocrWithLlm(
  images: Array<{ index: number; png: Buffer }>,
  config: AiProviderConfig,
  language: string,
  fetchImpl: typeof fetch = fetch,
): Promise<Array<{ index: number; text: string; language: string }>> {
  const endpoint = resolveAiEndpoint(config);
  const key = resolveApiKey(config);
  if (!key) throw new Error("未配置当前 AI 提供商的 API Key，无法使用大模型 OCR");
  if (!isVisionCapable(endpoint.provider, endpoint.model)) {
    throw new Error(`当前模型 ${endpoint.model} 不支持图片输入，请在设置中切换到支持视觉的模型（如 gpt-4o / qwen-vl / glm-4v / gemini）`);
  }
  const results: Array<{ index: number; text: string; language: string }> = [];
  for (const image of images) {
    const dataUrl = `data:image/png;base64,${image.png.toString("base64")}`;
    const prompt = language === "auto"
      ? "识别图片中的字幕文字。请严格输出 JSON：{\"text\":\"...\",\"language\":\"...\"}。text 为字幕原文（保持原始语言），language 为 ISO 639-1 语种代码。不要输出任何其他内容。"
      : `识别图片中的字幕文字（目标语言：${language}）。请严格输出 JSON：{"text":"...","language":"..."}。text 为字幕原文，language 为 ISO 639-1 语种代码。不要输出任何其他内容。`;
    const response = await fetchImpl(`${endpoint.baseUrl.replace(/\/$/, "")}/chat/completions`, {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: endpoint.model,
        temperature: 0,
        messages: [{
          role: "user",
          content: [
            { type: "text", text: prompt },
            { type: "image_url", image_url: { url: dataUrl } },
          ],
        }],
      }),
    });
    if (!response.ok) {
      const body = await response.text().catch(() => "");
      throw new Error(`大模型 OCR 请求失败（HTTP ${response.status}）：${body.slice(0, 240)}`);
    }
    const body = await response.json() as { choices?: Array<{ message?: { content?: string } }> };
    const content = body.choices?.[0]?.message?.content ?? "";
    const match = content.match(/\{[\s\S]*?\}/);
    let text = content.trim();
    let detected = "unknown";
    if (match) {
      try {
        const parsed = JSON.parse(match[0]) as { text?: string; language?: string };
        text = String(parsed.text ?? "").trim();
        detected = String(parsed.language ?? "unknown").trim().toLowerCase() || "unknown";
      } catch {
        text = content.trim();
      }
    }
    results.push({ index: image.index, text, language: detected });
  }
  return results;
}

// ── Pipeline orchestrator ─────────────────────────────────────────────────────
import { detectDvdOcrTarget, runDvdVobSubOcr, runVobSubOcr } from "./subtitle-ocr-dvd";
export { extractHandBrakeJson } from "./subtitle-ocr-dvd";

export async function runSubtitleOcr(params: {
  sourcePath: string;
  config: AiProviderConfig;
  engine?: OcrEngine;
  language?: string;
  titleId?: string | null;
  outputBaseName?: string;
  onProgress?: (message: string) => void;
}): Promise<OcrResult> {
  const requestedEngine: OcrEngine = params.engine ?? "auto";
  const language = params.language ?? "auto";
  const progress = async (message: string) => { await params.onProgress?.(message); };

  // Fail fast: verify the OCR engine and language data are usable before any
  // expensive DVD scan / HandBrake transcode / PGS extraction.
  await resolveOcrEngineAndLanguage({ config: params.config, engine: requestedEngine, language });

  // DVD folder → VobSub OCR via HandBrake passthrough.
  const dvdTarget = await detectDvdOcrTarget(params.sourcePath, params.titleId ?? null, language);
  if (dvdTarget) {
    return runDvdVobSubOcr(params, dvdTarget);
  }

  await progress("正在探测图形字幕轨…");
  const streams = await probeGraphicSubtitleStreams(params.sourcePath);
  const probe = pickPreferredGraphicStream(streams, language);
  if (!probe) throw new Error("未找到图形字幕轨（PGS/VobSub/DVB 等），无法执行 OCR");
  await progress(`已选择图形字幕轨（${probe.language ? probe.language.toUpperCase() : "无语言标记"}，第 ${probe.typeIndex + 1}/${streams.length} 条字幕轨）`);
  if (isDirectFrameGraphicCodec(probe.codec)) {
    return runVobSubOcr(params, params.sourcePath, probe.typeIndex, probe.language);
  }
  if (!PGS_SUBTITLE_CODECS.has(probe.codec)) {
    throw new Error(`检测到 ${probe.codec} 图形字幕；当前版本无法解码该格式`);
  }
  const { engine, ocrLanguage: preflightOcrLanguage } = await resolveOcrEngineAndLanguage({
    config: params.config,
    engine: requestedEngine,
    language,
    streamLanguage: probe.language,
  });
  await progress("正在提取 PGS 字幕流…");
  const sup = await extractPgsSup(params.sourcePath, probe.typeIndex);
  await progress(`已提取 ${sup.length} 字节 PGS 数据，正在解析字幕事件…`);
  const parsed = parsePgsSup(sup);
  if (parsed.length === 0) throw new Error("PGS 字幕中没有可解析的字幕事件");
  await progress(`解析到 ${parsed.length} 条字幕事件，正在生成图像…`);
  const images = parsed.map((event, index) => ({
    index,
    png: encodePng(toBlackOnWhite(event.rgba, event.width, event.height), event.width, event.height),
  }));
  let ocrLanguage = preflightOcrLanguage;
  if (engine === "tesseract" && language === "auto" && !probe.language) {
    const tesseractPath = await resolveToolPath("tesseract");
    if (tesseractPath) {
      ocrLanguage = await detectAutoTesseractLanguage(tesseractPath, images);
      await progress(`字幕轨无语言标记，自动检测 OCR 语言：${ocrLanguage}`);
    }
  }

  // Auto mode may select one local engine that is installed but unusable for
  // this particular subtitle image set. Retry with the other local engine
  // before reporting OCR failure; never silently switch to Whisper here.
  const engineCandidates: OcrEngine[] = [engine];
  if (requestedEngine === "auto") {
    if (engine === "tesseract") engineCandidates.push("rapidocr");
    if (engine === "rapidocr") engineCandidates.push("tesseract");
  }
  let recognized: Array<{ index: number; text: string; language: string; confidence?: number | null }> | null = null;
  let events: OcrEvent[] = [];
  let srtContent = "";
  let activeEngine = engine;
  let lastError: unknown = null;
  for (const candidate of engineCandidates) {
    try {
      let candidateLanguage = ocrLanguage;
      if (candidate === "tesseract") {
        candidateLanguage = (await resolveOcrEngineAndLanguage({
          config: params.config,
          engine: "tesseract",
          language,
          streamLanguage: probe.language,
        })).ocrLanguage;
        const tesseractPath = await resolveToolPath("tesseract");
        if (language === "auto" && !probe.language && tesseractPath) {
          candidateLanguage = await detectAutoTesseractLanguage(tesseractPath, images);
        }
        if (candidateLanguage === "chi_sim" || candidateLanguage === "chi_tra") {
          const variant = tesseractPath ? await detectChineseVariant(tesseractPath, images) : candidateLanguage;
          candidateLanguage = variant;
        }
        await progress(`正在使用本地 Tesseract（${candidateLanguage}）识别 ${images.length} 条字幕…`);
        recognized = await ocrWithTesseract(images, candidateLanguage);
      } else if (candidate === "llm") {
        await progress(`正在调用大模型识别 ${images.length} 条字幕…`);
        recognized = await ocrWithLlm(images, params.config, language);
      } else if (candidate === "rapidocr") {
        await progress(`正在使用 RapidOCR（中文优化）识别 ${images.length} 条字幕…`);
        recognized = await ocrWithRapidOcr(images);
      } else {
        throw new Error(`OCR 引擎 "${candidate}" 尚未实现`);
      }

      events = recognized.map((item) => ({
        index: item.index,
        startMs: parsed[item.index].startMs,
        endMs: parsed[item.index + 1]?.startMs ?? parsed[item.index].startMs + 3000,
        text: item.text,
      }));
      srtContent = assembleSrt(events);
      if (!srtContent.trim()) throw new Error("OCR 识别结果为空");
      await validateOcrCompleteness({ events, videoPath: params.sourcePath, label: "该字幕轨", onProgress: progress });
      activeEngine = candidate;
      break;
    } catch (error) {
      lastError = error;
      recognized = null;
      const message = error instanceof Error ? error.message : String(error);
      if (candidate !== engineCandidates[engineCandidates.length - 1]) {
        await progress(`OCR 引擎 ${candidate} 失败，尝试备用本地引擎：${message}`);
      }
    }
  }
  if (!recognized) throw (lastError instanceof Error ? lastError : new Error(String(lastError ?? "OCR 识别失败")));
  const detectedLanguage = language !== "auto"
    ? language
    : (recognized.find((item) => item.language !== "unknown")?.language ?? detectScriptLanguage(events.map((event) => event.text).join("\n")));
  const quality = computeOcrQuality(recognized, parsed.length);
  const srtPath = await writeSrtBesideSource(params.sourcePath, srtContent, params.outputBaseName);
  await progress(`已完成，生成 ${srtPath}`);
  return { srtPath, srtContent, events, language: detectedLanguage, engine: activeEngine, qualityScore: quality.score, qualityConfidenceBased: quality.confidenceBased };
}

type GraphicStreamInfo = { index: number; typeIndex: number; codec: string; language: string | null; packets?: number };

async function probeGraphicSubtitleStreams(sourcePath: string): Promise<GraphicStreamInfo[]> {
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const execFileAsync = promisify(execFile);
  try {
    const ffprobe = await resolveSubtitleToolPath("ffprobe");
    const { stdout } = await execFileAsync(ffprobe, ["-v", "error", "-print_format", "json", "-show_streams", "-count_packets", sourcePath], { timeout: 60_000 });
    const parsed = JSON.parse(stdout) as { streams?: Array<{ index: number; codec_type?: string; codec_name?: string; tags?: { language?: string }; nb_read_packets?: string | number }> };
    const streams = parsed.streams ?? [];
    const subtitleStreams = streams.filter((stream) => stream.codec_type === "subtitle");
    return streams
      .filter((stream) => {
        const codec = String(stream.codec_name ?? "").toLowerCase();
        return isGraphicSubtitleCodec(codec) || PGS_SUBTITLE_CODECS.has(codec);
      })
      .map((stream) => ({
        index: stream.index,
        typeIndex: subtitleStreams.findIndex((candidate) => candidate.index === stream.index),
        codec: String(stream.codec_name).toLowerCase(),
        language: stream.tags?.language ?? null,
        packets: Number(stream.nb_read_packets) > 0 ? Number(stream.nb_read_packets) : 0,
      }));
  } catch {
    return [];
  }
}

/**
 * Pick the graphic subtitle track to OCR.
 * "auto" prefers the Chinese track, then English, then the longest tagged
 * track, then the track with the most subtitle events. An explicit preset
 * prefers the longest matching track, then the longest overall.
 */
export function pickPreferredGraphicStream(streams: GraphicStreamInfo[], language: string): GraphicStreamInfo | null {
  if (streams.length === 0) return null;
  const longest = (list: GraphicStreamInfo[]) => list.sort((a, b) => (b.packets ?? 0) - (a.packets ?? 0))[0];
  const requested = (language || "auto").trim().toLowerCase();
  if (requested === "auto" || !requested) {
    return longest(streams.filter((stream) => ["zho", "chi", "zh", "cmn"].includes((stream.language ?? "").toLowerCase())))
      ?? longest(streams.filter((stream) => (stream.language ?? "").toLowerCase() === "eng"))
      ?? longest(streams.filter((stream) => (stream.language ?? "").trim().length > 0))
      ?? longest(streams);
  }
  return longest(streams.filter((stream) => languageMatchesRequest(stream.language, requested)))
    ?? longest(streams);
}

async function extractPgsSup(sourcePath: string, subTypeIndex: number): Promise<Buffer> {
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const { mkdtemp, readFile, rm } = await import("node:fs/promises");
  const { tmpdir } = await import("node:os");
  const { join } = await import("node:path");
  const execFileAsync = promisify(execFile);
  const ffmpeg = await resolveSubtitleToolPath("ffmpeg");
  const dir = await mkdtemp(join(tmpdir(), "vx-ocr-"));
  const outPath = join(dir, "subtitle.sup");
  try {
    await execFileAsync(ffmpeg, [
      "-v", "error", "-nostdin", "-y",
      "-analyzeduration", "100M", "-probesize", "100M",
      "-i", sourcePath,
      "-map", `0:s:${subTypeIndex}`,
      "-c:s", "copy",
      "-f", "sup",
      outPath,
    ], { timeout: 120_000 });
    const buffer = await readFile(outPath);
    if (buffer.length < 10) throw new Error("FFmpeg 未生成有效 SUP 数据");
    await rm(dir, { recursive: true, force: true });
    return buffer;
  } catch (error) {
    await rm(dir, { recursive: true, force: true }).catch(() => {});
    throw new Error(`PGS 字幕提取失败：${error instanceof Error ? error.message : String(error)}`);
  }
}

export async function writeSrtBesideSource(sourcePath: string, srtContent: string, outputBaseName?: string): Promise<string> {
  const { dirname, basename, extname, join } = await import("node:path");
  const { writeFile } = await import("node:fs/promises");
  const stem = outputBaseName ?? basename(sourcePath, extname(sourcePath));
  const srtPath = join(dirname(sourcePath), `${stem}.ocr.srt`);
  await writeFile(srtPath, srtContent, "utf8");
  return srtPath;
}
