import { afterEach, beforeEach, describe, expect, it } from "vitest";
import fs from "fs/promises";
import os from "os";
import path from "path";
import {
  collectDvdVobFilesForIfo,
  dvdTitleInputArgs,
  findDvdTitles,
  findMissingDvdVobFiles,
  resolveDvdDiscRootForIfo,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack,
} from "./disc";

let tempDir: string;

async function writeFile(filePath: string, size = 1) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, Buffer.alloc(size, 1));
}

beforeEach(async () => {
  tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-disc-test-"));
});

afterEach(async () => {
  await fs.rm(tempDir, { recursive: true, force: true });
});

describe("DVD title helpers", () => {
  it("accepts both a disc root and the VIDEO_TS directory", async () => {
    const videoTsDir = path.join(tempDir, "Movie", "VIDEO_TS");
    await writeFile(path.join(videoTsDir, "VIDEO_TS.IFO"));

    expect(await resolveDvdVideoTsDir(path.join(tempDir, "Movie"))).toBe(videoTsDir);
    expect(await resolveDvdVideoTsDir(videoTsDir)).toBe(videoTsDir);
  });

  it("does not append VIDEO_TS when the input path is already the VIDEO_TS directory", () => {
    if (process.platform !== "win32") return;

    const videoTsDir = "H:\\11 Days 11 Nights Part 3 (1989) DVD\\VIDEO_TS";
    expect(resolveDvdVideoInputPath(videoTsDir)).toBe(videoTsDir);
  });

  it("collects ordered content VOBs for an IFO and skips menu VOBs", () => {
    const ifoPath = path.join(tempDir, "VIDEO_TS", "VTS_02_0.IFO");
    const files = collectDvdVobFilesForIfo(ifoPath, [
      "VTS_02_0.VOB",
      "VTS_02_2.VOB",
      "VTS_02_1.VOB",
      "VTS_03_1.VOB",
    ]);

    expect(files.map((file) => path.basename(file))).toEqual(["VTS_02_1.VOB", "VTS_02_2.VOB"]);
  });

  it("finds DVD titles and chooses the largest IFO as the main track", async () => {
    const discRoot = path.join(tempDir, "Movie");
    const videoTsDir = path.join(discRoot, "VIDEO_TS");
    await writeFile(path.join(videoTsDir, "VIDEO_TS.IFO"));
    await writeFile(path.join(videoTsDir, "VTS_01_0.IFO"));
    await writeFile(path.join(videoTsDir, "VTS_01_1.VOB"), 5);
    await writeFile(path.join(videoTsDir, "VTS_02_0.IFO"));
    await writeFile(path.join(videoTsDir, "VTS_02_1.VOB"), 10);
    await writeFile(path.join(videoTsDir, "VTS_02_2.VOB"), 10);

    const titles = await findDvdTitles(discRoot);
    expect(titles.map((title) => title.titleNumber)).toEqual([2, 1]);
    expect(await resolveMainTrack(discRoot, "dvd")).toBe(path.join(videoTsDir, "VTS_02_0.IFO"));
  });

  it("resolves the requested VTS group instead of reusing the largest title", async () => {
    const discRoot = path.join(tempDir, "MultiTitle");
    const videoTsDir = path.join(discRoot, "VIDEO_TS");
    await writeFile(path.join(videoTsDir, "VIDEO_TS.IFO"));
    await writeFile(path.join(videoTsDir, "VTS_01_0.IFO"));
    await writeFile(path.join(videoTsDir, "VTS_01_1.VOB"), 5);
    await writeFile(path.join(videoTsDir, "VTS_02_0.IFO"));
    await writeFile(path.join(videoTsDir, "VTS_02_1.VOB"), 10);
    await writeFile(path.join(videoTsDir, "VTS_02_2.VOB"), 10);

    const selected = await resolveDvdTitleForSource(discRoot, 0, 1);
    expect(selected?.titleNumber).toBe(1);
    expect(selected?.vobFiles.map((file) => path.basename(file))).toEqual(["VTS_01_1.VOB"]);
  });

  it("does not return an unrelated VTS group when a logical title has no exact physical match", async () => {
    const discRoot = path.join(tempDir, "LogicalTitleWithoutVtsMatch");
    const videoTsDir = path.join(discRoot, "VIDEO_TS");
    await writeFile(path.join(videoTsDir, "VIDEO_TS.IFO"));
    await writeFile(path.join(videoTsDir, "VTS_02_0.IFO"));
    await writeFile(path.join(videoTsDir, "VTS_02_1.VOB"), 20);

    const selected = await resolveDvdTitleForSource(discRoot, 0, 7);
    expect(selected).toBeNull();
  });

  it("resolves title metadata from an IFO and uses the disc root for HandBrake", async () => {
    const discRoot = path.join(tempDir, "Movie");
    const videoTsDir = path.join(discRoot, "VIDEO_TS");
    const ifoPath = path.join(videoTsDir, "VTS_01_0.IFO");
    await writeFile(path.join(videoTsDir, "VIDEO_TS.IFO"));
    await writeFile(ifoPath);
    await writeFile(path.join(videoTsDir, "VTS_01_1.VOB"), 7);
    await writeFile(path.join(videoTsDir, "VTS_01_2.VOB"), 11);

    const title = await resolveDvdTitleForSource(ifoPath);
    expect(title?.sizeBytes).toBe(18);
    expect(title?.vobFiles.map((file) => path.basename(file))).toEqual(["VTS_01_1.VOB", "VTS_01_2.VOB"]);
    expect(resolveDvdDiscRootForIfo(ifoPath)).toBe(discRoot);
    expect(resolveDvdHandbrakeInputForIfo(ifoPath)).toBe(discRoot);
  });

  it("builds DVD title input args: folder rips use the VIDEO_TS dir, drive roots use the drive", async () => {
    const discRoot = path.join(tempDir, "Movie");
    const videoTsDir = path.join(discRoot, "VIDEO_TS");
    const ifoPath = path.join(videoTsDir, "VTS_03_0.IFO");
    await writeFile(path.join(videoTsDir, "VIDEO_TS.IFO"));
    await writeFile(ifoPath);
    await writeFile(path.join(videoTsDir, "VTS_03_1.VOB"), 7);

    const title = await resolveDvdTitleForSource(ifoPath);

    expect(title?.discRoot).toBe(discRoot);
    // Windows libdvdnav/libdvdcss cannot open the parent folder of a folder
    // rip; the dvdvideo input must be the VIDEO_TS directory itself.
    if (process.platform === "win32") {
      expect(dvdTitleInputArgs(title!)).toEqual(["-f", "dvdvideo", "-title", "3", "-i", videoTsDir]);
      expect(resolveDvdVideoInputPath("E:\\", videoTsDir)).toBe("E:\\");
    } else {
      expect(dvdTitleInputArgs(title!)).toEqual(["-f", "dvdvideo", "-title", "3", "-i", discRoot]);
    }
  });

  it("ignores titles without content VOB files", async () => {
    const discRoot = path.join(tempDir, "NoContent");
    const videoTsDir = path.join(discRoot, "VIDEO_TS");
    await writeFile(path.join(videoTsDir, "VTS_01_0.IFO"));
    await writeFile(path.join(videoTsDir, "VTS_01_0.VOB"));
    expect(await findDvdTitles(discRoot)).toEqual([]);
  });

  it("detects missing content VOBs in an incomplete rip", async () => {
    const discRoot = path.join(tempDir, "Incomplete");
    const videoTsDir = path.join(discRoot, "VIDEO_TS");
    const ifoPath = path.join(videoTsDir, "VTS_02_0.IFO");
    await writeFile(path.join(videoTsDir, "VIDEO_TS.IFO"));
    await writeFile(ifoPath);
    await writeFile(path.join(videoTsDir, "VTS_02_1.VOB"), 7);
    await writeFile(path.join(videoTsDir, "VTS_02_2.VOB"), 11);
    await writeFile(path.join(videoTsDir, "VTS_02_4.VOB"), 13);
    await writeFile(path.join(videoTsDir, "VTS_02_5.VOB"), 17);

    const entries = await fs.readdir(videoTsDir);
    expect(findMissingDvdVobFiles(ifoPath, entries)).toEqual(["VTS_02_3.VOB"]);

    const title = await resolveDvdTitleForSource(ifoPath);
    expect(title?.missingVobFiles).toEqual(["VTS_02_3.VOB"]);
  });
});
