import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { resolveExistingOpenDirectory } from "./open-path";

describe("open output path", () => {
  it("opens an existing file's parent directory", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-open-path-"));
    const file = path.join(dir, "output.mkv");
    await fs.writeFile(file, "ok");
    await expect(resolveExistingOpenDirectory(file)).resolves.toBe(dir);
    await fs.rm(dir, { recursive: true, force: true });
  });

  it("opens the nearest existing parent when an output file is not generated yet", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-open-path-"));
    await expect(resolveExistingOpenDirectory(path.join(dir, "future", "output.mkv"))).resolves.toBe(dir);
    await fs.rm(dir, { recursive: true, force: true });
  });

  it("keeps spaces and Unicode path segments intact", async () => {
    const root = await fs.mkdtemp(path.join(os.tmpdir(), "vx-open-path-中文 "));
    const nested = path.join(root, "电影 2026", "输出");
    await fs.mkdir(nested, { recursive: true });
    await expect(resolveExistingOpenDirectory(path.join(nested, "片名 (测试).mkv"))).resolves.toBe(nested);
    await fs.rm(root, { recursive: true, force: true });
  });

  it("returns a clear error for an empty path", async () => {
    await expect(resolveExistingOpenDirectory(" ")).rejects.toThrow("路径为空");
  });
});
