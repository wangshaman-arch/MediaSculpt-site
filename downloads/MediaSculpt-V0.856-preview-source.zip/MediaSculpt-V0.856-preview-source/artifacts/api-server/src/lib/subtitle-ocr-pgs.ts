// Extracted from subtitle-ocr.ts: Blu-ray PGS (.sup) parser.
import { inflateSync } from "node:zlib";

export type PgsObject = { width: number; height: number; rle: Buffer };
export type PgsComposition = { paletteId: number; comps: Array<{ oid: number; x: number; y: number }> };
export type PgsEvent = { startMs: number; rgba: Buffer; width: number; height: number };

function ycbcrToRgb(y: number, cr: number, cb: number): [number, number, number] {
  const r = y + 1.402 * (cr - 128);
  const g = y - 0.344136 * (cb - 128) - 0.714136 * (cr - 128);
  const b = y + 1.772 * (cb - 128);
  const clamp = (v: number) => Math.max(0, Math.min(255, Math.round(v)));
  return [clamp(r), clamp(g), clamp(b)];
}

function decodePgsRle(rle: Buffer, width: number, height: number, palette: Uint8Array): Buffer {
  const out = Buffer.alloc(width * height * 4);
  let pos = 0;
  let col = 0;
  let row = 0;
  const putPixel = (index: number, count: number) => {
    const off = index * 4;
    const a = palette[off + 3];
    for (let i = 0; i < count && col + i < width; i += 1) {
      const o = (row * width + col + i) * 4;
      out[o] = palette[off];
      out[o + 1] = palette[off + 1];
      out[o + 2] = palette[off + 2];
      out[o + 3] = a;
    }
    col += count;
  };
  while (row < height && pos < rle.length) {
    const b = rle[pos];
    pos += 1;
    if (b === 0x00) {
      col = 0;
      row += 1;
      continue;
    }
    if ((b & 0xc0) === 0x00) {
      const len = b & 0x3f;
      if (len === 1 && pos < rle.length) {
        putPixel(rle[pos], 1);
        pos += 1;
      } else if (len > 1 && pos + len <= rle.length) {
        for (let i = 0; i < len; i += 1) putPixel(rle[pos + i], 1);
        pos += len;
      }
      continue;
    }
    if ((b & 0xc0) === 0x40 && pos + 2 <= rle.length) {
      const len = ((b & 0x3f) << 8) | rle[pos];
      const pixel = rle[pos + 1];
      pos += 2;
      putPixel(pixel, len);
      continue;
    }
    if ((b & 0xc0) === 0x80 && pos + 2 <= rle.length) {
      const len = ((b & 0x0f) << 8) | rle[pos];
      const pixel = rle[pos + 1];
      pos += 2;
      putPixel(pixel, len);
      continue;
    }
    if (b === 0xff && pos + 2 <= rle.length) {
      const len = rle[pos];
      const pixel = rle[pos + 1];
      pos += 2;
      putPixel(pixel, len);
      continue;
    }
    if (b === 0xfe && pos + 3 <= rle.length) {
      const len = (rle[pos] << 8) | rle[pos + 1];
      const pixel = rle[pos + 2];
      pos += 3;
      putPixel(pixel, len);
      continue;
    }
    // Unknown code: skip one byte to stay in sync.
  }
  return out;
}

function buildPalette(entries: Buffer): Uint8Array {
  const palette = new Uint8Array(256 * 4);
  for (let e = 0; e < 16; e += 1) {
    const o = e * 5 + 1;
    if (o + 4 > entries.length) break;
    // PDS entry layout: entry_id, Y, Cr, Cb, Alpha.
    const y = entries[o + 1];
    const cr = entries[o + 2];
    const cb = entries[o + 3];
    const alpha = entries[o + 4];
    const [r, g, b] = ycbcrToRgb(y, cr, cb);
    const off = e * 4;
    palette[off] = r;
    palette[off + 1] = g;
    palette[off + 2] = b;
    palette[off + 3] = alpha === 0 ? 0 : 255;
  }
  return palette;
}

export function parsePgsSup(sup: Buffer): PgsEvent[] {
  const events: PgsEvent[] = [];
  const palettes = new Map<number, Uint8Array>();
  const objects = new Map<number, PgsObject>();
  let composition: PgsComposition | null = null;
  let startMs = 0;
  let i = 0;
  while (i + 6 <= sup.length) {
    if (!(sup[i] === 0 && sup[i + 1] === 0 && sup[i + 2] === 1 && sup[i + 3] === 0xbd)) {
      i += 1;
      continue;
    }
    const pesLen = (sup[i + 4] << 8) | sup[i + 5];
    let p = i + 6;
    if (p + 2 > sup.length) break;
    const flags2 = sup[p + 1];
    p += 2;
    let ptsMs = 0;
    if ((flags2 & 0x80) !== 0 && p + 5 <= sup.length) {
      const pts = ((sup[p] & 0x0e) << 29) | (sup[p + 1] << 22) | ((sup[p + 2] & 0xfe) << 14) | (sup[p + 3] << 7) | (sup[p + 4] >> 1);
      ptsMs = Math.round(pts / 90);
      p += 5;
    }
    const payloadEnd = Math.min(i + 6 + pesLen, sup.length);
    let s = p;
    while (s + 3 <= payloadEnd) {
      const type = sup[s];
      const segLen = (sup[s + 1] << 8) | sup[s + 2];
      const data = sup.subarray(s + 3, s + 3 + segLen);
      s += 3 + segLen;
      if (type === 0x14 && data.length >= 81) {
        palettes.set(data[0], buildPalette(data));
      } else if (type === 0x15 && data.length >= 11) {
        const oid = (data[0] << 8) | data[1];
        const width = (data[4] << 8) | data[5];
        const height = (data[6] << 8) | data[7];
        const dataLen = (data[8] << 16) | (data[9] << 8) | data[10];
        const rle = data.subarray(11, 11 + Math.min(dataLen, Math.max(0, data.length - 11)));
        objects.set(oid, { width, height, rle });
      } else if (type === 0x16 && data.length >= 11) {
        const paletteId = data[9];
        const objCount = data[10];
        const comps: PgsComposition["comps"] = [];
        let o = 11;
        for (let k = 0; k < objCount && o + 8 <= data.length; k += 1) {
          const oid = (data[o] << 8) | data[o + 1];
          const x = (data[o + 3] << 8) | data[o + 4];
          const y = (data[o + 5] << 8) | data[o + 6];
          const crop = data[o + 7];
          o += 8;
          if ((crop & 0x80) !== 0) o += 8;
          comps.push({ oid, x, y });
        }
        composition = { paletteId, comps };
        startMs = ptsMs;
      } else if (type === 0x80 && composition) {
        const palette = palettes.get(composition.paletteId);
        if (palette) {
          let maxRight = 0;
          let maxBottom = 0;
          for (const comp of composition.comps) {
            const obj = objects.get(comp.oid);
            if (!obj) continue;
            maxRight = Math.max(maxRight, comp.x + obj.width);
            maxBottom = Math.max(maxBottom, comp.y + obj.height);
          }
          if (maxRight > 0 && maxBottom > 0) {
            const rgba = Buffer.alloc(maxRight * maxBottom * 4);
            for (const comp of composition.comps) {
              const obj = objects.get(comp.oid);
              if (!obj) continue;
              const decoded = decodePgsRle(obj.rle, obj.width, obj.height, palette);
              for (let y = 0; y < obj.height; y += 1) {
                const srcOff = y * obj.width * 4;
                const dstOff = ((comp.y + y) * maxRight + comp.x) * 4;
                decoded.copy(rgba, dstOff, srcOff, srcOff + obj.width * 4);
              }
            }
            events.push({ startMs, rgba, width: maxRight, height: maxBottom });
          }
        }
        composition = null;
        palettes.clear();
        objects.clear();
      }
    }
    i = i + 6 + pesLen;
  }
  events.sort((a, b) => a.startMs - b.startMs);
  return events;
}
