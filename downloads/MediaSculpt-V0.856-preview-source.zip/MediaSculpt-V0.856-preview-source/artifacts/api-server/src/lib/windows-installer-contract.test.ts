import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import {
  enPack,
  projectRoot,
  readProjectFile,
  zhPack,
} from "./windows-contract-helpers";

describe("Windows contract", () => {
  it("keeps every Windows PowerShell entrypoint ASCII-only for PowerShell 5.1", () => {
    const powershellFiles = ["windows-setup", "scripts"].flatMap((directory) =>
      fs
        .readdirSync(path.join(projectRoot, directory))
        .filter((name) => name.endsWith(".ps1"))
        .map((name) => path.join(projectRoot, directory, name)),
    );

    for (const filePath of powershellFiles) {
      const bytes = fs.readFileSync(filePath);
      const offending = bytes.findIndex((byte) => byte > 0x7f);
      expect(offending, path.relative(projectRoot, filePath)).toBe(-1);
    }
  });

  it("shows installer progress live while recording one install log", () => {
    const batch = readProjectFile("windows-setup/安装MediaSculpt.bat");
    const wrapper = readProjectFile(
      "windows-setup/install-with-diagnostics.ps1",
    );
    const installer = readProjectFile("windows-setup/install.ps1");

    expect(batch).toContain("install-with-diagnostics.ps1");
    expect(batch).not.toMatch(/powershell\.exe.*>>/i);
    expect(wrapper).toContain("Start-Transcript");
    expect(wrapper).toContain("mediasculpt-diagnostics.log");
    expect(wrapper).toContain("Set-Content -Path $logPath");
    expect(wrapper).toContain("release-id.txt");
    expect(wrapper).toContain("Wrapper release:");
    expect(wrapper).toContain(
      "[System.Management.Automation.PSParser]::Tokenize",
    );
    expect(wrapper).toContain("PowerShell parser preflight passed");
    expect(installer).not.toContain("Read-Host");
    expect(installer).not.toContain("Pause-Key");
    expect(installer).not.toMatch(/\bexit 1\b/);
  });

  it("exposes install and diagnostics entrypoints at the package root", () => {
    const install = readProjectFile("windows-setup/安装MediaSculpt.bat");
    const diagnostics = readProjectFile("windows-setup/收集影刻诊断信息.bat");
    expect(install).toContain("install-with-diagnostics.ps1");
    expect(install).toContain("mediasculpt-diagnostics.log");
    expect(diagnostics).toContain("collect-diagnostics.ps1");
    expect(
      fs.existsSync(
        path.join(projectRoot, "windows-setup", "安装MediaSculpt.bat"),
      ),
    ).toBe(true);
    expect(
      fs.existsSync(
        path.join(projectRoot, "windows-setup", "收集影刻诊断信息.bat"),
      ),
    ).toBe(true);
  });

  it("uses portable installers instead of privileged winget for standard users", () => {
    const installer = readProjectFile("windows-setup/install.ps1");

    expect(installer.match(/\$hasWinget -and \$isAdmin/g)).toHaveLength(3);
    expect(installer).not.toContain("elseif ($hasWinget) {");
    expect(installer).toContain("InstallAllUsers=0");
  });

  it("uses the active Node runtime to install pnpm before dependency installation", () => {
    const installer = readProjectFile("windows-setup/install.ps1");

    expect(installer).toContain("function Install-PnpmForActiveNode");
    expect(installer).toContain("function Convert-CommandOutputLine");
    expect(installer).toContain("function Get-ExternalCommandFirstLine");
    expect(installer).toContain("Invoke-ExternalCommand");
    expect(installer).toContain('@("npm", "install", "-g", "pnpm")');
    expect(installer).toContain(
      "$safeOutput += Convert-CommandOutputLine -Value $line",
    );
    expect(installer).toContain(
      "$npmInstallOutput | ForEach-Object { Write-Host $_ }",
    );
    expect(installer).toContain(
      '$activeNode = Get-ExternalCommandFirstLine -CommandParts @("node", "--version")',
    );
    expect(installer).toContain(
      '$npmPrefix = Normalize-CommandPathLine -Value (Get-ExternalCommandFirstLine -CommandParts @("npm", "config", "get", "prefix"))',
    );
    expect(installer).toContain(
      'Invoke-ExternalCommand -CommandParts @("where", "pnpm")',
    );
    expect(installer).toContain(
      "Get-SafeExistingCommandPath -Candidates $pnpmCandidates",
    );
    expect(installer).toContain(
      '$pnpmVersionResult = Invoke-ExternalCommand -CommandParts @($pnpmCommand, "--version")',
    );
    expect(installer).toContain(
      "Invoke-PnpmInstallWithRegistryFallback -PnpmCommand $pnpmCommand",
    );
    expect(installer).not.toContain(
      "& pnpm install --config.dangerouslyAllowAllBuilds=true",
    );
    expect(installer).not.toContain("& npm install -g pnpm 2>&1");
    expect(installer).not.toContain("& node --version");
    expect(installer).not.toContain("& npm config get prefix");
    expect(installer).not.toContain("& $pnpmCommand install");
    expect(installer).not.toContain("$( & $pnpmCommand --version )");
  });

  it("retries dependency installation through multiple registries on slow Windows networks", () => {
    const installer = readProjectFile("windows-setup/install.ps1");

    expect(installer).toContain("Invoke-PnpmInstallWithRegistryFallback");
    expect(installer).toContain("https://registry.npmjs.org/");
    expect(installer).toContain("https://registry.npmmirror.com/");
    expect(installer).toContain("--fetch-retries");
    expect(installer).toContain("--fetch-timeout");
    expect(installer).toContain("--network-concurrency");
  });

  it("keeps heavyweight installer caches and tools outside the extracted software directory", () => {
    const installer = readProjectFile("windows-setup/install.ps1");
    const toolRuntime = readProjectFile(
      "artifacts/api-server/src/lib/tool-runtime.ts",
    );
    const plan = readProjectFile(
      "docs/windows-install-cache-uninstall-plan.md",
    );

    expect(installer).toContain(
      '$mediaSculptLocalRoot = Join-Path $env:LOCALAPPDATA "MediaSculpt"',
    );
    expect(installer).toContain(
      '$cacheDir = Join-Path $mediaSculptLocalRoot "Cache"',
    );
    expect(installer).toContain(
      '$toolsDir = Join-Path $mediaSculptLocalRoot "Tools"',
    );
    expect(installer).toContain(
      '$env:npm_config_cache = Join-Path $cacheDir "npm"',
    );
    expect(installer).toContain("$env:PNPM_HOME");
    expect(installer).toContain("pnpm-store");
    expect(installer).not.toMatch(/electron/i);
    expect(installer).toContain("MEDIASCULPT_TOOLS_DIR=$toolsDir");
    expect(installer).not.toContain('$toolsDir = "$projectDir\\tools"');
    expect(toolRuntime).toContain('"tools"');
    expect(plan).toContain("Cache");
    expect(plan).toContain("Tools");
  });

  it("does not install, verify, or repair an Electron desktop runtime", () => {
    const installer = readProjectFile("windows-setup/install.ps1");
    const plan = readProjectFile(
      "docs/windows-install-cache-uninstall-plan.md",
    );

    expect(installer).not.toMatch(/electron/i);
    expect(installer).not.toContain("desktop-shell");
    expect(installer).not.toContain("desktopRuntimeVerified");
    expect(installer).not.toContain("Installing desktop window dependencies");
    expect(installer).toContain("Download-FileWithCache");
    expect(installer).toContain('Range"] = "bytes=$existingBytes-"');
    expect(installer).toContain(".part");
    expect(installer).toContain("-TimeoutSec");
    expect(installer).toContain("$downloadAttempts = 2");
    expect(plan).not.toMatch(/electron/i);
    expect(plan).toContain("Tauri");
  });

  it("keeps PowerShell 5.1 string interpolation valid in installer download logging", () => {
    const installer = readProjectFile("windows-setup/install.ps1");

    expect(installer).not.toContain("$downloadAttempts:");
    expect(installer).toContain("${downloadAttempts}:");
  });

  it("uses a unified multi-source downloader with China-friendly mirrors for every Windows bootstrap download", () => {
    const installer = readProjectFile("windows-setup/install.ps1");
    const plan = readProjectFile(
      "docs/windows-install-cache-uninstall-plan.md",
    );

    expect(installer).toContain("function Download-FileFromSources");
    expect(installer).toContain("$nodeDownloadSources");
    expect(installer).toContain("$ffmpegDownloadSources");
    expect(installer).toContain("Resolve-HandBrakeDownloadSources");
    expect(installer).toContain("$pythonDownloadSources");
    expect(installer).toContain("$pipIndexSources");
    expect(installer).toContain("https://npmmirror.com/mirrors/node/");
    expect(installer).toContain("https://npmmirror.com/mirrors/python/");
    expect(installer).toContain("https://gh.llkk.cc/");
    expect(installer).toContain("https://mirror.ghproxy.com/");
    expect(installer).toContain("https://pypi.tuna.tsinghua.edu.cn/simple");
    expect(installer).toContain("https://pypi.org/simple");
    expect(plan).toContain("Node.js");
    expect(plan).toContain("FFmpeg");
    expect(plan).toContain("HandBrakeCLI");
    expect(plan).toContain("Python");
    expect(plan).toContain("Whisper");
    expect(plan).toContain("domestic mirrors");
  });

  it("installs and pins the project FFmpeg only after dvdvideo capability verification", () => {
    const installer = readProjectFile("windows-setup/install.ps1");
    const launcher = readProjectFile("windows-setup/start-services.ps1");

    expect(installer).toContain("ffmpeg-master-latest-win64-gpl.zip");
    expect(installer).not.toContain("ffmpeg-release-essentials.zip");
    expect(installer).toContain("-hide_banner -demuxers");
    expect(installer).toContain("-hide_banner -buildconf");
    expect(installer).toContain("dvdvideo");
    expect(installer).toContain("--enable-libdvdnav");
    expect(installer).toContain("--enable-libdvdread");
    expect(installer).toContain("ffmpeg-capabilities.log");
    expect(installer).toContain("MEDIASCULPT_FFMPEG_PATH=");
    expect(installer).toContain("MEDIASCULPT_FFPROBE_PATH=");
    expect(installer).not.toContain("$envContent = \"DATABASE_DRIVER=sqlite`nMEDIASCULPT_DATABASE_PATH=$dataDir\\mediasculpt.db`nMEDIASCULPT_TOOLS_DIR=$toolsDir`nMEDIASCULPT_CACHE_DIR=$cacheDir`nVX_AGENT_FFMPEG_PATH=");
    expect(launcher).toContain('set "MEDIASCULPT_FFMPEG_PATH=$ffmpegPath"');
    expect(launcher).toContain('set "MEDIASCULPT_FFPROBE_PATH=$ffprobePath"');
    expect(launcher).toContain('set "VX_AGENT_FFMPEG_PATH=$ffmpegPath"');
    expect(launcher).toContain('set "VX_AGENT_FFPROBE_PATH=$ffprobePath"');
  });

  it("checks startup risks before launching hidden Windows services", () => {
    const services = readProjectFile("windows-setup/start-services.ps1");

    expect(services).toContain("function Test-LocalPortAvailable");
    expect(services).toContain("Port 8080 is already in use");
    expect(services).toContain("Port 24403 is already in use");
    expect(services).toContain(
      "$diagnosticsParent = Split-Path $diagnosticsLog",
    );
    expect(services).not.toContain("Diagnostics log is not writable");
    expect(services).not.toContain("Test-DiagnosticsLogWritable");
  });

  it("creates an install manifest and a safe uninstaller with cache/tool cleanup choices", () => {
    const installer = readProjectFile("windows-setup/install.ps1");
    const uninstaller = readProjectFile("windows-setup/uninstall.ps1");
    const uninstallBatch = readProjectFile("Uninstall MediaSculpt.bat");
    const plan = readProjectFile(
      "docs/windows-install-cache-uninstall-plan.md",
    );

    expect(installer).toContain(
      '$installManifestPath = Join-Path $mediaSculptLocalRoot "install-manifest.json"',
    );
    expect(installer).toContain("Write-InstallManifest");
    expect(installer).toContain("install-manifest.json");
    expect(installer).toContain("Uninstall MediaSculpt.bat");
    expect(uninstaller).toContain("param(");
    expect(uninstaller).toContain("software");
    expect(uninstaller).toContain("cache");
    expect(uninstaller).toContain("tools");
    expect(uninstaller).toContain("all");
    expect(uninstaller).toContain("install-manifest.json");
    expect(uninstaller).toContain("Remove-Item");
    expect(uninstallBatch).toContain("windows-setup\\uninstall.ps1");
    expect(plan).toContain("only uninstall software");
    expect(plan).toContain("complete uninstall");
  });

  it("deletes the extracted software folder after root uninstall while preserving user caches by default", () => {
    const uninstaller = readProjectFile("Uninstall MediaSculpt.bat");
    const uninstallScript = readProjectFile("windows-setup/uninstall.ps1");
    expect(uninstaller).toContain("rmdir /s /q");
    expect(uninstaller).toContain("MODE");
    expect(uninstallScript).toContain("LOCALAPPDATA");
  });

  it("blocks startup after an incomplete install instead of launching broken services", () => {
    const installer = readProjectFile("windows-setup/install.ps1");
    const services = readProjectFile("windows-setup/start-services.ps1");

    expect(installer).toContain(".mediasculpt-install-complete");
    expect(installer).toContain("Set-Content -Path $installMarker");
    expect(services).toContain(".mediasculpt-install-complete");
    expect(services).toContain("Installation did not complete");
    expect(services).toContain("Run windows-setup");
    expect(services).toContain("node_modules");
  });

  it("checks native Windows tools without treating normal stderr as a failed install", () => {
    const installer = readProjectFile("windows-setup/install.ps1");

    expect(installer).toContain("function Test-Command");
    expect(installer).toContain("cmd.exe /d /s /c");
    expect(installer).toContain("$LASTEXITCODE -eq 0");
    expect(installer).not.toContain('Invoke-Expression "$Cmd 2>&1"');
  });

  it("normalizes pnpm build-policy settings for pnpm 11 before Windows dependency installation", () => {
    const installer = readProjectFile("windows-setup/install.ps1");

    expect(installer).toContain("Remove-PnpmYamlListBlock");
    expect(installer).toContain(
      'Remove-PnpmYamlListBlock -Yaml $yaml -Key "onlyBuiltDependencies"',
    );
    expect(installer).toContain(
      'Remove-PnpmYamlListBlock -Yaml $yaml -Key "neverBuiltDependencies"',
    );
    expect(installer).toContain("Ensure-PnpmAllowBuild");
    expect(installer).toContain("allowBuilds:");
    expect(installer).toContain("  esbuild: true");
    expect(installer).not.toContain(
      'Remove-PnpmYamlListBlock -Yaml $yaml -Key "allowBuilds"',
    );
  });

  it("rejects mixed package versions before installation or startup", () => {
    const releaseId = readProjectFile("windows-setup/release-id.txt").trim();
    const installer = readProjectFile("windows-setup/install.ps1");
    const diagnostics = readProjectFile(
      "windows-setup/start-with-diagnostics.ps1",
    );
    const services = readProjectFile("windows-setup/start-services.ps1");
    const launcher = readProjectFile("Start MediaSculpt.bat");

    expect(releaseId).toMatch(/^\d{4}\.\d{2}\.\d{2}\.\d+$/);
    expect(installer).toContain(`$expectedRelease = "${releaseId}"`);
    expect(installer).toContain("Package version mismatch");
    expect(diagnostics).toContain(`$expectedRelease = "${releaseId}"`);
    expect(diagnostics).toContain("Package version mismatch");
    expect(services).toContain(`# MediaSculpt-Release: ${releaseId}`);
    expect(launcher).toContain(`MediaSculpt-Release: ${releaseId}`);
  });

  it("appends every startup run into the unified diagnostics log with an identifiable current run", () => {
    const diagnostics = readProjectFile(
      "windows-setup/start-with-diagnostics.ps1",
    );

    expect(diagnostics).toContain("[Guid]::NewGuid()");
    expect(diagnostics).toContain("Add-Content -Path $logPath");
    expect(diagnostics).toContain("===== STARTUP =====");
    expect(diagnostics).toContain('"Release: $releaseId"');
    expect(diagnostics).toContain('"Run ID: $runId"');
    expect(diagnostics).toContain('"Project directory: $projectDir"');
    expect(diagnostics).toContain('"Started at:');
  });

  it("provides a default root launcher that immediately delegates to the hidden launcher without a blocking console", () => {
    const launcher = readProjectFile("Start MediaSculpt.bat");
    const hiddenLauncher = readProjectFile("windows-setup/hidden-launcher.vbs");

    expect(launcher).toContain("mediasculpt-diagnostics.log");
    expect(launcher).toContain("hidden-launcher.vbs");
    expect(launcher).not.toMatch(/pause/i);
    expect(launcher).not.toContain("start-with-diagnostics.ps1");
    expect(launcher).not.toContain("powershell.exe -NoProfile");
    expect(hiddenLauncher).toContain("start-with-diagnostics.ps1");
    expect(hiddenLauncher).toContain("-WindowStyle Hidden");
  });

  it("routes the desktop shortcut through the logged root launcher", () => {
    const installer = readProjectFile("windows-setup/install.ps1");

    expect(installer).toContain('SpecialFolders.Item("Desktop")');
    expect(installer).toContain(
      '$launcherPath = Join-Path $scriptDir "hidden-launcher.vbs"',
    );
    expect(installer).toContain("$savedShortcut.TargetPath");
    expect(installer).toContain("wscript.exe");
    expect(installer).toContain("$savedShortcut.Arguments");
  });

  it("keeps manual diagnostics separate from the default hidden launch", () => {
    const installer = readProjectFile("windows-setup/install.ps1");
    const launcher = readProjectFile("Start MediaSculpt.bat");
    const manualDiagnostics = readProjectFile(
      "windows-setup/收集影刻诊断信息.bat",
    );

    expect(installer).toContain(
      "Default launch is hidden; manual diagnostics remain available",
    );
    expect(launcher).toContain("hidden-launcher.vbs");
    expect(manualDiagnostics).toMatch(/pause/i);
    expect(installer).toContain("Test-Path $shortcutPath");
  });

  it("protects the complete startup lifecycle with one cleanup boundary", () => {
    const services = readProjectFile("windows-setup/start-services.ps1");

    expect(services).toContain("$apiProc = $null");
    expect(services).toContain("$webProc = $null");
    expect(services).toContain("# Entire startup lifecycle cleanup boundary");
    expect(services).toContain(
      '[pscustomobject]@{ Process = $webProc; Label = "Web" }',
    );
    expect(services).toContain(
      '[pscustomobject]@{ Process = $apiProc; Label = "API" }',
    );
    expect(services).toContain('throw "API did not become ready');
    expect(services).toContain('throw "Web frontend did not become ready');
    expect(services).toContain("finally {");
    expect(services).toContain("Stop-AllServices -Silent");
  });

  it("keeps the root diagnostics file as the single upload artifact without using it as a shared live output target", () => {
    const services = readProjectFile("windows-setup/start-services.ps1");
    const diagnostics = readProjectFile(
      "windows-setup/start-with-diagnostics.ps1",
    );
    const manualDiagnostics = readProjectFile(
      "windows-setup/收集影刻诊断信息.bat",
    );
    const logsPage = readProjectFile(
      "artifacts/video-agent/src/pages/Logs.tsx",
    );
    const jobsRoute = readProjectFile(
      "artifacts/api-server/src/routes/jobs.ts",
    );

    expect(services).toContain(
      '$diagnosticsLog = Join-Path $proj "mediasculpt-diagnostics.log"',
    );
    expect(services).toContain(
      '$serviceLogDir = Join-Path $env:TEMP "MediaSculpt\\logs"',
    );
    expect(services).not.toContain("function Test-DiagnosticsLogWritable");
    expect(services).not.toContain("Diagnostics log is not writable");
    expect(services).not.toContain("Add-Content -Path $Path");
    expect(services).toContain('set "VX_AGENT_DIAGNOSTICS_LOG=');
    expect(services).toContain('set "VX_AGENT_SERVICE_LOG_DIR=$serviceLogDir"');
    expect(services).toContain(
      'set "VX_AGENT_RUNTIME_TOOLS_LOG_PATH=$toolEventsLog"',
    );
    expect(services).toContain('set "VX_AGENT_JOB_LOG_PATH=$jobEventsLog"');
    expect(services).not.toContain("Add-Content -Path $diagnosticsLog");
    expect(services).not.toContain('>> "%VX_AGENT_DIAGNOSTICS_LOG%" 2>&1');
    expect(services).not.toContain("api.log");
    expect(services).not.toContain("web.log");
    expect(services).not.toContain("runtime-tools.log");
    expect(services).not.toContain("job-runtime.log");
    expect(diagnostics).toContain("Start-Transcript");
    expect(diagnostics).toContain("launcher-transcript.tmp.log");
    expect(diagnostics).not.toContain("Start-Transcript -Path $logPath");
    expect(diagnostics).not.toContain("Append-ServiceLog");
    expect(diagnostics).not.toContain("api.log");
    expect(diagnostics).not.toContain("web.log");
    expect(manualDiagnostics).not.toContain("for %%F in");
    expect(manualDiagnostics).toContain("MediaSculpt\\Tools");
    expect(logsPage).toContain("logs.diagnosticsLog");
    expect(zhPack()).toContain("统一诊断日志");
    expect(logsPage).not.toContain("api.log");
    expect(logsPage).not.toContain("runtime-tools.log");
    expect(jobsRoute).toContain("diagnosticsLog");
    expect(jobsRoute).not.toContain("apiLog");
    expect(diagnostics).not.toContain("launcher-output.log");
  });
});
