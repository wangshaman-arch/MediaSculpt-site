import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { projectRoot, readProjectFile } from "./windows-contract-helpers";

const SKIP_DIRECTORIES = new Set([
  "node_modules",
  ".git",
  "dist",
  "target",
  "release",
  ".pnpm-store",
  ".worktrees",
]);

function listMarkdownFiles(directory: string, out: string[] = []): string[] {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (SKIP_DIRECTORIES.has(entry.name)) continue;
    const full = path.join(directory, entry.name);
    if (entry.isDirectory()) listMarkdownFiles(full, out);
    else if (entry.name.endsWith(".md")) out.push(full);
  }
  return out;
}

/** VERSION.md is the single source of truth; every other location must agree with it. */
describe("version contract", () => {
  const display =
    /\*\*Current version: V (\d+\.\d+)\*\*/.exec(
      readProjectFile("VERSION.md"),
    )?.[1] ?? "";
  const semver = `${display}.0`;

  it("declares one current version in VERSION.md", () => {
    expect(display).toMatch(/^\d+\.\d{3}$/);
  });

  it("keeps the package manifests and the Tauri config on that version", () => {
    // AGENTS.md is intentionally removed from the release tree. Keep legacy
    // checkouts aligned when it is present, without requiring the old file.
    const agentsPath = path.join(projectRoot, "AGENTS.md");
    if (fs.existsSync(agentsPath)) {
      expect(readProjectFile("AGENTS.md")).toContain(
        `Current version: \`V ${display}\``,
      );
    }
    expect(JSON.parse(readProjectFile("package.json")).version).toBe(semver);
    expect(
      JSON.parse(readProjectFile("desktop-tauri/package.json")).version,
    ).toBe(semver);
    expect(
      JSON.parse(readProjectFile("desktop-tauri/src-tauri/tauri.conf.json"))
        .version,
    ).toBe(semver);
    expect(readProjectFile("desktop-tauri/src-tauri/Cargo.toml")).toContain(
      `version = "${semver}"`,
    );
    expect(
      readProjectFile("desktop-tauri/src-tauri/Cargo.lock").replace(
        /\r\n/g,
        "\n",
      ),
    ).toContain(`name = "mediasculpt"\nversion = "${semver}"`);
  });

  it("keeps the release id, the UI fallback and the installer file names aligned", () => {
    const patch = display.split(".")[1];
    expect(readProjectFile("windows-setup/release-id.txt").trim()).toMatch(
      new RegExp(`^\\d{4}\\.\\d{2}\\.\\d{2}\\.${patch}$`),
    );
    expect(readProjectFile("artifacts/video-agent/src/App.tsx")).toContain(
      `?? "V ${display}"`,
    );
    for (const file of [
      "README.md",
      "INSTALL.md",
      "windows-setup/README.txt",
    ]) {
      const names =
        readProjectFile(file).match(
          /MediaSculpt_\d+\.\d+\.\d+_x64-setup-base\.exe/g,
        ) ?? [];
      expect(names.length, file).toBeGreaterThan(0);
      for (const name of names)
        expect(name, file).toBe(`MediaSculpt_${semver}_x64-setup-base.exe`);
    }
  });

  it("stamps every Markdown file with the current version header", () => {
    const header = `> **Version:** V ${display} · 版本：V ${display}`;
    const offenders = listMarkdownFiles(projectRoot)
      .filter((file) => !fs.readFileSync(file, "utf8").includes(header))
      .map((file) => path.relative(projectRoot, file));
    expect(offenders).toEqual([]);
  });
});
