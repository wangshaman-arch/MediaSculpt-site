import fs from "node:fs/promises";
import path from "node:path";

/**
 * Durable per-title metadata, stored beside the media.
 *
 * Today the only cached artefact is a poster *URL* in the system temp
 * directory, so a machine without AI/API access re-queries the network for
 * every title and shows nothing at all when the network is unavailable. This
 * module makes a resolved title durable and readable offline.
 *
 * The record carries `resolvedBy`, which encodes the capability tier that
 * produced it, so a caller can tell a fully offline (filename-only) record from
 * one enriched by API keys, and deliberately re-resolve when it is worthwhile:
 *
 *   "filename"  — title/year parsed from the name; always available, no network
 *   "keyless"   — enriched by free keyless sources (IMDb suggestion, Wikipedia)
 *   "keyed"     — enriched by keyed sources (TMDb/OMDb) or the local IMDb dataset
 *   "ai"        — additionally corrected/summarised with the configured LLM
 *
 * The file lives inside the media folder, so it travels with the library and
 * survives re-installs, cache clearing and offline machines.
 */

export const TITLE_METADATA_FILE = "metadata.json";

export type MetadataTier = "filename" | "keyless" | "keyed" | "ai";

const TIER_ORDER: Record<MetadataTier, number> = {
  filename: 0,
  keyless: 1,
  keyed: 2,
  ai: 3,
};

export type TitleMetadataRecord = {
  version: 1;
  /** Capability tier that produced this record. */
  resolvedBy: MetadataTier;
  title?: string | null;
  titleEn?: string | null;
  year?: number | null;
  imdbId?: string | null;
  tmdbId?: number | null;
  director?: string | null;
  cast?: string | null;
  genres?: string | null;
  rating?: number | null;
  ratingSource?: string | null;
  runtimeMinutes?: number | null;
  overview?: string | null;
  /** Field name -> provider id, so a user can see where each value came from. */
  sources?: Record<string, string> | null;
  poster?: string | null;
  resolvedAt?: string | null;
};

export function titleMetadataPath(targetDirectory: string): string {
  return path.join(targetDirectory, TITLE_METADATA_FILE);
}

/** Rank a tier so callers can decide whether a re-resolve is an upgrade. */
export function tierRank(tier: MetadataTier): number {
  return TIER_ORDER[tier] ?? 0;
}

/**
 * Infer the tier of a historical record that predates the `resolvedBy` field,
 * so an older file is not discarded or wrongly reported as fully enriched.
 */
export function inferTier(record: Partial<TitleMetadataRecord>): MetadataTier {
  if (record.resolvedBy && TIER_ORDER[record.resolvedBy] !== undefined) return record.resolvedBy;
  if (record.overview || record.rating || record.director || record.cast) return "keyed";
  if (record.imdbId || record.titleEn) return "keyless";
  return "filename";
}

/**
 * Fields that only a keyed or AI tier can supply. Used to decide whether a
 * cached record is worth replacing.
 */
export function hasEnrichment(record: Partial<TitleMetadataRecord> | null | undefined): boolean {
  if (!record) return false;
  return Boolean(record.director || record.cast || record.genres || record.overview || record.rating);
}

export type ReadResult = {
  record: TitleMetadataRecord | null;
  tier: MetadataTier | null;
};

/**
 * Read the sidecar. Never throws: a corrupt or missing file simply means
 * "nothing cached", which lets the caller fall back to the network.
 */
export async function readTitleMetadata(targetDirectory: string): Promise<ReadResult> {
  try {
    const raw = await fs.readFile(titleMetadataPath(targetDirectory), "utf8");
    const parsed = JSON.parse(raw) as Partial<TitleMetadataRecord>;
    if (!parsed || typeof parsed !== "object") return { record: null, tier: null };
    const tier = inferTier(parsed);
    return { record: { version: 1, ...parsed, resolvedBy: tier }, tier };
  } catch {
    return { record: null, tier: null };
  }
}

/**
 * Merge new values into the sidecar and write it atomically.
 *
 * Merge semantics match `mergeResults`: an existing non-empty value is never
 * replaced by an empty one, so a failed keyed lookup cannot erase what the
 * keyless tier already established. `resolvedBy` only moves upward.
 */
export async function writeTitleMetadata(
  targetDirectory: string,
  incoming: Partial<TitleMetadataRecord>,
  tier: MetadataTier,
): Promise<TitleMetadataRecord | null> {
  try {
    const existing = (await readTitleMetadata(targetDirectory)).record;
    const merged: TitleMetadataRecord = {
      version: 1,
      resolvedBy: tier,
      ...(existing ?? {}),
    };
    for (const [key, value] of Object.entries(incoming)) {
      if (key === "resolvedBy" || key === "version") continue;
      if (value === undefined || value === null || value === "") continue;
      const current = (merged as Record<string, unknown>)[key];
      if (current === undefined || current === null || current === "") {
        (merged as Record<string, unknown>)[key] = value;
      }
    }
    const previousTier = existing ? inferTier(existing) : null;
    merged.resolvedBy = previousTier && tierRank(previousTier) > tierRank(tier) ? previousTier : tier;
    merged.resolvedAt = new Date().toISOString();
    await fs.mkdir(targetDirectory, { recursive: true });
    const target = titleMetadataPath(targetDirectory);
    const temp = `${target}.tmp`;
    await fs.writeFile(temp, JSON.stringify(merged, null, 2), "utf8");
    await fs.rename(temp, target);
    return merged;
  } catch {
    // Metadata persistence is best-effort and must never fail a media job.
    return null;
  }
}
