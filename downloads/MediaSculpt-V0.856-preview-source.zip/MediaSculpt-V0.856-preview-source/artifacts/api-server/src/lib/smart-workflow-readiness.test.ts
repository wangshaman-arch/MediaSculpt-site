import { describe, expect, it } from "vitest";
import * as workflow from "./smart-workflow";

describe("smart workflow job readiness", () => {
  it("requires exact DVD title verification before a Remux job can be created", () => {
    const requiresVerification = (workflow as unknown as {
      workflowItemRequiresTitleVerification?: (item: unknown) => boolean;
    }).workflowItemRequiresTitleVerification;

    expect(requiresVerification?.({ sourceType: "dvd", action: "remux", analysisId: "a1", titleId: "handbrake:5" })).toBe(true);
    expect(requiresVerification?.({ sourceType: "dvd", action: "compress", analysisId: "a1", titleId: "handbrake:5" })).toBe(false);
    expect(requiresVerification?.({ sourceType: "video", action: "remux", analysisId: null, titleId: null })).toBe(false);
  });
});
