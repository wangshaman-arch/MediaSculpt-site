// Extracted from subtitle-ocr.ts: the Tesseract OCR engine path.
import { deflateSync, inflateSync } from "node:zlib";
import { encodePng, decodePngRgba } from "./subtitle-ocr-png";
import { createHash } from "node:crypto";
import path from "node:path";
import { access } from "node:fs/promises";
import { resolveAiEndpoint, resolveApiKey, type AiProviderConfig } from "./ai-provider";
import { resolveToolPath } from "./tool-runtime";
import { findDvdTitles, resolveDvdVideoTsDir } from "./disc";
import { isGraphicSubtitleCodec } from "./subtitle-utils";

import {
  ensureTesseractLanguageData,
  cleanupCjkSpacing,
} from "./subtitle-ocr";

export function tesseractLanguageToIso(lang: string): string {
  if (lang === "chi_sim" || lang === "chi_tra") return "zh";
  if (lang === "jpn") return "ja";
  if (lang === "kor") return "ko";
  if (lang === "rus") return "ru";
  return "en";
}

export async function ocrWithTesseract(
  images: Array<{ index: number; png: Buffer }>,
  language: string,
): Promise<Array<{ index: number; text: string; language: string; confidence?: number | null }>> {
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const { mkdtemp, writeFile, readFile, rm } = await import("node:fs/promises");
  const { tmpdir } = await import("node:os");
  const { join } = await import("node:path");
  const execFileAsync = promisify(execFile);
  const tesseractPath = await resolveToolPath("tesseract");
  if (!tesseractPath) {
    throw new Error("未找到本地 Tesseract。请安装 Tesseract OCR（含语言数据）并放入工具目录，或改选“大模型识别”。");
  }
  await ensureTesseractLanguageData(tesseractPath, language);
  const dir = await mkdtemp(join(tmpdir(), "vx-tess-"));
  const results: Array<{ index: number; text: string; language: string; confidence?: number | null }> = [];
  try {
    for (const image of images) {
      const input = join(dir, `event-${image.index}.png`);
      await writeFile(input, prepareOcrPng(image.png));
      try {
        const { stdout } = await execFileAsync(tesseractPath, [input, "stdout", "-l", language, "--psm", "6", "tsv"], { timeout: 60_000 });
        const parsed = parseTesseractTsv(stdout);
        results.push({
          index: image.index,
          text: fixOcrCharacterConfusions(cleanupCjkSpacing(parsed.text.trim())),
          language: tesseractLanguageToIso(language),
          confidence: parsed.confidence,
        });
      } catch (error) {
        results.push({ index: image.index, text: "", language: tesseractLanguageToIso(language), confidence: null });
      }
    }
  } finally {
    await rm(dir, { recursive: true, force: true }).catch(() => {});
  }
  return results;
}

/**
 * 字幕图 OCR 预处理：二值化 + 内容裁剪 + 文字过小时放大。
 * 低分辨率 VobSub 字幕的细笔画（如衬线 I）与竖线 | 在像素上几乎相同，
 * 裁剪聚焦文字区域、强化边缘后，Tesseract 的 |/I 混淆会显著减少。
 */
function prepareOcrPng(png: Buffer): Buffer {
  const { width, height, rgba } = decodePngRgba(png);
  // 二值化（黑字白底：v<128 视为墨迹）
  const bw = Buffer.alloc(width * height);
  for (let i = 0; i < width * height; i += 1) {
    bw[i] = rgba[i * 4] < 128 ? 0 : 255;
  }
  // 内容包围盒
  let minX = width, minY = height, maxX = -1, maxY = -1;
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      if (bw[y * width + x] === 0) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }
  if (maxX < minX || maxY < minY) return png; // 空白帧原样返回
  const pad = 6;
  const x0 = Math.max(0, minX - pad);
  const y0 = Math.max(0, minY - pad);
  const x1 = Math.min(width - 1, maxX + pad);
  const y1 = Math.min(height - 1, maxY + pad);
  const cw = x1 - x0 + 1;
  const ch = y1 - y0 + 1;
  const crop = Buffer.alloc(cw * ch * 4);
  for (let y = 0; y < ch; y += 1) {
    for (let x = 0; x < cw; x += 1) {
      const o = (y * cw + x) * 4;
      const v = bw[(y0 + y) * width + (x0 + x)];
      crop[o] = v;
      crop[o + 1] = v;
      crop[o + 2] = v;
      crop[o + 3] = 255;
    }
  }
  // 文字高度过小时最近邻放大到至少 48px，保留硬边缘
  let scale = 1;
  if (ch < 48) scale = Math.ceil(48 / ch);
  const sw = cw * scale;
  const sh = ch * scale;
  const scaled = scale > 1 ? Buffer.alloc(sw * sh * 4) : crop;
  if (scale > 1) {
    for (let y = 0; y < sh; y += 1) {
      const sy = Math.min(ch - 1, Math.floor(y / scale));
      for (let x = 0; x < sw; x += 1) {
        const sx = Math.min(cw - 1, Math.floor(x / scale));
        const src = (sy * cw + sx) * 4;
        const dst = (y * sw + x) * 4;
        scaled[dst] = crop[src];
        scaled[dst + 1] = crop[src + 1];
        scaled[dst + 2] = crop[src + 2];
        scaled[dst + 3] = 255;
      }
    }
  }
  return encodePng(scaled, sw, sh);
}

/** 修复 VobSub 低分辨率 OCR 的常见字符混淆：竖线 | 在字母语境中还原为 I。 */
function fixOcrCharacterConfusions(text: string): string {
  // 字幕里竖线基本都是大写 I 的误识（低分辨率细笔画）；成对出现的 || 先保护起来。
  return text
    .replace(/\|\|/g, "\u0000")
    .replace(/\|/g, "I")
    .replace(/\u0000/g, "||");
}

/** Parse tesseract TSV output into per-frame text and average word confidence. */
export function parseTesseractTsv(tsv: string): { text: string; confidence: number | null } {
  const lines = tsv.split(/\r?\n/);
  if (!(lines[0] ?? "").includes("conf\ttext")) return { text: "", confidence: null };
  const words: Array<{ line: number; text: string; conf: number }> = [];
  for (let i = 1; i < lines.length; i += 1) {
    const cols = lines[i].split("\t");
    if (cols.length < 12) continue;
    if (Number(cols[0]) !== 5) continue; // level 5 = word
    const word = (cols[11] ?? "").trim();
    if (!word) continue;
    const conf = Number(cols[10]);
    words.push({ line: Number(cols[4]), text: word, conf: Number.isFinite(conf) ? conf : -1 });
  }
  const confidences = words.map((word) => word.conf).filter((conf) => conf >= 0);
  const byLine = new Map<number, string[]>();
  for (const word of words) {
    const bucket = byLine.get(word.line) ?? [];
    bucket.push(word.text);
    byLine.set(word.line, bucket);
  }
  const text = [...byLine.values()].map((bucket) => bucket.join(" ")).join("\n");
  const confidence = confidences.length > 0 ? confidences.reduce((sum, value) => sum + value, 0) / confidences.length : null;
  return { text, confidence };
}
