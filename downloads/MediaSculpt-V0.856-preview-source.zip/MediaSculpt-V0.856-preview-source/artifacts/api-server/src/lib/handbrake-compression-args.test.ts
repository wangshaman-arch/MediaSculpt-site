import { describe, expect, it } from "vitest";
import { buildHandBrakeSelectionArgs, parseHandBrakeSelectionPlan } from "./handbrake-compression-args";

describe("HandBrake compression selection args", () => {
  it("maps selected UI stream indexes to HandBrake audio and subtitle track numbers", () => {
    const plan = parseHandBrakeSelectionPlan(JSON.stringify({
      version: 1,
      video: [0],
      audio: [1, 2],
      subtitle: [4],
      chapters: [0, 1, 2],
      handbrake: {
        titleNumber: 3,
        audioTrackNumbers: [1, 2],
        subtitleTrackNumbers: [2],
        chapterNumbers: [1, 2, 3],
      },
    }));

    expect(buildHandBrakeSelectionArgs(plan, { audioCopy: true })).toEqual([
      "--title", "3",
      "--audio", "1,2",
      "--aencoder", "copy,copy",
      "--subtitle", "2",
      "--chapters", "1-3",
      "--markers",
    ]);
  });

  it("does not fall back to all audio or all subtitles when the user explicitly selects a subset", () => {
    const plan = parseHandBrakeSelectionPlan(JSON.stringify({
      version: 1,
      video: [0],
      audio: [2],
      subtitle: [],
      chapters: [],
      handbrake: {
        titleNumber: 1,
        audioTrackNumbers: [2],
        subtitleTrackNumbers: [],
        chapterNumbers: [],
      },
    }));

    const args = buildHandBrakeSelectionArgs(plan, { audioCopy: false });

    expect(args).toContain("--audio");
    expect(args).toContain("2");
    expect(args).toContain("--subtitle");
    expect(args).toContain("none");
    expect(args).not.toContain("--all-audio");
    expect(args).not.toContain("--all-subtitles");
  });

  it("preserves selected disc title size and duration for per-title compression statistics", () => {
    const plan = parseHandBrakeSelectionPlan(JSON.stringify({
      version: 1,
      video: [0],
      audio: [1],
      subtitle: [2],
      chapters: [0, 1],
      handbrake: {
        titleNumber: 7,
        titleSizeBytes: 1_734_000_000,
        durationSeconds: 5421.4,
        audioTrackNumbers: [1],
        subtitleTrackNumbers: [1],
        chapterNumbers: [1, 2],
      },
    }));

    expect(plan?.handbrake?.titleNumber).toBe(7);
    expect(plan?.handbrake?.titleSizeBytes).toBe(1_734_000_000);
    expect(plan?.handbrake?.durationSeconds).toBe(5421.4);
  });

  // Regression: a selected stream keeps no handbrakeTrackNumber when the scan
  // did not report one. Deciding on the mapping alone silently forced
  // `--subtitle none` and let HandBrake choose its own audio default, dropping
  // tracks the user had explicitly selected.
  it("keeps all subtitles when the user selected subtitle streams that have no HandBrake mapping", () => {
    const plan = parseHandBrakeSelectionPlan(JSON.stringify({
      version: 1,
      video: [0],
      audio: [1],
      subtitle: [4, 5],
      chapters: [],
      handbrake: {
        titleNumber: 1,
        audioTrackNumbers: [1],
        subtitleTrackNumbers: [],
        chapterNumbers: [],
      },
    }));

    const args = buildHandBrakeSelectionArgs(plan, { audioCopy: true });

    expect(args).toContain("--all-subtitles");
    expect(args).not.toContain("none");
  });

  it("keeps all audio when the user selected audio streams that have no HandBrake mapping", () => {
    const plan = parseHandBrakeSelectionPlan(JSON.stringify({
      version: 1,
      video: [0],
      audio: [1, 2],
      subtitle: [],
      chapters: [],
      handbrake: {
        titleNumber: 1,
        audioTrackNumbers: [],
        subtitleTrackNumbers: [],
        chapterNumbers: [],
      },
    }));

    const args = buildHandBrakeSelectionArgs(plan, { audioCopy: true });

    expect(args).toContain("--all-audio");
    expect(args).not.toContain("--audio");
  });
});
