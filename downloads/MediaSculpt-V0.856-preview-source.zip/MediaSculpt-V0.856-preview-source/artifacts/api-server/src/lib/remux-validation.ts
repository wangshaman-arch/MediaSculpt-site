import fs from "node:fs/promises";

export type RemuxProbe = {
  duration: number | null;
  streams?: Array<{ codecType?: string; language?: string | null }>;
  chapters?: Array<unknown>;
  timestamps?: readonly number[];
};

export type RemuxValidationOptions = {
  expectedSizeBytes?: number | null;
  minimumSizeRatio?: number;
  /** Upper bound for a stream-copy output relative to the selected physical source payload. */
  maximumSizeRatio?: number;
  /** Fixed allowance for Matroska/container metadata and small codec repacking overhead. */
  maximumSizeOverheadBytes?: number;
  /** Reject output duration drift beyond this ratio when the selected title is authoritative. */
  maximumDurationDrift?: number;
  expectedStreamCounts?: { video: number; audio: number; subtitle: number };
  expectedChapterCount?: number | null;
};

export async function validateRemuxOutput(
  filePath: string,
  expectedDuration: number | null,
  probe: (filePath: string) => Promise<RemuxProbe>,
  options: RemuxValidationOptions = {},
): Promise<{ fileSize: number; duration: number | null; drift: number | null }> {
  const stat = await fs.stat(filePath).catch(() => null);
  if (!stat || stat.size <= 0) throw new Error("Remux 输出文件为空");

  const result = await probe(filePath);
  const drift = result.duration !== null && expectedDuration && expectedDuration > 0
    ? Math.abs(result.duration - expectedDuration) / expectedDuration
    : null;

  if (drift !== null && options.maximumDurationDrift != null && options.maximumDurationDrift >= 0 && drift > options.maximumDurationDrift) {
    throw new Error(`Remux 输出时长偏离所选标题：源 ${expectedDuration?.toFixed(1)} 秒，输出 ${result.duration?.toFixed(1)} 秒，偏差 ${(drift * 100).toFixed(1)}%`);
  }

  const minimumSizeRatio = options.minimumSizeRatio ?? 0.65;
  // 大小校验必须结合时长：短标题/花絮（如 17 分钟附片）相对整张主碟会"显得过小"，
  // 但其时长与所选标题一致、是正确 remux。只有"既过小、时长也明显偏离所选标题"才判定异常。
  if (options.expectedSizeBytes && options.expectedSizeBytes > 0) {
    const minimumSizeBytes = options.expectedSizeBytes * minimumSizeRatio;
    const sizeLooksTooSmall = stat.size < minimumSizeBytes;
    const durationLooksOff = drift === null ? false : drift > 0.15;
    if (sizeLooksTooSmall && durationLooksOff) {
      throw new Error(`Remux 输出文件明显小于所选源：输出 ${(stat.size / 1024 / 1024).toFixed(1)} MB，所选源 ${(options.expectedSizeBytes / 1024 / 1024).toFixed(1)} MB，低于 ${(minimumSizeRatio * 100).toFixed(0)}% 安全阈值，且时长偏离 ${(drift! * 100).toFixed(0)}%`);
    }
    if (options.maximumSizeRatio != null && options.maximumSizeRatio > 0) {
      const overhead = Math.max(0, options.maximumSizeOverheadBytes ?? 0);
      const maximumSizeBytes = options.expectedSizeBytes * options.maximumSizeRatio + overhead;
      if (stat.size > maximumSizeBytes) {
        throw new Error(`Remux 输出超过所选 VOB 物理载荷：输出 ${(stat.size / 1024 / 1024).toFixed(1)} MB，所选 VOB ${(options.expectedSizeBytes / 1024 / 1024).toFixed(1)} MB，上限 ${(maximumSizeBytes / 1024 / 1024).toFixed(1)} MB`);
      }
    }
  }

  if (result.duration !== null && result.duration <= 0) throw new Error("Remux 输出时长为 0");
  if (result.timestamps) {
    if (result.timestamps.some((timestamp) => !Number.isFinite(timestamp))) {
      throw new Error("Remux 输出包含无效时间戳");
    }
    for (let index = 1; index < result.timestamps.length; index += 1) {
      if (result.timestamps[index]! < result.timestamps[index - 1]!) {
        throw new Error("Remux 输出时间戳不单调");
      }
    }
  }
  if (options.expectedStreamCounts && result.streams) {
    const actual = {
      video: result.streams.filter((stream) => stream.codecType === "video").length,
      audio: result.streams.filter((stream) => stream.codecType === "audio").length,
      subtitle: result.streams.filter((stream) => stream.codecType === "subtitle").length,
    };
    const missing = (["video", "audio", "subtitle"] as const)
      .filter((type) => actual[type] < options.expectedStreamCounts![type])
      .map((type) => `${type} ${actual[type]}/${options.expectedStreamCounts![type]}`);
    if (missing.length > 0) throw new Error(`处理完成，但输出流轨验证未通过：缺少 ${missing.join("、")}`);
  }
  if (options.expectedChapterCount != null && result.chapters && result.chapters.length < options.expectedChapterCount) {
    throw new Error(`处理完成，但输出章节验证未通过：${result.chapters.length}/${options.expectedChapterCount}`);
  }
  return { fileSize: stat.size, duration: result.duration, drift };
}
