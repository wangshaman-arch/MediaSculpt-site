import { buildDvdShortReadArgs, buildDvdTimestampProbeArgs, verifyDvdTitle, type DvdStream, type ExternalToolRunner } from "./dvd-remux";

export type DvdTitleReadEvidence = {
  status: "passed" | "failed";
  durationSeconds: number | null;
  videoFrameCount: number;
  timestampStatus: "not-measured" | "monotonic" | "failed";
  warnings: string[];
  failureReason: string | null;
};

export type DvdTitleReadInput = {
  sourcePath: string;
  titleNumber: number;
  handbrakeDurationSeconds: number | null;
  handbrakeChapterCount: number;
  handbrakeStreams?: DvdStream[];
  ffprobeExecutable: string;
  ffmpegExecutable: string;
};

function failed(reason: string, durationSeconds: number | null = null, warnings: string[] = []): DvdTitleReadEvidence {
  return { status: "failed", durationSeconds, videoFrameCount: 0, timestampStatus: "failed", warnings, failureReason: reason };
}

function frameCount(stdout: string): number {
  const matches = [...stdout.matchAll(/(?:^|\n)frame=(\d+)/g)];
  return matches.reduce((max, match) => Math.max(max, Number(match[1])), 0);
}

export async function validateDvdTitleRead(input: DvdTitleReadInput, run: ExternalToolRunner): Promise<DvdTitleReadEvidence> {
  const exact = await verifyDvdTitle({ ...input, run });
  if (!exact.verified) return failed(exact.failureReason ?? "精确标题校验失败", exact.durationSeconds, exact.warnings);
  const duration = exact.durationSeconds ?? input.handbrakeDurationSeconds;
  const windowStarts = [0, Math.max(0, (duration ?? 12) / 2 - 2), Math.max(0, (duration ?? 12) - 4)];
  let totalFrames = 0;
  const warnings = [...exact.warnings];
  for (const [index, startSeconds] of windowStarts.entries()) {
    const read = await run({
      tool: "ffmpeg",
      executable: input.ffmpegExecutable,
      args: buildDvdShortReadArgs({ sourcePath: input.sourcePath, titleNumber: input.titleNumber, startSeconds }),
      timeoutMs: 90_000,
    });
    const frames = frameCount(read.stdout);
    totalFrames += frames;
  if (read.exitCode !== 0 || frames <= 0) {
      const labels = ["开头", "中段", "末段"];
      return failed(`${labels[index]}读取未产生视频帧：${read.failureReason ?? read.stderr.trim() ?? `退出码 ${read.exitCode ?? "未知"}`}`, duration, warnings);
    }
  }
  const timestampProbe = await run({
    tool: "ffprobe",
    executable: input.ffprobeExecutable,
    args: buildDvdTimestampProbeArgs({ sourcePath: input.sourcePath, titleNumber: input.titleNumber }),
    timeoutMs: 90_000,
  });
  if (timestampProbe.exitCode !== 0) {
    return failed(`时间码读取失败：${timestampProbe.failureReason ?? timestampProbe.stderr.trim() ?? `退出码 ${timestampProbe.exitCode ?? "未知"}`}`, duration, warnings);
  }
  let packets: Array<{ pts_time?: unknown; dts_time?: unknown }> = [];
  try {
    const parsed = JSON.parse(timestampProbe.stdout) as { packets?: Array<{ pts_time?: unknown; dts_time?: unknown }> };
    packets = parsed.packets ?? [];
  } catch {
    return failed("时间码输出无法解析", duration, warnings);
  }
  if (packets.length < 2) return failed("时间码校验没有读取到足够的视频包", duration, warnings);
  for (const field of ["pts_time", "dts_time"] as const) {
    const values = packets.map((packet) => Number(packet[field])).filter(Number.isFinite);
    for (let index = 1; index < values.length; index += 1) {
      const delta = (values[index] ?? 0) - (values[index - 1] ?? 0);
      // MPEG-2 B-frames commonly reorder PTS by one or two frame durations.
      // Treat only a large backward jump as a broken navigation/timestamp chain.
      if (delta < -0.5) {
        return failed(`${field === "pts_time" ? "PTS" : "DTS"} 时间码倒退，禁止自动选择`, duration, warnings);
      }
      if (delta < -0.001) warnings.push(`${field === "pts_time" ? "PTS" : "DTS"} 存在正常帧重排（${delta.toFixed(3)} 秒），未视为标题损坏`);
    }
  }
  return {
    status: "passed",
    durationSeconds: duration,
    videoFrameCount: totalFrames,
    timestampStatus: "monotonic",
    warnings,
    failureReason: null,
  };
}
