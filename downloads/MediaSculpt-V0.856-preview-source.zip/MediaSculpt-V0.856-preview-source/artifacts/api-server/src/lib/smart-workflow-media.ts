import fs from "node:fs/promises";
import path from "node:path";

export const SMART_WORKFLOW_MEDIA_EXTENSIONS = new Set([
  ".mkv", ".mp4", ".avi", ".mov", ".wmv", ".flv", ".m4v", ".ts", ".m2ts", ".iso", ".vob", ".rmvb", ".webm",
]);

export const SMART_WORKFLOW_SUBTITLE_EXTENSIONS = new Set([".srt", ".ass", ".ssa", ".vtt", ".sub"]);

export type ExternalSubtitleInfo = {
  path: string;
  hasChinese: boolean;
  language: string | null;
};

function isHiddenDirectory(name: string): boolean {
  return name.startsWith(".") || name === "node_modules" || name === "dist";
}

async function isDiscRootDirectory(directory: string): Promise<boolean> {
  const [bdmv, videoTs] = await Promise.all([
    fs.access(path.join(directory, "BDMV", "index.bdmv")).then(() => true).catch(() => false),
    fs.access(path.join(directory, "VIDEO_TS", "VIDEO_TS.IFO")).then(() => true).catch(() => false),
  ]);
  return bdmv || videoTs;
}

const SUBTITLE_READ_LIMIT = 512 * 1024;

const SUBTITLE_LANGUAGE_TAG = /\.(zh|chi|chs|cht|zh-cn|zh-tw|en|eng|ja|jpn|ko|kor|fr|fra|de|ger|es|spa|ru|rus|it|ita|pt|por|pl|pol|ar|ara|th|tha|vi|vie|id|ind|hi|hin|nl|dut|sv|swe|no|nor|da|dan|fi|fin|tr|tur|uk|ukr|cs|ces|sk|slo|hu|hun|ro|rum|el|gre|he|heb|ms|may|fil|tl)(?:-[a-z0-9]{2,4})?$/i;

function subtitleStemWithoutLanguageTag(value: string): string {
  return value.replace(SUBTITLE_LANGUAGE_TAG, "");
}

/**
 * Find subtitle files that belong to a video: files in the same directory whose
 * stem matches the video stem (after stripping the language tag). Only
 * same-name companion subtitles count; a Chinese subtitle from another video in
 * the same directory must not mark this video as already having Chinese
 * subtitles. Reading is capped so huge subtitle assets cannot stall the probe.
 */
export async function detectExternalSubtitles(videoPath: string): Promise<ExternalSubtitleInfo[]> {
  const dir = path.dirname(videoPath);
  const stem = path.basename(videoPath).replace(/\.[^.]+$/, "").toLowerCase();
  let entries: string[] = [];
  try {
    entries = await fs.readdir(dir);
  } catch {
    return [];
  }
  const results: ExternalSubtitleInfo[] = [];
  for (const name of entries.sort((a, b) => a.localeCompare(b))) {
    const ext = path.extname(name).toLowerCase();
    if (!SMART_WORKFLOW_SUBTITLE_EXTENSIONS.has(ext)) continue;
    const fullPath = path.join(dir, name);
    const subStem = subtitleStemWithoutLanguageTag(name.replace(/\.[^.]+$/, "").toLowerCase());
    let text = "";
    try {
      const handle = await fs.open(fullPath, "r");
      const buffer = Buffer.alloc(SUBTITLE_READ_LIMIT);
      const { bytesRead } = await handle.read(buffer, 0, buffer.length, 0);
      await handle.close();
      text = buffer.subarray(0, bytesRead).toString("utf8");
    } catch {
      continue;
    }
    const hasChinese = /[\u3400-\u9fff]/.test(text);
    if (subStem !== stem) continue;
    const lower = name.toLowerCase();
    const language = /(zh|chi|chs|cht)/.test(lower)
      ? "chi"
      : /(en|eng)/.test(lower)
        ? "eng"
        : null;
    results.push({ path: fullPath, hasChinese, language });
  }
  return results;
}

/** Recursively list media files for a normal folder source. DVD/BD folders are handled before this helper. */
export async function listSmartWorkflowMediaFiles(directory: string): Promise<string[]> {
  const root = path.resolve(directory);
  const files: string[] = [];
  const visit = async (current: string): Promise<void> => {
    // Never descend into DVD/Blu-ray disc roots: their VOB/m2ts files must be
    // analyzed via /disc/analyze, not treated as standalone videos.
    if (current !== root && await isDiscRootDirectory(current)) return;
    let entries;
    try {
      entries = await fs.readdir(current, { withFileTypes: true });
    } catch {
      // Skip unreadable directories (e.g. protected folders on a drive root)
      // instead of aborting the whole scan and reporting "no media files".
      return;
    }
    for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
      if (entry.isDirectory()) {
        if (!isHiddenDirectory(entry.name)) await visit(path.join(current, entry.name));
        continue;
      }
      if (!entry.isFile()) continue;
      if (SMART_WORKFLOW_MEDIA_EXTENSIONS.has(path.extname(entry.name).toLowerCase())) files.push(path.join(current, entry.name));
    }
  };
  await visit(root);
  return files;
}

