export type DvdTitleSizeCandidate = {
  titleNumber?: number;
  durationSeconds?: number | null;
  /** Authoritative union of IFO/PGC/Cell VOB sectors. */
  exactSizeBytes?: number | null;
  toolMappings?: {
    physicalVtsNumber?: number | null;
  };
};

/**
 * Return only authoritative title sizes. A physical VTS may contain several
 * PGCs, so its file-group size is never a valid size for an individual title.
 * The parser must supply the exact union of IFO/PGC/Cell VOB sectors; unknown
 * mappings deliberately return null so capacity checks cannot accept a guess.
 */
export function mapDvdTitleSizes(
  titles: DvdTitleSizeCandidate[],
  vtsSizes: ReadonlyMap<number, number>,
): Array<number | null> {
  const result: Array<number | null> = titles.map(() => null);
  titles.forEach((title, index) => {
    if (typeof title.exactSizeBytes === "number" && Number.isFinite(title.exactSizeBytes) && title.exactSizeBytes > 0) {
      result[index] = Math.floor(title.exactSizeBytes);
    }
  });
  void vtsSizes;
  return result;
}

export async function readDvdVtsSizes(videoTsDir: string): Promise<ReadonlyMap<number, number>> {
  const entries = await fs.readdir(videoTsDir).catch(() => [] as string[]);
  const sizes = new Map<number, number>();
  for (const name of entries) {
    const match = /^VTS_(\d+)_\d+\.VOB$/i.exec(name);
    if (!match) continue;
    const vtsNumber = Number(match[1]);
    const stat = await fs.stat(path.join(videoTsDir, name)).catch(() => null);
    if (!stat || !Number.isInteger(vtsNumber) || vtsNumber <= 0) continue;
    sizes.set(vtsNumber, (sizes.get(vtsNumber) ?? 0) + stat.size);
  }
  return sizes;
}
import fs from "node:fs/promises";
import path from "node:path";
