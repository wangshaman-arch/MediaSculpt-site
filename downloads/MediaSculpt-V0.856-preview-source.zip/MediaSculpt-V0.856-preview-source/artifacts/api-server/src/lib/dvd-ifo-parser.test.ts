import { describe, expect, it } from "vitest";
import { buildPhysicalRanges, parseVmgTitleEntries, parseVtsTitleNavigation, type DvdVobFile } from "./dvd-ifo-parser";

function writeU16(buffer: Uint8Array, offset: number, value: number): void {
  buffer[offset] = (value >>> 8) & 0xff;
  buffer[offset + 1] = value & 0xff;
}

function writeU32(buffer: Uint8Array, offset: number, value: number): void {
  buffer[offset] = (value >>> 24) & 0xff;
  buffer[offset + 1] = (value >>> 16) & 0xff;
  buffer[offset + 2] = (value >>> 8) & 0xff;
  buffer[offset + 3] = value & 0xff;
}

function dvdTime(seconds: number): Uint8Array {
  const result = new Uint8Array(4);
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  result[0] = ((Math.floor(h / 10) << 4) | (h % 10));
  result[1] = 0x40 | ((Math.floor(m / 10) << 4) | (m % 10));
  result[2] = ((Math.floor(s / 10) << 4) | (s % 10));
  result[3] = 0;
  return result;
}

function makeVmg(): Uint8Array {
  const buffer = new Uint8Array(4096);
  new TextEncoder().encode("DVDVIDEO-VMG").forEach((value, index) => { buffer[index] = value; });
  writeU32(buffer, 0xc4, 1);
  const table = 2048;
  writeU16(buffer, table, 1);
  buffer[table + 8] = 0;
  buffer[table + 9] = 1;
  writeU16(buffer, table + 10, 1);
  writeU16(buffer, table + 12, 0);
  buffer[table + 14] = 2;
  buffer[table + 15] = 1;
  writeU32(buffer, table + 16, 123);
  return buffer;
}

function makeVts(): Uint8Array {
  const buffer = new Uint8Array(8192);
  new TextEncoder().encode("DVDVIDEO-VTS").forEach((value, index) => { buffer[index] = value; });
  writeU32(buffer, 0xc8, 1);
  writeU32(buffer, 0xcc, 2);

  const ptt = 2048;
  writeU16(buffer, ptt, 1);
  writeU32(buffer, ptt + 4, 23);
  writeU32(buffer, ptt + 8, 20);
  const title = ptt + 20;
  writeU16(buffer, title, 1);
  writeU16(buffer, title + 2, 2);

  const pgcit = 4096;
  writeU16(buffer, pgcit, 1);
  writeU32(buffer, pgcit + 12, 16);
  const pgc = pgcit + 16;
  buffer[pgc + 2] = 2;
  buffer[pgc + 3] = 2;
  buffer.set(dvdTime(90), pgc + 4);
  writeU16(buffer, pgc + 0xe6, 0xec);
  writeU16(buffer, pgc + 0xe8, 0xee);
  buffer[pgc + 0xec] = 1;
  buffer[pgc + 0xed] = 2;
  const cells = pgc + 0xee;
  buffer.set(dvdTime(30), cells + 4);
  writeU32(buffer, cells + 8, 10);
  writeU32(buffer, cells + 20, 19);
  buffer.set(dvdTime(50), cells + 28);
  writeU32(buffer, cells + 32, 30);
  writeU32(buffer, cells + 44, 49);
  return buffer;
}

describe("DVD IFO navigation parser", () => {
  it("resolves the global title to its VTS title and PGC", () => {
    const [entry] = parseVmgTitleEntries(makeVmg());
    expect(entry).toMatchObject({ globalTitleNumber: 1, vtsNumber: 2, vtsTitleNumber: 1, numberOfPtts: 1 });
  });

  it("reads PTT, program and exact cell sector ranges", () => {
    const [entry] = parseVmgTitleEntries(makeVmg());
    const title = parseVtsTitleNavigation(makeVts(), entry!, [
      { vtsNumber: 2, path: "VTS_02_1.VOB", sizeBytes: 50 * 2048 },
    ]);
    expect(title).toMatchObject({ pgcNumber: 1, programNumber: 2, durationSeconds: 50, sizeBytes: 20 * 2048 });
    expect(title?.cells.map((cell) => [cell.firstSector, cell.lastSector])).toEqual([[30, 49]]);
  });

  it("unions overlapping ranges instead of adding the same VOB sectors twice", () => {
    const files: DvdVobFile[] = [{ vtsNumber: 2, path: "VTS_02_1.VOB", sizeBytes: 100 * 2048 }];
    expect(buildPhysicalRanges(files, [
      { firstSector: 10, lastSector: 30 },
      { firstSector: 20, lastSector: 40 },
    ])).toMatchObject({ sizeBytes: 31 * 2048, ranges: [{ startSector: 10, endSector: 40 }] });
  });
});
