import fs from "node:fs/promises";
import path from "node:path";

const DVD_SECTOR_SIZE = 2048;

export type DvdVobFile = {
  vtsNumber: number;
  path: string;
  sizeBytes: number;
};

export type DvdCell = {
  cellNumber: number;
  firstSector: number;
  lastSector: number;
  durationSeconds: number;
};

export type DvdPhysicalRange = {
  vtsNumber: number;
  path: string;
  startSector: number;
  endSector: number;
  startByte: number;
  endByte: number;
};

export type DvdVmgTitleEntry = {
  globalTitleNumber: number;
  vtsNumber: number;
  vtsTitleNumber: number;
  numberOfPtts: number;
};

export type DvdNavigationTitle = DvdVmgTitleEntry & {
  pgcNumber: number;
  programNumber: number;
  durationSeconds: number | null;
  chapters: Array<{ id: number; startSeconds: number; endSeconds: number }>;
  cells: DvdCell[];
  physicalRanges: DvdPhysicalRange[];
  sizeBytes: number;
};

function readU16(buffer: Uint8Array, offset: number): number {
  if (offset < 0 || offset + 2 > buffer.length) throw new Error(`IFO u16 越界: ${offset}`);
  return (buffer[offset]! << 8) | buffer[offset + 1]!;
}

function readU32(buffer: Uint8Array, offset: number): number {
  if (offset < 0 || offset + 4 > buffer.length) throw new Error(`IFO u32 越界: ${offset}`);
  return (buffer[offset]! * 0x1000000) + (buffer[offset + 1]! << 16) + (buffer[offset + 2]! << 8) + buffer[offset + 3]!;
}

function bcd(value: number): number {
  return ((value >>> 4) * 10) + (value & 0x0f);
}

function dvdTimeSeconds(buffer: Uint8Array, offset: number): number | null {
  if (offset < 0 || offset + 4 > buffer.length) return null;
  const hours = bcd(buffer[offset]!);
  const minutes = bcd(buffer[offset + 1]! & 0x3f);
  const seconds = bcd(buffer[offset + 2]!);
  if (minutes > 59 || seconds > 59) return null;
  const result = hours * 3600 + minutes * 60 + seconds;
  return result > 0 ? result : 0;
}

function sectorOffset(buffer: Uint8Array, byteOffset: number): number {
  const sector = readU32(buffer, byteOffset);
  if (sector <= 0) throw new Error(`IFO 表偏移无效: ${byteOffset}`);
  return sector * DVD_SECTOR_SIZE;
}

function assertMagic(buffer: Uint8Array, expected: string): void {
  const actual = String.fromCharCode(...buffer.slice(0, expected.length));
  if (actual !== expected) throw new Error(`IFO 标识无效: ${actual || "空"}`);
}

/** Parse the VMG title table. DVD title numbers are global and are not VTS numbers. */
export function parseVmgTitleEntries(buffer: Uint8Array): DvdVmgTitleEntry[] {
  assertMagic(buffer, "DVDVIDEO-VMG");
  const table = sectorOffset(buffer, 0xc4);
  const count = readU16(buffer, table);
  if (count <= 0 || count > 99) throw new Error(`VMG 标题数量无效: ${count}`);
  const entries: DvdVmgTitleEntry[] = [];
  for (let index = 0; index < count; index += 1) {
    const offset = table + 8 + index * 12;
    const numberOfPtts = readU16(buffer, offset + 2);
    const vtsNumber = buffer[offset + 6]!;
    const vtsTitleNumber = buffer[offset + 7]!;
    if (vtsNumber <= 0 || vtsNumber > 99 || vtsTitleNumber <= 0) continue;
    entries.push({ globalTitleNumber: index + 1, vtsNumber, vtsTitleNumber, numberOfPtts });
  }
  return entries;
}

function readPttEntries(buffer: Uint8Array, table: number, titleNumber: number): Array<{ pgcNumber: number; programNumber: number }> {
  const offset = table + 8 + (titleNumber - 1) * 4;
  const titleOffset = readU32(buffer, offset);
  const nextOffset = titleNumber < readU16(buffer, table)
    ? readU32(buffer, offset + 4)
    : readU32(buffer, table + 4) + 1;
  const bytes = nextOffset - titleOffset;
  if (bytes <= 0 || bytes % 4 !== 0 || bytes / 4 > 999) throw new Error(`VTS PTT 区间无效: ${titleOffset}-${nextOffset}`);
  const title = table + titleOffset;
  return Array.from({ length: bytes / 4 }, (_value, index) => ({
    pgcNumber: readU16(buffer, title + index * 4),
    programNumber: readU16(buffer, title + index * 4 + 2),
  })).filter((entry) => entry.pgcNumber > 0 && entry.programNumber > 0);
}

function mergeRanges(ranges: DvdPhysicalRange[]): DvdPhysicalRange[] {
  const sorted = ranges.slice().sort((left, right) => left.path.localeCompare(right.path) || left.startSector - right.startSector);
  const merged: DvdPhysicalRange[] = [];
  for (const range of sorted) {
    const previous = merged[merged.length - 1];
    if (previous && previous.path === range.path && range.startSector <= previous.endSector + 1) {
      previous.endSector = Math.max(previous.endSector, range.endSector);
      previous.endByte = Math.max(previous.endByte, range.endByte);
    } else {
      merged.push({ ...range });
    }
  }
  return merged;
}

/** Map DVD logical sectors to the actual split VOB files and union overlaps. */
export function buildPhysicalRanges(
  files: DvdVobFile[],
  cells: Array<Pick<DvdCell, "firstSector" | "lastSector">>,
): { ranges: DvdPhysicalRange[]; sizeBytes: number } {
  const ordered = files.slice().sort((left, right) => left.path.localeCompare(right.path, undefined, { numeric: true }));
  const ranges: DvdPhysicalRange[] = [];
  let fileStartSector = 0;
  for (const file of ordered) {
    const sectorCount = Math.floor(file.sizeBytes / DVD_SECTOR_SIZE);
    const fileEndSector = fileStartSector + sectorCount - 1;
    for (const cell of cells) {
      const firstSector = Math.max(fileStartSector, cell.firstSector);
      const lastSector = Math.min(fileEndSector, cell.lastSector);
      if (firstSector > lastSector) continue;
      ranges.push({
        vtsNumber: file.vtsNumber,
        path: file.path,
        startSector: firstSector,
        endSector: lastSector,
        startByte: (firstSector - fileStartSector) * DVD_SECTOR_SIZE,
        endByte: (lastSector - fileStartSector + 1) * DVD_SECTOR_SIZE,
      });
    }
    fileStartSector += sectorCount;
  }
  const merged = mergeRanges(ranges);
  return { ranges: merged, sizeBytes: merged.reduce((sum, range) => sum + range.endByte - range.startByte, 0) };
}

function programStartCells(programMap: number[], programNumber: number, cellCount: number): number {
  const cell = programMap[programNumber - 1];
  if (!cell || cell < 1 || cell > cellCount) throw new Error(`PGC Program ${programNumber} 指向无效 Cell ${cell ?? "空"}；programMap=[${programMap.join(",")}] cells=${cellCount}`);
  return cell;
}

function readPgc(buffer: Uint8Array, pgcitTable: number, pgcNumber: number): { programMap: number[]; cells: DvdCell[]; durationSeconds: number | null } {
  const srp = pgcitTable + 8 + (pgcNumber - 1) * 8;
  const pgcStart = readU32(buffer, srp + 4);
  const pgc = pgcitTable + pgcStart;
  const programCount = buffer[pgc + 2]!;
  const cellCount = buffer[pgc + 3]!;
  if (programCount <= 0 || cellCount <= 0 || programCount > cellCount || cellCount > 999) throw new Error(`PGC ${pgcNumber} 的 Program/Cell 数量无效: ${programCount}/${cellCount}`);
  const durationSeconds = dvdTimeSeconds(buffer, pgc + 4);
  const programMapOffset = readU16(buffer, pgc + 0xe6);
  const cellPlaybackOffset = readU16(buffer, pgc + 0xe8);
  const programMap = Array.from({ length: programCount }, (_value, index) => buffer[pgc + programMapOffset + index]!);
  const cells: DvdCell[] = Array.from({ length: cellCount }, (_value, index) => {
    const offset = pgc + cellPlaybackOffset + index * 24;
    const cellDuration = dvdTimeSeconds(buffer, offset + 4);
    return {
      cellNumber: index + 1,
      firstSector: readU32(buffer, offset + 8),
      lastSector: readU32(buffer, offset + 20),
      durationSeconds: cellDuration ?? 0,
    };
  }).filter((cell) => cell.firstSector <= cell.lastSector);
  if (cells.length !== cellCount) throw new Error(`PGC ${pgcNumber} 存在无效 Cell 扇区范围`);
  return { programMap, cells, durationSeconds };
}

/** Parse one VTS title through PTT -> PGC -> Cell playback information. */
export function parseVtsTitleNavigation(
  buffer: Uint8Array,
  entry: DvdVmgTitleEntry,
  files: DvdVobFile[],
): DvdNavigationTitle | null {
  assertMagic(buffer, "DVDVIDEO-VTS");
  const pttTable = sectorOffset(buffer, 0xc8);
  const pgcitTable = sectorOffset(buffer, 0xcc);
  const ptts = readPttEntries(buffer, pttTable, entry.vtsTitleNumber);
  const firstPtt = ptts[0];
  if (!firstPtt) return null;
  // dvdnav/FFmpeg starts at the first PTT's PGC and stops when playback leaves
  // that PGC. Other PTT entries may point to alternate PGCs; concatenating
  // them here would manufacture a title that no DVD player actually plays.
  const pgc = readPgc(buffer, pgcitTable, firstPtt.pgcNumber);
  const startCell = programStartCells(pgc.programMap, firstPtt.programNumber, pgc.cells.length);
  const cells = pgc.cells.slice(startCell - 1);
  const durationSeconds = cells.reduce((sum, cell) => sum + cell.durationSeconds, 0);
  const chapterStarts = ptts
    .filter((ptt) => ptt.pgcNumber === firstPtt.pgcNumber)
    .map((ptt) => {
      const cellNumber = programStartCells(pgc.programMap, ptt.programNumber, pgc.cells.length);
      return cellNumber < startCell ? null : cells.slice(0, cellNumber - startCell).reduce((sum, cell) => sum + cell.durationSeconds, 0);
    })
    .filter((value): value is number => value !== null);
  const chapters = chapterStarts.map((startSeconds, index) => ({
    id: index + 1,
    startSeconds,
    endSeconds: chapterStarts[index + 1] ?? durationSeconds,
  }));
  const physical = buildPhysicalRanges(files, cells);
  return {
    ...entry,
    pgcNumber: firstPtt.pgcNumber,
    programNumber: firstPtt.programNumber,
    durationSeconds,
    chapters,
    cells,
    physicalRanges: physical.ranges,
    sizeBytes: physical.sizeBytes,
  };
}

export async function parseDvdNavigation(videoTsDir: string): Promise<DvdNavigationTitle[]> {
  const entries = await fs.readdir(videoTsDir);
  const vmgPath = path.join(videoTsDir, "VIDEO_TS.IFO");
  const vmg = await fs.readFile(vmgPath);
  const titles = parseVmgTitleEntries(vmg);
  const vtsBuffers = new Map<number, Uint8Array>();
  const vobFiles = new Map<number, DvdVobFile[]>();
  for (const name of entries) {
    const match = /^VTS_(\d{2})_(\d+)\.VOB$/i.exec(name);
    if (!match || Number(match[2]) <= 0) continue;
    const vtsNumber = Number(match[1]);
    const filePath = path.join(videoTsDir, name);
    const stat = await fs.stat(filePath).catch(() => null);
    if (!stat?.isFile()) continue;
    const group = vobFiles.get(vtsNumber) ?? [];
    group.push({ vtsNumber, path: filePath, sizeBytes: stat.size });
    vobFiles.set(vtsNumber, group);
  }
  const result: DvdNavigationTitle[] = [];
  for (const entry of titles) {
    let vts = vtsBuffers.get(entry.vtsNumber);
    if (!vts) {
      const ifoPath = path.join(videoTsDir, `VTS_${String(entry.vtsNumber).padStart(2, "0")}_0.IFO`);
      const loaded = await fs.readFile(ifoPath).catch(() => null);
      if (!loaded) continue;
      vts = loaded;
      vtsBuffers.set(entry.vtsNumber, vts);
    }
    const parsed = parseVtsTitleNavigation(vts, entry, vobFiles.get(entry.vtsNumber) ?? []);
    if (parsed) result.push(parsed);
  }
  return result;
}
