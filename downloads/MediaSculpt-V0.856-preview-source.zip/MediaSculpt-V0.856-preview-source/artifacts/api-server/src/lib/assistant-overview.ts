function stripMarkup(line: string): string {
  return line
    .trim()
    .replace(/^#{1,6}\s*/, "")
    .replace(/^\s*(?:[-+*]|\d+[.)])\s+/, "")
    .replace(/^>\s*/, "")
    .replace(/^[*_]{1,3}/, "")
    .replace(/[*_]{1,3}([:：]?)$/, "$1")
    .replace(/^\x60|\x60$/g, "")
    .trim();
}

const METADATA_INLINE = /^(?:IMDBID|TITLE_EN|TITLE_ZH|YEAR|来源年份|英文名(?:\/原名)?|英文名|原名|中文名|片名|标题|年代|年份|类型|题材|国家|地区|片长|评分|豆瓣(?:号|评分)?|IMDb(?:\s*(?:编号|评分|ID))?|IMDB(?:\s*(?:编号|评分|ID))?|烂番茄|Metacritic|导演|编剧|主要演员|主演)\s*[:：=]/i;
const METADATA_LABEL = /^(?:片名|标题|年代|年份|英文名(?:\/原名)?|英文名|原名|中文名|IMDb(?:\s*(?:编号|评分|ID))?|IMDB(?:\s*(?:编号|评分|ID))?)$/i;
/** Crew lines the reply credits under their own label; they are fields, never prose. */
/** Crew lines the reply credits under its own label; they are fields, never prose. */
const CREW_LABELS_LIST = "编剧|编剧组|导演|摄影|摄影指导|配乐|作曲|音乐|制片|制片人|制片方|出品|出品方|发行|监制|剪辑|剪辑师|美术|艺术指导|服装设计|主持人|主持|旁白|解说|讲述|嘉宾|指挥|演奏|乐团|乐队|编舞|舞者|演唱";
// A reply often joins labels ("主持人/旁白"), so the label may be a short list.
const CREW_LINE = new RegExp(`^(?:${CREW_LABELS_LIST})(?:\\s*[/、]\\s*(?:${CREW_LABELS_LIST}))*\\s*[:：=]`, "i");
const CREW_LABELS = new Set(CREW_LABELS_LIST.split("|"));
const SECTION_HEADING = /^(?:资料信息|基本信息|外部检索资料(?:（[^）]*）)?|主创栏|主创|识别依据|综合判断|技术特征|结论|分析过程)\s*[:：]?$/i;

/**
 * A compact "Title · 中文名 · 1993 · genre · country · runtime" header is a
 * metadata line. It must be told apart from a plot sentence that merely
 * mentions a year and a dotted name — Blow-Up's overview says
 * "…米开朗基罗·安东尼奥尼于1966年执导…", and the old year+dot test threw that
 * whole paragraph away, which left the overview empty.
 */
function isCompactIdentityLine(line: string): boolean {
  if (!/\b(?:19|20)\d{2}\b/.test(line)) return false;
  if ((line.match(/[·•]/g) ?? []).length < 2) return false;
  if (/[。！？；]/.test(line)) return false;
  return line.length <= 120;
}

export type AssistantReplyMetadata = {
  rating?: number;
  ratingVotes?: number;
  doubanRating?: number;
  director?: string;
  cast?: string[];
  genres?: string;
  runtimeMinutes?: number;
  /** Crew the reply credited under its own label (编剧/摄影/配乐/制片…). */
  credits?: Array<{ label: string; value: string }>;
};

function metadataValue(line: string, label: RegExp): string | null {
  const match = label.exec(stripMarkup(line));
  return match?.[1]?.trim() || null;
}

function splitCast(value: string): string[] {
  return value
    .split(/[、,，;；]/)
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 12);
}

function removeTrailingIdentityLines(value: string): string {
  return value
    .replace(/\n(?:IMDb|IMDB)\s*(?:编号|ID|评分)?\s*[:：=]\s*tt\d{7,8}\s*$/i, "")
    .trim();
}

function isMetadataLine(line: string): boolean {
  return METADATA_INLINE.test(line) || CREW_LINE.test(line) || SECTION_HEADING.test(line);
}

function normalizeProseLine(line: string): string {
  return line.replace(/[\s\u3000]+/g, " ").trim();
}

/** Remove repeated LLM sentences/lines while preserving non-empty content. */
function dedupeOverview(value: string): string {
  const seen = new Set<string>();
  return value
    .split(/\n+/)
    .map(normalizeProseLine)
    .map((line) => {
      // Some models put the compact identity header and the first paragraph
      // on one line.  Keep the paragraph after the heading instead of
      // discarding useful content with the header.
      const inlineProse = /^.+[·•].+(?:19|20)\d{2}.+(?:纪录片|电影|剧情|Documentary|Film).+?主创栏\s*[:：]\s*(.+)$/i.exec(line);
      return inlineProse?.[1]?.trim() || line;
    })
    .filter((line) => {
      if (!line) return false;
      // A compact title/year/type line is a metadata header, not prose; the
      // structured panel already renders these fields once.
      if (isCompactIdentityLine(line)) return false;
      const key = line.toLocaleLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/** Extract fields that the assistant explicitly returned for persistence/display. */
export function extractAssistantMetadata(raw: string | null | undefined): AssistantReplyMetadata {
  if (!raw) return {};
  const result: AssistantReplyMetadata = {};
  for (const sourceLine of raw.replace(/\r/g, "").split("\n")) {
    const line = stripMarkup(sourceLine);
    if (!line) continue;
    const ratingValue = metadataValue(line, /^(?:IMDb\s*(?:评分|Rating)|评分|Rating)\s*[:：=]\s*(.+)$/i);
    if (ratingValue) {
      const rating = Number(/\d+(?:\.\d+)?/.exec(ratingValue)?.[0] ?? NaN);
      const votes = Number(/[\d,.]+\s*万?\s*票/.exec(ratingValue)?.[0]?.replace(/[^\d.]/g, "") ?? NaN);
      const scale = /万/.test(/[\d,.]+\s*万?\s*票/.exec(ratingValue)?.[0] ?? "") ? 10_000 : 1;
      if (Number.isFinite(rating) && rating > 0) result.rating = rating;
      if (Number.isFinite(votes) && votes > 0) result.ratingVotes = Math.round(votes * scale);
      continue;
    }
    const doubanValue = metadataValue(line, /^(?:豆瓣评分|Douban\s*评分)\s*[:：=]\s*(.+)$/i);
    if (doubanValue) {
      const rating = Number(/\d+(?:\.\d+)?/.exec(doubanValue)?.[0] ?? NaN);
      if (Number.isFinite(rating) && rating > 0) result.doubanRating = rating;
      continue;
    }
    const director = metadataValue(line, /^(?:导演|Director)\s*[:：=]\s*(.+)$/i);
    if (director) {
      // 编剧 is a separate credit. Matching it here let the writer list
      // overwrite the director, so the panel credited screenwriters as directors.
      result.director = result.director ? `${result.director}、${director}` : director;
      continue;
    }
    // A reply may join labels ("主持人/旁白"), so every part of the label must be a
    // known crew label, and an unconfirmed placeholder is not worth a row.
    const creditMatch = /^([^:：=]{1,20})\s*[:：=]\s*(.+)$/.exec(line);
    if (creditMatch) {
      const parts = creditMatch[1].split(/[/、,，]/).map((part) => part.trim()).filter(Boolean);
      const creditValue = creditMatch[2].trim();
      const confirmed = !/^(待确认|未知|不详|暂无|未找到|未检索到|N\/?A)$/i.test(creditValue);
      if (parts.length > 0 && parts.every((part) => CREW_LABELS.has(part)) && confirmed) {
        result.credits = [...(result.credits ?? []), { label: creditMatch[1].trim(), value: creditValue }];
        continue;
      }
    }
    const cast = metadataValue(line, /^(?:主要演员|主演|演员|Cast)\s*[:：=]\s*(.+)$/i);
    if (cast) {
      result.cast = splitCast(cast);
      continue;
    }
    const genres = metadataValue(line, /^(?:类型|题材|Genres?)\s*[:：=]\s*(.+)$/i);
    if (genres) {
      result.genres = genres;
      continue;
    }
    const runtime = metadataValue(line, /^(?:片长|时长|Runtime)\s*[:：=]\s*(.+)$/i);
    if (runtime) {
      const minutes = Number(/\d+/.exec(runtime)?.[0] ?? NaN);
      if (Number.isFinite(minutes) && minutes > 0) result.runtimeMinutes = minutes;
    }
  }
  return result;
}

const OVERVIEW_HEADING = /^(?:内容简介|剧情简介|影片简介|简介|overview)\s*[:：]?\s*$/i;
const OVERVIEW_INLINE = /^(?:内容简介|剧情简介|影片简介|简介|overview)\s*[:：]\s*(.*)$/i;

/** Extract only prose from an assistant analysis reply for task persistence. */
export function extractAssistantOverview(raw: string | null | undefined): string {
  if (!raw) return "";
  const sourceLines = raw.replace(/\r/g, "").split("\n");
  // The label is a heading as often as it is a "简介：" field, and a heading
  // without a colon used to hide the whole overview behind the crew block.
  const contentIndex = sourceLines.findIndex((line) => {
    const stripped = stripMarkup(line);
    return OVERVIEW_HEADING.test(stripped) || OVERVIEW_INLINE.test(stripped);
  });
  if (contentIndex >= 0) {
    const contentLine = stripMarkup(sourceLines[contentIndex]);
    const inline = OVERVIEW_INLINE.exec(contentLine)?.[1]?.trim();
    const body = [
      ...(inline ? [inline] : []),
      ...sourceLines.slice(contentIndex + 1).map(stripMarkup),
    ].filter((line) => line && !isMetadataLine(line));
    return dedupeOverview(removeTrailingIdentityLines(body.join("\n").replace(/\n{3,}/g, "\n\n")));
  }

  const overview: string[] = [];
  let pendingLabelValue = false;
  let inOverview = false;
  for (const sourceLine of sourceLines) {
    const line = stripMarkup(sourceLine);
    if (!line) {
      if (inOverview && overview.length > 0) overview.push("");
      continue;
    }
    if (/^资料信息\s*[:：]?$/i.test(line)) break;
    if (isMetadataLine(line)) {
      pendingLabelValue = false;
      continue;
    }
    if (METADATA_LABEL.test(line)) {
      pendingLabelValue = true;
      continue;
    }
    if (pendingLabelValue) {
      pendingLabelValue = false;
      continue;
    }
    if (!inOverview && isCompactIdentityLine(line)) continue;
    inOverview = true;
    overview.push(line);
  }
  return dedupeOverview(removeTrailingIdentityLines(overview.join("\n").replace(/\n{3,}/g, "\n\n")));
}

/**
 * The id the assistant claims in its reply. It is only ever an unverified
 * suggestion: the model is not an identity authority, so this never pins a
 * poster and never overwrites a provider match.
 */
export function extractAssistantImdbId(raw: string | null | undefined): string | null {
  if (!raw) return null;
  const match = /\b(tt\d{7,8})\b/i.exec(raw.replace(/\r/g, ""));
  return match?.[1]?.toLowerCase() ?? null;
}
