import http from "node:http";
import net from "node:net";
import { afterEach, describe, expect, it } from "vitest";
import {
  LOCAL_PROXY_CANDIDATE_PORTS,
  detectLocalProxyUrl,
  fetchViaTunnel,
  requestJsonLike,
  resolvePosterProxyUrl,
} from "./http-client";

const servers: Array<http.Server | net.Server> = [];
const openSockets = new Set<net.Socket>();

function track<T extends http.Server | net.Server>(server: T): T {
  server.on("connection", (socket: net.Socket) => {
    openSockets.add(socket);
    socket.on("close", () => openSockets.delete(socket));
  });
  servers.push(server);
  return server;
}

function portOf(server: http.Server | net.Server): number {
  return (server.address() as net.AddressInfo).port;
}

/** 最小 HTTP 代理：按给定状态码应答 CONNECT。 */
async function startProxy(statusCode = 200): Promise<number> {
  const server = track(http.createServer((_request, response) => {
    response.statusCode = 405;
    response.end();
  }));
  server.on("connect", (_request, socket) => {
    const reason = statusCode === 200 ? "Connection Established" : "Forbidden";
    socket.end(`HTTP/1.1 ${statusCode} ${reason}\r\n\r\n`);
  });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  return portOf(server);
}

/** 只在监听、对 CONNECT 不作答的普通本地服务。 */
async function startPlainTcpServer(): Promise<number> {
  const server = track(net.createServer(() => { /* 故意不回应 */ }));
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  return portOf(server);
}

/** 应答 CONNECT 后记录隧道内首批字节的假代理，用于判断客户端有没有真的完成 TLS。 */
async function startCapturingProxy(): Promise<{ port: number; firstBytes: () => Buffer }> {
  let captured: Buffer = Buffer.alloc(0);
  const server = track(http.createServer());
  server.on("connect", (_request, socket) => {
    socket.write("HTTP/1.1 200 Connection Established\r\n\r\n");
    socket.once("data", (chunk: Buffer) => {
      captured = chunk;
      socket.destroy();
    });
  });
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  return { port: portOf(server), firstBytes: () => captured };
}

afterEach(async () => {
  for (const socket of openSockets) socket.destroy();
  openSockets.clear();
  await Promise.all(servers.splice(0).map((server) => new Promise<void>((resolve) => server.close(() => resolve()))));
});

describe("resolvePosterProxyUrl", () => {
  it("preserves an explicitly configured proxy", async () => {
    await expect(resolvePosterProxyUrl("http://127.0.0.1:10808")).resolves.toBe("http://127.0.0.1:10808");
  });

  it("honours the MEDIASCULPT_POSTER_PROXY override", async () => {
    const previous = process.env.MEDIASCULPT_POSTER_PROXY;
    process.env.MEDIASCULPT_POSTER_PROXY = "http://127.0.0.1:12334";
    try {
      await expect(resolvePosterProxyUrl(null)).resolves.toBe("http://127.0.0.1:12334");
    } finally {
      if (previous === undefined) delete process.env.MEDIASCULPT_POSTER_PROXY;
      else process.env.MEDIASCULPT_POSTER_PROXY = previous;
    }
  });

  it("does not probe the developer machine under NODE_ENV=test", async () => {
    // 即使本机真的开着代理，单元测试也必须保持独立，不依赖开发机环境。
    const proxyPort = await startProxy();
    const explicit = process.env.MEDIASCULPT_POSTER_PROXY;
    delete process.env.MEDIASCULPT_POSTER_PROXY;
    try {
      await expect(resolvePosterProxyUrl(null)).resolves.toBeNull();
      expect(proxyPort).toBeGreaterThan(0);
    } finally {
      if (explicit !== undefined) process.env.MEDIASCULPT_POSTER_PROXY = explicit;
    }
  });
});

describe("detectLocalProxyUrl", () => {
  it("detects a listening HTTP proxy", async () => {
    const port = await startProxy();
    await expect(detectLocalProxyUrl([port])).resolves.toBe(`http://127.0.0.1:${port}`);
  });

  it("rejects a listening port that is not an HTTP proxy", async () => {
    const plainPort = await startPlainTcpServer();
    await expect(detectLocalProxyUrl([plainPort])).resolves.toBeNull();
  });

  it("keeps looking past an unrelated port when a real proxy follows", async () => {
    const plainPort = await startPlainTcpServer();
    const proxyPort = await startProxy();
    await expect(detectLocalProxyUrl([plainPort, proxyPort])).resolves.toBe(`http://127.0.0.1:${proxyPort}`);
  });

  it("prefers the higher priority port when several proxies are listening", async () => {
    const first = await startProxy();
    const second = await startProxy();
    await expect(detectLocalProxyUrl([first, second])).resolves.toBe(`http://127.0.0.1:${first}`);
    await expect(detectLocalProxyUrl([second, first])).resolves.toBe(`http://127.0.0.1:${second}`);
  });

  it("ignores a proxy that refuses CONNECT", async () => {
    const port = await startProxy(403);
    await expect(detectLocalProxyUrl([port])).resolves.toBeNull();
  });

  it("returns null when the candidate port is closed", async () => {
    const server = track(net.createServer());
    await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
    const port = portOf(server);
    await new Promise<void>((resolve) => server.close(() => resolve()));
    servers.splice(servers.indexOf(server), 1);
    await expect(detectLocalProxyUrl([port])).resolves.toBeNull();
  });

  it("covers the Hiddify mixed proxy port", () => {
    expect(LOCAL_PROXY_CANDIDATE_PORTS).toContain(12334);
    expect(LOCAL_PROXY_CANDIDATE_PORTS).toContain(10809);
  });
});

describe("CONNECT tunnel", () => {
  // 修复前 https.request 会把裸隧道 socket 当成已加密连接，请求以明文写进
  // 隧道，对端只能回非 HTTP 字节 —— 表现就是"配了代理照样取不到海报"。
  it("performs a real TLS handshake inside the tunnel instead of writing plaintext", async () => {
    const proxy = await startCapturingProxy();
    const result = await fetchViaTunnel(
      "https://poster.example.test/poster.jpg",
      `http://127.0.0.1:${proxy.port}`,
      4_000,
      {},
    );
    expect(result).toBeNull();
    const bytes = proxy.firstBytes();
    expect(bytes.length).toBeGreaterThan(0);
    // 0x16 是 TLS handshake 记录；明文请求的首字节会是 "G"（GET）。
    expect(bytes[0]).toBe(0x16);
  });

  it("tunnels JSON requests over TLS as well", async () => {
    const proxy = await startCapturingProxy();
    const result = await requestJsonLike(
      "https://api.example.test/v1/models",
      {},
      `http://127.0.0.1:${proxy.port}`,
      4_000,
    );
    expect(result).toBeNull();
    expect(proxy.firstBytes()[0]).toBe(0x16);
  });

  it("sends a plain HTTP target through the tunnel without encrypting it", async () => {
    const proxy = await startCapturingProxy();
    await fetchViaTunnel("http://local.example.test/models", `http://127.0.0.1:${proxy.port}`, 4_000, {});
    expect(proxy.firstBytes().subarray(0, 4).toString("latin1")).toBe("GET ");
  });
});
