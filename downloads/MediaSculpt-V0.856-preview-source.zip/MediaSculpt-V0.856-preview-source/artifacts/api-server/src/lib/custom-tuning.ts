/**
 * 自定义调优配置：智能工作流逻辑参数 + LLM 提示词模板。
 * 存储在 config.custom_tuning（JSON 字符串），前端在“设置 → 自定义调优”中编辑，
 * 支持恢复默认值、导出/导入。后端各调用点按需读取。
 *
 * 逻辑参数从固定字段升级为用户可管理的参数表（V 0.826+）：
 * - 每个参数一行，可改名、改数值/范围/单位/说明，可删除、可逐项恢复默认；
 * - 内置参数被删除后，后端读取时自动回落内置默认值，逻辑不会断；
 * - 自定义参数（custom: true）可由用户任意添加，用于注入 LLM 提示或
 *   通过 {{logic.<key>}} 占位符在提示词模板中引用。
 */

export type TuningLogicParamKind = "number" | "select" | "text";

export type TuningLogicParam = {
  /** 稳定标识（内置参数固定；自定义参数由用户填写，小写字母/数字/下划线） */
  key: string;
  /** 用户改名后的显示名（内置参数未改名时不存，界面回退到 labelKey） */
  label?: string;
  /** 内置参数的 i18n key（仅内置参数有） */
  labelKey?: string;
  /** 当前值（number 或 string） */
  value: number | string;
  /** 控件类型：number=滑条/数字、select=下拉、text=文本 */
  kind: TuningLogicParamKind;
  /** 单位（如 GB、min） */
  unit?: string;
  min?: number;
  max?: number;
  step?: number;
  /** select 类型的可选项（dvdCompressPreset 由前端动态补压缩预设） */
  options?: string[];
  /** 内置参数的说明 i18n key（仅内置参数有） */
  hintKey?: string;
  /** 自定义参数的说明文字 */
  hint?: string;
  /** 恢复默认的目标值（内置=出厂值；自定义=新建时初值） */
  default: number | string;
  /** 是否为用户自定义参数 */
  custom: boolean;
};

export type CustomTuningLogic = {
  parameters: TuningLogicParam[];
};

export type CustomTuningPrompts = {
  /** 分析校对提示词（智能助手“分析”按钮） */
  analysis: string;
  /** 影片身份确认提示词（智能工作流影片资料确认） */
  identity: string;
  /** 字幕翻译补充指令（留空 = 使用内置默认） */
  translate: string;
  /** Readme 生成补充指令（留空 = 使用内置默认） */
  readme: string;
  /** 影评生成补充指令（留空 = 使用内置默认） */
  review: string;
};

export type CustomTuning = {
  prompts: CustomTuningPrompts;
  logic: CustomTuningLogic;
};

/** 内置逻辑参数的默认定义（含中文 label，供 LLM 上下文与恢复默认使用）。 */
export const DEFAULT_LOGIC_PARAMETERS: TuningLogicParam[] = [
  {
    key: "documentaryGbPer50min",
    label: "纪录片容量基准",
    labelKey: "settings.tuningLogic.documentaryGbPer50min",
    value: 2,
    kind: "number",
    unit: "GB",
    min: 0.5,
    max: 5,
    step: 0.1,
    hintKey: "settings.tuningLogic.documentaryGbPer50minHint",
    default: 2,
    custom: false,
  },
  {
    key: "movieGb",
    label: "电影容量基准",
    labelKey: "settings.tuningLogic.movieGb",
    value: 8,
    kind: "number",
    unit: "GB",
    min: 2,
    max: 20,
    step: 0.5,
    hintKey: "settings.tuningLogic.movieGbHint",
    default: 8,
    custom: false,
  },
  {
    key: "h265Ratio",
    label: "H.265 阈值比例",
    labelKey: "settings.tuningLogic.h265Ratio",
    value: 0.7,
    kind: "number",
    min: 0.5,
    max: 1,
    step: 0.05,
    hintKey: "settings.tuningLogic.h265RatioHint",
    default: 0.7,
    custom: false,
  },
  {
    key: "minClipMinutes",
    label: "短片阈值",
    labelKey: "settings.tuningLogic.minClipMinutes",
    value: 5,
    kind: "number",
    unit: "min",
    min: 1,
    max: 15,
    step: 1,
    hintKey: "settings.tuningLogic.minClipMinutesHint",
    default: 5,
    custom: false,
  },
  {
    key: "dvdDefaultMode",
    label: "DVD 默认处理",
    labelKey: "settings.tuningLogic.dvdDefaultMode",
    value: "remux",
    kind: "select",
    options: ["remux", "compress"],
    hintKey: "settings.tuningLogic.dvdDefaultModeHint",
    default: "remux",
    custom: false,
  },
  {
    key: "dvdCompressPreset",
    label: "DVD 压缩预设",
    labelKey: "settings.tuningLogic.dvdCompressPreset",
    value: "dvd-convert",
    kind: "select",
    hintKey: "settings.tuningLogic.dvdCompressPresetHint",
    default: "dvd-convert",
    custom: false,
  },
];

export const DEFAULT_CUSTOM_TUNING: CustomTuning = {
  prompts: {
    analysis:
      "你是影刻资料检索与识别助手。任务：根据「来源信息」「媒体技术信息」「用户提示词」，综合检索并准确识别这部作品（电影、剧集、纪录片、芭蕾舞剧、歌剧、音乐会、话剧等舞台演出），并给出尽量完整、可核验的资料。\n" +
      "识别方法：\n" +
      "1. 用户提示词是最优先线索，逐字分析其中的片名、年代、剧种、演员、舞团等线索；再结合来源文件名/目录名、时长、分辨率、音轨/字幕语言、章节数等技术特征交叉验证。\n" +
      "2. 综合检索你掌握的资料（Wikipedia、IMDb、TMDb、豆瓣等常见来源的知识），给出最可能的唯一作品身份；若存在多个候选版本（例如芭蕾舞剧《堂吉诃德》的多个演出录制年代/舞团），列出候选并在简介中说明判断依据和优先级。\n" +
      "3. 「外部检索资料」一栏已给出数据库（TVmaze/维基/豆瓣等）查到的规范片名与年份，优先采用其中的规范英文名作为 TITLE_EN（去掉其中年份与季集号），不要照抄文件名或目录名里的发布标签。\n" +
      "4. 年份核对规则：来源文件名/目录名或用户提示词中的年份代表该录制/发行版本，作为首选参照；但允许两类偏差——① 同一片名在外部资料中的年份与来源年份相差 1 年以内（±1 年，如来源 2006、资料 2005 或 2007），视为同一部作品，不要因为 1 年之差误判为不同影片；② 官方录像/发行年份可能晚于实际演出/录制年份多年（如 1967 年现场录制、2020 年才发行蓝光），来源年份与资料年份相差多年时仍可能是同一场演出，需要结合片名、导演/艺术家、演出内容判断，不要仅凭年份差异排除。只有片名相同但年份相差多年且确属重拍/新版/不同演出时，才判定为不同作品并选用与来源年份吻合的版本。\n" +
      "5. 对舞台演出/芭蕾/歌剧，重点区分：作品本身（剧名、编导、作曲）与具体演出录制（录制年份、舞团/剧院、版本）。YEAR 优先填写这场录制/发行的年份；无法确认时 YEAR 留空，绝不猜测、绝不使用默认年份。\n" +
      "输出格式（必须逐行，先结构化后正文）：\n" +
      "TITLE_EN=<纯英文/原文片名，单词用点连接，如 Don.Quichotte；只允许片名本身，禁止包含年份、季集号（S01E03/第一季）、分辨率（720p/1080p）、编码（x264/HEVC）、音轨（AAC/DTS/AC3）、发布标签（BluRay/DVDRip/WEB-DL/Remux）或发布组>\n" +
      "TITLE_EN 必须输出：即使无法确认规范英文名，也按源文件名/目录名清洗掉年份、季集号、分辨率、编码、音轨、发布标签与发布组后输出（如 Kronprinz.Rudolf.2006.2DVD5.Rus.Eng.Kinosvalka&rutracker → Kronprinz.Rudolf），禁止留空、禁止照抄原始文件名。\n" +
      "TITLE_ZH=<规范中文名称（以豆瓣等简中平台为准）；无法确认时留空>\n" +
      "YEAR=<四位数字年份；无法确认时留空>\n" +
      "POSTER_URL=<公开可访问的海报/封面图 URL；找不到就不输出这一行>\n" +
      "IMDB_ID=<IMDb 编号（tt 开头共 7-8 位，如 tt0087130）；只有确实检索到才填写，找不到就输出 IMDB_ID= 留空，禁止编造>\n" +
      "然后空一行，用当前界面语言输出一段基本信息简介。\n" +
      "正文请使用专业纯文本：禁止 Markdown 符号（*、#、- 列表符、反引号等）；文中提到片名时一律使用标准化的英文名（单词用点连接）与规范中文名，不要回显含 720p/x264/AAC 等发布标签的原始文件名。\n" +
      "基本信息必须格式专业、信息密度高：第一行给出一句话定位（规范英文名 · 规范中文名 · 年份 · 类型 · 国别/地区 · 片长；剧集/纪录片系列注明季数与集数）。随后是评价与资料栏（放在简介之前）：IMDb 编号（ttXXXXXXX，找到才写）、IMDb 评分（评分基准，含票数如“IMDb 7.2（约13万票）”）、烂番茄/Letterboxd/Metacritic 等国际评分与媒体评价（标注来源）、豆瓣评分（仅参考并标注来源）。然后给出主创栏：导演、主要演员（含舞者/主持人/指挥等，按作品类型调整）必须中英文双语，格式为“中文译名（English Name / 原文名）”（如 克劳斯·马利亚·布朗道尔（Klaus Maria Brandauer）），外语名不确定时可写“（待确认）”；纪录片/剧集可列主持人/旁白/主创。最后是约 300-500 字的内容/剧情简介（核心情节、主要人物、历史或艺术背景，可适当加长但不注水）。\n" +
      "评分规则：评分一律以 IMDb 为准，豆瓣评分只作参考且必须标注来源（如“豆瓣 8.9”）。对同性、女权、动画等题材，豆瓣评分可能因社区取向而失真；当 IMDb 与豆瓣评分差异超过约 1.5 分时，明确标注“两站评分差异较大，请谨慎参考”，并简要说明可能的原因（如题材取向或评分人群不同），不要把豆瓣评分当作权威值。\n" +
      "严格禁止输出过程性文字：不得出现“识别依据”“综合判断”“与来源文件的技术特征相符”“用户提示词给出”“无其他同名候选版本”等识别过程描述；不得提及文件格式、分辨率、编码、音轨或发布组（如 720p/x264/MVGroup），不得重复原始文件名。\n" +
      "绝不编造事实；不确定的信息明确标注“待确认”。不要输出任何 JSON 动作。",
    identity:
      "根据文件名/片源名称与媒体技术特征，综合检索并返回最可能的影片/节目/舞台演出资料候选。宁缺毋滥，尽可能给出唯一身份并说明理由。\n" +
      "title 必须使用豆瓣常用的中文片名（不要自行直译英文片名；无法确认豆瓣中文名时降低 confidence 或返回空数组），titleEn 只保留纯英文/原文片名（单词用点连接），禁止包含年份、季集号（S01E03/第一季/Series 1）、分辨率（720p/1080p）、编码（x264/HEVC）、音轨（AAC/DTS/AC3）、发布标签（BluRay/DVDRip/WEB-DL/Remux）或发布组（MVGroup 等）。\n" +
      "year 与来源年份相差 1 年以内（±1 年）视为同一部作品；官方录像/发行年份可能晚于实际演出/录制年份多年，仍可能是同一场演出，需结合片名、导演/艺术家、演出内容判断，不要仅凭年份差异排除。\n" +
      "只返回 JSON 数组，每项字段：title、titleEn、year、overview、mediaType（movie 或 tv）、confidence（0 到 1）、matchReason、technicalAssessment、recommendedAction。\n" +
      "year 仅在能够确认时填写数字；无法确认时省略或为 null，绝不猜测、绝不使用默认年份。\n" +
      "overview 尽量写清楚剧情/内容简介，帮助区分同名作品与多版本录制。\n" +
      "matchReason 说明为什么与文件名和媒体特征匹配；technicalAssessment 用一句话总结时长、章节、分辨率、音轨/字幕等可核验信息；recommendedAction 只能是保留、压缩、Remux 或人工确认之一。不要把推测写成已确认事实。\n" +
      "对舞台演出/芭蕾/歌剧类作品：title 可用公认译名，并在 matchReason 中注明可能的演出录制版本（年份/舞团）。\n" +
      "最多返回 5 项；没有可靠候选时返回空数组。",
    translate: "",
    readme: "",
    review: "",
  },
  logic: {
    parameters: DEFAULT_LOGIC_PARAMETERS.map((param) => ({ ...param })),
  },
};

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function mergePrompts(defaults: CustomTuningPrompts, raw: unknown): CustomTuningPrompts {
  const source = isPlainObject(raw) ? raw : {};
  const pick = (key: keyof CustomTuningPrompts): string =>
    typeof source[key] === "string" ? source[key] as string : defaults[key];
  return {
    analysis: pick("analysis"),
    identity: pick("identity"),
    translate: pick("translate"),
    readme: pick("readme"),
    review: pick("review"),
  };
}

/** 规范化单个参数：缺失字段回退到内置定义或合理默认值。 */
function normalizeParam(raw: unknown): TuningLogicParam | null {
  if (!isPlainObject(raw)) return null;
  const key = typeof raw.key === "string" && raw.key.trim() ? raw.key.trim() : "";
  if (!key) return null;
  const builtin = DEFAULT_LOGIC_PARAMETERS.find((param) => param.key === key);
  const kind: TuningLogicParamKind =
    raw.kind === "select" || raw.kind === "text" ? raw.kind : "number";
  const value =
    typeof raw.value === "number" && Number.isFinite(raw.value)
      ? raw.value
      : typeof raw.value === "string"
      ? raw.value
      : builtin?.value ?? 0;
  const defaultValue =
    typeof raw.default === "number" && Number.isFinite(raw.default)
      ? raw.default
      : typeof raw.default === "string"
      ? raw.default
      : builtin?.default ?? value;
  return {
    key,
    ...(typeof raw.label === "string" && raw.label.trim() ? { label: raw.label.trim() } : {}),
    ...(builtin?.labelKey ? { labelKey: builtin.labelKey } : {}),
    value,
    kind,
    ...(typeof raw.unit === "string" && raw.unit.trim() ? { unit: raw.unit.trim() } : {}),
    ...(builtin?.hintKey ? { hintKey: builtin.hintKey } : {}),
    ...(typeof raw.hint === "string" && raw.hint.trim() ? { hint: raw.hint.trim() } : {}),
    min: typeof raw.min === "number" && Number.isFinite(raw.min) ? raw.min : builtin?.min,
    max: typeof raw.max === "number" && Number.isFinite(raw.max) ? raw.max : builtin?.max,
    step:
      typeof raw.step === "number" && Number.isFinite(raw.step) && raw.step > 0
        ? raw.step
        : builtin?.step ?? 1,
    ...(Array.isArray(raw.options)
      ? { options: raw.options.filter((option): option is string => typeof option === "string") }
      : builtin?.options
      ? { options: builtin.options }
      : {}),
    default: defaultValue,
    custom: raw.custom === true,
  };
}

function mergeLogic(raw: unknown): CustomTuningLogic {
  const source = isPlainObject(raw) ? raw : {};
  // 新格式：参数表（保留用户删除的内置参数——缺失即“使用内置默认”）
  if (Array.isArray(source.parameters)) {
    const parameters = source.parameters
      .map(normalizeParam)
      .filter((param): param is TuningLogicParam => param !== null);
    return { parameters };
  }
  // 旧格式：固定字段对象 → 自动迁移为参数表
  const parameters = DEFAULT_LOGIC_PARAMETERS.map((definition) => ({
    ...definition,
    value:
      typeof source[definition.key] === "number" || typeof source[definition.key] === "string"
        ? (source[definition.key] as number | string)
        : definition.value,
  }));
  return { parameters };
}

/** 解析 config.custom_tuning（可为 null/空/部分字段/新旧格式），与默认值深度合并。 */
export function parseCustomTuning(raw: string | null | undefined): CustomTuning {
  if (!raw) return DEFAULT_CUSTOM_TUNING;
  try {
    const parsed = JSON.parse(raw) as { prompts?: unknown; logic?: unknown };
    return {
      prompts: mergePrompts(DEFAULT_CUSTOM_TUNING.prompts, parsed.prompts),
      logic: mergeLogic(parsed.logic),
    };
  } catch {
    return DEFAULT_CUSTOM_TUNING;
  }
}

/** 按 key 查找参数（不区分内置/自定义）。 */
export function logicParam(
  logic: CustomTuningLogic | undefined | null,
  key: string,
): TuningLogicParam | undefined {
  return logic?.parameters?.find((param) => param.key === key);
}

/** 读取参数值；缺失或非法时返回 fallback（内置参数被删除后即走默认值）。 */
export function logicValue<T extends number | string>(
  logic: CustomTuningLogic | undefined | null,
  key: string,
  fallback: T,
): T {
  const param = logicParam(logic, key);
  const value = param?.value;
  if (typeof fallback === "number") {
    return (typeof value === "number" && Number.isFinite(value) && value > 0 ? value : fallback) as T;
  }
  return (typeof value === "string" && value.trim() ? value : fallback) as T;
}

/** 生成“用户调优逻辑参数”文本块（注入到分析/资料确认的 LLM 提示中）。 */
export function buildTuningLogicContext(logic: CustomTuningLogic | undefined | null): string {
  const lines = (logic?.parameters ?? []).map((param) => {
    const label =
      param.label ??
      DEFAULT_LOGIC_PARAMETERS.find((definition) => definition.key === param.key)?.label ??
      param.key;
    return `- ${label}：${param.value}${param.unit ? ` ${param.unit}` : ""}`;
  });
  return lines.join("\n");
}

/** 将提示词模板中的 {{logic.<key>}} 占位符替换为当前参数值。 */
export function resolveLogicPlaceholders(
  text: string,
  logic: CustomTuningLogic | undefined | null,
): string {
  return text.replace(/\{\{logic\.([A-Za-z0-9_]+)\}\}/g, (match, key: string) => {
    const param = logicParam(logic, key);
    return param ? String(param.value) : match;
  });
}
