import { describe, expect, it } from "vitest";
import { normalizeSelection, type MediaAnalysis } from "./media-analysis";

describe("media analysis selection", () => {
  const analysis: MediaAnalysis = {
    sourcePath: "/tmp/movie.mkv",
    mediaType: "video",
    durationSeconds: 120,
    streams: [
      { index: 0, codecType: "video", codecName: "h264" },
      { index: 1, codecType: "audio", codecName: "aac" },
      { index: 2, codecType: "subtitle", codecName: "subrip" },
    ],
    chapters: [{ id: 0, startSeconds: 0, endSeconds: 60, title: "开头" }],
  };

  it("keeps only valid selected stream indexes", () => {
    expect(normalizeSelection(analysis, [0, 2, 99])).toEqual({
      video: [0], audio: [], subtitle: [2], chapters: [0],
    });
  });

  it("defaults to all supported streams and chapters", () => {
    expect(normalizeSelection(analysis)).toEqual({
      video: [0], audio: [1], subtitle: [2], chapters: [0],
    });
  });
});
