import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import {
  enPack,
  projectRoot,
  readProjectFile,
  zhPack,
} from "./windows-contract-helpers";

describe("Windows contract", () => {
  it("creates disc analysis jobs according to the selected mode instead of always remuxing", () => {
    const scanPage = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );

    expect(scanPage).toContain("processingMode: ProcessingMode");
    expect(scanPage).toContain("processingMode={processingMode}");
    expect(scanPage).toContain("subtitleMode={subtitleMode}");
    expect(scanPage).toContain("processingMode,");
    expect(scanPage).not.toContain('processingMode: "remux",');
    expect(scanPage).not.toContain(
      "Disc analysis always creates a remux job regardless of the selected mode",
    );
    expect(scanPage + zhPack()).toContain(
      "DVD/蓝光原盘由 HandBrake 直接分析并重新编码",
    );
  });

  it("explains disc compression as direct HandBrake analysis in queue and detail views", () => {
    const jobsPage = readProjectFile(
      "artifacts/video-agent/src/pages/Jobs.tsx",
    );
    const detailPage = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );

    expect(jobsPage).toContain("isDiscCompressionJob");
    expect(jobsPage + zhPack()).toContain("光盘压缩：HandBrake 直接分析");
    expect(detailPage).toContain("pipelineHasCompress");
    expect(detailPage).toContain("job-params-section");
    expect(detailPage + zhPack()).toContain("字幕策略");
    expect(detailPage + zhPack()).toContain("HandBrake 直接分析原盘");
  });

  it("allows importing a portable MakeMKV folder into the managed local tools directory", () => {
    const runtimeRoute = readProjectFile(
      "artifacts/api-server/src/routes/runtime.ts",
    );
    const runtime = readProjectFile(
      "artifacts/api-server/src/lib/tool-runtime.ts",
    );
    const settings = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );

    expect(runtimeRoute).not.toContain("makemkv");
    expect(runtime).not.toContain("makemkv");
    expect(settings).not.toContain("makemkv");
    expect(runtime).toContain("findExecutableInDirectory");
  });

  it("validates HandBrake compression output before marking a job complete", () => {
    const jobsRoute = readProjectFile(
      "artifacts/api-server/src/routes/jobs.ts",
    );

    expect(jobsRoute).toContain("validateCompressionOutput");
    expect(jobsRoute + zhPack()).toContain("压缩输出校验失败");
    expect(jobsRoute + zhPack()).toContain("压缩输出文件不存在或为空");
    expect(jobsRoute + zhPack()).toContain(
      "HandBrake 已成功退出，但后置校验失败",
    );
    expect(jobsRoute.indexOf("validateCompressionOutput")).toBeLessThan(
      jobsRoute.indexOf('status: "done"'),
    );
  });

  it("keeps unexpected async errors in the API log instead of silently exiting", () => {
    const index = readProjectFile("artifacts/api-server/src/index.ts");

    expect(index).toContain('process.on("unhandledRejection"');
    expect(index).toContain('process.on("uncaughtException"');
    expect(index).toContain("Unhandled rejection");
    expect(index).toContain("Uncaught exception");
  });

  it("does not auto-exit the API during long local jobs", () => {
    const index = readProjectFile("artifacts/api-server/src/index.ts");
    const services = readProjectFile("windows-setup/start-services.ps1");

    expect(services).toContain('set "VX_AGENT_AUTO_SHUTDOWN=1"');
    expect(index).toContain("VX_AGENT_AUTO_SHUTDOWN");
    expect(index).toContain("hasActiveJobs");
    expect(index).toContain("Browser ping timed out but active jobs exist");
    expect(index).not.toContain('process.env.NODE_ENV !== "production"');
  });

  it("exposes a menu-driven local shutdown path and normal software menubar", () => {
    const app = readProjectFile("artifacts/video-agent/src/App.tsx");
    const routes = readProjectFile("artifacts/api-server/src/routes/index.ts");
    const shutdownRoute = readProjectFile(
      "artifacts/api-server/src/routes/shutdown.ts",
    );

    expect(app).toContain("AppMenu");
    expect(app + zhPack()).toContain("文件");
    expect(app + zhPack()).toContain("处理");
    expect(app + zhPack()).toContain("工具");
    expect(app + zhPack()).toContain("设置");
    expect(app + zhPack()).toContain("帮助");
    expect(app + zhPack()).toContain("退出影刻");
    expect(app).toContain("/api/shutdown");
    expect(routes).toContain("shutdownRouter");
    expect(shutdownRoute).toContain('router.post("/shutdown"');
    expect(shutdownRoute).toContain("hasActiveJobs");
    expect(shutdownRoute).toContain('process.kill(process.pid, "SIGTERM")');
    expect(app).toContain("closeDesktopWindow");
    expect(app).toContain("if (isTauriDesktop())");
    expect(app.indexOf('if (isTauriDesktop())')).toBeLessThan(app.indexOf('fetch("/api/shutdown"'));
  });

  it("closes local services when the native desktop window exits so the install folder can be deleted", () => {
    const desktop = readProjectFile("desktop-tauri/src-tauri/src/main.rs");
    const sidecar = readProjectFile("desktop-tauri/src-tauri/src/sidecar.rs");
    const services = readProjectFile("windows-setup/start-services.ps1");
    const plan = readProjectFile(
      "docs/windows-install-cache-uninstall-plan.md",
    );

    expect(desktop).toContain("WindowEvent::CloseRequested");
    expect(desktop).toContain("sidecar.request_shutdown()");
    expect(desktop).toContain("ShutdownResult::ActiveJobs");
    expect(desktop).toContain("api.prevent_close()");
    expect(sidecar).toContain('const SHUTDOWN_PATH: &str = "/api/shutdown"');
    expect(services).toContain("finally");
    expect(services).toContain("Stop-AllServices -Silent");
    expect(services).toContain("taskkill /F /T /PID");
    expect(services).toContain(
      'Remove-Item -Path (Join-Path $proj ".vx-pids")',
    );
    expect(plan).toContain(
      "Closing the native desktop window requests local API shutdown",
    );
    expect(plan).toContain("the extracted software folder should be deletable");
  });

  it("keeps remuxing jobs alive during browser-ping shutdown checks", () => {
    const index = readProjectFile("artifacts/api-server/src/index.ts");
    expect(index).toMatch(
      /status IN \('pending','scanning','transcribing','compressing','remuxing'\)/,
    );
  });

  it("keeps settings and logs out of the left sidebar and opens them from dropdown menus", () => {
    const app = readProjectFile("artifacts/video-agent/src/App.tsx");
    const settingsPage = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );

    expect(app).not.toContain('href: "/settings", label: "设置"');
    expect(app).not.toContain('href: "/logs", label: "系统日志"');
    expect(app).toContain('go("/settings#tools")');
    expect(app).toContain('go("/settings#directories")');
    expect(app).toContain('go("/settings#compression")');
    expect(app).toContain('go("/settings#subtitles")');
    expect(app).toContain('go("/settings#ai")');
    expect(app).not.toContain('go("/settings#metadata")');
    expect(app).toContain('go("/settings#tuning")');
    expect(app).toContain('go("/settings#tools")');
    expect(app).toContain('go("/settings#system")');
    expect(app).toContain('go("/logs")');

    expect(settingsPage).toContain("useSettingsSections");
    expect(settingsPage).toContain('case "tools"');
    expect(settingsPage).toContain('section === "tools"');
    expect(settingsPage).toContain('section === "directories"');
    expect(settingsPage).toContain('section === "compression"');
    expect(settingsPage).toContain('section === "subtitles"');
    expect(settingsPage).toContain('section === "ai"');
    expect(settingsPage).not.toContain('section === "metadata"');
    expect(settingsPage).toContain('section === "tuning"');
    expect(settingsPage).toContain('section === "system"');
  });

  it("exposes queue-wide selection controls and display preferences in the UI", () => {
    const jobsPage = readProjectFile(
      "artifacts/video-agent/src/pages/Jobs.tsx",
    );
    const settingsPage = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );
    const routes = readProjectFile("artifacts/api-server/src/routes/jobs.ts");

    expect(jobsPage).toContain("selectedJobIds");
    expect(jobsPage + zhPack()).toContain("全选待处理");
    expect(jobsPage + zhPack()).toContain("整体开始队列");
    expect(jobsPage + zhPack()).toContain("开始所选");
    expect(settingsPage).toContain("outputResolution");
    expect(settingsPage + zhPack()).toContain("界面语言");
    expect(settingsPage + zhPack()).toContain("中文");
    expect(settingsPage + enPack()).toContain("English");
    expect(routes).toContain("outputResolution");
    expect(routes).toContain("uiLanguage");
  });

  it("keeps language in Settings (system section), switches UI immediately, and applies theme preferences", () => {
    const app = readProjectFile("artifacts/video-agent/src/App.tsx");
    const settingsPage = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );
    const desktopShell = readProjectFile("desktop-tauri/src-tauri/src/main.rs");

    expect(app).not.toContain("menu.language");
    expect(app).not.toContain("setAppLanguage");
    expect(app).toContain('t("menu.file")');
    expect(settingsPage).toContain("uiLanguage");
    expect(settingsPage).toContain("mutateAsync");
    expect(settingsPage).toContain("uiLanguage: value");
    expect(app).toContain("applyTheme");
    expect(app).not.toContain("document.documentElement.classList.add('dark')");
    expect(settingsPage).toContain("themeMode");
    expect(settingsPage + zhPack()).toContain("深海夜色");
    expect(settingsPage + zhPack()).toContain("晨光白");
    expect(desktopShell).toContain(
      "fn set_theme(window: Window, theme: String)",
    );
    expect(desktopShell).toContain('"morning-light"');
    expect(desktopShell).toMatch(
      /1180\.0_f64\.min\(available_width\)[\s\S]*820\.0_f64\.min\(available_height\)/,
    );
  });

  it("keeps browse details hidden until browse is selected and enriches file hover details", () => {
    const scanPage = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );
    const browseRoute = readProjectFile(
      "artifacts/api-server/src/routes/browse.ts",
    );
    const apiSchemas = readProjectFile(
      "lib/api-client-react/src/generated/api.schemas.ts",
    );

    expect(scanPage).toContain("SourceBrowserPanel");
    expect(scanPage).toContain('data-testid="source-browser-panel"');
    expect(scanPage + zhPack()).toContain("文件大小");
    expect(scanPage).toContain("entry.sizeBytes");
    expect(scanPage).toContain(
      "fileTitle={(entry) => fileHoverTitle(entry, t, lang)}",
    );
    expect(browseRoute).toContain("sizeBytes");
    expect(browseRoute).toContain("modifiedAt");
    expect(apiSchemas).toContain("sizeBytes?: number");
    expect(apiSchemas).toContain("modifiedAt?: string");
  });

  it("supports editable compression presets with resolution and import/export menu entries", () => {
    const app = readProjectFile("artifacts/video-agent/src/App.tsx");
    const detailPage = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const settingsPage = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );

    expect(app + zhPack()).toContain("导入预设");
    expect(app + zhPack()).toContain("导出预设");
    expect(detailPage).toContain("loadCompressionPresets");
    expect(detailPage).toContain("compressionPresets");
    expect(detailPage).toContain("outputResolution");
    expect(detailPage).toContain("<DecisionParameterPanel");
    expect(settingsPage).toContain("outputResolution");
  });

  it("uses mouse-select controls for compression preset editing and source-directory outputs", () => {
    const detailPage = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const scanPage = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );
    const settingsPage = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );
    const jobsRoute = readProjectFile(
      "artifacts/api-server/src/routes/jobs.ts",
    );

    expect(detailPage).toContain("compressionPresets.map");
    expect(detailPage).toContain("preset.values.encoder");
    expect(detailPage).toContain("config?.outputResolution");
    expect(scanPage).not.toContain('placeholder="编码器"');
    expect(scanPage).not.toContain("updateCompressionPresetDraft");
    expect(settingsPage + zhPack()).toContain("与源文件同目录");
    expect(settingsPage).toContain("__source__");
    expect(jobsRoute).toContain("SOURCE_DIRECTORY_VALUE");
    expect(jobsRoute).toContain("resolveJobOutputDirectory");
    expect(jobsRoute).toContain("resolveJobSubtitleDirectory");
    expect(jobsRoute + zhPack()).toContain(
      "字幕文件默认输出到视频源文件同目录",
    );
  });

  it("remembers network browse paths and keeps the native window draggable", () => {
    const scanPage = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );
    const app = readProjectFile("artifacts/video-agent/src/App.tsx");
    const desktopShell = readProjectFile("desktop-tauri/src-tauri/src/main.rs");
    const capability = readProjectFile(
      "desktop-tauri/src-tauri/capabilities/default.json",
    );

    expect(scanPage).toContain("VX_AGENT_NETWORK_PATHS");
    expect(scanPage).toContain("readNetworkPathHistory");
    expect(scanPage).toContain("rememberNetworkPath");
    expect(scanPage).toContain("networkPathHistory.map");
    expect(scanPage + zhPack()).toContain("最近使用");
    expect(app).toContain("data-tauri-drag-region");
    expect(app).toContain('data-testid="desktop-window-controls"');
    expect(desktopShell).toContain(".decorations(false)");
    expect(capability).toContain("core:window:allow-start-dragging");
  });

  it("extends English UI coverage beyond the shell menu", () => {
    const app = readProjectFile("artifacts/video-agent/src/App.tsx");
    const scanPage = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );

    expect(app).toContain('document.title = t("brand.documentTitle")');
    expect(enPack()).toContain("Video compression");
    expect(enPack()).toContain("Same as source folder");
    expect(scanPage).toContain("uiText");
    expect(scanPage + enPack()).toContain("Media Workbench");
    expect(scanPage + enPack()).toContain("Processing mode");
    expect(scanPage).not.toContain("Compression presets");
    expect(scanPage + enPack()).toContain("Disc analysis");
    expect(scanPage + enPack()).toContain("Create video compression job");
    expect(scanPage + enPack()).toContain("Recent locations");
    expect(enPack()).toContain("Import presets");
    expect(enPack()).toContain("Export presets");
  });

  it("opens job output folders through the runtime endpoint using the exact output path", () => {
    const jobsPage = readProjectFile(
      "artifacts/video-agent/src/pages/Jobs.tsx",
    );
    const routes = readProjectFile("artifacts/api-server/src/routes/jobs.ts");

    expect(jobsPage).toContain("openOutputPath");
    expect(jobsPage).toContain("job.outputPath");
    expect(jobsPage).not.toContain("outputDir(job.outputPath!)");
    expect(routes).toContain("resolveRuntimePath");
    expect(routes).toContain("resolveExistingOpenDirectory(runtimePath)");
    expect(routes).toContain('child.once("spawn"');
  });

  it("provides the desktop window through the Tauri app and keeps source runs native", () => {
    const services = readProjectFile("windows-setup/start-services.ps1");
    const installer = readProjectFile("windows-setup/install.ps1");
    const desktop = readProjectFile("desktop-tauri/src-tauri/src/main.rs");
    const plan = readProjectFile("docs/windows-native-menu-ui-plan.md");

    expect(desktop).toContain(
      'WebviewWindowBuilder::new(app, "main", local_application_url()?)',
    );
    expect(desktop).toContain('.title("MediaSculpt")');
    expect(services).toContain("native desktop launcher");
    expect(services).toContain("MEDIASCULPT_LEGACY_BROWSER_MODE");
    expect(services).not.toContain("desktop-shell");
    expect(services).not.toContain("Start-DesktopWindow");
    expect(services).not.toMatch(/electron/i);
    expect(installer).not.toContain("desktop-shell");
    expect(installer).not.toMatch(/electron/i);
    expect(plan).toContain("Tauri");
    expect(plan).not.toMatch(/electron/i);
    expect(plan + zhPack()).toContain("常规 Windows 窗口");
    expect(plan + zhPack()).toContain("不再自动打开系统浏览器");
    expect(plan + zhPack()).toContain("设置和系统日志不再出现在左侧导航");
  });

  it("routes every source shortcut through the single native launcher", () => {
    const dev = readProjectFile("scripts/start-dev.ps1");
    const root = readProjectFile("Start MediaSculpt.bat");
    const hidden = readProjectFile("windows-setup/hidden-launcher.vbs");
    const diagnostics = readProjectFile(
      "windows-setup/start-with-diagnostics.ps1",
    );

    expect(dev).toContain("tauri dev");
    expect(dev).not.toContain("Start-Process $url");
    expect(root).toContain("scripts\\start-dev.ps1");
    expect(root).toContain("-WindowStyle Hidden");
    expect(hidden + diagnostics).toContain("scripts\\start-dev.ps1");
    expect(hidden + diagnostics).not.toContain("24403/workbench");
  });

  it("keeps native startup single-window and never opens a browser implicitly", () => {
    const launcher = readProjectFile("scripts/start-dev.ps1");
    const desktop = readProjectFile("desktop-tauri/src-tauri/src/main.rs");

    expect(launcher).toContain("tauri dev");
    expect(launcher).not.toContain("OpenBrowser");
    expect(desktop).toContain("TcpStream::connect_timeout");
    expect(desktop).toContain("http://127.0.0.1:18080");
    expect(desktop).toContain("MediaSculpt-Desktop");
    expect(desktop).toContain("already running");
    expect(desktop).toContain(
      '#![cfg_attr(windows, windows_subsystem = "windows")]',
    );
  });

  it("logs desktop sidecar failures and flashes the taskbar on job completion", () => {
    const desktop = readProjectFile("desktop-tauri/src-tauri/src/main.rs");
    const sidecar = readProjectFile("desktop-tauri/src-tauri/src/sidecar.rs");
    const bridge = readProjectFile(
      "artifacts/video-agent/src/lib/desktop-bridge.ts",
    );
    const services = readProjectFile("windows-setup/start-services.ps1");

    expect(sidecar).toContain("mediasculpt-diagnostics.log");
    expect(sidecar).toContain("MEDIASCULPT_DIAGNOSTICS_LOG");
    expect(desktop).toContain(
      "request_user_attention(Some(UserAttentionType::Informational))",
    );
    expect(bridge).toContain(
      'invoke<void>("notify_task_complete", { title, body })',
    );
    expect(bridge).not.toMatch(/electron/i);
    expect(bridge).not.toContain("mediaSculpt?:");
    expect(services).not.toContain("desktop-window-output.tmp.log");
    expect(services).not.toContain("Desktop window exited unexpectedly");
  });

  it("does not auto-select an embedded subtitle when opening job preview", () => {
    const detail = readProjectFile("artifacts/video-agent/src/pages/JobDetail.tsx");
    const streamsEffectStart = detail.indexOf('fetch(`/api/jobs/${jobId}/streams`)');
    const subtitlesEffectStart = detail.indexOf('fetch(`/api/jobs/${jobId}/subtitles`)');
    const streamsEffect = detail.slice(streamsEffectStart, subtitlesEffectStart);

    expect(detail).toContain("不在详情页自动预选");
    expect(streamsEffect).not.toContain("setSubtitlePreviewKind");
    expect(streamsEffect).not.toContain("自动选中第一条内置文本字幕轨");
  });

  it("supervises only the API and web services in source run mode", () => {
    const services = readProjectFile("windows-setup/start-services.ps1");

    expect(services).toContain("while ($pidFileOwned) {");
    expect(services).toContain("if ($apiProc.HasExited) {");
    expect(services).toContain("if ($webProc.HasExited) {");
    expect(services).not.toContain("$desktopProc");
    expect(services).not.toContain("_desktop.bat");
    expect(services).not.toContain("Desktop shell dependencies are missing");
    expect(services).not.toContain("browser fallback is disabled");
  });

  it("keeps dependency lockfiles so repeated Windows installs can reuse caches", () => {
    const installer = readProjectFile("windows-setup/install.ps1");

    expect(installer).toContain("--store-dir");
    expect(installer).toContain("$pnpmStoreDir");
    expect(installer).not.toContain('Remove-Item "pnpm-lock.yaml"');
    expect(installer).not.toContain("Removed Linux lockfile");
  });

  it("fails disc remux through MakeMKV validation instead of accepting a suspiciously small output", () => {
    const jobsRoute = readProjectFile(
      "artifacts/api-server/src/routes/jobs.ts",
    );
    const validation = readProjectFile(
      "artifacts/api-server/src/lib/remux-validation.ts",
    );

    expect(jobsRoute).toContain("FFmpeg Remux 输出校验失败");
    expect(jobsRoute).toContain("validateRemuxOutput");
    expect(validation).toContain("minimumSizeRatio");
  });

  it("rounds displayed durations to whole seconds", () => {
    const utils = readProjectFile("artifacts/video-agent/src/lib/utils.ts");

    expect(utils).toContain("Math.round(seconds)");
    expect(utils).not.toContain("const s = seconds % 60");
  });

  it("moves source workflow controls out of job detail into the media workbench", () => {
    const app = readProjectFile("artifacts/video-agent/src/App.tsx");
    const workbench = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );

    expect(app + zhPack()).toContain("影音工作台");
    expect(app).toContain('href: "/workbench"');
    expect(app).toContain('path="/workbench"');
    expect(workbench + zhPack()).toContain("影音工作台");
    expect(workbench).toContain("FFmpeg");
    expect(workbench).toContain("HandBrake");
    expect(workbench + zhPack()).toContain("默认窗口");
    expect(detail).not.toContain("<StreamSelector");
    expect(detail).not.toContain("useRunSubtitlePipeline");
    expect(detail).not.toContain("useLookupMetadata");
    expect(detail).toContain("SourceInfoCompactBar");
    expect(detail).toContain("DecisionParameterPanel");
    expect(detail + zhPack()).toContain("日志与文件详情");
  });

  it("opens output folders by passing the original output file path to the runtime opener", () => {
    const jobsPage = readProjectFile(
      "artifacts/video-agent/src/pages/Jobs.tsx",
    );
    const detailPage = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const routes = readProjectFile("artifacts/api-server/src/routes/jobs.ts");
    const desktopBridge = readProjectFile(
      "artifacts/video-agent/src/lib/desktop-bridge.ts",
    );

    expect(jobsPage).toContain("openDesktopPath(hostPath)");
    expect(detailPage).toContain("openDesktopPath(hostPath)");
    expect(desktopBridge).toContain('fetch("/api/runtime/open-path"');
    expect(jobsPage).toContain("toHostPath(p, config) || p");
    expect(detailPage).toContain("toHostPath(p, config) || p");
    expect(jobsPage).not.toContain("outputDir(job.outputPath!)");
    expect(detailPage).not.toContain("openPath(outputDir(job.outputPath!))");
    expect(routes).toContain(
      "const openTarget = await resolveExistingOpenDirectory(runtimePath)",
    );
  });

  it("keeps a single outermost scroll region (expanded source list has no inner scrollbar)", () => {
    const app = readProjectFile("artifacts/video-agent/src/App.tsx");
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const playerCard = readProjectFile(
      "artifacts/video-agent/src/components/PreviewPlayerCard.tsx",
    );
    const css = readProjectFile("artifacts/video-agent/src/index.css");

    expect(app).toContain("overflow-hidden");
    expect(scan).not.toContain("max-h-[46vh]");
    expect(scan + zhPack()).toContain("默认不展开文件列表");
    expect(playerCard).toContain("h-[min(58vh,calc(100vh-19rem))]");
    expect(detail).toContain("line-clamp-2");
    expect(css).toContain("scrollbar-color");
    expect(css).toContain("::-webkit-scrollbar-thumb");
    expect(css).toContain("theme-morning-light");
  });

  it("uses a smart workflow entry without bringing back the old scan/workflow loop", () => {
    const app = readProjectFile("artifacts/video-agent/src/App.tsx");
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    const workflow = readProjectFile(
      "artifacts/video-agent/src/pages/Workflow.tsx",
    );
    const docs = readProjectFile("docs/stability-naming-preview-plan.md");

    expect(app + zhPack()).toContain("影音工作台");
    expect(app + enPack()).toContain("Media Workbench");
    expect(app).toContain('href: "/workbench"');
    expect(app).toContain('path="/workbench"');
    expect(app).not.toContain('href: "/workflow"');
    expect(app).toContain('path="/workflow"');
    expect(app + zhPack()).toContain("智能工作流");
    expect(app).not.toContain('href: "/scan"');
    expect(app).not.toContain("扫描目录");
    expect(app).not.toContain("处理工作流");
    expect(scan + zhPack()).toContain("影音工作台");
    expect(scan).toContain("SourceBrowserPanel");
    expect(scan).toContain("WorkbenchHint");
    expect(scan).toContain("TooltipContent");
    expect(scan).toContain('data-testid="workbench-mode-tabs"');
    expect(scan).toContain("Workflow");
    expect(scan).toContain("mode-tab-${mode}");
    expect(scan).not.toContain("准专业");
    expect(workflow).not.toContain("处理工作流");
    expect(workflow).toContain("export default function Workflow");
    expect(docs + zhPack()).toContain("影音工作台");
    expect(docs + zhPack()).toContain("说明性文字默认收进悬浮提示");
    expect(docs).not.toContain("准专业");
  });
});
