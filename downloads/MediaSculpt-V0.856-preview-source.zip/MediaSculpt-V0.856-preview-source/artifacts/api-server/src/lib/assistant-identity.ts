export type AssistantIdentitySource = { imdbId?: string | null } | null | undefined;

/**
 * Resolve the canonical IMDb id for one analysis request.
 *
 * The durable sidecar is cache-first: when it holds a record, the provider
 * lookup never runs, so `bestLookup` stays null while `metadataBest` carries the
 * identity. Reading only the fresh lookup therefore lost the id on every cache
 * hit, which is why the IMDb field stopped being written back into the panel.
 */
export function resolveAssistantImdbId(params: {
  imdbIdInput?: string | null;
  metadataBest?: AssistantIdentitySource;
  lookup?: AssistantIdentitySource;
}): string | null {
  for (const candidate of [params.imdbIdInput, params.metadataBest?.imdbId, params.lookup?.imdbId]) {
    const value = candidate?.trim();
    if (value) return value;
  }
  return null;
}
