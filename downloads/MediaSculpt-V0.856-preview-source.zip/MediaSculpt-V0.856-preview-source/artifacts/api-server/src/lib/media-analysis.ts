export type MediaType = "video" | "bluray" | "dvd" | "iso";
export type AnalysisStreamType = "video" | "audio" | "subtitle";

export type AnalysisStream = {
  index: number;
  codecType: AnalysisStreamType;
  codecName: string;
  language?: string | null;
  title?: string | null;
  width?: number | null;
  height?: number | null;
  channels?: number | null;
  default?: boolean;
  forced?: boolean;
};

export type AnalysisChapter = {
  id: number;
  startSeconds: number;
  endSeconds: number;
  title?: string | null;
};

export type MediaAnalysis = {
  sourcePath: string;
  mediaType: MediaType;
  durationSeconds: number | null;
  streams: AnalysisStream[];
  chapters: AnalysisChapter[];
};

export type NormalizedSelection = {
  video: number[];
  audio: number[];
  subtitle: number[];
  chapters: number[];
};

export function normalizeSelection(analysis: MediaAnalysis, selectedStreams?: number[], selectedChapters?: number[]): NormalizedSelection {
  const available = new Set(analysis.streams.map((stream) => stream.index));
  const requested = selectedStreams ?? [...available];
  const valid = requested.filter((index) => available.has(index));
  const selected = new Set(valid);
  return {
    video: analysis.streams.filter((s) => s.codecType === "video" && selected.has(s.index)).map((s) => s.index),
    audio: analysis.streams.filter((s) => s.codecType === "audio" && selected.has(s.index)).map((s) => s.index),
    subtitle: analysis.streams.filter((s) => s.codecType === "subtitle" && selected.has(s.index)).map((s) => s.index),
    chapters: (selectedChapters ?? analysis.chapters.map((chapter) => chapter.id))
      .filter((id) => analysis.chapters.some((chapter) => chapter.id === id)),
  };
}
