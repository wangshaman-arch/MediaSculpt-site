import type { MetadataResult } from "./metadata";
import {
  hasEnrichment,
  readTitleMetadata,
  writeTitleMetadata,
  type MetadataTier,
  type TitleMetadataRecord,
} from "./title-metadata";

/**
 * Cache-first resolution.
 *
 * A title that has already been resolved must not be resolved again: the user's
 * customers may have no API keys and no reliable network, and re-querying every
 * run both wastes requests and leaves the UI empty the moment the network is
 * down. The durable sidecar beside the media is therefore consulted first, and
 * the network is only used when the sidecar has nothing useful yet.
 */

/** Providers that require a configured key (or an imported dataset). */
const KEYED_SOURCES = new Set(["tmdb", "omdb"]);

/**
 * Decide the tier a resolution attempt achieved. `resolvedBy` must reflect what
 * actually answered, because the UI uses it to tell a user whether enabling a
 * key or AI would still add information.
 */
export function tierForResolution(params: {
  /** Source of the merged result, when one was produced. */
  source?: string | null;
  /** True when the configured LLM contributed to this record. */
  usedAi?: boolean;
  /** True when the local IMDb dataset answered. */
  usedLocalDataset?: boolean;
}): MetadataTier {
  if (params.usedAi) return "ai";
  if (params.usedLocalDataset) return "keyed";
  if (params.source && KEYED_SOURCES.has(params.source)) return "keyed";
  return "keyless";
}

/**
 * Rebuild a provider-shaped result from a cached record so the rest of the
 * pipeline can consume it without knowing whether it came from disk or network.
 * Returns null when the record carries no identity to work with.
 */
export function recordToMetadataResult(record: TitleMetadataRecord | null): MetadataResult | null {
  if (!record) return null;
  const title = (record.titleEn || record.title || "").trim();
  if (!title) return null;
  return {
    title: (record.title || record.titleEn || title).trim(),
    titleEn: record.titleEn ?? undefined,
    year: record.year ?? undefined,
    imdbId: record.imdbId ?? undefined,
    tmdbId: record.tmdbId ?? undefined,
    director: record.director ?? undefined,
    cast: record.cast ?? undefined,
    genres: record.genres ?? undefined,
    rating: record.rating ?? undefined,
    ratingSource: (record.ratingSource as MetadataResult["ratingSource"]) ?? undefined,
    runtimeMinutes: record.runtimeMinutes ?? undefined,
    overview: record.overview ?? undefined,
    poster: record.poster ?? undefined,
    mediaType: "movie",
    source: "imdb",
  };
}

export type CachedResolution = {
  /** Reusable result, or null when the network still needs to be consulted. */
  result: MetadataResult | null;
  tier: MetadataTier | null;
  /** Why the cache was not used, for logging/diagnostics. */
  reason: "hit" | "missing" | "not-enriched";
};

/**
 * Look for a reusable record. A filename-only record is treated as a miss: it
 * carries no more than the parsed name already does, so the network should still
 * get a chance to enrich it.
 */
export async function resolveFromCache(
  targetDirectory: string | null | undefined,
): Promise<CachedResolution> {
  if (!targetDirectory) return { result: null, tier: null, reason: "missing" };
  const { record, tier } = await readTitleMetadata(targetDirectory);
  if (!record) return { result: null, tier: null, reason: "missing" };
  if (!hasEnrichment(record) && !record.imdbId) {
    return { result: null, tier, reason: "not-enriched" };
  }
  const result = recordToMetadataResult(record);
  if (!result) return { result: null, tier, reason: "not-enriched" };
  return { result, tier, reason: "hit" };
}

/**
 * Persist the merged result. Empty fields are never written over populated
 * ones, and the tier never moves backwards — both enforced by
 * `writeTitleMetadata`.
 */
export async function persistResolvedMetadata(params: {
  targetDirectory: string | null | undefined;
  result: MetadataResult | null;
  tier: MetadataTier;
  sources?: Record<string, string> | null;
}): Promise<TitleMetadataRecord | null> {
  if (!params.targetDirectory || !params.result) return null;
  const result = params.result;
  return writeTitleMetadata(
    params.targetDirectory,
    {
      title: result.title ?? null,
      titleEn: result.titleEn ?? null,
      year: result.year ?? null,
      imdbId: result.imdbId ?? null,
      tmdbId: result.tmdbId ?? null,
      director: result.director ?? null,
      cast: result.cast ?? null,
      genres: result.genres ?? null,
      rating: result.rating ?? null,
      ratingSource: result.ratingSource ?? null,
      runtimeMinutes: result.runtimeMinutes ?? null,
      overview: result.overview ?? null,
      poster: result.poster ?? null,
      sources: params.sources ?? null,
    },
    params.tier,
  );
}
