import { describe, it, expect } from "vitest";
import { assessDiscComplexity } from "./disc-complexity";
import { buildDvdStructurePayload, validateRemuxPlan, type RemuxPlan } from "./dvd-llm";
import type { DiscAnalysisResult, DiscAnalysisStream, UnifiedDiscTitle } from "./disc-analysis";

function stream(partial: Partial<DiscAnalysisStream> & { index: number; codecType: "video" | "audio" | "subtitle" }): DiscAnalysisStream {
  return { codecName: null, language: null, title: null, ...partial };
}

function title(partial: Partial<UnifiedDiscTitle> & { titleId: string }): UnifiedDiscTitle {
  return {
    titleIndex: 0,
    sourcePath: "D:\\disc\\VIDEO_TS",
    displayName: partial.titleId,
    durationSeconds: 100,
    chapterCount: 1,
    chapters: [],
    estimateSize: null,
    estimatedSize: null,
    streams: [],
    videoTracks: [],
    audioTracks: [],
    subtitleTracks: [],
    toolMappings: { handbrakeTitleNumber: null, makemkvTitleIndex: null, dvdVtsNumber: null },
    mappingStatus: "not-required",
    ...partial,
  } as UnifiedDiscTitle;
}

function analysis(titles: UnifiedDiscTitle[]): DiscAnalysisResult {
  return {
    analysisId: "disc-a",
    sourcePath: "D:\\disc\\VIDEO_TS",
    sourceFingerprint: "fp",
    mediaType: "dvd",
    createdAt: "2026-01-01T00:00:00Z",
    titles,
    exportCandidates: [],
    diagnostics: [],
    diagnosticLogPath: null,
    warnings: [],
  };
}

describe("assessDiscComplexity", () => {
  it("simple single-feature disc is not complex", () => {
    const t = title({ titleId: "handbrake:1", durationSeconds: 6000, videoTracks: [stream({ index: 6, codecType: "video" })], audioTracks: [stream({ index: 7, codecType: "audio", language: "eng" })], streams: [{ index: 6, codecType: "video", codecName: "mpeg2video", language: null, title: null }, { index: 7, codecType: "audio", codecName: "ac3", language: "eng", title: null }] });
    expect(assessDiscComplexity(analysis([t])).complex).toBe(false);
  });

  it("ambiguous main feature (two long similar titles) is complex", () => {
    const a = title({ titleId: "handbrake:1", durationSeconds: 3000, videoTracks: [stream({ index: 1, codecType: "video" })], streams: [{ index: 1, codecType: "video", codecName: "mpeg2video", language: null, title: null }] });
    const b = title({ titleId: "handbrake:2", durationSeconds: 2900, videoTracks: [stream({ index: 4, codecType: "video" })], streams: [{ index: 4, codecType: "video", codecName: "mpeg2video", language: null, title: null }] });
    expect(assessDiscComplexity(analysis([a, b])).complex).toBe(true);
  });

  it("many titles alone is NOT complex (deterministic can handle episode discs)", () => {
    const ts = Array.from({ length: 10 }, (_, i) => title({ titleId: `handbrake:${i}`, durationSeconds: 600, videoTracks: [stream({ index: i, codecType: "video" })], streams: [{ index: i, codecType: "video", codecName: "mpeg2video", language: null, title: null }] }));
    expect(assessDiscComplexity(analysis(ts)).complex).toBe(false);
  });

  it("conflicting tool-scan (failed verification) is complex", () => {
    const t = title({ titleId: "handbrake:1", durationSeconds: 3000, verificationStatus: "failed", videoTracks: [stream({ index: 1, codecType: "video" })], streams: [{ index: 1, codecType: "video", codecName: "mpeg2video", language: null, title: null }] });
    expect(assessDiscComplexity(analysis([t])).complex).toBe(true);
  });
});

describe("buildDvdStructurePayload", () => {
  it("produces valid JSON with real stream indices", () => {
    const t = title({
      titleId: "handbrake:6",
      durationSeconds: 1033,
      toolMappings: { handbrakeTitleNumber: 6, makemkvTitleIndex: null, dvdVtsNumber: 6 },
      videoTracks: [stream({ index: 1, codecType: "video", codecName: "mpeg2video", width: 720, height: 480 })],
      audioTracks: [stream({ index: 2, codecType: "audio", codecName: "ac3", channels: 2 })],
      subtitleTracks: [stream({ index: 3, codecType: "subtitle", codecName: "dvd_subtitle", language: "eng", forced: false })],
    });
    const payload = JSON.parse(buildDvdStructurePayload(analysis([t])));
    expect(payload.titles[0].id).toBe("handbrake:6");
    expect(payload.titles[0].video[0].i).toBe(1);
    expect(payload.titles[0].audio[0].i).toBe(2);
    expect(payload.titles[0].subtitle[0].i).toBe(3);
  });
});

describe("validateRemuxPlan", () => {
  const a = analysis([
    title({
      titleId: "handbrake:6",
      durationSeconds: 1033,
      videoTracks: [stream({ index: 1, codecType: "video", codecName: "mpeg2video" })],
      audioTracks: [stream({ index: 2, codecType: "audio", codecName: "ac3", language: "eng" }), stream({ index: 3, codecType: "audio", codecName: "dts", language: "ita" })],
      subtitleTracks: [stream({ index: 4, codecType: "subtitle", codecName: "dvd_subtitle", language: "eng" }), stream({ index: 5, codecType: "subtitle", codecName: "dvd_subtitle", language: "ita", forced: true })],
    }),
  ]);

  it("accepts a real stream selection and drops invalid audio refs", () => {
    const plan: RemuxPlan = { titleId: "handbrake:6", video: 1, audio: [2, 3, 999], subtitles: [4] };
    const result = validateRemuxPlan(plan, a);
    expect(result.ok).toBe(true);
    expect(result.plan?.videoIndex).toBe(1);
    expect(result.plan?.audioIndices).toEqual([2, 3]);
    expect(result.plan?.subtitleIndices).toEqual([4]);
  });

  it("rejects a nonexistent title", () => {
    const result = validateRemuxPlan({ titleId: "handbrake:999", video: 1 }, a);
    expect(result.ok).toBe(false);
  });

  it("rejects a nonexistent video stream", () => {
    const result = validateRemuxPlan({ titleId: "handbrake:6", video: 777 }, a);
    expect(result.ok).toBe(false);
  });

  it("never recommends a DVD title whose payload scan failed", () => {
    const unavailable = analysis([title({
      titleId: "handbrake:23",
      availabilityStatus: "unavailable",
      videoTracks: [stream({ index: 1, codecType: "video" })],
    })]);
    const result = validateRemuxPlan({ titleId: "handbrake:23", video: 1 }, unavailable);
    expect(result).toMatchObject({ ok: false, plan: null });
    expect(result.reason).toContain("无法读取实际视频数据");
  });

  it("falls back to all audio when LLM gives no valid audio", () => {
    const result = validateRemuxPlan({ titleId: "handbrake:6", video: 1, audio: [999], subtitles: [] }, a);
    expect(result.ok).toBe(true);
    expect(result.plan?.audioIndices).toEqual([2, 3]);
    expect(result.plan?.subtitleIndices).toEqual([4, 5]);
  });
});
