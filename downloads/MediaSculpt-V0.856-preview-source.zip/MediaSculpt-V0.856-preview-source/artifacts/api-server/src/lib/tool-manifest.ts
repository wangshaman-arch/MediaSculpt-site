import os from "node:os";
import path from "node:path";
import { managedToolDirectory, type RuntimePlatform, type ToolId } from "./tool-runtime";

export type ToolPackage = {
  id: ToolId;
  label: string;
  required: boolean;
  installDirectory: string;
  sources: string[];
  checksum?: string;
};

/**
 * GitHub 加速镜像，按国内实测可达性排序（可用/快在前，失效/慢在后）。
 * 2026-08 实测(无VPN)：ghproxy.cn/ghproxy.net/gh-proxy.com/gh.con.sh/ghfast.top 可达，
 * github.moeyy.xyz/mirror.ghproxy.com/gh.llkk.cc 超时失败，放到队尾。
 * 直接 github.com 作为最后兜底。
 */
const GH_PROXY_PREFIXES = [
  "https://ghfast.top/",
  "https://ghproxy.net/",
  "https://gh.con.sh/",
  "https://github.moeyy.xyz/",
  "https://ghproxy.cc/",
  "https://gh.ddlc.top/",
  "https://ghps.cc/",
  "https://mirror.ghproxy.com/",
  "https://gh-proxy.com/",
  "https://ghproxy.cn/",
  "https://gh.llkk.cc/",
  "https://hub.gitmirror.com/",
  "https://ghproxy.vv.gd/",
  "https://gh.ykk.moe/",
  "https://gh.cp0204.top/",
];

/** 用镜像前缀包住 raw GitHub 下载地址，生成候选列表。GitHub 直连排第一：
 * 部分地区直连可达且稳定（虽然慢），配合断点续传能完整下载；镜像随后兜底。 */
export function ghMirrorChain(rawUrl: string): string[] {
  return [rawUrl, ...GH_PROXY_PREFIXES.map((prefix) => `${prefix}${rawUrl}`)];
}

/** 官方发布页/下载源；二进制文件名会随版本变化，因此不硬编码易失效的版本号。 */
const officialSources: Record<RuntimePlatform, Partial<Record<ToolId, string[]>>> = {
  darwin: {
    ffmpeg: ["https://evermeet.cx/ffmpeg/", "https://github.com/BtbN/FFmpeg-Builds/releases"],
    handbrake: ["https://handbrake.fr/downloads.php", "https://github.com/HandBrake/HandBrake/releases"],
    whisper: ["https://github.com/openai/whisper", "https://openaipublic.blob.core.windows.net/main/whisper/models/"],
    libretranslate: ["https://pypi.org/project/libretranslate/"],
    rapidocr: ["https://pypi.org/project/rapidocr_onnxruntime/"],
    // macOS has no official standalone Tesseract binary; use Homebrew or the
    // upstream source page. The installer URL field doubles as documentation.
    tesseract: ["https://github.com/tesseract-ocr/tesseract", "https://formulae.brew.sh/formula/tesseract"],
  },
  win32: {
    // 国内用户直连 GitHub 下载大文件经常超时，因此把可用的国内加速镜像放在官方源之前，
    // 每个源都会按顺序尝试直到成功。官方 releases 页面保留作为最后兜底。
    ffmpeg: [
      ...ghMirrorChain("https://github.com/BtbN/FFmpeg-Builds/releases/latest/download/ffmpeg-master-latest-win64-gpl.zip"),
      "https://github.com/BtbN/FFmpeg-Builds/releases",
    ],
    ffprobe: [
      ...ghMirrorChain("https://github.com/BtbN/FFmpeg-Builds/releases/latest/download/ffmpeg-master-latest-win64-gpl.zip"),
      "https://github.com/BtbN/FFmpeg-Builds/releases",
    ],
    handbrake: [
      ...ghMirrorChain("https://github.com/HandBrake/HandBrake/releases/download/1.11.2/HandBrakeCLI-1.11.2-win-x86_64.zip"),
      "https://handbrake.fr/downloads.php",
      "https://github.com/HandBrake/HandBrake/releases",
    ],
    whisper: ["https://github.com/openai/whisper", "https://openaipublic.blob.core.windows.net/main/whisper/models/"],
    libretranslate: ["https://pypi.org/project/libretranslate/"],
    rapidocr: ["https://pypi.org/project/rapidocr_onnxruntime/"],
    // UB-Mannheim ships the de-facto Windows Tesseract build as an NSIS
    // installer. Mirrors come first because the binary is large (~150 MB).
    // The downloader runs it with /S /D=<managed dir> and then installs the
    // common language data (tessdata_fast) next to the executable.
    tesseract: [
      ...ghMirrorChain("https://github.com/UB-Mannheim/tesseract/releases/download/v5.4.0.20240606/tesseract-ocr-w64-setup-5.4.0.20240606.exe"),
      "https://github.com/UB-Mannheim/tesseract/releases",
    ],
  },
  linux: {
    ffmpeg: ["https://johnvansickle.com/ffmpeg/", "https://github.com/BtbN/FFmpeg-Builds/releases"],
    handbrake: ["https://handbrake.fr/downloads.php", "https://github.com/HandBrake/HandBrake/releases"],
    whisper: ["https://github.com/openai/whisper", "https://openaipublic.blob.core.windows.net/main/whisper/models/"],
    libretranslate: ["https://pypi.org/project/libretranslate/"],
    rapidocr: ["https://pypi.org/project/rapidocr_onnxruntime/"],
    // Linux Tesseract is normally installed via apt/dnf/pacman. The source
    // page is kept as documentation for the installer URL field.
    tesseract: ["https://github.com/tesseract-ocr/tesseract"],
  },
};

const sourceEnv: Partial<Record<ToolId, string>> = {
  ffmpeg: process.env.MEDIASCULPT_FFMPEG_URL ?? process.env.VX_AGENT_FFMPEG_URL,
  ffprobe: process.env.MEDIASCULPT_FFPROBE_URL ?? process.env.VX_AGENT_FFPROBE_URL,
  handbrake: process.env.MEDIASCULPT_HANDBRAKE_URL ?? process.env.VX_AGENT_HANDBRAKE_URL,
  whisper: process.env.MEDIASCULPT_WHISPER_URL ?? process.env.VX_AGENT_WHISPER_URL,
  libretranslate: process.env.MEDIASCULPT_LIBRETRANSLATE_URL ?? process.env.VX_AGENT_LIBRETRANSLATE_URL,
  tesseract: process.env.MEDIASCULPT_TESSERACT_URL ?? process.env.VX_AGENT_TESSERACT_URL,
  rapidocr: process.env.MEDIASCULPT_RAPIDOCR_URL ?? process.env.VX_AGENT_RAPIDOCR_URL,
};

export function toolPackages(platform: RuntimePlatform = process.platform as RuntimePlatform, home = os.homedir()): ToolPackage[] {
  const root = managedToolDirectory(platform, home);
  const packageFor = (id: ToolId, label: string, required: boolean): ToolPackage => ({
    id,
    label,
    required,
    installDirectory: path.join(root, id),
    sources: sourceEnv[id] ? [sourceEnv[id]!] : (officialSources[platform]?.[id] ?? []),
  });
  return [
    packageFor("ffmpeg", "FFmpeg", true),
    packageFor("ffprobe", "FFprobe", true),
    packageFor("handbrake", "HandBrakeCLI", true),
    packageFor("whisper", "Whisper", false),
    packageFor("libretranslate", "LibreTranslate", false),
    packageFor("tesseract", "Tesseract OCR", false),
    packageFor("rapidocr", "RapidOCR（中文 OCR）", false),
  ];
}

export function getToolPackage(id: ToolId, platform?: RuntimePlatform): ToolPackage {
  const found = toolPackages(platform).find((pkg) => pkg.id === id);
  if (!found) throw new Error(`未知工具：${id}`);
  return found;
}
