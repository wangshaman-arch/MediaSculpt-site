import { afterEach, describe, expect, it } from "vitest";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { openSqliteDatabase } from "../../../../lib/db/src/sqlite";
import { sqliteSchema } from "../../../../lib/db/src/sqlite-schema";
import { eq } from "drizzle-orm";

describe("node sqlite driver", () => {
  let client: ReturnType<typeof openSqliteDatabase>["client"] | undefined;
  let tempDirectory: string | undefined;

  afterEach(() => {
    client?.close();
    if (tempDirectory) fs.rmSync(tempDirectory, { recursive: true, force: true });
  });

  it("uses Node DatabaseSync and initializes the local schema", () => {
    const opened = openSqliteDatabase(":memory:");
    client = opened.client;

    expect(client.constructor.name).toBe("DatabaseSync");
    const row = client.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'jobs'").get() as { name?: string };
    expect(row.name).toBe("jobs");
  });

  it("keeps Drizzle inserts and selects working through the proxy", async () => {
    const opened = openSqliteDatabase(":memory:");
    client = opened.client;

    await opened.db.insert(sqliteSchema.configTable).values({ watchDirectory: "C:\\Media", outputDirectory: "C:\\Output" });
    const rows = await opened.db.select().from(sqliteSchema.configTable);

    expect(rows).toHaveLength(1);
    expect(rows[0]?.watchDirectory).toBe("C:\\Media");

    const [updated] = await opened.db.update(sqliteSchema.configTable)
      .set({ outputDirectory: "C:\\Finished" })
      .where(eq(sqliteSchema.configTable.id, rows[0]!.id))
      .returning();
    expect(updated?.outputDirectory).toBe("C:\\Finished");
  });

  it("reopens an existing SQLite file without losing data", async () => {
    tempDirectory = fs.mkdtempSync(path.join(os.tmpdir(), "vx-node-sqlite-"));
    const databasePath = path.join(tempDirectory, "vx-agent.db");
    const first = openSqliteDatabase(databasePath);
    await first.db.insert(sqliteSchema.configTable).values({ watchDirectory: "D:\\Input", outputDirectory: "D:\\Output" });
    first.client.close();

    const reopened = openSqliteDatabase(databasePath);
    client = reopened.client;
    const rows = await reopened.db.select().from(sqliteSchema.configTable);

    expect(rows[0]?.outputDirectory).toBe("D:\\Output");
  });
});
