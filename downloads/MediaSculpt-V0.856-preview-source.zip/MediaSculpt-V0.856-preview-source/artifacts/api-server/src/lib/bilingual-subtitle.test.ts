import { describe, expect, it } from "vitest";
import { alignBilingualPairs, DEFAULT_BILINGUAL_STYLE, renderBilingualAss } from "./bilingual-subtitle";

describe("bilingual subtitle assembly", () => {
  const zh = [
    { startMs: 1000, endMs: 3000, text: "你好世界" },
    { startMs: 10_000, endMs: 12_000, text: "第二句" },
  ];
  const en = [
    { startMs: 1100, endMs: 3100, text: "Hello world" },
    { startMs: 40_000, endMs: 42_000, text: "Too far away" },
  ];

  it("aligns foreign blocks by nearest start time within the window", () => {
    const pairs = alignBilingualPairs(zh, en);
    expect(pairs[0]?.foreign?.text).toBe("Hello world");
    expect(pairs[1]?.foreign).toBeNull();
  });

  it("renders ASS with Chinese on top and foreign at half size by default", () => {
    const ass = renderBilingualAss(zh, en, DEFAULT_BILINGUAL_STYLE);
    expect(ass).toContain("[V4+ Styles]");
    expect(ass).toContain("Dialogue: 0,0:00:01.00,0:00:03.00,Bilingual,,0,0,0,,{\\q2}你好世界\\N{\\fs9.6}Hello world");
    // 细深灰描边无阴影：Outline=0.2、Shadow=0、深灰描边 &H00404040。
    expect(ass).toContain("Style: Bilingual,Microsoft YaHei,16,&H00FFFFFF,&H000000FF,&H00404040,&H00000000,0,0,0,0,100,100,0,0,1,0.2,0,2,10,10,12,1");
  });

  it("renders ASS with foreign on top when requested", () => {
    const ass = renderBilingualAss(zh, en, { ...DEFAULT_BILINGUAL_STYLE, layout: "foreign-top" });
    expect(ass).toContain("Dialogue: 0,0:00:01.00,0:00:03.00,Bilingual,,0,0,0,,{\\q2}Hello world\\N{\\fs9.6}你好世界");
  });

  it("renders Chinese-only line when no foreign pair exists", () => {
    const ass = renderBilingualAss([zh[1]!], [], DEFAULT_BILINGUAL_STYLE);
    expect(ass).toContain("Dialogue: 0,0:00:10.00,0:00:12.00,Bilingual,,0,0,0,,{\\q2}第二句");
  });

  it("flattens multi-line source text into a single line per language (no artificial space in Chinese)", () => {
    const multiLine = [
      { startMs: 1000, endMs: 3000, text: "第一行\n第二行" },
    ];
    const foreignMulti = [
      { startMs: 1100, endMs: 3100, text: "first line\nsecond line" },
    ];
    const ass = renderBilingualAss(multiLine, foreignMulti, DEFAULT_BILINGUAL_STYLE);
    expect(ass).toContain("Dialogue: 0,0:00:01.00,0:00:03.00,Bilingual,,0,0,0,,{\\q2}第一行第二行\\N{\\fs9.6}first line second line");
    expect(ass).not.toContain("\\N第一行");
    expect(ass).not.toContain("第一行 第二行");
  });

  it("never emits NaN timestamps for malformed time values", () => {
    const ass = renderBilingualAss([{ startMs: Number.NaN, endMs: Number.NaN, text: "损坏时间" }], [], DEFAULT_BILINGUAL_STYLE);
    expect(ass).toContain("Dialogue: 0,0:00:00.00,0:00:00.00");
    expect(ass).not.toContain("NaN");
  });

  it("applies custom style settings (layout, outline, shadow, colors, font sizes)", () => {
    const ass = renderBilingualAss(zh, en, {
      layout: "foreign-top",
      outlineWidth: 1,
      shadowWidth: 0.5,
      outlineColor: "&H00FFFFFF",
      fontSizeTop: 20,
      fontSizeBottom: 12,
    });
    expect(ass).toContain("Style: Bilingual,Microsoft YaHei,20,&H00FFFFFF,&H000000FF,&H00FFFFFF,&H00000000,0,0,0,0,100,100,0,0,1,1,0.5,2,10,10,12,1");
    expect(ass).toContain("Dialogue: 0,0:00:01.00,0:00:03.00,Bilingual,,0,0,0,,{\\q2}Hello world\\N{\\fs12}你好世界");
  });

  it("strips SRT/ASS inline tags like <i> from subtitle text", () => {
    const taggedZh = [{ startMs: 1000, endMs: 3000, text: "<i>在《基督教历史》第五集中，</i>这是正文" }];
    const taggedEn = [{ startMs: 1100, endMs: 3100, text: "<b>In episode five</b> of Churches" }];
    const ass = renderBilingualAss(taggedZh, taggedEn, DEFAULT_BILINGUAL_STYLE);
    expect(ass).toContain("在《基督教历史》第五集中，这是正文");
    expect(ass).toContain("In episode five of Churches");
    expect(ass).not.toContain("<i>");
    expect(ass).not.toContain("<b>");
  });
});
