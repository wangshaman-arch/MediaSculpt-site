import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import {
  enPack,
  projectRoot,
  readProjectFile,
  zhPack,
} from "./windows-contract-helpers";

describe("Windows contract", () => {
  it("keeps file browsing collapsed until the explicit source picker action is clicked", () => {
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");

    expect(scan).toContain('data-testid="workbench-source-entry"');
    expect(scan).toContain('data-testid="source-entry-toggle"');
    expect(scan + zhPack()).toContain("浏览来源");
    expect(scan + zhPack()).toContain("展开列表");
    expect(scan).toContain("uiText.expandList");
    expect(scan).toContain("uiText.collapseList");
    expect(scan).not.toContain(
      'onClick={() => { setTab("browse"); setShowBrowseDetails(true); }}',
    );
    expect(scan).not.toContain("Remux 提取（蓝光 / DVD）");
    expect(scan).not.toContain("准专业");
    expect(scan).toContain("browseDetailsOpen");
    expect(scan + zhPack()).toContain("展开浏览");
    expect(scan).toContain("VX_AGENT_LAST_BROWSE_PATH");
    expect(scan).toContain("networkDetailsOpen");
    expect(scan).toContain("rememberBrowsePath");
  });

  it("uses a top workspace switcher and avoids nested page scrollbars", () => {
    const app = readProjectFile("artifacts/video-agent/src/App.tsx");
    const dashboard = readProjectFile(
      "artifacts/video-agent/src/pages/Dashboard.tsx",
    );
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    const jobs = readProjectFile("artifacts/video-agent/src/pages/Jobs.tsx");
    const settings = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );

    expect(app).toContain("topWorkspaceItems");
    expect(app).toContain('data-testid="top-workspace-switcher"');
    expect(app).not.toContain('testId: "workspace-/workflow"');
    expect(scan).toContain("Brain");
    expect(app).toContain('testId: "workspace-/workbench"');
    expect(app).toContain("workspaceIconClass");
    expect(app).toContain("h-11 w-11");
    expect(app).toContain("text-[15px]");
    expect(app).toContain("flex flex-wrap items-stretch gap-3");
    expect(app).toContain("processHighPriority");
    expect(app).toContain("shutdownAfterComplete");
    expect(app).toContain('testId: "workspace-/settings"');
    expect(app).toContain("Settings2");
    expect(app).not.toContain('data-testid="topbar-settings"');
    expect(app).not.toContain("<Sidebar />");
    expect(app).not.toContain("function Sidebar()");
    expect(app).not.toContain("w-24 flex-shrink-0");
    expect(dashboard).toContain('data-testid="dashboard-page"');
    expect(dashboard).not.toContain(
      '<h2 className="text-2xl font-bold tracking-tight">总览</h2>',
    );
    expect(scan).toContain('data-testid="workbench-page"');
    expect(scan).not.toContain(
      '<h2 className="text-2xl font-bold tracking-tight">{uiText.title}</h2>',
    );
    expect(jobs).toContain('data-testid="jobs-page"');
    expect(jobs).not.toContain(
      '<h2 className="text-2xl font-bold tracking-tight">任务队列</h2>',
    );
    expect(settings).toContain('data-testid="settings-page"');
    expect(settings).toContain('data-testid="settings-section-strip"');
    expect(settings).not.toContain(
      "text-2xl font-bold tracking-tight flex items-center gap-2",
    );
    expect(settings).not.toContain("max-w-4xl mx-auto pb-16");
    expect(app).not.toContain('{ href: "/settings", label: copy.settings');
    expect(app).not.toContain("w-64 flex-shrink-0");
  });

  it("opens settings to an icon overview and keeps page scrollbars wheel-synced", () => {
    const app = readProjectFile("artifacts/video-agent/src/App.tsx");
    const settings = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );
    const css = readProjectFile("artifacts/video-agent/src/index.css");

    expect(app).toContain(
      "app-scroll-shell min-h-0 flex-1 p-3 sm:p-4 lg:p-6 xl:p-8",
    );
    expect(app).toContain(
      'isWorkbench ? "overflow-hidden" : "overflow-y-auto"',
    );
    expect(app).not.toContain("app-scroll-shell scrollbar-none");
    expect(css).toContain("html, body, #root");
    expect(css).toContain("overflow: hidden");
    expect(settings).toContain('export type SettingsSection = "overview"');
    expect(settings).toContain("settingsOverviewItems");
    expect(settings).toContain('data-testid="settings-overview-grid"');
    expect(settings).toContain('section === "overview"');
    expect(settings).toContain("openSettingsSection(item)");
    expect(settings).toContain("requestSectionChange(item.id)");
    expect(settings).not.toContain('data-testid="settings-back-overview"');
    expect(settings).toContain('data-testid="settings-section-strip"');
    expect(settings).toContain('requestSectionChange("overview")');
    expect(settings).toContain("settingsSectionHash(next)");
  });

  it("keeps selected disc title metadata isolated and uses it for compression statistics", () => {
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    const discDialog = readProjectFile(
      "artifacts/video-agent/src/features/workbench/DiscAnalyzeDialog.tsx",
    );
    const handbrakeArgs = readProjectFile(
      "artifacts/api-server/src/lib/handbrake-compression-args.ts",
    );
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");

    expect(scan).toContain("titleSizeBytes: track.sizeBytes ?? null");
    expect(scan).toContain("durationSeconds: track.durationSeconds ?? null");
    expect(scan).toContain("streamSelections.get(activeTrackIdx)");
    expect(discDialog).toContain("defaultStreamSelection");
    expect(discDialog).toContain("track?.streams");
    expect(scan).toContain("chapterSelections.get(activeTrackIdx)");
    expect(discDialog).toContain("defaultChapterSelection");
    expect(discDialog).toContain("track?.chapters");
    expect(handbrakeArgs).toContain("titleSizeBytes?: number | null");
    expect(handbrakeArgs).toContain("durationSeconds?: number | null");
    expect(jobsRoute).toContain("selectedTitleSizeBytes");
    expect(jobsRoute).toContain("selectedTitleDurationSeconds");
    expect(jobsRoute.indexOf("selectedTitleSizeBytes")).toBeLessThan(
      jobsRoute.indexOf("dvdTitle?.sizeBytes"),
    );
  });

  it("requires the immutable DVD title selection instead of falling back to a re-resolved title", () => {
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");
    expect(jobsRoute).toContain(
      "taskSnapshot?.toolSelections.handbrakeTitleNumber",
    );
    expect(jobsRoute).toContain("selectedTitleId");
    expect(jobsRoute + zhPack()).toContain("HandBrake DVD 标题");
    expect(jobsRoute).not.toContain(
      'if (!temporaryRemuxPath && !handBrakeSelectionArgs.includes("--title") && job.mediaType === "dvd" && dvdTitle?.titleNumber',
    );
  });

  it("freezes DVD compression output names and does not use disc-total bytes as a title size", () => {
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");
    expect(jobsRoute).toContain("frozenCompressionFileName");
    expect(jobsRoute).toContain("taskSnapshot.output.fileName");
    expect(jobsRoute).toContain('job.mediaType === "dvd" && taskSnapshot');
    expect(jobsRoute).toContain("fileSizeBefore: null");
    expect(jobsRoute).toContain("selectedTitleDurationSeconds");
  });

  it("shares compression presets between settings and task details instead of duplicating hardcoded options", () => {
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const settings = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );
    const sharedPresets = readProjectFile(
      "artifacts/video-agent/src/lib/compression-presets.ts",
    );

    expect(sharedPresets).toContain("DEFAULT_COMPRESSION_PRESETS");
    expect(sharedPresets).toContain("loadCompressionPresets");
    expect(sharedPresets).toContain("PRESET_CHANGED_EVENT");
    expect(settings).toContain("loadCompressionPresets");
    expect(detail).toContain("loadCompressionPresets");
    expect(detail).toContain("compressionPresets");
    expect(detail).toContain("selectedPresetLabel");
    expect(detail).toContain("editableJobPreset");
    expect(detail).toContain('data-testid="job-detail-compression-preset"');
    expect(detail).toContain("onCompressionPresetSelect");
    expect(detail).not.toContain("DETAIL_COMPRESSION_PRESETS");
    expect(detail).not.toContain("H.264/H.265 · RF 18-20");
  });

  it("uses a compact queue-first dashboard and compact job details", () => {
    const dashboard = readProjectFile(
      "artifacts/video-agent/src/pages/Dashboard.tsx",
    );
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );

    expect(dashboard).toContain('data-testid="compact-stats-strip"');
    expect(dashboard + zhPack()).toContain("节省");
    expect(dashboard + zhPack()).toContain("运行");
    expect(dashboard + zhPack()).toContain("等待");
    expect(dashboard + zhPack()).toContain("完成");
    expect(dashboard).not.toContain('data-testid="home-left-workbench"');
    expect(dashboard).not.toContain('data-testid="home-right-settings"');
    expect(dashboard).not.toContain("进入工作台");
    expect(dashboard).not.toContain("本地工具");
    expect(detail).toContain("fileDetailsOpen");
    expect(detail).toContain("jobLogsOpen");
    expect(detail).toContain("setJobLogsOpen");
    expect(detail + zhPack()).toContain("处理日志");
    expect(detail.indexOf("statusTimeline")).toBeLessThan(
      detail.indexOf("logsAndFiles"),
    );
    expect(detail).toContain("assistantOpen");
    expect(detail).not.toContain("border-blue-500/30 bg-blue-500/5");
  });

  it("shows disc title-specific stream summaries and keeps toggles scoped to the active title", () => {
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    const titleRow = readProjectFile(
      "artifacts/video-agent/src/features/workbench/DiscTitleRow.tsx",
    );
    const discDialog = readProjectFile(
      "artifacts/video-agent/src/features/workbench/DiscAnalyzeDialog.tsx",
    );

    expect(scan).toContain("trackLanguageSummary");
    expect(titleRow).not.toContain("audioSummary");
    expect(titleRow).not.toContain("subtitleSummary");
    expect(discDialog).toContain("title-level-stream-controls");
    expect(discDialog).toContain("title-level-chapter-controls");
    expect(scan).toContain("const base =");
    expect(scan).toContain("prev.get(activeTrackIdx)");
    expect(discDialog).toContain("defaultStreamSelection");
    expect(discDialog).toContain("defaultChapterSelection");
    expect(discDialog).toContain("track?.streams");
    expect(discDialog).toContain("track?.chapters");
    expect(discDialog).toContain("setSelectedTrackIndices(new Set());");
    expect(scan).not.toContain("if (data && !initDone)");
  });

  it("keeps disc stream and chapter choices inside the selection summary", () => {
    const dialog = readProjectFile(
      "artifacts/video-agent/src/features/workbench/DiscAnalyzeDialog.tsx",
    );

    expect(dialog).toContain("renderExpandedTitleControls");
    expect(dialog).toContain("selectedTrack");
    expect(dialog).toContain("title-level-stream-controls");
    expect(dialog).toContain("title-level-chapter-controls");
    expect(dialog).toContain(
      "onPointerDown={(event) => event.stopPropagation()}",
    );
    expect(dialog).toContain("onClick={(event) => event.stopPropagation()}");
    expect(dialog).not.toContain("stream.frameRate ? ` · ${stream.frameRate}`");
    expect(dialog).not.toContain("badges.push(`${stream.frameRate}fps`)");
    expect(dialog).not.toContain(
      "{selectedTrack && selectedTrack.streams.length > 0 && (",
    );
    const summaryIndex = dialog.indexOf('t("scan.selectionSummary")');
    const controlsIndex = dialog.lastIndexOf("{renderExpandedTitleControls()}");
    const titleListIndex = dialog.indexOf("{/* Track selector */}");
    expect(summaryIndex).toBeGreaterThanOrEqual(0);
    expect(controlsIndex).toBeGreaterThan(summaryIndex);
    expect(dialog.slice(titleListIndex)).not.toContain(
      "renderExpandedTitleControls()",
    );
  });

  it("keeps job runtime failures in the single upload diagnostics log", () => {
    const jobRuntimeLog = readProjectFile(
      "artifacts/api-server/src/lib/job-runtime-log.ts",
    );
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");

    expect(jobRuntimeLog).toContain("appendJobRuntimeLog");
    expect(jobRuntimeLog).toContain("diagnosticsLogPath");
    expect(jobRuntimeLog).toContain("===== JOB");
    expect(jobsRoute).toContain("appendJobRuntimeLog");
    expect(jobsRoute + zhPack()).toContain("任务失败");
  });

  it("uses one responsive source browser with media objects and stale-scan protection", () => {
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    expect(scan).toContain("SourceBrowserPanel");
    expect(scan).toContain('data-testid="source-browser-panel"');
    expect(scan).toContain("scanRequestIdRef");
    expect(scan + zhPack()).toContain("当前目录中的可处理媒体对象");
    expect(scan + zhPack()).toContain("拖放");
    expect(scan).not.toContain("Remux 来源");
  });

  it("keeps preview controls inside the video and exposes a responsive details drawer", () => {
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const player = readProjectFile(
      "artifacts/video-agent/src/components/PreviewPlayer.tsx",
    );
    expect(player).toContain("previewControlsVisible");
    expect(player).toContain("previewControlsTimerRef");
    expect(player).toContain("updatePreviewControlsForPointer");
    expect(player).toContain("previewStageRef");
    expect(player).toContain("rect.height * 0.8");
    expect(player).toContain('data-testid="preview-control-overlay"');
    expect(detail).toContain('data-testid="job-details-drawer"');
    expect(detail).toContain("detailsPinned");
    expect(player).toContain("object-contain");
    expect(detail).not.toContain("aspect-video max-h-[52vh]");
  });

  it("keeps disc title selection keyed by stable title IDs and preview failures non-blocking", () => {
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");
    expect(scan).toContain("titleId");
    expect(scan).toContain("previewByTitleId");
    expect(scan).toContain("previewGeneration");
    expect(scan + zhPack()).toContain("预览不可用，但不影响任务创建");
    expect(scan).toContain("overflow-y-auto");
    expect(scan + zhPack()).toContain("创建");
    expect(jobsRoute).toContain('router.get("/disc/title-preview"');
    expect(jobsRoute).toContain("discTitlePreviewCache");
    expect(jobsRoute + zhPack()).toContain("预览不可用，但不影响任务创建");
  });

  it("does not make DVD title preview reopen the raw VIDEO_TS path with FFmpeg", () => {
    const jobsPreview = readProjectFile(
      "artifacts/api-server/src/routes/jobs-preview.ts",
    );
    const previewRoute = jobsPreview.slice(
      jobsPreview.indexOf('router.get("/disc/title-preview"'),
    );
    const dvdBranch = previewRoute.slice(
      0,
      previewRoute.indexOf('router.get("/jobs/:id/preview"'),
    );

    expect(dvdBranch).toContain("sourceFingerprint");
    expect(dvdBranch).toContain("titleId");
    expect(dvdBranch).not.toContain('"-i", title.sourcePath');
    expect(dvdBranch).not.toContain('"-f", "dvdvideo"');
    expect(dvdBranch + zhPack()).toContain("预览不可用，但不影响任务创建");
  });

  it("puts smart-workflow cancel and confirm actions immediately before smart analysis", () => {
    const dialog = readProjectFile(
      "artifacts/video-agent/src/features/workbench/DiscAnalyzeDialog.tsx",
    );
    const smartAction = dialog.indexOf('{t("scan.smartParse")}');
    const confirmAction = dialog.indexOf('{t("scan.confirmSelection")}');
    const footer = dialog.indexOf("{/* Footer */}");

    expect(smartAction).toBeGreaterThan(-1);
    expect(confirmAction).toBeGreaterThan(-1);
    expect(confirmAction).toBeLessThan(smartAction);
    expect(dialog.slice(footer)).not.toContain("scan.confirmSelection");
  });

  it("gives all three header actions the same size and blinks only non-smart actions before selection", () => {
    const dialog = readProjectFile(
      "artifacts/video-agent/src/features/workbench/DiscAnalyzeDialog.tsx",
    );
    const header = dialog.slice(
      dialog.indexOf("{/* Header */}"),
      dialog.indexOf("{smartNote &&"),
    );
    const smartStart = header.indexOf('{t("scan.smartParse")}');
    const smartBlock = header.slice(
      Math.max(0, smartStart - 700),
      smartStart + 80,
    );

    expect((header.match(/w-32/g) ?? []).length).toBeGreaterThanOrEqual(3);
    expect(header).toContain("selectedTrackIndices.size === 0");
    expect(header).toContain("animate-pulse");
    expect(smartBlock).not.toContain("animate-pulse");
  });

  it("keeps chapters as timing information and does not advertise chapter image preview", () => {
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    expect(scan + zhPack()).toContain("章节信息");
    expect(scan).not.toContain("章节预览与选择");
    expect(scan).not.toContain("章节预览");
    expect(scan).not.toContain("章节图片");
  });

  it("uses one outer scroll owner and a detailed selected-title summary in the disc dialog", () => {
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    expect(scan).toContain("DiscAnalyzeDialog");
    const dialog = readProjectFile(
      "artifacts/video-agent/src/features/workbench/DiscAnalyzeDialog.tsx",
    );
    // The invariant is "one outer scroll owner for the dialog body plus fixed
    // inner panels", not a total count of the utility class, which changes
    // whenever the inner layout gains a scroller.
    expect(dialog).toContain("flex min-h-0 flex-1 flex-col overflow-y-auto");
    expect(dialog).toContain("max-h-[calc(100vh-9rem)]");
    expect(dialog).not.toContain("统一预览窗口");
    expect(dialog).toContain("title-level-stream-controls");
    expect(dialog).toContain("title-level-chapter-controls");
  });

  it("keeps the workbench and job preview inside common 1080P viewport bounds", () => {
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const picker = readProjectFile(
      "artifacts/video-agent/src/components/DirectoryPicker.tsx",
    );
    expect(scan).not.toContain("打开批量扫描");
    expect(detail).toContain("minmax(0,1fr)");
    expect(detail).toContain("min-w-0");
    expect(picker).toContain("min(96vw, 680px)");
    expect(picker).toContain("max-h-[90vh]");
  });

  it("routes smart-workflow identity confirmation through the configured LLM before legacy metadata fallback", () => {
    const workflow = readProjectFile(
      "artifacts/video-agent/src/pages/Workflow.tsx",
    );
    const route = readProjectFile(
      "artifacts/api-server/src/routes/smart-workflow.ts",
    );
    expect(workflow).toContain("/api/smart-workflow/metadata");
    expect(workflow).toContain("metadataFromLlm");
    expect(route).toContain('router.post("/smart-workflow/metadata"');
    expect(route).toContain("resolveApiKey");
    expect(route).toContain("source: `llm:${endpoint.provider}`");
  });

  it("keeps directory picker actions and job preview inside the viewport", () => {
    const picker = readProjectFile(
      "artifacts/video-agent/src/components/DirectoryPicker.tsx",
    );
    const app = readProjectFile("artifacts/video-agent/src/App.tsx");
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const playerCard = readProjectFile(
      "artifacts/video-agent/src/components/PreviewPlayerCard.tsx",
    );
    const jobs = readProjectFile("artifacts/video-agent/src/pages/Jobs.tsx");
    const routes =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");
    expect(picker).toContain("max-w-[calc(100vw-2rem)]");
    expect(picker).toContain("w-full min-w-0");
    expect(app).toContain("max-w-[1680px]");
    expect(detail).toContain("minmax(16rem,22rem)");
    expect(playerCard).toContain("h-[min(58vh,calc(100vh-19rem))]");
    expect(jobs).toContain("openDesktopPath(hostPath)");
    expect(routes).toContain("args: [openTarget]");
    expect(routes).toContain('process.env.ComSpec || "cmd.exe"');
    expect(routes).toContain('"start"');
    expect(routes).not.toContain("/root,${openTarget}");
    expect(picker).toContain("box-border");
    expect(jobs).toContain("btn-open-output-path-");
  });

  it("keeps disc title preview and summary fixed while the title list owns scrolling", () => {
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    expect(scan).toContain("DiscAnalyzeDialog");
    const dialog = readProjectFile(
      "artifacts/video-agent/src/features/workbench/DiscAnalyzeDialog.tsx",
    );
    expect(dialog).toContain("max-h-[calc(100vh-9rem)]");
    // The title list keeps a fixed height so preview and summary stay put; the
    // exact pixel value is a layout choice, so assert the fixed-height contract
    // and that the scrolling region is the one carrying it.
    expect(dialog).toContain("h-[220px] max-lg:h-[120px]");
    expect(dialog).toContain("flex-col overflow-y-auto");
    expect(dialog).toContain('data-testid="title-level-stream-controls"');
    expect(dialog).toContain('data-testid="title-level-chapter-controls"');
    expect(dialog).toContain("overflow-y-auto");
    // The title list is the scroll owner: it keeps its own min height and is
    // exempt from flex growth so the surrounding panels stay fixed.
    expect(dialog).toContain("min-h-[12rem] flex-none overflow-y-auto");
    expect(dialog).not.toContain("fixed inset-0 bg-black/60");
  });

  it("keeps the Remux workbench entry available while hiding non-Remux-only hints", () => {
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    expect(scan).toContain("WORKBENCH_TABS.map");
    expect(scan).not.toContain("availableProcessingModes");
    expect(scan).toContain('processingMode === "remux"');
    expect(scan).toContain('selectedTrack.verificationStatus === "verified"');
    expect(scan).toContain("key={analyzeDiscPath}");
    expect(scan).toContain('data-testid="workbench-mode-tabs"');
  });

  it("places LLM movie confirmation beside the analysis and keeps the Douban title rule explicit", () => {
    const workflow = readProjectFile(
      "artifacts/video-agent/src/pages/Workflow.tsx",
    );
    const smartWorkflowRoute = readProjectFile(
      "artifacts/api-server/src/routes/smart-workflow.ts",
    );
    expect(workflow).toContain(
      "md:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]",
    );
    expect(workflow + zhPack()).toContain("跳过压缩");
    expect(smartWorkflowRoute + zhPack()).toContain("豆瓣");
  });

  it("keeps settings directory fields shrinkable at every viewport width", () => {
    const settings = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );
    const picker = readProjectFile(
      "artifacts/video-agent/src/components/DirectoryPicker.tsx",
    );
    expect(settings).toContain('data-testid="settings-directories-form"');
    expect(settings).toContain("min-w-0");
    expect(settings).toContain("overflow-hidden");
    expect(picker).toContain("max-w-full");
    expect(picker).toContain(
      'DialogFooter className="w-full min-w-0 flex-wrap',
    );
    expect(picker).toContain('<span className="min-w-0 truncate">');
  });

  it("passes technical media context to LLM title confirmation", () => {
    const workflow = readProjectFile(
      "artifacts/video-agent/src/pages/Workflow.tsx",
    );
    const route = readProjectFile(
      "artifacts/api-server/src/routes/smart-workflow.ts",
    );
    expect(workflow).toContain("media: nextMedia");
    expect(route).toContain("const mediaContext");
    expect(route).toContain("durationSeconds");
    expect(route).toContain("chapterCount");
    expect(route).toContain("technicalAssessment");
    expect(route).toContain("recommendedAction");
    expect(workflow + zhPack()).toContain("LLM 影片确认建议");
  });
});
