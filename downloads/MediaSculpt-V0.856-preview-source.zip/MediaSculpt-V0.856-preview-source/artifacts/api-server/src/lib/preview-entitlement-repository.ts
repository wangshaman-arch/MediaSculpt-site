import { randomUUID } from "node:crypto";
import type { DatabaseSync } from "node:sqlite";
import { sqliteClient } from "@workspace/db";
import {
  DEFAULT_PREVIEW_POLICY,
  evaluatePreviewStatus,
  type Edition,
  type PreviewEntitlementState,
  type PreviewPolicy,
  type PreviewStatus,
} from "./preview-entitlement";

export type PreviewRepositoryClient = Pick<DatabaseSync, "exec" | "prepare">;

export type PreviewEntitlementRepositoryOptions = {
  client?: PreviewRepositoryClient | null;
  edition?: Edition;
  policy?: PreviewPolicy;
  installationIdFactory?: () => string;
};

export type ChargeTaskInput = {
  jobId: number;
  taskKind: string;
  chargedAt: Date;
};

export type ChargeTaskResult = {
  charged: boolean;
  successfulTaskCount: number;
};

type EntitlementRow = {
  id: number;
  edition: Edition;
  installation_id: string;
  first_started_at: number;
  last_seen_at: number;
  expires_at: number;
  task_limit: number;
  successful_task_count: number;
  ai_call_count: number;
};

function toDate(value: number): Date {
  return new Date(Number(value));
}

function toState(row: EntitlementRow): PreviewEntitlementState {
  return {
    edition: row.edition === "preview" ? "preview" : "development",
    installationId: row.installation_id,
    firstStartedAt: toDate(row.first_started_at),
    lastSeenAt: toDate(row.last_seen_at),
    expiresAt: toDate(row.expires_at),
    taskLimit: Number(row.task_limit),
    successfulTaskCount: Number(row.successful_task_count),
    aiCallCount: Number(row.ai_call_count),
  };
}

export function resolveRuntimeEdition(value = process.env.MEDIASCULPT_EDITION): Edition {
  return value === "preview" ? "preview" : "development";
}

export function createPreviewEntitlementRepository(options: PreviewEntitlementRepositoryOptions = {}) {
  const client = options.client ?? sqliteClient;
  if (!client) throw new Error("预览配额需要本地 SQLite 数据库");
  const policy = options.policy ?? DEFAULT_PREVIEW_POLICY;
  const edition = options.edition ?? resolveRuntimeEdition();
  const installationIdFactory = options.installationIdFactory ?? randomUUID;

  const getRow = (): EntitlementRow | null => {
    const row = (client.prepare("SELECT * FROM preview_entitlements WHERE id = 1").get() as EntitlementRow | undefined) ?? null;
    return row;
  };

  const ensureRow = (now: Date): EntitlementRow => {
    const existing = getRow();
    if (existing) {
      // The edition is a build/runtime concern. A source-development run must
      // not permanently unlock a later preview installation on the same machine.
      if (existing.edition !== edition || Number(existing.task_limit) !== policy.taskLimit) {
        client.prepare("UPDATE preview_entitlements SET edition = ?, task_limit = ? WHERE id = 1").run(edition, policy.taskLimit);
        return getRow()!;
      }
      return existing;
    }
    const state = {
      edition,
      installationId: installationIdFactory(),
      firstStartedAt: now.getTime(),
      lastSeenAt: now.getTime(),
      expiresAt: now.getTime() + policy.trialDays * 24 * 60 * 60 * 1000,
      taskLimit: policy.taskLimit,
      successfulTaskCount: 0,
      aiCallCount: 0,
    };
    client.prepare(`
      INSERT INTO preview_entitlements
        (id, edition, installation_id, first_started_at, last_seen_at, expires_at, task_limit, successful_task_count, ai_call_count)
      VALUES (1, ?, ?, ?, ?, ?, ?, 0, 0)
    `).run(state.edition, state.installationId, state.firstStartedAt, state.lastSeenAt, state.expiresAt, state.taskLimit);
    return getRow()!;
  };

  const touch = (row: EntitlementRow, now: Date): EntitlementRow => {
    if (now.getTime() <= Number(row.last_seen_at)) return row;
    client.prepare("UPDATE preview_entitlements SET last_seen_at = ? WHERE id = 1").run(now.getTime());
    return getRow()!;
  };

  return {
    async getOrCreate(now: Date): Promise<PreviewEntitlementState> {
      return toState(touch(ensureRow(now), now));
    },

    async getStatus(now: Date): Promise<PreviewStatus> {
      const state = toState(touch(ensureRow(now), now));
      return evaluatePreviewStatus(state, now, policy);
    },

    async chargeTaskOnce(input: ChargeTaskInput): Promise<ChargeTaskResult> {
      const existingState = await this.getOrCreate(input.chargedAt);
      client.exec("BEGIN IMMEDIATE");
      try {
        const current = getRow()!;
        const usage = client.prepare("SELECT id FROM preview_task_usage WHERE job_id = ?").get(input.jobId);
        if (usage) {
          client.exec("COMMIT");
          return { charged: false, successfulTaskCount: Number(current.successful_task_count) };
        }
        if (existingState.edition === "preview" && Number(current.successful_task_count) >= policy.taskLimit) {
          client.exec("COMMIT");
          return { charged: false, successfulTaskCount: Number(current.successful_task_count) };
        }
        const result = (client.prepare("INSERT INTO preview_task_usage (job_id, task_kind, charged_at) VALUES (?, ?, ?)").run(input.jobId, input.taskKind, input.chargedAt.getTime()) as { changes?: number | bigint });
        if (Number(result.changes ?? 0) === 1) {
          client.prepare("UPDATE preview_entitlements SET successful_task_count = successful_task_count + 1 WHERE id = 1").run();
        }
        const updated = getRow()!;
        client.exec("COMMIT");
        return { charged: Number(result.changes ?? 0) === 1, successfulTaskCount: Number(updated.successful_task_count) };
      } catch (error) {
        try { client.exec("ROLLBACK"); } catch { /* preserve the original database error */ }
        throw error;
      }
    },

    async recordAiCall(now: Date): Promise<number> {
      ensureRow(now);
      client.prepare("UPDATE preview_entitlements SET ai_call_count = ai_call_count + 1, last_seen_at = MAX(last_seen_at, ?) WHERE id = 1").run(now.getTime());
      const row = getRow()!;
      return Number(row.ai_call_count);
    },
  };
}

export type PreviewEntitlementRepository = ReturnType<typeof createPreviewEntitlementRepository>;
