import { describe, expect, it, vi } from "vitest";
import { buildDvdShortReadArgs, buildDvdTimestampProbeArgs, type ExternalToolRunner } from "./dvd-remux";
import { validateDvdTitleRead } from "./dvd-title-validation";

const probe = JSON.stringify({
  streams: [{ index: 0, codec_type: "video", codec_name: "mpeg2video", width: 720, height: 576 }],
  chapters: [{ id: 0, start_time: "0", end_time: "600" }],
  format: { duration: "600" },
});
const timestampProbe = JSON.stringify({ packets: [{ pts_time: "0", dts_time: "0" }, { pts_time: "0.04", dts_time: "0.04" }] });

function result(request: Parameters<ExternalToolRunner>[0], stdout: string, exitCode = 0, stderr = "") {
  return { tool: request.tool, executable: request.executable, args: request.args, stdout, stderr, exitCode, durationMs: 1, failureReason: exitCode === 0 ? null : "tool failed" };
}

function successfulRunner() {
  return vi.fn(async (request) => request.tool === "ffprobe"
    ? result(request, request.args.includes("-show_packets") ? timestampProbe : probe)
    : result(request, "frame=12\nout_time_ms=4000000\nprogress=end\n")) as ExternalToolRunner & ReturnType<typeof vi.fn>;
}

describe("validateDvdTitleRead", () => {
  it("requires three non-empty short reads after the exact probe succeeds", async () => {
    const run = successfulRunner();
    const evidence = await validateDvdTitleRead({
      sourcePath: "D:\\DVD\\VIDEO_TS",
      titleNumber: 4,
      handbrakeDurationSeconds: 600,
      handbrakeChapterCount: 1,
      ffprobeExecutable: "ffprobe.exe",
      ffmpegExecutable: "ffmpeg.exe",
    }, run);

    expect(evidence).toMatchObject({ status: "passed", videoFrameCount: 36, timestampStatus: "monotonic" });
    expect(run).toHaveBeenCalledTimes(5);
    expect(run.mock.calls.slice(1).map(([request]) => request.tool)).toEqual(["ffmpeg", "ffmpeg", "ffmpeg", "ffprobe"]);
  });

  it("rejects a title when the middle window exits successfully but encodes no frames", async () => {
    let ffmpegCalls = 0;
    const run = vi.fn(async (request) => {
      if (request.tool === "ffprobe") return result(request, request.args.includes("-show_packets") ? timestampProbe : probe);
      ffmpegCalls += 1;
      return ffmpegCalls === 2 ? result(request, "frame=0\nout_time_ms=0\nprogress=end\n") : result(request, "frame=12\nout_time_ms=4000000\nprogress=end\n");
    }) as ExternalToolRunner & ReturnType<typeof vi.fn>;

    const evidence = await validateDvdTitleRead({
      sourcePath: "D:\\DVD\\VIDEO_TS", titleNumber: 4, handbrakeDurationSeconds: 600, handbrakeChapterCount: 1,
      ffprobeExecutable: "ffprobe.exe", ffmpegExecutable: "ffmpeg.exe",
    }, run);

    expect(evidence.status).toBe("failed");
    expect(evidence.failureReason).toContain("中段");
  });

  it("rejects a title when the exact probe has no video stream", async () => {
    const run = vi.fn(async (request) => result(request, JSON.stringify({ streams: [], chapters: [], format: { duration: "600" } }))) as ExternalToolRunner & ReturnType<typeof vi.fn>;
    const evidence = await validateDvdTitleRead({
      sourcePath: "D:\\DVD\\VIDEO_TS", titleNumber: 4, handbrakeDurationSeconds: 600, handbrakeChapterCount: 1,
      ffprobeExecutable: "ffprobe.exe", ffmpegExecutable: "ffmpeg.exe",
    }, run);
    expect(evidence.status).toBe("failed");
    expect(evidence.failureReason).toContain("视频流");
    expect(run).toHaveBeenCalledTimes(1);
  });

  it("accepts normal MPEG-2 frame reordering but rejects a large timestamp reset", async () => {
    const run = vi.fn(async (request) => {
      if (request.tool !== "ffprobe") return result(request, "frame=12\nout_time_ms=4000000\nprogress=end\n");
      if (!request.args.includes("-show_packets")) return result(request, probe);
      return result(request, JSON.stringify({ packets: [{ pts_time: "1.000", dts_time: "1.000" }, { pts_time: "0.934", dts_time: "0.934" }, { pts_time: "0.968", dts_time: "0.968" }] }));
    }) as ExternalToolRunner & ReturnType<typeof vi.fn>;
    const evidence = await validateDvdTitleRead({
      sourcePath: "D:\\DVD\\VIDEO_TS", titleNumber: 4, handbrakeDurationSeconds: 600, handbrakeChapterCount: 1,
      ffprobeExecutable: "ffprobe.exe", ffmpegExecutable: "ffmpeg.exe",
    }, run);
    expect(evidence.status).toBe("passed");
    expect(evidence.warnings.join(" ")).toContain("正常帧重排");

    const brokenRun = vi.fn(async (request) => {
      if (request.tool !== "ffprobe") return result(request, "frame=12\nout_time_ms=4000000\nprogress=end\n");
      if (!request.args.includes("-show_packets")) return result(request, probe);
      return result(request, JSON.stringify({ packets: [{ pts_time: "10", dts_time: "10" }, { pts_time: "1", dts_time: "1" }] }));
    }) as ExternalToolRunner & ReturnType<typeof vi.fn>;
    const broken = await validateDvdTitleRead({
      sourcePath: "D:\\DVD\\VIDEO_TS", titleNumber: 4, handbrakeDurationSeconds: 600, handbrakeChapterCount: 1,
      ffprobeExecutable: "ffprobe.exe", ffmpegExecutable: "ffmpeg.exe",
    }, brokenRun);
    expect(broken.status).toBe("failed");
  });

  it("uses an explicit bounded dvdvideo input and null output", () => {
    expect(buildDvdShortReadArgs({ sourcePath: "D:\\影片 甲\\VIDEO_TS", titleNumber: 7, startSeconds: 123.4 })).toEqual([
      "-hide_banner", "-f", "dvdvideo", "-title", "7", "-ss", "123.400", "-i", "D:\\影片 甲\\VIDEO_TS",
      "-map", "0:v:0", "-t", "4.000", "-an", "-progress", "pipe:1", "-f", "null", "-",
    ]);
    expect(buildDvdTimestampProbeArgs({ sourcePath: "D:\\DVD\\VIDEO_TS", titleNumber: 7 })).toContain("-show_packets");
  });
});
