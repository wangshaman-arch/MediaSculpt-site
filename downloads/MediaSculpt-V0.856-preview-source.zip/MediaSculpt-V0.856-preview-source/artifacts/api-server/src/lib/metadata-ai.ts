import type { MetadataResult } from "./metadata";

/**
 * Optional AI metadata enrichment.
 *
 * This is deliberately the *last* tier and is off unless explicitly enabled.
 * An LLM can fill gaps that keyless sources cannot reach (ratings, genres,
 * director for niche or non-Western titles) but it can also invent them, so the
 * module enforces three rules that keep "better than nothing" from becoming
 * "wrong":
 *
 *   1. Identity is never touched. Title, year and IMDb/TMDb/Douban ids only ever
 *      come from a verifiable provider — an LLM must not relabel a work.
 *   2. Populated fields are never replaced. AI only fills what is empty.
 *   3. Every AI-supplied field is recorded in `sources` as `ai`, so a user can
 *      see which values are not independently verifiable.
 */

/** Fields an LLM is allowed to fill. Identity fields are intentionally absent. */
export const AI_FILLABLE_FIELDS = ["director", "cast", "genres", "overview", "runtimeMinutes"] as const;

export type AiFillableField = (typeof AI_FILLABLE_FIELDS)[number];

/**
 * Values a model returns to mean "I could not fill this". Accepting them would
 * put a literal 未知 in the field, which reads as data rather than as absence.
 */
const PLACEHOLDER_VALUES = new RegExp(
  "^(?:"
  + "unknown|n/?a|none|null|nil|undefined|not\\s+(?:available|known|applicable)"
  + "|未知|不详|不明|暂无|无|待定|无法确定|无法确认"
  + "|-{1,3}|\\?+|—+"
  + ")$",
  "i",
);

export type AiEnrichmentSuggestion = Partial<Record<AiFillableField, string | number>>;

export type AiEnrichmentOutcome = {
  /** The result to use; identical to the input when nothing was filled. */
  result: MetadataResult;
  /** Fields that were actually filled from the AI response. */
  filled: AiFillableField[];
  /** True when the AI contributed at least one field. */
  used: boolean;
  /** Why nothing was filled, for logging and the UI. */
  skippedReason?: "disabled" | "nothing-missing" | "empty-response";
};

/**
 * Decide whether an AI call is worth making at all. Avoids spending a request on
 * a record that has nothing missing.
 */
export function missingEnrichableFields(result: MetadataResult | null): AiFillableField[] {
  if (!result) return [];
  return AI_FILLABLE_FIELDS.filter((field) => {
    const value = result[field];
    if (typeof value === "number") return !Number.isFinite(value) || value <= 0;
    return value === undefined || value === null || String(value).trim() === "";
  });
}

/** Normalise an LLM reply into the fillable shape, dropping junk values. */
export function normalizeSuggestion(raw: unknown): AiEnrichmentSuggestion {
  if (!raw || typeof raw !== "object") return {};
  const source = raw as Record<string, unknown>;
  const out: AiEnrichmentSuggestion = {};
  for (const field of AI_FILLABLE_FIELDS) {
    const value = source[field];
    if (value === undefined || value === null) continue;
    if (field === "runtimeMinutes") {
      const minutes = Number(value);
      if (Number.isFinite(minutes) && minutes > 0) out.runtimeMinutes = Math.round(minutes);
      continue;
    }
    const text = String(value).trim();
    // Guard against the model answering a placeholder instead of omitting the
    // key. Both languages must be covered: a Chinese-language prompt routinely
    // comes back with 未知 / 不详 / 暂无, and writing that literal into the field
    // is worse than leaving it empty.
    if (!text || PLACEHOLDER_VALUES.test(text)) continue;
    out[field] = text;
  }
  return out;
}

/**
 * Merge an AI suggestion into a resolved record.
 *
 * `enabled` must be true for anything to be applied — the safe default is off.
 */
export function applyAiEnrichment(params: {
  result: MetadataResult | null;
  suggestion: AiEnrichmentSuggestion | null;
  enabled: boolean;
  /** Field -> provider id accumulated so far; AI entries are added to a copy. */
  sources?: Record<string, string> | null;
}): AiEnrichmentOutcome & { sources: Record<string, string> | null } {
  const base = params.result;
  const existingSources = params.sources ?? null;
  if (!base) {
    return { result: { title: "", mediaType: "movie", source: "imdb" }, filled: [], used: false, skippedReason: "disabled", sources: existingSources };
  }
  if (!params.enabled) {
    return { result: base, filled: [], used: false, skippedReason: "disabled", sources: existingSources };
  }
  const missing = missingEnrichableFields(base);
  if (missing.length === 0) {
    return { result: base, filled: [], used: false, skippedReason: "nothing-missing", sources: existingSources };
  }
  // Normalise before applying: a model that answers "未知" / "N/A" instead of
  // omitting the key must not have that literal written into a field.
  const suggestion = normalizeSuggestion(params.suggestion);
  if (Object.keys(suggestion).length === 0) {
    return { result: base, filled: [], used: false, skippedReason: "empty-response", sources: existingSources };
  }

  const next: MetadataResult = { ...base };
  const filled: AiFillableField[] = [];
  const sources: Record<string, string> = { ...(existingSources ?? {}) };
  for (const field of missing) {
    const value = suggestion[field];
    if (value === undefined || value === null || String(value).trim() === "") continue;
    // Rule 2: only ever write into a still-empty field.
    (next as unknown as Record<string, unknown>)[field] = value;
    // Rule 3: mark it so the value is never mistaken for a verified one.
    sources[field] = "ai";
    filled.push(field);
  }
  if (filled.length === 0) {
    return { result: base, filled: [], used: false, skippedReason: "empty-response", sources: existingSources };
  }
  return { result: next, filled, used: true, sources };
}

/**
 * Build the prompt for the enrichment call. Kept here so the identity rule is
 * stated to the model explicitly rather than relying on its judgement.
 */
export function buildAiEnrichmentPrompt(params: {
  title: string;
  titleEn?: string | null;
  year?: number | null;
  imdbId?: string | null;
  missing: AiFillableField[];
}): string {
  const known = [
    `片名：${params.title}`,
    params.titleEn ? `英文名：${params.titleEn}` : "",
    params.year ? `年份：${params.year}` : "",
    params.imdbId ? `IMDb 号：${params.imdbId}` : "",
  ].filter(Boolean).join("\n");
  return [
    "你是影视资料补全助手。已知信息如下：",
    known,
    "",
    `请只补充以下缺失字段：${params.missing.join("、")}。`,
    "严格要求：",
    "1. 不要修改片名、年份、IMDb 号等身份信息。",
    "2. 不确定的字段请直接省略，不要猜测、不要填“未知”。",
    "3. 只输出 JSON，键为字段名，值为字符串（runtimeMinutes 为整数分钟）。",
    "4. 不要输出任何解释文字或 Markdown 代码块。",
  ].join("\n");
}
