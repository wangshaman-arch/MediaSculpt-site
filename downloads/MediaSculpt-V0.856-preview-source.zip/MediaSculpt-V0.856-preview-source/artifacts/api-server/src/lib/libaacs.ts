import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";

/**
 * AACS / BD+ decryption support for Blu-ray discs.
 *
 * MediaSculpt ships neither of the two things Blu-ray decryption needs:
 *
 *   1. `libaacs.dll` + `libbdplus.dll` — the decryption engines. Open source and
 *      freely redistributable. `libbluray`/ffmpeg/HandBrake load them
 *      dynamically from the directory that holds their own executable, the same
 *      way `libdvdcss-2.dll` is picked up for CSS DVDs.
 *   2. `KEYDB.cfg` — the key database. libaacs contains no keys of its own, so
 *      without this file the engines cannot decrypt anything. It is NOT
 *      redistributed by any of these projects; this module fetches a published
 *      community database on demand.
 *
 * Verified mirror behaviour (probed, not assumed):
 *   - `raw.githubusercontent.com` is unreachable from some networks, so the
 *     `github.com/<repo>/raw/<branch>/...` form is used for KEYDB.
 *   - The library bundle is published as a GitHub release asset (a zip with
 *     `winx64/`, `winx86/`, `winarm64/` layouts).
 */

export const LIBAACS_FILE_NAME = "libaacs.dll";
export const LIBBDPLUS_FILE_NAME = "libbdplus.dll";
export const KEYDB_FILE_NAME = "KEYDB.cfg";

/** Release bundle containing the prebuilt decryption engines. */
export const AACS_LIBRARY_ARCHIVE_URL =
  "https://github.com/KnugiHK/libaacs-libbdplus-windows/releases/download/0.12.0-0.2.0-20260715/libaacs_libbdplus.zip";

/** Preferred KEYDB sources, tried in order. */
export const KEYDB_MIRRORS = [
  "https://github.com/labdv/libaacs/raw/master/KEYDB.cfg",
  "https://bluray.beandog.org/keydb/KEYDB.cfg",
];

/** Short list for responsive health probes. */
export const KEYDB_PROBE_MIRRORS = KEYDB_MIRRORS.slice(0, 1);

/** A plausible KEYDB is a text file with at least one `|`-delimited record. */
export const KEYDB_MIN_BYTES = 4096;
/** The prebuilt engine DLLs are ~1.5-2 MB; the PE magic check guards the rest. */
export const AACS_DLL_MIN_BYTES = 64 * 1024;

export type AacsInstallStatus = "unsupported" | "already" | "installed" | "failed";

export type AacsDownloadFn = (
  url: string,
  timeoutMs: number,
) => Promise<{ ok: boolean; status: number; data: Uint8Array }>;

/**
 * Where libaacs looks for the key database on Windows. libaacs resolves
 * `$HOME/.config/aacs/` on Windows to `%APPDATA%\aacs\`, so the file is placed
 * there (and mirrored next to the tools, where hand-placed copies are also
 * picked up).
 */
export function keydbTargetPaths(
  executable: string | null,
  platform: NodeJS.Platform = process.platform,
  home: string = os.homedir(),
  appData: string = process.env.APPDATA ?? "",
): string[] {
  if (platform !== "win32") return [];
  const paths: string[] = [];
  const roaming = appData || path.join(home, "AppData", "Roaming");
  paths.push(path.join(roaming, "aacs", KEYDB_FILE_NAME));
  if (executable) {
    paths.push(path.join(path.dirname(path.resolve(executable)), KEYDB_FILE_NAME));
  }
  return paths;
}

/** Target path for the decryption engines: next to the given tool executable. */
export function aacsLibraryTargetPath(
  executable: string,
  fileName: string,
  platform: NodeJS.Platform = process.platform,
): string | null {
  if (platform !== "win32") return null;
  return path.join(path.dirname(path.resolve(executable)), fileName);
}

async function fileSizeOrZero(target: string): Promise<number> {
  try {
    const stat = await fs.stat(target);
    return stat.isFile() ? stat.size : 0;
  } catch {
    return 0;
  }
}

export async function isAacsLibraryInstalled(
  executable: string,
  platform: NodeJS.Platform = process.platform,
): Promise<boolean> {
  const aacs = aacsLibraryTargetPath(executable, LIBAACS_FILE_NAME, platform);
  const bdplus = aacsLibraryTargetPath(executable, LIBBDPLUS_FILE_NAME, platform);
  if (!aacs || !bdplus) return false;
  return (await fileSizeOrZero(aacs)) >= AACS_DLL_MIN_BYTES && (await fileSizeOrZero(bdplus)) >= AACS_DLL_MIN_BYTES;
}

export async function isKeydbInstalled(
  executable: string | null,
  platform: NodeJS.Platform = process.platform,
  home: string = os.homedir(),
  appData: string = process.env.APPDATA ?? "",
): Promise<boolean> {
  for (const target of keydbTargetPaths(executable, platform, home, appData)) {
    if ((await fileSizeOrZero(target)) >= KEYDB_MIN_BYTES) return true;
  }
  return false;
}

/** PE files start with the MZ magic; reject HTML error pages served as 200. */
export function isPeDllHead(head: Uint8Array, totalSize: number): boolean {
  return totalSize >= AACS_DLL_MIN_BYTES && head.length >= 2 && head[0] === 0x4d && head[1] === 0x5a;
}

/**
 * A real KEYDB starts with a comment header and contains `|`-delimited device
 * or disc records. This rejects an HTML error page that happened to be large.
 */
export function isKeydbContent(head: Uint8Array, totalSize: number): boolean {
  if (totalSize < KEYDB_MIN_BYTES) return false;
  const text = Buffer.from(head).toString("latin1");
  if (/<!DOCTYPE|<html/i.test(text)) return false;
  return text.includes("|") || /^;|^#/m.test(text) || /discid|processing key|device key/i.test(text);
}

async function defaultDownload(
  url: string,
  timeoutMs: number,
): Promise<{ ok: boolean; status: number; data: Uint8Array }> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { redirect: "follow", signal: controller.signal });
    if (!response.ok || !response.body) {
      return { ok: false, status: response.status, data: new Uint8Array() };
    }
    const buffer = new Uint8Array(await response.arrayBuffer());
    return { ok: true, status: response.status, data: buffer };
  } catch {
    return { ok: false, status: 0, data: new Uint8Array() };
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Extract `winx64/libaacs.dll` and `winx64/libbdplus.dll` from the release zip.
 *
 * The archive is a plain stored/deflated zip; the two entries are located by
 * suffix match so a version bump that changes the folder name keeps working.
 * Returns null when either entry is missing, so a malformed archive cannot
 * half-install the engines.
 */
export function extractAacsLibrariesFromZip(archive: Uint8Array): {
  aacs: Uint8Array;
  bdplus: Uint8Array;
} | null {
  const buffer = Buffer.from(archive);
  const entries = readZipEntries(buffer);
  const find = (suffix: string) =>
    entries.find((entry) => entry.name.toLowerCase().endsWith(suffix));
  const aacsEntry = find("winx64/libaacs.dll") ?? find("libaacs.dll");
  const bdplusEntry = find("winx64/libbdplus.dll") ?? find("libbdplus.dll");
  if (!aacsEntry || !bdplusEntry) return null;
  const aacs = inflateEntry(buffer, aacsEntry);
  const bdplus = inflateEntry(buffer, bdplusEntry);
  if (!aacs || !bdplus) return null;
  return { aacs, bdplus };
}

type ZipEntry = {
  name: string;
  method: number;
  compressedSize: number;
  uncompressedSize: number;
  localHeaderOffset: number;
};

/** Minimal central-directory reader; avoids pulling in an unzip dependency. */
function readZipEntries(buffer: Buffer): ZipEntry[] {
  const entries: ZipEntry[] = [];
  // Locate the End Of Central Directory record (signature 0x06054b50).
  let eocd = -1;
  for (let i = buffer.length - 22; i >= 0 && i >= buffer.length - 66_000; i -= 1) {
    if (buffer.readUInt32LE(i) === 0x06054b50) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) return entries;
  const count = buffer.readUInt16LE(eocd + 10);
  let cursor = buffer.readUInt32LE(eocd + 16);
  for (let index = 0; index < count; index += 1) {
    if (cursor + 46 > buffer.length || buffer.readUInt32LE(cursor) !== 0x02014b50) break;
    const method = buffer.readUInt16LE(cursor + 10);
    const compressedSize = buffer.readUInt32LE(cursor + 20);
    const uncompressedSize = buffer.readUInt32LE(cursor + 24);
    const nameLength = buffer.readUInt16LE(cursor + 28);
    const extraLength = buffer.readUInt16LE(cursor + 30);
    const commentLength = buffer.readUInt16LE(cursor + 32);
    const localHeaderOffset = buffer.readUInt32LE(cursor + 42);
    const name = buffer.toString("utf8", cursor + 46, cursor + 46 + nameLength);
    entries.push({ name, method, compressedSize, uncompressedSize, localHeaderOffset });
    cursor += 46 + nameLength + extraLength + commentLength;
  }
  return entries;
}

function inflateEntry(buffer: Buffer, entry: ZipEntry): Uint8Array | null {
  const offset = entry.localHeaderOffset;
  if (offset + 30 > buffer.length || buffer.readUInt32LE(offset) !== 0x04034b50) return null;
  const nameLength = buffer.readUInt16LE(offset + 26);
  const extraLength = buffer.readUInt16LE(offset + 28);
  const start = offset + 30 + nameLength + extraLength;
  const raw = buffer.subarray(start, start + entry.compressedSize);
  if (entry.method === 0) return new Uint8Array(raw);
  if (entry.method !== 8) return null;
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const zlib = require("node:zlib") as typeof import("node:zlib");
    return new Uint8Array(zlib.inflateRawSync(raw));
  } catch {
    return null;
  }
}

/** Write bytes to `target` atomically so a failed download cannot leave a stub. */
async function writeAtomic(target: string, data: Uint8Array): Promise<void> {
  await fs.mkdir(path.dirname(target), { recursive: true });
  const temp = `${target}.download`;
  await fs.writeFile(temp, Buffer.from(data));
  await fs.rename(temp, target);
}

export type EnsureAacsOptions = {
  force?: boolean;
  home?: string;
  appData?: string;
  platform?: NodeJS.Platform;
  libraryUrl?: string;
  keydbMirrors?: string[];
  timeoutMs?: number;
  download?: AacsDownloadFn;
  onLog?: (message: string) => void | Promise<void>;
};

/**
 * Install the AACS/BD+ engines next to the given executable, then fetch the key
 * database when it is missing. Both halves are independent: a failed KEYDB
 * download still leaves the engines in place, so a user-supplied KEYDB later
 * works without another download.
 */
export async function ensureAacsDecryption(
  executable: string,
  options: EnsureAacsOptions = {},
): Promise<{ libraries: AacsInstallStatus; keydb: AacsInstallStatus }> {
  const platform = options.platform ?? process.platform;
  const log = async (message: string) => {
    await options.onLog?.(message);
  };
  if (platform !== "win32") return { libraries: "unsupported", keydb: "unsupported" };
  const timeoutMs = options.timeoutMs ?? 60_000;
  const download = options.download ?? defaultDownload;

  let libraries: AacsInstallStatus = "failed";
  if (!options.force && (await isAacsLibraryInstalled(executable, platform))) {
    libraries = "already";
  } else {
    const url = options.libraryUrl ?? AACS_LIBRARY_ARCHIVE_URL;
    try {
      const result = await download(url, timeoutMs);
      const extracted = result.ok ? extractAacsLibrariesFromZip(result.data) : null;
      if (!extracted) {
        await log(`libaacs: ${url} -> archive unusable (HTTP ${result.status})`);
      } else if (
        !isPeDllHead(extracted.aacs.slice(0, 16), extracted.aacs.length) ||
        !isPeDllHead(extracted.bdplus.slice(0, 16), extracted.bdplus.length)
      ) {
        await log("libaacs: extracted payload is not a PE DLL, skipping");
      } else {
        const aacsTarget = aacsLibraryTargetPath(executable, LIBAACS_FILE_NAME, platform);
        const bdplusTarget = aacsLibraryTargetPath(executable, LIBBDPLUS_FILE_NAME, platform);
        if (aacsTarget && bdplusTarget) {
          await writeAtomic(aacsTarget, extracted.aacs);
          await writeAtomic(bdplusTarget, extracted.bdplus);
          await log(`libaacs: installed ${LIBAACS_FILE_NAME} + ${LIBBDPLUS_FILE_NAME} from ${url}`);
          libraries = "installed";
        }
      }
    } catch (error) {
      await log(`libaacs: ${url} -> ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  let keydb: AacsInstallStatus = "failed";
  if (!options.force && (await isKeydbInstalled(executable, platform, options.home, options.appData))) {
    keydb = "already";
  } else {
    for (const url of options.keydbMirrors ?? KEYDB_MIRRORS) {
      try {
        const result = await download(url, timeoutMs);
        if (!result.ok) {
          await log(`KEYDB: ${url} -> HTTP ${result.status}, skipping`);
          continue;
        }
        if (!isKeydbContent(result.data.slice(0, 4096), result.data.length)) {
          await log(`KEYDB: ${url} -> payload is not a key database, skipping`);
          continue;
        }
        const targets = keydbTargetPaths(executable, platform, options.home, options.appData);
        for (const target of targets) await writeAtomic(target, result.data);
        await log(`KEYDB: installed to ${targets[0]} from ${url}`);
        keydb = "installed";
        break;
      } catch (error) {
        await log(`KEYDB: ${url} -> ${error instanceof Error ? error.message : String(error)}`);
      }
    }
  }

  return { libraries, keydb };
}

/**
 * Recognise AACS/BD+ decryption failures in tool stderr so the UI can explain
 * an encrypted disc instead of surfacing a raw tool error.
 */
export function isAacsDecryptionError(stderr: string): boolean {
  if (!stderr) return false;
  return /aacs|libaacs|bd\+|bdplus|bdsvm|unit_key|decrypt(?:ion)?\s+(?:key|failed)/i.test(stderr);
}
