import fs from "fs/promises";
import path from "path";

export type MediaType = "video" | "bluray" | "dvd" | "iso";

/**
 * MPLS PlayItem IN_time/OUT_time and PlayListMark time are stored in 45 kHz
 * ticks (not 90 kHz). Dividing by 90 kHz halved every Blu-ray playlist and
 * chapter duration on real discs.
 */
const MPLS_TIME_HZ = 45_000;

/**
 * Menus and "all clips" playlists repeat the exact same clip range many times
 * (e.g. a 63 s loop listed 201×). Their summed duration is not a real title
 * length and would otherwise outrank the actual feature, so they are skipped.
 */
const MAX_IDENTICAL_PLAYLIST_SEGMENTS = 10;

export interface DvdTitle {
  titleNumber: number;
  discRoot: string;
  videoTsDir: string;
  ifoPath: string;
  vobFiles: string[];
  /** Content VOB numbers (1..N) absent from the rip, e.g. ["VTS_02_5.VOB"]. */
  missingVobFiles?: string[];
  sizeBytes: number;
}

export interface BlurayPlaylistSegment {
  clipId: string;
  streamPath: string;
  inTime45k: number;
  outTime45k: number;
}

export interface BlurayChapter {
  id: number;
  startSeconds: number;
  endSeconds: number;
  title: string | null;
}

export interface BlurayPlaylistInfo {
  playlistId: string;
  mplsPath: string;
  durationSeconds: number | null;
  sizeBytes: number;
  chapterCount: number;
  chapters: BlurayChapter[];
  segments: BlurayPlaylistSegment[];
  /** Stream files referenced by the playlist but absent from the source. */
  missingSegments: string[];
}

/**
 * Parse a standard Blu-ray MPLS playlist and return its m2ts segments in
 * playback order. Follows the BD spec: the header carries three start
 * addresses, PlayItem count is a single byte, and SubPath entries are skipped
 * by their own length so they cannot misalign the segment walk.
 */
export async function parseBlurayMpls(
  mplsPath: string,
  discRoot: string,
): Promise<BlurayPlaylistSegment[]> {
  const data = await fs.readFile(mplsPath);
  if (data.toString("ascii", 0, 4) !== "MPLS") return [];
  const playlistOffset = data.readUInt32BE(8);
  if (playlistOffset + 10 > data.length) return [];
  const length = data.readUInt32BE(playlistOffset);
  const end = Math.min(data.length, playlistOffset + 4 + length);
  // The BD spec stores number_of_PlayItems and number_of_SubPaths as 16-bit
  // values. Reading single bytes only saw the high byte of real discs (0),
  // which made every playlist look empty and Remux fail with
  // "未找到蓝光播放列表".
  const playItemCount = data.readUInt16BE(playlistOffset + 6);
  const subPathCount = data.readUInt16BE(playlistOffset + 8);
  let cursor = playlistOffset + 10;
  const segments: BlurayPlaylistSegment[] = [];
  for (let i = 0; i < playItemCount && cursor + 2 <= end; i++) {
    const itemLength = data.readUInt16BE(cursor);
    const itemEnd = Math.min(end, cursor + 2 + itemLength);
    if (cursor + 9 > itemEnd) break;
    const clipId = data.toString("ascii", cursor + 2, cursor + 7);
    // PlayItem(): length(2) clip_identifier(5) clip_codec_identifier(4)
    // flags(2) ref_to_STC_id(1) IN_time(4) OUT_time(4). Reading IN/OUT at
    // +22/+26 landed past the timestamps, so every real playlist reported a
    // zero duration and Remux/compression fell back to the first segment file.
    const inTime45k =
      itemEnd >= cursor + 18 ? data.readUInt32BE(cursor + 14) : 0;
    const outTime45k =
      itemEnd >= cursor + 22 ? data.readUInt32BE(cursor + 18) : 0;
    if (/^\d{5}$/.test(clipId))
      segments.push({
        clipId,
        streamPath: path.join(discRoot, "BDMV", "STREAM", clipId + ".m2ts"),
        inTime45k,
        outTime45k,
      });
    cursor += 2 + itemLength;
  }
  for (let i = 0; i < subPathCount && cursor + 4 <= end; i++) {
    const subLength = data.readUInt32BE(cursor);
    cursor += 4 + subLength;
  }
  return segments;
}

/** Parse PlayListMark entry points (mark_type 1) as chapters, in playback order. */
export async function parseBlurayChapters(
  mplsPath: string,
  discRoot: string,
): Promise<BlurayChapter[]> {
  const data = await fs.readFile(mplsPath);
  if (data.toString("ascii", 0, 4) !== "MPLS") return [];
  const markOffset = data.readUInt32BE(12);
  if (markOffset + 6 > data.length) return [];
  const length = data.readUInt32BE(markOffset);
  const end = Math.min(data.length, markOffset + 4 + length);
  const count = data.readUInt16BE(markOffset + 4);
  const segments = await parseBlurayMpls(mplsPath, discRoot);
  // Playlist-relative start of each play item. A mark's `time` shares the
  // clip's absolute STC base, so the playlist position is
  //   (sum of earlier segment durations) + (mark time - segment IN_time).
  // The old code added IN_time, yielding ~10-hour chapter positions that
  // FFmpeg silently discarded (output had zero chapters).
  const prefix45k: number[] = [];
  let running45k = 0;
  for (const segment of segments) {
    prefix45k.push(running45k);
    running45k += Math.max(0, segment.outTime45k - segment.inTime45k);
  }
  // PlayListMark() entries are fixed 14 bytes each:
  //   reserved(1) mark_type(1) play_item_ref(2) time(4) entry_ES_PID(2) duration(4)
  // Reading them as variable 8/12-byte records desynced the walk and produced
  // bogus chapter counts (e.g. 67 chapters on a 63-second clip).
  const MARK_ENTRY_BYTES = 14;
  let cursor = markOffset + 6;
  const marks = [];
  for (let i = 0; i < count && cursor + MARK_ENTRY_BYTES <= end; i++) {
    const markType = data.readUInt8(cursor + 1);
    const playItemRef = data.readUInt16BE(cursor + 2);
    const time45k = data.readUInt32BE(cursor + 4);
    const segment = segments[playItemRef];
    const relative45k = segment
      ? (prefix45k[playItemRef] ?? 0) + Math.max(0, time45k - segment.inTime45k)
      : time45k;
    marks.push({ absolute45k: relative45k, isEntry: markType === 1 });
    cursor += MARK_ENTRY_BYTES;
  }
  const entries = marks.filter((mark) => mark.isEntry);
  const uniqueStarts = Array.from(
    new Set(
      (entries.length > 0 ? entries : marks).map((mark) => mark.absolute45k),
    ),
  );
  const sorted = uniqueStarts.sort((a, b) => a - b);
  const total45k = segments.reduce(
    (sum, segment) => sum + Math.max(0, segment.outTime45k - segment.inTime45k),
    0,
  );
  // When the playlist carries no usable IN/OUT times (some authored discs),
  // fall back to "1 second after the last chapter start" so the final chapter
  // always has a valid end instead of 0.
  const lastStart45k = sorted.length > 0 ? sorted[sorted.length - 1] : 0;
  const endFallback45k = total45k > 0 ? total45k : lastStart45k + MPLS_TIME_HZ;
  return sorted.map((start45k, index) => ({
    id: index,
    startSeconds: start45k / MPLS_TIME_HZ,
    endSeconds:
      (index + 1 < sorted.length
        ? Math.max(sorted[index + 1], start45k + 1)
        : Math.max(endFallback45k, start45k + 1)) / MPLS_TIME_HZ,
    title: null,
  }));
}

/** Enumerate all playlists of a Blu-ray disc and derive duration, size and chapters. */
export async function scanBlurayPlaylists(
  discRoot: string,
): Promise<BlurayPlaylistInfo[]> {
  const playlistDir = path.join(discRoot, "BDMV", "PLAYLIST");
  const entries = await fs.readdir(playlistDir).catch(() => []);
  const files = entries.filter((name) => /\.mpls$/i.test(name)).sort();
  const playlists = [];
  for (const name of files) {
    const mplsPath = path.join(playlistDir, name);
    const segments = await parseBlurayMpls(mplsPath, discRoot);
    if (segments.length === 0) continue;
    const rangeCounts = new Map<string, number>();
    for (const segment of segments) {
      const key = `${segment.clipId}:${segment.inTime45k}:${segment.outTime45k}`;
      rangeCounts.set(key, (rangeCounts.get(key) ?? 0) + 1);
    }
    if (Math.max(...rangeCounts.values()) > MAX_IDENTICAL_PLAYLIST_SEGMENTS)
      continue;
    const total45k = segments.reduce(
      (sum, segment) =>
        sum + Math.max(0, segment.outTime45k - segment.inTime45k),
      0,
    );
    const chapters = await parseBlurayChapters(mplsPath, discRoot);
    // A playlist can reference the same m2ts in several PlayItems (loops,
    // multi-angle, chaptered short clips). Sum each physical file once so the
    // reported size can never exceed the bytes actually present on the disc.
    const countedStreams = new Set<string>();
    const missingSegments = new Set<string>();
    let sizeBytes = 0;
    for (const segment of segments) {
      if (countedStreams.has(segment.streamPath)) continue;
      countedStreams.add(segment.streamPath);
      const stat = await fs.stat(segment.streamPath).catch(() => null);
      if (stat) sizeBytes += stat.size;
      else missingSegments.add(segment.streamPath);
    }
    playlists.push({
      playlistId: path.basename(name, path.extname(name)),
      mplsPath,
      durationSeconds: total45k > 0 ? total45k / MPLS_TIME_HZ : null,
      sizeBytes,
      chapterCount: chapters.length,
      chapters,
      segments,
      missingSegments: Array.from(missingSegments),
    });
  }
  return playlists;
}

export async function isBlurayDisc(dir: string): Promise<boolean> {
  try {
    const stat = await fs.stat(path.join(dir, "BDMV", "index.bdmv"));
    return stat.isFile();
  } catch {
    return false;
  }
}

export async function resolveDvdVideoTsDir(
  inputPath: string,
): Promise<string | null> {
  const directIfo = path.join(inputPath, "VIDEO_TS.IFO");
  try {
    const stat = await fs.stat(directIfo);
    if (
      stat.isFile() &&
      path.basename(inputPath).toUpperCase() === "VIDEO_TS"
    ) {
      return inputPath;
    }
  } catch {
    // Try disc root below.
  }

  const nestedDir = path.join(inputPath, "VIDEO_TS");
  const nestedIfo = path.join(nestedDir, "VIDEO_TS.IFO");
  try {
    const stat = await fs.stat(nestedIfo);
    return stat.isFile() ? nestedDir : null;
  } catch {
    return null;
  }
}

export async function isDvdDisc(dir: string): Promise<boolean> {
  return (await resolveDvdVideoTsDir(dir)) !== null;
}

export function collectDvdVobFilesForIfo(
  ifoPath: string,
  entries: string[],
): string[] {
  const ifoDir = path.dirname(ifoPath);
  const ifoStem = path.basename(ifoPath, path.extname(ifoPath));
  const vtsGroup = ifoStem.replace(/_0$/i, "");
  const escapedGroup = vtsGroup.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const vobPattern = new RegExp(`^${escapedGroup}_(\\d+)\\.VOB$`, "i");

  return entries
    .map((name) => {
      const match = name.match(vobPattern);
      return match ? { name, index: parseInt(match[1] ?? "0", 10) } : null;
    })
    .filter(
      (entry): entry is { name: string; index: number } =>
        !!entry && entry.index > 0,
    )
    .sort((a, b) => a.index - b.index)
    .map((entry) => path.join(ifoDir, entry.name));
}

/** Content VOB numbers (1..N) that are absent from the folder, e.g. ["VTS_02_5.VOB"]. */
export function findMissingDvdVobFiles(
  ifoPath: string,
  entries: string[],
): string[] {
  const ifoStem = path.basename(ifoPath, path.extname(ifoPath));
  const vtsGroup = ifoStem.replace(/_0$/i, "");
  const escapedGroup = vtsGroup.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const vobPattern = new RegExp(`^${escapedGroup}_(\\d+)\\.VOB$`, "i");
  const present = new Set<number>();
  let maxIndex = 0;
  for (const name of entries) {
    const match = name.match(vobPattern);
    if (!match) continue;
    const index = parseInt(match[1] ?? "0", 10);
    if (index > 0) present.add(index);
    if (index > maxIndex) maxIndex = index;
  }
  const missing: string[] = [];
  for (let index = 1; index <= maxIndex; index += 1) {
    if (!present.has(index)) missing.push(`${vtsGroup}_${index}.VOB`);
  }
  return missing;
}

export async function resolveDvdTitleForIfo(
  ifoPath: string,
): Promise<DvdTitle | null> {
  // Filename plus VOB group remains the portable fallback for sparse IFO extracts.
  const entries = await fs
    .readdir(path.dirname(ifoPath))
    .catch(() => [] as string[]);
  const vobFiles = collectDvdVobFilesForIfo(ifoPath, entries);
  if (vobFiles.length === 0) return null;
  const missingVobFiles = findMissingDvdVobFiles(ifoPath, entries);

  let sizeBytes = 0;
  for (const file of vobFiles) {
    try {
      sizeBytes += (await fs.stat(file)).size;
    } catch {
      // Missing VOBs are ignored here; ffmpeg will report the concrete error.
    }
  }

  const match = path.basename(ifoPath).match(/^VTS_(\d{2})_0\.IFO$/i);
  const videoTsDir = path.dirname(ifoPath);
  return {
    titleNumber: match ? parseInt(match[1] ?? "0", 10) : 0,
    discRoot: resolveDvdDiscRootForIfo(ifoPath),
    videoTsDir,
    ifoPath,
    vobFiles,
    missingVobFiles: missingVobFiles.length > 0 ? missingVobFiles : undefined,
    sizeBytes,
  };
}

export async function resolveDvdTitleForSource(
  sourcePath: string,
  minSizeBytes = 0,
  requestedTitleNumber?: number,
): Promise<DvdTitle | null> {
  if (/\.ifo$/i.test(sourcePath)) {
    const title = await resolveDvdTitleForIfo(sourcePath);
    return title && title.sizeBytes >= minSizeBytes ? title : null;
  }

  const titles = await findDvdTitles(sourcePath, minSizeBytes);
  if (typeof requestedTitleNumber === "number" && requestedTitleNumber > 0) {
    // findDvdTitles is intentionally sorted by physical size for discovery,
    // but Remux must use the VOB group belonging to the immutable user choice.
    // Otherwise a navigation failure can fall back to a different title while
    // keeping the selected title number in the command.
    // The navigation route still needs a physical title object for the
    // executor contract. Returning the largest VTS on a mismatch silently
    // exports a different programme, so an exact physical match is required.
    return (
      titles.find((title) => title.titleNumber === requestedTitleNumber) ?? null
    );
  }
  return titles[0] ?? null;
}

export function resolveDvdDiscRootForIfo(ifoPath: string): string {
  const videoTsDir = path.dirname(ifoPath);
  return path.basename(videoTsDir).toUpperCase() === "VIDEO_TS"
    ? path.dirname(videoTsDir)
    : videoTsDir;
}

export function resolveDvdHandbrakeInputForIfo(ifoPath: string): string {
  return resolveDvdDiscRootForIfo(ifoPath);
}

/**
 * Pick the input path that libdvdnav/libdvdcss can actually open for a
 * dvdvideo demuxer on the current platform.
 *
 * - Physical drives and mounted ISO images must be passed as the drive root
 *   (e.g. `E:\`): libdvdnav appends `VIDEO_TS` itself, and libdvdcss on
 *   Windows only authenticates CSS against a drive device.
 * - Folder-based VIDEO_TS rips must be passed as the folder that directly
 *   contains the IFO/VOB files (e.g. `D:\Movies\Title\VIDEO_TS`); the parent
 *   folder cannot be opened by the Windows dvdnav/dvdcss layer.
 */
export function resolveDvdVideoInputPath(
  discRoot: string,
  videoTsDir?: string | null,
): string {
  const resolved = path.resolve(discRoot);
  if (process.platform !== "win32") return resolved;
  if (/^[a-zA-Z]:[\\/]?$/.test(resolved)) return resolved;
  if (path.basename(resolved).toUpperCase() === "VIDEO_TS") return resolved;
  return videoTsDir ?? path.join(resolved, "VIDEO_TS");
}

export function dvdTitleInputArgs(title: DvdTitle): string[] {
  if (title.titleNumber > 0) {
    return [
      "-f",
      "dvdvideo",
      "-title",
      String(title.titleNumber),
      "-i",
      resolveDvdVideoInputPath(title.discRoot, title.videoTsDir),
    ];
  }
  return ["-i", title.ifoPath];
}

export async function findDvdTitles(
  inputPath: string,
  minSizeBytes = 0,
): Promise<DvdTitle[]> {
  const videoTsDir = await resolveDvdVideoTsDir(inputPath);
  if (!videoTsDir) return [];

  const entries = await fs.readdir(videoTsDir);
  const ifoFiles = entries
    .filter((name) => /^VTS_\d{2}_0\.IFO$/i.test(name))
    .sort();

  const titles: DvdTitle[] = [];
  for (const ifoName of ifoFiles) {
    const title = await resolveDvdTitleForIfo(path.join(videoTsDir, ifoName));
    if (title && title.sizeBytes >= minSizeBytes) {
      titles.push(title);
    }
  }

  titles.sort((a, b) => b.sizeBytes - a.sizeBytes);
  return titles;
}

export async function resolveMainTrack(
  sourcePath: string,
  mediaType: MediaType | string,
): Promise<string> {
  if (mediaType === "bluray") {
    const streamDir = path.join(sourcePath, "BDMV", "STREAM");
    try {
      const entries = await fs.readdir(streamDir);
      const m2tsFiles = entries.filter((name) =>
        name.toLowerCase().endsWith(".m2ts"),
      );
      const withSizes = await Promise.all(
        m2tsFiles.map(async (name) => {
          const filePath = path.join(streamDir, name);
          const stat = await fs.stat(filePath);
          return { path: filePath, size: stat.size };
        }),
      );
      withSizes.sort((a, b) => b.size - a.size);
      return withSizes[0]?.path ?? sourcePath;
    } catch {
      return sourcePath;
    }
  }

  if (mediaType === "dvd") {
    if (/\.ifo$/i.test(sourcePath)) return sourcePath;
    const titles = await findDvdTitles(sourcePath);
    return (
      titles[0]?.ifoPath ??
      (await resolveDvdVideoTsDir(sourcePath)) ??
      sourcePath
    );
  }

  return sourcePath;
}
