import { describe, expect, it } from "vitest";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "./remux-mapping";

describe("remux stream mapping", () => {
  it("maps selected stream indexes", () => expect(buildRemuxMapArgs("[0,2,5]")).toEqual(["-map", "0:0", "-map", "0:2", "-map", "0:5"]));
  it("falls back to all streams for invalid selections", () => expect(buildRemuxMapArgs("bad")).toEqual(["-map", "0"]));
  it("rejects an explicit empty stream selection instead of silently remuxing all streams", () => expect(() => buildRemuxMapArgs("[]")).toThrow("至少选择一个视频、音频或字幕流"));
  it("does not preserve raw input timestamps for concat or chapter remuxes", () => {
    expect(buildRemuxCopyArgs({ usesConcatInput: true })).not.toContain("-copyts");
    expect(buildRemuxCopyArgs({ usesConcatInput: false })).not.toContain("-copyts");
    expect(buildRemuxCopyArgs({ usesConcatInput: true })).toContain("-avoid_negative_ts");
  });
  it("removes chapters when the user explicitly selects no chapters", () => {
    expect(buildRemuxCopyArgs({ usesConcatInput: false, selectedChapters: "[]" })).toEqual(expect.arrayContaining(["-map_chapters", "-1"]));
  });
});
