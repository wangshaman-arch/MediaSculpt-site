import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

export const projectRoot = path.resolve(import.meta.dirname, "../../../..");

export function readProjectFile(relativePath: string): string {
  const absolutePath = path.join(projectRoot, relativePath);
  if (!fs.existsSync(absolutePath)) return "";
  const source = fs.readFileSync(absolutePath, "utf8");
  // Page contracts intentionally include the feature modules composed by the
  // page. This keeps the assertions about user-visible behavior stable while
  // allowing the implementation to live outside a single oversized page file.
  if (
    relativePath === "artifacts/video-agent/src/pages/Scan.tsx" ||
    relativePath === "artifacts/video-agent/src/pages/Settings.tsx" ||
    relativePath === "artifacts/video-agent/src/pages/JobDetail.tsx"
  ) {
    const featureRoot = path.join(
      projectRoot,
      "artifacts/video-agent/src/features/workbench",
    );
    const featureFiles = relativePath.endsWith("Scan.tsx")
      ? fs
          .readdirSync(featureRoot)
          .filter((name) => /\.(ts|tsx)$/.test(name))
          .sort()
          .map((name) => fs.readFileSync(path.join(featureRoot, name), "utf8"))
      : [];
    const extractedPageModules =
      {
        "artifacts/video-agent/src/pages/Scan.tsx": ["scan-model.ts"],
        "artifacts/video-agent/src/pages/Settings.tsx": [
          "settings-model.ts",
          "settings-tool-manager.tsx",
          "settings-compression-section.tsx",
          "settings-subtitles-section.tsx",
          "settings-ai-section.tsx",
          "settings-directories-section.tsx",
          "settings-tools-section.tsx",
          "settings-system-section.tsx",
        ],
        "artifacts/video-agent/src/pages/JobDetail.tsx": [
          "job-detail-model.ts",
          "job-detail-source-bar.tsx",
          "job-detail-decision-panel.tsx",
        ],
      }[relativePath] ?? [];
    const extractedPageSources = extractedPageModules.map((name) =>
      fs.readFileSync(
        path.join(projectRoot, "artifacts/video-agent/src/pages", name),
        "utf8",
      ),
    );
    const hookPath = relativePath.endsWith("Scan.tsx")
      ? path.join(
          projectRoot,
          "artifacts/video-agent/src/hooks/useWorkbenchState.ts",
        )
      : path.join(
          projectRoot,
          "artifacts/video-agent/src/hooks/useSettingsSections.ts",
        );
    return [
      source,
      ...featureFiles,
      ...extractedPageSources,
      fs.readFileSync(hookPath, "utf8"),
    ].join("\n");
  }
  // The jobs route was split into focused router modules; contract assertions
  // about the job API should see the whole surface regardless of which file a
  // handler now lives in.
  const routeCompanions = {
    "artifacts/api-server/src/routes/jobs.ts": [
      "artifacts/api-server/src/routes/jobs-preview.ts",
      "artifacts/api-server/src/routes/disc.ts",
      "artifacts/api-server/src/routes/admin.ts",
      "artifacts/api-server/src/routes/jobs-crud.ts",
      "artifacts/api-server/src/routes/jobs-crud-helpers.ts",
      "artifacts/api-server/src/routes/job-orchestrator.ts",
      "artifacts/api-server/src/routes/jobs-bilingual.ts",
      "artifacts/api-server/src/routes/jobs-iso.ts",
      "artifacts/api-server/src/routes/jobs-probe.ts",
      "artifacts/api-server/src/routes/jobs-subtitle-files.ts",
      "artifacts/api-server/src/routes/jobs-output-paths.ts",
      "artifacts/api-server/src/routes/jobs-dvd.ts",
      "artifacts/api-server/src/routes/jobs-tracking.ts",
      "artifacts/api-server/src/routes/jobs-ffmpeg-run.ts",
      "artifacts/api-server/src/routes/jobs-pipeline.ts",
      "artifacts/api-server/src/routes/jobs-config.ts",
      "artifacts/api-server/src/routes/jobs-ocr-flow.ts",
      "artifacts/api-server/src/routes/jobs-translation.ts",
      "artifacts/api-server/src/routes/jobs-prompts.ts",
      "artifacts/api-server/src/routes/jobs-audio.ts",
      "artifacts/api-server/src/routes/jobs-subtitle-probe.ts",
      "artifacts/api-server/src/routes/jobs-subtitle-pipeline.ts",
      "artifacts/api-server/src/routes/jobs-chapter-preview.ts",
      "artifacts/api-server/src/routes/jobs-readme-ai.ts",
      "artifacts/api-server/src/routes/jobs-dvd-remux.ts",
      "artifacts/api-server/src/routes/jobs-dvd-audio.ts",
      "artifacts/api-server/src/routes/jobs-subtitle-select.ts",
      "artifacts/api-server/src/routes/jobs-subtitle-sidecars.ts",
    ],
    "artifacts/api-server/src/lib/disc-analysis.ts": [
      "artifacts/api-server/src/lib/disc-analysis-bluray.ts",
      "artifacts/api-server/src/lib/disc-analysis-dvd.ts",
    ],
    "artifacts/api-server/src/lib/metadata.ts": [
      "artifacts/api-server/src/lib/metadata-providers.ts",
      "artifacts/api-server/src/lib/metadata-imdb.ts",
    ],
    "artifacts/api-server/src/lib/tool-downloader.ts": [
      "artifacts/api-server/src/lib/tool-install-tesseract.ts",
    ],
    "artifacts/api-server/src/lib/smart-workflow.ts": [
      "artifacts/api-server/src/lib/smart-workflow-decisions.ts",
    ],
    "artifacts/api-server/src/lib/subtitle-ocr.ts": [
      "artifacts/api-server/src/lib/subtitle-ocr-dvd.ts",
      "artifacts/api-server/src/lib/subtitle-ocr-png.ts",
      "artifacts/api-server/src/lib/subtitle-ocr-pgs.ts",
      "artifacts/api-server/src/lib/subtitle-ocr-tesseract.ts",
      "artifacts/api-server/src/lib/subtitle-ocr-language.ts",
    ],
  }[relativePath];
  if (routeCompanions) {
    return [
      source,
      ...routeCompanions.map((companion) => {
        const companionPath = path.join(projectRoot, companion);
        return fs.existsSync(companionPath)
          ? fs.readFileSync(companionPath, "utf8")
          : "";
      }),
    ].join("\n");
  }
  const extractedImplementation = {
    "artifacts/api-server/src/lib/preview-service.ts":
      "artifacts/api-server/src/media/preview-service.ts",
    "artifacts/api-server/src/lib/compression-service.ts":
      "artifacts/api-server/src/media/compression-service.ts",
  }[relativePath];
  if (extractedImplementation) {
    const implementationPath = path.join(projectRoot, extractedImplementation);
    if (fs.existsSync(implementationPath)) {
      return [source, fs.readFileSync(implementationPath, "utf8")].join("\n");
    }
  }
  return source;
}

/** UI copy now lives in the locale packs; assertions accept source or pack occurrences. */
export const zhPack = () =>
  readProjectFile("artifacts/video-agent/src/i18n/zh-CN.ts");
export const enPack = () =>
  readProjectFile("artifacts/video-agent/src/i18n/en-US.ts");
