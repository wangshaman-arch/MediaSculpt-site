import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
  persistResolvedMetadata,
  recordToMetadataResult,
  resolveFromCache,
  tierForResolution,
} from "./metadata-cache";
import { writeTitleMetadata } from "./title-metadata";
import type { MetadataResult } from "./metadata";

let dir: string;

beforeEach(async () => {
  dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-meta-cache-"));
});

afterEach(async () => {
  await fs.rm(dir, { recursive: true, force: true });
});

const enriched: MetadataResult = {
  title: "美丽心灵",
  titleEn: "A Beautiful Mind",
  year: 2001,
  imdbId: "tt0268978",
  director: "Ron Howard",
  cast: "Russell Crowe、Jennifer Connelly",
  genres: "剧情",
  rating: 8.2,
  ratingSource: "imdb",
  runtimeMinutes: 135,
  overview: "A biographical drama…",
  poster: "https://example.com/p.jpg",
  mediaType: "movie",
  source: "imdb",
};

describe("cache-first resolution", () => {
  it("reports a miss for a folder with no sidecar", async () => {
    const cached = await resolveFromCache(dir);
    expect(cached).toMatchObject({ result: null, reason: "missing" });
  });

  // The behaviour that makes offline work possible: an already-resolved title
  // is served from disk, so no request is needed on a machine with no keys.
  it("serves an enriched record without touching the network", async () => {
    await writeTitleMetadata(dir, { ...enriched }, "keyed");
    const cached = await resolveFromCache(dir);
    expect(cached.reason).toBe("hit");
    expect(cached.tier).toBe("keyed");
    expect(cached.result).toMatchObject({
      title: "美丽心灵",
      titleEn: "A Beautiful Mind",
      imdbId: "tt0268978",
      director: "Ron Howard",
      cast: "Russell Crowe、Jennifer Connelly",
      rating: 8.2,
    });
  });

  it("treats a filename-only record as a miss so the network can still enrich it", async () => {
    await writeTitleMetadata(dir, { title: "Hamlet", year: 1996 }, "filename");
    const cached = await resolveFromCache(dir);
    expect(cached.reason).toBe("not-enriched");
    expect(cached.result).toBeNull();
  });

  it("accepts a record that only carries an IMDb id as usable identity", async () => {
    await writeTitleMetadata(dir, { title: "Hamlet", imdbId: "tt0116477" }, "keyless");
    const cached = await resolveFromCache(dir);
    expect(cached.reason).toBe("hit");
    expect(cached.result?.imdbId).toBe("tt0116477");
  });

  it("persists a result and reads it back on the next run", async () => {
    await persistResolvedMetadata({ targetDirectory: dir, result: enriched, tier: "keyed" });
    const cached = await resolveFromCache(dir);
    expect(cached.reason).toBe("hit");
    expect(cached.result?.cast).toBe("Russell Crowe、Jennifer Connelly");
  });

  it("does not overwrite a richer cached record with a poorer one", async () => {
    await persistResolvedMetadata({ targetDirectory: dir, result: enriched, tier: "keyed" });
    // A later offline run only knows the filename.
    await persistResolvedMetadata({
      targetDirectory: dir,
      result: { title: "A Beautiful Mind", mediaType: "movie", source: "imdb" },
      tier: "filename",
    });
    const cached = await resolveFromCache(dir);
    expect(cached.tier).toBe("keyed");
    expect(cached.result?.director).toBe("Ron Howard");
    expect(cached.result?.cast).toBe("Russell Crowe、Jennifer Connelly");
  });

  it("is a no-op without a target directory or a result", async () => {
    expect(await persistResolvedMetadata({ targetDirectory: null, result: enriched, tier: "keyed" })).toBeNull();
    expect(await persistResolvedMetadata({ targetDirectory: dir, result: null, tier: "keyed" })).toBeNull();
    expect((await resolveFromCache(null)).reason).toBe("missing");
  });

  it("returns null when a record carries no usable title", () => {
    expect(recordToMetadataResult(null)).toBeNull();
    expect(recordToMetadataResult({ version: 1, resolvedBy: "filename", title: "  " })).toBeNull();
    expect(recordToMetadataResult({ version: 1, resolvedBy: "keyless", titleEn: "Hamlet" })?.title).toBe("Hamlet");
  });

  // The tier is user-facing: it tells them whether enabling a key or AI would
  // still add anything, so it must reflect what actually answered.
  it("attributes the tier to the source that answered", () => {
    expect(tierForResolution({ source: "imdb" })).toBe("keyless");
    expect(tierForResolution({ source: "wikipedia" })).toBe("keyless");
    expect(tierForResolution({ source: "tmdb" })).toBe("keyed");
    expect(tierForResolution({ source: "omdb" })).toBe("keyed");
    expect(tierForResolution({ source: "imdb", usedLocalDataset: true })).toBe("keyed");
    expect(tierForResolution({ source: "tmdb", usedAi: true })).toBe("ai");
  });
});
