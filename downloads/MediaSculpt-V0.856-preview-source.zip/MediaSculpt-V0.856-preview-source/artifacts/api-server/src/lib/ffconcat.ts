export function buildFfconcatFileContent(files: string[], platform = process.platform): string {
  const normalize = (file: string) => platform === "win32" ? file.replace(/\\/g, "/") : file;
  const escape = (file: string) => `'${normalize(file).replace(/'/g, "'\\''")}'`;
  return ["ffconcat version 1.0", ...files.map((file) => `file ${escape(file)}`), ""].join("\n");
}

export function buildFfconcatChapterContent(
  file: string,
  chapters: Array<{ startSeconds: number; endSeconds: number }>,
  platform = process.platform,
): string {
  const normalize = platform === "win32" ? file.replace(/\\/g, "/") : file;
  const escaped = `'${normalize.replace(/'/g, "'\\''")}'`;
  const lines = ["ffconcat version 1.0"];
  for (const chapter of chapters) {
    lines.push(`file ${escaped}`, `inpoint ${chapter.startSeconds}`, `outpoint ${chapter.endSeconds}`);
  }
  return `${lines.join("\n")}\n`;
}

export type FfconcatTimedSegment = { file: string; startSeconds?: number; endSeconds?: number };

export function buildFfconcatTimedContent(segments: FfconcatTimedSegment[], platform = process.platform): string {
  const normalize = (file: string) => platform === "win32" ? file.replace(/\\/g, "/") : file;
  const escape = (file: string) => `'${normalize(file).replace(/'/g, "'\\''")}'`;
  const lines = ["ffconcat version 1.0"];
  for (const segment of segments) {
    lines.push(`file ${escape(segment.file)}`);
    if (segment.startSeconds !== undefined) lines.push(`inpoint ${segment.startSeconds}`);
    if (segment.endSeconds !== undefined) lines.push(`outpoint ${segment.endSeconds}`);
  }
  return `${lines.join("\n")}\n`;
}
