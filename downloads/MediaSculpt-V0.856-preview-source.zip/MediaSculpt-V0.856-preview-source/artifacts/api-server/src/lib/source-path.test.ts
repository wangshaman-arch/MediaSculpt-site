import { describe, expect, it } from "vitest";
import { mediaInfoDirectoryForSource } from "./source-path";

describe("mediaInfoDirectoryForSource", () => {
  it("keeps POSIX roots when a macOS source is a disc folder", () => {
    expect(mediaInfoDirectoryForSource("/Volumes/Archive/The.Making.of.King.Arthur/VIDEO_TS"))
      .toBe("/Volumes/Archive/The.Making.of.King.Arthur/MediaInfo");
  });

  it("uses Windows path semantics for drive-letter sources", () => {
    expect(mediaInfoDirectoryForSource("C:\\Archive\\Film\\VIDEO_TS"))
      .toBe("C:\\Archive\\Film\\MediaInfo");
  });
});
