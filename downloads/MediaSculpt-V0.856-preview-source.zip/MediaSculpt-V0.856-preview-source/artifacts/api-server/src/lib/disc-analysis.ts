import { createHash } from "node:crypto";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs/promises";
import type { Dirent } from "node:fs";
import os from "node:os";
import path from "node:path";
import {
  parseHandBrakeScanOutput,
  type HandBrakeChapter,
  type HandBrakeStream,
  type HandBrakeTitle,
} from "./handbrake-scan";
import {
  findDvdTitles,
  dvdTitleInputArgs,
  resolveDvdVideoTsDir,
  scanBlurayPlaylists,
  type BlurayPlaylistInfo,
  type DvdTitle,
} from "./disc";
import { resolveToolPath } from "./tool-runtime";
import {
  analyzeDvdWithHandBrake,
  verifyDvdTitle,
  type ExternalToolRunner,
} from "./dvd-remux";
import { buildDvdStreamUid, buildDvdTitleUid } from "./dvd-manifest";
import { parseDvdNavigation, type DvdNavigationTitle } from "./dvd-ifo-parser";

const execFileAsync = promisify(execFile);
const HANDBRAKE_SCAN_TIMEOUT_MS = 10 * 60_000;
const MAX_TOOL_BUFFER = 32 * 1024 * 1024;

export function safeNumber(value: unknown): number | null {
  const result = Number(value);
  return Number.isFinite(result) ? result : null;
}

function buildBlurayPreviewSegments(
  playlist: BlurayPlaylistInfo,
): DiscPreviewSegment[] {
  let startSeconds = 0;
  return playlist.segments.flatMap((segment) => {
    const durationSeconds =
      Math.max(0, segment.outTime45k - segment.inTime45k) / 45_000;
    if (!Number.isFinite(durationSeconds) || durationSeconds <= 0) return [];
    const previewSegment = {
      sourcePath: segment.streamPath,
      startSeconds,
      endSeconds: startSeconds + durationSeconds,
    };
    startSeconds += durationSeconds;
    return [previewSegment];
  });
}

export type DiscMediaType = "dvd" | "bluray";
export type DiscToolName = "handbrake" | "ffprobe";
export type DiscAnalysisTrackType = "video" | "audio" | "subtitle" | "unknown";

export type DiscAnalysisStream = {
  index: number;
  trackUid?: string;
  codecType: DiscAnalysisTrackType;
  codecName: string | null;
  /** ffprobe stream profile (e.g. "DTS-HD MA", "High 10") or null. */
  profile?: string | null;
  /** Tool-provided human description (e.g. HandBrake "DTS-HD MA, 5.1 ch"). */
  description?: string | null;
  language: string | null;
  title: string | null;
  width?: number | null;
  height?: number | null;
  channels?: number | null;
  channelLayout?: string | null;
  sampleRate?: number | null;
  bitrate?: number | null;
  estimatedSizeBytes?: number | null;
  bitsPerRawSample?: number | null;
  frameRate?: string | null;
  handbrakeTrackNumber?: number | null;
  default?: boolean;
  forced?: boolean;
};

export type DiscAnalysisChapter = {
  id: number;
  startSeconds: number;
  endSeconds: number;
  title: string | null;
};

export type DiscPhysicalRange = {
  path: string;
  startByte: number;
  endByte: number;
};

export type DiscToolDiagnostic = {
  tool: DiscToolName;
  executable: string | null;
  args: string[];
  startedAt: string;
  finishedAt: string;
  durationMs: number;
  exitCode: number | null;
  stdout: string;
  stderr: string;
  failureReason: string | null;
};

export type DiscToolDiagnosticSummary = Omit<
  DiscToolDiagnostic,
  "stdout" | "stderr"
> & {
  stdoutBytes: number;
  stderrBytes: number;
};

export type UnifiedDiscTitle = {
  titleId: string;
  titleUid?: string;
  titleIndex: number;
  sourcePath: string;
  /** Playlist-less m2ts fallback vs HandBrake-scan compression title. */
  titleKind?: "m2ts" | "handbrake" | null;
  /** File used to render preview frames when sourcePath is a disc root. */
  previewSourcePath?: string | null;
  /** Ordered Blu-ray stream segments with playlist-relative time ranges. */
  previewSegments?: DiscPreviewSegment[];
  displayName: string;
  durationSeconds: number | null;
  chapterCount: number;
  chapters: DiscAnalysisChapter[];
  videoTracks: DiscAnalysisStream[];
  audioTracks: DiscAnalysisStream[];
  subtitleTracks: DiscAnalysisStream[];
  estimatedSize: number | null;
  /** Exact physical VOB ranges proven by IFO/PGC/Cell navigation. */
  physicalRanges?: DiscPhysicalRange[];
  /** IFO/PGC duration and chapters must survive later stream verification. */
  dvdNavigationDurationSeconds?: number | null;
  dvdNavigationChapters?: DiscAnalysisChapter[];
  streams: DiscAnalysisStream[];
  toolMappings: {
    handbrakeTitleNumber: number | null;
    makemkvTitleIndex: number | null;
    playlistId?: string | null;
    /** Logical dvdvideo/HandBrake title number used for navigation and jobs. */
    dvdVtsNumber: number | null;
    /** Physical VTS file group, only when an exact IFO/PGC mapping is known. */
    physicalVtsNumber?: number | null;
  };
  mappingStatus: "not-required" | "unmapped";
  verificationStatus?: "pending" | "verified" | "failed";
  verificationFailureReason?: string | null;
  verificationWarnings?: string[];
  availabilityStatus?: "confirmed" | "unavailable";
  availabilityFailureReason?: string | null;
};

export type DiscPreviewSegment = {
  sourcePath: string;
  startSeconds: number;
  endSeconds: number;
};

/** Menus/stubs and ultra-short clips are noise for title selection. */
export const MIN_DISC_TITLE_SECONDS = 10;
/** Keep the main feature plus the most substantial extras. */
export const MAX_DISC_TITLES = 15;

/**
 * Consolidate a disc's title list so the user sees a usable set: drop menu
 * stubs/very short fragments, sort the longest (main) title first, and cap
 * the list so discs with dozens of HandBrake PGCs do not flood the UI.
 */
export function consolidateDiscTitles(
  titles: UnifiedDiscTitle[],
  log?: (message: string) => void,
  options?: { preserveAll?: boolean },
): UnifiedDiscTitle[] {
  const meaningful = titles.filter(
    (title) =>
      ((title.videoTracks?.length ?? 0) > 0 ||
        title.availabilityStatus === "unavailable") &&
      (title.durationSeconds ?? 0) >= MIN_DISC_TITLE_SECONDS,
  );
  const longestUnavailable = meaningful.reduce(
    (longest, title) =>
      title.availabilityStatus === "unavailable"
        ? Math.max(longest, title.durationSeconds ?? 0)
        : longest,
    0,
  );
  // If the only readable candidates are tiny clips while a much longer
  // playlist is known but unavailable, do not let a menu/preview clip appear
  // to be the main title. The unavailable playlist is the deterministic result
  // and carries the exact missing-file reason for the user.
  const hasDominantUnavailableTitle =
    longestUnavailable >= 600 &&
    meaningful.some((title) => title.availabilityStatus !== "unavailable") &&
    meaningful
      .filter((title) => title.availabilityStatus !== "unavailable")
      .every(
        (title) => (title.durationSeconds ?? 0) < longestUnavailable * 0.5,
      );
  const filtered = hasDominantUnavailableTitle
    ? meaningful.filter((title) => title.availabilityStatus === "unavailable")
    : meaningful;
  const sorted = filtered
    .slice()
    .sort((a, b) => (b.durationSeconds ?? 0) - (a.durationSeconds ?? 0));
  if (!options?.preserveAll && sorted.length > MAX_DISC_TITLES) {
    const dropped = sorted.length - MAX_DISC_TITLES;
    log?.(
      `已折叠 ${dropped} 个短片/碎片标题，仅保留最长的主片与主要花絮（共 ${MAX_DISC_TITLES} 个）`,
    );
    return sorted.slice(0, MAX_DISC_TITLES);
  }
  return sorted;
}

export type MakeMkvExportCandidate = {
  makemkvTitleIndex: number;
  name: string;
  sourcePath: string;
  estimatedSize: number | null;
  durationSeconds: number | null;
  mappedTitleId: string | null;
  mappingStatus: "not-required" | "unmapped";
};

export type HandBrakeDiscScanResult = {
  titles: Array<{
    handbrakeTitleNumber: number;
    sourcePath: string;
    estimatedSize: number | null;
    durationSeconds: number | null;
    streams: DiscAnalysisStream[];
    chapters: DiscAnalysisChapter[];
  }>;
};

export type DiscAnalysisResult = {
  analysisId: string;
  sourcePath: string;
  /** Original ISO file path when the analysis was created from an ISO image. */
  isoPath?: string;
  sourceFingerprint: string;
  /** Total bytes physically present under DVD VIDEO_TS; title sizes may overlap this payload. */
  sourceSizeBytes?: number | null;
  mediaType: DiscMediaType;
  createdAt: string;
  titles: UnifiedDiscTitle[];
  exportCandidates: MakeMkvExportCandidate[];
  diagnostics: DiscToolDiagnostic[];
  diagnosticLogPath: string | null;
  warnings: string[];
};

export type CachedDiscAnalysis<T> = {
  value: T;
  cached: boolean;
  shared: boolean;
};

type CacheEntry<T> = { value: T; createdAtMs: number };

export class DiscAnalysisCache<T> {
  private readonly entries = new Map<string, CacheEntry<T>>();
  private readonly inFlight = new Map<string, Promise<T>>();

  constructor(private readonly maxAgeMs = 5 * 60_000) {}

  async getOrAnalyze(
    input: { cacheKey: string; force: boolean },
    analyze: () => Promise<T>,
  ): Promise<CachedDiscAnalysis<T>> {
    const now = Date.now();
    const cached = this.entries.get(input.cacheKey);
    if (!input.force && cached && now - cached.createdAtMs <= this.maxAgeMs) {
      return { value: cached.value, cached: true, shared: false };
    }

    const active = this.inFlight.get(input.cacheKey);
    if (active) return { value: await active, cached: false, shared: true };

    const activeAnalysis = Promise.resolve().then(analyze);
    this.inFlight.set(input.cacheKey, activeAnalysis);
    try {
      const value = await activeAnalysis;
      this.entries.set(input.cacheKey, { value, createdAtMs: Date.now() });
      return { value, cached: false, shared: false };
    } finally {
      this.inFlight.delete(input.cacheKey);
    }
  }

  clear(): void {
    this.entries.clear();
  }
}

export function normalizeDiscSourcePath(sourcePath: string): string {
  const resolved = path.resolve(sourcePath);
  const base = path.basename(resolved).toUpperCase();
  return base === "VIDEO_TS" || base === "BDMV"
    ? path.dirname(resolved)
    : resolved;
}

export function buildDiscAnalysisId(input: {
  sourcePath: string;
  sourceFingerprint: string;
}): string {
  return `disc-${createHash("sha256")
    .update(
      `${normalizeDiscSourcePath(input.sourcePath).replace(/\\/g, "/").toLowerCase()}\n${input.sourceFingerprint}`,
    )
    .digest("hex")
    .slice(0, 24)}`;
}

export function buildDiscAnalysisCacheKey(input: {
  sourcePath: string;
  sourceFingerprint: string;
  mediaType: DiscMediaType;
}): string {
  return `${input.mediaType}:${buildDiscAnalysisId(input)}`;
}

export function buildFfprobeAnalysisArgs(
  sourcePath: string,
  inputArgs?: string[],
): string[] {
  return [
    "-v",
    "error",
    "-print_format",
    "json",
    "-show_streams",
    "-show_format",
    "-show_chapters",
    ...(inputArgs ?? [
      process.platform === "win32"
        ? sourcePath.replace(/\\/g, "/")
        : sourcePath,
    ]),
  ];
}

function toDiscStream(stream: HandBrakeStream): DiscAnalysisStream {
  return {
    index: stream.index,
    codecType: stream.codecType,
    codecName: stream.codecName,
    ...(stream.description ? { description: stream.description } : {}),
    language: stream.language ?? null,
    title: stream.title ?? null,
    ...("width" in stream
      ? {
          width: stream.width ?? null,
          height: stream.height ?? null,
          frameRate: stream.frameRate ?? null,
        }
      : {}),
    ...("bitrate" in stream
      ? {
          bitrate: (stream as { bitrate?: number | null }).bitrate ?? null,
          estimatedSizeBytes:
            "estimatedSizeBytes" in stream
              ? ((stream as { estimatedSizeBytes?: number | null })
                  .estimatedSizeBytes ?? null)
              : null,
        }
      : {}),
    ...("channels" in stream
      ? {
          channels: stream.channels ?? null,
          channelLayout: stream.channelLayout ?? null,
          sampleRate: stream.sampleRate ?? null,
          bitrate:
            "bitrate" in stream
              ? ((stream as { bitrate?: number | null }).bitrate ?? null)
              : null,
          estimatedSizeBytes:
            "estimatedSizeBytes" in stream
              ? ((stream as { estimatedSizeBytes?: number | null })
                  .estimatedSizeBytes ?? null)
              : null,
          bitsPerRawSample:
            "bitsPerRawSample" in stream
              ? ((stream as { bitsPerRawSample?: number | null })
                  .bitsPerRawSample ?? null)
              : null,
        }
      : {}),
    ...("handbrakeTrackNumber" in stream
      ? { handbrakeTrackNumber: stream.handbrakeTrackNumber ?? null }
      : {}),
  };
}

/**
 * Fill in per-stream size estimates when the tool result did not provide them:
 * known bitrates are multiplied by the title duration; a video stream without
 * bitrate approximates the whole title size (video dominates disc payloads).
 * Existing estimates are preserved.
 */
export function fillStreamSizeEstimates(
  streams: DiscAnalysisStream[],
  durationSeconds: number | null,
  estimatedTitleSize: number | null,
): DiscAnalysisStream[] {
  const estimates = streams.map((stream) => {
    if (stream.estimatedSizeBytes && stream.estimatedSizeBytes > 0)
      return stream.estimatedSizeBytes;
    if (stream.bitrate && durationSeconds)
      return Math.round((stream.bitrate * durationSeconds) / 8);
    return null;
  });
  const unknownVideoIndexes = streams
    .map((stream, index) =>
      stream.codecType === "video" && estimates[index] === null ? index : -1,
    )
    .filter((index) => index >= 0);
  const targetSize =
    estimatedTitleSize && estimatedTitleSize > 0
      ? Math.floor(estimatedTitleSize)
      : null;
  if (targetSize !== null && unknownVideoIndexes.length > 0) {
    const knownTotal = estimates.reduce<number>(
      (sum, value) => sum + (value ?? 0),
      0,
    );
    const remaining = Math.max(0, targetSize - knownTotal);
    const share = Math.floor(remaining / unknownVideoIndexes.length);
    let remainder = remaining - share * unknownVideoIndexes.length;
    for (const index of unknownVideoIndexes) {
      estimates[index] = share + (remainder > 0 ? 1 : 0);
      remainder -= 1;
    }
  }
  if (targetSize !== null) {
    const total = estimates.reduce<number>(
      (sum, value) => sum + (value ?? 0),
      0,
    );
    if (total > targetSize && total > 0) {
      // Bitrate metadata can describe a logical title more than once. Scale
      // the display-only estimates so their sum never exceeds the physical
      // title size supplied by the caller.
      let remaining = targetSize;
      estimates.forEach((value, index) => {
        if (value === null) return;
        const scaled =
          index === estimates.length - 1
            ? remaining
            : Math.floor((value * targetSize) / total);
        estimates[index] = Math.max(0, Math.min(remaining, scaled));
        remaining -= estimates[index] ?? 0;
      });
    }
  }
  return streams.map((stream, index) => {
    const estimate = estimates[index];
    if (estimate === null) return stream;
    return {
      ...stream,
      estimatedSizeBytes: estimate,
      ...(stream.codecType === "video" && !stream.bitrate && durationSeconds
        ? { bitrate: Math.round((estimate * 8) / durationSeconds) }
        : {}),
    };
  });
}

/** Measure the physical DVD payload once; logical titles are allowed to share these bytes. */
export async function measureDvdSourceBytes(
  sourcePath: string,
): Promise<number | null> {
  const videoTsDir = await resolveDvdVideoTsDir(sourcePath);
  if (!videoTsDir) return null;
  const entries = await fs
    .readdir(videoTsDir, { withFileTypes: true })
    .catch(() => [] as Dirent[]);
  let total = 0;
  for (const entry of entries) {
    if (!entry.isFile()) continue;
    const stat = await fs
      .stat(path.join(videoTsDir, entry.name))
      .catch(() => null);
    if (stat) total += stat.size;
  }
  return total > 0 ? total : null;
}

function toDiscChapters(chapters: HandBrakeChapter[]): DiscAnalysisChapter[] {
  return chapters.map((chapter) => ({
    id: chapter.id,
    startSeconds: chapter.startSeconds,
    endSeconds: chapter.endSeconds,
    title: chapter.title,
  }));
}

function handBrakeResult(
  sourcePath: string,
  titles: HandBrakeTitle[],
): HandBrakeDiscScanResult {
  return {
    titles: titles.map((title) => ({
      handbrakeTitleNumber: title.titleNumber,
      sourcePath,
      estimatedSize: null,
      durationSeconds: title.durationSeconds,
      streams: fillStreamSizeEstimates(
        title.streams.map(toDiscStream),
        title.durationSeconds,
        null,
      ),
      chapters: toDiscChapters(title.chapters),
    })),
  };
}

function splitTracks(streams: DiscAnalysisStream[]) {
  return {
    videoTracks: streams.filter((stream) => stream.codecType === "video"),
    audioTracks: streams.filter((stream) => stream.codecType === "audio"),
    subtitleTracks: streams.filter((stream) => stream.codecType === "subtitle"),
  };
}

export async function buildDiscSourceFingerprint(
  sourcePath: string,
  mediaType: DiscMediaType,
): Promise<string> {
  const root = normalizeDiscSourcePath(sourcePath);
  const discDir =
    mediaType === "dvd" ? path.join(root, "VIDEO_TS") : path.join(root, "BDMV");
  const entries = await fs
    .readdir(discDir, { withFileTypes: true })
    .catch((): Dirent[] => []);
  const relevant = entries
    .filter(
      (entry) =>
        entry.isFile() &&
        (mediaType === "dvd"
          ? /\.(ifo|bup|vob)$/i.test(entry.name)
          : /\.(mpls|bdmv)$/i.test(entry.name)),
    )
    .sort((a, b) => a.name.localeCompare(b.name));
  const parts = await Promise.all(
    relevant.map(async (entry) => {
      const stat = await fs.stat(path.join(discDir, entry.name));
      return `${entry.name}:${stat.size}:${Math.floor(stat.mtimeMs)}`;
    }),
  );
  return createHash("sha256")
    .update([root, mediaType, ...parts].join("\n"))
    .digest("hex");
}

export async function persistDiscAnalysisDiagnostics(
  analysisId: string,
  diagnostics: DiscToolDiagnostic[],
): Promise<string> {
  // Keep diagnostics under the current product profile; legacy VX-Agent logs
  // may still be read by migration tooling, but are never appended to.
  const directory = path.join(
    os.homedir(),
    ".MediaSculpt",
    "logs",
    "disc-analysis",
  );
  const logPath = path.join(directory, `${analysisId}.log`);
  const content = diagnostics
    .map((diagnostic) =>
      [
        `[${diagnostic.tool}] executable=${diagnostic.executable ?? "<unavailable>"}`,
        `started=${diagnostic.startedAt} finished=${diagnostic.finishedAt} durationMs=${diagnostic.durationMs} exitCode=${diagnostic.exitCode ?? "n/a"}`,
        `args=${JSON.stringify(diagnostic.args)}`,
        `failure=${diagnostic.failureReason ?? "<none>"}`,
        "--- stdout ---",
        diagnostic.stdout,
        "--- stderr ---",
        diagnostic.stderr,
        "",
      ].join("\n"),
    )
    .join("\n");
  await fs.mkdir(directory, { recursive: true });
  await fs.writeFile(logPath, content, "utf8");
  return logPath;
}

export function summarizeDiscDiagnostics(
  diagnostics: DiscToolDiagnostic[],
): DiscToolDiagnosticSummary[] {
  return diagnostics.map(({ stdout, stderr, ...diagnostic }) => ({
    ...diagnostic,
    stdoutBytes: Buffer.byteLength(stdout),
    stderrBytes: Buffer.byteLength(stderr),
  }));
}

import { analyzeDvdWithFfprobeFallback } from "./disc-analysis-dvd";
export { analyzeDvdWithFfprobeFallback } from "./disc-analysis-dvd";

export async function analyzeDiscSource(input: {
  sourcePath: string;
  mediaType: DiscMediaType;
  sourceFingerprint: string;
  handbrakeCliPath?: string | null;
  toolRunner?: ExternalToolRunner;
}): Promise<DiscAnalysisResult> {
  if (input.mediaType === "dvd") {
    const handbrakeExecutable =
      input.handbrakeCliPath || (await resolveToolPath("handbrake"));
    const analysisId = buildDiscAnalysisId(input);
    if (!handbrakeExecutable) {
      const now = new Date().toISOString();
      const diagnostics: DiscToolDiagnostic[] = [
        {
          tool: "handbrake",
          executable: null,
          args: [
            "--input",
            input.sourcePath,
            "--title",
            "0",
            "--scan",
            "--json",
          ],
          startedAt: now,
          finishedAt: now,
          durationMs: 0,
          exitCode: null,
          stdout: "",
          stderr: "",
          failureReason: "HandBrakeCLI 未安装或不可执行",
        },
      ];
      const diagnosticLogPath = await persistDiscAnalysisDiagnostics(
        analysisId,
        diagnostics,
      ).catch(() => null);
      return {
        analysisId,
        sourcePath: input.sourcePath,
        sourceFingerprint: input.sourceFingerprint,
        mediaType: "dvd",
        createdAt: now,
        titles: [],
        exportCandidates: [],
        diagnostics,
        diagnosticLogPath,
        warnings: ["DVD 初始分析需要 HandBrakeCLI；本轮未调用 ffprobe 兜底。"],
      };
    }
    const startedAt = new Date();
    const result = await analyzeDvdWithHandBrake({
      sourcePath: input.sourcePath,
      sourceFingerprint: input.sourceFingerprint,
      handbrakeExecutable,
      run: input.toolRunner,
    });
    const finishedAt = new Date();
    const diagnostics: DiscToolDiagnostic[] = [
      {
        tool: "handbrake",
        executable: result.diagnostic.executable,
        args: result.diagnostic.args,
        startedAt: startedAt.toISOString(),
        finishedAt: finishedAt.toISOString(),
        durationMs: result.diagnostic.durationMs,
        exitCode: result.diagnostic.exitCode,
        stdout: result.diagnostic.stdout,
        stderr: result.diagnostic.stderr,
        failureReason: result.diagnostic.failureReason,
      },
    ];
    // DVD titles have no per-file preview source (ffprobe cannot open a
    // VIDEO_TS directory). Use the largest title's VOB set via the concat
    // protocol so the preview can extract real frames from the movie.
    // Type the fallback explicitly: a bare `() => []` infers `never[]`, which
    // makes the union `DvdTitle[] | never[]` collapse the `.find()` callback
    // parameter to `never` (TS2339 on the line below).
    const dvdVts: DvdTitle[] = await findDvdTitles(input.sourcePath).catch(
      () => [] as DvdTitle[],
    );
    const mainVts =
      dvdVts.slice().sort((a, b) => b.sizeBytes - a.sizeBytes)[0] ?? null;
    const dvdPreviewSourceForVts = (vtsNumber: number | null | undefined) => {
      const vts =
        typeof vtsNumber === "number"
          ? dvdVts.find((candidate) => candidate.titleNumber === vtsNumber)
          : null;
      const files = vts?.vobFiles ?? mainVts?.vobFiles ?? [];
      return files.length > 0
        ? `concat:${files.map((file) => file.replace(/\\/g, "/")).join("|")}`
        : null;
    };
    const dvdPreviewSource = dvdPreviewSourceForVts(null);
    const warnings: string[] = [];
    warnings.push(...(result.warnings ?? []));
    for (const title of dvdVts) {
      if (title.missingVobFiles?.length) {
        warnings.push(
          `光盘文件不完整：VIDEO_TS 缺少 ${title.missingVobFiles.join("、")}，` +
            `该光盘标题将在缺失文件处提前截断。请重新抓轨，或改用完整的 ISO 镜像处理。`,
        );
      }
    }
    const sourceSizeBytes = await measureDvdSourceBytes(input.sourcePath);
    // Do not collapse DVD titles by duration/chapter/stream signatures before
    // reading IFO/PGC/Cell navigation. Two independent physical clips can be
    // intentionally identical at the stream level; physical Cell ranges are
    // the only safe duplicate key for DVD titles.
    const titles: UnifiedDiscTitle[] = consolidateDiscTitles(
      result.titles.map((title) => {
        const titleNumber = title.toolMappings.handbrakeTitleNumber;
        const titleUid = buildDvdTitleUid({
          sourceFingerprint: input.sourceFingerprint,
          handbrakeTitleNumber: titleNumber,
        });
        const streams = title.streams.map((stream, index) => ({
          ...stream,
          ...(stream.codecType !== "unknown"
            ? {
                trackUid: buildDvdStreamUid({
                  titleUid,
                  type: stream.codecType,
                  ordinal: title.streams
                    .slice(0, index)
                    .filter(
                      (candidate) => candidate.codecType === stream.codecType,
                    ).length,
                  codecName: stream.codecName,
                  language: stream.language,
                  channels: stream.channels,
                }),
              }
            : {}),
        }));
        return {
          ...title,
          titleUid,
          streams,
          videoTracks: streams.filter((stream) => stream.codecType === "video"),
          audioTracks: streams.filter((stream) => stream.codecType === "audio"),
          subtitleTracks: streams.filter(
            (stream) => stream.codecType === "subtitle",
          ),
          availabilityStatus: title.availabilityStatus ?? "confirmed",
          availabilityFailureReason: title.availabilityFailureReason ?? null,
          previewSourcePath: dvdPreviewSource,
          verificationStatus:
            title.availabilityStatus === "unavailable"
              ? ("failed" as const)
              : ("pending" as const),
          verificationFailureReason: title.availabilityFailureReason ?? null,
          mappingStatus: "unmapped" as const,
        };
      }),
      (message) => warnings.push(message),
      { preserveAll: true },
    );
    // The only authoritative DVD title identity is VMG title -> VTS TTN ->
    // PGC -> Cell. HandBrake remains the stream probe, but duration-based or
    // VTS-size-based title matching is forbidden because one VTS can contain
    // several different PGCs (or the same chain repeated with different names).
    const videoTsDir =
      (await resolveDvdVideoTsDir(input.sourcePath)) ?? input.sourcePath;
    let navigationTitles: DvdNavigationTitle[] = [];
    try {
      navigationTitles = await parseDvdNavigation(videoTsDir);
    } catch (error) {
      warnings.push(
        `DVD IFO/PGC 导航解析失败：${error instanceof Error ? error.message : String(error)}；已停止使用猜测式容量和物理标题映射`,
      );
    }
    if (navigationTitles.length > 0) {
      const navigationByTitle = new Map(
        navigationTitles.map((navigation) => [
          navigation.globalTitleNumber,
          navigation,
        ]),
      );
      const mappedTitles: UnifiedDiscTitle[] = [];
      const seenPhysicalChains = new Set<string>();
      let unmappedCount = 0;
      let duplicateCount = 0;
      for (const title of titles) {
        const titleNumber = title.toolMappings.handbrakeTitleNumber;
        const navigation = titleNumber
          ? navigationByTitle.get(titleNumber)
          : undefined;
        if (
          !navigation ||
          navigation.sizeBytes <= 0 ||
          navigation.physicalRanges.length === 0
        ) {
          unmappedCount += 1;
          continue;
        }
        const chainKey = navigation.physicalRanges
          .map(
            (range) => `${range.path}:${range.startSector}-${range.endSector}`,
          )
          .sort()
          .join("|");
        if (seenPhysicalChains.has(chainKey)) {
          duplicateCount += 1;
          continue;
        }
        seenPhysicalChains.add(chainKey);
        title.toolMappings.physicalVtsNumber = navigation.vtsNumber;
        title.previewSourcePath = dvdPreviewSourceForVts(navigation.vtsNumber);
        title.estimatedSize = navigation.sizeBytes;
        title.physicalRanges = navigation.physicalRanges.map((range) => ({
          path: range.path,
          startByte: range.startByte,
          endByte: range.endByte,
        }));
        title.mappingStatus = "not-required";
        if (navigation.durationSeconds != null) {
          if (
            title.durationSeconds != null &&
            Math.abs(title.durationSeconds - navigation.durationSeconds) > 5
          ) {
            warnings.push(
              `DVD Title ${titleNumber} 的 HandBrake 时长与 IFO/PGC 时长相差 ${Math.abs(title.durationSeconds - navigation.durationSeconds).toFixed(1)} 秒；已采用 IFO/PGC 时长`,
            );
          }
          title.durationSeconds = navigation.durationSeconds;
          title.dvdNavigationDurationSeconds = navigation.durationSeconds;
        }
        if (navigation.chapters.length > 0) {
          title.chapters = navigation.chapters.map((chapter) => ({
            ...chapter,
            title: null,
          }));
          title.chapterCount = title.chapters.length;
          title.dvdNavigationChapters = title.chapters;
        }
        mappedTitles.push(title);
      }
      titles.length = 0;
      titles.push(...mappedTitles);
      if (unmappedCount > 0)
        warnings.push(
          `DVD IFO/PGC 未能证明 ${unmappedCount} 个 HandBrake title 的物理 Cell 范围；这些标题已从可导出列表移除`,
        );
      if (duplicateCount > 0)
        warnings.push(
          `DVD IFO/PGC 确认并移除 ${duplicateCount} 条完全重复的物理 Cell 播放链`,
        );
    } else {
      warnings.push(
        "DVD 未获得可验证的 IFO/PGC/Cell 标题映射；标题容量保持未知，禁止按 VTS 总大小或时长猜测",
      );
    }
    // Complete the deterministic analysis before returning it. HandBrake's
    // scan describes logical titles, but it does not prove that a title is
    // readable by the actual dvdvideo demuxer. Leaving every title pending
    // made the main feature on multi-VOB concert DVDs look like a failed scan.
    const ffprobeExecutable = await resolveToolPath("ffprobe");
    if (ffprobeExecutable && titles.length > 0) {
      for (const title of titles) {
        const titleNumber = title.toolMappings.handbrakeTitleNumber;
        if (!titleNumber || titleNumber <= 0) continue;
        const verification = await verifyDvdTitle({
          sourcePath: input.sourcePath,
          titleNumber,
          handbrakeDurationSeconds: title.durationSeconds,
          handbrakeChapterCount: title.chapterCount,
          handbrakeStreams: title.streams,
          ffprobeExecutable,
          run: input.toolRunner,
        });
        diagnostics.push({
          tool: "ffprobe",
          executable: verification.diagnostic.executable,
          args: verification.diagnostic.args,
          startedAt: new Date(
            Date.now() - verification.diagnostic.durationMs,
          ).toISOString(),
          finishedAt: new Date().toISOString(),
          durationMs: verification.diagnostic.durationMs,
          exitCode: verification.diagnostic.exitCode,
          stdout: verification.diagnostic.stdout,
          stderr: verification.diagnostic.stderr,
          failureReason:
            verification.failureReason ?? verification.diagnostic.failureReason,
        });
        title.verificationStatus = verification.verified
          ? "verified"
          : "failed";
        title.verificationFailureReason = verification.failureReason;
        title.verificationWarnings = verification.warnings;
        if (!verification.verified) continue;
        const verifiedStreams = verification.streams.map((stream, index) => ({
          ...stream,
          ...(stream.codecType !== "unknown"
            ? {
                trackUid: buildDvdStreamUid({
                  titleUid: title.titleUid ?? "",
                  type: stream.codecType,
                  ordinal: verification.streams
                    .slice(0, index)
                    .filter(
                      (candidate) => candidate.codecType === stream.codecType,
                    ).length,
                  codecName: stream.codecName,
                  language: stream.language,
                  channels: stream.channels,
                }),
              }
            : {}),
        }));
        title.toolMappings.dvdVtsNumber = titleNumber;
        title.durationSeconds =
          title.dvdNavigationDurationSeconds ??
          verification.durationSeconds ??
          title.durationSeconds;
        title.chapters = title.dvdNavigationChapters ?? verification.chapters;
        title.chapterCount = title.chapters.length;
        title.streams = verifiedStreams;
        title.videoTracks = verifiedStreams.filter(
          (stream) => stream.codecType === "video",
        );
        title.audioTracks = verifiedStreams.filter(
          (stream) => stream.codecType === "audio",
        );
        title.subtitleTracks = verifiedStreams.filter(
          (stream) => stream.codecType === "subtitle",
        );
      }
    }
    // Always augment with the ffprobe dvdvideo title probe: HandBrakeCLI's
    // --scan --json is not reliably parsed (1.11.x outputs no "JSON Title Set"
    // marker) so we cannot trust a 0-title result to mean "no titles". The
    // ffprobe probe enumerates VIDEO_TS titles and reads streams directly.
    const ffprobeTitles =
      titles.length === 0
        ? await analyzeDvdWithFfprobeFallback(
            input.sourcePath,
            input.sourceFingerprint,
          ).catch(() => null)
        : null;
    if (ffprobeTitles && ffprobeTitles.titles.length > 0) {
      const probed = consolidateDiscTitles(
        ffprobeTitles.titles,
        (message) => warnings.push(message),
        { preserveAll: true },
      );
      for (const probeTitle of probed) {
        if (
          !titles.some(
            (title) =>
              title.toolMappings.dvdVtsNumber ===
              probeTitle.toolMappings.dvdVtsNumber,
          )
        ) {
          titles.push(probeTitle);
        }
      }
      if (ffprobeTitles.diagnostic) diagnostics.push(ffprobeTitles.diagnostic);
    }
    if (titles.length === 0) {
      warnings.push(
        `HandBrakeCLI 未返回可用 DVD 标题：${result.diagnostic.failureReason ?? `退出码 ${result.diagnostic.exitCode ?? "未知"}`}`,
      );
    }
    const diagnosticLogPath = await persistDiscAnalysisDiagnostics(
      analysisId,
      diagnostics,
    ).catch(() => null);
    return {
      analysisId,
      sourcePath: input.sourcePath,
      sourceFingerprint: input.sourceFingerprint,
      sourceSizeBytes,
      mediaType: "dvd",
      createdAt: startedAt.toISOString(),
      titles,
      exportCandidates: [],
      diagnostics,
      diagnosticLogPath,
      warnings,
    };
  }

  const handbrakeExecutable =
    input.handbrakeCliPath || (await resolveToolPath("handbrake"));
  const ffprobe = await resolveToolPath("ffprobe");
  const startedAt = new Date();
  const playlists = await scanBlurayPlaylists(input.sourcePath);
  const titles: UnifiedDiscTitle[] = [];
  const analysisNotes: string[] = [];
  const diagnostics: DiscToolDiagnostic[] = [
    {
      tool: "ffprobe",
      executable: ffprobe,
      args: ["-show_streams", "-show_format", "-show_chapters"],
      startedAt: startedAt.toISOString(),
      finishedAt: new Date().toISOString(),
      durationMs: 0,
      exitCode: playlists.length > 0 ? 0 : 1,
      stdout: "",
      stderr: "",
      failureReason:
        playlists.length > 0 ? null : "BDMV/PLAYLIST 未解析到播放列表",
    },
  ];
  for (const [index, playlist] of playlists.entries()) {
    const streams = ffprobe
      ? await probeBlurayTitleStreams(ffprobe, playlist)
      : [];
    const firstSegmentPath = playlist.segments[0]?.streamPath ?? null;
    const probedDuration =
      firstSegmentPath && ffprobe && playlist.durationSeconds == null
        ? await probeBlurayStreamDuration(ffprobe, firstSegmentPath)
        : null;
    titles.push({
      titleId: `mpls:${playlist.playlistId}`,
      titleIndex: index,
      titleKind: "m2ts",
      sourcePath: playlist.mplsPath,
      previewSourcePath: firstSegmentPath,
      previewSegments: buildBlurayPreviewSegments(playlist),
      displayName: buildBlurayTitleDisplayName({
        kind: "playlist",
        index,
        playlistId: playlist.playlistId,
      }),
      durationSeconds: playlist.durationSeconds ?? probedDuration,
      chapterCount: playlist.chapterCount,
      chapters: playlist.chapters.map((chapter) => ({
        id: chapter.id,
        startSeconds: chapter.startSeconds,
        endSeconds: chapter.endSeconds,
        title: chapter.title,
      })),
      estimatedSize: playlist.sizeBytes,
      streams,
      videoTracks: streams.filter((stream) => stream.codecType === "video"),
      audioTracks: streams.filter((stream) => stream.codecType === "audio"),
      subtitleTracks: streams.filter(
        (stream) => stream.codecType === "subtitle",
      ),
      availabilityStatus:
        playlist.missingSegments.length > 0 ? "unavailable" : "confirmed",
      availabilityFailureReason:
        playlist.missingSegments.length > 0
          ? `播放列表 ${playlist.playlistId} 缺少源文件：${playlist.missingSegments
              .map((file) => path.basename(file))
              .join(", ")}`
          : null,
      toolMappings: {
        handbrakeTitleNumber: null,
        makemkvTitleIndex: null,
        dvdVtsNumber: null,
        playlistId: playlist.playlistId,
      },
      mappingStatus: "not-required",
    });
    if (playlist.missingSegments.length > 0) {
      analysisNotes.push(
        `播放列表 ${playlist.playlistId} 不可读取：缺少源文件 ${playlist.missingSegments
          .map((file) => path.basename(file))
          .join(", ")}`,
      );
    }
  }
  // Authoring tools sometimes ship several playlists pointing at the same
  // content (identical duration, size and stream signature). Keep only the
  // first copy so the title list never shows "identical" entries.
  const seenTitles = new Set<string>();
  for (let index = titles.length - 1; index >= 0; index -= 1) {
    const title = titles[index];
    const signature = [
      title.durationSeconds ?? "",
      title.estimatedSize ?? "",
      title.streams
        .map((stream) =>
          [
            stream.codecType,
            stream.codecName ?? "",
            stream.profile ?? "",
            stream.description ?? "",
            stream.language ?? "",
            stream.channels ?? "",
            stream.bitrate ?? "",
          ].join("|"),
        )
        .join(";"),
    ].join("#");
    if (seenTitles.has(signature)) {
      titles.splice(index, 1);
    } else {
      seenTitles.add(signature);
    }
  }
  if (titles.length === 0) {
    const fallbackTitles = await fallbackBlurayStreamTitles(
      input.sourcePath,
      ffprobe,
    );
    titles.push(...fallbackTitles);
  }
  // HandBrake's own title grouping is required for compression (it owns the
  // title numbers), so it runs for every Blu-ray regardless of whether
  // playlists were parsed. Playlist titles stay available for Remux/preview.
  if (handbrakeExecutable) {
    const hbScan = await scanBlurayWithHandBrake(
      input.sourcePath,
      handbrakeExecutable,
    );
    diagnostics.push(hbScan.diagnostic);
    if (hbScan.titles.length > 0) {
      const baseIndex = titles.length;
      titles.push(
        ...handBrakeTitlesToUnified(
          input.sourcePath,
          hbScan.titles,
          titles,
          baseIndex,
        ),
      );
      // HandBrake lists the same content twice when a disc carries duplicate
      // playlists (e.g. 00000/01007). Collapse entries with the same duration
      // and stream signature, keeping the one with the richer chapter layout.
      const handbrakeSeen = new Map<string, UnifiedDiscTitle>();
      for (const title of titles) {
        if (title.titleKind !== "handbrake") continue;
        const signature = [
          Math.round((title.durationSeconds ?? 0) * 10),
          title.streams
            .map((stream) =>
              [
                stream.codecType,
                stream.codecName ?? "",
                stream.language ?? "",
                stream.channels ?? "",
              ].join("|"),
            )
            .join(";"),
        ].join("#");
        const existing = handbrakeSeen.get(signature);
        if (
          !existing ||
          (title.chapterCount ?? 0) > (existing.chapterCount ?? 0)
        ) {
          handbrakeSeen.set(signature, title);
        }
      }
      const keptHandbrake = Array.from(handbrakeSeen.values());
      if (
        keptHandbrake.length <
        titles.filter((title) => title.titleKind === "handbrake").length
      ) {
        const handbrakeSet = new Set(keptHandbrake);
        for (let index = titles.length - 1; index >= 0; index -= 1) {
          if (
            titles[index].titleKind === "handbrake" &&
            !handbrakeSet.has(titles[index])
          ) {
            titles.splice(index, 1);
          }
        }
      }
    }
  }
  // Final consolidation: merge cross-tool duplicates first, then remove menu
  // stubs, put the main feature first, and cap the usable title list.
  const mplsTitles = titles.filter((title) => title.titleKind !== "handbrake");
  const handbrakeTitles = titles.filter(
    (title) => title.titleKind === "handbrake",
  );
  const mergedTitles = mergeBluRayToolTitles(mplsTitles, handbrakeTitles);
  const consolidatedTitles = consolidateDiscTitles(mergedTitles, (message) =>
    analysisNotes.push(message),
  );
  titles.length = 0;
  titles.push(...consolidatedTitles);
  const warnings = [
    ...analysisNotes,
    ...(titles.length > 0
      ? playlists.length > 0
        ? []
        : [
            "未解析到蓝光播放列表，已将 BDMV/STREAM 中的 m2ts 片段作为标题（无章节信息，预览与无损封装仍可用）。",
          ]
      : ["未从 BDMV/PLAYLIST 解析到可用蓝光标题；请检查光盘结构和诊断日志。"]),
  ];
  const diagnosticLogPath = await persistDiscAnalysisDiagnostics(
    buildDiscAnalysisId(input),
    diagnostics,
  ).catch(() => null);
  return {
    analysisId: buildDiscAnalysisId(input),
    sourcePath: input.sourcePath,
    sourceFingerprint: input.sourceFingerprint,
    mediaType: input.mediaType,
    createdAt: startedAt.toISOString(),
    titles,
    exportCandidates: [],
    diagnostics,
    diagnosticLogPath,
    warnings,
  };
}

import {
  buildBlurayTitleDisplayName,
  probeBlurayTitleStreams,
  probeBlurayStreamDuration,
  fallbackBlurayStreamTitles,
  scanBlurayWithHandBrake,
  handBrakeTitlesToUnified,
  mergeBluRayToolTitles,
} from "./disc-analysis-bluray";
