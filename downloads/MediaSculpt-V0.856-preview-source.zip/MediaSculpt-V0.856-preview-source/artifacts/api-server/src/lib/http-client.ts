import http from "node:http";
import https from "node:https";
import net from "node:net";
import tls from "node:tls";
import { URL } from "node:url";

export type FetchLike = { ok: boolean; body?: AsyncIterable<Uint8Array> | null };

export type JsonResponseLike = {
  ok: boolean;
  status: number;
  text: () => Promise<string>;
  json: <T = unknown>() => Promise<T>;
};

/**
 * 本地代理常见监听端口（按优先级排列）：12334 Hiddify、10809/10808 v2rayN、
 * 7890/7897 Clash 与 Clash Verge、1080 通用、8118 Privoxy、8080 备用。
 * 端口被监听并不等于它是 HTTP 代理，因此探测时还会真实发起一次 CONNECT 校验。
 */
export const LOCAL_PROXY_CANDIDATE_PORTS = [12334, 10809, 7890, 7897, 1080, 8118, 10808, 12337, 8080] as const;

const PROXY_PROBE_CONNECT_TIMEOUT_MS = 300;
const PROXY_PROBE_RESPONSE_TIMEOUT_MS = 1_200;
const PROXY_POSITIVE_TTL_MS = 5 * 60_000;
const PROXY_NEGATIVE_TTL_MS = 15_000;

let cachedProxyProbe: { url: string | null; at: number } | null = null;

/** 校验某个端口是否真的按 HTTP 代理应答 CONNECT（排除恰好占用端口的普通本地服务）。 */
async function probeHttpProxyPort(port: number): Promise<boolean> {
  return new Promise<boolean>((resolve) => {
    let settled = false;
    const finish = (value: boolean) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };
    const socket = net.createConnection({ host: "127.0.0.1", port, timeout: PROXY_PROBE_CONNECT_TIMEOUT_MS });
    let buffer = "";
    socket.once("connect", () => {
      socket.setTimeout(PROXY_PROBE_RESPONSE_TIMEOUT_MS);
      socket.write("CONNECT www.gstatic.com:443 HTTP/1.1\r\nHost: www.gstatic.com:443\r\n\r\n");
    });
    socket.on("data", (chunk) => {
      buffer += chunk.toString("latin1");
      const statusLine = buffer.split("\r\n", 1)[0]?.trim() ?? "";
      if (!/^HTTP\/1\.[01] \d{3}\b/.test(statusLine)) return;
      socket.destroy();
      finish(/^HTTP\/1\.[01] 2\d\d\b/.test(statusLine));
    });
    socket.once("error", () => finish(false));
    socket.once("timeout", () => {
      socket.destroy();
      finish(false);
    });
    socket.once("close", () => finish(false));
  });
}

/** 并行探测候选端口，返回优先级最高的可用 HTTP 代理。 */
export async function detectLocalProxyUrl(
  candidatePorts: readonly number[] = LOCAL_PROXY_CANDIDATE_PORTS,
): Promise<string | null> {
  if (candidatePorts.length === 0) return null;
  const reachable = await Promise.all(candidatePorts.map((port) => probeHttpProxyPort(port)));
  const index = reachable.findIndex(Boolean);
  const port = index >= 0 ? candidatePorts[index] : undefined;
  return port === undefined ? null : `http://127.0.0.1:${port}`;
}

/** Resolve the configured or locally detected HTTP proxy for online lookups. */
export async function resolvePosterProxyUrl(configured?: string | null): Promise<string | null> {
  const explicit = configured?.trim() || process.env.MEDIASCULPT_POSTER_PROXY?.trim();
  if (explicit) return explicit;
  // Unit tests stub the global fetch implementation and must not be coupled
  // to whichever proxy happens to be running on the developer machine.
  if (process.env.NODE_ENV === "test") return null;

  // 探测最多约 1.5 秒且每个取图流程都会调用，因此缓存结果：
  // 命中代理后缓存久一些，未命中则短缓存，便于用户刚打开 VPN 时尽快生效。
  const now = Date.now();
  if (cachedProxyProbe) {
    const ttl = cachedProxyProbe.url ? PROXY_POSITIVE_TTL_MS : PROXY_NEGATIVE_TTL_MS;
    if (now - cachedProxyProbe.at < ttl) return cachedProxyProbe.url;
  }
  const url = await detectLocalProxyUrl();
  cachedProxyProbe = { url, at: now };
  return url;
}

/**
 * 在 CONNECT 隧道上建立到目标站点的连接。
 *
 * 这里有两个必须绕开的 Node 行为，二者都会让"配了代理却依然拿不到数据"：
 * 1. https.request 不会替 createConnection 返回的裸 socket 再做一次 TLS
 *    握手，请求会以明文写进隧道（对端只能回非 HTTP 字节，报解析错误）。
 * 2. 显式传 agent: false 时 createConnection 会被忽略，客户端退回直连
 *    目标站点，代理形同不存在。
 * 因此：不加 agent: false，并在这里自己完成 TLS。
 */
function openTunnelConnection(target: URL, socket: net.Socket): net.Socket {
  if (target.protocol === "http:") return socket;
  const options: tls.ConnectionOptions = { socket };
  // IP 字面量不能作为 SNI 主机名。
  if (net.isIP(target.hostname) === 0) options.servername = target.hostname;
  return tls.connect(options);
}

function parseJsonResponse(status: number, body: string): JsonResponseLike {
  return {
    ok: status >= 200 && status < 300,
    status,
    text: async () => body,
    json: async <T>() => JSON.parse(body) as T,
  };
}

/**
 * Make a JSON request with the same optional local proxy used by metadata and
 * poster lookups. Native fetch has no portable HTTP CONNECT setting on the
 * supported Node versions, so the proxy branch uses a small CONNECT tunnel.
 */
export async function requestJsonLike(
  targetUrl: string,
  options: { method?: string; headers?: Record<string, string>; body?: string },
  proxyUrl: string | null,
  timeoutMs: number,
): Promise<JsonResponseLike | null> {
  if (!proxyUrl) {
    try {
      const response = await fetch(targetUrl, {
        ...options,
        signal: AbortSignal.timeout(timeoutMs),
        redirect: "follow",
      });
      const body = await response.text();
      return parseJsonResponse(response.status, body);
    } catch {
      return null;
    }
  }

  return new Promise((resolvePromise) => {
    let settled = false;
    const finish = (value: JsonResponseLike | null) => {
      if (settled) return;
      settled = true;
      resolvePromise(value);
    };
    let target: URL;
    let proxy: URL;
    try {
      target = new URL(targetUrl);
      proxy = new URL(proxyUrl);
    } catch {
      finish(null);
      return;
    }
    const body = options.body ?? "";
    const headers = {
      ...(options.headers ?? {}),
      "Content-Length": String(Buffer.byteLength(body)),
      Host: target.host,
    };
    const tunnel = http.request({
      host: proxy.hostname,
      port: Number(proxy.port || 80),
      method: "CONNECT",
      path: `${target.hostname}:${target.port || 443}`,
      headers: { Host: `${target.hostname}:${target.port || 443}` },
    });
    tunnel.setTimeout(timeoutMs, () => { tunnel.destroy(); finish(null); });
    tunnel.on("connect", (connectResponse, socket) => {
      if ((connectResponse.statusCode ?? 0) !== 200) {
        socket.destroy();
        finish(null);
        return;
      }
      const handleResponse = (response: http.IncomingMessage) => {
        const chunks: Buffer[] = [];
        response.on("data", (chunk) => chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)));
        response.on("end", () => finish(parseJsonResponse(response.statusCode ?? 0, Buffer.concat(chunks).toString("utf8"))));
        response.on("error", () => finish(null));
      };
      const requestOptions: https.RequestOptions = {
        hostname: target.hostname,
        port: Number(target.port || 443),
        path: `${target.pathname}${target.search}`,
        method: options.method ?? "GET",
        headers,
        createConnection: () => openTunnelConnection(target, socket),
      };
      const request = target.protocol === "http:"
        ? http.request(requestOptions, handleResponse)
        : https.request(requestOptions, handleResponse);
      request.setTimeout(timeoutMs, () => { request.destroy(); finish(null); });
      request.on("error", () => finish(null));
      request.end(body);
    });
    tunnel.on("error", () => finish(null));
    tunnel.end();
  });
}

/** 通过 HTTP 代理建立 CONNECT 隧道拉取目标（适配国内网络环境）。 */
export async function fetchViaTunnel(
  targetUrl: string,
  proxyUrl: string,
  timeoutMs: number,
  headers: Record<string, string>,
): Promise<FetchLike | null> {
  return new Promise((resolvePromise) => {
    let settled = false;
    const finish = (value: FetchLike | null) => { if (!settled) { settled = true; resolvePromise(value); } };
    let target: URL;
    let proxy: URL;
    try {
      target = new URL(targetUrl);
      proxy = new URL(proxyUrl);
    } catch {
      finish(null);
      return;
    }
    const tunnel = http.request({
      host: proxy.hostname,
      port: Number(proxy.port || 80),
      method: "CONNECT",
      path: `${target.hostname}:${target.port || 443}`,
      headers: { Host: `${target.hostname}:${target.port || 443}` },
    });
    tunnel.setTimeout(timeoutMs, () => { tunnel.destroy(); finish(null); });
    tunnel.on("connect", (_res, socket) => {
      const handleResponse = (response: http.IncomingMessage) => {
        finish({
          ok: (response.statusCode ?? 0) >= 200 && (response.statusCode ?? 0) < 300,
          body: response,
        });
      };
      const requestOptions: https.RequestOptions = {
        hostname: target.hostname,
        port: Number(target.port || 443),
        path: `${target.pathname}${target.search}`,
        method: "GET",
        headers,
        createConnection: () => openTunnelConnection(target, socket),
      };
      const request = target.protocol === "http:"
        ? http.request(requestOptions, handleResponse)
        : https.request(requestOptions, handleResponse);
      request.setTimeout(timeoutMs, () => { request.destroy(); finish(null); });
      request.on("error", () => finish(null));
      request.end();
    });
    tunnel.on("error", () => finish(null));
    tunnel.end();
  });
}

/**
 * 带可选 HTTP 代理与 Referer 的 fetch（豆瓣图床需 Referer 放行）。
 * proxyUrl 为空时走系统默认网络。
 */
export async function fetchLike(url: string, proxyUrl: string | null, timeoutMs: number): Promise<FetchLike | null> {
  const headers: Record<string, string> = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
  };
  try {
    const host = new URL(url).hostname.toLowerCase();
    if (host.includes("doubanio.com") || host.includes("douban.com")) {
      headers.Referer = "https://movie.douban.com/";
    }
  } catch { /* 无效 URL 交给调用方处理 */ }
  if (!proxyUrl) {
    try {
      const response = await fetch(url, { signal: AbortSignal.timeout(timeoutMs), redirect: "follow", headers });
      return { ok: response.ok, body: response.body ?? null };
    } catch {
      return null;
    }
  }
  return fetchViaTunnel(url, proxyUrl, timeoutMs, headers);
}
