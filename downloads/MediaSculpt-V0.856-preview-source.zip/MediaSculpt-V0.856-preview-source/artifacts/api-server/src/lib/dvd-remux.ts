import { execFile } from "node:child_process";
import fs from "node:fs/promises";
import { promisify } from "node:util";
import { parseHandBrakeScanOutput, parseHandBrakeScanSummaries, type HandBrakeTitle, type HandBrakeTitleSummary } from "./handbrake-scan";
import { ensureLibdvdcss, isLibdvdcssMissingError } from "./libdvdcss";

const execFileAsync = promisify(execFile);

/** HandBrakeCLI (Windows) writes --scan --json as UTF-16LE; decode BOM / null-byte-heavy output correctly. */
function decodeExecOutput(value: string | Buffer | Uint8Array | undefined): string {
  if (!value) return "";
  if (typeof value === "string") return value;
  const buf = Buffer.isBuffer(value) ? value : Buffer.from(value as Uint8Array);
  const hasLeBom = buf[0] === 0xff && buf[1] === 0xfe;
  const hasBeBom = buf[0] === 0xfe && buf[1] === 0xff;
  if (hasLeBom || hasBeBom || buf.includes(0)) {
    let b = buf;
    if (hasLeBom) b = buf.subarray(2);
    else if (hasBeBom) b = buf.subarray(2).swap16();
    return b.toString("utf16le").replace(/^\uFEFF/, "");
  }
  return buf.toString("utf8");
}
const MAX_TOOL_BUFFER = 32 * 1024 * 1024;

export type DvdToolName = "handbrake" | "ffprobe" | "ffmpeg";

export type ExternalToolRequest = {
  tool: DvdToolName;
  executable: string;
  args: string[];
  timeoutMs?: number;
};

export type ExternalToolResult = {
  tool: DvdToolName;
  executable: string;
  args: string[];
  exitCode: number | null;
  stdout: string;
  stderr: string;
  durationMs: number;
  failureReason: string | null;
};

export type ExternalToolRunner = (request: ExternalToolRequest) => Promise<ExternalToolResult>;

export type DvdStream = {
  index: number;
  codecType: "video" | "audio" | "subtitle" | "unknown";
  codecName: string | null;
  language: string | null;
  title: string | null;
  width?: number | null;
  height?: number | null;
  channels?: number | null;
  channelLayout?: string | null;
  sampleRate?: number | null;
  bitrate?: number | null;
  estimatedSizeBytes?: number | null;
  bitsPerRawSample?: number | null;
  frameRate?: string | null;
  handbrakeTrackNumber?: number | null;
  default?: boolean;
  forced?: boolean;
};

export type DvdChapter = {
  id: number;
  startSeconds: number;
  endSeconds: number;
  title: string | null;
};

export type DvdHandBrakeTitle = {
  titleId: string;
  titleIndex: number;
  sourcePath: string;
  displayName: string;
  durationSeconds: number | null;
  chapterCount: number;
  chapters: DvdChapter[];
  streams: DvdStream[];
  videoTracks: DvdStream[];
  audioTracks: DvdStream[];
  subtitleTracks: DvdStream[];
  estimatedSize: null;
  toolMappings: {
    handbrakeTitleNumber: number;
    makemkvTitleIndex: null;
    dvdVtsNumber: null;
  };
  mappingStatus: "not-required";
  availabilityStatus?: "confirmed" | "unavailable";
  availabilityFailureReason?: string | null;
};

export type DvdTitleVerification = {
  verified: boolean;
  titleNumber: number;
  durationSeconds: number | null;
  chapters: DvdChapter[];
  streams: DvdStream[];
  videoTracks: DvdStream[];
  audioTracks: DvdStream[];
  subtitleTracks: DvdStream[];
  warnings: string[];
  durationDifferenceSeconds: number | null;
  durationDifferencePercent: number | null;
  diagnostic: ExternalToolResult;
  failureReason: string | null;
};

export const DVD_DURATION_NORMAL_PERCENT = 0.02;
export const DVD_DURATION_WARNING_PERCENT = 0.10;
export const DVD_DURATION_BLOCK_ABS_SECONDS = 180;

function streamCountDifferenceWarnings(handBrakeStreams: DvdStream[] | undefined, ffmpegStreams: DvdStream[]): string[] {
  if (!handBrakeStreams) return [];
  const warnings: string[] = [];
  for (const [codecType, label] of [["audio", "音轨"], ["subtitle", "字幕"], ["video", "视频"]] as const) {
    const handBrakeCount = handBrakeStreams.filter((stream) => stream.codecType === codecType).length;
    const ffmpegCount = ffmpegStreams.filter((stream) => stream.codecType === codecType).length;
    if (handBrakeCount !== ffmpegCount) warnings.push(`${label}数量差异：HandBrake ${handBrakeCount}，FFprobe ${ffmpegCount}`);
  }
  return warnings;
}

function errorDetails(error: unknown): { exitCode: number | null; stdout: string; stderr: string; failureReason: string } {
  const value = error as { code?: unknown; stdout?: unknown; stderr?: unknown; message?: unknown };
  return {
    exitCode: typeof value.code === "number" ? value.code : null,
    stdout: decodeExecOutput(value.stdout as string | Buffer | Uint8Array | undefined),
    stderr: decodeExecOutput(value.stderr as string | Buffer | Uint8Array | undefined),
    failureReason: typeof value.message === "string" ? value.message : String(error),
  };
}

export const runExternalTool: ExternalToolRunner = async (request) => {
  const startedAt = Date.now();
  const attempt = async (): Promise<ExternalToolResult> => {
    try {
      const result = await execFileAsync(request.executable, request.args, {
        timeout: request.timeoutMs ?? 10 * 60_000,
        maxBuffer: MAX_TOOL_BUFFER,
        windowsHide: true,
        encoding: "buffer",
      });
      return {
        tool: request.tool,
        executable: request.executable,
        args: [...request.args],
        exitCode: 0,
        stdout: decodeExecOutput(result.stdout),
        stderr: decodeExecOutput(result.stderr),
        durationMs: Date.now() - startedAt,
        failureReason: null,
      };
    } catch (error) {
      const details = errorDetails(error);
      return { tool: request.tool, executable: request.executable, args: [...request.args], durationMs: Date.now() - startedAt, ...details };
    }
  };
  const first = await attempt();
  if (first.exitCode === 0) return first;
  // CSS-encrypted DVDs fail until libdvdcss-2.dll is present next to
  // ffmpeg/ffprobe. Install it on demand and retry the exact same command
  // once; HandBrake does not need the DLL (it bundles its own decryption).
  const details = `${first.failureReason ?? ""}\n${first.stderr}`;
  if (request.tool !== "handbrake" && isLibdvdcssMissingError(details)) {
    const status = await ensureLibdvdcss(request.executable).catch(() => "failed" as const);
    if (status === "installed" || status === "already") return attempt();
  }
  return first;
};

function splitStreams(streams: DvdStream[]) {
  return {
    videoTracks: streams.filter((stream) => stream.codecType === "video"),
    audioTracks: streams.filter((stream) => stream.codecType === "audio"),
    subtitleTracks: streams.filter((stream) => stream.codecType === "subtitle"),
  };
}

export async function analyzeDvdWithHandBrake(input: {
  sourcePath: string;
  sourceFingerprint: string;
  handbrakeExecutable: string;
  run?: ExternalToolRunner;
}): Promise<{ titles: DvdHandBrakeTitle[]; diagnostic: ExternalToolResult; warnings?: string[] }> {
  const run = input.run ?? runExternalTool;
  const diagnostic = await run({
    tool: "handbrake",
    executable: input.handbrakeExecutable,
    args: ["--input", input.sourcePath, "--title", "0", "--scan", "--json"],
    timeoutMs: 10 * 60_000,
  });
  if (diagnostic.exitCode !== 0) return { titles: [], diagnostic };

  const scanOutput = `${diagnostic.stdout}\n${diagnostic.stderr}`;
  const parsedTitles = parseHandBrakeScanOutput(scanOutput);
  const summaries = parseHandBrakeScanSummaries(scanOutput);
  const titlesByNumber = new Map(parsedTitles.map((title) => [title.titleNumber, title]));
  const warnings: string[] = [];

  // HandBrake 1.11 may emit all titles in the text scan but only MainFeature
  // in JSON. Probe each title separately so stream metadata and the execution
  // title number come from the same logical DVD title.
  for (const summary of summaries) {
    if (titlesByNumber.has(summary.titleNumber)) continue;
    const detail = await run({
      tool: "handbrake",
      executable: input.handbrakeExecutable,
      args: ["--input", input.sourcePath, "--title", String(summary.titleNumber), "--scan", "--json"],
      timeoutMs: 10 * 60_000,
    });
    if (detail.exitCode !== 0) {
      warnings.push(`DVD Title ${summary.titleNumber} 无法完成逐标题读取：${detail.failureReason ?? detail.stderr.trim() ?? `退出码 ${detail.exitCode ?? "未知"}`}`);
      continue;
    }
    const parsed = parseHandBrakeScanOutput(`${detail.stdout}\n${detail.stderr}`)
      .find((title) => title.titleNumber === summary.titleNumber);
    if (parsed) titlesByNumber.set(summary.titleNumber, parsed);
    else warnings.push(`DVD Title ${summary.titleNumber} 逐标题扫描未返回有效流轨`);
  }

  const fallbackTemplate = parsedTitles.find((title) => title.streams.length > 0) ?? null;
  const titleInputs: Array<HandBrakeTitle | HandBrakeTitleSummary> = summaries.length > 0
    ? summaries.map((summary) => titlesByNumber.get(summary.titleNumber) ?? summary)
    : parsedTitles;
  const titles = titleInputs.map((titleInput, titleIndex) => {
    const summary = "chapterCount" in titleInput ? titleInput : null;
    const unavailable = Boolean(summary && !titlesByNumber.has(summary.titleNumber));
    const title = "titleNumber" in titleInput && "streams" in titleInput
      ? titleInput
      : fallbackTemplate
        ? { ...fallbackTemplate, titleNumber: titleInput.titleNumber, durationSeconds: titleInput.durationSeconds }
        : {
            titleNumber: titleInput.titleNumber,
            durationSeconds: titleInput.durationSeconds,
            chapters: [],
            streams: [],
          };
    const chapters = summary?.chapterDurationsSeconds?.length
      ? summary.chapterDurationsSeconds.map((duration, index, durations) => {
          const startSeconds = durations.slice(0, index).reduce((sum, value) => sum + value, 0);
          return { id: index, startSeconds, endSeconds: startSeconds + duration, title: `Chapter ${index + 1}` };
        })
      : title.chapters;
    const streams: DvdStream[] = title.streams.map((stream) => ({
      ...stream,
      codecName: stream.codecName || null,
      language: stream.language ?? null,
      title: stream.title ?? null,
    }));
    const normalizedChapters = chapters.map((chapter) => ({ ...chapter }));
    return {
      titleId: `handbrake:${title.titleNumber}`,
      titleIndex,
      sourcePath: input.sourcePath,
      displayName: `Title ${title.titleNumber}`,
      durationSeconds: title.durationSeconds,
      chapterCount: normalizedChapters.length,
      chapters: normalizedChapters,
      streams,
      ...splitStreams(streams),
      estimatedSize: null,
      toolMappings: { handbrakeTitleNumber: title.titleNumber, makemkvTitleIndex: null, dvdVtsNumber: null },
      mappingStatus: "not-required" as const,
      availabilityStatus: unavailable ? "unavailable" as const : "confirmed" as const,
      availabilityFailureReason: unavailable
        ? warnings.find((message) => message.includes(`Title ${title.titleNumber}`)) ?? "逐标题读取失败"
        : null,
    };
  });
  return { titles, diagnostic, ...(warnings.length > 0 ? { warnings } : {}) };
}

export function buildDvdTitleProbeArgs(sourcePath: string, titleNumber: number): string[] {
  if (!Number.isInteger(titleNumber) || titleNumber <= 0) throw new Error("DVD 标题编号无效");
  return [
    "-v", "error",
    "-f", "dvdvideo",
    "-title", String(titleNumber),
    "-i", sourcePath,
    "-print_format", "json",
    "-show_streams", "-show_format", "-show_chapters",
  ];
}

/** Read a small window from one logical DVD title without creating an output file. */
export function buildDvdShortReadArgs(input: {
  sourcePath: string;
  titleNumber: number;
  startSeconds: number;
  durationSeconds?: number;
}): string[] {
  if (!Number.isInteger(input.titleNumber) || input.titleNumber <= 0) throw new Error("DVD 标题编号无效");
  const startSeconds = Math.max(0, Number.isFinite(input.startSeconds) ? input.startSeconds : 0);
  const durationSeconds = Math.max(1, Number.isFinite(input.durationSeconds ?? 4) ? input.durationSeconds ?? 4 : 4);
  return [
    "-hide_banner", "-f", "dvdvideo", "-title", String(input.titleNumber),
    "-ss", startSeconds.toFixed(3), "-i", input.sourcePath,
    "-map", "0:v:0", "-t", durationSeconds.toFixed(3), "-an",
    "-progress", "pipe:1", "-f", "null", "-",
  ];
}

export function buildDvdTimestampProbeArgs(input: { sourcePath: string; titleNumber: number }): string[] {
  if (!Number.isInteger(input.titleNumber) || input.titleNumber <= 0) throw new Error("DVD 标题编号无效");
  return [
    "-v", "error", "-f", "dvdvideo", "-title", String(input.titleNumber), "-i", input.sourcePath,
    "-select_streams", "v:0", "-read_intervals", "%+#180", "-show_packets",
    "-show_entries", "packet=pts_time,dts_time", "-of", "json",
  ];
}

function parseProbeOutput(stdout: string): { durationSeconds: number | null; streams: DvdStream[]; chapters: DvdChapter[] } {
  const parsed = JSON.parse(stdout) as {
    streams?: Array<Record<string, unknown>>;
    chapters?: Array<Record<string, unknown>>;
    format?: { duration?: unknown };
  };
  const duration = Number(parsed.format?.duration);
  const durationSeconds = Number.isFinite(duration) && duration > 0 ? duration : null;
  const streams = (parsed.streams ?? []).map((stream, fallbackIndex): DvdStream => {
    const tags = (stream.tags ?? {}) as Record<string, unknown>;
    const disposition = (stream.disposition ?? {}) as Record<string, unknown>;
    const codecType = ["video", "audio", "subtitle"].includes(String(stream.codec_type))
      ? String(stream.codec_type) as DvdStream["codecType"]
      : "unknown";
    return {
      index: Number(stream.index ?? fallbackIndex),
      codecType,
      codecName: typeof stream.codec_name === "string" ? stream.codec_name : null,
      language: typeof tags.language === "string" ? tags.language : null,
      title: typeof tags.title === "string" ? tags.title : null,
      width: typeof stream.width === "number" ? stream.width : null,
      height: typeof stream.height === "number" ? stream.height : null,
      channels: typeof stream.channels === "number" ? stream.channels : null,
      channelLayout: typeof stream.channel_layout === "string" ? stream.channel_layout : null,
      sampleRate: typeof stream.sample_rate === "string" || typeof stream.sample_rate === "number" ? Number(stream.sample_rate) : null,
      bitrate: typeof stream.bit_rate === "string" || typeof stream.bit_rate === "number" ? Number(stream.bit_rate) : null,
      estimatedSizeBytes: durationSeconds && (typeof stream.bit_rate === "string" || typeof stream.bit_rate === "number")
        ? Math.round((Number(stream.bit_rate) * durationSeconds) / 8)
        : null,
      bitsPerRawSample: typeof stream.bits_per_raw_sample === "string" || typeof stream.bits_per_raw_sample === "number"
        ? Number(stream.bits_per_raw_sample)
        : typeof stream.bits_per_sample === "string" || typeof stream.bits_per_sample === "number"
          ? Number(stream.bits_per_sample)
          : null,
      frameRate: typeof stream.avg_frame_rate === "string" ? stream.avg_frame_rate : null,
      default: Number(disposition.default ?? 0) === 1,
      forced: Number(disposition.forced ?? 0) === 1,
    };
  });
  const chapters = (parsed.chapters ?? []).map((chapter, index): DvdChapter => {
    const tags = (chapter.tags ?? {}) as Record<string, unknown>;
    return {
      // Keep 0-based ids consistent with the HandBrake analysis and the
      // smart-workflow plan so verified chapters validate against the plan's
      // selectedChapterIds (TASK_SNAPSHOT_INVALID otherwise).
      id: index,
      startSeconds: Number(chapter.start_time ?? 0),
      endSeconds: Number(chapter.end_time ?? 0),
      title: typeof tags.title === "string" ? tags.title : null,
    };
  });
  return { durationSeconds, streams, chapters };
}

function attachHandBrakeTrackNumbers(streams: DvdStream[], handBrakeStreams?: DvdStream[]): { streams: DvdStream[]; warnings: string[] } {
  if (!handBrakeStreams || handBrakeStreams.length === 0) return { streams, warnings: [] };
  const warnings: string[] = [];
  const used = new Set<number>();
  const mapped: DvdStream[] = streams.map((stream) => {
    const candidates = handBrakeStreams
      .map((candidate, candidateIndex) => ({ candidate, candidateIndex, score:
        (candidate.codecType === stream.codecType ? 5 : 0)
        + (candidate.codecName && stream.codecName && candidate.codecName.toLowerCase() === stream.codecName.toLowerCase() ? 3 : 0)
        + (candidate.language && stream.language && candidate.language.toLowerCase() === stream.language.toLowerCase() ? 3 : 0)
        + (candidate.channels && stream.channels && candidate.channels === stream.channels ? 2 : 0)
        + (candidate.title && stream.title && candidate.title.toLowerCase() === stream.title.toLowerCase() ? 1 : 0),
      }))
      .filter(({ candidate, candidateIndex, score }) => candidate.codecType === stream.codecType && !used.has(candidateIndex) && score > 0)
      .sort((a, b) => b.score - a.score);
    const best = candidates[0];
    const tied = best && candidates[1] && candidates[1].score === best.score;
    if (!best || tied || typeof best.candidate.handbrakeTrackNumber !== "number") {
      // Leave unmapped; the positional fallback below handles it.
      return stream;
    }
    used.add(best.candidateIndex);
    return { ...stream, handbrakeTrackNumber: best.candidate.handbrakeTrackNumber };
  });
  // Positional fallback: DVDs often carry several identical-looking subtitle
  // tracks (HandBrake reports them all as "bitmap", ffprobe as
  // "dvd_subtitle"), so the score-based match ties and maps nothing. Map the
  // remaining streams to the next unused HandBrake track of the same type, in
  // order, so a selected subtitle is never dropped from the compression plan.
  for (let index = 0; index < mapped.length; index += 1) {
    const stream = mapped[index];
    if (typeof stream.handbrakeTrackNumber === "number") continue;
    const fallbackIndex = handBrakeStreams.findIndex(
      (candidate, candidateIndex) =>
        candidate.codecType === stream.codecType
        && !used.has(candidateIndex)
        && typeof candidate.handbrakeTrackNumber === "number",
    );
    if (fallbackIndex >= 0) {
      used.add(fallbackIndex);
      mapped[index] = { ...stream, handbrakeTrackNumber: handBrakeStreams[fallbackIndex].handbrakeTrackNumber };
    } else {
      warnings.push(`无法可靠映射 FFprobe ${stream.codecType} 流 ${stream.index} 到 HandBrake 轨道`);
    }
  }
  return { streams: mapped, warnings };
}

export async function verifyDvdTitle(input: {
  sourcePath: string;
  titleNumber: number;
  handbrakeDurationSeconds: number | null;
  handbrakeChapterCount: number;
  handbrakeStreams?: DvdStream[];
  ffprobeExecutable: string;
  run?: ExternalToolRunner;
}): Promise<DvdTitleVerification> {
  const run = input.run ?? runExternalTool;
  const diagnostic = await run({
    tool: "ffprobe",
    executable: input.ffprobeExecutable,
    args: buildDvdTitleProbeArgs(input.sourcePath, input.titleNumber),
    timeoutMs: 90_000,
  });
  const failed = (reason: string): DvdTitleVerification => ({
    verified: false,
    titleNumber: input.titleNumber,
    durationSeconds: null,
    chapters: [],
    streams: [],
    videoTracks: [],
    audioTracks: [],
    subtitleTracks: [],
    warnings: [],
    durationDifferenceSeconds: null,
    durationDifferencePercent: null,
    diagnostic,
    failureReason: `所选标题验证失败：${reason}`,
  });
  if (diagnostic.exitCode !== 0) {
    const details = `${diagnostic.failureReason ?? ""}\n${diagnostic.stderr}`;
    if (/dvdvideo|unknown demuxer|unknown format|invalid input/i.test(details)) {
      return failed("当前FFmpeg不支持DVD标题读取，请修复FFmpeg工具");
    }
    return failed(diagnostic.failureReason ?? `ffprobe 退出码 ${diagnostic.exitCode}`);
  }

  let parsed: ReturnType<typeof parseProbeOutput>;
  try {
    parsed = parseProbeOutput(diagnostic.stdout);
  } catch (error) {
    return failed(`ffprobe 输出无法解析：${error instanceof Error ? error.message : String(error)}`);
  }
  const mappedStreams = attachHandBrakeTrackNumbers(parsed.streams, input.handbrakeStreams);
  parsed.streams = mappedStreams.streams;
  const videoTracks = parsed.streams.filter((stream) => stream.codecType === "video");
  if (videoTracks.length === 0) return failed("所选DVD标题没有可处理的视频流");
  const warnings = [...mappedStreams.warnings, ...streamCountDifferenceWarnings(input.handbrakeStreams, parsed.streams)];
  let durationDifferenceSeconds: number | null = null;
  let durationDifferencePercent: number | null = null;
  if (input.handbrakeDurationSeconds && parsed.durationSeconds) {
    durationDifferenceSeconds = Math.abs(input.handbrakeDurationSeconds - parsed.durationSeconds);
    durationDifferencePercent = durationDifferenceSeconds / input.handbrakeDurationSeconds;
    if (durationDifferencePercent > DVD_DURATION_WARNING_PERCENT && durationDifferenceSeconds >= DVD_DURATION_BLOCK_ABS_SECONDS) {
      return failed(`HandBrake 时长 ${input.handbrakeDurationSeconds.toFixed(1)} 秒，FFprobe 时长 ${parsed.durationSeconds.toFixed(1)} 秒，差异 ${durationDifferenceSeconds.toFixed(1)} 秒（${(durationDifferencePercent * 100).toFixed(1)}%）`);
    }
    if (durationDifferencePercent > DVD_DURATION_NORMAL_PERCENT && durationDifferenceSeconds >= 30) {
      warnings.push(`时长差异：${durationDifferenceSeconds.toFixed(1)} 秒（${(durationDifferencePercent * 100).toFixed(1)}%），Remux 将采用 FFprobe 实际流轨`);
    }
  }
  if (input.handbrakeChapterCount > 0 && parsed.chapters.length !== input.handbrakeChapterCount) {
    warnings.push(`章节数量差异：HandBrake ${input.handbrakeChapterCount}，FFprobe ${parsed.chapters.length}`);
  }
  return {
    verified: true,
    titleNumber: input.titleNumber,
    ...parsed,
    ...splitStreams(parsed.streams),
    warnings,
    durationDifferenceSeconds,
    durationDifferencePercent,
    diagnostic,
    failureReason: null,
  };
}

function pcmDvdOutputCodec(bitsPerRawSample: number | null | undefined): "pcm_s16le" | "pcm_s24le" {
  return typeof bitsPerRawSample === "number" && bitsPerRawSample > 16 ? "pcm_s24le" : "pcm_s16le";
}

export function buildDvdRemuxArgs(input: {
  sourcePath: string;
  titleNumber: number;
  selectedVideoStreams: number[];
  selectedAudioStreams: number[];
  selectedAudioCodecs?: Array<{
    inputIndex: number;
    codecName: string | null;
    bitsPerRawSample?: number | null;
  }>;
  selectedSubtitleStreams: number[];
  outputPath: string;
}): string[] {
  if (!Number.isInteger(input.titleNumber) || input.titleNumber <= 0) throw new Error("DVD 标题编号无效");
  if (input.selectedVideoStreams.length === 0) throw new Error("DVD Remux 至少需要一个视频流");
  // Map the exact selected streams by absolute index. Using type-relative
  // counts (`-map 0:a:0..N-1`) silently ignored WHICH tracks the user picked:
  // selecting only the 2nd audio track still remuxed the 1st one.
  const args = [
    "-y", "-hide_banner",
    "-f", "dvdvideo", "-title", String(input.titleNumber), "-i", input.sourcePath,
    ...input.selectedVideoStreams.flatMap((index) => ["-map", `0:${index}`]),
    ...input.selectedAudioStreams.flatMap((index) => ["-map", `0:${index}`]),
    ...input.selectedSubtitleStreams.flatMap((index) => ["-map", `0:${index}`]),
    "-map_chapters", "0",
    "-c", "copy",
    input.outputPath,
  ];
  // Matroska has no pcm_dvd codec tag. Convert only this selected audio
  // family to little-endian PCM; all video/audio/subtitle streams otherwise
  // remain lossless stream copies.
  let audioOutputIndex = 0;
  for (const inputIndex of input.selectedAudioStreams) {
    const metadata = input.selectedAudioCodecs?.find((stream) => stream.inputIndex === inputIndex);
    if (metadata?.codecName?.toLowerCase() === "pcm_dvd") {
      args.splice(args.length - 1, 0, "-c:a:" + audioOutputIndex, pcmDvdOutputCodec(metadata.bitsPerRawSample));
    }
    audioOutputIndex += 1;
  }
  return args;
}

export function canStartDvdRemux(input: {
  validSource: boolean;
  selectedTitleNumber: number | null;
  titleVerified: boolean;
  videoStreamCount: number;
  outputPathValid: boolean;
  duplicateRunning: boolean;
  estimatedSize?: number | null;
  makeMkvAvailable?: boolean;
  selectedSubtitleStreams?: number[];
}): boolean {
  return input.validSource
    && typeof input.selectedTitleNumber === "number"
    && input.selectedTitleNumber > 0
    && input.titleVerified
    && input.videoStreamCount > 0
    && input.outputPathValid
    && !input.duplicateRunning;
}

export async function runDvdRemux(input: {
  executable: string;
  sourcePath: string;
  titleNumber: number;
  selectedVideoStreams: number[];
  selectedAudioStreams: number[];
  selectedAudioCodecs?: Array<{
    inputIndex: number;
    codecName: string | null;
    bitsPerRawSample?: number | null;
  }>;
  selectedSubtitleStreams: number[];
  outputPath: string;
  /** Pre-built FFmpeg args (from the unified Remux planner); falls back to buildDvdRemuxArgs. */
  args?: string[];
  /** Optional prepared VOB fallback args used when the primary output fails validation. */
  fallbackArgs?: string[];
  onFallback?: (error: unknown) => Promise<void> | void;
  /** Optional post-output probe/validation. Any failure removes the output. */
  validateOutput?: (outputPath: string) => Promise<void>;
  run?: ExternalToolRunner;
}): Promise<{ fileSize: number; diagnostic: ExternalToolResult }> {
  const run = input.run ?? runExternalTool;
  const execute = async (args: string[]): Promise<{ fileSize: number; diagnostic: ExternalToolResult }> => {
    await fs.rm(input.outputPath, { force: true }).catch(() => {});
    const diagnostic = await run({
      tool: "ffmpeg",
      executable: input.executable,
      args,
      timeoutMs: 24 * 60 * 60_000,
    });
    if (diagnostic.exitCode !== 0) {
      throw new Error(diagnostic.failureReason ?? diagnostic.stderr.trim() ?? `ffmpeg 退出码 ${diagnostic.exitCode}`);
    }
    const stat = await fs.stat(input.outputPath).catch(() => null);
    if (!stat?.isFile() || stat.size < 1024) throw new Error("FFmpeg 退出成功但未生成有效 MKV");
    const handle = await fs.open(input.outputPath, "r").catch(() => null);
    if (!handle) throw new Error("FFmpeg 退出成功但未生成有效 MKV");
    try {
      const header = Buffer.alloc(4);
      const read = await handle.read(header, 0, header.length, 0);
      if (read.bytesRead !== 4 || !header.equals(Buffer.from([0x1a, 0x45, 0xdf, 0xa3]))) {
        throw new Error("FFmpeg 退出成功但未生成有效 MKV");
      }
    } finally {
      await handle.close();
    }
    await input.validateOutput?.(input.outputPath);
    return { fileSize: stat.size, diagnostic };
  };
  const primaryArgs = input.args ?? buildDvdRemuxArgs(input);
  try {
    return await execute(primaryArgs);
  } catch (error) {
    if (input.fallbackArgs) {
      try {
        await input.onFallback?.(error);
      } catch {
        // Fallback logging is diagnostic only and must never block recovery.
      }
      return await execute(input.fallbackArgs).catch(async (fallbackError) => {
        await fs.rm(input.outputPath, { force: true }).catch(() => {});
        throw fallbackError;
      });
    }
    await fs.rm(input.outputPath, { force: true }).catch(() => {});
    throw error;
  }
}

export async function inspectFfmpegCapabilities(executable: string, run: ExternalToolRunner = runExternalTool) {
  const version = await run({ tool: "ffmpeg", executable, args: ["-hide_banner", "-version"], timeoutMs: 15_000 });
  const demuxers = await run({ tool: "ffmpeg", executable, args: ["-hide_banner", "-demuxers"], timeoutMs: 15_000 });
  const buildconf = await run({ tool: "ffmpeg", executable, args: ["-hide_banner", "-buildconf"], timeoutMs: 15_000 });
  const dvdvideo = /(^|\s)dvdvideo(\s|$)/m.test(`${demuxers.stdout}\n${demuxers.stderr}`);
  const configuration = `${buildconf.stdout}\n${buildconf.stderr}`;
  const libdvdnav = configuration.includes("--enable-libdvdnav");
  const libdvdread = configuration.includes("--enable-libdvdread");
  return {
    executable,
    version: `${version.stdout}\n${version.stderr}`.trim().split(/\r?\n/)[0] ?? "",
    dvdvideo,
    libdvdnav,
    libdvdread,
    supported: version.exitCode === 0 && demuxers.exitCode === 0 && buildconf.exitCode === 0 && dvdvideo && libdvdnav && libdvdread,
    diagnostics: [version, demuxers, buildconf],
  };
}
