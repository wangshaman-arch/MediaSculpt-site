import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const projectRoot = path.resolve(import.meta.dirname, "../../../..");

describe("runtime requirements", () => {
  it("requires Node 22.20+ everywhere node:sqlite array rows are used", () => {
    const rootPackage = JSON.parse(
      fs.readFileSync(path.join(projectRoot, "package.json"), "utf8"),
    ) as { engines?: { node?: string } };

    expect(rootPackage.engines?.node).toBe(">=22.20.0");

    const requirementFiles = [
      "windows-setup/install.ps1",
      "windows-setup/start-services.ps1",
      "windows-setup/update.ps1",
      "scripts/prepare-tauri-sidecar.ps1",
      "scripts/require-node22.ps1",
      "README.md",
    ];

    for (const relativePath of requirementFiles) {
      const contents = fs.readFileSync(path.join(projectRoot, relativePath), "utf8");
      expect(contents, relativePath).toContain("22.20");
      expect(contents, relativePath).not.toMatch(/22\.13|22\.16/);
    }
  });

  it("checks the active build Node before Tauri packages the sidecar", () => {
    const buildScript = fs.readFileSync(
      path.join(projectRoot, "scripts/build-tauri.ps1"),
      "utf8",
    );
    const packageScript = fs.readFileSync(
      path.join(projectRoot, "scripts/build-tauri-base.ps1"),
      "utf8",
    );
    const sidecarScript = fs.readFileSync(
      path.join(projectRoot, "scripts/prepare-tauri-sidecar.ps1"),
      "utf8",
    );

    expect(buildScript).toContain("require-node22.ps1");
    expect(packageScript).toContain("require-node22.ps1");
    expect(sidecarScript).toContain("Node.js 22.20+");
  });

  it("waits for bundled tools before the API announces readiness", () => {
    const indexScript = fs
      .readFileSync(
        path.join(projectRoot, "artifacts/api-server/src/index.ts"),
        "utf8",
      )
      .replace(/\r\n/g, "\n");

    expect(indexScript).toContain("ensureRuntimeDirectories()\n  .then(() => seedBundledTools())\n  .then(() => runMigrations())");
    expect(indexScript).not.toContain("void seedBundledTools()");
  });

  it("includes a size-aware output capacity guard for large remux jobs", () => {
    const orchestrator = fs.readFileSync(
      path.join(projectRoot, "artifacts/api-server/src/routes/job-orchestrator.ts"),
      "utf8",
    );
    expect(orchestrator).toContain("estimateOutputCapacity");
    expect(orchestrator).toContain("输出空间预检通过");
    expect(orchestrator).toContain("describeOutputCapacity");
  });
});
