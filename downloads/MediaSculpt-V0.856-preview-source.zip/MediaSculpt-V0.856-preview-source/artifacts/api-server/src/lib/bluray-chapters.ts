import type { BlurayPlaylistSegment } from "./disc";
import type { FfconcatTimedSegment } from "./ffconcat";

export function mapBlurayChaptersToSegments(
  segments: BlurayPlaylistSegment[],
  chapters: Array<{ startSeconds: number; endSeconds: number }>,
): FfconcatTimedSegment[] {
  const result: FfconcatTimedSegment[] = [];
  for (const chapter of chapters) {
    // MPLS PlayItem IN/OUT timestamps are stored at 45 kHz, not 90 kHz.
    // Chapter positions are seconds, so use the same clock before comparing
    // them with segment boundaries.
    const start45k = Math.max(0, chapter.startSeconds * 45000);
    const end45k = Math.max(start45k, chapter.endSeconds * 45000);
    for (const segment of segments) {
      const overlapStart = Math.max(start45k, segment.inTime45k);
      const overlapEnd = Math.min(end45k, segment.outTime45k);
      if (overlapEnd <= overlapStart) continue;
      result.push({ file: segment.streamPath, startSeconds: (overlapStart - segment.inTime45k) / 45000, endSeconds: (overlapEnd - segment.inTime45k) / 45000 });
    }
  }
  return result;
}
