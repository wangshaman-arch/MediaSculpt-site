import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
  TITLE_METADATA_FILE,
  hasEnrichment,
  inferTier,
  readTitleMetadata,
  tierRank,
  titleMetadataPath,
  writeTitleMetadata,
} from "./title-metadata";

let dir: string;

beforeEach(async () => {
  dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-title-meta-"));
});

afterEach(async () => {
  await fs.rm(dir, { recursive: true, force: true });
});

describe("durable title metadata", () => {
  it("returns nothing cached for a folder with no sidecar", async () => {
    const result = await readTitleMetadata(dir);
    expect(result).toEqual({ record: null, tier: null });
  });

  // The point of the sidecar: a machine with no AI/API access must still be able
  // to show what was already resolved, with no network involved.
  it("round-trips a record so it can be read offline", async () => {
    await writeTitleMetadata(dir, {
      title: "美丽心灵",
      titleEn: "A Beautiful Mind",
      year: 2001,
      imdbId: "tt0268978",
      director: "Ron Howard",
      cast: "Russell Crowe、Jennifer Connelly",
      genres: "剧情",
      rating: 8.2,
      ratingSource: "imdb",
      overview: "A biographical drama…",
    }, "keyed");

    const { record, tier } = await readTitleMetadata(dir);
    expect(tier).toBe("keyed");
    expect(record).toMatchObject({
      title: "美丽心灵",
      titleEn: "A Beautiful Mind",
      year: 2001,
      imdbId: "tt0268978",
      director: "Ron Howard",
      cast: "Russell Crowe、Jennifer Connelly",
      rating: 8.2,
    });
    expect(await fs.readFile(titleMetadataPath(dir), "utf8")).toContain("A Beautiful Mind");
    expect(TITLE_METADATA_FILE).toBe("metadata.json");
  });

  it("does not let a later empty value erase what is already cached", async () => {
    await writeTitleMetadata(dir, { title: "Hamlet", year: 1996, director: "Kenneth Branagh" }, "keyed");
    // A failed keyed lookup reports empty strings; they must not overwrite.
    const merged = await writeTitleMetadata(dir, { director: "", cast: "", year: 0 as unknown as number }, "keyed");
    expect(merged?.director).toBe("Kenneth Branagh");
    expect(merged?.year).toBe(1996);
  });

  it("fills a missing field from a later tier", async () => {
    await writeTitleMetadata(dir, { title: "Hamlet", year: 1996 }, "keyless");
    const merged = await writeTitleMetadata(dir, { cast: "Kenneth Branagh、Kate Winslet" }, "keyed");
    expect(merged?.cast).toBe("Kenneth Branagh、Kate Winslet");
    expect(merged?.title).toBe("Hamlet");
  });

  // Tier must never move backwards: an offline re-run must not demote a record
  // that a keyed lookup already enriched.
  it("never demotes the recorded tier", async () => {
    await writeTitleMetadata(dir, { title: "Hamlet", cast: "Kate Winslet" }, "keyed");
    const afterOfflineRun = await writeTitleMetadata(dir, { title: "Hamlet" }, "filename");
    expect(afterOfflineRun?.resolvedBy).toBe("keyed");
    expect(afterOfflineRun?.cast).toBe("Kate Winslet");
  });

  it("promotes the tier when a richer source answers", async () => {
    await writeTitleMetadata(dir, { title: "Hamlet" }, "filename");
    const enriched = await writeTitleMetadata(dir, { cast: "Kate Winslet", overview: "…" }, "keyed");
    expect(enriched?.resolvedBy).toBe("keyed");
  });

  it("leaves no temporary file behind after writing", async () => {
    await writeTitleMetadata(dir, { title: "Hamlet" }, "keyless");
    const entries = await fs.readdir(dir);
    expect(entries).toEqual([TITLE_METADATA_FILE]);
  });

  it("treats a corrupt sidecar as nothing cached instead of throwing", async () => {
    await fs.writeFile(titleMetadataPath(dir), "{not json", "utf8");
    await expect(readTitleMetadata(dir)).resolves.toEqual({ record: null, tier: null });
  });

  it("infers the tier of records written before the field existed", () => {
    expect(inferTier({ title: "Hamlet" })).toBe("filename");
    expect(inferTier({ title: "Hamlet", imdbId: "tt0116477" })).toBe("keyless");
    expect(inferTier({ title: "Hamlet", cast: "Kate Winslet" })).toBe("keyed");
    expect(inferTier({ resolvedBy: "ai", title: "Hamlet" })).toBe("ai");
  });

  it("reports which tiers outrank which", () => {
    expect(tierRank("filename")).toBeLessThan(tierRank("keyless"));
    expect(tierRank("keyless")).toBeLessThan(tierRank("keyed"));
    expect(tierRank("keyed")).toBeLessThan(tierRank("ai"));
  });

  it("distinguishes an enriched record from a filename-only one", () => {
    expect(hasEnrichment({ title: "Hamlet", year: 1996 })).toBe(false);
    expect(hasEnrichment({ title: "Hamlet", director: "Kenneth Branagh" })).toBe(true);
    expect(hasEnrichment({ cast: "Kate Winslet" })).toBe(true);
    expect(hasEnrichment({ overview: "…" })).toBe(true);
    expect(hasEnrichment(null)).toBe(false);
  });
});
