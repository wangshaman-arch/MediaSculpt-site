export const MIN_OUTPUT_FREE_BYTES = 2 * 1024 ** 3;
const CAPACITY_SAFETY_BYTES = 512 * 1024 ** 2;

export type OutputCapacityMode = "remux" | "compress" | "both" | "none";

export type OutputCapacityEstimate = {
  mode: OutputCapacityMode;
  sourceBytes: number | null;
  requiredFreeBytes: number;
  reason: string;
};

/**
 * Reserve space for the output and its temporary neighbour. Compression size
 * is content-dependent, so use a quarter of the source with a 512 MiB floor;
 * lossless Remux must reserve the selected source payload in full.
 */
export function estimateOutputCapacity(mode: OutputCapacityMode, sourceBytes: number | null): OutputCapacityEstimate {
  const normalizedSource = typeof sourceBytes === "number" && Number.isFinite(sourceBytes) && sourceBytes > 0
    ? Math.ceil(sourceBytes)
    : null;
  if (mode === "none") {
    return { mode, sourceBytes: normalizedSource, requiredFreeBytes: 0, reason: "无需生成视频文件" };
  }

  const compressionBytes = normalizedSource === null
    ? 0
    : Math.max(Math.ceil(normalizedSource * 0.25), 512 * 1024 ** 2);
  const payloadBytes = mode === "remux"
    ? (normalizedSource ?? 0)
    : mode === "compress"
      ? compressionBytes
      : (normalizedSource ?? 0) + compressionBytes;
  const requiredFreeBytes = Math.max(MIN_OUTPUT_FREE_BYTES, payloadBytes + CAPACITY_SAFETY_BYTES);
  const reason = normalizedSource === null
    ? "源大小暂不可统计，使用最低安全余量"
    : `源文件 ${normalizedSource} bytes，按 ${mode} 预留输出与临时文件空间`;
  return { mode, sourceBytes: normalizedSource, requiredFreeBytes, reason };
}

export function describeOutputCapacity(availableBytes: number, estimate: OutputCapacityEstimate): string {
  const availableGB = Math.max(0, availableBytes) / 1_000_000_000;
  const requiredGB = estimate.requiredFreeBytes / 1_000_000_000;
  return `输出磁盘空间不足：可用 ${availableGB.toFixed(1)} GB，至少需要 ${requiredGB.toFixed(1)} GB（${estimate.reason}）`;
}
