// Extracted from tool-downloader.ts: Tesseract / seven-zip install and archive extraction.
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { getToolPackage, ghMirrorChain } from "./tool-manifest";
import { candidatePaths, executableName, resolveToolPath, type ToolId } from "./tool-runtime";


const execFileAsync = promisify(execFile);
import {
  TESSERACT_INSTALL_LANGUAGES,
  TESSDATA_REPOS,
  TESSDATA_MIRRORS,
  downloadSingleFileWithResume,
  type DownloadToolOptions,
} from "./tool-downloader";

/** Locate the tessdata directory next to a Tesseract executable. */
export async function findTessdataDirectory(tesseractPath: string): Promise<string | null> {
  const candidates = [
    path.join(path.dirname(tesseractPath), "tessdata"),
    path.join(path.dirname(tesseractPath), "..", "tessdata"),
  ];
  for (const candidate of candidates) {
    try {
      const stat = await fs.stat(candidate);
      if (stat.isDirectory()) return candidate;
    } catch {
      // Try the next candidate.
    }
  }
  return null;
}

/**
 * Install Tesseract language data (.traineddata from tessdata_fast) into the
 * tessdata directory that belongs to the given executable. Missing files are
 * downloaded through the mirror chain; existing files are reused.
 */
export async function installTesseractLanguageData(
  tesseractPath: string,
  languages: string[],
  log?: DownloadToolOptions["onLog"],
): Promise<string[]> {
  const tessdata = (await findTessdataDirectory(tesseractPath)) ?? path.join(path.dirname(tesseractPath), "tessdata");
  await fs.mkdir(tessdata, { recursive: true });
  const installed: string[] = [];
  for (const [index, language] of languages.entries()) {
    const clean = language.trim();
    if (!/^[a-z_]+$/.test(clean)) throw new Error(`无效的 Tesseract 语言代码：${language}`);
    const target = path.join(tessdata, `${clean}.traineddata`);
    try {
      await fs.access(target);
      installed.push(target);
      continue;
    } catch {
      // Missing - download below.
    }
    let downloaded = false;
    let lastError: unknown = null;
    for (const { repo, tier } of TESSDATA_REPOS) {
      if (downloaded) break;
      for (const mirror of TESSDATA_MIRRORS) {
        if (downloaded) break;
        const url = mirror(repo, clean);
        try {
          await log?.(`tesseract: language data ${index + 1}/${languages.length}: ${clean} (${tier}) from ${url}`);
          await downloadSingleFileWithResume(url, target, log);
          installed.push(target);
          downloaded = true;
          await log?.(`tesseract: language data ${clean} (${tier}) installed at ${target}`);
          break;
        } catch (error) {
          lastError = error;
          await log?.(`tesseract: language ${clean} failed from ${url}: ${error instanceof Error ? error.message : String(error)}`);
        }
      }
    }
    if (!downloaded) {
      throw new Error(`下载 Tesseract 语言数据失败：${clean}（${lastError instanceof Error ? lastError.message : String(lastError)}）`);
    }
  }
  return installed;
}

/** Run the UB-Mannheim NSIS installer silently into the managed directory. */
async function installTesseractOnWindows(installerPath: string, installDirectory: string, log: DownloadToolOptions["onLog"]): Promise<void> {
  await log?.(`tesseract: running silent installer ${installerPath} /S /D=${installDirectory}`);
  try {
    // NSIS requires /D to be the last argument and unquoted. cmd /c passes the
    // whole raw command line, so /D=C:\... (even with spaces) parses correctly.
    const command = `"${installerPath}" /S /D=${installDirectory}`;
    await execFileAsync("cmd.exe", ["/d", "/s", "/c", command], {
      timeout: 20 * 60_000,
      maxBuffer: 4 * 1024 * 1024,
      windowsHide: true,
    });
  } catch (error) {
    const marker = path.join(installDirectory, "tesseract.exe");
    try {
      await fs.access(marker);
      await log?.(`tesseract: installer exited non-zero but ${marker} exists; continuing`);
      return;
    } catch {
      // Fall through and surface the original failure.
    }
    throw new Error(`Tesseract 静默安装失败：${error instanceof Error ? error.message : String(error)}`);
  }
  await log?.("tesseract: silent installer completed");
}

/**
 * 查找可用的 7-Zip 命令行工具。NSIS 安装器静默安装通常需要管理员权限
 * （无权限时 /S 会静默退出、什么都不装），改用 7-Zip 直接解包安装器
 * 可以完全避开 UAC，任何用户目录都能部署。
 */
async function locateSevenZip(): Promise<string | null> {
  const envPath = process.env.MEDIASCULPT_7Z_PATH ?? process.env.VX_AGENT_7Z_PATH;
  if (envPath) {
    try {
      await fs.access(envPath);
      return envPath;
    } catch {
      // 忽略无效环境变量，继续查找。
    }
  }
  const known = [
    "C:\\Program Files\\7-Zip\\7z.exe",
    "C:\\Program Files (x86)\\7-Zip\\7z.exe",
    "C:\\Program Files\\7-Zip\\7za.exe",
    "C:\\Program Files (x86)\\7-Zip\\7za.exe",
  ];
  for (const candidate of known) {
    try {
      await fs.access(candidate);
      return candidate;
    } catch {
      // Try the next candidate.
    }
  }
  for (const name of ["7z.exe", "7za.exe"]) {
    try {
      const { stdout } = await execFileAsync("where.exe", [name], { timeout: 5000, windowsHide: true });
      const found = stdout.split(/\r?\n/).map((line) => line.trim()).find((line) => line.length > 0);
      if (found) return found;
    } catch {
      // Not on PATH.
    }
  }
  return null;
}

/**
 * 下载并解包完整版 7-Zip（7z.exe + 7z.dll）。
 * 用 ip7z 的 MSI + 系统自带 msiexec /a 管理安装解包，全程不需要管理员权限；
 * 只有完整版 7z.exe 才支持解包 NSIS 安装器（7za.exe 不支持）。
 */
export async function ensureSevenZip(toolsRoot: string, log: DownloadToolOptions["onLog"]): Promise<string> {
  const found = await locateSevenZip();
  if (found) {
    await log?.(`tesseract: using system 7-Zip at ${found}`);
    return found;
  }
  const sevenZipDir = path.join(toolsRoot, "7zip");
  await fs.mkdir(sevenZipDir, { recursive: true });
  const msiPath = path.join(sevenZipDir, "7z2409-x64.msi");
  if (!(await fs.stat(msiPath).then((stat) => stat.size > 1_000_000).catch(() => false))) {
    let downloaded = false;
    let lastError: unknown = null;
    for (const url of ghMirrorChain("https://github.com/ip7z/7zip/releases/download/24.09/7z2409-x64.msi")) {
      try {
        await log?.(`tesseract: downloading 7-Zip ${url}`);
        await downloadSingleFileWithResume(url, msiPath, log);
        downloaded = true;
        break;
      } catch (error) {
        lastError = error;
        await log?.(`tesseract: 7-Zip download failed from ${url}: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    if (!downloaded) throw new Error(`下载 7-Zip 失败：${lastError instanceof Error ? lastError.message : String(lastError)}`);
  }
  // msiexec /a 管理安装：免管理员把 MSI 内容解包到指定目录（返回码 1 也可能成功）。
  const extractDir = path.join(sevenZipDir, "msi-out");
  const sevenZa = path.join(extractDir, "Files", "7-Zip", "7z.exe");
  if (!(await fs.stat(sevenZa).then((stat) => stat.size > 500_000).catch(() => false))) {
    await fs.mkdir(extractDir, { recursive: true });
    await log?.("tesseract: extracting 7-Zip via msiexec /a (no admin needed)");
    await execFileAsync("msiexec.exe", ["/a", msiPath, "/qn", `TARGETDIR=${extractDir}`], {
      timeout: 5 * 60_000,
      windowsHide: true,
    }).catch(() => {});
  }
  if (!(await fs.stat(sevenZa).then((stat) => stat.size > 500_000).catch(() => false))) {
    throw new Error("7-Zip 解包后未找到 7z.exe（请安装 7-Zip 或设置 MEDIASCULPT_7Z_PATH）");
  }
  await log?.(`tesseract: 7-Zip ready at ${sevenZa}`);
  return sevenZa;
}

/** 用 7-Zip 直接解包 NSIS 安装器（无需管理员权限）。 */
export async function extractNsisWithSevenZip(
  installerPath: string,
  installDirectory: string,
  toolsRoot: string,
  log: DownloadToolOptions["onLog"],
): Promise<boolean> {
  try {
    const sevenZip = await ensureSevenZip(toolsRoot, log);
    await log?.(`tesseract: extracting installer with 7-Zip to ${installDirectory}`);
    await execFileAsync(sevenZip, ["x", installerPath, `-o${installDirectory}`, "-y"], {
      timeout: 10 * 60_000,
      maxBuffer: 4 * 1024 * 1024,
      windowsHide: true,
    });
    const marker = path.join(installDirectory, "tesseract.exe");
    try {
      await fs.access(marker);
      await log?.(`tesseract: extracted ${marker}`);
      return true;
    } catch {
      return false;
    }
  } catch (error) {
    await log?.(`tesseract: 7-Zip extraction failed (${error instanceof Error ? error.message : String(error)}); falling back to silent installer`);
    return false;
  }
}

export async function extractArchive(file: string, destination: string): Promise<boolean> {
  const lower = file.toLowerCase();
  if (lower.endsWith(".zip")) {
    if (process.platform === "win32") await execFileAsync("powershell", ["-NoProfile", "-Command", "Expand-Archive", "-LiteralPath", file, "-DestinationPath", destination, "-Force"]);
    else await execFileAsync("unzip", ["-oq", file, "-d", destination]);
    return true;
  }
  if (lower.endsWith(".tar.gz") || lower.endsWith(".tgz") || lower.endsWith(".tar")) {
    await execFileAsync("tar", ["-xf", file, "-C", destination]);
    return true;
  }
  return false;
}

export async function deployExecutable(id: ToolId, directory: string): Promise<string | null> {
  const wanted = executableName(id).toLowerCase();
  const visit = async (current: string): Promise<string | null> => {
    for (const entry of await fs.readdir(current, { withFileTypes: true })) {
      const full = path.join(current, entry.name);
      if (entry.isDirectory()) { const found = await visit(full); if (found) return found; }
      else if (entry.name.toLowerCase() === wanted) return full;
    }
    return null;
  };
  const found = await visit(directory);
  if (!found) return null;
  const target = path.join(directory, executableName(id));
  if (path.resolve(found) !== path.resolve(target)) await fs.copyFile(found, target);
  if (process.platform !== "win32") await fs.chmod(target, 0o755);
  return target;
}

export async function installManagedTesseract(target: string, options: DownloadToolOptions, pkg: { installDirectory: string }): Promise<string> {
  const log = async (message: string) => { await options.onLog?.(message); };
  if (process.platform === "win32" && target.toLowerCase().endsWith(".exe")) {
    // 优先用 7-Zip 解包（无需管理员权限、不受 UAC 静默抑制影响）；
    // 找不到 7-Zip 且引导下载失败时，回退到 NSIS 静默安装。
    // 7-Zip 引导组件放到工具根目录（tesseract 的上一级），避免混入安装目录。
    const extracted = await extractNsisWithSevenZip(target, pkg.installDirectory, path.dirname(pkg.installDirectory), options.onLog);
    if (!extracted) {
      await installTesseractOnWindows(target, pkg.installDirectory, options.onLog);
    }
    await fs.unlink(target).catch(() => {});
    const deployed = (await deployExecutable("tesseract", pkg.installDirectory)) ?? pkg.installDirectory;
    await log(`tesseract: deployed ${deployed}`);
    const languages = options.tesseractLanguages?.length ? options.tesseractLanguages : TESSERACT_INSTALL_LANGUAGES;
    try {
      await installTesseractLanguageData(deployed, languages, options.onLog);
    } catch (error) {
      // 语言数据失败不阻断主安装：OCR 运行时会按需自动补装（tessdata_fast）。
      await log(`tesseract: language data install partial failure (${error instanceof Error ? error.message : String(error)}); OCR will auto-install missing languages on demand`);
    }
    return deployed;
  }
  if (process.platform === "win32") {
    throw new Error(`下载完成的内容不是可执行的 Tesseract 安装程序（${target} 不是 .exe，镜像可能返回了错误页面）`);
  }
  throw new Error("当前平台不支持自动安装 Tesseract。请在系统包管理器中安装 tesseract，或设置 MEDIASCULPT_TESSERACT_PATH 指向 tesseract 可执行文件。");
}
