import { execFile } from "node:child_process";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);
const HANDBRAKE_SCAN_TIMEOUT_MS = 10 * 60 * 1000;
const HANDBRAKE_SCAN_MAX_BUFFER = 32 * 1024 * 1024;

export type HandBrakeChapter = {
  id: number;
  startSeconds: number;
  endSeconds: number;
  title: string | null;
};

export type HandBrakeStream = {
  index: number;
  codecType: "video" | "audio" | "subtitle";
  codecName: string;
  /** HandBrake scan description, e.g. "Unknown (DTS-HD MA, 5.1 ch)". */
  description?: string | null;
  bitrate?: number | null;
  language?: string | null;
  title?: string | null;
  width?: number | null;
  height?: number | null;
  channels?: number | null;
  channelLayout?: string | null;
  sampleRate?: number | null;
  frameRate?: string | null;
  handbrakeTrackNumber?: number | null;
};

export type HandBrakeTitle = {
  titleNumber: number;
  durationSeconds: number | null;
  chapters: HandBrakeChapter[];
  streams: HandBrakeStream[];
};

export type HandBrakeTitleSummary = {
  titleNumber: number;
  durationSeconds: number | null;
  chapterCount: number;
  chapterDurationsSeconds?: number[];
};

type HandBrakeTitleLike = {
  durationSeconds: number | null;
  chapters: Array<{ startSeconds: number; endSeconds: number }>;
  streams: Array<{ codecType: string; codecName: string | null; language?: string | null; channels?: number | null; bitrate?: number | null }>;
};

const LOGICAL_TITLE_DURATION_TOLERANCE_SECONDS = 3;
const LOGICAL_TITLE_CHAPTER_TOLERANCE_SECONDS = 2;

function sameLogicalPlaybackChain(left: HandBrakeTitleLike, right: HandBrakeTitleLike): boolean {
  if (left.durationSeconds == null || right.durationSeconds == null) return false;
  if (Math.abs(left.durationSeconds - right.durationSeconds) > LOGICAL_TITLE_DURATION_TOLERANCE_SECONDS) return false;
  if (left.chapters.length !== right.chapters.length || left.streams.length !== right.streams.length) return false;
  const chaptersMatch = left.chapters.every((chapter, index) => {
    const other = right.chapters[index];
    return Boolean(other)
      && Math.abs(chapter.startSeconds - other.startSeconds) <= LOGICAL_TITLE_CHAPTER_TOLERANCE_SECONDS
      && Math.abs(chapter.endSeconds - other.endSeconds) <= LOGICAL_TITLE_CHAPTER_TOLERANCE_SECONDS;
  });
  if (!chaptersMatch) return false;
  return left.streams.every((stream, index) => {
    const other = right.streams[index];
    return Boolean(other)
      && stream.codecType === other.codecType
      && (stream.codecName ?? "").toLowerCase() === (other.codecName ?? "").toLowerCase()
      && (stream.language ?? "").toLowerCase() === (other.language ?? "").toLowerCase()
      && (stream.channels ?? null) === (other.channels ?? null)
      && (stream.bitrate ?? null) === (other.bitrate ?? null);
  });
}

/**
 * Collapse repeated logical playback chains before they reach the normal title
 * list. HandBrake can expose the same long DVD programme through several PGC
 * numbers; leaving all of them visible makes the user select the same payload
 * repeatedly. Titles with different chapter layouts remain available.
 */
export function consolidateDvdHandBrakeTitles<T extends HandBrakeTitleLike>(titles: T[], log?: (message: string) => void): T[] {
  const ordered = titles.slice().sort((a, b) => {
    const aNumber = Number((a as T & { titleNumber?: number }).titleNumber ?? 0);
    const bNumber = Number((b as T & { titleNumber?: number }).titleNumber ?? 0);
    return aNumber - bNumber;
  });
  const kept: T[] = [];
  let duplicateCount = 0;
  for (const title of ordered) {
    if (kept.some((existing) => sameLogicalPlaybackChain(existing, title))) {
      duplicateCount += 1;
      continue;
    }
    kept.push(title);
  }
  if (duplicateCount > 0) {
    log?.(`DVD HandBrake 标题折叠 ${duplicateCount} 条重复逻辑播放链；保留 ${kept.length} 条不同章节/流轨布局的标题`);
  }
  return kept;
}

function durationToSeconds(value: unknown): number {
  const duration = value as { Hours?: number; Minutes?: number; Seconds?: number } | null | undefined;
  if (!duration) return 0;
  return Number(duration.Hours ?? 0) * 3600 + Number(duration.Minutes ?? 0) * 60 + Number(duration.Seconds ?? 0);
}

function textValue(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}

function numberValue(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function frameRateValue(value: unknown): string | null {
  const frameRate = value as { Num?: unknown; Den?: unknown } | null | undefined;
  const num = numberValue(frameRate?.Num);
  const den = numberValue(frameRate?.Den);
  return num && den ? `${num}/${den}` : null;
}

function channelsFromLayout(layout: string | null): number | null {
  if (!layout) return null;
  const normalized = layout.toLowerCase();
  if (normalized.includes("mono")) return 1;
  if (normalized.includes("stereo")) return 2;
  const match = normalized.match(/(\d+)(?:\.(\d+))?/);
  if (!match) return null;
  const base = Number(match[1]);
  const extra = match[2] ? Number(match[2]) : 0;
  return Number.isFinite(base) ? base + (Number.isFinite(extra) ? extra : 0) : null;
}

function parseHandBrakeStreams(title: Record<string, unknown>): HandBrakeStream[] {
  const streams: HandBrakeStream[] = [];
  const geometry = title.Geometry as { Width?: unknown; Height?: unknown } | null | undefined;
  const videoCodec = textValue(title.VideoCodec) ?? textValue(title.VideoCodecName) ?? "video";
  streams.push({
    index: 0,
    codecType: "video",
    codecName: videoCodec,
    width: numberValue(geometry?.Width),
    height: numberValue(geometry?.Height),
    frameRate: frameRateValue(title.FrameRate),
    handbrakeTrackNumber: 0,
  });

  let nextIndex = 1;
  const audioList = Array.isArray(title.AudioList) ? title.AudioList as Array<Record<string, unknown>> : [];
  const seenAudio = new Set<string>();
  for (const audio of audioList) {
    const channelLayout = textValue(audio.ChannelLayout);
    const stream: HandBrakeStream = {
      index: nextIndex++,
      codecType: "audio",
      codecName: textValue(audio.CodecName) ?? textValue(audio.Codec) ?? "audio",
      ...(textValue(audio.Description) ? { description: textValue(audio.Description) } : {}),
      ...(numberValue(audio.BitRate) !== null ? { bitrate: numberValue(audio.BitRate) } : {}),
      language: textValue(audio.LanguageCode) ?? textValue(audio.Language),
      title: textValue(audio.Language) ?? textValue(audio.Name),
      channels: channelsFromLayout(channelLayout),
      channelLayout,
      sampleRate: numberValue(audio.SampleRate),
      handbrakeTrackNumber: numberValue(audio.TrackNumber) ?? nextIndex - 1,
    };
    // HandBrake occasionally lists the same physical audio track twice for a
    // Blu-ray (e.g. DTS core duplicated); keep only the first identical entry.
    const signature = [
      stream.codecName,
      stream.description ?? "",
      stream.language ?? "",
      stream.channels ?? "",
      stream.bitrate ?? "",
      stream.handbrakeTrackNumber ?? "",
    ].join("|");
    if (!seenAudio.has(signature)) {
      seenAudio.add(signature);
      streams.push(stream);
    }
  }

  const subtitleList = Array.isArray(title.SubtitleList) ? title.SubtitleList as Array<Record<string, unknown>> : [];
  for (const subtitle of subtitleList) {
    streams.push({
      index: nextIndex++,
      codecType: "subtitle",
      codecName: textValue(subtitle.Format) ?? textValue(subtitle.CodecName) ?? "subtitle",
      ...(textValue(subtitle.Description) ? { description: textValue(subtitle.Description) } : {}),
      language: textValue(subtitle.LanguageCode) ?? textValue(subtitle.Language),
      title: textValue(subtitle.Language) ?? textValue(subtitle.Name),
      handbrakeTrackNumber: numberValue(subtitle.TrackNumber) ?? nextIndex - 1,
    });
  }

  return streams;
}

function extractJsonTitleSet(output: string): unknown | null {
  const marker = "JSON Title Set:";
  const markerIndex = output.indexOf(marker);
  if (markerIndex < 0) return null;
  const afterMarker = output.slice(markerIndex + marker.length);
  const start = afterMarker.indexOf("{");
  if (start < 0) return null;
  const jsonText = afterMarker.slice(start).trim();
  try {
    return JSON.parse(jsonText);
  } catch {
    const end = jsonText.lastIndexOf("}");
    if (end < 0) return null;
    try {
      return JSON.parse(jsonText.slice(0, end + 1));
    } catch {
      return null;
    }
  }
}

export function parseHandBrakeScanOutput(output: string): HandBrakeTitle[] {
  const parsed = extractJsonTitleSet(output) as { TitleList?: Array<Record<string, unknown>> } | null;
  const titleList = parsed?.TitleList;
  if (!Array.isArray(titleList)) return [];

  const titles: HandBrakeTitle[] = [];
  for (const title of titleList) {
    const titleNumber = Number(title.Index);
    if (!Number.isInteger(titleNumber) || titleNumber <= 0) continue;
    const chapterList = Array.isArray(title.ChapterList) ? title.ChapterList as Array<Record<string, unknown>> : [];
    let cursor = 0;
    const chapters = chapterList.map((chapter, chapterIndex) => {
      const duration = durationToSeconds(chapter.Duration);
      const startSeconds = cursor;
      const endSeconds = cursor + duration;
      cursor = endSeconds;
      return {
        id: chapterIndex,
        startSeconds,
        endSeconds,
        title: typeof chapter.Name === "string" && chapter.Name.trim() ? chapter.Name.trim() : `Chapter ${chapterIndex + 1}`,
      };
    });
    titles.push({
      titleNumber,
      durationSeconds: durationToSeconds(title.Duration) || (cursor || null),
      chapters,
      streams: parseHandBrakeStreams(title),
    });
  }
  return titles;
}

function parseScanClock(value: string): number | null {
  const match = /^(\d+):(\d{2}):(\d{2})(?:\.(\d+))?$/.exec(value);
  if (!match) return null;
  const hours = Number(match[1]);
  const minutes = Number(match[2]);
  const seconds = Number(match[3]);
  const fraction = match[4] ? Number(`0.${match[4]}`) : 0;
  const total = hours * 3600 + minutes * 60 + seconds + fraction;
  return Number.isFinite(total) ? total : null;
}

/**
 * HandBrake 1.11 emits a complete human-readable title scan but its JSON
 * Title Set may contain only MainFeature. Read the title/duration/chapter
 * records from that scan so callers can request detailed metadata per title.
 */
export function parseHandBrakeScanSummaries(output: string): HandBrakeTitleSummary[] {
  const summaries = new Map<number, HandBrakeTitleSummary>();
  let pendingDuration: number | null = null;
  let currentTitle: HandBrakeTitleSummary | null = null;
  for (const line of output.split(/\r?\n/)) {
    const durationMatch = /scan: duration is (\d+:\d{2}:\d{2}(?:\.\d+)?)/.exec(line);
    if (durationMatch) {
      pendingDuration = parseScanClock(durationMatch[1]);
      continue;
    }
    const titleMatch = /scan: title (\d+) has (\d+) chapters/.exec(line);
    if (titleMatch) {
      const titleNumber = Number(titleMatch[1]);
      const chapterCount = Number(titleMatch[2]);
      if (!Number.isInteger(titleNumber) || titleNumber <= 0 || !Number.isInteger(chapterCount) || chapterCount < 0) continue;
      const summary: HandBrakeTitleSummary = {
        titleNumber,
        durationSeconds: pendingDuration,
        chapterCount,
      };
      summaries.set(titleNumber, summary);
      currentTitle = summary;
      pendingDuration = null;
      continue;
    }
    const chapterMatch = /scan: chap \d+, (\d+(?:\.\d+)?) ms/.exec(line);
    if (chapterMatch && currentTitle) {
      const duration = Number(chapterMatch[1]) / 1000;
      if (Number.isFinite(duration)) {
        currentTitle.chapterDurationsSeconds = [...(currentTitle.chapterDurationsSeconds ?? []), duration];
      }
    }
  }
  return [...summaries.values()].sort((a, b) => a.titleNumber - b.titleNumber);
}

export function mergeHandBrakeChapters<T extends { handbrakeTitleNumber?: number | null; chapters?: unknown[] }>(
  tracks: T[],
  handBrakeTitles: HandBrakeTitle[],
): T[] {
  return tracks.map((track) => {
    const handbrakeTitleNumber = track.handbrakeTitleNumber;
    const match = typeof handbrakeTitleNumber === "number" && handbrakeTitleNumber > 0
      ? handBrakeTitles.find((title) => title.titleNumber === handbrakeTitleNumber) ?? null
      : null;
    if (!match) return track;
    return {
      ...track,
      chapters: match.chapters.length ? match.chapters : track.chapters,
      ...((match.streams?.length ?? 0) > 0 ? { streams: match.streams } : {}),
    };
  });
}

export async function scanHandBrakeTitles(sourcePath: string, handbrakeCli = "HandBrakeCLI"): Promise<HandBrakeTitle[]> {
  const result = await execFileAsync(handbrakeCli, ["--input", sourcePath, "--title", "0", "--scan", "--json"], {
    timeout: HANDBRAKE_SCAN_TIMEOUT_MS,
    maxBuffer: HANDBRAKE_SCAN_MAX_BUFFER,
  });
  return parseHandBrakeScanOutput(`${result.stdout}\n${result.stderr}`);
}
