import {
  lookupAll,
  metadataIdentityMatches,
  type LookupOutcome,
  type MetadataResult,
} from "./metadata";
import { detectLocalProxyUrl } from "./http-client";

/**
 * Metadata source self-check.
 *
 * The point of this module is to make source quality *reproducible by the user*
 * instead of something the developer asserts. It answers three questions with
 * evidence:
 *
 *   1. Which sources are actually usable right now? A source that needs an API
 *      key is reported as disabled rather than silently skipped.
 *   2. For known titles, does a lookup return a candidate, and does that
 *      candidate survive the identity gate? A candidate that is fetched but then
 *      rejected is reported as `rejected`, which is the difference between "the
 *      provider has nothing" and "our matching is too strict".
 *   3. What failed, and why — the provider error text is carried through.
 *
 * It performs read-only HEAD/GET style lookups. It never writes posters, never
 * provisions tools, and never downloads datasets.
 */

export type SelfCheckSourceId =
  | "imdb-suggestion"
  | "douban"
  | "tmdb"
  | "omdb"
  | "imdb-local"
  | "wikipedia";

export type SelfCheckCase = {
  /** Title handed to the lookup, normally the parsed filename title. */
  query: string;
  year?: number;
  /** What the user expects to be identified, for a readable report. */
  expect?: string;
};

export type SelfCheckCaseResult = {
  query: string;
  expected: string | null;
  outcome: "identified" | "rejected" | "no-candidate" | "error";
  candidate: {
    title: string | null;
    titleEn: string | null;
    year: number | null;
    imdbId: string | null;
    source: string | null;
    hasPoster: boolean;
    mediaType: string | null;
  } | null;
  /** Present when the provider returned candidates that the gate then refused. */
  rejectedCount: number;
  errors: string[];
};

/**
 * Which network path metadata and posters actually take.
 *
 * "I filled in a proxy and still got empty results" was impossible to diagnose
 * from the report, because nothing said whether a proxy was in play. Reporting
 * the configured, detected and effective values separately makes a VPN that is
 * running but not recognised visible instead of something the user must guess.
 */
export type SelfCheckNetwork = {
  /** 用户在设置里填写的代理；为空表示留空、由程序自动探测。 */
  configuredProxyUrl: string | null;
  /** 本机自动探测到的本地代理（忽略用户配置）；null 表示没探测到。 */
  detectedProxyUrl: string | null;
  /** 资料与海报实际使用的代理；null 表示直连。 */
  effectiveProxyUrl: string | null;
};

export type SelfCheckReport = {
  checkedAt: string;
  health: "ok" | "degraded" | "broken";
  /** Which capability tier is active, and what the next one would add. */
  capability: {
    current: CapabilityTierId;
    tiers: CapabilityTier[];
  };
  network: SelfCheckNetwork;
  sources: Array<{
    id: SelfCheckSourceId;
    label: string;
    status: "enabled" | "disabled" | "unavailable";
    detail: string;
  }>;
  cases: SelfCheckCaseResult[];
  summary: {
    total: number;
    identified: number;
    rejected: number;
    noCandidate: number;
    error: number;
  };
};

export type SelfCheckOptions = {
  cases: SelfCheckCase[];
  config: {
    tmdbApiKey?: string | null;
    omdbApiKey?: string | null;
    imdbTitleCount?: number | null;
    /**
     * True when any LLM provider key is configured. Passed in rather than
     * derived from one specific provider: DeepSeek is a first-class option, and
     * checking only `openaiApiKey` reported the AI tier as unavailable to a user
     * who had a working DeepSeek key.
     */
    aiAvailable?: boolean;
  };
  language?: string;
  proxyUrl?: string | null;
  /**
   * Injectable for tests; defaults to the real local proxy probe. Unit tests
   * must not be coupled to whichever proxy happens to run on the machine.
   */
  detectProxy?: () => Promise<string | null>;
  /** Injectable for tests; defaults to the real multi-provider lookup. */
  lookup?: (input: {
    rawQuery: string;
    year?: number;
    language: string;
    config: SelfCheckOptions["config"];
    proxyUrl?: string | null;
  }) => Promise<LookupOutcome>;
  /** Injectable clock so the report is deterministic under test. */
  now?: () => Date;
};

/** Sources that need no credentials and should always be reachable. */
const KEYLESS_SOURCES: Array<{ id: SelfCheckSourceId; label: string }> = [
  { id: "imdb-suggestion", label: "IMDb suggestion (keyless)" },
  { id: "douban", label: "Douban suggestion (keyless)" },
  { id: "wikipedia", label: "Wikipedia (keyless)" },
];

export type CapabilityTierId = "filename" | "keyless" | "keyed" | "ai";

export type CapabilityTier = {
  id: CapabilityTierId;
  label: string;
  available: boolean;
  /** What this tier can supply that the tiers below it cannot. */
  provides: string[];
  /** How to reach this tier, shown when it is not available yet. */
  requirement: string | null;
};

/**
 * Describe the capability ladder so a user — or their customer — can see which
 * layer is active and exactly what enabling the next one would add. This is the
 * user-facing half of graceful degradation: "no AI" must not mean "no
 * information", it means a lower tier with a stated, bounded feature set.
 */
export function describeCapabilityTiers(config: SelfCheckOptions["config"]): {
  current: CapabilityTierId;
  tiers: CapabilityTier[];
} {
  const keyed = Boolean(config.tmdbApiKey || config.omdbApiKey || (config.imdbTitleCount ?? 0) > 0);
  const ai = Boolean(config.aiAvailable);
  const current: CapabilityTierId = ai ? "ai" : keyed ? "keyed" : "keyless";
  return {
    current,
    tiers: [
      {
        id: "filename",
        label: "Filename only (offline, no configuration)",
        available: true,
        provides: ["title", "year", "existing artwork in the folder", "video/audio technical facts"],
        requirement: null,
      },
      {
        id: "keyless",
        label: "Keyless sources (network required)",
        available: true,
        provides: ["poster", "IMDb id", "cast", "English title", "plot summary"],
        requirement: null,
      },
      {
        id: "keyed",
        label: "Keyed sources (TMDb / OMDb / local IMDb dataset)",
        available: keyed,
        provides: ["multiple directors", "localised titles and summaries", "ratings", "genres", "runtime"],
        requirement: keyed ? null : "add a TMDb or OMDb API key, or import the local IMDb dataset",
      },
      {
        id: "ai",
        label: "AI enrichment (optional)",
        available: ai,
        provides: ["title correction", "generated synopsis", "translation of sparse records"],
        requirement: ai ? null : "configure an LLM provider key (optional; records are marked as AI-sourced)",
      },
    ],
  };
}

function describeDiscoveredSources(
  config: SelfCheckOptions["config"],
): SelfCheckReport["sources"] {
  const sources: SelfCheckReport["sources"] = [
    { id: "imdb-suggestion", label: "IMDb suggestion (keyless)", status: "enabled", detail: "always queried" },
    { id: "douban", label: "Douban suggestion (keyless)", status: "enabled", detail: "Chinese/English title bridge" },
    { id: "wikipedia", label: "Wikipedia (keyless)", status: "enabled", detail: "always queried" },
    {
      id: "tmdb",
      label: "TMDb",
      status: config.tmdbApiKey ? "enabled" : "disabled",
      detail: config.tmdbApiKey ? "API key configured" : "no API key configured",
    },
    {
      id: "omdb",
      label: "OMDb",
      status: config.omdbApiKey ? "enabled" : "disabled",
      detail: config.omdbApiKey ? "API key configured" : "no API key configured",
    },
    {
      id: "imdb-local",
      label: "Local IMDb dataset",
      status: (config.imdbTitleCount ?? 0) > 0 ? "enabled" : "disabled",
      detail: (config.imdbTitleCount ?? 0) > 0
        ? `${config.imdbTitleCount} titles imported`
        : "no dataset imported",
    },
  ];
  return sources;
}

function summarizeCase(
  testCase: SelfCheckCase,
  outcome: LookupOutcome,
  queryYear?: number,
): SelfCheckCaseResult {
  const candidates = outcome.results ?? [];
  const accepted = candidates.filter((candidate) =>
    metadataIdentityMatches({
      candidate,
      queryTitle: testCase.query,
      queryYear: testCase.year ?? queryYear,
    }),
  );
  const pick: MetadataResult | undefined = accepted[0];
  const state: SelfCheckCaseResult["outcome"] = pick
    ? "identified"
    : candidates.length > 0
      ? "rejected"
      : outcome.errors.length > 0
        ? "error"
        : "no-candidate";
  return {
    query: testCase.query,
    expected: testCase.expect ?? null,
    outcome: state,
    candidate: pick
      ? {
          title: pick.title ?? null,
          titleEn: pick.titleEn ?? null,
          year: pick.year ?? null,
          imdbId: pick.imdbId ?? null,
          source: pick.source ?? null,
          hasPoster: Boolean(pick.poster),
          mediaType: pick.mediaType ?? null,
        }
      : null,
    rejectedCount: candidates.length - accepted.length,
    errors: outcome.errors ?? [],
  };
}

/**
 * 说明当前网络路径。即使已经手填代理也照样探测一次：用户需要看到"VPN 到底
 * 有没有被识别到"，而探测失败绝不能让整份自检失败。
 */
async function describeNetwork(
  configured: string | null,
  detectProxy: () => Promise<string | null>,
): Promise<SelfCheckNetwork> {
  const configuredProxyUrl = configured?.trim() || null;
  const detectedProxyUrl = await detectProxy().catch(() => null);
  return {
    configuredProxyUrl,
    detectedProxyUrl,
    effectiveProxyUrl: configuredProxyUrl ?? detectedProxyUrl,
  };
}

export async function runMetadataSelfCheck(options: SelfCheckOptions): Promise<SelfCheckReport> {
  const language = options.language ?? "zh-CN";
  const lookup = options.lookup ?? ((input) => lookupAll(input as Parameters<typeof lookupAll>[0]));
  const now = options.now ?? (() => new Date());
  const network = await describeNetwork(
    options.proxyUrl ?? null,
    options.detectProxy ?? detectLocalProxyUrl,
  );

  const cases: SelfCheckCaseResult[] = [];
  for (const testCase of options.cases) {
    try {
      const outcome = await lookup({
        rawQuery: testCase.query,
        year: testCase.year,
        language,
        config: options.config,
        // 用已经确定下来的生效代理，保证报告与实际查询走的是同一条路。
        proxyUrl: network.effectiveProxyUrl,
      });
      cases.push(summarizeCase(testCase, outcome, testCase.year));
    } catch (error) {
      cases.push({
        query: testCase.query,
        expected: testCase.expect ?? null,
        outcome: "error",
        candidate: null,
        rejectedCount: 0,
        errors: [error instanceof Error ? error.message : String(error)],
      });
    }
  }

  const summary = {
    total: cases.length,
    identified: cases.filter((entry) => entry.outcome === "identified").length,
    rejected: cases.filter((entry) => entry.outcome === "rejected").length,
    noCandidate: cases.filter((entry) => entry.outcome === "no-candidate").length,
    error: cases.filter((entry) => entry.outcome === "error").length,
  };

  // "degraded" is the honest verdict when something worked but not everything:
  // a partially reachable provider list is exactly what the user needs to see.
  const health: SelfCheckReport["health"] =
    summary.total === 0
      ? "broken"
      : summary.identified === 0 && summary.error === summary.total
        ? "broken"
        : summary.error > 0 || summary.rejected > 0
          ? "degraded"
          : "ok";

  return {
    checkedAt: now().toISOString(),
    health,
    capability: describeCapabilityTiers(options.config),
    network,
    sources: describeDiscoveredSources(options.config),
    cases,
    summary,
  };
}

/** Suggested cases: a mainstream film, a title with a release-year suffix, and
 *  a work whose year is part of its name — the three shapes that broke. */
export const SELF_CHECK_DEFAULT_CASES: SelfCheckCase[] = [
  { query: "A Beautiful Mind", year: 2001, expect: "A Beautiful Mind" },
  { query: "The Age of Innocence", year: 1993, expect: "The Age of Innocence" },
  { query: "2046", year: 2004, expect: "2046" },
];

export { KEYLESS_SOURCES };
