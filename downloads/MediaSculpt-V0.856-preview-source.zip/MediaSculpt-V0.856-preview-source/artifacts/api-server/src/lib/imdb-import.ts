import { createReadStream } from "fs";
import { Readable } from "stream";
import type { DatabaseSync } from "node:sqlite";
import os from "os";
import path from "path";
import zlib from "zlib";
import readline from "readline";
import { count, sql } from "drizzle-orm";
import { db, imdbTitlesTable, configTable, sqliteClient } from "@workspace/db";
import { logger } from "./logger";

/**
 * Importer for the free IMDb TSV datasets (https://datasets.imdbws.com/,
 * free for non-commercial use).
 *
 * Core pass: title.ratings.tsv.gz (small, held in memory) and
 * title.basics.tsv.gz streamed row by row into imdb_titles.
 *
 * Optional people pass (directors + cast): title.crew.tsv.gz,
 * title.principals.tsv.gz and name.basics.tsv.gz are streamed into temporary
 * tables and aggregated back into imdb_titles.directors / imdb_titles.cast.
 * The people pass requires the local SQLite backend (raw DatabaseSync); on
 * Postgres it is skipped for now.
 *
 * Every dataset can be read from a local .tsv/.tsv.gz path for machines where
 * the CDN is slow — download manually and pass the paths.
 */

const BASICS_URL = "https://datasets.imdbws.com/title.basics.tsv.gz";
const RATINGS_URL = "https://datasets.imdbws.com/title.ratings.tsv.gz";
const CREW_URL = "https://datasets.imdbws.com/title.crew.tsv.gz";
const NAMES_URL = "https://datasets.imdbws.com/name.basics.tsv.gz";
const PRINCIPALS_URL = "https://datasets.imdbws.com/title.principals.tsv.gz";

/** Title types worth keeping for a movie/DVD tool (drops 8M+ TV episodes) */
const KEEP_TYPES = new Set(["movie", "tvMovie", "tvSeries", "tvMiniSeries", "video"]);
/** title.principals categories that make up the on-screen cast */
const CAST_CATEGORIES = new Set(["actor", "actress", "self"]);
const MAX_DIRECTORS = 5;
const MAX_CAST = 12;
const BATCH_SIZE = 1000;

export interface ImdbImportStatus {
  status: "idle" | "running" | "done" | "error";
  phase: string;
  linesRead: number;
  titlesImported: number;
  /** name.basics lines scanned during the people pass */
  peopleRead: number;
  /** people actually linked into directors/cast */
  peopleImported: number;
  error: string | null;
  startedAt: string | null;
  finishedAt: string | null;
}

const state: ImdbImportStatus = {
  status: "idle",
  phase: "",
  linesRead: 0,
  titlesImported: 0,
  peopleRead: 0,
  peopleImported: 0,
  error: null,
  startedAt: null,
  finishedAt: null,
};

export function getImportStatus(): ImdbImportStatus {
  return { ...state };
}

/** "\N" is the dataset's NULL marker */
function tsvField(v: string | undefined): string | null {
  return v === undefined || v === "" || v === "\\N" ? null : v;
}

export interface ImdbTitleRow {
  tconst: string;
  titleType: string;
  primaryTitle: string;
  originalTitle: string;
  startYear: number | null;
  runtimeMinutes: number | null;
  genres: string | null;
  rating: number | null;
  votes: number | null;
}

/**
 * Convert one title.basics TSV line into an insert row, or null if the
 * title should be skipped (wrong type, adult, malformed).
 * Columns: tconst titleType primaryTitle originalTitle isAdult startYear endYear runtimeMinutes genres
 */
export function basicsLineToRow(
  line: string,
  ratings: Map<string, { rating: number; votes: number }>
): ImdbTitleRow | null {
  const f = line.split("\t");
  if (f.length < 9) return null;
  const [tconst, titleType, primaryTitle, originalTitle, isAdult, startYear, , runtimeMinutes, genres] = f;
  if (!tconst?.startsWith("tt")) return null;          // header or garbage
  if (!KEEP_TYPES.has(titleType)) return null;
  if (isAdult === "1") return null;
  if (!tsvField(primaryTitle)) return null;

  const r = ratings.get(tconst);
  const year = tsvField(startYear);
  const runtime = tsvField(runtimeMinutes);
  return {
    tconst,
    titleType,
    primaryTitle,
    originalTitle: tsvField(originalTitle) ?? primaryTitle,
    startYear: year ? parseInt(year) : null,
    runtimeMinutes: runtime ? parseInt(runtime) : null,
    genres: tsvField(genres),
    rating: r?.rating ?? null,
    votes: r?.votes ?? null,
  };
}

/** Open a line reader over a URL or local path, transparently gunzipping */
async function openLines(source: string): Promise<readline.Interface> {
  let raw: NodeJS.ReadableStream;
  if (/^https?:\/\//.test(source)) {
    const resp = await fetch(source);
    if (!resp.ok || !resp.body) throw new Error(`下载失败 ${source}: HTTP ${resp.status}`);
    raw = Readable.fromWeb(resp.body as import("stream/web").ReadableStream);
  } else {
    raw = createReadStream(source);
  }
  const input = source.endsWith(".gz") ? raw.pipe(zlib.createGunzip()) : raw;
  return readline.createInterface({ input, crlfDelay: Infinity });
}

async function loadRatings(source: string): Promise<Map<string, { rating: number; votes: number }>> {
  const ratings = new Map<string, { rating: number; votes: number }>();
  const rl = await openLines(source);
  for await (const line of rl) {
    // Columns: tconst averageRating numVotes
    const [tconst, avg, votes] = line.split("\t");
    if (!tconst?.startsWith("tt")) continue;
    const rating = parseFloat(avg);
    const numVotes = parseInt(votes);
    if (!Number.isNaN(rating)) {
      ratings.set(tconst, { rating, votes: Number.isNaN(numVotes) ? 0 : numVotes });
    }
  }
  return ratings;
}

async function flushBatch(batch: ImdbTitleRow[]): Promise<void> {
  if (batch.length === 0) return;
  await db.insert(imdbTitlesTable)
    .values(batch)
    .onConflictDoUpdate({
      target: imdbTitlesTable.tconst,
      set: {
        titleType: sql`excluded.title_type`,
        primaryTitle: sql`excluded.primary_title`,
        originalTitle: sql`excluded.original_title`,
        startYear: sql`excluded.start_year`,
        runtimeMinutes: sql`excluded.runtime_minutes`,
        genres: sql`excluded.genres`,
        rating: sql`excluded.rating`,
        votes: sql`excluded.votes`,
      },
    });
}

export interface ImdbImportOptions {
  basicsPath?: string;
  ratingsPath?: string;
  crewPath?: string;
  namesPath?: string;
  principalsPath?: string;
  /** Download crew/names/principals and populate directors + cast */
  withPeople?: boolean;
}

/**
 * Run the full import. Call sites must check getImportStatus().status first;
 * this rejects if an import is already running.
 */
export async function runImdbImport(opts: ImdbImportOptions = {}): Promise<void> {
  if (state.status === "running") throw new Error("导入已在进行中");

  state.status = "running";
  state.error = null;
  state.linesRead = 0;
  state.titlesImported = 0;
  state.peopleRead = 0;
  state.peopleImported = 0;
  state.startedAt = new Date().toISOString();
  state.finishedAt = null;

  try {
    state.phase = "下载/读取评分数据 (title.ratings)";
    logger.info("IMDb import: loading ratings…");
    const ratings = await loadRatings(opts.ratingsPath || RATINGS_URL);
    logger.info({ count: ratings.size }, "IMDb import: ratings loaded");

    state.phase = "导入片名数据 (title.basics)";
    const rl = await openLines(opts.basicsPath || BASICS_URL);
    let batch: ImdbTitleRow[] = [];
    for await (const line of rl) {
      state.linesRead++;
      const row = basicsLineToRow(line, ratings);
      if (!row) continue;
      batch.push(row);
      if (batch.length >= BATCH_SIZE) {
        await flushBatch(batch);
        state.titlesImported += batch.length;
        batch = [];
      }
    }
    await flushBatch(batch);
    state.titlesImported += batch.length;

    state.phase = "更新统计";
    // drizzle's count() emits `count(*)::int`, which SQLite rejects, so use a
    // raw count on the SQLite backend and keep the portable version for Postgres.
    let total: number;
    if (sqliteClient) {
      const row = sqliteClient.prepare("SELECT count(*) AS total FROM imdb_titles").get() as
        | { total: number }
        | undefined;
      total = Number(row?.total ?? 0);
    } else {
      const [{ value }] = await db.select({ value: count() }).from(imdbTitlesTable);
      total = value;
    }
    const cfgRows = await db.select({ id: configTable.id }).from(configTable).limit(1);
    if (cfgRows.length === 0) {
      // A fresh install may reach the importer before the UI ever called
      // getConfig(), so create the config row with the same platform defaults.
      const home = os.homedir();
      const defaultWatch =
        process.platform === "win32" ? home || "C:\\" : path.join(home, "Downloads");
      const defaultOutput =
        process.platform === "win32"
          ? path.join(home || process.cwd(), "Videos", "MediaSculpt Output")
          : path.join(home, "Movies", "MediaSculpt Output");
      await db.insert(configTable).values({
        watchDirectory: defaultWatch,
        outputDirectory: defaultOutput,
        imdbTitleCount: total,
        imdbLastImportAt: new Date(),
      });
    } else {
      await db.update(configTable).set({
        imdbTitleCount: total,
        imdbLastImportAt: new Date(),
      });
    }

    const wantsPeople =
      opts.withPeople === true ||
      Boolean(opts.crewPath || opts.namesPath || opts.principalsPath);
    if (wantsPeople) {
      if (sqliteClient) {
        await enrichPeople(opts);
      } else {
        logger.warn(
          "IMDb import: people pass skipped (raw SQLite client unavailable; Postgres enrichment is not implemented yet)"
        );
      }
    }

    state.status = "done";
    state.phase = "完成";
    state.finishedAt = new Date().toISOString();
    logger.info(
      { imported: state.titlesImported, people: state.peopleImported, total },
      "IMDb import complete"
    );
  } catch (e) {
    state.status = "error";
    state.error = e instanceof Error ? e.message : String(e);
    state.finishedAt = new Date().toISOString();
    logger.error({ err: e }, "IMDb import failed");
    throw e;
  }
}

/**
 * People pass: stream title.crew / title.principals / name.basics into
 * temporary tables, then backfill imdb_titles.directors and .cast with the
 * top directors and cast per title. Missing local paths fall back to the
 * official download URLs.
 */
async function enrichPeople(opts: ImdbImportOptions): Promise<void> {
  const client = sqliteClient!;
  const stagingTables = [
    "tmp_imdb_cast_agg",
    "tmp_imdb_directors_agg",
    "tmp_imdb_names",
    "tmp_imdb_nconst",
    "tmp_imdb_principals",
    "tmp_imdb_crew",
    "tmp_imdb_keep",
  ];

  try {
    state.phase = "准备人员导入";
    for (const table of stagingTables) client.exec(`DROP TABLE IF EXISTS ${table}`);
    client.exec("CREATE TEMP TABLE tmp_imdb_keep (tconst TEXT PRIMARY KEY)");
    client.exec("INSERT INTO tmp_imdb_keep (tconst) SELECT tconst FROM imdb_titles");

    // title.crew → director nconsts (columns: tconst directors writers)
    state.phase = "读取导演数据 (title.crew)";
    client.exec("CREATE TEMP TABLE tmp_imdb_crew (tconst TEXT NOT NULL, nconst TEXT NOT NULL)");
    client.exec("CREATE INDEX tmp_imdb_crew_tconst_idx ON tmp_imdb_crew (tconst)");
    const crewKeep = client.prepare("SELECT 1 FROM tmp_imdb_keep WHERE tconst = ?");
    const insertCrew = makeBatchedInsert(
      client.prepare("INSERT INTO tmp_imdb_crew (tconst, nconst) VALUES (?, ?)")
    );
    client.exec("BEGIN");
    const crewRl = await openLines(opts.crewPath || CREW_URL);
    for await (const line of crewRl) {
      state.linesRead++;
      const [tconst, directors] = line.split("\t");
      if (!tconst?.startsWith("tt") || !directors || directors === "\\N") continue;
      if (!crewKeep.get(tconst)) continue;
      for (const nconst of directors.split(",")) {
        if (nconst?.startsWith("nm")) insertCrew([tconst, nconst]);
      }
    }
    client.exec("COMMIT");
    logger.info("IMDb import: crew loaded");

    // title.principals → cast candidates (columns: tconst ordering nconst category job characters)
    state.phase = "读取演员数据 (title.principals)";
    client.exec(
      "CREATE TEMP TABLE tmp_imdb_principals (tconst TEXT NOT NULL, ordering INTEGER NOT NULL, nconst TEXT NOT NULL)"
    );
    client.exec(
      "CREATE INDEX tmp_imdb_principals_tconst_idx ON tmp_imdb_principals (tconst, ordering)"
    );
    const principalKeep = client.prepare("SELECT 1 FROM tmp_imdb_keep WHERE tconst = ?");
    const insertPrincipal = makeBatchedInsert(
      client.prepare("INSERT INTO tmp_imdb_principals (tconst, ordering, nconst) VALUES (?, ?, ?)")
    );
    client.exec("BEGIN");
    const principalRl = await openLines(opts.principalsPath || PRINCIPALS_URL);
    for await (const line of principalRl) {
      state.linesRead++;
      const [tconst, ordering, nconst, category] = line.split("\t");
      if (!tconst?.startsWith("tt") || !nconst?.startsWith("nm")) continue;
      if (!CAST_CATEGORIES.has(category ?? "")) continue;
      if (!principalKeep.get(tconst)) continue;
      const ord = parseInt(ordering ?? "", 10);
      insertPrincipal([tconst, Number.isNaN(ord) ? 0 : ord, nconst]);
    }
    client.exec("COMMIT");
    logger.info("IMDb import: principals loaded");

    // name.basics → keep only names referenced above (columns: nconst primaryName ...)
    state.phase = "读取人名数据 (name.basics)";
    client.exec("CREATE TEMP TABLE tmp_imdb_nconst (nconst TEXT PRIMARY KEY)");
    client.exec("INSERT INTO tmp_imdb_nconst (nconst) SELECT DISTINCT nconst FROM tmp_imdb_crew");
    client.exec(
      "INSERT OR IGNORE INTO tmp_imdb_nconst (nconst) SELECT DISTINCT nconst FROM tmp_imdb_principals"
    );
    client.exec("CREATE TEMP TABLE tmp_imdb_names (nconst TEXT PRIMARY KEY, primary_name TEXT NOT NULL)");
    const wantName = client.prepare("SELECT 1 FROM tmp_imdb_nconst WHERE nconst = ?");
    const insertName = makeBatchedInsert(
      client.prepare("INSERT INTO tmp_imdb_names (nconst, primary_name) VALUES (?, ?)")
    );
    client.exec("BEGIN");
    const namesRl = await openLines(opts.namesPath || NAMES_URL);
    for await (const line of namesRl) {
      state.linesRead++;
      state.peopleRead++;
      const [nconst, primaryName] = line.split("\t");
      if (!nconst?.startsWith("nm")) continue;
      const name = primaryName && primaryName !== "\\N" ? primaryName : null;
      if (!name) continue;
      if (!wantName.get(nconst)) continue;
      insertName([nconst, name]);
    }
    client.exec("COMMIT");
    const peopleRows = client.prepare("SELECT count(*) AS people FROM tmp_imdb_names").all() as unknown as Array<{
      people: number;
    }>;
    state.peopleImported = peopleRows[0]?.people ?? 0;
    logger.info({ people: state.peopleImported }, "IMDb import: names loaded");

    // Aggregate top directors/cast and backfill the titles table.
    state.phase = "聚合导演与演员";
    client.exec(`
      CREATE TEMP TABLE tmp_imdb_directors_agg AS
      SELECT tconst, GROUP_CONCAT(primary_name, '、') AS names
      FROM (
        SELECT c.tconst, n.primary_name,
               ROW_NUMBER() OVER (PARTITION BY c.tconst ORDER BY n.primary_name COLLATE NOCASE) AS rn
        FROM tmp_imdb_crew c JOIN tmp_imdb_names n ON n.nconst = c.nconst
      )
      WHERE rn <= ${MAX_DIRECTORS}
      GROUP BY tconst
    `);
    client.exec(
      "CREATE INDEX tmp_imdb_directors_agg_tconst_idx ON tmp_imdb_directors_agg (tconst)"
    );
    client.exec(`
      CREATE TEMP TABLE tmp_imdb_cast_agg AS
      SELECT tconst, GROUP_CONCAT(primary_name, '、') AS names
      FROM (
        SELECT p.tconst, n.primary_name,
               ROW_NUMBER() OVER (PARTITION BY p.tconst ORDER BY p.ordering) AS rn
        FROM tmp_imdb_principals p JOIN tmp_imdb_names n ON n.nconst = p.nconst
      )
      WHERE rn <= ${MAX_CAST}
      GROUP BY tconst
    `);
    client.exec("CREATE INDEX tmp_imdb_cast_agg_tconst_idx ON tmp_imdb_cast_agg (tconst)");

    state.phase = "回填导演与演员";
    client.exec(`
      UPDATE imdb_titles SET
        directors = (SELECT names FROM tmp_imdb_directors_agg a WHERE a.tconst = imdb_titles.tconst),
        cast = (SELECT names FROM tmp_imdb_cast_agg a WHERE a.tconst = imdb_titles.tconst)
    `);
    logger.info("IMDb import: directors/cast backfilled");
  } finally {
    for (const table of stagingTables) {
      try {
        client.exec(`DROP TABLE IF EXISTS ${table}`);
      } catch {
        // Best-effort cleanup; leftover staging tables are dropped on the next run.
      }
    }
  }
}

/** Wrap a prepared insert so it commits every BATCH_SIZE rows. */
function makeBatchedInsert(stmt: ReturnType<DatabaseSync["prepare"]>): (values: (string | number)[]) => void {
  const client = sqliteClient!;
  let rows = 0;
  return (values) => {
    stmt.run(...values);
    rows++;
    if (rows >= BATCH_SIZE) {
      client.exec("COMMIT");
      client.exec("BEGIN");
      rows = 0;
    }
  };
}
