import { describe, expect, it } from "vitest";
import { mkdtemp, mkdir, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import {
  assembleSrt,
  cleanupCjkSpacing,
  computeOcrQuality,
  buildGraphicSubtitleExportArgs,
  decodePngRgba,
  detectScriptLanguage,
  encodePng,
  ensureTesseractLanguageData,
  extractHandBrakeJson,
  findTessdataDirectoryForTesseract,
  isDirectFrameGraphicCodec,
  formatSrtTime,
  mapTesseractLanguage,
  parseTesseractTsv,
  parsePgsSup,
  resolveSubtitleToolPath,
  type OcrEvent,
} from "./subtitle-ocr";

describe("graphic subtitle codec routing", () => {
  it("routes DVB subtitles through the generic frame decoder", () => {
    expect(isDirectFrameGraphicCodec("dvb_subtitle")).toBe(true);
    expect(isDirectFrameGraphicCodec("dvd_subtitle")).toBe(true);
  });

  it("keeps PGS subtitles on the PGS parser path", () => {
    expect(isDirectFrameGraphicCodec("hdmv_pgs_subtitle")).toBe(false);
    expect(isDirectFrameGraphicCodec("pgssub")).toBe(false);
  });

  it("exports PGS as SUP and DVD VobSub as a Matroska sidecar", () => {
    expect(buildGraphicSubtitleExportArgs({
      sourceInputArgs: ["-f", "dvdvideo", "-title", "4", "-i", "D:/DVD/VIDEO_TS"],
      subtitleTypeIndex: 1,
      codec: "dvd_subtitle",
      outputBasePath: "D:/Output/Movie.graphic-1",
    })).toEqual([
      "-y", "-hide_banner", "-f", "dvdvideo", "-title", "4", "-i", "D:/DVD/VIDEO_TS",
      "-map", "0:s:1", "-c:s", "copy", "-f", "matroska", "D:/Output/Movie.graphic-1.mkv",
    ]);
    expect(buildGraphicSubtitleExportArgs({
      sourceInputArgs: ["-i", "D:/Movie.m2ts"],
      subtitleTypeIndex: 0,
      codec: "hdmv_pgs_subtitle",
      outputBasePath: "D:/Output/Movie.graphic-0",
    })).toEqual([
      "-y", "-hide_banner", "-i", "D:/Movie.m2ts",
      "-map", "0:s:0", "-c:s", "copy", "-f", "sup", "D:/Output/Movie.graphic-0.sup",
    ]);
  });
});

describe("resolveSubtitleToolPath", () => {
  it("uses the managed executable path when PATH does not contain the media tool", async () => {
    const managedPath = "C:/MediaSculpt/Tools/ffmpeg/bin/ffprobe.exe";
    await expect(resolveSubtitleToolPath("ffprobe", async () => managedPath)).resolves.toBe(managedPath);
  });
});

describe("detectScriptLanguage", () => {
  it("detects Chinese, Japanese, Korean, Cyrillic and Latin samples", () => {
    expect(detectScriptLanguage("你好世界，这是中文字幕")).toBe("zh");
    expect(detectScriptLanguage("こんにちは、日本語の字幕")).toBe("ja");
    expect(detectScriptLanguage("안녕하세요 자막")).toBe("ko");
    expect(detectScriptLanguage("Привет, русские субтитры")).toBe("ru");
    expect(detectScriptLanguage("Hello, this is a subtitle")).toBe("en");
  });
});

describe("mapTesseractLanguage", () => {
  it("maps explicit languages and stream language tags", () => {
    expect(mapTesseractLanguage("zh")).toBe("chi_sim");
    expect(mapTesseractLanguage("ja")).toBe("jpn");
    expect(mapTesseractLanguage("ko")).toBe("kor");
    expect(mapTesseractLanguage("ru")).toBe("rus");
    expect(mapTesseractLanguage("en")).toBe("eng");
    expect(mapTesseractLanguage("auto", "chi")).toBe("chi_sim");
    expect(mapTesseractLanguage("auto", "jpn")).toBe("jpn");
    expect(mapTesseractLanguage("auto", "kor")).toBe("kor");
    expect(mapTesseractLanguage("auto", "rus")).toBe("rus");
    expect(mapTesseractLanguage("auto", "eng")).toBe("eng");
    expect(mapTesseractLanguage("auto", null)).toBe("eng");
  });
});

describe("assembleSrt / formatSrtTime", () => {
  it("formats times and assembles SRT blocks", () => {
    expect(formatSrtTime(61_000)).toBe("00:01:01,000");
    expect(formatSrtTime(3_661_234)).toBe("01:01:01,234");
    const events: OcrEvent[] = [
      { index: 0, startMs: 1000, endMs: 3000, text: "Hello" },
      { index: 1, startMs: 3500, endMs: 5000, text: "World" },
    ];
    const srt = assembleSrt(events);
    expect(srt).toContain("00:00:01,000 --> 00:00:03,000");
    expect(srt).toContain("00:00:03,500 --> 00:00:05,000");
    expect(srt).toContain("Hello");
    expect(srt).toContain("World");
  });

  it("skips empty events", () => {
    const events: OcrEvent[] = [
      { index: 0, startMs: 1000, endMs: 2000, text: "  " },
      { index: 1, startMs: 2000, endMs: 3000, text: "Kept" },
    ];
    expect(assembleSrt(events)).not.toContain("00:00:01,000 --> 00:00:02,000");
    expect(assembleSrt(events)).toMatch(/^1\n/);
    expect(assembleSrt(events)).toContain("Kept");
  });
});

describe("tesseract language data guard", () => {
  it("locates tessdata next to the executable and validates traineddata", async () => {
    const dir = await mkdtemp(path.join(os.tmpdir(), "vx-tessdata-"));
    try {
      const tessdata = path.join(dir, "tessdata");
      await mkdir(tessdata);
      await writeFile(path.join(tessdata, "eng.traineddata"), "placeholder");
      const executable = path.join(dir, "tesseract.exe");
      expect(await findTessdataDirectoryForTesseract(executable)).toBe(tessdata);
      await expect(ensureTesseractLanguageData(executable, "eng")).resolves.toBeUndefined();
      // 完全独立的目录（上下级都不存在 tessdata）时立即报错，
      // 不依赖网络自动下载，保证测试在联网/断网环境都确定通过。
      const missingDir = await mkdtemp(path.join(os.tmpdir(), "vx-tessdata-missing-"));
      try {
        await expect(ensureTesseractLanguageData(path.join(missingDir, "tesseract.exe"), "chi_sim"))
          .rejects.toThrow(/无法定位 Tesseract 语言数据目录/);
      } finally {
        await rm(missingDir, { recursive: true, force: true });
      }
    } finally {
      await rm(dir, { recursive: true, force: true });
    }
  });
});

describe("extractHandBrakeJson", () => {
  it("parses the JSON document despite the CLI banner prefix", () => {
    const output = [
      "HandBrake 1.11.2 (2025041500) - Linux x86_64 - https://handbrake.fr",
      "libdvdnav: DVD disk reports itself with Region mask 0x00000000.",
      "JSON Title Set: {\"TitleList\":[{\"Index\":1,\"SubtitleList\":[{\"TrackNumber\":1,\"LanguageCode\":\"eng\"}]}]}",
    ].join("\n");
    const parsed = extractHandBrakeJson(output) as { TitleList?: Array<{ Index?: number }> } | null;
    expect(parsed?.TitleList?.[0]?.Index).toBe(1);
    expect(extractHandBrakeJson("no json here")).toBeNull();
  });
});

describe("subtitle frame preprocessing", () => {
  it("round-trips an RGBA frame through the PNG encoder/decoder", () => {
    const width = 8;
    const height = 4;
    const rgba = Buffer.alloc(width * height * 4);
    for (let i = 0; i < width * height; i += 1) {
      const o = i * 4;
      rgba[o] = 255;
      rgba[o + 1] = 255;
      rgba[o + 2] = 255;
      rgba[o + 3] = i % 3 === 0 ? 0 : 255;
    }
    const decoded = decodePngRgba(encodePng(rgba, width, height));
    expect(decoded.width).toBe(width);
    expect(decoded.height).toBe(height);
    expect(decoded.rgba).toEqual(rgba);
  });

  it("removes spaces inserted between CJK characters", () => {
    expect(cleanupCjkSpacing("旁 述 : 我 們 聽到")).toBe("旁述 : 我們聽到");
    expect(cleanupCjkSpacing("hello world 中文 字幕 test")).toBe("hello world 中文字幕 test");
  });
});

describe("OCR quality scoring", () => {
  it("uses engine confidence when available", () => {
    const quality = computeOcrQuality(
      [
        { text: "hello", confidence: 0.95 },
        { text: "world", confidence: 0.9 },
        { text: "", confidence: 0.8 },
      ],
      3,
    );
    expect(quality.confidenceBased).toBe(true);
    expect(quality.score).toBeGreaterThanOrEqual(60);
    expect(quality.score).toBeLessThanOrEqual(100);
  });

  it("falls back to text heuristics without confidence", () => {
    const quality = computeOcrQuality(
      [
        { text: "完整的一句话" },
        { text: "另一句完整的话" },
        { text: "" },
      ],
      3,
    );
    expect(quality.confidenceBased).toBe(false);
    expect(quality.score).toBeGreaterThan(40);
  });

  it("parses tesseract TSV into text and average confidence", () => {
    const tsv = [
      "level\tpage_num\tblock_num\tpar_num\tline_num\tword_num\tleft\ttop\twidth\theight\tconf\ttext",
      "5\t1\t1\t1\t1\t1\t10\t20\t60\t20\t95.2\tHello",
      "5\t1\t1\t1\t1\t2\t70\t20\t50\t20\t90.1\tworld",
      "5\t1\t1\t1\t2\t1\t10\t50\t60\t20\t80\tSecond",
    ].join("\n");
    const parsed = parseTesseractTsv(tsv);
    expect(parsed.text).toBe("Hello world\nSecond");
    expect(parsed.confidence).toBeCloseTo(88.433, 1);
  });
});

describe("encodePng", () => {
  it("produces a valid PNG header", () => {
    const rgba = Buffer.alloc(4 * 4 * 4, 0);
    const png = encodePng(rgba, 4, 4);
    expect(png.subarray(0, 8).toString("hex")).toBe("89504e470d0a1a0a");
    expect(png.includes(Buffer.from("IHDR"))).toBe(true);
    expect(png.includes(Buffer.from("IEND"))).toBe(true);
  });
});

// ── Synthetic PGS (.sup) builder ──────────────────────────────────────────────
function encodePts(pts: number): Buffer {
  const b = Buffer.alloc(5);
  b[0] = 0x21 | ((pts >> 29) & 0x0e);
  b[1] = (pts >> 22) & 0xff;
  b[2] = 0x01 | ((pts >> 14) & 0xfe);
  b[3] = (pts >> 7) & 0xff;
  b[4] = 0x01 | ((pts << 1) & 0xfe);
  return b;
}

function segment(type: number, payload: Buffer): Buffer {
  const len = Buffer.alloc(2);
  len.writeUInt16BE(payload.length, 0);
  return Buffer.concat([Buffer.from([type]), len, payload]);
}

function pds(paletteId: number): Buffer {
  const entries = Buffer.alloc(16 * 5);
  // index 0: transparent; index 1: white; index 2: black
  for (let e = 0; e < 16; e += 1) {
    const o = e * 5;
    entries[o] = e; // entry index
    if (e === 0) {
      entries[o + 1] = 0; // Y
      entries[o + 2] = 128; // Cr
      entries[o + 3] = 128; // Cb
      entries[o + 4] = 0; // alpha
    } else if (e === 1) {
      entries[o + 1] = 235;
      entries[o + 2] = 128;
      entries[o + 3] = 128;
      entries[o + 4] = 255;
    } else if (e === 2) {
      entries[o + 1] = 16;
      entries[o + 2] = 128;
      entries[o + 3] = 128;
      entries[o + 4] = 255;
    } else {
      entries[o + 1] = 0;
      entries[o + 2] = 128;
      entries[o + 3] = 128;
      entries[o + 4] = 0;
    }
  }
  return segment(0x14, Buffer.concat([Buffer.from([paletteId]), entries]));
}

function ods(objectId: number, width: number, height: number, rows: number[][]): Buffer {
  const rleParts: Buffer[] = [];
  for (const row of rows) {
    rleParts.push(Buffer.from([0x02, row[0], row[1], 0x00]));
  }
  const rle = Buffer.concat(rleParts);
  const dataLen = Buffer.alloc(3);
  dataLen.writeUIntBE(rle.length, 0, 3);
  const head = Buffer.alloc(11);
  head.writeUInt16BE(objectId, 0);
  head[2] = 0; // version
  head[3] = 0; // flags
  head.writeUInt16BE(width, 4);
  head.writeUInt16BE(height, 6);
  dataLen.copy(head, 8);
  return segment(0x15, Buffer.concat([head, rle]));
}

function pcs(width: number, height: number, compNum: number, paletteId: number, objectId: number, x: number, y: number): Buffer {
  const payload = Buffer.alloc(20);
  payload.writeUInt16BE(width, 0);
  payload.writeUInt16BE(height, 2);
  payload[4] = 0x10; // frame rate
  payload.writeUInt16BE(compNum, 5);
  payload[7] = 0x00; // epoch start
  payload[8] = 0x00; // palette update
  payload[9] = paletteId;
  payload[10] = 1; // object count
  payload.writeUInt16BE(objectId, 11);
  payload[13] = 0; // window id
  payload.writeUInt16BE(x, 14);
  payload.writeUInt16BE(y, 16);
  payload[18] = 0; // crop flag
  return segment(0x16, payload);
}

function pes(payload: Buffer, pts: number): Buffer {
  const flags = Buffer.from([0x80, 0x80]);
  const body = Buffer.concat([flags, encodePts(pts), payload]);
  const len = Buffer.alloc(2);
  len.writeUInt16BE(body.length, 0);
  return Buffer.concat([Buffer.from([0x00, 0x00, 0x01, 0xbd]), len, body]);
}

function buildSup(): Buffer {
  const paletteId = 0;
  const objectId = 1;
  const event1 = pes(Buffer.concat([
    pds(paletteId),
    ods(objectId, 2, 2, [[1, 1], [2, 2]]),
    pcs(640, 480, 1, paletteId, objectId, 10, 20),
    segment(0x80, Buffer.alloc(0)),
  ]), 90_000); // 1000 ms
  const event2 = pes(Buffer.concat([
    pds(paletteId),
    ods(objectId, 2, 2, [[1, 1], [2, 2]]),
    pcs(640, 480, 2, paletteId, objectId, 10, 20),
    segment(0x80, Buffer.alloc(0)),
  ]), 450_000); // 5000 ms
  return Buffer.concat([event1, event2]);
}

describe("parsePgsSup", () => {
  it("parses events, timestamps and decoded bitmaps from a synthetic .sup", () => {
    const events = parsePgsSup(buildSup());
    expect(events.length).toBe(2);
    expect(events[0].startMs).toBe(1000);
    expect(events[1].startMs).toBe(5000);
    expect(events[0].width).toBeGreaterThanOrEqual(12);
    expect(events[0].height).toBeGreaterThanOrEqual(22);
    // Object drawn at (10,20); first pixel of the object row should be white.
    const rgba = events[0].rgba;
    const off = (20 * events[0].width + 10) * 4;
    expect(rgba[off + 0]).toBe(235);
    expect(rgba[off + 1]).toBe(235);
    expect(rgba[off + 2]).toBe(235);
    expect(rgba[off + 3]).toBe(255);
    // Second row uses palette index 2 (black).
    const off2 = (21 * events[0].width + 10) * 4;
    expect(rgba[off2 + 0]).toBeLessThan(40);
  });
});
