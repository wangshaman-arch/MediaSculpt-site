import { afterEach, describe, expect, it } from "vitest";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { parseBlurayChapters, parseBlurayMpls, scanBlurayPlaylists } from "./disc";

const cleanups: string[] = [];
afterEach(async () => {
  await Promise.all(cleanups.splice(0).map((entry) => fs.rm(entry, { recursive: true, force: true }).catch(() => {})));
});

function buildPlayItem(clip: string, inTime45k: number, outTime45k: number, streamCount = 0): Buffer {
  const body: Buffer[] = [
    Buffer.from(clip, "ascii"),
    Buffer.from("M2TS", "ascii"),
    // flags(2) + ref_to_STC_id(1) so IN_time starts at item offset +14.
    Buffer.from([0, 0, 1]),
    (() => { const t = Buffer.alloc(4); t.writeUInt32BE(inTime45k); return t; })(),
    (() => { const t = Buffer.alloc(4); t.writeUInt32BE(outTime45k); return t; })(),
    Buffer.alloc(8),
    Buffer.from([0, 0, 0]),
  ];
  const stn = Buffer.alloc(2);
  stn.writeUInt16BE(8 + streamCount * 8, 0);
  body.push(stn);
  const data = Buffer.concat(body);
  const out = Buffer.alloc(2 + data.length);
  out.writeUInt16BE(data.length, 0);
  data.copy(out, 2);
  return out;
}

function buildMpls(items: Buffer[], subPaths: Buffer[] = [], marks: Array<{ type: number; ref: number; time90k: number }> = []): Buffer {
  const header = Buffer.alloc(40);
  header.write("MPLS", 0, "ascii");
  header.write("0200", 4, "ascii");
  header.writeUInt32BE(40, 8);
  const playList: Buffer[] = [];
  const lengthField = Buffer.alloc(4);
  playList.push(lengthField);
  // Official layout: reserved(16) + number_of_PlayItems(16) + number_of_SubPaths(16).
  const countsHeader = Buffer.alloc(6);
  countsHeader.writeUInt16BE(items.length, 2);
  countsHeader.writeUInt16BE(subPaths.length, 4);
  playList.push(countsHeader);
  playList.push(...items);
  playList.push(...subPaths);
  const playListData = Buffer.concat(playList);
  playListData.writeUInt32BE(playListData.length - 4, 0);
  const markStart = 40 + playListData.length;
  header.writeUInt32BE(markStart, 12);
  header.writeUInt32BE(0, 16);

  const markBody: Buffer[] = [];
  const markLength = Buffer.alloc(4);
  markBody.push(markLength);
  const count = Buffer.alloc(2);
  count.writeUInt16BE(marks.length, 0);
  markBody.push(count);
  for (const mark of marks) {
    // PlayListMark() entry layout: reserved(1) + mark_type(1) + play_item_ref(2)
    // + time(4) + entry_ES_PID(2) + duration(4) = 14 bytes.
    markBody.push(Buffer.from([0, mark.type]));
    const ref = Buffer.alloc(2);
    ref.writeUInt16BE(mark.ref, 0);
    markBody.push(ref);
    const time = Buffer.alloc(4);
    time.writeUInt32BE(mark.time90k, 0);
    markBody.push(time);
    markBody.push(Buffer.alloc(2));
    markBody.push(Buffer.alloc(4));
  }
  const markData = Buffer.concat(markBody);
  markData.writeUInt32BE(markData.length - 4, 0);
  return Buffer.concat([header, playListData, markData]);
}

describe("Blu-ray MPLS parser", () => {
  it("returns playlist clips in playback order using the official layout", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-mpls-"));
    cleanups.push(dir);
    const mpls = path.join(dir, "00000.mpls");
    await fs.writeFile(mpls, buildMpls([
      buildPlayItem("00002", 90000, 180000),
      buildPlayItem("00001", 180000, 270000),
    ]));
    const result = await parseBlurayMpls(mpls, dir);
    expect(result.map((segment) => segment.clipId)).toEqual(["00002", "00001"]);
    expect(result[0]?.inTime45k).toBe(90000);
    expect(result[0]?.streamPath).toContain(path.join("BDMV", "STREAM", "00002.m2ts"));
  });

  it("skips SubPath entries so they cannot misalign the segment walk", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-mpls-"));
    cleanups.push(dir);
    const mpls = path.join(dir, "00000.mpls");
    const subPath = Buffer.alloc(8);
    subPath.writeUInt32BE(4, 0);
    await fs.writeFile(mpls, buildMpls([
      buildPlayItem("00010", 0, 90000),
      buildPlayItem("00011", 90000, 180000),
    ], [subPath]));
    const result = await parseBlurayMpls(mpls, dir);
    expect(result.map((segment) => segment.clipId)).toEqual(["00010", "00011"]);
  });

  it("reads 16-bit play item counts like real authored discs", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-mpls-"));
    cleanups.push(dir);
    const mpls = path.join(dir, "00000.mpls");
    await fs.writeFile(mpls, buildMpls([
      buildPlayItem("00000", 0, 90000),
      buildPlayItem("00008", 90000, 180000),
      buildPlayItem("00007", 180000, 270000),
    ]));
    const result = await parseBlurayMpls(mpls, dir);
    expect(result.map((segment) => segment.clipId)).toEqual(["00000", "00008", "00007"]);
    expect(result.map((segment) => segment.inTime45k)).toEqual([0, 90000, 180000]);
  });

  it("derives chapters from PlayListMark entry points", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-mpls-"));
    cleanups.push(dir);
    const mpls = path.join(dir, "00000.mpls");
    await fs.writeFile(mpls, buildMpls([
      buildPlayItem("00001", 0, 45000),
      buildPlayItem("00002", 45000, 90000),
    ], [], [
      { type: 1, ref: 0, time90k: 0 },
      // 1.5 s into the second item: prefix(1 s) + (67500 - 45000) / 45000.
      { type: 1, ref: 1, time90k: 67500 },
    ]));
    const chapters = await parseBlurayChapters(mpls, dir);
    expect(chapters.map((chapter) => chapter.startSeconds)).toEqual([0, 1.5]);
    expect(chapters[0]?.endSeconds).toBe(1.5);
  });

  it("scans all playlists and derives duration, size and chapters", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-bd-"));
    cleanups.push(dir);
    await fs.mkdir(path.join(dir, "BDMV", "PLAYLIST"), { recursive: true });
    await fs.mkdir(path.join(dir, "BDMV", "STREAM"), { recursive: true });
    await fs.writeFile(path.join(dir, "BDMV", "STREAM", "00001.m2ts"), Buffer.alloc(1000));
    await fs.writeFile(path.join(dir, "BDMV", "STREAM", "00002.m2ts"), Buffer.alloc(2000));
    await fs.writeFile(path.join(dir, "BDMV", "PLAYLIST", "00000.mpls"), buildMpls([
      buildPlayItem("00001", 0, 90000),
      buildPlayItem("00002", 90000, 180000),
    ], [], [
      { type: 1, ref: 0, time90k: 0 },
      { type: 1, ref: 1, time90k: 45000 },
    ]));
    const playlists = await scanBlurayPlaylists(dir);
    expect(playlists).toHaveLength(1);
    expect(playlists[0]).toMatchObject({
      playlistId: "00000",
      // 0..180000 ticks at 45 kHz = 4 seconds.
      durationSeconds: 4,
      sizeBytes: 3000,
      chapterCount: 2,
    });
  });

  it("counts a repeated m2ts only once so the reported size cannot exceed the disc", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-bd-"));
    cleanups.push(dir);
    await fs.mkdir(path.join(dir, "BDMV", "PLAYLIST"), { recursive: true });
    await fs.mkdir(path.join(dir, "BDMV", "STREAM"), { recursive: true });
    await fs.writeFile(path.join(dir, "BDMV", "STREAM", "00001.m2ts"), Buffer.alloc(5000));
    await fs.writeFile(path.join(dir, "BDMV", "PLAYLIST", "00000.mpls"), buildMpls([
      buildPlayItem("00001", 0, 90000),
      buildPlayItem("00001", 90000, 180000),
    ]));
    const playlists = await scanBlurayPlaylists(dir);
    expect(playlists[0]?.sizeBytes).toBe(5000);
  });

  it("skips menu/loop playlists that repeat the same clip range many times", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-bd-"));
    cleanups.push(dir);
    await fs.mkdir(path.join(dir, "BDMV", "PLAYLIST"), { recursive: true });
    await fs.mkdir(path.join(dir, "BDMV", "STREAM"), { recursive: true });
    await fs.writeFile(path.join(dir, "BDMV", "STREAM", "00001.m2ts"), Buffer.alloc(1000));
    await fs.writeFile(path.join(dir, "BDMV", "PLAYLIST", "00000.mpls"), buildMpls(
      Array.from({ length: 12 }, () => buildPlayItem("00001", 0, 90000)),
    ));
    const playlists = await scanBlurayPlaylists(dir);
    expect(playlists).toHaveLength(0);
  });
});
