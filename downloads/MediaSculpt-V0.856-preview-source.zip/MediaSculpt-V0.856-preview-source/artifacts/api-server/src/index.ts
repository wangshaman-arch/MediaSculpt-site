import app, { heartbeat } from "./app";
import { logger } from "./lib/logger";
import { db, configTable, jobsTable } from "@workspace/db";
import { sql } from "drizzle-orm";
import { jobProcessController } from "./infrastructure/job-process-controller";
import { terminateProcessTree } from "./infrastructure/process-termination";
import { activateManagedToolDirectory, ensureRuntimeDirectories, seedBundledTools } from "./lib/tool-runtime";

activateManagedToolDirectory();

process.on("unhandledRejection", (reason) => {
  logger.error({ reason }, "Unhandled rejection");
});

process.on("uncaughtException", (error) => {
  logger.error({ error }, "Uncaught exception");
});

async function runMigrations() {
  if ((process.env.DATABASE_DRIVER ?? (process.env.DATABASE_URL ? "postgres" : "sqlite")).toLowerCase() === "sqlite") {
    logger.info("SQLite selected; automatic local schema initialization already completed.");
    return;
  }
  logger.info("Running DB migrations...");
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS jobs (
      id                       SERIAL PRIMARY KEY,
      file_path                TEXT NOT NULL,
      output_path              TEXT,
      status                   TEXT NOT NULL DEFAULT 'pending',
      subtitle_mode            TEXT NOT NULL DEFAULT 'auto',
      subtitle_path            TEXT,
      has_embedded_subtitles   BOOLEAN,
      file_size_before         INTEGER,
      file_size_after          INTEGER,
      duration_seconds         REAL,
      progress                 REAL,
      error_message            TEXT,
      movie_title              TEXT,
      movie_title_en           TEXT,
      movie_year               INTEGER,
      movie_rating             REAL,
      movie_director           TEXT,
      movie_genres             TEXT,
      movie_overview           TEXT,
      movie_metadata           TEXT,
      movie_poster             TEXT,
      standardized_name        TEXT,
      tmdb_id                  INTEGER,
      readme_path              TEXT,
      subtitle_source          TEXT,
      translated_subtitle_path TEXT,
      subtitle_pipeline_status TEXT,
      media_type               TEXT NOT NULL DEFAULT 'video',
      main_track_path          TEXT,
      selected_streams         TEXT,
      selected_chapters        TEXT,
      source_manifest          TEXT,
      selection_plan           TEXT,
      task_snapshot            TEXT,
      task_snapshot_version    INTEGER,
      legacy_task              BOOLEAN NOT NULL DEFAULT FALSE,
      processing_mode          TEXT NOT NULL DEFAULT 'compress',
      created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      started_at               TIMESTAMPTZ,
      completed_at             TIMESTAMPTZ
    )
  `);

  // Upgrade file size columns from INTEGER to BIGINT (supports files > 2 GB)
  await db.execute(sql.raw(`ALTER TABLE jobs ALTER COLUMN file_size_before TYPE BIGINT`));
  await db.execute(sql.raw(`ALTER TABLE jobs ALTER COLUMN file_size_after  TYPE BIGINT`));

  // Add columns that may be missing in older installs
  const jobCols: [string, string][] = [
    ["subtitle_source",           "TEXT"],
    ["translated_subtitle_path",  "TEXT"],
    ["subtitle_pipeline_status",  "TEXT"],
    ["media_type",                "TEXT NOT NULL DEFAULT 'video'"],
    ["main_track_path",           "TEXT"],
    ["selected_streams",          "TEXT"],
    ["selected_chapters",         "TEXT"],
    ["source_manifest",           "TEXT"],
    ["selection_plan",            "TEXT"],
    ["task_snapshot",             "TEXT"],
    ["task_snapshot_version",     "INTEGER"],
    // Existing records lack a reliable immutable selection and must stay legacy.
    ["legacy_task",               "BOOLEAN NOT NULL DEFAULT TRUE"],
    ["processing_mode",           "TEXT NOT NULL DEFAULT 'compress'"],
    ["pipeline_steps",            "TEXT"],
    ["movie_title_en",            "TEXT"],
    ["movie_metadata",             "TEXT"],
    ["tmdb_id",                   "INTEGER"],
    ["readme_path",               "TEXT"],
    ["current_fps",               "REAL"],
    ["avg_fps",                   "REAL"],
    ["eta_seconds",               "INTEGER"],
  ];
  for (const [col, def] of jobCols) {
    await db.execute(
      sql.raw(`ALTER TABLE jobs ADD COLUMN IF NOT EXISTS ${col} ${def}`)
    );
  }
  await db.execute(sql.raw("ALTER TABLE jobs ALTER COLUMN legacy_task SET DEFAULT FALSE"));
  await db.execute(sql.raw("UPDATE jobs SET legacy_task = TRUE WHERE task_snapshot IS NULL AND legacy_task IS NULL"));

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS job_logs (
      id         SERIAL PRIMARY KEY,
      job_id     INTEGER NOT NULL,
      level      TEXT NOT NULL DEFAULT 'info',
      message    TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS config (
      id                      SERIAL PRIMARY KEY,
      watch_directory         TEXT NOT NULL DEFAULT '/media/downloads',
      output_directory        TEXT NOT NULL DEFAULT '/media/output',
      remux_output_directory  TEXT NOT NULL DEFAULT '__source__',
      handbrake_preset        TEXT NOT NULL DEFAULT 'HQ 1080p30 Surround',
      whisper_model           TEXT NOT NULL DEFAULT 'medium',
      subtitle_language       TEXT NOT NULL DEFAULT 'zh',
      crf                     INTEGER NOT NULL DEFAULT 20,
      encoder                 TEXT NOT NULL DEFAULT 'x264_10bit',
      audio_copy              BOOLEAN NOT NULL DEFAULT TRUE,
      output_format           TEXT NOT NULL DEFAULT 'mkv',
      handbrake_cli_path      TEXT,
      subtitle_edit_cli_path  TEXT,
      tmdb_api_key            TEXT,
      openai_api_key          TEXT,
      deepseek_api_key        TEXT,
      siliconflow_api_key     TEXT,
      zhipu_api_key           TEXT,
      moonshot_api_key        TEXT,
      qwen_api_key            TEXT,
      groq_api_key            TEXT,
      gemini_api_key          TEXT,
      ai_translation_enabled  BOOLEAN NOT NULL DEFAULT FALSE,
      translation_target_lang TEXT NOT NULL DEFAULT 'zh-CN',
      ai_provider             TEXT NOT NULL DEFAULT 'deepseek',
      ai_base_url             TEXT,
      ai_model                TEXT,
      frame_rate              TEXT NOT NULL DEFAULT 'same',
      output_resolution       TEXT NOT NULL DEFAULT 'source',
      encoder_preset          TEXT NOT NULL DEFAULT 'slow',
      encoder_tune            TEXT NOT NULL DEFAULT 'film',
      encoder_profile         TEXT NOT NULL DEFAULT 'high10',
      encoder_level           TEXT NOT NULL DEFAULT '4.1',
      ui_language             TEXT NOT NULL DEFAULT 'zh-CN',
      theme_mode              TEXT NOT NULL DEFAULT 'deep-ocean'
    )
  `);

  // Add columns that may be missing in older installs
  const cfgCols: [string, string][] = [
    ["remux_output_directory", "TEXT NOT NULL DEFAULT '__source__'"],
    ["openai_api_key",          "TEXT"],
    ["deepseek_api_key",        "TEXT"],
    ["siliconflow_api_key",     "TEXT"],
    ["zhipu_api_key",           "TEXT"],
    ["moonshot_api_key",        "TEXT"],
    ["qwen_api_key",            "TEXT"],
    ["groq_api_key",            "TEXT"],
    ["gemini_api_key",          "TEXT"],
    ["ai_translation_enabled",  "BOOLEAN NOT NULL DEFAULT FALSE"],
    ["translation_target_lang", "TEXT NOT NULL DEFAULT 'zh-CN'"],
    ["ai_provider",             "TEXT NOT NULL DEFAULT 'deepseek'"],
    ["ai_base_url",             "TEXT"],
    ["ai_model",                "TEXT"],
    ["frame_rate",              "TEXT NOT NULL DEFAULT 'same'"],
    ["output_resolution",       "TEXT NOT NULL DEFAULT 'source'"],
    ["encoder_preset",          "TEXT NOT NULL DEFAULT 'slow'"],
    ["encoder_tune",            "TEXT NOT NULL DEFAULT 'film'"],
    ["encoder_profile",         "TEXT NOT NULL DEFAULT 'high10'"],
    ["encoder_level",           "TEXT NOT NULL DEFAULT '4.1'"],
    ["ui_language",             "TEXT NOT NULL DEFAULT 'zh-CN'"],
    ["theme_mode",              "TEXT NOT NULL DEFAULT 'deep-ocean'"],
    ["libre_translate_url",          "TEXT"],
    ["host_downloads_path",          "TEXT"],
    ["host_output_path",             "TEXT"],
    ["subtitle_directory",           "TEXT"],
    ["process_high_priority",        "BOOLEAN NOT NULL DEFAULT FALSE"],
    ["shutdown_after_complete",      "BOOLEAN NOT NULL DEFAULT FALSE"],
    ["omdb_api_key",                 "TEXT"],
    ["deinterlace",                  "BOOLEAN NOT NULL DEFAULT FALSE"],
    ["imdb_last_import_at",          "TIMESTAMPTZ"],
    ["imdb_title_count",             "INTEGER"],
    ["custom_tuning",                "TEXT"],
  ];
  for (const [col, def] of cfgCols) {
    await db.execute(
      sql.raw(`ALTER TABLE config ADD COLUMN IF NOT EXISTS ${col} ${def}`)
    );
  }

  // Local mirror of the free IMDb TSV datasets (populated by POST /imdb/import)
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS imdb_titles (
      tconst          TEXT PRIMARY KEY,
      title_type      TEXT NOT NULL,
      primary_title   TEXT NOT NULL,
      original_title  TEXT NOT NULL,
      start_year      INTEGER,
      runtime_minutes INTEGER,
      genres          TEXT,
      rating          REAL,
      votes           INTEGER,
      directors       TEXT,
      cast            TEXT
    )
  `);
  await db.execute(sql.raw(
    `CREATE INDEX IF NOT EXISTS imdb_titles_primary_title_idx ON imdb_titles (primary_title)`
  ));
  await db.execute(sql.raw(
    `CREATE INDEX IF NOT EXISTS imdb_titles_original_title_idx ON imdb_titles (original_title)`
  ));
  await db.execute(sql.raw(
    `ALTER TABLE imdb_titles ADD COLUMN IF NOT EXISTS directors TEXT`
  ));
  await db.execute(sql.raw(
    `ALTER TABLE imdb_titles ADD COLUMN IF NOT EXISTS cast TEXT`
  ));

  // Fix legacy bad defaults: /output → /media/output, /downloads → /media/downloads
  try {
    await db.execute(sql`
      UPDATE config SET output_directory = '/media/output'
      WHERE output_directory IN ('/output', '/app/output', '/data/output')
    `);
    await db.execute(sql`
      UPDATE config SET watch_directory = '/media/downloads'
      WHERE watch_directory IN ('/downloads', '/app/downloads', '/data/downloads', '/media/downloads/downloads')
    `);
  } catch (e) {
    logger.warn({ err: e }, "Could not fix legacy directory defaults");
  }

  logger.info("DB migrations complete.");

  // Pre-fill host path config from env vars on first run (when fields are still NULL)
  try {
    const hostOutputFromEnv    = process.env["HOST_OUTPUT_PATH"];
    const hostDownloadsFromEnv = process.env["HOST_DOWNLOADS_PATH"];
    if (hostOutputFromEnv || hostDownloadsFromEnv) {
      const rows = await db.select().from(configTable).limit(1);
      if (rows.length > 0) {
        const row = rows[0];
        if (hostOutputFromEnv && !row.hostOutputPath) {
          await db.execute(sql`UPDATE config SET host_output_path = ${hostOutputFromEnv} WHERE id = ${row.id}`);
          logger.info({ value: hostOutputFromEnv }, "Pre-filled host_output_path from env");
        }
        if (hostDownloadsFromEnv && !row.hostDownloadsPath) {
          await db.execute(sql`UPDATE config SET host_downloads_path = ${hostDownloadsFromEnv} WHERE id = ${row.id}`);
          logger.info({ value: hostDownloadsFromEnv }, "Pre-filled host_downloads_path from env");
        }
      }
    }
  } catch (e) {
    logger.warn({ err: e }, "Could not pre-fill host path config from env vars");
  }

  // Apply high-priority scheduling if configured
  try {
    const cfg = await db.select().from(configTable).limit(1);
    if (cfg[0]?.processHighPriority) {
      try {
        (process as NodeJS.Process & { setpriority?: (pid: number, priority: number) => void }).setpriority?.(process.pid, -10);
        logger.info("Process priority set to high (-10 nice)");
      } catch (e) {
        logger.warn({ err: e }, "Could not set process priority (requires CAP_SYS_NICE)");
      }
    }
  } catch { /* ignore if config table not yet ready */ }
}

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

function killActiveChildren(signal: NodeJS.Signals = "SIGTERM") {
  const count = jobProcessController.activeChildren.size;
  if (count > 0) {
    logger.info({ count }, `Killing ${count} active child process(es) with ${signal}`);
    for (const child of jobProcessController.activeChildren) {
      terminateProcessTree(child, signal);
    }
  }
}

async function hasActiveJobs(): Promise<boolean> {
  const activeJobs = await db.select({ id: jobsTable.id }).from(jobsTable).where(
    sql`status IN ('pending','scanning','transcribing','compressing','remuxing')`
  ).limit(1);
  return activeJobs.length > 0;
}

/**
 * After a restart the in-memory job executor (cancelledJobs, jobProcesses,
 * running promises) is gone, so any task still marked as running can never
 * make progress again — the queue would hang forever on it. Reset those rows
 * to a terminal error so the user can retry them and the queue keeps moving.
 * Pending tasks are untouched: they were never started and can still run.
 */
async function recoverInterruptedJobs(): Promise<void> {
  const interrupted = await db.select({ id: jobsTable.id }).from(jobsTable).where(
    sql`status IN ('scanning','transcribing','compressing','remuxing')`,
  );
  if (interrupted.length === 0) return;
  await db.update(jobsTable).set({
    status: "error",
    errorMessage: "服务重启导致任务中断，请重新启动该任务",
    completedAt: new Date(),
  }).where(
    sql`status IN ('scanning','transcribing','compressing','remuxing')`,
  );
  logger.info(
    { count: interrupted.length, ids: interrupted.map((row: { id: number }) => row.id) },
    "Marked interrupted jobs as error after restart",
  );
}

process.on("SIGTERM", () => {
  logger.info("SIGTERM received — shutting down gracefully");
  killActiveChildren("SIGTERM");
  setTimeout(() => process.exit(0), 3000);
});

process.on("SIGINT", () => {
  killActiveChildren("SIGTERM");
  process.exit(0);
});

ensureRuntimeDirectories()
  .then(() => seedBundledTools())
  .then(() => runMigrations())
  .then(() => recoverInterruptedJobs())
  .then(() => {
    app.listen(port, "127.0.0.1", (err) => {
      if (err) {
        logger.error({ err }, "Error listening on port");
        process.exit(1);
      }
      logger.info({ port }, "Server listening");

      // ── Browser-close auto-shutdown (explicit opt-in only) ─────────────────
      // Frontend sends POST /api/ping every 15 s. If no ping arrives for 60 s
      // we can exit so Windows releases file locks. Long local jobs must never
      // be killed by a missing browser ping, so this behavior is disabled by
      // default and still checks active jobs before exiting.
      if ((process.env.MEDIASCULPT_AUTO_SHUTDOWN ?? process.env.VX_AGENT_AUTO_SHUTDOWN) === "1") {
        const rawTimeout = Number(process.env.MEDIASCULPT_PING_TIMEOUT_MS ?? process.env.VX_AGENT_PING_TIMEOUT_MS);
        const PING_TIMEOUT_MS = Number.isFinite(rawTimeout) && rawTimeout >= 60_000 ? rawTimeout : 60_000;
        setInterval(async () => {
          if (Date.now() - heartbeat.lastPingMs > PING_TIMEOUT_MS) {
            let activeJobs = true;
            try {
              activeJobs = await hasActiveJobs();
            } catch (error) {
              logger.warn({ error }, "Could not check active jobs during browser ping timeout — keeping API alive");
            }
            if (activeJobs) {
              logger.info("Browser ping timed out but active jobs exist — keeping API alive");
              heartbeat.lastPingMs = Date.now();
              return;
            }
            logger.info(`No browser ping for ${Math.round(PING_TIMEOUT_MS / 1000)} s — shutting down`);
            killActiveChildren("SIGTERM");
            setTimeout(() => process.exit(0), 2000);
          }
        }, 15_000).unref(); // unref so this timer alone doesn't keep the process alive
      }
    });
  })
  .catch((err) => {
    logger.error({ err }, "Migration failed, aborting startup");
    process.exit(1);
  });
