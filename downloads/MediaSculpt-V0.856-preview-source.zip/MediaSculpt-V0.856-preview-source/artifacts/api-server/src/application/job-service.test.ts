import { describe, expect, it, vi } from "vitest";
import { JobService, type JobServiceRecord } from "./job-service";
import { PreviewLimitError } from "../lib/preview-entitlement";

type TestJob = JobServiceRecord & { selectionPlan: string | null };

function createService(initial: TestJob) {
  let job = initial;
  const findById = vi.fn(async () => job);
  const update = vi.fn(async (_id: number, patch: Partial<TestJob>) => {
    job = { ...job, ...patch };
  });
  const startWhenIdle = vi.fn(async () => true);
  const markCancelled = vi.fn();
  const killProcesses = vi.fn();
  const removeIncompleteOutputs = vi.fn(async () => {});
  const addLog = vi.fn(async () => {});
  const service = new JobService<TestJob>({
    findById,
    update,
    startWhenIdle,
    requiresWorkflowSelection: (selectionPlan) =>
      selectionPlan === "needs-confirmation",
    markCancelled,
    killProcesses,
    removeIncompleteOutputs,
    addLog,
  });
  return {
    service,
    findById,
    update,
    startWhenIdle,
    markCancelled,
    killProcesses,
    removeIncompleteOutputs,
    addLog,
  };
}

describe("JobService", () => {
  it("starts pending jobs and returns the refreshed record", async () => {
    const deps = createService({
      id: 7,
      status: "pending",
      selectionPlan: "confirmed",
    });

    const result = await deps.service.start(7);

    expect(result).toMatchObject({
      kind: "started",
      job: { id: 7, status: "pending" },
    });
    expect(deps.startWhenIdle).toHaveBeenCalledWith(7);
  });

  it("does not launch a second process when a job is already active", async () => {
    const deps = createService({
      id: 8,
      status: "compressing",
      selectionPlan: null,
    });

    const result = await deps.service.start(8);

    expect(result).toMatchObject({
      kind: "running",
      job: { status: "compressing" },
    });
    expect(deps.startWhenIdle).not.toHaveBeenCalled();
  });

  it("blocks a start when the preview entitlement rejects it", async () => {
    const deps = createService({
      id: 10,
      status: "pending",
      selectionPlan: "confirmed",
    });
    const error = new PreviewLimitError(
      "PREVIEW_LIMIT_EXHAUSTED",
      "preview blocked",
      {
        edition: "preview",
        isActive: false,
        firstStartedAt: "2026-09-14T00:00:00.000Z",
        expiresAt: "2026-10-14T00:00:00.000Z",
        daysRemaining: 0,
        taskLimit: 20,
        successfulTaskCount: 20,
        remainingTasks: 0,
        aiCallCount: 0,
        blockedReason: "quota_exhausted",
      },
    );
    const blockedService = new JobService<TestJob>({
      findById: deps.findById,
      update: deps.update,
      startWhenIdle: deps.startWhenIdle,
      requiresWorkflowSelection: () => false,
      markCancelled: deps.markCancelled,
      killProcesses: deps.killProcesses,
      removeIncompleteOutputs: deps.removeIncompleteOutputs,
      addLog: deps.addLog,
      assertPreviewTaskAllowed: async () => {
        throw error;
      },
    });

    await expect(blockedService.start(10)).resolves.toMatchObject({
      kind: "preview-blocked",
      code: "PREVIEW_LIMIT_EXHAUSTED",
    });
    expect(deps.startWhenIdle).not.toHaveBeenCalled();
  });

  it("cancels idempotently by stopping processes, cleaning outputs, and recording the state", async () => {
    const deps = createService({
      id: 9,
      status: "compressing",
      selectionPlan: null,
    });

    const result = await deps.service.cancel(9);

    expect(result).toMatchObject({
      kind: "cancelled",
      job: { status: "error" },
    });
    expect(deps.markCancelled).toHaveBeenCalledWith(9);
    expect(deps.killProcesses).toHaveBeenCalledWith(9);
    expect(deps.removeIncompleteOutputs).toHaveBeenCalledWith(9);
    expect(deps.update).toHaveBeenCalledWith(
      9,
      expect.objectContaining({ status: "error", errorMessage: "用户取消" }),
    );
    expect(deps.addLog).not.toHaveBeenCalled();
  });

  it("does not record cancellation while an external process is still alive", async () => {
    const deps = createService({
      id: 11,
      status: "compressing",
      selectionPlan: null,
    });
    deps.killProcesses.mockReturnValue(false);

    const result = await deps.service.cancel(11);

    expect(result).toMatchObject({
      kind: "stop-failed",
      job: { status: "compressing" },
    });
    expect(deps.removeIncompleteOutputs).not.toHaveBeenCalled();
    expect(deps.update).not.toHaveBeenCalled();
    expect(deps.addLog).toHaveBeenCalledWith(
      11,
      "error",
      "停止失败：外部处理进程未确认退出，任务仍保持运行状态",
    );
  });
});
