import { canStartJobStatus, isActiveJobStatus } from "./job-errors";
import {
  isPreviewLimitError,
  type PreviewStatus,
} from "../lib/preview-entitlement";

export interface JobServiceRecord {
  id: number;
  status: string;
  selectionPlan?: string | null;
}

type JobPatch = Record<string, unknown>;

export interface JobServiceDependencies<Job extends JobServiceRecord> {
  findById: (jobId: number) => Promise<Job | null>;
  update: (jobId: number, patch: JobPatch) => Promise<void>;
  startWhenIdle: (jobId: number) => Promise<boolean>;
  requiresWorkflowSelection: (
    selectionPlan: string | null | undefined,
  ) => boolean;
  markCancelled: (jobId: number) => void;
  killProcesses: (jobId: number) => Promise<boolean> | boolean;
  clearCancelled?: (jobId: number) => void;
  removeIncompleteOutputs: (jobId: number) => Promise<void>;
  addLog: (
    jobId: number,
    level: "info" | "warn" | "error",
    message: string,
  ) => Promise<void>;
  assertPreviewTaskAllowed?: () => Promise<void>;
}
export type JobCommandResult<Job> =
  | { kind: "not-found" }
  | { kind: "running"; job: Job }
  | { kind: "invalid-state"; job: Job }
  | { kind: "needs-confirmation"; job: Job }
  | {
      kind: "preview-blocked";
      job: Job;
      code: string;
      message: string;
      preview: PreviewStatus;
    }
  | { kind: "started"; job: Job }
  | { kind: "paused"; job: Job }
  | { kind: "cancelled"; job: Job }
  | { kind: "stop-failed"; job: Job };

export class JobService<Job extends JobServiceRecord> {
  constructor(private readonly dependencies: JobServiceDependencies<Job>) {}

  async start(jobId: number): Promise<JobCommandResult<Job>> {
    const job = await this.dependencies.findById(jobId);
    if (!job) return { kind: "not-found" };
    if (isActiveJobStatus(job.status)) return { kind: "running", job };
    if (!canStartJobStatus(job.status)) return { kind: "invalid-state", job };
    if (this.dependencies.requiresWorkflowSelection(job.selectionPlan))
      return { kind: "needs-confirmation", job };

    try {
      await this.dependencies.assertPreviewTaskAllowed?.();
    } catch (error) {
      if (isPreviewLimitError(error)) {
        return {
          kind: "preview-blocked",
          job,
          code: error.errorCode,
          message: error.message,
          preview: error.preview,
        };
      }
      throw error;
    }

    await this.dependencies.startWhenIdle(jobId);
    return {
      kind: "started",
      job: (await this.dependencies.findById(jobId)) ?? job,
    };
  }

  async pause(jobId: number): Promise<JobCommandResult<Job>> {
    const job = await this.dependencies.findById(jobId);
    if (!job) return { kind: "not-found" };

    this.dependencies.markCancelled(jobId);
    const stopped = await this.dependencies.killProcesses(jobId);
    if (stopped === false) {
      this.dependencies.clearCancelled?.(jobId);
      await this.dependencies.addLog(
        jobId,
        "error",
        "停止失败：外部处理进程未确认退出，任务仍保持运行状态",
      );
      return {
        kind: "stop-failed",
        job: (await this.dependencies.findById(jobId)) ?? job,
      };
    }
    await this.dependencies.update(jobId, {
      status: "paused",
      errorMessage: null,
      completedAt: new Date(),
    });
    await this.dependencies.addLog(
      jobId,
      "warn",
      "任务已暂停（可稍后恢复/重试）",
    );
    return {
      kind: "paused",
      job: (await this.dependencies.findById(jobId)) ?? job,
    };
  }

  async cancel(jobId: number): Promise<JobCommandResult<Job>> {
    const job = await this.dependencies.findById(jobId);
    if (!job) return { kind: "not-found" };

    this.dependencies.markCancelled(jobId);
    const stopped = await this.dependencies.killProcesses(jobId);
    if (stopped === false) {
      this.dependencies.clearCancelled?.(jobId);
      await this.dependencies.addLog(
        jobId,
        "error",
        "停止失败：外部处理进程未确认退出，任务仍保持运行状态",
      );
      return {
        kind: "stop-failed",
        job: (await this.dependencies.findById(jobId)) ?? job,
      };
    }
    await this.dependencies.removeIncompleteOutputs(jobId);
    await this.dependencies.update(jobId, {
      status: "error",
      errorMessage: "用户取消",
      completedAt: new Date(),
    });
    return {
      kind: "cancelled",
      job: (await this.dependencies.findById(jobId)) ?? job,
    };
  }
}
