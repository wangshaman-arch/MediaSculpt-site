// Extracted from routes/jobs.ts: DVD input/navigation helpers (dvdvideo, VOB concat, type maps).
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { lookupAll, metadataIdentityMatches, normalizeTitleEn } from "../lib/metadata";
import { servePreviewSegment, cleanupPreviewSegments } from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import { buildFfconcatFileContent as buildManifest, buildFfconcatChapterContent, buildFfconcatTimedContent, type FfconcatTimedSegment } from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import { appendJobRuntimeLog, appendJobToolOutput } from "../lib/job-runtime-log";
import { appendRuntimeToolLog, appendRuntimeToolOutput } from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import { buildCompressionOutputName, buildRemuxOutputName, cleanSegment, encoderBitDepth, selectBestAudioTrack } from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import { renderBilingualAss, DEFAULT_BILINGUAL_STYLE, type BilingualAssStyle, type SubtitleBlock } from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import { ensureLocalPoster, MEDIA_INFO_DIR, POSTER_META_FILE, posterIdentityMatches } from "../lib/poster";
import { ensureFasterWhisperModel, ensureWhisperCliScript } from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import { hasValidSubtitleCues, isGraphicSubtitleCodec, shouldFallbackToWhisper } from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import { buildDvdRemuxArgs, runDvdRemux, verifyDvdTitle } from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import { buildDvdStructurePayload, resolveRemuxPlanWithLlm, validateRemuxPlan } from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import { assertPreviewTaskAllowed, recordPreviewAiCall, settlePreviewTask } from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import { parseCustomTuning, resolveLogicPlaceholders } from "../lib/custom-tuning";
import { decryptSecret, encryptSecret, isEncryptedSecret } from "../lib/secrets";
import { ffmpegPath, resolveOutputDir, resolveRuntimePath, type RuntimePathConfig } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import { assertCompleteMediaTitle, createDvdMediaTitle } from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import { buildPreviewTranscodeArgs, isPreviewVideoCandidate, previewService } from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";

let resolvedFfmpeg: string | null = null;
let resolvedFfprobe: string | null = null;
export async function ffmpegCmd(): Promise<string> {
  if (!resolvedFfmpeg) resolvedFfmpeg = (await resolveToolPath("ffmpeg").catch(() => null)) ?? "ffmpeg";
  return resolvedFfmpeg;
}
export async function ffprobeCmd(): Promise<string> {
  if (!resolvedFfprobe) resolvedFfprobe = (await resolveToolPath("ffprobe").catch(() => null)) ?? "ffprobe";
  return resolvedFfprobe;
}

/**
 * dvdvideo input paths: drive roots must stay in backslash form (`E:\`).
 * libdvdcss on Windows opens the drive as a raw device and fails on the
 * forward-slash form (`E:/`), which is what ffmpegPath produces.
 */
export function dvdInputArg(p: string): string {
  return /^[a-zA-Z]:[\\/]?$/.test(p) ? p : ffmpegPath(p);
}

/**
 * Best-effort provisioning of libdvdcss-2.dll next to ffmpeg/ffprobe so that
 * CSS-encrypted DVDs can be read through the dvdvideo demuxer. The check is
 * cheap (file existence) and the download only happens when the DLL is
 * missing. Failures are non-blocking: regular (non-encrypted) media still
 * works without the DLL.
 */
export async function ensureDvdCssSupport(executable: string | null | undefined): Promise<"ok" | "failed" | "unsupported"> {
  if (!executable) return "failed";
  const status = await ensureLibdvdcss(executable, {
    onLog: async (message) => { await appendRuntimeToolLog(message).catch(() => {}); },
  }).catch(() => "failed" as const);
  if (status === "installed") {
    await appendRuntimeToolLog(`libdvdcss: auto-installed for ${executable}`).catch(() => {});
  }
  return status === "already" || status === "installed" ? "ok" : status;
}

/**
 * Normalize a DVD source path into the input that the `dvdvideo` demuxer can
 * open: drive roots for ISO/optical sources, the VIDEO_TS folder itself for
 * folder-based rips. See resolveDvdVideoInputPath in lib/disc.
 */
export function dvdVideoInputPath(sourcePath: string): string {
  return resolveDvdVideoInputPath(normalizeDiscSourcePath(sourcePath));
}

export function buildFfconcatFileContent(files: string[]): string { return buildManifest(files, process.platform); }

export async function writeDvdConcatListFile(title: DvdTitle, purpose: string): Promise<string> {
  const listName = `vx-${purpose}-${title.titleNumber || "dvd"}-${Date.now()}-${Math.random().toString(36).slice(2)}.ffconcat`;
  const listFile = path.join(os.tmpdir(), listName);
  const mediaTitle = createDvdMediaTitle(title);
  assertCompleteMediaTitle(mediaTitle);
  await fs.writeFile(listFile, buildFfconcatFileContent([...mediaTitle.orderedInputs]), "utf8");
  await fs.stat(listFile);
  return listFile;
}

export function dvdConcatInputArgs(listFile: string): string[] {
  // DVD VOBs are designed to be byte-spliced into one continuous MPEG-PS
  // stream. The concat demuxer splits packets at file boundaries and corrupts
  // later GOPs; the concat protocol keeps a single continuous stream so the
  // later part of the movie stays playable.
  try {
    const content = fsSync.readFileSync(listFile, "utf8");
    const files = content
      .split(/\r?\n/)
      .map((line) => {
        const match = /^file\s+(?:'([^']+)'|(.+))$/.exec(line.trim());
        return match ? (match[1] ?? match[2] ?? "").trim() : "";
      })
      .filter(Boolean);
    if (files.length > 0 && files.some((file) => /\.vob$/i.test(file))) {
      return ["-i", `concat:${files.map((file) => ffmpegPath(file).replace(/\\/g, "/")).join("|")}`];
    }
  } catch {
    // Fall through to the concat demuxer.
  }
  return ["-f", "concat", "-safe", "0", "-i", ffmpegPath(listFile)];
}

export function isVobConcatList(listFile: string): boolean {
  try {
    const content = fsSync.readFileSync(listFile, "utf8");
    return /\.vob["']?$/im.test(content);
  } catch {
    return false;
  }
}

/** Decode a short sample near the end of an output to catch mid-file
 * corruption (e.g. broken VOB concat boundaries) before marking done. */

export function dvdTitleNavigationInputArgs(title: DvdTitle): string[] {
  const args = dvdTitleInputArgs(title);
  return args.map((arg, index) => args[index - 1] === "-i" ? dvdInputArg(arg) : arg);
}

export function ffmpegSupportsDvdTitleNavigation(error: unknown): boolean {
  const message = error instanceof Error ? error.message : String(error);
  return !message.includes("Unrecognized option 'title'") &&
    !message.includes("Option not found") &&
    !message.includes("Unknown input format: 'dvdvideo'");
}

/**
 * Prefer the dvdvideo title number that was actually verified by ffprobe
 * (taskSnapshot.toolSelections.dvdVtsNumber, a global DVD title number)
 * over the per-VTS index resolved from the IFO files. The two numbering
 * schemes only coincide when every VTS holds exactly one title; on discs
 * like The Odyssey (feature = global title 7, VTS_02) the VTS index (2)
 * selects a different short title and the dvdvideo stream map fails.
 */
export function dvdNavigationTitleWithVerifiedNumber(title: DvdTitle, taskSnapshot: TaskSnapshotV1 | null | undefined): DvdTitle {
  const verifiedNumber = taskSnapshot?.toolSelections.dvdVtsNumber;
  if (typeof verifiedNumber === "number" && verifiedNumber > 0 && verifiedNumber !== title.titleNumber) {
    return { ...title, titleNumber: verifiedNumber };
  }
  return title;
}

/**
 * Fail fast when the DVD rip is missing content VOBs: the dvdvideo demuxer
 * and the VOB-concat fallback both silently truncate the output at the hole,
 * which produced "successful" but unplayable/truncated files in the past.
 */
export function assertDvdTitleComplete(title: DvdTitle | null | undefined): void {
  if (title) assertCompleteMediaTitle(createDvdMediaTitle(title));
}

/**
 * Build `-map 0:v:N / 0:a:N / 0:s:N` maps for a DVD dvdvideo input. Index maps
 * (`-map 0:5`) become ambiguous when the dvdvideo demuxer re-exposes the same
 * title mid-read on some discs (each stream appears twice), which made the
 * muxer write duplicate TrackEntries and produced structurally corrupt MKVs
 * (ffprobe reports EBML overruns). Type maps stay stable across re-probes.
 * Ordinals are derived from the verified analysis stream list so non-contiguous
 * selections still map to the correct input streams.
 */
export function buildDvdTypeMaps(taskSnapshot: TaskSnapshotV1 | null | undefined, analysisTitle?: { streams?: Array<{ index: number; codecType: string }> } | null): string[] | null {
  if (!taskSnapshot) return null;
  const ordinals = new Map<number, { prefix: "v" | "a" | "s"; n: number }>();
  const counts = { v: 0, a: 0, s: 0 };
  for (const stream of analysisTitle?.streams ?? []) {
    const prefix = stream.codecType === "video" ? "v" as const
      : stream.codecType === "audio" ? "a" as const
        : stream.codecType === "subtitle" ? "s" as const
          : null;
    if (!prefix) continue;
    ordinals.set(stream.index, { prefix, n: counts[prefix] });
    counts[prefix] += 1;
  }
  const maps: string[] = [];
  const push = (ids: string[] | undefined) => {
    for (const id of ids ?? []) {
      const match = /^stream:(\d+)$/.exec(id);
      if (!match) continue;
      const ordinal = ordinals.get(Number(match[1]));
      if (ordinal) maps.push("-map", `0:${ordinal.prefix}:${ordinal.n}`);
    }
  };
  push(taskSnapshot.streamSelection.videoTrackIds);
  push(taskSnapshot.streamSelection.audioTrackIds);
  push(taskSnapshot.streamSelection.subtitleTrackIds);
  return maps.length > 0 ? maps : null;
}

export async function withDvdConcatList<T>(title: DvdTitle, purpose: string, fn: (listFile: string) => Promise<T>): Promise<T> {
  const listFile = await writeDvdConcatListFile(title, purpose);
  try {
    return await fn(listFile);
  } finally {
    await fs.unlink(listFile).catch(() => {});
  }
}

// Track running child processes per job so cancel can kill them
// Set of jobIds that have been requested to cancel
