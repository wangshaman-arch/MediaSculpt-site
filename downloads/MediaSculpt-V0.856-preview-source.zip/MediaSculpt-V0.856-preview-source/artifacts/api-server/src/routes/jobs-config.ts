// Extracted from routes/jobs.ts: config loading and secret redaction/decryption.
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { lookupAll, metadataIdentityMatches, normalizeTitleEn } from "../lib/metadata";
import { servePreviewSegment, cleanupPreviewSegments } from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import { buildFfconcatFileContent as buildManifest, buildFfconcatChapterContent, buildFfconcatTimedContent, type FfconcatTimedSegment } from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import { appendJobRuntimeLog, appendJobToolOutput } from "../lib/job-runtime-log";
import { appendRuntimeToolLog, appendRuntimeToolOutput } from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import { buildCompressionOutputName, buildRemuxOutputName, cleanSegment, encoderBitDepth, selectBestAudioTrack } from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import { renderBilingualAss, DEFAULT_BILINGUAL_STYLE, type BilingualAssStyle, type SubtitleBlock } from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import { ensureLocalPoster, MEDIA_INFO_DIR, POSTER_META_FILE, posterIdentityMatches } from "../lib/poster";
import { ensureFasterWhisperModel, ensureWhisperCliScript } from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import { hasValidSubtitleCues, isGraphicSubtitleCodec, shouldFallbackToWhisper } from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import { buildDvdRemuxArgs, runDvdRemux, verifyDvdTitle } from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import { buildDvdStructurePayload, resolveRemuxPlanWithLlm, validateRemuxPlan } from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import { assertPreviewTaskAllowed, recordPreviewAiCall, settlePreviewTask } from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import { parseCustomTuning, resolveLogicPlaceholders } from "../lib/custom-tuning";
import { decryptSecret, encryptSecret, isEncryptedSecret } from "../lib/secrets";
import { ffmpegPath, resolveOutputDir, resolveRuntimePath, type RuntimePathConfig } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import { assertCompleteMediaTitle, createDvdMediaTitle } from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import { buildPreviewTranscodeArgs, isPreviewVideoCandidate, previewService } from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";

/** 需要加密/脱敏的密钥字段 */
export const SECRET_FIELDS = [
  "deepseekApiKey", "siliconflowApiKey", "zhipuApiKey", "moonshotApiKey", "qwenApiKey",
  "groqApiKey", "geminiApiKey", "openaiApiKey", "tmdbApiKey", "omdbApiKey",
] as const;

/** 密钥脱敏：已配置的 Key 仅返回 "__set__" 掩码，永不把明文发给前端；空值返回 ""。 */
export function redactSecrets(row: Record<string, unknown>): Record<string, unknown> {
  const redacted = { ...row };
  for (const field of SECRET_FIELDS) {
    redacted[field] = redacted[field] ? "__set__" : "";
  }
  return redacted;
}

type ConfigRow = typeof configTable.$inferSelect;

let secretDecryptCache: { fingerprint: string; decrypted: Record<string, string> } | null = null;

function secretFingerprint(row: ConfigRow): string {
  return SECRET_FIELDS.map((field) => String((row as Record<string, unknown>)[field] ?? "")).join("\u0000");
}

/** 解密密钥字段（DPAPI），并把遗留明文自动迁移为加密存储；结果带进程级缓存避免每次请求都调 PowerShell。 */
async function decryptConfigSecrets(row: ConfigRow): Promise<ConfigRow> {
  const fingerprint = secretFingerprint(row);
  if (!secretDecryptCache || secretDecryptCache.fingerprint !== fingerprint) {
    const decrypted: Record<string, string> = {};
    const migrations: Record<string, string> = {};
    for (const field of SECRET_FIELDS) {
      const stored = (row as Record<string, unknown>)[field];
      const value = typeof stored === "string" ? stored : "";
      if (!value) continue;
      decrypted[field] = await decryptSecret(value);
      // 旧明文 → 迁移为 DPAPI 加密
      if (!isEncryptedSecret(value)) {
        migrations[field] = await encryptSecret(value);
      }
    }
    if (Object.keys(migrations).length > 0) {
      await db.update(configTable)
        .set(migrations as Partial<ConfigRow>)
        .where(eq(configTable.id, row.id))
        .catch(() => {});
    }
    secretDecryptCache = { fingerprint, decrypted };
  }
  return { ...row, ...secretDecryptCache.decrypted };
}

export async function getConfig() {
  const rows = await db.select().from(configTable).limit(1);
  if (rows.length === 0) {
    // First run: insert with platform-appropriate defaults so the UI shows
    // a navigable starting path instead of a Linux container path.
    const home = os.homedir();
    const defaultWatch = process.platform === "win32"
      ? (home || "C:\\")
      : path.join(home, "Downloads");
    const defaultOutput = process.platform === "win32"
      ? path.join(home || process.cwd(), "Videos", "MediaSculpt Output")
      : path.join(home, "Movies", "MediaSculpt Output");
    await db.insert(configTable).values({
      watchDirectory: defaultWatch,
      outputDirectory: defaultOutput,
    });
    const fresh = await db.select().from(configTable).limit(1);
    return await decryptConfigSecrets(fresh[0]);
  }

  const config = rows[0];

  // On Windows, silently migrate any Linux-style absolute paths (e.g. /downloads,
  // /media/output) that cannot be opened on the host filesystem. Replace them with
  // sensible Windows defaults so the file browser and scanner work out of the box.
  if (process.platform === "win32") {
    const isLinuxPath = (p: string | null | undefined) =>
      !!p && /^\/[^:]/.test(p);          // starts with / but not a drive letter

    const updates: { watchDirectory?: string; outputDirectory?: string } = {};

    if (isLinuxPath(config.watchDirectory)) {
      updates.watchDirectory = os.homedir() || "C:\\";
    }
    if (isLinuxPath(config.outputDirectory)) {
      updates.outputDirectory = path.join(process.cwd(), "output");
    }

    if (Object.keys(updates).length > 0) {
      await db.update(configTable)
        .set(updates)
        .where(eq(configTable.id, config.id));
      return await decryptConfigSecrets({ ...config, ...updates });
    }
  }

  return await decryptConfigSecrets(config);
}
