import { describe, expect, it } from "vitest";
import {
  parseSelectedChapterIds,
  readPersistedSelectedChapters,
  selectChaptersById,
} from "./job-remux-chapter-selection";

describe("Remux chapter selection", () => {
  it("parses selected chapter ids and rejects malformed selections", () => {
    expect(parseSelectedChapterIds("[0,2,4]")).toEqual([0, 2, 4]);
    expect(() => parseSelectedChapterIds("not-json")).toThrow();
    expect(() => parseSelectedChapterIds(JSON.stringify({ ids: [1] }))).toThrow();
  });

  it("restores only the selected persisted chapter times", () => {
    expect(readPersistedSelectedChapters(JSON.stringify({
      chapterTimes: [
        { id: 0, startSeconds: 0, endSeconds: 10 },
        { id: 1, startSeconds: 10, endSeconds: 20 },
      ],
    }), [1])).toEqual([{ id: 1, startSeconds: 10, endSeconds: 20, title: null }]);
  });

  it("selects chapters without changing their source timing", () => {
    const chapters = [
      { id: 0, startSeconds: 0, endSeconds: 10, title: "A" },
      { id: 1, startSeconds: 10, endSeconds: 20, title: "B" },
    ];
    expect(selectChaptersById(chapters, [1])).toEqual([chapters[1]]);
  });
});
