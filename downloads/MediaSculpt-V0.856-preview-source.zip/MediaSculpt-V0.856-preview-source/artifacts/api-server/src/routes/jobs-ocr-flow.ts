// Extracted from routes/jobs.ts: shared OCR subtitle execution flow.
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { lookupAll, metadataIdentityMatches, normalizeTitleEn } from "../lib/metadata";
import { servePreviewSegment, cleanupPreviewSegments } from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import { buildFfconcatFileContent as buildManifest, buildFfconcatChapterContent, buildFfconcatTimedContent, type FfconcatTimedSegment } from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import { appendJobRuntimeLog, appendJobToolOutput } from "../lib/job-runtime-log";
import { appendRuntimeToolLog, appendRuntimeToolOutput } from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import { buildCompressionOutputName, buildRemuxOutputName, cleanSegment, encoderBitDepth, selectBestAudioTrack } from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import { renderBilingualAss, DEFAULT_BILINGUAL_STYLE, type BilingualAssStyle, type SubtitleBlock } from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import { ensureLocalPoster, MEDIA_INFO_DIR, POSTER_META_FILE, posterIdentityMatches } from "../lib/poster";
import { ensureFasterWhisperModel, ensureWhisperCliScript } from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import { hasValidSubtitleCues, isGraphicSubtitleCodec, shouldFallbackToWhisper } from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import { buildDvdRemuxArgs, runDvdRemux, verifyDvdTitle } from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import { buildDvdStructurePayload, resolveRemuxPlanWithLlm, validateRemuxPlan } from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import { assertPreviewTaskAllowed, recordPreviewAiCall, settlePreviewTask } from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import { parseCustomTuning, resolveLogicPlaceholders } from "../lib/custom-tuning";
import { decryptSecret, encryptSecret, isEncryptedSecret } from "../lib/secrets";
import { ffmpegPath, resolveOutputDir, resolveRuntimePath, type RuntimePathConfig } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import { assertCompleteMediaTitle, createDvdMediaTitle } from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import { buildPreviewTranscodeArgs, isPreviewVideoCandidate, previewService } from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";
import {
  addLog,
  detectExistingSubtitleFiles,
  translateBatch,
  buildTranslationPrompt,
  cancelledJobs,
  trackJobOutputFile,
  ocrProgressPercent,
  type DetectedSubtitleFile,
} from "./jobs";

/**
 * Shared OCR execution used by explicit "ocr" jobs and by the "auto" subtitle
 * pipeline when a source has only graphic subtitles. When failJobOnError is
 * false (auto mode), OCR failures return ok:false so the caller can fall back
 * to speech recognition instead of failing the job.
 */
export async function executeOcrSubtitleFlow(params: {
  jobId: number;
  mediaInputPath: string;
  config: typeof configTable.$inferSelect;
  job: typeof jobsTable.$inferSelect;
  subtitleDirJob: string;
  outputBaseName: string;
  ocrTitleId: string | null;
  engine?: string;
  language?: string;
  /** 双语任务固定以简体中文为纠错/翻译目标，不受「输出语言」影响 */
  forceChineseTarget?: boolean;
  failJobOnError: boolean;
  addLog: (level: "info" | "warn" | "error", message: string) => Promise<void>;
}): Promise<{ ok: boolean; cancelled?: boolean; skipped?: boolean; subtitlePath: string | null; translatedSubtitlePath: string | null; error?: string }> {
  const { jobId, mediaInputPath, config, job, subtitleDirJob, outputBaseName, ocrTitleId, failJobOnError, addLog } = params;
  const engine: OcrEngine = (params.engine ?? job.ocrEngine ?? "auto") as OcrEngine;
  const language = params.language ?? job.ocrLanguage ?? "auto";
  let subtitlePath: string | null = null;
  let translatedSubtitlePath: string | null = null;
  if (cancelledJobs.has(jobId)) return { ok: false, cancelled: true, subtitlePath: null, translatedSubtitlePath: null };
  // 外置中文字幕文件（无论多少、是否同名）不阻止 OCR/翻译：
  // 只有视频本身内置中文字幕轨才算“已翻译”。
  const existingSubs = await detectExistingSubtitleFiles(
    path.dirname(mediaInputPath),
    path.basename(mediaInputPath, path.extname(mediaInputPath)),
  ).catch(() => [] as DetectedSubtitleFile[]);
  const existingEn = existingSubs.find((item) => item.language === "en");
  await db.update(jobsTable).set({ status: "transcribing", progress: 5 }).where(eq(jobsTable.id, jobId));
  await addLog("info", `【图形字幕 OCR】开始识别图形字幕（引擎：${engine}，语言：${language}）`);
  if (ocrTitleId) await addLog("info", `OCR 目标标题：HandBrake Title ${ocrTitleId}`);
  try {
    let ocrProgress = 5;
    const result = await runSubtitleOcr({
      sourcePath: mediaInputPath,
      config,
      engine,
      language,
      titleId: ocrTitleId,
      onProgress: async (message) => {
        await addLog("info", message);
        ocrProgress = ocrProgressPercent(message, ocrProgress);
        await db.update(jobsTable).set({ progress: ocrProgress }).where(eq(jobsTable.id, jobId));
      },
    });
    subtitlePath = result.srtPath;
    trackJobOutputFile(jobId, result.srtPath);
    // DVD OCR writes beside the disc folder by default; keep a single
    // artifact by moving it into the job subtitle directory instead.
    if (job.mediaType === "dvd") {
      const targetPath = path.join(subtitleDirJob, `${outputBaseName}.ocr.srt`);
      trackJobOutputFile(jobId, targetPath);
      try {
        await fs.copyFile(result.srtPath, targetPath);
        subtitlePath = targetPath;
        if (path.resolve(targetPath) !== path.resolve(result.srtPath)) {
          await fs.unlink(result.srtPath).catch(() => {});
        }
      } catch {
        // source folder may be read-only; keep the beside-source path
      }
    }

    // ── OCR → LLM correction + simplified-Chinese output ────────────────────
    const ocrLanguageIso = result.language;
    const isEnglishSource = ocrLanguageIso === "en";
    const enableBilingual = config.ocrBilingualCorrection !== false;
    const qualityScore = result.qualityScore ?? 80;
    const needBilingual = enableBilingual && !isEnglishSource && qualityScore < 85;
    await addLog("info", `识别质量 ${qualityScore}${result.qualityConfidenceBased ? "（引擎置信度）" : "（内容启发式）"}${needBilingual ? " → 启用英文对照纠错" : " → 跳过双语对照"}`);
    let englishBlocks: SrtBlock[] | null = null;
    // Prefer the disc's native English graphic-subtitle track as the semantic
    // reference (most accurate names); fall back to an existing English
    // subtitle file in the directory (e.g. a previous Whisper SRT).
    if (needBilingual && ocrTitleId) {
      try {
        await addLog("info", "源字幕非英文，正在 OCR 原盘英文图形字幕轨作为纠错对照…");
        const engResult = await runSubtitleOcr({
          sourcePath: mediaInputPath,
          config,
          engine: "tesseract",
          language: "eng",
          titleId: ocrTitleId,
          outputBaseName: `${outputBaseName}.eng`,
          onProgress: async (message) => {
            await addLog("info", `[英文对照] ${message}`);
          },
        });
        if ((engResult.language === "en" || engResult.language === "eng") && engResult.events.length > 0) {
          const engContent = await fs.readFile(engResult.srtPath, "utf-8");
          englishBlocks = parseSrt(engContent.replace(/\r\n/g, "\n"));
          const enTarget = path.join(subtitleDirJob, `${outputBaseName}.en.srt`);
          await fs.copyFile(engResult.srtPath, enTarget).catch(() => {});
          await fs.unlink(engResult.srtPath).catch(() => {});
          await addLog("info", `原盘英文字幕轨 OCR 就绪（${engResult.events.length} 条）→ ${enTarget}`);
        } else {
          await addLog("warn", "原盘没有可用的英文图形字幕轨，尝试复用目录已有英文字幕…");
        }
      } catch (error) {
        await addLog("warn", `原盘英文轨 OCR 失败（尝试复用已有英文字幕）：${error instanceof Error ? error.message : String(error)}`);
      }
    }
    if (!englishBlocks && existingEn) {
      // Fallback: reuse an existing English subtitle file (e.g. a previous
      // Whisper SRT) as the semantic reference.
      try {
        const engContent = await fs.readFile(existingEn.path, "utf-8");
        const parsedEn = parseSrt(engContent.replace(/\r\n/g, "\n"));
        if (parsedEn.length > 0) {
          englishBlocks = parsedEn;
          const enTarget = path.join(subtitleDirJob, `${outputBaseName}.en.srt`);
          await fs.copyFile(existingEn.path, enTarget).catch(() => {});
          await addLog("info", `复用目录已有英文字幕作为对照：${existingEn.path}（${parsedEn.length} 条）`);
        }
      } catch (error) {
        await addLog("warn", `复用已有英文字幕失败：${error instanceof Error ? error.message : String(error)}`);
      }
    }
    const apiKey = resolveApiKey(config) || process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
    let englishLines: string[] | null = null;
    if (!apiKey) {
      await addLog("warn", "未配置 AI API Key，OCR 结果仅保留识别原文，不执行纠错/简体中文转换");
    } else {
      const isChineseSource = ocrLanguageIso === "zh" || ocrLanguageIso === "chi" || ocrLanguageIso === "cmn";
      const { baseUrl, model, label: providerLabel } = resolveAiEndpoint(config);
      const targetLang = params.forceChineseTarget ? "zh-CN" : config.translationTargetLang || "zh-CN";
      await addLog("info", `OCR 纠错${isChineseSource ? "转简体" : "翻译"}：${providerLabel} / ${model} → ${targetLang}（源语种 ${ocrLanguageIso ?? "未知"}${englishLines ? "，双语对照" : ""}）`);
      try {
        const srtContent = await fs.readFile(subtitlePath, "utf-8");
        const blocks = parseSrt(srtContent.replace(/\r\n/g, "\n"));
        if (blocks.length > 0) {
          englishLines = englishBlocks ? alignEnglishReference(blocks, englishBlocks) : null;
          const basePrompt = await buildTranslationPrompt(
            job,
            config,
            targetLang,
            isChineseSource ? "zh" : (ocrLanguageIso === "unknown" ? null : ocrLanguageIso),
          );
          const sourceName = path.basename(job.filePath) || job.filePath;
          const instruction = isChineseSource
            ? `以下字幕是通过 OCR 从“${sourceName}”的图形字幕识别的（原字幕可能为繁体中文），可能存在识别错误。要求：\n1. 结合上下文纠正明显的 OCR 错误（人名、专名、错字、漏字），例如「肉嘉倫」应纠正为「帕瓦罗蒂」。\n2. 输出必须为简体中文：把所有繁体字转换为简体字，例如「我們」→「我们」、「認識」→「认识」、「因為」→「因为」。\n3. 禁止输出任何繁体字，输出繁体即视为错误。\n逐条输出，保持行号与时间轴不变。`
            : `以下字幕是通过 OCR 从“${sourceName}”的图形字幕识别的，可能存在识别错误。请先结合上下文纠正明显的 OCR 错误（人名、专名、错字、漏字），再翻译成简体中文。逐条输出，保持行号与时间轴不变。`;
          const bilingualNote = englishLines
            ? "\n每条输入包含「EN」（准确的英文字幕）与「OCR」（中文图形字幕识别结果，可能有错）。请以 EN 的含义为基准纠正 OCR 错误（如「肉嘉倫」→「帕瓦罗蒂」），只输出纠正后的简体中文文本，不要输出 EN / OCR 前缀。"
            : "";
          const systemPrompt = `${basePrompt}\n\n【OCR 字幕纠错与简体中文】\n${instruction}${bilingualNote}`;
          const BATCH_SIZE = 50;
          const translatedBlocks: SrtBlock[] = [];
          for (let i = 0; i < blocks.length; i += BATCH_SIZE) {
            const batch = blocks.slice(i, i + BATCH_SIZE);
            const pct = Math.round((i / blocks.length) * 100);
            await addLog("info", `OCR 纠错进度 ${pct}%（${i + 1}–${Math.min(i + BATCH_SIZE, blocks.length)} / ${blocks.length}${englishLines ? "，双语对照" : ""}）`);
            const items = batch.map((b, j) => {
              const en = englishLines?.[i + j];
              return en ? `EN: ${en}\nOCR: ${b.text}` : b.text;
            });
            const translated = await translateBatch(items, systemPrompt, apiKey, baseUrl, model);
            for (let j = 0; j < batch.length; j++) {
              translatedBlocks.push({ ...batch[j], text: translated[j] || batch[j].text });
            }
          }
          const translatedSrt = renderSrtSimplified(translatedBlocks, true);
          translatedSubtitlePath = path.join(subtitleDirJob, `${outputBaseName}.zhs.srt`);
          trackJobOutputFile(jobId, translatedSubtitlePath);
          await fs.writeFile(translatedSubtitlePath, translatedSrt, "utf-8");
          await addLog("info", `OCR 纠错完成：${translatedSubtitlePath}`);
        }
      } catch (error) {
        await addLog("error", `OCR 纠错失败：${error instanceof Error ? error.message : String(error)}`);
      }
    }
    await db.update(jobsTable).set({ progress: 100, subtitlePath, translatedSubtitlePath, subtitleSource: "ocr" }).where(eq(jobsTable.id, jobId));
    await addLog("info", `OCR 识别完成：${subtitlePath}（引擎=${result.engine}，语种=${result.language}${translatedSubtitlePath ? `；中文翻译=${translatedSubtitlePath}` : ""}）`);
    return { ok: true, subtitlePath, translatedSubtitlePath };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    await addLog("error", `OCR 识别失败：${message}`);
    if (failJobOnError) {
      await db.update(jobsTable).set({ status: "error", errorMessage: message, completedAt: new Date() }).where(eq(jobsTable.id, jobId));
    }
    return { ok: false, subtitlePath: null, translatedSubtitlePath: null, error: message };
  }
}
