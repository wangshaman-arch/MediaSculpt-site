export type SelectedRemuxChapter = {
  id: number;
  startSeconds: number;
  endSeconds: number;
  title: string | null;
};

export function parseSelectedChapterIds(serialized: string): number[] {
  const parsed: unknown = JSON.parse(serialized);
  if (!Array.isArray(parsed)) throw new Error("章节选择必须是数组");
  return parsed as number[];
}

export function selectChaptersById<T extends { id: number }>(chapters: T[], selectedIds: number[]): T[] {
  return chapters.filter((chapter) => selectedIds.includes(chapter.id));
}

export function readPersistedSelectedChapters(
  selectionPlan: string | null | undefined,
  selectedIds: number[],
): SelectedRemuxChapter[] {
  try {
    const parsed = selectionPlan ? JSON.parse(selectionPlan) as { chapterTimes?: unknown } : null;
    if (!Array.isArray(parsed?.chapterTimes) || parsed.chapterTimes.length === 0) return [];
    return parsed.chapterTimes
      .filter((chapter) => selectedIds.includes(Number((chapter as { id?: unknown }).id)))
      .map((chapter) => {
        const value = chapter as { id?: unknown; startSeconds?: unknown; endSeconds?: unknown };
        return {
          id: Number(value.id) || 0,
          startSeconds: Number(value.startSeconds) || 0,
          endSeconds: Number(value.endSeconds) || 0,
          title: null,
        };
      });
  } catch {
    return [];
  }
}
