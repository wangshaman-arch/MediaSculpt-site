import { describe, expect, it } from "vitest";
import { remuxFinalizationMode } from "./job-remux-finalization";

describe("remux finalization", () => {
  it("keeps a validated remux as an intermediate pipeline artifact", () => {
    expect(remuxFinalizationMode(true)).toBe("pipeline");
  });

  it("finishes the job when remux is the last stage", () => {
    expect(remuxFinalizationMode(false)).toBe("terminal");
  });
});
