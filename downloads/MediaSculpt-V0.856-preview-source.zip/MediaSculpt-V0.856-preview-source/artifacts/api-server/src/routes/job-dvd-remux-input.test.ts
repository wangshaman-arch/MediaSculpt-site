import { describe, expect, it } from "vitest";
import { findDvdVobFiles, prepareDvdRemuxInput } from "./job-dvd-remux-input";

describe("DVD remux input", () => {
  it("finds only content VOBs for the selected IFO and sorts them", () => {
    expect(findDvdVobFiles("VTS_02_0.IFO", [
      "VTS_02_3.VOB",
      "VTS_01_1.VOB",
      "VTS_02_0.VOB",
      "VTS_02_1.VOB",
      "VTS_02_2.VOB",
      "VIDEO_TS.IFO",
    ])).toEqual(["VTS_02_1.VOB", "VTS_02_2.VOB", "VTS_02_3.VOB"]);
  });

  it("uses VOB concat when a DVD title has no usable navigation number", async () => {
    const logs: string[] = [];
    const title = {
      titleNumber: 0,
      discRoot: "D:\\DVD",
      videoTsDir: "D:\\DVD\\VIDEO_TS",
      ifoPath: "D:\\DVD\\VIDEO_TS\\VTS_01_0.IFO",
      vobFiles: ["D:\\DVD\\VIDEO_TS\\VTS_01_1.VOB"],
      sizeBytes: 100,
    };
    const result = await prepareDvdRemuxInput({
      jobId: 42,
      sourcePath: title.videoTsDir,
      isIfoInput: false,
      isMplsInput: false,
      mediaType: "dvd",
      taskSnapshot: null,
      dvdTitle: null,
      selectedTitleSizeBytes: null,
      selectedAnalysisEstimatedSize: null,
      resolveDvdTitleForSource: async () => title,
      resolveDvdTitleForIfo: async () => null,
      writeDvdConcatListFile: async () => "C:\\Temp\\dvd.ffconcat",
      log: async (_level, message) => { logs.push(message); },
    });

    expect(result.concatListFile).toBe("C:\\Temp\\dvd.ffconcat");
    expect(result.dvdNavigationTitle).toBeNull();
    expect(logs.some((message) => message.includes("VOB concat"))).toBe(true);
  });
});
