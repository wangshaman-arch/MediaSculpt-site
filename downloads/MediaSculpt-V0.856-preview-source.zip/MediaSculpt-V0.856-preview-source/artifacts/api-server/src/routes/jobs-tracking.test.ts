import { afterEach, describe, expect, it } from "vitest";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import {
  clearJobOutputFiles,
  markJobOutputFileCompleted,
  removeIncompleteJobOutputs,
  trackJobOutputFile,
} from "../infrastructure/job-output-tracker";

describe("job output lifecycle", () => {
  const files: string[] = [];

  afterEach(async () => {
    for (const file of files.splice(0)) await fs.rm(file, { force: true });
    clearJobOutputFiles(42);
  });

  it("keeps a validated earlier pipeline output when a later stage fails", async () => {
    const file = path.join(os.tmpdir(), `mediasculpt-complete-${Date.now()}.mkv`);
    files.push(file);
    await fs.writeFile(file, "validated remux output");
    trackJobOutputFile(42, file);

    markJobOutputFileCompleted(42, file);
    await removeIncompleteJobOutputs(42);

    await expect(fs.stat(file)).resolves.toBeTruthy();
  });
});
