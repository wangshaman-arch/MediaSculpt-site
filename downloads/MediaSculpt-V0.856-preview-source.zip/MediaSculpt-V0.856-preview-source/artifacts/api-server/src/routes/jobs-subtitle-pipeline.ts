// Extracted from routes/jobs.ts: the main subtitle pipeline stage.
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { lookupAll, metadataIdentityMatches, normalizeTitleEn } from "../lib/metadata";
import { servePreviewSegment, cleanupPreviewSegments } from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import { buildFfconcatFileContent as buildManifest, buildFfconcatChapterContent, buildFfconcatTimedContent, type FfconcatTimedSegment } from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import { appendJobRuntimeLog, appendJobToolOutput } from "../lib/job-runtime-log";
import { appendRuntimeToolLog, appendRuntimeToolOutput } from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import { buildCompressionOutputName, buildRemuxOutputName, cleanSegment, encoderBitDepth, selectBestAudioTrack } from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import { renderBilingualAss, DEFAULT_BILINGUAL_STYLE, type BilingualAssStyle, type SubtitleBlock } from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import { ensureLocalPoster, MEDIA_INFO_DIR, POSTER_META_FILE, posterIdentityMatches } from "../lib/poster";
import { ensureFasterWhisperModel, ensureWhisperCliScript } from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import { chooseEmbeddedSubtitleAction, hasValidSubtitleCues, isGraphicSubtitleCodec, shouldFallbackToWhisper } from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import { buildDvdRemuxArgs, runDvdRemux, verifyDvdTitle } from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import { buildDvdStructurePayload, resolveRemuxPlanWithLlm, validateRemuxPlan } from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import { assertPreviewTaskAllowed, recordPreviewAiCall, settlePreviewTask } from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import { parseCustomTuning, resolveLogicPlaceholders } from "../lib/custom-tuning";
import { decryptSecret, encryptSecret, isEncryptedSecret } from "../lib/secrets";
import { ffmpegPath, resolveOutputDir, resolveRuntimePath, type RuntimePathConfig } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import { assertCompleteMediaTitle, createDvdMediaTitle } from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import { buildPreviewTranscodeArgs, isPreviewVideoCandidate, previewService } from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";
import type { PipelineStep } from "./jobs-subtitle-probe";
import {
  addLog,
  selectExternalSubtitleForJob,
  detectExistingSubtitleFiles,
  SUBTITLE_EXTENSIONS,
  getConfig,
  resolveJobOutputDirectory,
  resolveJobSubtitleDirectory,
  ensureDirectory,
  ffprobeCmd,
  ffmpegCmd,
  languageTagIsChinese,
  sampleEmbeddedSubtitleText,
  textLooksChinese,
  translateBatchLibre,
  translateBatch,
  buildTranslationPrompt,
  trackJobOutputFile,
  type DetectedSubtitleFile,
} from "./jobs";

export async function runSubtitlePipeline(jobId: number): Promise<{
  subtitleSource: string;
  rawSubtitlePath: string | null;
  translatedSubtitlePath: string | null;
  steps: PipelineStep[];
}> {
  const steps: PipelineStep[] = [];
  const config = await getConfig();
  const jobRows = await db.select().from(jobsTable).where(eq(jobsTable.id, jobId)).limit(1);
  if (!jobRows.length) throw new Error("任务不存在");
const pipelineBilingual = jobRows[0]?.subtitleMode === "bilingual";
const pipelineMode = pipelineBilingual ? "auto" : jobRows[0]?.subtitleMode ?? "auto";
  // Automatic subtitle mode may use the configured LLM provider (DeepSeek,
  // Gemini, etc.) without forcing users to enable the global translation toggle.
  // Traditional modes keep the existing opt-in behavior and execution path.
  const automaticAiEnabled = jobRows[0]?.subtitleMode === "auto"
    && (config.aiProvider === "libretranslate" || Boolean(resolveApiKey(config) || process.env.AI_INTEGRATIONS_OPENAI_API_KEY));
  const job = {
    ...jobRows[0],
    filePath: resolveRuntimePath(jobRows[0].filePath, config),
    mainTrackPath: jobRows[0].mainTrackPath ? resolveRuntimePath(jobRows[0].mainTrackPath, config) : null,
  };

  const videoPath = job.mainTrackPath || job.filePath;
  const videoDir = path.dirname(videoPath);
  const baseName = path.basename(job.filePath, path.extname(job.filePath));
  const outputDir = resolveJobOutputDirectory(config, job);
  const subtitleDir = resolveJobSubtitleDirectory(config, job);
  await ensureDirectory(outputDir);
  await ensureDirectory(subtitleDir);

  let subtitleSource = "none";
  let rawSubtitlePath: string | null = null;

  await addLog(jobId, "info", "─── 字幕流水线启动 ───");

  // ── Step 1: Check external subtitle files ────────────────────────────────
  await addLog(jobId, "info", "【步骤1】检测外置字幕文件");
  let externalSubFound: string | null = null;
  let externalChineseBilingualSource = false;
  try {
    const dirEntries = await fs.readdir(videoDir);
    for (const entry of dirEntries) {
      const ext = path.extname(entry).toLowerCase();
      if (!SUBTITLE_EXTENSIONS.includes(ext)) continue;
      const entryBase = path.basename(entry, ext);
      // Match: exact base name, or base name with language suffix like .zh, .en, .chs
      if (entryBase === baseName || entryBase.startsWith(baseName + ".")) {
        externalSubFound = path.join(videoDir, entry);
        break;
      }
    }
    const detectedExternal = await detectExistingSubtitleFiles(videoDir, baseName).catch((): DetectedSubtitleFile[] => []);
    const selectedExternal = selectExternalSubtitleForJob(detectedExternal, pipelineBilingual);
    if (selectedExternal) {
      externalSubFound = selectedExternal.path;
      externalChineseBilingualSource = pipelineBilingual && selectedExternal.language === "zh"
        && !detectedExternal.some((item) => item.language === "en" || item.language === "other");
    }
  if (externalSubFound && pipelineMode !== "whisper") {
      steps.push({ name: "外置字幕检测", status: "ok", message: `找到外置字幕：${path.basename(externalSubFound)}` });
      await addLog(jobId, "info", `找到外置字幕：${externalSubFound}`);
    } else {
      steps.push({ name: "外置字幕检测", status: "skip", message: "未找到外置字幕文件" });
      await addLog(jobId, "info", "未找到外置字幕");
    }
  } catch (e) {
    steps.push({ name: "外置字幕检测", status: "error", message: `检测失败：${String(e)}` });
    await addLog(jobId, "warn", `外置字幕检测失败：${String(e)}`);
  }

  // ── Step 2: Check embedded subtitles via ffprobe ─────────────────────────
  await addLog(jobId, "info", "【步骤2】检测内置字幕流（ffprobe）");
  let embeddedSubStreams: Array<{ index: number; codecName: string; language: string }> = [];
  if (!externalSubFound) {
    try {
      const ffprobeP = await ffprobeCmd();
      const probeResult = await new Promise<string>((resolve, reject) => {
        const probe = jobProcessController.spawnForJob(jobId, ffprobeP, [
          "-v", "quiet", "-print_format", "json",
          "-show_streams", "-select_streams", "s",
          videoPath,
        ]);
        let out = "";
        probe.stdout?.on("data", (d) => (out += d));
        probe.on("close", (code) => (code === 0 ? resolve(out) : reject(new Error(`ffprobe 退出码 ${code}`))));
        probe.on("error", reject);
      });
      const probeData = JSON.parse(probeResult) as {
        streams?: Array<{ index: number; codec_name: string; tags?: { language?: string } }>;
      };
      embeddedSubStreams = (probeData.streams ?? []).map(s => ({
        index: s.index,
        codecName: s.codec_name,
        language: s.tags?.language ?? "und",
      }));

      if (embeddedSubStreams.length > 0) {
        const info = embeddedSubStreams.map(s => `流${s.index}[${s.codecName}/${s.language}]`).join(", ");
        steps.push({ name: "内置字幕检测", status: "ok", message: `发现 ${embeddedSubStreams.length} 条字幕流：${info}` });
        await addLog(jobId, "info", `内置字幕：${info}`);
      } else {
        steps.push({ name: "内置字幕检测", status: "skip", message: "视频中无内置字幕流" });
        await addLog(jobId, "info", "无内置字幕");
      }
    } catch (e) {
      steps.push({ name: "内置字幕检测", status: "error", message: `ffprobe 不可用：${String(e)}` });
      await addLog(jobId, "warn", `ffprobe 失败：${String(e)}`);
    }
  } else {
    steps.push({ name: "内置字幕检测", status: "skip", message: "已有外置字幕，跳过内置检测" });
  }

  // ── Step 3a: Use external subtitle ──────────────────────────────────────
  if (externalSubFound) {
    subtitleSource = "external";
    const destExt = path.extname(externalSubFound);
    const destPath = path.join(subtitleDir, `${baseName}.original${destExt}`);
    try {
      await fs.copyFile(externalSubFound, destPath);
      rawSubtitlePath = destPath;
      steps.push({ name: "外置字幕复制", status: "ok", message: `已复制至 ${destPath}` });
      await addLog(jobId, "info", `外置字幕复制：${destPath}`);
    } catch (e) {
      // If copy fails, use in-place
      rawSubtitlePath = externalSubFound;
      steps.push({ name: "外置字幕复制", status: "ok", message: `使用原路径 ${externalSubFound}` });
    }
  }
  // ── Step 3b: Extract ALL embedded text subtitle streams ─────────────────
  else if (embeddedSubStreams.length > 0 && pipelineMode !== "whisper") {
    subtitleSource = "embedded";
    await addLog(jobId, "info", "【步骤3】提取内置字幕（ffmpeg）— 提取全部文字字幕轨");
    // Skip image-based subtitle formats (PGS/VOBSUB cannot be converted to SRT)
    const textSubs = embeddedSubStreams.filter(s => !isGraphicSubtitleCodec(s.codecName));
    const subsToExtract = textSubs.length > 0 ? textSubs : [];
    // Auto mode: if the container already has a Chinese subtitle track, no
    // extraction or translation is needed.
    let embeddedChineseSkipped = false;
    if (pipelineMode === "auto" && subsToExtract.length > 0) {
      let chineseIndex: number | null = null;
      for (const sub of subsToExtract) {
        if (languageTagIsChinese(sub.language)) {
          chineseIndex = sub.index;
          break;
        }
        const typeIndex = embeddedSubStreams.findIndex((s) => s.index === sub.index);
        const sample = await sampleEmbeddedSubtitleText(videoPath, typeIndex);
        if (textLooksChinese(sample)) {
          chineseIndex = sub.index;
          break;
        }
      }
      if (chineseIndex !== null) {
        embeddedChineseSkipped = true;
        steps.push({ name: "内置字幕检测", status: "skip", message: `视频已内置中文字幕（流 ${chineseIndex}），自动模式无需提取/翻译` });
        await addLog(jobId, "info", "检测到视频已内置中文字幕（自动模式），跳过字幕提取与翻译");
      }
    }
    if (embeddedChineseSkipped) {
      // No extraction / translation needed.
    } else if (subsToExtract.length === 0) {
      const graphicSubtitleCount = embeddedSubStreams.filter((stream) => isGraphicSubtitleCodec(stream.codecName)).length;
      const action = chooseEmbeddedSubtitleAction({
        mode: pipelineMode,
        textSubtitleCount: subsToExtract.length,
        graphicSubtitleCount,
      });
      if (action === "ocr") {
        steps.push({ name: "内置图形字幕 OCR", status: "ok", message: "正在对 PGS/VobSub 等图形字幕执行 OCR" });
        await addLog(jobId, "info", "检测到图形字幕，进入 OCR；OCR 失败时保留原图形字幕，不转入 Whisper");
        try {
          const ocrResult = await runSubtitleOcr({
            sourcePath: videoPath,
            config,
            engine: (job.ocrEngine ?? "auto") as OcrEngine,
            language: job.ocrLanguage ?? "auto",
            titleId: job.mainTrackPath ? null : job.selectedTitleId ?? null,
            outputBaseName: `${baseName}.ocr-${jobId}`,
            onProgress: (message) => addLog(jobId, "info", `OCR：${message}`),
          });
          const ocrPath = path.join(subtitleDir, `${baseName}.ocr.srt`);
          if (path.resolve(ocrResult.srtPath) !== path.resolve(ocrPath)) {
            await fs.copyFile(ocrResult.srtPath, ocrPath);
            await fs.unlink(ocrResult.srtPath).catch(() => {});
          }
          rawSubtitlePath = ocrPath;
          trackJobOutputFile(jobId, ocrPath);
          const step = steps[steps.length - 1];
          if (step) step.status = "ok";
          if (step) step.message = `OCR 完成：${ocrPath}`;
          await addLog(jobId, "info", `图形字幕 OCR 完成：${ocrPath}；原始 PGS/VobSub 仍保留在源视频中`);
        } catch (e) {
          const step = steps[steps.length - 1];
          if (step) step.status = "error";
          if (step) step.message = `OCR 失败，保留原图形字幕：${String(e)}`;
          await addLog(jobId, "warn", `图形字幕 OCR 失败，保留原图形字幕，不转入 Whisper：${String(e)}`);
        }
      } else {
        steps.push({ name: "内置字幕提取", status: "skip", message: "仅有图形字幕（PGS/VOBSUB），未选择 OCR；原图形字幕保留" });
        await addLog(jobId, "warn", "所有内置字幕为图形格式，当前模式未选择 OCR；原图形字幕保留");
      }
    } else {
      const extractedPaths: string[] = [];
      const ffmpegP = await ffmpegCmd();
      for (const sub of subsToExtract) {
        const lang = sub.language && sub.language !== "und" ? sub.language : `track${sub.index}`;
        const extractPath = path.join(subtitleDir, `${baseName}.${lang}.srt`);
        try {
          await new Promise<void>((resolve, reject) => {
            const ff = jobProcessController.spawnForJob(jobId, ffmpegP, [
              "-y", "-i", videoPath,
              "-map", `0:${sub.index}`,
              extractPath,
            ]);
            let errOut = "";
            ff.stderr?.on("data", (d) => { errOut = (errOut + String(d)).slice(-8192); });
            ff.on("close", (code) => (code === 0 ? resolve() : reject(new Error(`ffmpeg 退出码 ${code}: ${errOut.slice(-200)}`))));
            ff.on("error", reject);
          });
          const extractedText = await fs.readFile(extractPath, "utf8").catch(() => "");
          if (!hasValidSubtitleCues(extractedText)) throw new Error("输出没有有效字幕 cue");
          extractedPaths.push(extractPath);
          await addLog(jobId, "info", `字幕轨 [${lang}] 提取完成：${extractPath}`);
        } catch (e) {
          await addLog(jobId, "warn", `字幕轨 [${lang}] 提取失败：${String(e)}`);
        }
      }
      if (extractedPaths.length > 0) {
        // Primary = the fullest extracted track (forced/partial tracks first in
        // the container would otherwise produce an incomplete primary).
        let primaryPath = extractedPaths[0];
        let primaryCues = 0;
        for (const candidate of extractedPaths) {
          let cueCount = 0;
          try {
            const content = await fs.readFile(candidate, "utf8");
            cueCount = (content.match(/-->/g) ?? []).length;
          } catch {
            cueCount = 0;
          }
          if (cueCount > primaryCues) {
            primaryCues = cueCount;
            primaryPath = candidate;
          }
        }
        rawSubtitlePath = primaryPath;
        steps.push({ name: "内置字幕提取", status: "ok", message: `提取 ${extractedPaths.length} 条字幕，主字幕选条数最多轨（${path.basename(primaryPath)}，${primaryCues} 条）：${extractedPaths.map(p => path.basename(p)).join(", ")}` });
        await addLog(jobId, "info", `内置字幕提取完成，共 ${extractedPaths.length} 条，主字幕：${path.basename(primaryPath)}（${primaryCues} 条）`);
      } else {
        steps.push({ name: "内置字幕提取", status: "error", message: "所有字幕轨提取失败" });
      }
    }
  }
  // ── Step 3c: Whisper ASR ─────────────────────────────────────────────────
  else if (pipelineMode === "extract" || pipelineMode === "transcribe_translate") {
    subtitleSource = "none";
    steps.push({ name: "Whisper 语音识别", status: "skip", message: "本模式不进行语音识别" });
    await addLog(jobId, "info", "本模式不进行语音识别");
  }
  else {
    subtitleSource = "whisper";
    await addLog(jobId, "info", "【步骤3】无字幕 — 提取音轨进行 Whisper 语音识别");

    // Extract audio first (16kHz mono WAV works best for Whisper)
    const audioPath = path.join(outputDir, `${baseName}.audio.wav`);
    let audioExtracted = false;
    try {
      const ffmpegP2 = await ffmpegCmd();
      await new Promise<void>((resolve, reject) => {
        const ff = jobProcessController.spawnForJob(jobId, ffmpegP2, [
          "-y", "-i", videoPath,
          "-vn", "-acodec", "pcm_s16le",
          "-ar", "16000", "-ac", "1",
          audioPath,
        ]);
        let errOut = "";
        ff.stderr?.on("data", (d) => { errOut = (errOut + String(d)).slice(-8192); });
        ff.on("close", (code) => (code === 0 ? resolve() : reject(new Error(`ffmpeg 退出码 ${code}: ${errOut.slice(-200)}`))));
        ff.on("error", reject);
      });
      audioExtracted = true;
      steps.push({ name: "音轨提取", status: "ok", message: `已提取音频（16kHz mono WAV）：${audioPath}` });
      await addLog(jobId, "info", `音轨提取完成：${audioPath}`);
    } catch (e) {
      steps.push({ name: "音轨提取", status: "error", message: `音轨提取失败：${String(e)}` });
      await addLog(jobId, "error", `音轨提取失败：${String(e)}`);
    }

    if (audioExtracted) {
      await addLog(jobId, `info`, `Whisper 语音识别中（模型：${config.whisperModel}，语言：${config.subtitleLanguage || "自动"}）`);
      const srtPath = path.join(subtitleDir, `${baseName}.original.srt`);
      try {
        const whisperExecutable = await resolveToolPath("whisper");
        if (!whisperExecutable) throw new Error("Whisper 未安装或不可执行。请先在工具管理器安装 Whisper 环境和模型。");
        await addLog(jobId, "info", `Whisper 可执行文件：${whisperExecutable}`);
        await new Promise<void>((resolve, reject) => {
          // Do NOT pass --language — let Whisper auto-detect the audio language.
          // Forcing --language zh on non-Chinese audio produces garbled output.
          const whisperArgs = [
            audioPath,
            "--model", config.whisperModel,
            "--output_format", "srt",
              "--output_dir", subtitleDir,
              ...(config.subtitleLanguage && config.subtitleLanguage !== "auto" ? ["--language", config.subtitleLanguage] : []),
            "--task", "transcribe",
          ];
          const whisper = jobProcessController.spawnForJob(jobId, whisperExecutable, whisperArgs);
          let errOut = "";
          whisper.stderr?.on("data", (d) => { errOut = (errOut + String(d)).slice(-8192); });
          whisper.on("close", (code) => (code === 0 ? resolve() : reject(new Error(`whisper 退出码 ${code}: ${errOut.slice(-300)}`))));
          whisper.on("error", reject);
        });
        // Whisper names output as <audio_basename>.srt
        const whisperOut = path.join(subtitleDir, `${path.basename(audioPath, ".wav")}.srt`);
        // Rename to standard path
        try {
          await fs.rename(whisperOut, srtPath);
        } catch {
          // May already be at the right path
        }
        rawSubtitlePath = srtPath;
        steps.push({ name: "Whisper 语音识别", status: "ok", message: `转录完成：${srtPath}` });
        await addLog(jobId, "info", `Whisper 转录完成：${srtPath}`);
        // Clean up audio file
        await fs.unlink(audioPath).catch(() => {});
      } catch (e) {
        steps.push({ name: "Whisper 语音识别", status: "error", message: `转录失败：${String(e)}` });
        await addLog(jobId, "error", `Whisper 失败：${String(e)}`);
      }
    }
  }

  // ── Step 4: AI Translation ────────────────────────────────────────────────
  let translatedSubtitlePath: string | null = null;

  if (!rawSubtitlePath) {
    steps.push({ name: "AI 智能翻译", status: "skip", message: "无可用字幕源，跳过翻译" });
    await addLog(jobId, "warn", "无可用字幕，跳过 AI 翻译");
  } else if (externalChineseBilingualSource) {
    steps.push({ name: "AI 智能翻译", status: "skip", message: "双语任务仅发现中文字幕，跳过重复翻译" });
    await addLog(jobId, "info", "双语任务仅发现同名中文字幕，跳过 AI 翻译，避免生成两行中文");
  } else if (!config.aiTranslationEnabled && !automaticAiEnabled) {
    steps.push({ name: "AI 智能翻译", status: "skip", message: "AI 翻译未启用（在设置中开启）" });
    await addLog(jobId, "info", "AI 翻译未启用");
  } else if (config.aiProvider === "libretranslate") {
    // ── LibreTranslate (offline, no API key) ──────────────────────────────
    const ltUrl = config.libreTranslateUrl || "http://libretranslate:5000";
    await addLog(jobId, "info", `【步骤4】本地离线翻译（LibreTranslate @ ${ltUrl}）→ ${config.translationTargetLang}`);

    try {
      let srtContent = await fs.readFile(rawSubtitlePath, "utf-8");
      srtContent = srtContent.replace(/\r\n/g, "\n");
      const blocks = parseSrt(srtContent);

      if (blocks.length === 0) {
        steps.push({ name: "本地离线翻译", status: "error", message: "无法解析字幕文件（格式异常）" });
        await addLog(jobId, "error", "字幕解析失败");
      } else {
        await addLog(jobId, "info", `共 ${blocks.length} 条字幕，开始离线翻译（每次 1 条）`);

        // Detect source language — LibreTranslate needs explicit source lang
        const srcLang = "en"; // most subtitles are English; auto-detect would require extra API call
        const tgtLang = config.translationTargetLang.split("-")[0]; // zh-CN → zh

        const BATCH_SIZE = 20;
        const translatedBlocks: SrtBlock[] = [];

        for (let i = 0; i < blocks.length; i += BATCH_SIZE) {
          const batch = blocks.slice(i, i + BATCH_SIZE);
          const pct = Math.round((i / blocks.length) * 100);
          await addLog(jobId, "info", `翻译进度 ${pct}%（${i + 1}–${Math.min(i + BATCH_SIZE, blocks.length)} / ${blocks.length}）`);

          const texts = batch.map(b => b.text);
          const translated = await translateBatchLibre(texts, srcLang, tgtLang, ltUrl);

          for (let j = 0; j < batch.length; j++) {
            translatedBlocks.push({ ...batch[j], text: translated[j] || batch[j].text });
          }
        }

        const translatedSrt = renderSrtSimplified(translatedBlocks, config.translationTargetLang.startsWith("zh-CN"));
                const translatedPath = path.join(subtitleDir, `${baseName}.zhs.srt`);
        trackJobOutputFile(jobId, translatedPath);
        await fs.writeFile(translatedPath, translatedSrt, "utf-8");
        translatedSubtitlePath = translatedPath;

        steps.push({ name: "本地离线翻译", status: "ok", message: `翻译完成（${blocks.length} 条） → ${translatedPath}` });
        await addLog(jobId, "info", `本地翻译完成：${translatedPath}`);
      }
    } catch (e) {
      steps.push({ name: "本地离线翻译", status: "error", message: `翻译失败：${String(e)}` });
      await addLog(jobId, "error", `本地翻译失败：${String(e)}`);
    }
  } else {
    const apiKey = resolveApiKey(config) || process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
    const { baseUrl, model, label: providerLabel } = resolveAiEndpoint(config);

    if (!apiKey) {
      steps.push({ name: "AI 智能翻译", status: "error", message: "未配置 API Key（在设置中填写）" });
      await addLog(jobId, "warn", "AI API Key 未配置，跳过翻译");
    } else {
      await addLog(jobId, "info", `【步骤4】AI 智能翻译（${providerLabel} / ${model}）→ ${config.translationTargetLang}`);
      await addLog(jobId, "info", "正在获取影片上下文（演员表、维基百科、TMDb 双语数据）…");

      try {
        let srtContent = await fs.readFile(rawSubtitlePath, "utf-8");
        srtContent = srtContent.replace(/\r\n/g, "\n");

        const blocks = parseSrt(srtContent);
        if (blocks.length === 0) {
          steps.push({ name: "AI 智能翻译", status: "error", message: "无法解析字幕文件（格式异常）" });
          await addLog(jobId, "error", "字幕解析失败");
        } else {
          await addLog(jobId, "info", `共 ${blocks.length} 条字幕，开始构建翻译上下文`);

          const systemPrompt = await buildTranslationPrompt(job, config, config.translationTargetLang, null);

          await addLog(jobId, "info", "上下文构建完毕，开始分批翻译（每批 50 条）");

          const BATCH_SIZE = 50;
          const translatedBlocks: SrtBlock[] = [];

          for (let i = 0; i < blocks.length; i += BATCH_SIZE) {
            const batch = blocks.slice(i, i + BATCH_SIZE);
            const pct = Math.round((i / blocks.length) * 100);
            await addLog(jobId, "info", `翻译进度 ${pct}%（${i + 1}–${Math.min(i + BATCH_SIZE, blocks.length)} / ${blocks.length}）`);

            const texts = batch.map(b => b.text);
            const translated = await translateBatch(texts, systemPrompt, apiKey, baseUrl, model);

            for (let j = 0; j < batch.length; j++) {
              translatedBlocks.push({
                ...batch[j],
                text: translated[j] || batch[j].text,
              });
            }
          }

          const translatedSrt = renderSrtSimplified(translatedBlocks, config.translationTargetLang.startsWith("zh-CN"));
                    const translatedPath = path.join(subtitleDir, `${baseName}.zhs.srt`);
          trackJobOutputFile(jobId, translatedPath);
          await fs.writeFile(translatedPath, translatedSrt, "utf-8");
          translatedSubtitlePath = translatedPath;

          steps.push({ name: "AI 智能翻译", status: "ok", message: `翻译完成（${blocks.length} 条） → ${translatedPath}` });
          await addLog(jobId, "info", `AI 翻译完成：${translatedPath}`);
        }
      } catch (e) {
        steps.push({ name: "AI 智能翻译", status: "error", message: `翻译失败：${String(e)}` });
        await addLog(jobId, "error", `AI 翻译失败：${String(e)}`);
      }
    }
  }

  // ── Save results to DB ────────────────────────────────────────────────────
  await db.update(jobsTable).set({
    subtitleSource,
    subtitlePath: rawSubtitlePath ?? job.subtitlePath,
    translatedSubtitlePath,
    subtitlePipelineStatus: "done",
    hasEmbeddedSubtitles: embeddedSubStreams.length > 0,
  }).where(eq(jobsTable.id, jobId));

  await addLog(jobId, "info", "─── 字幕流水线完成 ───");

  return { subtitleSource, rawSubtitlePath, translatedSubtitlePath, steps };
}
