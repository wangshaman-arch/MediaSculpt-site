// Extracted from routes/jobs.ts: subtitle translation backends (LibreTranslate / LLM).
import { Router, type Response } from "express";
import { requestJsonLike } from "../lib/http-client";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { lookupAll, metadataIdentityMatches, normalizeTitleEn } from "../lib/metadata";
import { servePreviewSegment, cleanupPreviewSegments } from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import { buildFfconcatFileContent as buildManifest, buildFfconcatChapterContent, buildFfconcatTimedContent, type FfconcatTimedSegment } from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import { appendJobRuntimeLog, appendJobToolOutput } from "../lib/job-runtime-log";
import { appendRuntimeToolLog, appendRuntimeToolOutput } from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import { buildCompressionOutputName, buildRemuxOutputName, cleanSegment, encoderBitDepth, selectBestAudioTrack } from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import { renderBilingualAss, DEFAULT_BILINGUAL_STYLE, type BilingualAssStyle, type SubtitleBlock } from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import { ensureLocalPoster, MEDIA_INFO_DIR, POSTER_META_FILE, posterIdentityMatches } from "../lib/poster";
import { ensureFasterWhisperModel, ensureWhisperCliScript } from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import { assertUsableTranslatedTexts, hasValidSubtitleCues, isGraphicSubtitleCodec, shouldFallbackToWhisper } from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import { buildDvdRemuxArgs, runDvdRemux, verifyDvdTitle } from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import { buildDvdStructurePayload, resolveRemuxPlanWithLlm, validateRemuxPlan } from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import { assertPreviewTaskAllowed, recordPreviewAiCall, settlePreviewTask } from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import { parseCustomTuning, resolveLogicPlaceholders } from "../lib/custom-tuning";
import { decryptSecret, encryptSecret, isEncryptedSecret } from "../lib/secrets";
import { ffmpegPath, resolveOutputDir, resolveRuntimePath, type RuntimePathConfig } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import { assertCompleteMediaTitle, createDvdMediaTitle } from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import { buildPreviewTranscodeArgs, isPreviewVideoCandidate, previewService } from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";

/** Translate a batch of subtitle texts using LibreTranslate (offline, no API key) */
export async function translateBatchLibre(
  texts: string[],
  sourceLanguage: string,
  targetLanguage: string,
  baseUrl: string
): Promise<string[]> {
  const results: string[] = [];
  // LibreTranslate: translate one by one to preserve formatting
  for (const text of texts) {
    const resp = await fetch(`${baseUrl}/translate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ q: text, source: sourceLanguage, target: targetLanguage, format: "text" }),
    });
    if (!resp.ok) {
      const err = await resp.text();
      throw new Error(`LibreTranslate 错误 ${resp.status}: ${err}`);
    }
    const data = await resp.json() as { translatedText: string };
    results.push(data.translatedText ?? text);
  }
  assertUsableTranslatedTexts(results);
  return results;
}

type TranslateBatchResult = { results: string[]; truncated: boolean };

async function translateBatchOnce(
  texts: string[],
  systemPrompt: string,
  apiKey: string,
  baseUrl: string,
  model: string,
  proxyUrl: string | null = null,
): Promise<TranslateBatchResult> {
  const numbered = texts.map((t, i) => `[${i + 1}] ${t}`).join("\n---\n");
  const userMsg = `请翻译以下字幕条目，保持原有换行、HTML标签（如<i>）和格式。每条用 [编号] 开头，顺序与输入一致，不要添加任何额外解释。

${numbered}`;
  const resp = await requestJsonLike(`${baseUrl.replace(/\/$/, "")}/chat/completions`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model,
      temperature: 0.3,
      max_tokens: 4096,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userMsg },
      ],
    }),
  }, proxyUrl, 120_000);
  void recordPreviewAiCall("subtitle-translation").catch(() => {});
  if (!resp) {
    throw new Error(`无法连接 AI 服务（${baseUrl}）；请检查 API Key、网络或 HTTP 代理设置${proxyUrl ? `（当前代理 ${proxyUrl}）` : ""}`);
  }
  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`AI API 错误 ${resp.status}: ${err}`);
  }
  const data = await resp.json() as { choices: Array<{ message: { content: string }; finish_reason?: string }> };
  const finishReason = data.choices[0]?.finish_reason;
  const raw = data.choices[0]?.message?.content ?? "";
  const results: string[] = new Array(texts.length).fill("");
  const regex = /\[(\d+)\]\s*([\s\S]*?)(?=\n\[(\d+)\]|\n---|\s*$)/g;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(raw)) !== null) {
    const idx = parseInt(match[1], 10) - 1;
    if (idx >= 0 && idx < texts.length) {
      results[idx] = match[2].trim();
    }
  }
  assertUsableTranslatedTexts(results);
  const missing = results.some((value, index) => !value && Boolean(texts[index]));
  const truncated = finishReason === "length" || missing;
  return { results, truncated };
}

/** Translate a batch of subtitle texts, automatically splitting when the model truncates. */
export async function translateBatch(
  texts: string[],
  systemPrompt: string,
  apiKey: string,
  baseUrl: string,
  model: string,
  proxyUrl: string | null = null,
): Promise<string[]> {
  if (texts.length === 0) return [];
  const first = await translateBatchOnce(texts, systemPrompt, apiKey, baseUrl, model, proxyUrl);
  if (!first.truncated) {
    return first.results.map((value, index) => value || texts[index]);
  }
  if (texts.length <= 1) {
    return first.results.map((value, index) => value || texts[index]);
  }
  const half = Math.ceil(texts.length / 2);
  const left = await translateBatch(texts.slice(0, half), systemPrompt, apiKey, baseUrl, model, proxyUrl);
  const right = await translateBatch(texts.slice(half), systemPrompt, apiKey, baseUrl, model, proxyUrl);
  return [...left, ...right];
}
