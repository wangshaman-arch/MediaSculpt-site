// Extracted from routes/jobs.ts: chapter-preview job execution.
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { lookupAll, metadataIdentityMatches, normalizeTitleEn } from "../lib/metadata";
import { servePreviewSegment, cleanupPreviewSegments } from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import { buildFfconcatFileContent as buildManifest, buildFfconcatChapterContent, buildFfconcatTimedContent, type FfconcatTimedSegment } from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import { appendJobRuntimeLog, appendJobToolOutput } from "../lib/job-runtime-log";
import { appendRuntimeToolLog, appendRuntimeToolOutput } from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import { buildCompressionOutputName, buildRemuxOutputName, cleanSegment, encoderBitDepth, selectBestAudioTrack } from "../lib/output-naming";
import { dvdOutputBaseName } from "../lib/dvd-source-identity";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import { renderBilingualAss, DEFAULT_BILINGUAL_STYLE, type BilingualAssStyle, type SubtitleBlock } from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import { ensureLocalPoster, MEDIA_INFO_DIR, POSTER_META_FILE, posterIdentityMatches } from "../lib/poster";
import { ensureFasterWhisperModel, ensureWhisperCliScript } from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import { hasValidSubtitleCues, isGraphicSubtitleCodec, shouldFallbackToWhisper } from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import { buildDvdRemuxArgs, runDvdRemux, verifyDvdTitle } from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import { buildDvdStructurePayload, resolveRemuxPlanWithLlm, validateRemuxPlan } from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import { assertPreviewTaskAllowed, recordPreviewAiCall, settlePreviewTask } from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import { parseCustomTuning, resolveLogicPlaceholders } from "../lib/custom-tuning";
import { decryptSecret, encryptSecret, isEncryptedSecret } from "../lib/secrets";
import { ffmpegPath, resolveOutputDir, resolveRuntimePath, type RuntimePathConfig } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import { assertCompleteMediaTitle, createDvdMediaTitle } from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import { buildPreviewTranscodeArgs, isPreviewVideoCandidate, previewService } from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";
import {
  addLog,
  probeStreams,
  snapshotTitleIndex,
  outputDirectoryForTask,
  ensureDirectory,
  trackJobOutputFile,
  runFfmpegCapture,
  cancelledJobs,
} from "./jobs";

// ── 章节预览（Chapter Preview）──────────────────────────────────────────────
// 独立处理模式：读取章节列表，每章取一段（默认中间 5 秒），用 FFmpeg 拼接成
// 一个预览 mkv。视频文件直接读容器章节；蓝光走 mpls 章节 + m2ts 分段；
// DVD 优先使用任务创建时持久化的分析章节（selectionPlan.chapterTimes）。
const CHAPTER_PREVIEW_SAMPLE_SECONDS = 5;
type ChapterSamplePosition = "middle" | "start" | "end";

/**
 * 视频没有章节时的退化方案：把总时长均分成最多 8 段“伪章节”，
 * 复用章节采样逻辑生成分段预览（每段默认取中间 5 秒），
 * 让无章节视频也能通过章节预览入口获得全片各位置的预览。
 */
function buildFallbackSegments(durationSeconds: number, maxSegments = 8): Array<{ startSeconds: number; endSeconds: number }> {
  const count = Math.max(1, Math.min(maxSegments, Math.floor(durationSeconds / 30)));
  const step = durationSeconds / count;
  const segments: Array<{ startSeconds: number; endSeconds: number }> = [];
  for (let index = 0; index < count; index += 1) {
    segments.push({
      startSeconds: Math.round(index * step * 1000) / 1000,
      endSeconds: Math.round(Math.min(durationSeconds, (index + 1) * step) * 1000) / 1000,
    });
  }
  return segments;
}

type ChapterClipSource = {
  startSeconds: number;
  endSeconds: number;
  title?: string | null;
  /** 单个章节的采样位置覆盖（用于片尾/演员表章节前移到开头）。 */
  samplePosition?: ChapterSamplePosition;
};

function sampleChapterClips(
  chapters: ChapterClipSource[],
  position: ChapterSamplePosition,
  sampleSeconds = CHAPTER_PREVIEW_SAMPLE_SECONDS,
): Array<{ startSeconds: number; endSeconds: number }> {
  const clips: Array<{ startSeconds: number; endSeconds: number }> = [];
  for (const chapter of chapters) {
    const duration = chapter.endSeconds - chapter.startSeconds;
    if (!Number.isFinite(duration) || duration <= 0) continue;
    if (duration <= sampleSeconds) {
      clips.push({ startSeconds: chapter.startSeconds, endSeconds: chapter.endSeconds });
      continue;
    }
    const pos = chapter.samplePosition ?? position;
    let start: number;
    let end: number;
    if (pos === "start") {
      start = chapter.startSeconds;
      end = chapter.startSeconds + sampleSeconds;
    } else if (pos === "end") {
      end = chapter.endSeconds;
      start = chapter.endSeconds - sampleSeconds;
    } else {
      const mid = (chapter.startSeconds + chapter.endSeconds) / 2;
      start = mid - sampleSeconds / 2;
      end = mid + sampleSeconds / 2;
      if (start < chapter.startSeconds) {
        start = chapter.startSeconds;
        end = start + sampleSeconds;
      }
      if (end > chapter.endSeconds) {
        end = chapter.endSeconds;
        start = end - sampleSeconds;
      }
    }
    clips.push({
      startSeconds: Math.max(chapter.startSeconds, Math.min(start, end)),
      endSeconds: Math.min(chapter.endSeconds, Math.max(start, end)),
    });
  }
  return clips;
}

/** DVD 标题无法走 concat demuxer（需要 -f dvdvideo -title），改用 trim/concat 滤镜。 */
function buildDvdChapterPreviewFilter(
  clips: Array<{ startSeconds: number; endSeconds: number }>,
  hasAudio: boolean,
): { filter: string; maps: string[] } {
  const videoLabels: string[] = [];
  const audioLabels: string[] = [];
  const parts: string[] = [];
  clips.forEach((clip, index) => {
    const start = clip.startSeconds.toFixed(3);
    const end = clip.endSeconds.toFixed(3);
    const videoLabel = `v${index}`;
    parts.push(`[0:v]trim=start=${start}:end=${end},setpts=PTS-STARTPTS[${videoLabel}]`);
    videoLabels.push(`[${videoLabel}]`);
    if (hasAudio) {
      const audioLabel = `a${index}`;
      parts.push(`[0:a]atrim=start=${start}:end=${end},asetpts=PTS-STARTPTS[${audioLabel}]`);
      audioLabels.push(`[${audioLabel}]`);
    }
  });
  const concatIn = [...videoLabels, ...audioLabels].join("");
  if (hasAudio) {
    parts.push(`${concatIn}concat=n=${clips.length}:v=1:a=1[vout][aout]`);
    return { filter: parts.join(";"), maps: ["-map", "[vout]", "-map", "[aout]"] };
  }
  parts.push(`${concatIn}concat=n=${clips.length}:v=1:a=0[vout]`);
  return { filter: parts.join(";"), maps: ["-map", "[vout]"] };
}

export async function processChapterPreviewJob(
  jobId: number,
  job: typeof jobsTable.$inferSelect & { filePath: string; mainTrackPath: string | null },
  config: typeof configTable.$inferSelect,
): Promise<void> {
  if (job.mediaType === "iso") {
    throw new Error("章节预览暂不支持 ISO 镜像，请选择视频文件、DVD 或蓝光目录");
  }

  await db.update(jobsTable).set({ status: "scanning", startedAt: new Date(), progress: 0 }).where(eq(jobsTable.id, jobId));
  await addLog(jobId, "info", "章节预览任务开始 — 正在读取章节信息");

  const mediaInputPath = job.mainTrackPath || job.filePath;
  const selectionPlan = (() => {
    try { return job.selectionPlan ? JSON.parse(job.selectionPlan) as Record<string, unknown> : {}; } catch { return {}; }
  })();
  const samplePosition: ChapterSamplePosition =
    selectionPlan.chapterSamplePosition === "start" || selectionPlan.chapterSamplePosition === "end"
      ? selectionPlan.chapterSamplePosition
      : "middle";

  /** DVD 章节预览必须用已验证的 dvdvideo 全局标题号（HandBrake 编号），
   *  而不是 resolveDvdTitleForSource 的 VTS 序号——后者会选错标题，
   *  采样时间段没有画面，FFmpeg 输出空文件却仍以 0 退出。 */
  const taskSnapshotForPreview = loadTaskSnapshot(job);
  const resolveDvdPreviewTitle = async (): Promise<DvdTitle | null> => {
    let title = await resolveDvdTitleForSource(mediaInputPath).catch(() => null);
    if (!title) title = await resolveDvdTitleForIfo(mediaInputPath).catch(() => null);
    if (!title) return null;
    const verifiedNumber = taskSnapshotForPreview?.toolSelections?.dvdVtsNumber
      ?? taskSnapshotForPreview?.toolSelections?.handbrakeTitleNumber;
    if (typeof verifiedNumber === "number" && verifiedNumber > 0 && verifiedNumber !== title.titleNumber) {
      await addLog(jobId, "info", `章节预览：使用已验证的 dvdvideo 标题 ${verifiedNumber}（替换 VTS 序号 ${title.titleNumber}）`);
      return { ...title, titleNumber: verifiedNumber };
    }
    return title;
  };

  // 优先使用任务创建时持久化的分析章节（绝对播放时间，DVD/蓝光可靠）。
  const planChapters = Array.isArray(selectionPlan.chapterTimes)
    ? (selectionPlan.chapterTimes as Array<{ startSeconds?: number; endSeconds?: number }>)
        .filter((chapter) => Number.isFinite(chapter.startSeconds) && Number.isFinite(chapter.endSeconds))
        .map((chapter) => ({ startSeconds: Number(chapter.startSeconds), endSeconds: Number(chapter.endSeconds) }))
    : [];

  let rawChapters: Array<{ startSeconds: number; endSeconds: number; title?: string | null }>;
  let inputKind: "concat" | "dvd-filter" = "concat";
  let dvdTitle: DvdTitle | null = null;
  let sourceDescription = "";

  if (job.mediaType === "bluray") {
    if (planChapters.length > 0) {
      rawChapters = planChapters;
      sourceDescription = `蓝光（分析章节 ${planChapters.length} 章）`;
    } else {
      const taskSnapshot = loadTaskSnapshot(job);
      const discRoot = job.filePath;
      let mplsPath: string | null = null;
      const playlistId = taskSnapshot?.toolSelections?.playlistId
        ?? (/^mpls:(\d+)$/.exec(String(taskSnapshot?.selectedTitleId ?? ""))?.[1] ?? null);
      if (playlistId) {
        const candidate = path.join(discRoot, "BDMV", "PLAYLIST", playlistId + ".mpls");
        if (fsSync.existsSync(candidate)) mplsPath = candidate;
      }
      if (!mplsPath) {
        const playlists = await scanBlurayPlaylists(discRoot);
        mplsPath = playlists.sort((a, b) => (b.durationSeconds ?? 0) - (a.durationSeconds ?? 0))[0]?.mplsPath ?? null;
      }
      if (!mplsPath) throw new Error("未找到蓝光播放列表（.mpls），无法读取章节");
      const chapters = await parseBlurayChapters(mplsPath, discRoot);
      if (chapters.length === 0) throw new Error("该蓝光标题未检测到章节，无法生成章节预览");
      rawChapters = chapters;
      sourceDescription = `蓝光 ${path.basename(mplsPath)}（${chapters.length} 章）`;
    }
  } else if (job.mediaType === "dvd") {
    if (planChapters.length > 0) {
      rawChapters = planChapters;
      inputKind = "dvd-filter";
      dvdTitle = await resolveDvdPreviewTitle();
      sourceDescription = `DVD（分析章节 ${planChapters.length} 章）`;
    } else {
      // 旧任务没有持久化章节：尝试实时探测 IFO。
      const probe = await probeStreams(mediaInputPath);
      if (!probe.chapters || probe.chapters.length === 0) {
        throw new Error("该 DVD 任务未包含章节信息（旧任务未持久化章节），请重新分析后创建任务");
      }
      rawChapters = probe.chapters;
      inputKind = "dvd-filter";
      dvdTitle = await resolveDvdPreviewTitle();
      sourceDescription = `DVD（实时探测 ${rawChapters.length} 章）`;
    }
  } else {
    const probe = await probeStreams(mediaInputPath);
    rawChapters = probe.chapters ?? [];
    if (rawChapters.length === 0) {
      // 无章节：按时长均分做“分段预览”，避免预览功能对无章节视频直接失败。
      const duration = Number(probe.duration ?? 0);
      if (!Number.isFinite(duration) || duration <= 0) {
        throw new Error("源文件未检测到章节且无法获取时长，无法生成预览");
      }
      rawChapters = buildFallbackSegments(duration);
      sourceDescription = `视频（无章节，已按时间均分 ${rawChapters.length} 段预览）`;
    } else {
      sourceDescription = `视频（${rawChapters.length} 章）`;
    }
  }

  // 片尾/演员表章节的中间或结尾采样常落在滚动名单上，把这类章节的采样点
  // 前移到开头（用户已显式选“开头”时保持原样）。
  const CREDIT_CHAPTER_PATTERN = /credit|end(ing)?\s*credits?|roll|cast|演职员|片尾|制作名单|字幕滚动/i;
  const taggedChapters: ChapterClipSource[] = rawChapters.map((chapter, index) => {
    const title = typeof chapter.title === "string" && chapter.title.trim() ? chapter.title : null;
    const isLastChapter = index === rawChapters.length - 1 && rawChapters.length >= 4;
    const looksLikeCredits = Boolean(title && CREDIT_CHAPTER_PATTERN.test(title)) || isLastChapter;
    if (looksLikeCredits && samplePosition !== "start") {
      return { ...chapter, title, samplePosition: "start" as const };
    }
    return { ...chapter, title };
  });
  const creditShiftedCount = taggedChapters.filter((chapter) => chapter.samplePosition === "start" && samplePosition !== "start").length;
  if (creditShiftedCount > 0) {
    await addLog(jobId, "info", `检测到 ${creditShiftedCount} 个疑似片尾/演员表章节，采样点已前移到章节开头`);
  }
  const clips = sampleChapterClips(taggedChapters, samplePosition);
  if (clips.length === 0) throw new Error("章节切片结果为空，无法生成预览");
  const expectedDuration = clips.reduce((sum, clip) => sum + Math.max(0, clip.endSeconds - clip.startSeconds), 0);
  const positionLabel = samplePosition === "start" ? "开头" : samplePosition === "end" ? "结尾" : "中间";
  await addLog(jobId, "info", `章节采样：${sourceDescription}，每章 ${CHAPTER_PREVIEW_SAMPLE_SECONDS} 秒（${positionLabel}），共 ${clips.length} 个片段，预计 ${expectedDuration.toFixed(1)} 秒`);

  // 输出命名：规范化基名[.TitleXX].ChapterPreview.mkv；DVD 单标题不暴露内部编号。
  const baseName = path.basename(job.filePath, path.extname(job.filePath));
  const outputBaseName = job.mediaType === "dvd"
    ? dvdOutputBaseName({ sourcePath: job.filePath, mediaType: "dvd" })
    : (/^(VIDEO_TS|BDMV)$/i.test(baseName)
      ? path.basename(path.dirname(job.filePath))
      : baseName);
  const titleIndex = snapshotTitleIndex(loadTaskSnapshot(job));
  const titleSuffix = job.mediaType === "dvd" ? "" : (titleIndex >= 0 ? `.Title${String(titleIndex + 1).padStart(2, "0")}` : "");
  const outputDir = outputDirectoryForTask(config, job);
  await ensureDirectory(outputDir);
  const outputFile = path.join(outputDir, `${cleanSegment(`${outputBaseName}${titleSuffix}`)}.ChapterPreview.mkv`);
  trackJobOutputFile(jobId, outputFile);
  await addLog(jobId, "info", `章节预览输出路径：${outputFile}`);

  const ffmpegExecutable = (await resolveToolPath("ffmpeg").catch(() => null)) ?? "ffmpeg";
  await db.update(jobsTable).set({ status: "compressing" }).where(eq(jobsTable.id, jobId));
  try {
    if (inputKind === "dvd-filter") {
      if (!dvdTitle) throw new Error("无法定位 DVD 标题输入（IFO）");
      const dvdInputArgs = dvdTitleInputArgs(dvdTitle);
      const probe = await probeStreams(mediaInputPath).catch(() => null);
      const hasAudio = Boolean(probe?.streams?.some((stream) => stream.codecType === "audio"));
      const { filter, maps } = buildDvdChapterPreviewFilter(clips, hasAudio);
      const args = [
        ...dvdInputArgs,
        "-filter_complex", filter,
        ...maps,
        "-sn",
        "-c:v", "libx264", "-preset", "medium", "-crf", "23", "-pix_fmt", "yuv420p",
        ...(hasAudio ? ["-c:a", "aac", "-b:a", "192k"] : ["-an"]),
        "-y", ffmpegPath(outputFile),
      ];
      await runFfmpegCapture(jobId, args, expectedDuration);
    } else {
      let timedSegments: FfconcatTimedSegment[];
      if (job.mediaType === "bluray") {
        // 蓝光章节可能跨多个 m2ts 片段，映射为各片段的 in/out 时间点。
        const taskSnapshot = loadTaskSnapshot(job);
        const discRoot = job.filePath;
        let mplsPath: string | null = null;
        const playlistId = taskSnapshot?.toolSelections?.playlistId
          ?? (/^mpls:(\d+)$/.exec(String(taskSnapshot?.selectedTitleId ?? ""))?.[1] ?? null);
        if (playlistId) {
          const candidate = path.join(discRoot, "BDMV", "PLAYLIST", playlistId + ".mpls");
          if (fsSync.existsSync(candidate)) mplsPath = candidate;
        }
        if (!mplsPath) {
          const playlists = await scanBlurayPlaylists(discRoot);
          mplsPath = playlists.sort((a, b) => (b.durationSeconds ?? 0) - (a.durationSeconds ?? 0))[0]?.mplsPath ?? null;
        }
        if (!mplsPath) throw new Error("未找到蓝光播放列表（.mpls）");
        const segments = await parseBlurayMpls(mplsPath, discRoot);
        timedSegments = mapBlurayChaptersToSegments(segments, clips);
      } else {
        timedSegments = clips.map((clip) => ({
          file: mediaInputPath,
          startSeconds: clip.startSeconds,
          endSeconds: clip.endSeconds,
        }));
      }
      if (timedSegments.length === 0) throw new Error("蓝光章节映射为空，无法生成预览");
      const concatDir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-chapter-preview-"));
      const concatFile = path.join(concatDir, "concat.txt");
      try {
        await fs.writeFile(concatFile, buildFfconcatTimedContent(timedSegments), "utf8");
        const args = [
          "-f", "concat", "-safe", "0", "-i", ffmpegPath(concatFile),
          "-map", "0:v:0", "-map", "0:a:0?", "-sn",
          "-c:v", "libx264", "-preset", "medium", "-crf", "23", "-pix_fmt", "yuv420p",
          "-c:a", "aac", "-b:a", "192k",
          "-y", ffmpegPath(outputFile),
        ];
        await runFfmpegCapture(jobId, args, expectedDuration);
      } finally {
        await fs.rm(concatDir, { recursive: true, force: true }).catch(() => {});
      }
    }
  } finally {
    if (cancelledJobs.has(jobId)) {
      await fs.rm(outputFile, { force: true }).catch(() => {});
    }
  }

  const stat = await fs.stat(outputFile).catch(() => null);
  // FFmpeg 可能以 0 退出但什么都没编码（空输出/采样时段无画面），必须视为失败。
  if (!stat || stat.size < 1024) {
    await fs.rm(outputFile, { force: true }).catch(() => {});
    throw new Error(`章节预览生成失败：输出为空（${stat?.size ?? 0} 字节），采样时间段可能没有有效画面，请重试或更换采样位置`);
  }
  await db.update(jobsTable).set({
    status: "done",
    progress: 100,
    outputPath: outputFile,
    fileSizeAfter: stat?.size ?? null,
    durationSeconds: expectedDuration,
    completedAt: new Date(),
  }).where(eq(jobsTable.id, jobId));
  await addLog(jobId, "info", `章节预览任务完成 — 输出：${outputFile}`);
}
