// Extracted from routes/jobs.ts: embedded subtitle probing and CJK detection.
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { lookupAll, metadataIdentityMatches, normalizeTitleEn } from "../lib/metadata";
import { servePreviewSegment, cleanupPreviewSegments } from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import { buildFfconcatFileContent as buildManifest, buildFfconcatChapterContent, buildFfconcatTimedContent, type FfconcatTimedSegment } from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import { appendJobRuntimeLog, appendJobToolOutput } from "../lib/job-runtime-log";
import { appendRuntimeToolLog, appendRuntimeToolOutput } from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import { buildCompressionOutputName, buildRemuxOutputName, cleanSegment, encoderBitDepth, selectBestAudioTrack } from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import { renderBilingualAss, DEFAULT_BILINGUAL_STYLE, type BilingualAssStyle, type SubtitleBlock } from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import { ensureLocalPoster, MEDIA_INFO_DIR, POSTER_META_FILE, posterIdentityMatches } from "../lib/poster";
import { ensureFasterWhisperModel, ensureWhisperCliScript } from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import { hasValidSubtitleCues, isGraphicSubtitleCodec, shouldFallbackToWhisper } from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import { buildDvdRemuxArgs, runDvdRemux, verifyDvdTitle } from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import { buildDvdStructurePayload, resolveRemuxPlanWithLlm, validateRemuxPlan } from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import { assertPreviewTaskAllowed, recordPreviewAiCall, settlePreviewTask } from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import { parseCustomTuning, resolveLogicPlaceholders } from "../lib/custom-tuning";
import { decryptSecret, encryptSecret, isEncryptedSecret } from "../lib/secrets";
import { ffmpegPath, resolveOutputDir, resolveRuntimePath, type RuntimePathConfig } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import { assertCompleteMediaTitle, createDvdMediaTitle } from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import { buildPreviewTranscodeArgs, isPreviewVideoCandidate, previewService } from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";

export interface PipelineStep {
  name: string;
  status: "ok" | "skip" | "error";
  message: string;
}

const CJK_IDEOGRAPH_RE = /[\u3400-\u9fff]/;
const KANA_RE = /[\u3040-\u30ff]/;
const HANGUL_RE = /[\uac00-\ud7af]/;
// Full dialog tracks carry roughly 10-15 cues per minute; forced/partial tracks
// only carry on-screen text (about 1.5-2 per minute). The "full track" check
// is therefore judged against video duration, with an absolute fallback when
// the duration is unknown (or for tiny clips).
const MIN_FULL_SUBTITLE_PACKETS = 400;
const FULL_SUBTITLE_PACKETS_PER_MINUTE = 6;
const MIN_FULL_SUBTITLE_ABSOLUTE = 30;

export function fullSubtitlePacketThreshold(durationSeconds: number | null | undefined): number {
  const minutes = typeof durationSeconds === "number" && Number.isFinite(durationSeconds) && durationSeconds > 0
    ? durationSeconds / 60
    : 0;
  if (minutes <= 0) return MIN_FULL_SUBTITLE_PACKETS;
  return Math.max(minutes * FULL_SUBTITLE_PACKETS_PER_MINUTE, MIN_FULL_SUBTITLE_ABSOLUTE);
}

/** Extract a short sample of one embedded text subtitle track (fast, 60s window). */
export async function sampleEmbeddedSubtitleText(videoPath: string, typeIndex: number, windowSeconds = 60): Promise<string> {
  const ffmpegExecutable = (await resolveToolPath("ffmpeg").catch(() => null)) ?? "ffmpeg";
  return new Promise((resolve) => {
    const proc = jobProcessController.spawn(ffmpegExecutable, [
      "-hide_banner",
      "-loglevel", "error",
      "-t", String(windowSeconds),
      "-i", ffmpegPath(videoPath),
      "-map", `0:s:${typeIndex}`,
      "-f", "srt", "-",
    ]);
    let stdout = "";
    proc.stdout?.on("data", (chunk) => {
      stdout += String(chunk);
      if (stdout.length > 300_000) proc.kill("SIGKILL");
    });
    proc.on("error", () => resolve(""));
    proc.on("close", () => resolve(stdout));
  });
}

/**
 * A track "looks Chinese" when it contains CJK ideographs without Japanese
 * kana or Korean hangul. Track titles/language tags are checked separately.
 */
export function textLooksChinese(sample: string): boolean {
  if (!CJK_IDEOGRAPH_RE.test(sample)) return false;
  if (KANA_RE.test(sample)) return false;
  if (HANGUL_RE.test(sample)) return false;
  return true;
}

/** Count subtitle packets of one track (ffprobe full read, ~1s per track). */
export async function probeSubtitlePacketCount(videoPath: string, typeIndex: number): Promise<number> {
  const ffprobeExecutable = (await resolveToolPath("ffprobe").catch(() => null)) ?? "ffprobe";
  const raw = await new Promise<string>((resolve) => {
    const proc = jobProcessController.spawn(ffprobeExecutable, [
      "-v", "quiet",
      "-select_streams", `s:${typeIndex}`,
      "-count_packets",
      "-show_entries", "stream=nb_read_packets",
      "-of", "csv=p=0",
      ffmpegPath(videoPath),
    ]);
    let stdout = "";
    proc.stdout?.on("data", (chunk) => { stdout += String(chunk); });
    proc.on("error", () => resolve(""));
    proc.on("close", () => resolve(stdout));
  });
  const count = Number(String(raw).trim());
  return Number.isFinite(count) && count > 0 ? count : 0;
}

export function languageTagIsChinese(language: string | null | undefined): boolean {
  const lang = (language ?? "").toLowerCase().trim();
  return lang === "chi" || lang === "zho" || lang === "zh" || lang === "chs" || lang === "cht"
    || lang.startsWith("zh-") || lang.startsWith("chi-") || lang.startsWith("zho-");
}
