import { describe, expect, it } from "vitest";
import { resolveProbedDuration, summarizeMediaProbeStreams } from "./job-media-probe-context";

describe("job media probe context", () => {
  it("summarizes video, audio, subtitle and primary audio information", () => {
    expect(summarizeMediaProbeStreams([
      { codecType: "video", codecName: "mpeg2video", height: 576 },
      { codecType: "audio", codecName: "ac3", channels: 2, bitRate: 192000, tags: { language: "en" } },
      { codecType: "subtitle", codecName: "dvd_subtitle" },
    ])).toEqual({
      hasEmbeddedSubs: true,
      primaryAudioCodec: "ac3",
      sourceHasAudio: true,
      probeVideoHeight: 576,
      probeHasVideo: true,
    });
  });

  it("uses the selected disc title duration instead of another probe title", () => {
    expect(resolveProbedDuration({
      mediaType: "dvd",
      hasTaskSnapshot: true,
      probeDuration: 3600,
      selectedTitleDurationSeconds: 120,
    })).toBe(120);
  });

  it("uses the media probe for ordinary video jobs", () => {
    expect(resolveProbedDuration({
      mediaType: "video",
      hasTaskSnapshot: false,
      probeDuration: 3600,
      selectedTitleDurationSeconds: null,
    })).toBe(3600);
  });
});
