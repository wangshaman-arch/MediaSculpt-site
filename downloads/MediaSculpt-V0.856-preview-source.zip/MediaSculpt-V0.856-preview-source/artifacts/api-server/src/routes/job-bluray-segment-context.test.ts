import { describe, expect, it } from "vitest";
import {
  calculateBlurayPlaylistDurationSeconds,
  probeAndTrimBluraySegments,
  trimTrailingShortBluraySegments,
} from "./job-bluray-segment-context";

function segment(clipId: string, seconds: number) {
  return {
    clipId,
    streamPath: `${clipId}.m2ts`,
    inTime45k: 0,
    outTime45k: seconds * 45_000,
  };
}

describe("Blu-ray segment context", () => {
  it("uses the 45 kHz MPLS clock when deriving playlist duration", () => {
    expect(calculateBlurayPlaylistDurationSeconds([segment("00001", 90)])).toBe(90);
  });

  it("trims only trailing short segments and keeps the main segment", () => {
    const result = trimTrailingShortBluraySegments(
      [segment("main", 100), segment("logo", 1), segment("promo", 1)],
      [100, 1, 1],
    );

    expect(result.segments.map((item) => item.clipId)).toEqual(["main"]);
    expect(result.trimmedSegments.map((item) => item.clipId)).toEqual(["promo", "logo"]);
    expect(result.keptDurationSeconds).toBe(100);
  });

  it("does not remove a short segment from the middle of the playlist", () => {
    const result = trimTrailingShortBluraySegments(
      [segment("main", 100), segment("interlude", 1), segment("ending", 100)],
      [100, 1, 100],
    );

    expect(result.segments.map((item) => item.clipId)).toEqual(["main", "interlude", "ending"]);
    expect(result.trimmedSegments).toEqual([]);
    expect(result.keptDurationSeconds).toBe(201);
  });

  it("keeps MPLS duration when physical stream probing is unavailable", async () => {
    const segments = [segment("main", 100), segment("ending", 1)];
    const result = await probeAndTrimBluraySegments({
      segments,
      probeDuration: async () => null,
    });

    expect(result.segments).toEqual(segments);
    expect(result.playlistDuration).toBe(101);
    expect(result.keptDurationSeconds).toBe(101);
  });
});
