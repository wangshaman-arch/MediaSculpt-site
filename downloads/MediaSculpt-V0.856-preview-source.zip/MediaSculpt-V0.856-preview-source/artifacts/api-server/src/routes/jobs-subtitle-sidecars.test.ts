import { afterEach, describe, expect, it } from "vitest";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { stageSubtitleSidecars } from "./jobs-subtitle-sidecars";
import { clearJobOutputFiles } from "../infrastructure/job-output-tracker";

describe("graphic subtitle sidecar staging", () => {
  const cleanupDirs: string[] = [];

  afterEach(async () => {
    clearJobOutputFiles(9182);
    for (const dir of cleanupDirs.splice(0)) await fs.rm(dir, { recursive: true, force: true });
  });

  it("copies every PGS/VobSub sidecar beside the final output without collisions", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "mediasculpt-sidecars-"));
    cleanupDirs.push(dir);
    const sourceDir = path.join(dir, "subtitle");
    const outputDir = path.join(dir, "output");
    await fs.mkdir(sourceDir);
    await fs.mkdir(outputDir);
    const pgs = path.join(sourceDir, "Source.graphic-0.sup");
    const vobsub = path.join(sourceDir, "Source.graphic-1.mkv");
    const output = path.join(outputDir, "Final.mkv");
    await fs.writeFile(pgs, Buffer.from("PGS"));
    await fs.writeFile(vobsub, Buffer.from("VobSub"));
    await fs.writeFile(output, Buffer.from("video"));

    const logs: string[] = [];
    await stageSubtitleSidecars(9182, output, null, null, async (_level, message) => { logs.push(message); }, [pgs, vobsub]);

    await expect(fs.readFile(path.join(outputDir, "Final.graphic-0.sup"), "utf8")).resolves.toBe("PGS");
    await expect(fs.readFile(path.join(outputDir, "Final.graphic-1.mkv"), "utf8")).resolves.toBe("VobSub");
    expect(logs).toHaveLength(2);
  });
});
