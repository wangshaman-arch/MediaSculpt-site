import { Router, type Response } from "express";
import os from "os";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import type { ChildProcess } from "child_process";
import { db, jobsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { servePreviewSegment } from "../lib/preview-segments";
import { appendRuntimeToolLog } from "../lib/runtime-tool-log";
import { resolveToolPath } from "../lib/tool-runtime";
import {
  ensureLocalPoster,
  MEDIA_INFO_DIR,
  POSTER_META_FILE,
  posterIdentityMatches,
} from "../lib/poster";
import { ffmpegPath, resolveRuntimePath } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { processRunner } from "../infrastructure/process-runner";
import {
  buildPreviewTranscodeArgs,
  isPreviewVideoCandidate,
  previewService,
} from "../media/preview-service";
import {
  resolveDvdTitleForIfo,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";
import {
  buildDiscPreviewInputArgs,
  extractLastJpegFrame,
} from "../lib/disc-preview";
import type { DiscAnalysisResult } from "../lib/disc-analysis";
import {
  discAnalysisRegistry,
  getConfig,
  resolveMainTrack,
  toWebVtt,
  readSubtitleText,
  resolveJobSubtitleDirectories,
  scanJobSubtitleFiles,
  ensureAnalysisIsoReady,
  ensureDvdCssSupport,
  dvdVideoInputPath,
} from "./jobs";

const router = Router();
type DiscTitlePreviewCacheEntry = {
  previews: string[];
  createdAt: number;
  warning?: string;
  source: "cache" | "ffmpeg-validated-input" | "unavailable";
};

const discTitlePreviewCache = new Map<string, DiscTitlePreviewCacheEntry>();

function previewFallbackSvg(
  title: { displayName: string; durationSeconds: number | null },
  index = 1,
): string {
  const label =
    `${title.displayName} · ${title.durationSeconds ? Math.round(title.durationSeconds) + "s" : "时长未知"}`.replace(
      /[<&>]/g,
      "",
    );
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360"><rect width="640" height="360" fill="#07121f"/><path d="M280 145h80v70h-80z" fill="#1e9bcf" opacity=".65"/><path d="M314 160l32 20-32 20z" fill="#fff"/><text x="320" y="250" fill="#cbd5e1" font-family="sans-serif" font-size="18" text-anchor="middle">${label}</text><text x="320" y="280" fill="#64748b" font-family="sans-serif" font-size="13" text-anchor="middle">Title Preview ${index}</text><text x="320" y="305" fill="#64748b" font-family="sans-serif" font-size="13" text-anchor="middle">预览不可用，但不影响任务创建</text></svg>`;
  return `data:image/svg+xml;base64,${Buffer.from(svg).toString("base64")}`;
}

export function buildDiscTitlePreviewArgs(input: {
  analysis: DiscAnalysisResult;
  title: DiscAnalysisResult["titles"][number];
  offsetSeconds: number;
  ffmpeg: string;
}): {
  executable: string;
  args: string[];
  source: "ffmpeg-validated-input" | "unavailable";
  frameCount: number;
} {
  if (input.analysis.mediaType === "dvd" && !input.title.previewSourcePath) {
    const titleNumber = input.title.toolMappings.handbrakeTitleNumber;
    if (
      typeof titleNumber !== "number" ||
      !Number.isInteger(titleNumber) ||
      titleNumber <= 0
    )
      return {
        executable: input.ffmpeg,
        args: [],
        source: "unavailable",
        frameCount: 1,
      };
    // HandBrake is the sole title authority.  The FFmpeg fallback uses the
    // already verified dvdvideo input contract and the exact HandBrake title;
    // it never opens the VIDEO_TS directory as a generic media file.
    return {
      executable: input.ffmpeg,
      args: [
        "-hide_banner",
        "-loglevel",
        "error",
        ...buildDiscPreviewInputArgs({
          mediaType: "dvd",
          sourcePath: dvdVideoInputPath(input.analysis.sourcePath),
          handbrakeTitleNumber: titleNumber,
          offsetSeconds: Math.max(0, input.offsetSeconds),
        }),
        "-frames:v",
        "1",
        "-vf",
        "yadif,scale=640:-2",
        "-f",
        "image2pipe",
        "-vcodec",
        "mjpeg",
        "pipe:1",
      ],
      source: "ffmpeg-validated-input",
      frameCount: 1,
    };
  }
  // HandBrake titles point at the disc root; preview frames must come from a
  // real media file, so prefer the mapped m2ts preview source.
  const previewSourcePath =
    input.title.previewSourcePath ?? input.title.sourcePath;
  const titleDuration =
    input.title.durationSeconds && input.title.durationSeconds > 0
      ? input.title.durationSeconds
      : null;
  const safeOffset =
    titleDuration != null
      ? Math.min(
          Math.max(0, input.offsetSeconds),
          Math.max(0, titleDuration - 1),
        )
      : Math.max(0, input.offsetSeconds);
  // VC-1 Blu-ray streams often begin a random seek on a non-reference frame.
  // Decode a short warmup window from the mapped M2TS and use its last frame;
  // this is fast and avoids the multi-minute MPLS seek on slow optical drives.
  const vc1Warmup =
    input.analysis.mediaType === "bluray" &&
    Boolean(previewSourcePath) &&
    input.title.videoTracks.some(
      (stream) => stream.codecName?.toLowerCase() === "vc1",
    );
  return {
    executable: input.ffmpeg,
    args: [
      "-hide_banner",
      "-loglevel",
      "error",
      ...buildDiscPreviewInputArgs({
        mediaType: input.analysis.mediaType,
        sourcePath: input.analysis.sourcePath,
        previewSourcePath,
        previewSegments: input.title.previewSegments,
        playlistId: vc1Warmup ? null : input.title.toolMappings.playlistId,
        offsetSeconds: safeOffset,
      }),
      "-frames:v",
      String(vc1Warmup ? 180 : 1),
      "-vf",
      "yadif,scale=640:-2",
      "-f",
      "image2pipe",
      "-vcodec",
      "mjpeg",
      "pipe:1",
    ],
    source: "ffmpeg-validated-input",
    frameCount: vc1Warmup ? 180 : 1,
  };
}
async function renderDiscTitlePreviewFrame(
  executable: string,
  args: string[],
  frameCount = 1,
): Promise<{ data: Buffer; stderr: string; code: number | null }> {
  return new Promise((resolve) => {
    const managed = processRunner.spawn({
      executable,
      args,
      stage: "disc-title-preview",
      timeoutMs: 15_000,
    });
    const child = managed.child;
    const chunks: Buffer[] = [];
    let stderr = "";
    const timer = setTimeout(() => managed.kill("SIGKILL"), 15_000);
    child.stdout?.on("data", (chunk: Buffer) => chunks.push(chunk));
    child.stderr?.on("data", (chunk: Buffer) => {
      stderr += chunk.toString();
    });
    child.once("error", () => {
      clearTimeout(timer);
      resolve({ data: Buffer.alloc(0), stderr: "FFmpeg 不可用", code: null });
    });
    child.once("close", (code) => {
      clearTimeout(timer);
      const data = Buffer.concat(chunks);
      resolve({
        data: frameCount > 1 ? extractLastJpegFrame(data) : data,
        stderr,
        code,
      });
    });
  });
}

// Generates cached low-resolution title images for the disc dialog.  Preview
// failures are deliberately non-blocking: title selection and task creation
// continue to use the HandBrake analysis and task snapshot.
router.get("/disc/title-preview", async (req, res) => {
  const analysisId = String(req.query.analysisId ?? "");
  const titleId = String(req.query.titleId ?? "");
  if (!analysisId || !titleId)
    return res.status(400).json({ error: "analysisId 和 titleId 不能为空" });
  const analysis = discAnalysisRegistry.find(analysisId);
  const title = analysis?.titles.find((item) => item.titleId === titleId);
  if (!analysis || !title)
    return res.status(404).json({ error: "标题分析结果已过期，请重新分析" });
  await ensureAnalysisIsoReady(analysis);

  const cacheKey = `${analysis.sourceFingerprint}:${titleId}`;
  const cached = discTitlePreviewCache.get(cacheKey);
  if (cached && Date.now() - cached.createdAt < 15 * 60_000)
    return res.json({
      url: cached.previews[0],
      previews: cached.previews,
      warning: cached.warning,
      source: cached.source,
      cached: true,
    });

  const ffmpeg = (await resolveToolPath("ffmpeg")) ?? "ffmpeg";
  if (analysis.mediaType === "dvd") await ensureDvdCssSupport(ffmpeg);
  const duration =
    title.durationSeconds && title.durationSeconds > 0
      ? title.durationSeconds
      : 0;
  // Preview frames follow the chapter list (one frame per chapter, capped),
  // so the dialog shows one preview per chapter. Titles without chapters get
  // two frames at 25% / 75% so the preview area is never empty.
  const MAX_PREVIEWS = 6;
  const chapters = Array.isArray(title.chapters) ? title.chapters : [];
  // Only trust chapter positions when they actually span the title. Some
  // authored discs carry broken chapter timestamps (e.g. all within the first
  // seconds), which would produce a row of identical opening frames.
  const lastChapterEnd = chapters.reduce(
    (max, chapter) => Math.max(max, Number(chapter.endSeconds ?? 0)),
    0,
  );
  const chaptersCoverTitle = duration > 0 && lastChapterEnd >= duration * 0.5;
  let offsets: number[];
  if (chapters.length > 0 && chaptersCoverTitle) {
    offsets = chapters.slice(0, MAX_PREVIEWS).map((chapter) => {
      const start = Number(chapter.startSeconds ?? 0);
      const end = Number(chapter.endSeconds ?? start);
      const frameOffset =
        end > start ? start + Math.max(0.5, (end - start) * 0.25) : start + 0.5;
      return duration > 0
        ? Math.min(frameOffset, Math.max(0, duration - 0.01))
        : frameOffset;
    });
  } else if (duration > 0) {
    offsets = [Math.max(0, duration * 0.25), Math.max(0, duration * 0.75)];
  } else {
    offsets = [0];
  }
  const previews: string[] = [];
  const diagnostics: string[] = [];
  let source: DiscTitlePreviewCacheEntry["source"] = "unavailable";
  for (const [index, offsetSeconds] of offsets.entries()) {
    const command = buildDiscTitlePreviewArgs({
      analysis,
      title,
      offsetSeconds,
      ffmpeg,
    });
    if (!command.args.length) {
      diagnostics.push(`preview-${index + 1}: 没有有效标题编号`);
      previews.push(previewFallbackSvg(title, index + 1));
      continue;
    }
    const output = await renderDiscTitlePreviewFrame(
      command.executable,
      command.args,
      command.frameCount,
    );
    if (output.code === 0 && output.data.length > 128) {
      previews.push(`data:image/jpeg;base64,${output.data.toString("base64")}`);
      source = command.source;
    } else {
      diagnostics.push(
        `preview-${index + 1}: exit=${output.code ?? "n/a"} ${output.stderr.trim().slice(-300)}`,
      );
      previews.push(previewFallbackSvg(title, index + 1));
    }
  }
  const allFallback = previews.every((preview) =>
    preview.startsWith("data:image/svg+xml"),
  );
  const warning = allFallback
    ? "预览不可用，但不影响任务创建"
    : diagnostics.length > 0
      ? "部分预览不可用，但不影响任务创建"
      : undefined;
  if (allFallback) source = "unavailable";
  const entry = {
    previews,
    createdAt: Date.now(),
    warning,
    source,
  } satisfies DiscTitlePreviewCacheEntry;
  discTitlePreviewCache.set(cacheKey, entry);
  await appendRuntimeToolLog(
    `标题预览 title=${titleId} source=${source} tool=${ffmpeg} frames=${previews.length} warning=${warning ?? "none"} diagnostics=${diagnostics.join(" | ") || "none"}`,
  ).catch(() => {});
  return res.json({
    url: previews[0],
    previews,
    warning,
    source,
    cached: false,
  });
});
router.get("/jobs/:id/preview", async (req, res) => {
  const id = Number(req.params.id);
  const filePath = await resolveJobPreviewFilePath(id);
  if (!filePath) return res.status(404).json({ error: "没有可预览的视频文件" });
  try {
    const stat = await fs.stat(filePath);
    const range = req.headers.range;
    const extension = path.extname(filePath).toLowerCase();
    const contentType =
      extension === ".webm"
        ? "video/webm"
        : extension === ".mkv"
          ? "video/x-matroska"
          : extension === ".ts" || extension === ".m2ts"
            ? "video/mp2t"
            : extension === ".mov"
              ? "video/quicktime"
              : "video/mp4";
    if (!range) {
      res.setHeader("Content-Length", stat.size);
      res.setHeader("Content-Type", contentType);
      return fsSync.createReadStream(filePath).pipe(res);
    }
    const match = range.match(/bytes=(\d*)-(\d*)/);
    if (!match) return res.status(416).end();
    const start = match[1] ? Number(match[1]) : 0;
    const end = match[2]
      ? Math.min(Number(match[2]), stat.size - 1)
      : Math.min(start + 1024 * 1024 - 1, stat.size - 1);
    if (start >= stat.size || end < start) return res.status(416).end();
    res.status(206).set({
      "Content-Range": `bytes ${start}-${end}/${stat.size}`,
      "Accept-Ranges": "bytes",
      "Content-Length": String(end - start + 1),
      "Content-Type": contentType,
    });
    return fsSync.createReadStream(filePath, { start, end }).pipe(res);
  } catch {
    return res.status(404).json({ error: "视频文件不存在或无法读取" });
  }
});

async function resolveJobPreviewFilePath(id: number): Promise<string | null> {
  const [job] = await db
    .select({
      filePath: jobsTable.filePath,
      mainTrackPath: jobsTable.mainTrackPath,
      outputPath: jobsTable.outputPath,
      mediaType: jobsTable.mediaType,
    })
    .from(jobsTable)
    .where(eq(jobsTable.id, id))
    .limit(1);
  // 按优先级逐个尝试：输出文件 → 光盘主标题轨 → 源文件。
  // 某个候选不存在/读不到（文件被移动、改名、云盘未下载）时跳过继续试下一个，
  // 避免“输出路径失效就整条预览 404（浏览器报错码 4）”。
  const candidates = [job?.outputPath, job?.mainTrackPath, job?.filePath]
    .filter((candidate): candidate is string => Boolean(candidate))
    // 字幕任务的 outputPath 是 .ass/.srt 字幕文件，不是视频，必须跳过，
    // 否则 ffmpeg 无视频流 → 空响应 → 浏览器报错误码 4。
    .filter(isPreviewVideoCandidate);
  for (const candidate of candidates) {
    let filePath = candidate;
    try {
      const stat = await fs.stat(filePath);
      if (stat.isDirectory()) {
        filePath = await resolveDiscMainTrack(
          filePath,
          job?.mediaType ?? "video",
        );
      }
    } catch {
      continue;
    }
    if (/\.ifo$/i.test(filePath)) {
      const title = await resolveDvdTitleForIfo(filePath).catch(() => null);
      filePath = title?.vobFiles[0] ?? filePath;
    }
    try {
      const stat = await fs.stat(filePath);
      if (stat.isFile()) return filePath;
    } catch {
      // 当前候选解析出的文件不可读，继续尝试下一个候选。
    }
  }
  return null;
}

router.get("/jobs/:id/preview/meta", async (req, res) => {
  const id = Number(req.params.id);
  const filePath = await resolveJobPreviewFilePath(id);
  if (!filePath) return res.status(404).json({ error: "没有可预览的视频文件" });
  const metadata = await previewService.probeMetadata(filePath);
  return res.json(metadata);
});

router.get("/jobs/:id/preview.mp4", async (req, res) => {
  const id = Number(req.params.id);
  const filePath = await resolveJobPreviewFilePath(id);
  if (!filePath) return res.status(404).json({ error: "没有可预览的视频文件" });
  const seekRaw = typeof req.query.seek === "string" ? req.query.seek : "";
  const seekSeconds = Number(seekRaw);
  const hasSeek =
    seekRaw !== "" && Number.isFinite(seekSeconds) && seekSeconds > 0;
  const subRaw = typeof req.query.sub === "string" ? req.query.sub : "";
  const subIndex = Number(subRaw);
  const hasSub = subRaw !== "" && Number.isInteger(subIndex) && subIndex >= 0;
  let subTypeIndex: number | null = null;
  if (hasSub) {
    const containerIndices =
      await previewService.subtitleContainerIndices(filePath);
    const found = containerIndices.indexOf(subIndex);
    subTypeIndex = found >= 0 ? found : null;
  }
  // 默认使用连续流；旧的分段模式仅在显式 segment=1 时启用。
  if (req.query.segment === "1") {
    return servePreviewSegment(
      res,
      filePath,
      subTypeIndex,
      hasSeek ? seekSeconds : 0,
    );
  }
  return streamContinuousPreview(
    res,
    filePath,
    subTypeIndex,
    hasSeek ? seekSeconds : 0,
  );
});

// 通用预览转码：同一时刻只保留一个进程（快速 seek / 切换项时终止旧的）。
let genericPreviewFfmpeg: ChildProcess | null = null;
function streamFfmpegPreview(
  res: Response,
  executable: string,
  args: string[],
): void {
  res.setHeader("Content-Type", "video/mp4");
  res.setHeader("Cache-Control", "no-store");
  if (genericPreviewFfmpeg && !genericPreviewFfmpeg.killed) {
    try {
      genericPreviewFfmpeg.kill("SIGKILL");
    } catch {
      /* ignore */
    }
  }
  const ffmpeg = jobProcessController.spawn(executable, args);
  genericPreviewFfmpeg = ffmpeg;
  let stderr = "";
  let wroteBytes = false;
  ffmpeg.stderr?.on("data", (chunk) => {
    stderr += String(chunk);
  });
  // 手动写响应：ffmpeg 输出为空时绝不能以 200 空响应结束（浏览器会报错误码 4）。
  ffmpeg.stdout?.on("data", (chunk: Buffer) => {
    wroteBytes = true;
    if (res.destroyed || res.writableEnded) return;
    if (!res.write(chunk)) ffmpeg.stdout?.pause();
  });
  res.on("drain", () => ffmpeg.stdout?.resume());
  ffmpeg.stdout?.on("end", () => {
    /* close 时统一收尾 */
  });
  ffmpeg.on("error", (error) => {
    if (!res.headersSent)
      res.status(500).json({ error: `预览转码启动失败：${error.message}` });
    else res.destroy(error);
  });
  ffmpeg.on("close", (code) => {
    if (genericPreviewFfmpeg === ffmpeg) genericPreviewFfmpeg = null;
    if (!wroteBytes) {
      if (!res.headersSent) {
        res.status(500).json({
          error: `预览转码失败：${stderr.slice(-600) || `ffmpeg exit ${code ?? "unknown"}`}`,
        });
        return;
      }
      res.destroy();
      return;
    }
    if (!res.writableEnded) res.end();
  });
  res.on("close", () => {
    if (!ffmpeg.killed) ffmpeg.kill("SIGTERM");
  });
}

/** 连续预览转码：整条响应保持同一个 MP4 流，不按 5 秒片段切换源。 */
async function streamContinuousPreview(
  res: Response,
  filePath: string,
  subTypeIndex: number | null,
  seekSeconds: number,
): Promise<void> {
  const ffmpegExecutable =
    (await resolveToolPath("ffmpeg").catch(() => null)) ?? "ffmpeg";
  const inputArgs = [
    "-hide_banner",
    "-loglevel",
    "error",
    "-fflags",
    "+genpts",
    ...(seekSeconds > 0 ? ["-ss", String(seekSeconds)] : []),
    "-i",
    ffmpegPath(filePath),
  ];
  const transcodeArgs = buildPreviewTranscodeArgs(
    subTypeIndex !== null,
    subTypeIndex,
  );
  streamFfmpegPreview(res, ffmpegExecutable, [...inputArgs, ...transcodeArgs]);
}

// 按路径预览（视频文件，或光盘目录的主标题）：与任务详情预览相同的转码管线。
router.get("/media/preview.mp4", async (req, res) => {
  const rawPath =
    typeof req.query.path === "string" ? req.query.path.trim() : "";
  if (!rawPath) return res.status(400).json({ error: "path 参数不能为空" });
  const config = await getConfig();
  const sourcePath = resolveRuntimePath(rawPath, config);
  let filePath = sourcePath;
  try {
    const stat = await fs.stat(filePath);
    if (stat.isDirectory())
      filePath = await resolveMainTrack(filePath, "bluray").catch(
        () => filePath,
      );
    const fileStat = await fs.stat(filePath);
    if (!fileStat.isFile())
      return res.status(404).json({ error: "没有可预览的视频文件" });
  } catch {
    return res.status(404).json({ error: "视频文件不存在或无法读取" });
  }
  const seekRaw = typeof req.query.seek === "string" ? req.query.seek : "";
  const seekSeconds = Number(seekRaw);
  const hasSeek =
    seekRaw !== "" && Number.isFinite(seekSeconds) && seekSeconds > 0;
  const subRaw = typeof req.query.sub === "string" ? req.query.sub : "";
  const subIndex = Number(subRaw);
  const hasSub = subRaw !== "" && Number.isInteger(subIndex) && subIndex >= 0;
  let subTypeIndex: number | null = null;
  if (hasSub) {
    const containerIndices =
      await previewService.subtitleContainerIndices(filePath);
    const found = containerIndices.indexOf(subIndex);
    subTypeIndex = found >= 0 ? found : null;
  }
  // 默认使用连续流；旧的分段模式仅在显式 segment=1 时启用。
  if (req.query.segment === "1") {
    return servePreviewSegment(
      res,
      filePath,
      subTypeIndex,
      hasSeek ? seekSeconds : 0,
    );
  }
  return streamContinuousPreview(
    res,
    filePath,
    subTypeIndex,
    hasSeek ? seekSeconds : 0,
  );
});

async function resolveMediaPreviewFilePath(
  rawPath: string,
): Promise<string | null> {
  if (!rawPath) return null;
  const config = await getConfig();
  const sourcePath = resolveRuntimePath(rawPath, config);
  let filePath = sourcePath;
  try {
    const stat = await fs.stat(filePath);
    if (stat.isDirectory())
      filePath = await resolveMainTrack(filePath, "bluray").catch(
        () => filePath,
      );
    const fileStat = await fs.stat(filePath);
    return fileStat.isFile() ? filePath : null;
  } catch {
    return null;
  }
}

/** 源路径可能存在的海报目录：MediaInfo 子目录优先（新位置），再回退到目录根（旧位置）。 */
function posterDirectoriesForSource(sourcePath: string): string[] {
  const baseDirs: string[] = [];
  try {
    const stat = fsSync.statSync(sourcePath);
    if (stat.isFile()) {
      baseDirs.push(path.dirname(sourcePath));
    } else if (stat.isDirectory()) {
      baseDirs.push(sourcePath);
      const base = path.basename(sourcePath);
      if (/^(VIDEO_TS|BDMV|DVD|AUDIO_TS)$/i.test(base))
        baseDirs.push(path.dirname(sourcePath));
    }
  } catch {
    if (path.extname(sourcePath)) baseDirs.push(path.dirname(sourcePath));
    else baseDirs.push(sourcePath);
  }
  const uniqueBase = baseDirs.filter(
    (dir, index) => baseDirs.indexOf(dir) === index,
  );
  const infoDirs = uniqueBase.map((dir) => path.join(dir, MEDIA_INFO_DIR));
  return [...infoDirs, ...uniqueBase];
}

// GET /media/poster — 读取源目录里已保存的海报（poster.jpg / folder.jpg）。
router.get("/media/poster", async (req, res) => {
  const rawPath =
    typeof req.query.path === "string" ? req.query.path.trim() : "";
  if (!rawPath) return res.status(400).json({ error: "path 参数不能为空" });
  const expectedImdbId =
    typeof req.query.imdbId === "string" ? req.query.imdbId.trim() : "";
  const expectedTitle =
    typeof req.query.title === "string" ? req.query.title.trim() : "";
  const expectedTitleEn =
    typeof req.query.titleEn === "string" ? req.query.titleEn.trim() : "";
  const expectedYear =
    typeof req.query.year === "string" && /^\d{4}$/.test(req.query.year)
      ? Number(req.query.year)
      : undefined;
  const config = await getConfig();
  const sourcePath = resolveRuntimePath(rawPath, config);
  for (const dir of posterDirectoriesForSource(sourcePath)) {
    for (const name of ["poster.jpg", "folder.jpg"]) {
      const file = path.join(dir, name);
      try {
        const stat = await fs.stat(file);
        if (stat.isFile()) {
          // Once the task has a canonical IMDb id, never display a legacy
          // poster unless its sidecar provenance points to the same identity.
          // This prevents a failed refresh from surfacing a poster from a
          // previous, similarly named title.
          if (
            expectedImdbId ||
            expectedTitle ||
            expectedTitleEn ||
            expectedYear
          ) {
            const metaRaw = await fs
              .readFile(path.join(dir, POSTER_META_FILE), "utf8")
              .catch(() => null);
            if (!metaRaw) continue;
            const meta = JSON.parse(metaRaw) as {
              imdbId?: string | null;
              title?: string | null;
              titleEn?: string | null;
              year?: number | string | null;
            };
            if (
              !posterIdentityMatches(meta, {
                imdbId: expectedImdbId,
                title: expectedTitle,
                titleEn: expectedTitleEn,
                year: expectedYear,
              })
            )
              continue;
          }
          res.setHeader(
            "Content-Type",
            name.toLowerCase().endsWith(".png") ? "image/png" : "image/jpeg",
          );
          res.setHeader("Cache-Control", "no-store");
          return fsSync.createReadStream(file).pipe(res);
        }
      } catch {
        /* try next candidate */
      }
    }
  }
  return res.status(404).json({ error: "目录中没有海报" });
});

// POST /media/poster — 把找到的真实海报保存到源目录（poster.jpg + folder.jpg）。
router.post("/media/poster", async (req, res) => {
  const rawPath =
    typeof req.body?.path === "string" ? req.body.path.trim() : "";
  const url = typeof req.body?.url === "string" ? req.body.url.trim() : "";
  if (!rawPath || !url || !/^https?:\/\//i.test(url)) {
    return res.status(400).json({ error: "path 与 url 不能为空" });
  }
  const config = await getConfig();
  const sourcePath = resolveRuntimePath(rawPath, config);
  const dir = posterDirectoriesForSource(sourcePath)[0];
  if (!dir) return res.status(404).json({ error: "无法确定海报保存目录" });
  const posterPath = await ensureLocalPoster({
    title: typeof req.body?.title === "string" ? req.body.title : null,
    titleEn: typeof req.body?.titleEn === "string" ? req.body.titleEn : null,
    imdbId: typeof req.body?.imdbId === "string" ? req.body.imdbId : null,
    posterUrl: url,
    posterMirrorUrl: config.posterMirrorUrl,
    posterProxyUrl: config.posterProxyUrl,
    year: typeof req.body?.year === "number" ? req.body.year : null,
    targetDirectory: dir,
  });
  if (!posterPath) return res.status(500).json({ error: "海报保存失败" });
  return res.json({ posterPath });
});

// 按路径的原始文件流（Range 支持）：浏览器可直接播放的容器（mp4/webm/mov 等）用
// 它替代转码流，时长/进度/seek 原生准确、零转码不卡顿。
router.get("/media/preview", async (req, res) => {
  const rawPath =
    typeof req.query.path === "string" ? req.query.path.trim() : "";
  const filePath = await resolveMediaPreviewFilePath(rawPath);
  if (!filePath) return res.status(404).json({ error: "没有可预览的视频文件" });
  try {
    const stat = await fs.stat(filePath);
    const range = req.headers.range;
    const extension = path.extname(filePath).toLowerCase();
    const contentType =
      extension === ".webm"
        ? "video/webm"
        : extension === ".mkv"
          ? "video/x-matroska"
          : extension === ".ts" || extension === ".m2ts"
            ? "video/mp2t"
            : extension === ".mov"
              ? "video/quicktime"
              : "video/mp4";
    if (!range) {
      res.setHeader("Content-Length", stat.size);
      res.setHeader("Content-Type", contentType);
      return fsSync.createReadStream(filePath).pipe(res);
    }
    const match = range.match(/bytes=(\d*)-(\d*)/);
    if (!match) return res.status(416).end();
    const start = match[1] ? Number(match[1]) : 0;
    const end = match[2]
      ? Math.min(Number(match[2]), stat.size - 1)
      : Math.min(start + 1024 * 1024 - 1, stat.size - 1);
    if (start >= stat.size || end < start) return res.status(416).end();
    res.status(206).set({
      "Content-Range": `bytes ${start}-${end}/${stat.size}`,
      "Accept-Ranges": "bytes",
      "Content-Length": String(end - start + 1),
      "Content-Type": contentType,
    });
    return fsSync.createReadStream(filePath, { start, end }).pipe(res);
  } catch {
    return res.status(404).json({ error: "视频文件不存在或无法读取" });
  }
});

// 按路径的预览元信息（时长），供播放器校准进度条/时长显示。
router.get("/media/preview/meta", async (req, res) => {
  const rawPath =
    typeof req.query.path === "string" ? req.query.path.trim() : "";
  const filePath = await resolveMediaPreviewFilePath(rawPath);
  if (!filePath) return res.status(404).json({ error: "没有可预览的视频文件" });
  const metadata = await previewService.probeMetadata(filePath);
  return res.json(metadata);
});

// 光盘标题预览元信息（时长），供播放器校准进度条/时长显示。
router.get("/disc/title-preview/meta", async (req, res) => {
  const analysisId =
    typeof req.query.analysisId === "string" ? req.query.analysisId : "";
  const titleId =
    typeof req.query.titleId === "string" ? req.query.titleId : "";
  if (!analysisId || !titleId)
    return res.status(400).json({ error: "analysisId 和 titleId 不能为空" });
  const analysis = discAnalysisRegistry.find(analysisId);
  const title = analysis?.titles.find((item) => item.titleId === titleId);
  if (!analysis || !title)
    return res.status(404).json({ error: "标题分析结果已过期，请重新分析" });
  return res.json({ durationSeconds: title.durationSeconds ?? null });
});

// 光盘标题预览流（批量确认阶段无需任务即可预览）；DVD 与缩略图共用实体 VTS 输入。
router.get("/disc/title-preview.mp4", async (req, res) => {
  const analysisId =
    typeof req.query.analysisId === "string" ? req.query.analysisId : "";
  const titleId =
    typeof req.query.titleId === "string" ? req.query.titleId : "";
  if (!analysisId || !titleId)
    return res.status(400).json({ error: "analysisId 和 titleId 不能为空" });
  const analysis = discAnalysisRegistry.find(analysisId);
  const title = analysis?.titles.find((item) => item.titleId === titleId);
  if (!analysis || !title)
    return res.status(404).json({ error: "标题分析结果已过期，请重新分析" });
  await ensureAnalysisIsoReady(analysis);
  const seekRaw = typeof req.query.seek === "string" ? req.query.seek : "";
  const seekSeconds = Number(seekRaw);
  const hasSeek =
    seekRaw !== "" && Number.isFinite(seekSeconds) && seekSeconds > 0;
  const ffmpegExecutable =
    (await resolveToolPath("ffmpeg").catch(() => null)) ?? "ffmpeg";
  if (analysis.mediaType === "dvd") await ensureDvdCssSupport(ffmpegExecutable);
  let inputArgs: string[];
  let transcodeArgs: string[];
  if (analysis.mediaType === "dvd") {
    const titleNumber = title.toolMappings.handbrakeTitleNumber;
    if (
      typeof titleNumber !== "number" ||
      !Number.isInteger(titleNumber) ||
      titleNumber <= 0
    ) {
      return res
        .status(400)
        .json({ error: "该标题没有有效的 HandBrake 标题编号，无法预览" });
    }
    const previewSourcePath = title.previewSourcePath ?? null;
    inputArgs = [
      "-hide_banner",
      "-loglevel",
      "error",
      "-fflags",
      "+genpts",
      ...buildDiscPreviewInputArgs({
        mediaType: "dvd",
        sourcePath: analysis.sourcePath,
        previewSourcePath,
        handbrakeTitleNumber: titleNumber,
        offsetSeconds: hasSeek ? seekSeconds : 0,
      }),
    ];
    transcodeArgs = buildPreviewTranscodeArgs(false, null);
  } else {
    const previewSourcePath = title.previewSourcePath ?? title.sourcePath;
    if (!previewSourcePath)
      return res.status(404).json({ error: "该标题没有可预览的媒体文件" });
    inputArgs = [
      "-hide_banner",
      "-loglevel",
      "error",
      "-fflags",
      "+genpts",
      ...buildDiscPreviewInputArgs({
        mediaType: analysis.mediaType,
        sourcePath: analysis.sourcePath,
        previewSourcePath,
        previewSegments: title.previewSegments,
        playlistId: title.toolMappings.playlistId,
        offsetSeconds: hasSeek ? seekSeconds : 0,
      }),
    ];
    // 蓝光标题支持按字幕轨烧录预览（?sub=容器轨索引）。
    const subRaw = typeof req.query.sub === "string" ? req.query.sub : "";
    const subIndex = Number(subRaw);
    const hasSub = subRaw !== "" && Number.isInteger(subIndex) && subIndex >= 0;
    let subTypeIndex: number | null = null;
    if (hasSub) {
      const containerIndices =
        await previewService.subtitleContainerIndices(previewSourcePath);
      const found = containerIndices.indexOf(subIndex);
      subTypeIndex = found >= 0 ? found : null;
    }
    transcodeArgs = buildPreviewTranscodeArgs(hasSub, subTypeIndex);
  }
  return streamFfmpegPreview(res, ffmpegExecutable, [
    ...inputArgs,
    ...transcodeArgs,
  ]);
});

router.get("/jobs/:id/preview/raw", async (req, res) => {
  const id = Number(req.params.id);
  const filePath = await resolveJobPreviewFilePath(id);
  if (!filePath) return res.status(404).json({ error: "没有可预览的视频文件" });
  try {
    const stat = await fs.stat(filePath);
    const range = req.headers.range;
    const extension = path.extname(filePath).toLowerCase();
    const contentType =
      extension === ".webm"
        ? "video/webm"
        : extension === ".mkv"
          ? "video/x-matroska"
          : extension === ".ts" || extension === ".m2ts"
            ? "video/mp2t"
            : extension === ".mov"
              ? "video/quicktime"
              : "video/mp4";
    if (!range) {
      res.setHeader("Content-Length", stat.size);
      res.setHeader("Content-Type", contentType);
      return fsSync.createReadStream(filePath).pipe(res);
    }
    const match = range.match(/bytes=(\d*)-(\d*)/);
    if (!match) return res.status(416).end();
    const start = match[1] ? Number(match[1]) : 0;
    const end = match[2]
      ? Math.min(Number(match[2]), stat.size - 1)
      : Math.min(start + 1024 * 1024 - 1, stat.size - 1);
    if (start >= stat.size || end < start) return res.status(416).end();
    res.status(206).set({
      "Content-Range": `bytes ${start}-${end}/${stat.size}`,
      "Accept-Ranges": "bytes",
      "Content-Length": String(end - start + 1),
      "Content-Type": contentType,
    });
    return fsSync.createReadStream(filePath, { start, end }).pipe(res);
  } catch {
    return res.status(404).json({ error: "视频文件不存在或无法读取" });
  }
});

router.get("/jobs/:id/download", async (req, res) => {
  const id = Number(req.params.id);
  const kind =
    req.query.kind === "subtitle"
      ? "subtitlePath"
      : req.query.kind === "translated"
        ? "translatedSubtitlePath"
        : "outputPath";
  const [job] = await db
    .select({
      outputPath: jobsTable.outputPath,
      subtitlePath: jobsTable.subtitlePath,
      translatedSubtitlePath: jobsTable.translatedSubtitlePath,
    })
    .from(jobsTable)
    .where(eq(jobsTable.id, id))
    .limit(1);
  const filePath = job?.[kind];
  if (!filePath) return res.status(404).json({ error: "文件尚未生成" });
  try {
    await fs.access(filePath);
    return res.download(filePath, path.basename(filePath));
  } catch {
    return res.status(404).json({ error: "文件不存在或无法读取" });
  }
});

router.get("/jobs/:id/subtitles", async (req, res) => {
  const id = Number(req.params.id);
  const [job] = await db
    .select({
      filePath: jobsTable.filePath,
      outputPath: jobsTable.outputPath,
      mainTrackPath: jobsTable.mainTrackPath,
      subtitlePath: jobsTable.subtitlePath,
      translatedSubtitlePath: jobsTable.translatedSubtitlePath,
    })
    .from(jobsTable)
    .where(eq(jobsTable.id, id))
    .limit(1);
  if (!job) return res.status(404).json({ error: "任务不存在" });
  const files = await scanJobSubtitleFiles(job);
  // Repair stale DB paths so downloads / later steps point at real files.
  const updates: Partial<typeof jobsTable.$inferInsert> = {};
  const original = files.find((file) => file.kind === "original");
  const translated = files.find((file) => file.kind === "translated");
  if (job.subtitlePath) {
    try {
      await fs.access(job.subtitlePath);
    } catch {
      if (original) updates.subtitlePath = original.path;
    }
  } else if (original) {
    updates.subtitlePath = original.path;
  }
  if (job.translatedSubtitlePath) {
    try {
      await fs.access(job.translatedSubtitlePath);
    } catch {
      if (translated) updates.translatedSubtitlePath = translated.path;
    }
  } else if (translated) {
    updates.translatedSubtitlePath = translated.path;
  }
  if (Object.keys(updates).length > 0) {
    await db
      .update(jobsTable)
      .set(updates)
      .where(eq(jobsTable.id, id))
      .catch(() => {});
  }
  return res.json({
    files,
    subtitlePath: updates.subtitlePath ?? job.subtitlePath,
    translatedSubtitlePath:
      updates.translatedSubtitlePath ?? job.translatedSubtitlePath,
  });
});

router.get("/jobs/:id/subtitle-preview", async (req, res) => {
  const id = Number(req.params.id);
  const fileQuery =
    typeof req.query.file === "string" && req.query.file
      ? req.query.file
      : null;
  if (fileQuery) {
    const [job] = await db
      .select({
        filePath: jobsTable.filePath,
        outputPath: jobsTable.outputPath,
        mainTrackPath: jobsTable.mainTrackPath,
        subtitlePath: jobsTable.subtitlePath,
        translatedSubtitlePath: jobsTable.translatedSubtitlePath,
      })
      .from(jobsTable)
      .where(eq(jobsTable.id, id))
      .limit(1);
    if (!job) return res.status(404).json({ error: "任务不存在" });
    if (path.basename(fileQuery) !== fileQuery || fileQuery.includes("..")) {
      return res.status(400).json({ error: "字幕文件名无效" });
    }
    const dirs = await resolveJobSubtitleDirectories(job);
    for (const dir of dirs) {
      const fullPath = path.join(dir, fileQuery);
      try {
        const stat = await fs.stat(fullPath);
        if (stat.isFile()) {
          const content = await readSubtitleText(fullPath);
          return res.type("text/plain; charset=utf-8").send(content);
        }
      } catch {
        // try next directory
      }
    }
    return res.status(404).json({ error: "字幕文件不存在或无法读取" });
  }
  const kind =
    req.query.kind === "translated" ? "translatedSubtitlePath" : "subtitlePath";
  const [job] = await db
    .select({
      subtitlePath: jobsTable.subtitlePath,
      translatedSubtitlePath: jobsTable.translatedSubtitlePath,
    })
    .from(jobsTable)
    .where(eq(jobsTable.id, id))
    .limit(1);
  const filePath = job?.[kind];
  if (filePath) {
    try {
      const content = await readSubtitleText(filePath);
      return res.type("text/plain; charset=utf-8").send(content);
    } catch {
      // stored path is stale; fall through to directory scan
    }
  }
  const [fullJob] = await db
    .select({
      filePath: jobsTable.filePath,
      outputPath: jobsTable.outputPath,
      mainTrackPath: jobsTable.mainTrackPath,
      subtitlePath: jobsTable.subtitlePath,
      translatedSubtitlePath: jobsTable.translatedSubtitlePath,
    })
    .from(jobsTable)
    .where(eq(jobsTable.id, id))
    .limit(1);
  if (fullJob) {
    const files = await scanJobSubtitleFiles(fullJob);
    const preferredKind =
      kind === "translatedSubtitlePath" ? "translated" : "original";
    const match = files.find((file) => file.kind === preferredKind) ?? files[0];
    if (match) {
      try {
        const content = await fs.readFile(match.path, "utf8");
        return res.type("text/plain; charset=utf-8").send(content);
      } catch {
        // fall through
      }
    }
  }
  return res.status(404).json({ error: "字幕尚未生成" });
});

router.get("/jobs/:id/subtitle-vtt", async (req, res) => {
  const id = Number(req.params.id);
  let embeddedStream =
    req.query.stream != null ? Number(req.query.stream) : null;
  // 未指定字幕轨时自动选用第一条内置文本字幕轨，保证前端叠加层总能拿到字幕。
  if (embeddedStream === null) {
    const [job] = await db
      .select({
        filePath: jobsTable.filePath,
        mainTrackPath: jobsTable.mainTrackPath,
        outputPath: jobsTable.outputPath,
      })
      .from(jobsTable)
      .where(eq(jobsTable.id, id))
      .limit(1);
    const sourceFile = job?.outputPath ?? job?.mainTrackPath ?? job?.filePath;
    if (sourceFile && !/[\\/]$/.test(sourceFile)) {
      const indices = await previewService.subtitleContainerIndices(sourceFile);
      if (indices.length > 0) embeddedStream = indices[0];
    }
  }
  if (embeddedStream !== null) {
    if (!Number.isInteger(embeddedStream) || embeddedStream < 0)
      return res.status(400).json({ error: "字幕轨参数无效" });
    const [job] = await db
      .select({
        filePath: jobsTable.filePath,
        mainTrackPath: jobsTable.mainTrackPath,
        outputPath: jobsTable.outputPath,
      })
      .from(jobsTable)
      .where(eq(jobsTable.id, id))
      .limit(1);
    const sourceFile = job?.outputPath ?? job?.mainTrackPath ?? job?.filePath;
    if (!sourceFile || /[\\/]$/.test(sourceFile))
      return res.status(404).json({ error: "没有可提取的内置字幕源" });
    const sourceFilePath: string = sourceFile;
    const cacheDir = path.join(os.tmpdir(), "MediaSculpt", "subtitle-preview");
    await fs.mkdir(cacheDir, { recursive: true });
    const cacheFile = path.join(
      cacheDir,
      `job-${id}-stream-${embeddedStream}.vtt`,
    );
    try {
      await fs.access(cacheFile);
      return res
        .type("text/vtt; charset=utf-8")
        .send(await fs.readFile(cacheFile, "utf8"));
    } catch {
      // cache miss
    }
    try {
      const ffmpegExecutable =
        (await resolveToolPath("ffmpeg").catch(() => null)) ?? "ffmpeg";
      await new Promise<void>((resolve, reject) => {
        const ff: ChildProcess = processRunner.spawn({
          executable: ffmpegExecutable,
          args: [
            "-y",
            "-i",
            ffmpegPath(sourceFilePath),
            "-map",
            `0:${embeddedStream}`,
            "-f",
            "webvtt",
            ffmpegPath(cacheFile),
          ],
          stage: "subtitle-preview",
          timeoutMs: 120_000,
        }).child;
        let stderr = "";
        ff.stderr?.on("data", (chunk: Buffer) => {
          stderr += chunk.toString();
        });
        ff.on("close", (code) =>
          code === 0
            ? resolve()
            : reject(new Error(stderr.slice(-600) || `ffmpeg exit ${code}`)),
        );
        ff.on("error", reject);
      });
      return res
        .type("text/vtt; charset=utf-8")
        .send(await fs.readFile(cacheFile, "utf8"));
    } catch (error) {
      return res.status(500).json({
        error: `内置字幕轨无法转换为浏览器字幕：${error instanceof Error ? error.message : String(error)}`,
      });
    }
  }
  const kind =
    req.query.kind === "translated" ? "translatedSubtitlePath" : "subtitlePath";
  const [job] = await db
    .select({
      subtitlePath: jobsTable.subtitlePath,
      translatedSubtitlePath: jobsTable.translatedSubtitlePath,
    })
    .from(jobsTable)
    .where(eq(jobsTable.id, id))
    .limit(1);
  const filePath = job?.[kind];
  if (!filePath) return res.status(404).json({ error: "字幕尚未生成" });
  try {
    const content = await readSubtitleText(filePath);
    return res.type("text/vtt; charset=utf-8").send(toWebVtt(content));
  } catch {
    return res.status(404).json({ error: "字幕文件不存在或无法读取" });
  }
});

export const previewRouter = router;
