import fs from "fs/promises";
import os from "os";
import path from "path";
import type { BlurayPlaylistSegment } from "../lib/disc";
import { parseBlurayMpls } from "../lib/disc";
import { buildFfconcatFileContent } from "./jobs-dvd";

export function filterAvailableMplsSegments(
  segments: BlurayPlaylistSegment[],
  availablePaths: Set<string>,
): BlurayPlaylistSegment[] {
  return segments.filter((segment) => availablePaths.has(segment.streamPath));
}

/** Count physical m2ts files once even when a playlist references a clip repeatedly. */
export function sumMplsSegmentSizes(
  segments: BlurayPlaylistSegment[],
  sizes: Map<string, number>,
): number {
  const counted = new Set<string>();
  let total = 0;
  for (const segment of segments) {
    if (counted.has(segment.streamPath)) continue;
    counted.add(segment.streamPath);
    total += sizes.get(segment.streamPath) ?? 0;
  }
  return total;
}

export async function prepareMplsRemuxInput(input: {
  jobId: number;
  sourcePath: string;
  discRoot: string;
  trackTempFile: (filePath: string) => void;
  log: (level: "info" | "warn", message: string) => Promise<unknown>;
  parsePlaylist?: (sourcePath: string, discRoot: string) => Promise<BlurayPlaylistSegment[]>;
  statSegment?: (streamPath: string) => Promise<{ size: number }>;
}): Promise<{ concatListFile: string; remuxExpectedSizeBytes: number }> {
  const parsePlaylist = input.parsePlaylist ?? parseBlurayMpls;
  const statSegment = input.statSegment ?? (async (streamPath: string) => fs.stat(streamPath));
  const segments = await parsePlaylist(input.sourcePath, input.discRoot);
  const sizeMap = new Map<string, number>();
  const availablePaths = new Set<string>();
  for (const segment of segments) {
    if (availablePaths.has(segment.streamPath)) continue;
    try {
      const stat = await statSegment(segment.streamPath);
      availablePaths.add(segment.streamPath);
      sizeMap.set(segment.streamPath, stat.size);
    } catch {
      // A missing m2ts is filtered below instead of producing a broken concat list.
    }
  }
  const existingSegments = filterAvailableMplsSegments(segments, availablePaths);
  if (existingSegments.length === 0) {
    throw new Error(`蓝光 playlist 未找到可用 m2ts 片段：${input.sourcePath}`);
  }
  const remuxExpectedSizeBytes = sumMplsSegmentSizes(existingSegments, sizeMap);
  const concatListFile = path.join(os.tmpdir(), `vx-mpls-${input.jobId}-${Date.now()}.ffconcat`);
  input.trackTempFile(concatListFile);
  await fs.writeFile(concatListFile, buildFfconcatFileContent(existingSegments.map((segment) => segment.streamPath)), "utf8");
  await input.log("info", `蓝光 playlist concat（${existingSegments.length} 个 m2ts 片段）`);
  return { concatListFile, remuxExpectedSizeBytes };
}
