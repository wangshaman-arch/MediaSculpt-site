import { Router } from "express";
import os from "os";
import path from "path";
import fs from "fs/promises";
import { spawn } from "child_process";
import { db, jobsTable, configTable } from "@workspace/db";
import { eq, desc, inArray } from "drizzle-orm";
import { lookupAll, metadataIdentityMatches } from "../lib/metadata";
import { runMetadataSelfCheck, SELF_CHECK_DEFAULT_CASES } from "../lib/metadata-selfcheck";
import { resolveApiKey } from "../lib/ai-provider";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { encryptSecret } from "../lib/secrets";
import { appendRuntimeToolLog } from "../lib/runtime-tool-log";
import { resolveRuntimePath } from "../lib/runtime-paths";
import { addLog, getConfig, redactSecrets, SECRET_FIELDS } from "./jobs";

const router = Router();
router.post("/metadata/lookup", async (req, res) => {
  const { query: rawQuery, year, language = "zh-CN" } = req.body as {
    query?: string;
    year?: number;
    language?: string;
  };

  if (!rawQuery) return res.status(400).json({ error: "查询不能为空" });

  const config = await getConfig();

  const { results: rawResults, errors } = await lookupAll({ rawQuery, year, language, config, proxyUrl: config.posterProxyUrl });
  const results = rawResults.filter((candidate) => metadataIdentityMatches({
    candidate,
    queryTitle: rawQuery,
    queryYear: typeof year === "number" ? year : undefined,
  }));

  // Only fail the request when every configured source failed AND we have
  // nothing to show — a single provider outage must not break lookups.
  if (results.length === 0 && errors.length > 0) {
    return res.status(502).json({ error: `元数据查询失败：${errors.join("；")}` });
  }
  return res.json(results);
});

// GET /metadata/selfcheck — read-only diagnostic for the metadata sources.
//
// Exists so source quality is reproducible on the user's own machine rather than
// asserted by a developer: it reports which sources are usable, and for each
// sample title whether a candidate was found, rejected by the identity gate, or
// absent. Optional `?query=` (repeatable) replaces the default sample set.
router.get("/metadata/selfcheck", async (req, res) => {
  const config = await getConfig();
  const rawQuery = req.query.query;
  const requested = (Array.isArray(rawQuery) ? rawQuery : rawQuery ? [rawQuery] : [])
    .map((value) => String(value).trim())
    .filter(Boolean)
    .slice(0, 10);
  const cases = requested.length > 0
    ? requested.map((query) => ({ query }))
    : SELF_CHECK_DEFAULT_CASES;
  try {
    const report = await runMetadataSelfCheck({
      cases,
      // `resolveApiKey` covers every configured provider, so a DeepSeek-only
      // setup correctly reports the AI tier as available.
      config: { ...config, aiAvailable: Boolean(resolveApiKey(config)) },
      proxyUrl: config.posterProxyUrl ?? null,
    });
    return res.json(report);
  } catch (error) {
    return res.status(500).json({ error: `自检失败：${error instanceof Error ? error.message : String(error)}` });
  }
});

// GET /stats
router.get("/stats", async (_req, res) => {
  type StatsRow = {
    status: string;
    processingMode: string;
    fileSizeBefore: number | null;
    fileSizeAfter: number | null;
  };
  const rows = await db.select({
    status: jobsTable.status,
    processingMode: jobsTable.processingMode,
    fileSizeBefore: jobsTable.fileSizeBefore,
    fileSizeAfter: jobsTable.fileSizeAfter,
  }).from(jobsTable) as StatsRow[];

  const compressibleRows = rows.filter((row) => (
    row.processingMode !== "remux" &&
    typeof row.fileSizeBefore === "number" &&
    typeof row.fileSizeAfter === "number" &&
    row.fileSizeBefore > 0 &&
    row.fileSizeAfter >= 0
  ));
  const savedRows = compressibleRows.filter((row) => row.fileSizeBefore! > row.fileSizeAfter!);
  const totalSavedBytes = savedRows.reduce((sum, row) => sum + (row.fileSizeBefore! - row.fileSizeAfter!), 0);
  const avgCompressionRatio = compressibleRows.length > 0
    ? compressibleRows.reduce((sum, row) => sum + row.fileSizeAfter! / row.fileSizeBefore!, 0) / compressibleRows.length
    : 0;

  return res.json({
    totalJobs: rows.length,
    pending: rows.filter((row) => row.status === "pending").length,
    running: rows.filter((row) => ["scanning", "transcribing", "compressing", "remuxing"].includes(row.status)).length,
    done: rows.filter((row) => row.status === "done").length,
    error: rows.filter((row) => row.status === "error").length,
    totalSavedBytes,
    avgCompressionRatio,
  });
});

// GET /stats/recent
router.get("/stats/recent", async (req, res) => {
  const limit = parseInt(String(req.query.limit ?? "10"));
  const rows = await db.select()
    .from(jobsTable)
    .where(eq(jobsTable.status, "done"))
    .orderBy(desc(jobsTable.completedAt))
    .limit(isNaN(limit) ? 10 : limit);

  return res.json(rows);
});

// GET /system-logs — read the single root diagnostics log used by Windows launchers and API jobs
router.get("/system-logs", async (_req, res) => {
  // 与写入方（runtime-tool-log.ts）保持同一优先级与默认值，避免改名后
  // “写到 mediasculpt-*、读到 vx-agent-*”导致日志页面显示为空。
  const diagnosticsLog = process.env.MEDIASCULPT_DIAGNOSTICS_LOG ?? process.env.VX_AGENT_DIAGNOSTICS_LOG
    ?? path.resolve(process.cwd(), "..", "..", "mediasculpt-diagnostics.log");
  const serviceLogDir = process.env.MEDIASCULPT_SERVICE_LOG_DIR ?? process.env.VX_AGENT_SERVICE_LOG_DIR
    ?? path.join(os.tmpdir(), "MediaSculpt", "logs");
  async function readLogTail(filePath: string): Promise<string> {
    try {
      const content = await fs.readFile(filePath, "utf-8");
      const lines = content.split(/\r?\n/);
      return lines.slice(-400).join("\n");
    } catch {
      return "";
    }
  }
  const sections: string[] = [];
  const files: Array<{ name: string; content: string }> = [];
  const rootDiagnostics = await readLogTail(diagnosticsLog);
  if (rootDiagnostics.trim()) {
    sections.push(rootDiagnostics);
    files.push({ name: "diagnostics", content: rootDiagnostics });
  }
  try {
    const serviceFiles = (await fs.readdir(serviceLogDir))
      .filter((name) => name.endsWith(".log"))
      .sort();
    for (const name of serviceFiles) {
      const content = await readLogTail(path.join(serviceLogDir, name));
      if (content.trim()) {
        sections.push(`===== ${name} =====\n${content}`);
        files.push({ name, content });
      }
    }
  } catch {
    // Runtime service logs may not exist before the services start.
  }
  const diagnostics = sections.join("\n\n");
  return res.json({ diagnosticsLog, diagnostics, files });
});

// PATCH /jobs/:id/ai-options — AI generation toggles for one job.
router.patch("/jobs/:id/ai-options", async (req, res) => {
  const id = Number(req.params.id);
  const updates: Partial<typeof jobsTable.$inferInsert> = {};
  const pick = (key: "generateReadme" | "generatePoster" | "generateReview") => {
    if (typeof req.body?.[key] === "boolean") updates[key] = req.body[key];
  };
  pick("generateReadme");
  pick("generatePoster");
  pick("generateReview");
  if (Object.keys(updates).length === 0) return res.status(400).json({ error: "未提供任何 AI 选项" });
  const [job] = await db.select({ id: jobsTable.id }).from(jobsTable).where(eq(jobsTable.id, id)).limit(1);
  if (!job) return res.status(404).json({ error: "任务不存在" });
  await db.update(jobsTable).set(updates).where(eq(jobsTable.id, id));
  return res.json({ id, ...updates });
});

// PATCH /jobs/:id/subtitle-mode — 任务详情页可鼠标修改队列任务的字幕策略。
router.patch("/jobs/:id/subtitle-mode", async (req, res) => {
  const id = Number(req.params.id);
  const mode = req.body?.subtitleMode;
  const allowed = ["auto", "extract", "whisper", "transcribe_translate", "skip", "ocr", "bilingual"];
  if (typeof mode !== "string" || !allowed.includes(mode)) {
    return res.status(400).json({ error: "subtitleMode 无效（auto/extract/whisper/transcribe_translate/skip/ocr/bilingual）" });
  }
  const [job] = await db.select({ id: jobsTable.id, status: jobsTable.status }).from(jobsTable).where(eq(jobsTable.id, id)).limit(1);
  if (!job) return res.status(404).json({ error: "任务不存在" });
  if (["scanning", "transcribing", "compressing", "remuxing"].includes(job.status)) {
    return res.status(409).json({ error: "任务运行中，字幕模式不可修改" });
  }
  await db.update(jobsTable).set({ subtitleMode: mode }).where(eq(jobsTable.id, id));
  await addLog(id, "info", `任务字幕模式已改为：${mode}`);
  return res.json({ id, subtitleMode: mode });
});

// POST /jobs/ai-options/apply-all — apply AI generation toggles to all queued jobs.
router.post("/jobs/ai-options/apply-all", async (req, res) => {
  const updates: Partial<typeof jobsTable.$inferInsert> = {};
  const pick = (key: "generateReadme" | "generatePoster" | "generateReview") => {
    if (typeof req.body?.[key] === "boolean") updates[key] = req.body[key];
  };
  pick("generateReadme");
  pick("generatePoster");
  pick("generateReview");
  if (Object.keys(updates).length === 0) return res.status(400).json({ error: "未提供任何 AI 选项" });
  const rows = await db.select({ id: jobsTable.id }).from(jobsTable).where(inArray(jobsTable.status, ["pending", "queued"]));
  for (const row of rows) {
    await db.update(jobsTable).set(updates).where(eq(jobsTable.id, row.id));
  }
  return res.json({ applied: rows.length, ...updates });
});

// GET /config
router.get("/config", async (_req, res) => {
  const config = await getConfig();
  return res.json(redactSecrets(config as Record<string, unknown>));
});

router.post("/runtime/open-path", async (req, res) => {
  const rawPath = typeof req.body?.path === "string" ? req.body.path : "";
  if (!rawPath.trim()) return res.status(400).json({ error: "路径为空" });

  const config = await getConfig();
  const runtimePath = resolveRuntimePath(rawPath, config);
  try {
    const openTarget = await resolveExistingOpenDirectory(runtimePath);

    const windowsTarget = `"${openTarget.replace(/"/g, '""')}"`;
    const openers = process.platform === "win32"
      ? [
          // explorer.exe is the primary opener: it reliably surfaces a window even
          // when the API runs as a hidden background process. "cmd /c start" can
          // spawn successfully without actually showing Explorer, so it is only a
          // fallback here.
          { command: "explorer.exe", args: [openTarget] },
          { command: process.env.ComSpec || "cmd.exe", args: ["/d", "/c", "start", "", windowsTarget] },
        ]
      : [process.platform === "darwin"
        ? { command: "open", args: [openTarget] }
        : { command: "xdg-open", args: [openTarget] }];

    await appendRuntimeToolLog(`打开文件夹：raw=${rawPath} runtime=${runtimePath} target=${openTarget} openers=${JSON.stringify(openers)}`).catch(() => {});
    const launch = (command: string, args: string[]) => new Promise<void>((resolve, reject) => {
      const child = spawn(command, args, { detached: true, stdio: "ignore", windowsHide: true });
      child.once("error", reject);
      child.once("spawn", () => { child.unref(); resolve(); });
    });
    let launchError: unknown = null;
    for (const opener of openers) {
      try {
        await launch(opener.command, opener.args);
        launchError = null;
        break;
      } catch (error) {
        launchError = error;
      }
    }
    if (launchError) throw launchError;
    return res.json({ ok: true, path: openTarget });
  } catch (error) {
    return res.status(500).json({ error: `无法打开路径：${error instanceof Error ? error.message : String(error)}` });
  }
});

// PUT /config
router.put("/config", async (req, res) => {
  const config = await getConfig();

  // IMPORTANT: Drizzle .set() requires the camelCase JS property names from the schema,
  // NOT the SQL snake_case column names.  Passing snake_case keys is silently ignored.
  const allowedFields = [
    "watchDirectory", "outputDirectory", "remuxOutputDirectory", "subtitleDirectory", "hostDownloadsPath",
    "outputNameTemplate",
    "posterMirrorUrl", "posterProxyUrl",
    "hostOutputPath", "handbrakePreset", "whisperModel", "subtitleLanguage", "crf",
    "encoder", "audioCopy", "outputFormat", "handbrakeCliPath", "subtitleEditCliPath",
    "tmdbApiKey", "openaiApiKey", "deepseekApiKey", "siliconflowApiKey", "zhipuApiKey",
    "moonshotApiKey", "qwenApiKey", "groqApiKey", "geminiApiKey", "aiTranslationEnabled",
    "translationTargetLang", "aiProvider", "aiBaseUrl", "aiModel", "libreTranslateUrl",
    "ocrBilingualCorrection", "aiMetadataEnrichment",
    "bilingualLayout", "bilingualOutlineWidth", "bilingualShadowWidth", "bilingualOutlineColor",
    "bilingualFontSizeTop", "bilingualFontSizeBottom",
    "processHighPriority", "shutdownAfterComplete", "frameRate", "encoderPreset",
    "outputResolution", "encoderTune", "encoderProfile", "encoderLevel", "uiLanguage", "themeMode",
    "omdbApiKey", "deinterlace", "customTuning",
  ] as const;

  const updates: Partial<typeof configTable.$inferInsert> = {};
  for (const field of allowedFields) {
    if (field in req.body) {
      (updates as Record<string, unknown>)[field] = req.body[field];
    }
  }
  // 密钥字段：非空值加密后落库；空值表示“保持不变”，避免误删已配置的 Key
  for (const field of SECRET_FIELDS) {
    if (field in updates) {
      const value = (updates as Record<string, unknown>)[field];
      if (typeof value === "string" && value.trim()) {
        (updates as Record<string, unknown>)[field] = await encryptSecret(value);
      } else {
        delete (updates as Record<string, unknown>)[field];
      }
    }
  }

  if (Object.keys(updates).length === 0) {
    return res.json(redactSecrets(config as Record<string, unknown>));
  }

  await db.update(configTable).set(updates).where(eq(configTable.id, config.id));
  const [updated] = await db.select().from(configTable).where(eq(configTable.id, config.id));
  return res.json(redactSecrets(updated as Record<string, unknown>));
});

export const adminRouter = router;
