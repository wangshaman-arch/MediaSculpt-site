import path from "path";
import type { BlurayPlaylistSegment } from "../lib/disc";

const MPLS_TIME_HZ = 45_000;

export type BluraySegmentDurationResult = {
  segments: BlurayPlaylistSegment[];
  durations: Array<number | null>;
  playlistDuration: number | null;
  keptDurationSeconds: number;
  trimmedSegments: BlurayPlaylistSegment[];
};

/** Convert the playlist's 45 kHz timestamp range into seconds. */
export function calculateBlurayPlaylistDurationSeconds(
  segments: BlurayPlaylistSegment[],
): number | null {
  const totalTicks = segments.reduce(
    (sum, segment) => sum + Math.max(0, segment.outTime45k - segment.inTime45k),
    0,
  );
  return totalTicks > 0 ? totalTicks / MPLS_TIME_HZ : null;
}

/**
 * Keep the playlist's content order while removing only very short trailing
 * clips, which are commonly logos or studio splash frames.
 */
export function trimTrailingShortBluraySegments(
  segments: BlurayPlaylistSegment[],
  durations: Array<number | null>,
): { segments: BlurayPlaylistSegment[]; trimmedSegments: BlurayPlaylistSegment[]; keptDurationSeconds: number } {
  let endTrimCount = 0;
  const measuredTotal = durations.reduce<number>((sum, duration) => sum + (duration ?? 0), 0);
  if (segments.length > 1 && measuredTotal > 0) {
    const threshold = Math.min(60, measuredTotal * 0.02);
    while (segments.length - endTrimCount > 1) {
      const index = segments.length - 1 - endTrimCount;
      const duration = durations[index] ?? 0;
      if (duration > 0 && duration < threshold) {
        endTrimCount += 1;
      } else {
        break;
      }
    }
  }

  const keptSegments = endTrimCount > 0
    ? segments.slice(0, segments.length - endTrimCount)
    : segments;
  const trimmedSegments = endTrimCount > 0
    ? segments.slice(segments.length - endTrimCount).reverse()
    : [];
  const keptDurationSeconds = keptSegments.reduce(
    (sum, _segment, index) => sum + (durations[index] ?? 0),
    0,
  );

  return { segments: keptSegments, trimmedSegments, keptDurationSeconds };
}

/** Probe physical m2ts durations and apply the playlist boundary policy. */
export async function probeAndTrimBluraySegments(input: {
  segments: BlurayPlaylistSegment[];
  probeDuration: (streamPath: string) => Promise<number | null>;
  log?: (message: string) => Promise<unknown>;
}): Promise<BluraySegmentDurationResult> {
  const originalSegments = input.segments;
  const playlistDuration = calculateBlurayPlaylistDurationSeconds(originalSegments);
  let durations: Array<number | null> = [];
  let segments = originalSegments;
  let keptDurationSeconds = playlistDuration ?? 0;
  let trimmedSegments: BlurayPlaylistSegment[] = [];

  if (originalSegments.length > 1) {
    durations = [];
    for (const segment of originalSegments) {
      try {
        durations.push(await input.probeDuration(segment.streamPath));
      } catch {
        durations.push(null);
      }
    }

    const measuredTotal = durations.reduce<number>((sum, duration) => sum + (duration ?? 0), 0);
    if (measuredTotal > 0) {
      const trimmed = trimTrailingShortBluraySegments(originalSegments, durations);
      segments = trimmed.segments;
      trimmedSegments = trimmed.trimmedSegments;
      keptDurationSeconds = trimmed.keptDurationSeconds;
      if (keptDurationSeconds > 0) {
        for (const segment of trimmedSegments) {
          const index = originalSegments.indexOf(segment);
          const duration = durations[index] ?? 0;
          await input.log?.(`已跳过片尾极短片段：${path.basename(segment.streamPath)}（${duration.toFixed(2)} 秒）`);
        }
      }
    }
  }

  return {
    segments,
    durations,
    playlistDuration: keptDurationSeconds > 0 ? keptDurationSeconds : playlistDuration,
    keptDurationSeconds,
    trimmedSegments,
  };
}
