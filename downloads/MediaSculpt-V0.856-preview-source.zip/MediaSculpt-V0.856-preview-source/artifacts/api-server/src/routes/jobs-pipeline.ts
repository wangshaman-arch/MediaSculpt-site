// Extracted from routes/jobs.ts: pipeline parsing, viability checks and OCR progress helpers.
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { lookupAll, metadataIdentityMatches, normalizeTitleEn } from "../lib/metadata";
import { servePreviewSegment, cleanupPreviewSegments } from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import { buildFfconcatFileContent as buildManifest, buildFfconcatChapterContent, buildFfconcatTimedContent, type FfconcatTimedSegment } from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import { appendJobRuntimeLog, appendJobToolOutput } from "../lib/job-runtime-log";
import { appendRuntimeToolLog, appendRuntimeToolOutput } from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import { buildCompressionOutputName, buildRemuxOutputName, cleanSegment, encoderBitDepth, selectBestAudioTrack } from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import { renderBilingualAss, DEFAULT_BILINGUAL_STYLE, type BilingualAssStyle, type SubtitleBlock } from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import { ensureLocalPoster, MEDIA_INFO_DIR, POSTER_META_FILE, posterIdentityMatches } from "../lib/poster";
import { ensureFasterWhisperModel, ensureWhisperCliScript } from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import { hasValidSubtitleCues, isGraphicSubtitleCodec, shouldFallbackToWhisper } from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import { buildDvdRemuxArgs, runDvdRemux, verifyDvdTitle } from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import { buildDvdStructurePayload, resolveRemuxPlanWithLlm, validateRemuxPlan } from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import { assertPreviewTaskAllowed, recordPreviewAiCall, settlePreviewTask } from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import { parseCustomTuning, resolveLogicPlaceholders } from "../lib/custom-tuning";
import { decryptSecret, encryptSecret, isEncryptedSecret } from "../lib/secrets";
import { ffmpegPath, resolveOutputDir, resolveRuntimePath, type RuntimePathConfig } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import { assertCompleteMediaTitle, createDvdMediaTitle } from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import { buildPreviewTranscodeArgs, isPreviewVideoCandidate, previewService } from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";

export function parseTaskSnapshotIndexArray(raw: string | undefined): number[] | null {
  if (raw === undefined) return null;
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed) || parsed.some((item) => !Number.isInteger(item) || item < 0)) {
      throw new Error("not an index array");
    }
    return Array.from(new Set(parsed as number[])).sort((a, b) => a - b);
  } catch {
    throw new TaskSnapshotError("TASK_SNAPSHOT_INVALID");
  }
}

export function defaultTaskSnapshotOutputMode(input: { processingMode: string; subtitleMode: string }): TaskSnapshotOutputMode {
  if (input.processingMode === "remux") return "remux";
  // 章节预览为独立模式；快照仍按 compress 占位构建（执行阶段完全独立，不使用快照的输出设置）。
  if (input.processingMode === "chapterPreview") return "compress";
  if (input.processingMode === "none") {
    return input.subtitleMode === "whisper" || input.subtitleMode === "transcribe_translate" ? "whisper" : "subtitle";
  }
  return "compress";
}

export type BlockedReasonCode = "no-video" | "no-subtitle-track" | "no-audio-track";

/**
 * 执行前可执行性检查：任务所需模式缺少对应流轨时，不启动工具，直接标记
 * “不可执行 + 原因”，队列继续启动下一个任务（不阻塞整批）。
 * errorMessage 使用稳定前缀 `VX_BLOCKED:<code>`，前端据此显示徽标与本地化原因。
 */
export function validateJobViability(
  job: { processingMode?: string | null; subtitleMode?: string | null },
  streams: { video: boolean; audio: boolean; subtitle: boolean },
): { ok: true } | { ok: false; code: BlockedReasonCode } {
  const mode = job.processingMode ?? "compress";
  if ((mode === "remux" || mode === "compress") && !streams.video) {
    return { ok: false, code: "no-video" };
  }
  let subMode = job.subtitleMode ?? "auto";
  if (subMode === "bilingual") subMode = "auto";
  if ((subMode === "extract" || subMode === "ocr") && !streams.subtitle) {
    return { ok: false, code: "no-subtitle-track" };
  }
  if ((subMode === "whisper" || subMode === "transcribe_translate") && !streams.audio) {
    return { ok: false, code: "no-audio-track" };
  }
  return { ok: true };
}

export function blockedReasonMessage(code: BlockedReasonCode): string {
  switch (code) {
    case "no-video": return "该轨道没有可用视频流，无法执行压缩/Remux";
    case "no-subtitle-track": return "该轨道没有可用字幕轨，无法执行字幕提取/OCR";
    case "no-audio-track": return "该轨道没有可用音轨，无法执行语音识别/字幕翻译";
  }
}

export type WorkflowPipelineStep = "remux" | "subtitle" | "compress" | "chapterPreview";
export type PipelineNames = { remux?: string | null; compress?: string | null };

/** Parse the ordered pipeline persisted on a job row (column pipeline_steps). */
export function parsePipelineSteps(job: { pipelineSteps?: string | null }): WorkflowPipelineStep[] {
  if (!job.pipelineSteps) return [];
  try {
    const parsed = JSON.parse(job.pipelineSteps) as { steps?: unknown } | WorkflowPipelineStep[] | null;
    const raw = Array.isArray(parsed)
      ? parsed
      : Array.isArray(parsed?.steps)
        ? parsed.steps
        : [];
    return Array.from(new Set(raw.filter((step): step is WorkflowPipelineStep => step === "remux" || step === "subtitle" || step === "compress" || step === "chapterPreview")));
  } catch {
    return [];
  }
}

/** Parse the per-stage output names persisted on the same job row. */
export function parsePipelineNames(job: { pipelineSteps?: string | null }): PipelineNames {
  if (!job.pipelineSteps) return {};
  try {
    const parsed = JSON.parse(job.pipelineSteps) as { names?: Record<string, unknown> };
    const names = parsed && typeof parsed === "object" && "names" in parsed ? parsed.names : {};
    return {
      remux: typeof names?.remux === "string" && names.remux.trim() ? names.remux.trim() : null,
      compress: typeof names?.compress === "string" && names.compress.trim() ? names.compress.trim() : null,
    };
  } catch {
    return {};
  }
}

/** Validate and normalize the pipeline requested at job creation. */
export function normalizePipelineSteps(raw: unknown, mediaType: string): WorkflowPipelineStep[] {
  if (!Array.isArray(raw)) return [];
  let steps = Array.from(new Set(raw.filter((step): step is WorkflowPipelineStep => step === "remux" || step === "subtitle" || step === "compress" || step === "chapterPreview")));
  // 章节预览是独立互斥模式：不与其他步骤混用。
  if (steps.includes("chapterPreview")) steps = ["chapterPreview"];
  const isDisc = mediaType === "dvd" || mediaType === "bluray" || mediaType === "iso";
  // 视频文件不支持 Remux：多选时按“压缩为主 + 按需字幕”处理
  return isDisc ? steps : steps.filter((step) => step !== "remux");
}

/** Resolve the HandBrake title number frozen in a disc job's task snapshot for OCR. */
export function ocrTitleIdForTaskSnapshot(taskSnapshot: {
  selectedTitleId?: string | null;
  toolSelections?: { handbrakeTitleNumber?: number | null };
} | null | undefined): string | null {
  if (!taskSnapshot) return null;
  const handbrakeTitle = taskSnapshot.toolSelections?.handbrakeTitleNumber;
  if (typeof handbrakeTitle === "number" && handbrakeTitle > 0) return String(handbrakeTitle);
  const raw = taskSnapshot.selectedTitleId ?? "";
  const match = /^handbrake:(\d+)$/.exec(raw);
  if (match) return match[1];
  if (/^\d+$/.test(raw)) return raw;
  return null;
}

/** Map OCR progress messages onto the job progress bar (0-100). */
export function ocrProgressPercent(message: string, current: number): number {
  if (/探测|扫描|检测/.test(message)) return Math.max(current, 5);
  if (/提取|转码|HandBrake/.test(message)) return Math.max(current, 15);
  if (/解码|就绪/.test(message)) return Math.max(current, 35);
  if (/解析到/.test(message)) return Math.max(current, 45);
  if (/识别/.test(message)) return Math.max(current, 60);
  if (/完成/.test(message)) return 100;
  return current;
}

