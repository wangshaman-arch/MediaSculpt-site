import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { lookupAll, metadataIdentityMatches, normalizeTitleEn } from "../lib/metadata";
import { servePreviewSegment, cleanupPreviewSegments } from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import { buildFfconcatFileContent as buildManifest, buildFfconcatChapterContent, buildFfconcatTimedContent, type FfconcatTimedSegment } from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import { appendJobRuntimeLog, appendJobToolOutput } from "../lib/job-runtime-log";
import { appendRuntimeToolLog, appendRuntimeToolOutput } from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import { buildCompressionOutputName, buildRemuxOutputName, cleanSegment, encoderBitDepth, selectBestAudioTrack } from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import { renderBilingualAss, DEFAULT_BILINGUAL_STYLE, type BilingualAssStyle, type SubtitleBlock } from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import { ensureLocalPoster, MEDIA_INFO_DIR, POSTER_META_FILE, posterIdentityMatches } from "../lib/poster";
import { ensureFasterWhisperModel, ensureWhisperCliScript } from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import { hasValidSubtitleCues, isGraphicSubtitleCodec, shouldFallbackToWhisper } from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import { buildDvdRemuxArgs, runDvdRemux, verifyDvdTitle } from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import { buildDvdStructurePayload, resolveRemuxPlanWithLlm, validateRemuxPlan } from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import { assertPreviewTaskAllowed, recordPreviewAiCall, settlePreviewTask } from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import { parseCustomTuning, resolveLogicPlaceholders } from "../lib/custom-tuning";
import { decryptSecret, encryptSecret, isEncryptedSecret } from "../lib/secrets";
import { ffmpegPath, resolveOutputDir, resolveRuntimePath, type RuntimePathConfig } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import { assertCompleteMediaTitle, createDvdMediaTitle } from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import { buildPreviewTranscodeArgs, isPreviewVideoCandidate, previewService } from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";
import { previewRouter } from "./jobs-preview";
import { discRouter } from "./disc";
import { adminRouter } from "./admin";
import { jobsCrudRouter } from "./jobs-crud";
import { processJob } from "./job-orchestrator";

import { SOURCE_DIRECTORY_VALUE, isSourceDirectoryValue, resolveJobOutputDirectory, validateWritableDirectory, outputDirectoryForTask, resolveJobSubtitleDirectory, ensureDirectory, describeFfmpegExecutable, sourceDirectoryForJob } from "./jobs-output-paths";
export { SOURCE_DIRECTORY_VALUE, isSourceDirectoryValue, resolveJobOutputDirectory, validateWritableDirectory, outputDirectoryForTask, resolveJobSubtitleDirectory, ensureDirectory, sourceDirectoryForJob, describeFfmpegExecutable } from "./jobs-output-paths";

import { resolveJobSubtitleDirectories, scanJobSubtitleFiles, SUBTITLE_FILE_EXT_RE } from "./jobs-subtitle-files";
export { resolveJobSubtitleDirectories, scanJobSubtitleFiles, SUBTITLE_FILE_EXT_RE } from "./jobs-subtitle-files";

import { ffmpegCmd, ffprobeCmd, dvdInputArg, ensureDvdCssSupport, dvdVideoInputPath, buildFfconcatFileContent, writeDvdConcatListFile, dvdConcatInputArgs, isVobConcatList, dvdTitleNavigationInputArgs, ffmpegSupportsDvdTitleNavigation, dvdNavigationTitleWithVerifiedNumber, assertDvdTitleComplete, buildDvdTypeMaps, withDvdConcatList } from "./jobs-dvd";
export { ffmpegCmd, ffprobeCmd, dvdInputArg, ensureDvdCssSupport, dvdVideoInputPath, buildFfconcatFileContent, writeDvdConcatListFile, dvdConcatInputArgs, isVobConcatList, dvdTitleNavigationInputArgs, ffmpegSupportsDvdTitleNavigation, dvdNavigationTitleWithVerifiedNumber, assertDvdTitleComplete, buildDvdTypeMaps, withDvdConcatList } from "./jobs-dvd";
import { verifyOutputEndPlayable, snapshotTitleIndex, runFfmpegCapture } from "./jobs-ffmpeg-run";
export { verifyOutputEndPlayable, snapshotTitleIndex, runFfmpegCapture } from "./jobs-ffmpeg-run";

import { mountBlurayIso, unmountBlurayIso, registerIsoMount, unmountAllIsoMounts, ensureAnalysisIsoReady } from "./jobs-iso";
export { mountBlurayIso, unmountBlurayIso, registerIsoMount, unmountAllIsoMounts, ensureAnalysisIsoReady } from "./jobs-iso";

import { cancelledJobs, setQueuePaused, isQueuePaused, trackJobOutputFile, clearJobOutputFiles, removeIncompleteJobOutputs, killJobProcesses } from "./jobs-tracking";
export { cancelledJobs, setQueuePaused, isQueuePaused, trackJobOutputFile, clearJobOutputFiles, removeIncompleteJobOutputs, killJobProcesses } from "./jobs-tracking";
import { tryDirectBilingualMerge, buildBilingualSubtitle } from "./jobs-bilingual";
export { tryDirectBilingualMerge, buildBilingualSubtitle } from "./jobs-bilingual";
const router = Router();
export const discAnalysisCache = new DiscAnalysisCache<DiscAnalysisResult>();
export const discAnalysisRegistry = new DiscAnalysisRegistry();
export type DvdVerificationResult = Awaited<ReturnType<typeof verifyDvdTitle>>;
export const dvdTitleVerificationInFlight = new Map<string, Promise<DvdVerificationResult>>();
export const dvdTitleVerificationCache = new Map<string, { verification: DvdVerificationResult; cachedAt: number }>();
export const DVD_VERIFICATION_CACHE_TTL_MS = 10 * 60_000;

// Kept as a narrow internal seam for the /disc/analyze → POST /jobs hand-off.
// It does not scan, reorder, or infer titles; callers can only register a completed analysis.
export function registerDiscAnalysisForTaskCreation(analysis: DiscAnalysisResult): void {
  discAnalysisRegistry.remember(analysis);
}

export const VIDEO_EXTENSIONS = [".mkv", ".mp4", ".avi", ".mov", ".wmv", ".flv", ".m4v", ".ts", ".m2ts", ".iso", ".vob"];
export const SUBTITLE_EXTENSIONS = [".srt", ".ass", ".ssa", ".sub", ".vtt"];

// ─── Disc detection helpers ───────────────────────────────────────────────────

/** Check if a directory is a Blu-ray disc root (contains BDMV subfolder) */
export async function isBlurayDisc(dir: string): Promise<boolean> {
  return isBlurayDiscSource(dir);

  try {
    const stat = await fs.stat(path.join(dir, "BDMV", "index.bdmv"));
    return stat.isFile();
  } catch { return false; }
}

/** Check if a directory is a DVD disc root (contains VIDEO_TS subfolder with IFO file) */
export async function isDvdDisc(dir: string): Promise<boolean> {
  return isDvdDiscSource(dir);

  try {
    const stat = await fs.stat(path.join(dir, "VIDEO_TS", "VIDEO_TS.IFO"));
    return stat.isFile();
  } catch { return false; }
}

/** Resolve the primary track path for a disc source */
export async function resolveMainTrack(discPath: string, mediaType: string): Promise<string> {
  return resolveDiscMainTrack(discPath, mediaType);

  if (mediaType === "bluray") {
    const streamDir = path.join(discPath, "BDMV", "STREAM");
    try {
      const entries = await fs.readdir(streamDir);
      const m2tsFiles = entries.filter(f => f.toLowerCase().endsWith(".m2ts"));
      const withSizes = await Promise.all(m2tsFiles.map(async f => {
        const s = await fs.stat(path.join(streamDir, f));
        return { path: path.join(streamDir, f), size: s.size };
      }));
      withSizes.sort((a, b) => b.size - a.size);
      return withSizes[0]?.path ?? discPath;
    } catch { return discPath; }
  }
  if (mediaType === "dvd") {
    return path.join(discPath, "VIDEO_TS");
  }
  return discPath; // ISO — ffmpeg reads directly with libbluray/libdvdread
}

import { probeStreams, probeVideoPlayRes, detectInterlacedFromStreams, probeDvdTitleByNumber, probeMediaStreams } from "./jobs-probe";
export { probeStreams, probeVideoPlayRes, detectInterlacedFromStreams, probeDvdTitleByNumber, probeMediaStreams } from "./jobs-probe";

export function toWebVtt(content: string): string {
  const normalized = content
    .replace(/^\uFEFF/, "")
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n");
  return /^WEBVTT\b/.test(normalized)
    ? normalized
    : `WEBVTT\n\n${normalized
      .replace(/^\d+\n(?=\d{2}:\d{2}:\d{2}[,.]\d{3}\s+-->\s+)/gm, "")
      .replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, "$1.$2")}`;
}

/** 读取字幕文件并统一为 UTF-8：UTF-8 直读，非法 UTF-8（GBK/GB2312 等）按 GB18030 解码。 */
export async function readSubtitleText(filePath: string): Promise<string> {
  const buffer = await fs.readFile(filePath);
  if (buffer.length >= 3 && buffer[0] === 0xef && buffer[1] === 0xbb && buffer[2] === 0xbf) {
    return buffer.subarray(3).toString("utf8");
  }
  const utf8 = buffer.toString("utf8");
  if (!utf8.includes("\uFFFD")) return utf8;
  try {
    return new TextDecoder("gb18030").decode(buffer);
  } catch {
    return utf8;
  }
}

/** Build ffmpeg -map args from selected stream index array (null = all) */

const WHISPER_LANG_ALIASES: Record<string, string> = {
  english: "en", chinese: "zh", french: "fr", german: "de", spanish: "es",
  japanese: "ja", korean: "ko", italian: "it", portuguese: "pt", russian: "ru",
  dutch: "nl", polish: "pl", turkish: "tr", arabic: "ar", thai: "th",
  vietnamese: "vi", indonesian: "id", ukrainian: "uk", czech: "cs",
  swedish: "sv", norwegian: "no", danish: "da", finnish: "fi", greek: "el",
  hebrew: "he", hindi: "hi", hungarian: "hu", romanian: "ro",
};

export function whisperDetectedLanguage(stderr: string): string | null {
  const match = /Detected language:\s*(\w+)/i.exec(stderr);
  if (!match) return null;
  const raw = match[1].trim().toLowerCase();
  if (/^[a-z]{2}$/.test(raw)) return raw;
  return WHISPER_LANG_ALIASES[raw] ?? null;
}

export async function addLog(jobId: number, level: "info" | "warn" | "error", message: string) {
  await db.insert(jobLogsTable).values({ jobId, level, message });
  await appendJobRuntimeLog(jobId, level, message).catch(() => {});
}

export async function settlePreviewTaskSafely(jobId: number, input: Omit<PreviewJobSettlementInput, "jobId">): Promise<void> {
  try {
    const result = await settlePreviewTask({ jobId, ...input });
    if (input.outputValid && !input.cancelled && !input.isPreviewOnly && !result.charged) {
      await addLog(jobId, "warn", "预览版任务已完成，但本次成功任务记录未写入（可能已重复结算或额度在并发任务中已用尽）");
    }
  } catch (error) {
    // Output validation already passed. A local entitlement write failure must
    // not turn a completed media job into a false processing failure.
    await addLog(jobId, "warn", `预览版成功任务记录失败：${error instanceof Error ? error.message : String(error)}`).catch(() => {});
  }
}

import { parseTaskSnapshotIndexArray, defaultTaskSnapshotOutputMode, validateJobViability, blockedReasonMessage, parsePipelineSteps, parsePipelineNames, normalizePipelineSteps, ocrTitleIdForTaskSnapshot, ocrProgressPercent } from "./jobs-pipeline";
export { parseTaskSnapshotIndexArray, defaultTaskSnapshotOutputMode, validateJobViability, blockedReasonMessage, parsePipelineSteps, parsePipelineNames, normalizePipelineSteps, ocrTitleIdForTaskSnapshot, ocrProgressPercent } from "./jobs-pipeline";
import { executeOcrSubtitleFlow } from "./jobs-ocr-flow";
export { executeOcrSubtitleFlow } from "./jobs-ocr-flow";

import { stageSubtitleSidecars, fixAssPlayResForOutput } from "./jobs-subtitle-sidecars";
export { stageSubtitleSidecars, fixAssPlayResForOutput } from "./jobs-subtitle-sidecars";

export async function validateTaskSnapshotBeforeStart(jobId: number): Promise<boolean> {
  const rows = await db.select().from(jobsTable).where(eq(jobsTable.id, jobId)).limit(1);
  const job = rows[0];
  if (!job) return false;
  try {
    await assertPreviewTaskAllowed();
  } catch (error) {
    if (isPreviewLimitError(error)) {
      await addLog(jobId, "warn", `任务启动被预览版限制阻止：${error.errorCode} ${error.message}`);
      return false;
    }
    throw error;
  }
  try {
    const snapshot = loadTaskSnapshot(job);
    if (!snapshot) {
      await db.update(jobsTable).set({
        status: "error",
        errorMessage: "旧任务没有不可变任务快照，请重新分析并创建任务",
        completedAt: new Date(),
      }).where(eq(jobsTable.id, jobId));
      await addLog(jobId, "error", "任务启动被阻止：legacy 任务没有不可变 taskSnapshot，未重新猜测默认标题或当前设置");
      return false;
    }
    const summary = taskSnapshotSummary(snapshot);
  await addLog(jobId, "info", `任务快照校验通过：version=${summary.snapshotVersion} analysis=${summary.analysisId} title=${summary.selectedTitleId} mode=${summary.outputMode} sourceStrategy=${summary.compressionSourceStrategy} handbrake=${summary.handbrakeTitleNumber ?? "n/a"}`);
    if (summary.outputMode !== (job.processingMode ?? null)) {
      await addLog(jobId, "warn", `计划不一致：快照 outputMode=${summary.outputMode}，任务记录 processingMode=${job.processingMode ?? "null"}，执行以快照为准`);
    }
    return true;
  } catch (error) {
    const message = error instanceof TaskSnapshotError ? error.code : String(error);
    await db.update(jobsTable).set({
      status: "error",
      errorMessage: `任务快照无效：${message}`,
      completedAt: new Date(),
    }).where(eq(jobsTable.id, jobId));
    await addLog(jobId, "error", `任务启动被阻止：taskSnapshot 校验失败 ${message}`);
    return false;
  }
}

export async function runningJobStatuses(): Promise<string[]> {
  const rows = await db.select({ status: jobsTable.status })
    .from(jobsTable)
    .where(sql`${jobsTable.status} in ('scanning', 'transcribing', 'compressing', 'remuxing')`);
  return rows.map((row: { status: string }) => row.status);
}

export const jobRunner = new JobRunner({
  getRunningStatuses: runningJobStatuses,
  validateBeforeStart: validateTaskSnapshotBeforeStart,
  start: async (jobId) => {
    await db.update(jobsTable).set({
      status: "scanning",
      startedAt: new Date(),
      progress: 0,
      currentFps: null,
      avgFps: null,
      etaSeconds: null,
      errorMessage: null,
    }).where(eq(jobsTable.id, jobId));
    processJob(jobId).catch(() => {});
  },
  findNextPending: async () => {
    const rows = await db.select({ id: jobsTable.id })
      .from(jobsTable)
      .where(eq(jobsTable.status, "pending"))
      .orderBy(asc(jobsTable.createdAt))
      .limit(1);
    return rows[0]?.id ?? null;
  },
  logQueued: (jobId) => addLog(jobId, "info", "任务已加入顺序队列，等待当前任务完成后自动开始"),
  logNextPending: (jobId) => addLog(jobId, "info", "顺序队列：前一个任务已结束，开始当前任务"),
});

export const jobService = new JobService<typeof jobsTable.$inferSelect>({
  findById: async (jobId) => {
    const rows = await db.select().from(jobsTable).where(eq(jobsTable.id, jobId)).limit(1);
    return rows[0] ?? null;
  },
  update: async (jobId, patch) => {
    await db.update(jobsTable).set(patch as Partial<typeof jobsTable.$inferInsert>).where(eq(jobsTable.id, jobId));
  },
  startWhenIdle: startJobWhenQueueIdle,
  requiresWorkflowSelection,
  markCancelled: (jobId) => cancelledJobs.add(jobId),
  killProcesses: killJobProcesses,
  clearCancelled: (jobId) => cancelledJobs.delete(jobId),
  removeIncompleteOutputs: (jobId) => removeIncompleteJobOutputs(jobId),
  addLog,
  assertPreviewTaskAllowed,
});

export function startJobWhenQueueIdle(jobId: number): Promise<boolean> {
  return jobRunner.startWhenIdle(jobId);
}

export async function startNextPendingJob(): Promise<void> {
  await jobRunner.startNextPending(isQueuePaused());
}

export async function validateCompressionOutput(input: {
  jobId: number;
  outputFile: string;
  expectedDurationSeconds?: number | null;
  expectedStreamCounts?: { video: number; audio: number; subtitle: number };
  expectedChapterCount?: number | null;
  requiredAudioCount?: number;
}): Promise<{ fileSize: number; durationSeconds: number | null }> {
  const { jobId, outputFile, expectedDurationSeconds, expectedStreamCounts, expectedChapterCount, requiredAudioCount = 0 } = input;
  try {
    const stat = await fs.stat(outputFile);
    if (!stat.isFile() || stat.size < 1024) {
      throw new Error("压缩输出文件不存在或为空");
    }

    let durationSeconds: number | null = null;
    try {
      const probe = await probeStreams(outputFile);
      durationSeconds = probe.duration ?? null;
      const grade = gradeCompressionOutput({
        probe: {
          durationSeconds,
          streams: probe.streams,
          chapters: probe.chapters,
        },
        expectedDurationSeconds,
        expectedVideoCount: expectedStreamCounts?.video ?? 1,
        expectedAudioCount: expectedStreamCounts?.audio ?? 0,
        requiredAudioCount,
        expectedSubtitleCount: expectedStreamCounts?.subtitle ?? 0,
        expectedChapterCount: expectedChapterCount ?? 0,
      });
      for (const warning of grade.warnings) await addLog(jobId, "warn", `压缩后置校验警告：${warning}`);
      if (grade.errors.length > 0) {
        throw new Error(`HandBrake 已成功退出，但后置校验失败：${grade.errors.join("；")}`);
      }
    } catch (error) {
      if (error instanceof Error && error.message.includes("后置校验失败")) throw error;
      await addLog(jobId, "warn", `压缩输出时长校验无法完成：${error instanceof Error ? error.message : String(error)}`);
    }

    return { fileSize: stat.size, durationSeconds };
  } catch (error) {
    await addLog(jobId, "error", `压缩输出校验失败：${error instanceof Error ? error.message : String(error)}`);
    throw error;
  }
}

import { SECRET_FIELDS, redactSecrets, getConfig } from "./jobs-config";
export { SECRET_FIELDS, redactSecrets, getConfig } from "./jobs-config";

// parseFilename / buildStandardizedName moved to ../lib/metadata

export type DetectedSubtitleFile = { path: string; language: "zh" | "en" | "bilingual" | "other" };

import { selectExternalSubtitleForJob, detectExistingSubtitleFiles } from "./jobs-subtitle-select";
export { selectExternalSubtitleForJob, detectExistingSubtitleFiles } from "./jobs-subtitle-select";
import { pickBestAudioTrack, probeAudioTracks } from "./jobs-audio";
export { pickBestAudioTrack, probeAudioTracks } from "./jobs-audio";
import { translateBatchLibre, translateBatch } from "./jobs-translation";
export { translateBatchLibre, translateBatch } from "./jobs-translation";
import { buildWhisperCorrectionPrompt, buildTranslationPrompt, findPosterUrlByLlm } from "./jobs-prompts";
export { buildWhisperCorrectionPrompt, buildTranslationPrompt, findPosterUrlByLlm } from "./jobs-prompts";
import { fullSubtitlePacketThreshold, sampleEmbeddedSubtitleText, textLooksChinese, probeSubtitlePacketCount, languageTagIsChinese } from "./jobs-subtitle-probe";
export { fullSubtitlePacketThreshold, sampleEmbeddedSubtitleText, textLooksChinese, probeSubtitlePacketCount, languageTagIsChinese } from "./jobs-subtitle-probe";
import type { PipelineStep } from "./jobs-subtitle-probe";
export type { PipelineStep } from "./jobs-subtitle-probe";

import { runSubtitlePipeline } from "./jobs-subtitle-pipeline";

// ─── Job processing pipeline ──────────────────────────────────────────────────

import { snapshotStreamIndexes, selectedDvdAudioCodecs, probeDvdAudioCodecs } from "./jobs-dvd-audio";
export { snapshotStreamIndexes, selectedDvdAudioCodecs, probeDvdAudioCodecs } from "./jobs-dvd-audio";

import { processVerifiedDvdRemuxJob } from "./jobs-dvd-remux";
export { processVerifiedDvdRemuxJob } from "./jobs-dvd-remux";

import { processChapterPreviewJob } from "./jobs-chapter-preview";
export { processChapterPreviewJob } from "./jobs-chapter-preview";

import { runAiAssetStage, generateAndWriteReadme, generateAiReview } from "./jobs-readme-ai";
export { runAiAssetStage } from "./jobs-readme-ai";

// POST /jobs/:id/readme
router.post("/jobs/:id/readme", async (req, res) => {
  const idParsed = GetJobParams.safeParse(req.params);
  if (!idParsed.success) return res.status(400).json({ error: "无效的任务 ID" });

  const jobId = idParsed.data.id;
  const rows = await db.select().from(jobsTable).where(eq(jobsTable.id, jobId)).limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });

  const config = await getConfig();
  const result = await generateAndWriteReadme(jobId, config);
  return res.json(result);
});

// POST /jobs/:id/review — 立即生成专家影评（需要 LLM）。
router.post("/jobs/:id/review", async (req, res) => {
  const idParsed = GetJobParams.safeParse(req.params);
  if (!idParsed.success) return res.status(400).json({ error: "无效的任务 ID" });
  const jobId = idParsed.data.id;
  const rows = await db.select().from(jobsTable).where(eq(jobsTable.id, jobId)).limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });
  const config = await getConfig();
  const reviewPath = await generateAiReview(jobId, config);
  return res.json({ reviewPath });
});

// POST /jobs/:id/poster — 立即刮削/下载真实海报到源目录。
router.post("/jobs/:id/poster", async (req, res) => {
  const idParsed = GetJobParams.safeParse(req.params);
  if (!idParsed.success) return res.status(400).json({ error: "无效的任务 ID" });
  const jobId = idParsed.data.id;
  const rows = await db.select().from(jobsTable).where(eq(jobsTable.id, jobId)).limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });
  const config = await getConfig();
  const job = {
    ...rows[0],
    filePath: resolveRuntimePath(rows[0].filePath, config),
    mainTrackPath: rows[0].mainTrackPath ? resolveRuntimePath(rows[0].mainTrackPath, config) : null,
  };
  const posterDir = path.join(sourceDirectoryForJob(job), MEDIA_INFO_DIR);
  const posterPath = await ensureLocalPoster({
    title: job.movieTitle,
    titleEn: job.movieTitleEn,
    imdbId: job.movieImdbId,
    posterUrl: job.moviePoster,
    tmdbId: job.tmdbId,
    tmdbApiKey: config.tmdbApiKey,
    omdbApiKey: config.omdbApiKey,
    posterMirrorUrl: config.posterMirrorUrl,
    posterProxyUrl: config.posterProxyUrl,
    findPosterUrlByLlm: () => findPosterUrlByLlm(job, config),
    year: job.movieYear,
    targetDirectory: posterDir,
    onLog: async (message) => addLog(jobId, "info", message),
  });
  if (!posterPath) return res.status(404).json({ error: "未找到真实海报来源，跳过" });
  return res.json({ posterPath });
});

// GET /jobs/:id/streams
router.get("/jobs/:id/streams", async (req, res) => {
  const id = parseInt(req.params.id ?? "", 10);
  if (isNaN(id)) return res.status(400).json({ error: "无效的任务 ID" });

  const rows = await db.select().from(jobsTable).where(eq(jobsTable.id, id)).limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });

  const cfg = await getConfig();
  const job = {
    ...rows[0],
    filePath: resolveRuntimePath(rows[0].filePath, cfg),
    mainTrackPath: rows[0].mainTrackPath ? resolveRuntimePath(rows[0].mainTrackPath, cfg) : null,
    outputPath: rows[0].outputPath ? resolveRuntimePath(rows[0].outputPath, cfg) : null,
  };
  const sourcePath = job.outputPath || job.mainTrackPath || job.filePath;

  try {
    // Disc jobs (DVD/Blu-ray/ISO) point at a disc root that plain ffprobe
    // cannot enumerate. Prefer the live disc analysis for the selected title
    // so the detail drawer's source info is populated.
    let snapshot: { analysisId?: string; selectedTitleId?: string } | null = null;
    if (typeof job.taskSnapshot === "string" && job.taskSnapshot) {
      try {
        snapshot = JSON.parse(job.taskSnapshot) as { analysisId?: string; selectedTitleId?: string };
      } catch {
        snapshot = null;
      }
    }
    const isDiscJob = job.mediaType === "dvd" || job.mediaType === "bluray" || job.mediaType === "iso";
    if (isDiscJob && snapshot?.analysisId && snapshot?.selectedTitleId) {
      const analysis = discAnalysisRegistry.find(snapshot.analysisId);
      const title = analysis?.titles.find((candidate) => candidate.titleId === snapshot?.selectedTitleId);
      if (title && title.streams.length > 0) {
        await addLog(id, "info", `使用光盘分析源信息：title=${title.titleId} streams=${title.streams.length}`);
        return res.json({
          streams: title.streams.map((s) => ({
            index: s.index,
            codecType: s.codecType,
            codecName: s.codecName,
            profile: s.profile ?? null,
            description: s.description ?? null,
            language: s.language,
            title: s.title,
            channels: s.channels ?? null,
            channelLayout: s.channelLayout ?? null,
            sampleRate: s.sampleRate ?? null,
            width: s.width ?? null,
            height: s.height ?? null,
            frameRate: s.frameRate ?? null,
            bitRate: s.bitrate != null ? String(s.bitrate) : null,
            hdr: false,
            default: s.default ?? false,
            forced: s.forced ?? false,
          })),
          chapters: (title.chapters ?? []).map((c) => ({
            id: c.id,
            startSeconds: c.startSeconds,
            endSeconds: c.endSeconds,
            title: c.title,
          })),
          duration: title.durationSeconds ?? null,
          formatName: analysis?.mediaType === "bluray" ? "bluray" : "dvd",
          bitRate: null,
        });
      }
    }
    await addLog(id, "info", `正在探测流轨：${sourcePath}`);
    const result = await probeMediaStreams(sourcePath, job.mediaType);
    await addLog(id, "info", `流轨探测完成：${result.streams.length} 条流，${result.chapters?.length ?? 0} 个章节`);
    return res.json(result);
  } catch (e) {
    await addLog(id, "error", `流轨探测失败：${String(e)}`);
    return res.status(500).json({ error: `ffprobe 失败：${String(e)}` });
  }
});

// GET /media/analyze?path= — unified analysis entry for ordinary media files.
// Disc sources continue to use /disc/analyze until playlist/title selection is
// migrated to the same source manifest in the next stage of this work.
router.get("/media/analyze", async (req, res) => {
  const rawPath = String(req.query.path ?? "");
  if (!rawPath) return res.status(400).json({ error: "path 参数不能为空" });
  const cfg = await getConfig();
  const sourcePath = resolveRuntimePath(rawPath, cfg);
  try {
    const ext = path.extname(sourcePath).toLowerCase();
    const mediaType = ext === ".iso" ? "iso" : "video";
    const result = await probeMediaStreams(sourcePath, mediaType);
    return res.json({
      sourcePath,
      mediaType,
      durationSeconds: result.duration,
      streams: result.streams.map((stream) => ({
        index: stream.index,
        codecType: stream.codecType,
        codecName: stream.codecName,
        language: stream.language,
        title: stream.title,
        width: stream.width,
        height: stream.height,
        channels: stream.channels,
        default: stream.default,
        forced: stream.forced,
      })),
      chapters: result.chapters ?? [],
    });
  } catch (e) {
    return res.status(500).json({ error: `媒体分析失败：${String(e)}` });
  }
});

// PUT /jobs/:id/disc-settings
router.put("/jobs/:id/disc-settings", async (req, res) => {
  const id = parseInt(req.params.id ?? "", 10);
  if (isNaN(id)) return res.status(400).json({ error: "无效的任务 ID" });

  const rows = await db.select().from(jobsTable).where(eq(jobsTable.id, id)).limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });

  const { selectedStreams, selectedChapters, processingMode, mainTrackPath } = req.body as { selectedStreams?: string | null; selectedChapters?: string | null; processingMode?: string; mainTrackPath?: string | null };

  const update: Partial<typeof jobsTable.$inferInsert> = {};
  if (selectedStreams !== undefined) update.selectedStreams = selectedStreams;
  if (selectedChapters !== undefined) update.selectedChapters = selectedChapters;
  if (processingMode === "compress" || processingMode === "remux" || processingMode === "none") update.processingMode = processingMode;
  if (mainTrackPath !== undefined) update.mainTrackPath = mainTrackPath;

  const [updated] = await db.update(jobsTable).set(update).where(eq(jobsTable.id, id)).returning();
  return res.json(updated);
});

// POST /jobs/:id/subtitle-pipeline
router.post("/jobs/:id/subtitle-pipeline", async (req, res) => {
  const idParsed = GetJobParams.safeParse(req.params);
  if (!idParsed.success) return res.status(400).json({ error: "无效的任务 ID" });

  const jobId = idParsed.data.id;
  const rows = await db.select().from(jobsTable).where(eq(jobsTable.id, jobId)).limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });

  // Mark pipeline as running
  await db.update(jobsTable).set({ subtitlePipelineStatus: "running" }).where(eq(jobsTable.id, jobId));

  try {
    const result = await runSubtitlePipeline(jobId);
    return res.json({
      jobId,
      subtitleSource: result.subtitleSource,
      rawSubtitlePath: result.rawSubtitlePath,
      translatedSubtitlePath: result.translatedSubtitlePath,
      steps: result.steps,
    });
  } catch (e) {
    await db.update(jobsTable).set({ subtitlePipelineStatus: "error" }).where(eq(jobsTable.id, jobId));
    return res.status(500).json({ error: String(e) });
  }
});

// POST /metadata/lookup — query TMDb + OMDb + local IMDb dataset in parallel

/**
 * Build lossless Remux args for Blu-ray/DVD sources.  Everything is copied
 * except `pcm_bluray` audio: MKV has no codec tag for Blu-ray LPCM, so those
 * tracks are transcoded losslessly to pcm_s24le (same sample values, MKV-safe).
 */
export async function buildLosslessRemuxArgs(probeTarget: string, inputArgs?: string[], selectedStreams?: number[] | null): Promise<{ args: string[]; transcodedPcmBluray: boolean }> {
  const probe = await probeStreams(probeTarget, inputArgs);
  const args = ["-dn", "-ignore_unknown", "-avoid_negative_ts", "make_zero"];
  // Honour the user's stream selection: map only the selected indexes. Without
  // this the Blu-ray Remux copied every track regardless of what was picked.
  const wanted = selectedStreams && selectedStreams.length > 0 ? new Set(selectedStreams) : null;
  let audioOutIndex = 0;
  let transcodedPcmBluray = false;
  for (const stream of probe.streams) {
    if (wanted && !wanted.has(stream.index)) continue;
    args.push("-map", `0:${stream.index}`);
    if (stream.codecType === "audio") {
      if (stream.codecName === "pcm_bluray") {
        args.push(`-c:a:${audioOutIndex}`, "pcm_s24le");
        transcodedPcmBluray = true;
      } else {
        args.push(`-c:a:${audioOutIndex}`, "copy");
      }
      audioOutIndex += 1;
    } else if (stream.codecType === "video") {
      args.push("-c:v", "copy");
    } else if (stream.codecType === "subtitle") {
      args.push("-c:s", "copy");
    }
  }
  return { args, transcodedPcmBluray };
}

router.use(discRouter);
router.use(adminRouter);
router.use(jobsCrudRouter);
router.use(previewRouter);

export default router;
