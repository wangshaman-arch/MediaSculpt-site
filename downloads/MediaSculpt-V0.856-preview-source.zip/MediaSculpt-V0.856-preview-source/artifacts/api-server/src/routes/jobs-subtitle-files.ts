// Extracted from routes/jobs.ts: subtitle file discovery and pairing.
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { lookupAll, metadataIdentityMatches, normalizeTitleEn } from "../lib/metadata";
import { servePreviewSegment, cleanupPreviewSegments } from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import { buildFfconcatFileContent as buildManifest, buildFfconcatChapterContent, buildFfconcatTimedContent, type FfconcatTimedSegment } from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import { appendJobRuntimeLog, appendJobToolOutput } from "../lib/job-runtime-log";
import { appendRuntimeToolLog, appendRuntimeToolOutput } from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { isSourceDirectoryValue } from "./jobs";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import { buildCompressionOutputName, buildRemuxOutputName, cleanSegment, encoderBitDepth, selectBestAudioTrack } from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import { renderBilingualAss, DEFAULT_BILINGUAL_STYLE, type BilingualAssStyle, type SubtitleBlock } from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import { ensureLocalPoster, MEDIA_INFO_DIR, POSTER_META_FILE, posterIdentityMatches } from "../lib/poster";
import { ensureFasterWhisperModel, ensureWhisperCliScript } from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import { hasValidSubtitleCues, isGraphicSubtitleCodec, shouldFallbackToWhisper } from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import { buildDvdRemuxArgs, runDvdRemux, verifyDvdTitle } from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import { buildDvdStructurePayload, resolveRemuxPlanWithLlm, validateRemuxPlan } from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import { assertPreviewTaskAllowed, recordPreviewAiCall, settlePreviewTask } from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import { parseCustomTuning, resolveLogicPlaceholders } from "../lib/custom-tuning";
import { decryptSecret, encryptSecret, isEncryptedSecret } from "../lib/secrets";
import { ffmpegPath, resolveOutputDir, resolveRuntimePath, type RuntimePathConfig } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import { assertCompleteMediaTitle, createDvdMediaTitle } from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import { buildPreviewTranscodeArgs, isPreviewVideoCandidate, previewService } from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";

type SubtitleFileEntry = {
  name: string;
  path: string;
  kind: "original" | "translated" | "other";
};

export const SUBTITLE_FILE_EXT_RE = /\.(srt|vtt|ass|ssa|sup|mkv)$/i;

/**
 * Collect directories that may contain this job's subtitle files: the
 * configured subtitle output directory, directories of stored subtitle
 * paths (including stale DB values), and the source file directory.
 */
export async function resolveJobSubtitleDirectories(
  job: { filePath: string; outputPath?: string | null; mainTrackPath?: string | null; subtitlePath?: string | null; translatedSubtitlePath?: string | null },
): Promise<string[]> {
  const dirs = new Set<string>();
  const addFilePathDir = (p: string | null | undefined) => {
    if (!p) return;
    try {
      const stat = fsSync.statSync(p);
      if (!stat.isDirectory()) dirs.add(path.dirname(p));
    } catch {
      // The stored path may be stale; still scan its directory so real files nearby are found.
      if (path.dirname(p) !== p) dirs.add(path.dirname(p));
    }
  };
  addFilePathDir(job.subtitlePath);
  addFilePathDir(job.translatedSubtitlePath);
  addFilePathDir(job.outputPath);
  addFilePathDir(job.mainTrackPath);
  addFilePathDir(job.filePath);
  try {
    const [config] = await db.select({
      subtitleDirectory: configTable.subtitleDirectory,
      hostOutputPath: configTable.hostOutputPath,
      outputDirectory: configTable.outputDirectory,
    }).from(configTable).limit(1);
    if (config && config.subtitleDirectory && !isSourceDirectoryValue(config.subtitleDirectory)) {
      dirs.add(resolveOutputDir(config.subtitleDirectory, config));
    }
  } catch {
    // config table may be empty; ignore
  }
  const result: string[] = [];
  for (const dir of dirs) {
    try {
      const stat = await fs.stat(dir);
      if (stat.isDirectory()) result.push(dir);
    } catch {
      // skip missing directories
    }
  }
  return result;
}

/** Scan the job's subtitle directories for real files related to this task. */
export async function scanJobSubtitleFiles(job: {
  filePath: string;
  outputPath?: string | null;
  mainTrackPath?: string | null;
  subtitlePath?: string | null;
  translatedSubtitlePath?: string | null;
}): Promise<SubtitleFileEntry[]> {
  const dirs = await resolveJobSubtitleDirectories(job);
  const baseName = await (async () => {
    for (const p of [job.outputPath, job.mainTrackPath, job.filePath]) {
      if (!p || /[\\/]$/.test(p)) continue;
      try {
        const stat = await fs.stat(p);
        if (!stat.isDirectory()) return path.basename(p, path.extname(p));
      } catch {
        // fall through to next candidate
      }
    }
    return path.basename(job.filePath, path.extname(job.filePath));
  })();
  const lowerBase = baseName.toLowerCase();
  const dbNames = new Set(
    [job.subtitlePath, job.translatedSubtitlePath]
      .filter((p): p is string => Boolean(p))
      .map((p) => path.basename(p).toLowerCase()),
  );
  const files: SubtitleFileEntry[] = [];
  const seen = new Set<string>();
  for (const dir of dirs) {
    let entries: string[] = [];
    try {
      entries = await fs.readdir(dir);
    } catch {
      continue;
    }
    for (const name of entries) {
      if (!SUBTITLE_FILE_EXT_RE.test(name)) continue;
      const lower = name.toLowerCase();
      if (!lower.startsWith(`${lowerBase}.`) && !dbNames.has(lower)) continue;
      const fullPath = path.join(dir, name);
      if (seen.has(fullPath)) continue;
      try {
        const stat = await fs.stat(fullPath);
        if (!stat.isFile()) continue;
      } catch {
        continue;
      }
      seen.add(fullPath);
      let kind: SubtitleFileEntry["kind"] = "other";
      if (/\.zhs\./i.test(name) || /\.zh[-_]?(cn|s|hans)\./i.test(name) || /\.chs\./i.test(name)) {
        kind = "translated";
      } else if (
        lower === `${lowerBase}.srt` ||
        /\.original\./i.test(name) ||
        /\.en(?:g)?\./i.test(name)
      ) {
        kind = "original";
      }
      if (job.translatedSubtitlePath && path.resolve(fullPath) === path.resolve(job.translatedSubtitlePath)) kind = "translated";
      if (job.subtitlePath && path.resolve(fullPath) === path.resolve(job.subtitlePath)) kind = "original";
      files.push({ name, path: fullPath, kind });
    }
  }
  const order = { translated: 0, original: 1, other: 2 } as const;
  files.sort((a, b) => order[a.kind] - order[b.kind] || a.name.localeCompare(b.name));
  return files;
}
