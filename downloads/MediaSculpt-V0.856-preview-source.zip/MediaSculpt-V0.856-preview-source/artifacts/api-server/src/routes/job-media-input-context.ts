import { db, configTable, jobsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { resolveDvdHandbrakeInputForIfo, resolveDvdTitleForSource, type DvdTitle } from "../lib/disc";
import type { UnifiedDiscTitle } from "../lib/disc-analysis";
import { parseHandBrakeSelectionPlan, type HandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { resolveToolPath } from "../lib/tool-runtime";
import { resolveRuntimePath } from "../lib/runtime-paths";
import type { TaskSnapshotV1 } from "../lib/task-snapshot";
import { dvdVideoInputPath, discAnalysisRegistry, ensureDvdCssSupport, resolveMainTrack } from "./jobs";

export type ResolvedJob = typeof jobsTable.$inferSelect & {
  filePath: string;
  mainTrackPath: string | null;
};

export type PreparedJobMediaInput = {
  job: ResolvedJob;
  mediaInputPath: string;
  dvdVideoInput: string;
  dvdTitle: DvdTitle | null;
  handbrakeInputPath: string;
  selectedHandBrakePlan: HandBrakeSelectionPlan | null;
  selectedTitleSizeBytes: number | null;
  selectedAnalysisTitle: UnifiedDiscTitle | undefined;
  selectedTitleDurationSeconds: number | null;
};

export function resolveSelectedTitleDurationSeconds(
  plan: { handbrake?: { durationSeconds?: number | null } } | null | undefined,
  analysisTitle: { durationSeconds?: number | null } | null | undefined,
): number | null {
  const plannedDuration = plan?.handbrake?.durationSeconds;
  if (typeof plannedDuration === "number" && plannedDuration > 0) return plannedDuration;
  const analyzedDuration = analysisTitle?.durationSeconds;
  return typeof analyzedDuration === "number" && analyzedDuration > 0 ? analyzedDuration : null;
}

export async function prepareJobMediaInput(input: {
  jobId: number;
  job: ResolvedJob;
  taskSnapshot: TaskSnapshotV1 | null;
  config: typeof configTable.$inferSelect;
  log: (level: "info" | "warn", message: string) => Promise<unknown>;
  probeDvdTitleByNumber?: (sourcePath: string, titleNumber: number) => Promise<{ duration?: number | null } | null>;
}): Promise<PreparedJobMediaInput> {
  const job = { ...input.job };

  if (job.mediaType === "dvd" && input.taskSnapshot?.sourceType === "dvd") {
    job.mainTrackPath = resolveRuntimePath(input.taskSnapshot.sourcePath, input.config);
    await input.log("info", `DVD 标题来源已冻结：selectedTitleId=${input.taskSnapshot.selectedTitleId} HandBrake Title=${input.taskSnapshot.toolSelections.handbrakeTitleNumber ?? "未知"}`);
  } else if (job.mediaType === "dvd") {
    const resolvedTrack = await resolveMainTrack(job.mainTrackPath || job.filePath, "dvd");
    if (resolvedTrack && resolvedTrack !== job.mainTrackPath) {
      job.mainTrackPath = resolvedTrack;
      await db.update(jobsTable)
        .set({ mainTrackPath: resolvedTrack })
        .where(eq(jobsTable.id, input.jobId));
    }
  } else if (job.mediaType === "bluray" && !job.mainTrackPath) {
    const resolvedTrack = await resolveMainTrack(job.filePath, "bluray");
    if (resolvedTrack && resolvedTrack !== job.filePath) {
      job.mainTrackPath = resolvedTrack;
      await db.update(jobsTable)
        .set({ mainTrackPath: resolvedTrack })
        .where(eq(jobsTable.id, input.jobId));
    }
  }

  const mediaInputPath = job.mainTrackPath || job.filePath;
  const dvdVideoInput = job.mediaType === "dvd" ? dvdVideoInputPath(mediaInputPath) : mediaInputPath;
  if (job.mediaType === "dvd") {
    const ffmpegExecutable = await resolveToolPath("ffmpeg").catch(() => null);
    const cssSupport = await ensureDvdCssSupport(ffmpegExecutable);
    if (cssSupport === "ok") {
      await input.log("info", "libdvdcss 就绪：CSS 加密 DVD 可直接通过 FFmpeg 读取");
    } else if (cssSupport === "failed") {
      await input.log("warn", "libdvdcss 自动安装失败：若为 CSS 加密 DVD，读取可能失败（普通 DVD 不受影响）");
    }
  }

  const dvdTitle = job.mediaType === "dvd" && !input.taskSnapshot
    ? await resolveDvdTitleForSource(mediaInputPath)
    : null;
  const handbrakeInputPath = dvdTitle
    ? resolveDvdHandbrakeInputForIfo(dvdTitle.ifoPath)
    : job.mediaType === "bluray"
      ? resolveRuntimePath(job.filePath, input.config)
      : mediaInputPath;
  const selectedHandBrakePlan = parseHandBrakeSelectionPlan(job.selectionPlan);
  const selectedTitleSizeBytes = selectedHandBrakePlan?.handbrake?.titleSizeBytes ?? null;
  const selectedAnalysisTitle = input.taskSnapshot
    ? discAnalysisRegistry.find(input.taskSnapshot.analysisId)?.titles.find((candidate) => candidate.titleId === input.taskSnapshot?.selectedTitleId)
    : undefined;
  let selectedTitleDurationSeconds = resolveSelectedTitleDurationSeconds(
    selectedHandBrakePlan,
    selectedAnalysisTitle,
  );
  const snapshotDvdTitleNumber = input.taskSnapshot?.toolSelections.dvdVtsNumber;
  if (
    !selectedTitleDurationSeconds
    && job.mediaType === "dvd"
    && typeof snapshotDvdTitleNumber === "number"
    && snapshotDvdTitleNumber > 0
  ) {
    const selectedTitleProbe = input.probeDvdTitleByNumber
      ? await input.probeDvdTitleByNumber(mediaInputPath, snapshotDvdTitleNumber).catch(() => null)
      : null;
    if (selectedTitleProbe?.duration && selectedTitleProbe.duration > 0) {
      selectedTitleDurationSeconds = selectedTitleProbe.duration;
      await input.log("info", `按所选 DVD 标题 ${snapshotDvdTitleNumber} 探测时长：${selectedTitleProbe.duration.toFixed(1)} 秒`);
    }
  }

  return {
    job,
    mediaInputPath,
    dvdVideoInput,
    dvdTitle,
    handbrakeInputPath,
    selectedHandBrakePlan,
    selectedTitleSizeBytes,
    selectedAnalysisTitle,
    selectedTitleDurationSeconds,
  };
}
