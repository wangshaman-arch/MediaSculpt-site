import { afterEach, describe, expect, it, vi } from "vitest";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

function srtBlock(text: string): string {
  return Array.from({ length: 20 }, (_, i) => {
    const startSeconds = String(i % 10).padStart(2, "0");
    return `${i + 1}\n00:00:${startSeconds},000 --> 00:00:02,000\n${text}${i}\n`;
  }).join("\n");
}

function assBlock(): string {
  return Array.from({ length: 20 }, (_, i) => `Dialogue: ${i},0:00:01.00,0:00:02.00,Default,,0,0,0,,中文${i}`).join("\n");
}

describe("detectExistingSubtitleFiles filename pairing", () => {
  let tempDirectory: string | undefined;

  afterEach(async () => {
    delete process.env.VX_AGENT_DATABASE_PATH;
    delete process.env.DATABASE_DRIVER;
    delete process.env.VX_AGENT_DIAGNOSTICS_LOG;
    vi.resetModules();
    if (tempDirectory) {
      await fs.rm(tempDirectory, { recursive: true, force: true }).catch(() => {});
    }
    tempDirectory = undefined;
  });

  async function loadJobs() {
    const databaseDirectory = path.join(tempDirectory!, "db");
    await fs.mkdir(databaseDirectory, { recursive: true });
    process.env.VX_AGENT_DATABASE_PATH = path.join(databaseDirectory, "vx-agent.db");
    process.env.DATABASE_DRIVER = "sqlite";
    process.env.VX_AGENT_DIAGNOSTICS_LOG = path.join(tempDirectory!, "diagnostics.log");
    vi.resetModules();
    return import("./jobs");
  }

  it("only pairs subtitles whose file name matches the media base name", async () => {
    tempDirectory = await fs.mkdtemp(path.join(os.tmpdir(), "vx-sub-pair-"));
    await fs.writeFile(path.join(tempDirectory, "Movie.srt"), srtBlock("中文配对字幕"));
    await fs.writeFile(path.join(tempDirectory, "Movie.zh.srt"), srtBlock("中文配对字幕"));
    await fs.writeFile(path.join(tempDirectory, "Other.srt"), srtBlock("其他影片的中文字幕"));
    await fs.writeFile(path.join(tempDirectory, "Other.ass"), assBlock());

    const jobs = await loadJobs();
    const paired = await jobs.detectExistingSubtitleFiles(tempDirectory, "Movie");
    expect(paired.map((item) => path.basename(item.path)).sort()).toEqual(["Movie.srt", "Movie.zh.srt"]);
    expect(paired.every((item) => item.language === "zh")).toBe(true);

    // Without a media base name the directory scan still returns everything
    // (backwards compatible for callers that intentionally scan a whole folder).
    const all = await jobs.detectExistingSubtitleFiles(tempDirectory);
    expect(all.map((item) => path.basename(item.path)).sort()).toEqual(["Movie.srt", "Movie.zh.srt", "Other.ass", "Other.srt"]);
  }, 30_000);

  it("never refuses subtitle translation because of external Chinese subtitle files", async () => {
    // The job orchestration moved out of jobs.ts into job-orchestrator.ts.
    const source = [
      await fs.readFile(fileURLToPath(new URL("./jobs.ts", import.meta.url)), "utf8"),
      await fs.readFile(fileURLToPath(new URL("./job-orchestrator.ts", import.meta.url)), "utf8"),
    ].join("\n");
    // The pipeline must keep working when only external Chinese subtitle files
    // exist next to the video (copied/mismatched files must not block work).
    expect(source).toContain("不视为已翻译");
    expect(source).not.toContain("将直接保留");
  }, 30_000);

  it("uses a same-name external Chinese subtitle as the bilingual source when it is the only subtitle", async () => {
    tempDirectory = await fs.mkdtemp(path.join(os.tmpdir(), "vx-sub-bilingual-zh-only-"));
    await fs.writeFile(path.join(tempDirectory, "Movie.zh.srt"), srtBlock("只有中文字幕"));

    const jobs = await loadJobs();
    const detected = await jobs.detectExistingSubtitleFiles(tempDirectory, "Movie");
    const selected = jobs.selectExternalSubtitleForJob(detected, true);

    expect(selected).toMatchObject({
      path: path.join(tempDirectory, "Movie.zh.srt"),
      language: "zh",
    });
  }, 30_000);

  it("recognizes a same-name dual-language subtitle instead of misclassifying it as English", async () => {
    tempDirectory = await fs.mkdtemp(path.join(os.tmpdir(), "vx-sub-bilingual-mixed-"));
    await fs.writeFile(path.join(tempDirectory, "Movie.ds.srt"), srtBlock("中文 line\nEnglish line"));

    const jobs = await loadJobs();
    const detected = await jobs.detectExistingSubtitleFiles(tempDirectory, "Movie");
    expect(detected).toMatchObject([{
      path: path.join(tempDirectory, "Movie.ds.srt"),
      language: "bilingual",
    }]);
    expect(jobs.selectExternalSubtitleForJob(detected, true)).toMatchObject({
      path: path.join(tempDirectory, "Movie.ds.srt"),
      language: "bilingual",
    });
  }, 30_000);
});
