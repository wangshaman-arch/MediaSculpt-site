import { ffmpegPath } from "../lib/runtime-paths";

export function buildDvdVobFallbackArgs(input: {
  concatInputArgs: readonly string[];
  typeMaps: readonly string[] | null;
  outputPath: string;
  selectedAudioStreams: number[];
  selectedAudioCodecs: Array<{
    inputIndex: number;
    codecName: string | null;
    bitsPerRawSample?: number | null;
  }>;
  chapterMetadataPath: string | null;
}): string[] {
  const args = [
    "-y",
    "-hide_banner",
    "-fflags",
    "+genpts",
    "-analyzeduration",
    "100M",
    "-probesize",
    "100M",
    ...input.concatInputArgs,
  ];

  // The concat protocol exposes stable type-relative streams. Reuse the
  // verified analysis selection instead of guessing raw stream indexes from a
  // different demuxer. Matroska supports DVD VobSub and Blu-ray PGS stream
  // entries, so selected graphic subtitles must remain in the lossless remux.
  const typedMaps = input.typeMaps ?? ["-map", "0:v", "-map", "0:a"];
  for (let index = 0; index < typedMaps.length; index += 2) {
    const mapFlag = typedMaps[index];
    const mapValue = typedMaps[index + 1];
    if (mapFlag === "-map" && mapValue) {
      args.push(mapFlag, mapValue);
    }
  }

  args.push(
    "-dn",
    "-ignore_unknown",
    "-c",
    "copy",
    "-avoid_negative_ts",
    "make_zero",
  );
  let audioOutputIndex = 0;
  for (const inputIndex of input.selectedAudioStreams) {
    const codec = input.selectedAudioCodecs.find(
      (candidate) => candidate.inputIndex === inputIndex,
    );
    if (codec?.codecName?.toLowerCase() === "pcm_dvd") {
      args.push(
        `-c:a:${audioOutputIndex}`,
        (codec.bitsPerRawSample ?? 16) > 16 ? "pcm_s24le" : "pcm_s16le",
      );
    }
    audioOutputIndex += 1;
  }

  if (input.chapterMetadataPath) {
    args.push(
      "-i",
      ffmpegPath(input.chapterMetadataPath),
      "-map_metadata",
      "1",
      "-map_chapters",
      "1",
    );
  } else {
    args.push("-map_chapters", "0");
  }
  args.push(input.outputPath);
  return args;
}
