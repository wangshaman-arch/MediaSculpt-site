import path from "path";
import { scanBlurayPlaylists } from "../lib/disc";
import { mountBlurayIso, probeStreams } from "./jobs";

type PlaylistSelectionSnapshot = {
  selectedTitleId?: string | null;
  toolSelections?: { playlistId?: string | null };
};

export function selectedBlurayPlaylistId(snapshot: PlaylistSelectionSnapshot | null | undefined): string | null {
  return snapshot?.toolSelections?.playlistId
    ?? (/^mpls:(\d+)$/.exec(String(snapshot?.selectedTitleId ?? ""))?.[1] ?? null);
}

export async function resolveBlurayPlaylistInput(input: {
  mediaType: string;
  sourcePath: string;
  discSourcePath: string;
  taskSnapshot: PlaylistSelectionSnapshot | null;
  expectedTitleSeconds: number | null;
  log: (level: "info" | "warn", message: string) => Promise<unknown>;
}): Promise<{ discRoot: string; mplsPath: string }> {
  const isMplsInput = /\.mpls$/i.test(input.sourcePath);
  let discRoot: string | null = null;
  let mplsPath: string | null = null;

  if (isMplsInput) {
    mplsPath = input.sourcePath;
    discRoot = path.dirname(path.dirname(input.sourcePath));
  } else if (input.mediaType === "bluray") {
    // The selected m2ts is only a preview/analysis source. The playlist lives
    // under the disc root captured in the immutable task snapshot.
    discRoot = input.discSourcePath;
    const playlistId = selectedBlurayPlaylistId(input.taskSnapshot);
    if (playlistId) mplsPath = path.join(discRoot, "BDMV", "PLAYLIST", `${playlistId}.mpls`);
  } else if (input.mediaType === "iso") {
    const mounted = await mountBlurayIso(input.sourcePath);
    if (!mounted) throw new Error("无法挂载蓝光 ISO，请检查系统挂载支持");
    discRoot = mounted;
    const playlistId = selectedBlurayPlaylistId(input.taskSnapshot);
    if (playlistId) mplsPath = path.join(mounted, "BDMV", "PLAYLIST", `${playlistId}.mpls`);
  }

  if (!mplsPath || !discRoot) {
    if (discRoot) {
      const playlists = await scanBlurayPlaylists(discRoot);
      if (input.expectedTitleSeconds && playlists.length > 0) {
        let bestMpls: string | null = null;
        let bestDiff = Number.POSITIVE_INFINITY;
        let bestMeasured = 0;
        for (const playlist of playlists) {
          if (!playlist.segments || playlist.segments.length === 0) continue;
          let measured = 0;
          let measurable = true;
          for (const segment of playlist.segments) {
            try {
              const probe = await probeStreams(segment.streamPath);
              if (!probe.duration || probe.duration <= 0) { measurable = false; break; }
              measured += probe.duration;
            } catch {
              measurable = false;
              break;
            }
          }
          if (!measurable || measured <= 0) continue;
          const diff = Math.abs(measured - input.expectedTitleSeconds);
          if (diff < bestDiff) {
            bestDiff = diff;
            bestMpls = playlist.mplsPath;
            bestMeasured = measured;
          }
        }
        const tolerance = Math.max(30, input.expectedTitleSeconds * 0.05);
        if (bestMpls && bestDiff <= tolerance) {
          mplsPath = bestMpls;
          await input.log("info", `按实测时长匹配标题：${path.basename(mplsPath)}（期望 ${input.expectedTitleSeconds.toFixed(1)}s，实测 ${bestMeasured.toFixed(1)}s）`);
        } else if (bestMpls) {
          await input.log("warn", `时长匹配未达容差（最接近差异 ${bestDiff.toFixed(1)}s），回退到最大播放列表`);
        }
      }
      if (!mplsPath) {
        const playlistWeight = (playlist: { durationSeconds: number | null; sizeBytes: number }) => playlist.durationSeconds ?? (playlist.sizeBytes > 0 ? playlist.sizeBytes / 1_000_000 : 0);
        const best = playlists.sort((a, b) => playlistWeight(b) - playlistWeight(a))[0];
        mplsPath = best?.mplsPath ?? null;
      }
    }
  }

  if (!mplsPath) throw new Error("未找到蓝光播放列表（.mpls）");
  if (!discRoot) throw new Error("未找到蓝光目录");
  return { discRoot, mplsPath };
}
