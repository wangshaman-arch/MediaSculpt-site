// Extracted from routes/jobs.ts: bilingual (dual-language) subtitle assembly.
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { lookupAll, metadataIdentityMatches, normalizeTitleEn } from "../lib/metadata";
import { servePreviewSegment, cleanupPreviewSegments } from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import { buildFfconcatFileContent as buildManifest, buildFfconcatChapterContent, buildFfconcatTimedContent, type FfconcatTimedSegment } from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import { appendJobRuntimeLog, appendJobToolOutput } from "../lib/job-runtime-log";
import { appendRuntimeToolLog, appendRuntimeToolOutput } from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import { buildCompressionOutputName, buildRemuxOutputName, cleanSegment, encoderBitDepth, selectBestAudioTrack } from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import { renderBilingualAss, DEFAULT_BILINGUAL_STYLE, type BilingualAssStyle, type SubtitleBlock } from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import { ensureLocalPoster, MEDIA_INFO_DIR, POSTER_META_FILE, posterIdentityMatches } from "../lib/poster";
import { ensureFasterWhisperModel, ensureWhisperCliScript } from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import { hasValidSubtitleCues, isGraphicSubtitleCodec, shouldFallbackToWhisper } from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import { buildDvdRemuxArgs, runDvdRemux, verifyDvdTitle } from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import { buildDvdStructurePayload, resolveRemuxPlanWithLlm, validateRemuxPlan } from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import { assertPreviewTaskAllowed, recordPreviewAiCall, settlePreviewTask } from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import { parseCustomTuning, resolveLogicPlaceholders } from "../lib/custom-tuning";
import { decryptSecret, encryptSecret, isEncryptedSecret } from "../lib/secrets";
import { ffmpegPath, resolveOutputDir, resolveRuntimePath, type RuntimePathConfig } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import { assertCompleteMediaTitle, createDvdMediaTitle } from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import { buildPreviewTranscodeArgs, isPreviewVideoCandidate, previewService } from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";
import {
  addLog,
  detectExistingSubtitleFiles,
  probeVideoPlayRes,
  trackJobOutputFile,
  type DetectedSubtitleFile,
} from "./jobs";

const BILINGUAL_ZH_SUFFIXES = ["zhs", "zh", "chs", "cn", "ds", "zh-cn", "zh-hans", "zh-hant", "sc", "chi", "gb", "zhs", "utf8"];
const BILINGUAL_EN_SUFFIXES = ["en", "eng", "original", "en-us", "en-gb", "english"];
const BILINGUAL_SUBTITLE_EXTS = new Set([".srt", ".ass", ".ssa", ".vtt"]);

function splitDualLanguageSubtitleBlocks(blocks: SubtitleBlock[]): { chinese: SubtitleBlock[]; foreign: SubtitleBlock[] } {
  const chinese: SubtitleBlock[] = [];
  const foreign: SubtitleBlock[] = [];
  for (const block of blocks) {
    const lines = block.text
      .split(/\r?\n/)
      .flatMap((line) => line.split(/(?<=[\u3400-\u9fff。！？；：，、])\s*(?=[A-Za-z])|(?<=[A-Za-z])\s*(?=[\u3400-\u9fff])/g))
      .map((line) => line.trim())
      .filter(Boolean);
    const chineseLines = lines.filter((line) => /[\u3400-\u9fff]/.test(line));
    const foreignLines = lines.filter((line) => !/[\u3400-\u9fff]/.test(line));
    if (chineseLines.length > 0) chinese.push({ ...block, text: chineseLines.join(" ") });
    if (foreignLines.length > 0) foreign.push({ ...block, text: foreignLines.join(" ") });
  }
  return { chinese, foreign };
}

/**
 * 直接合成：目录内已有与视频同名的中文字幕（.zhs/.zh/.chs/.ds 等）和外语字幕
 * （.en/.eng/.original 等）时，跳过翻译/OCR，直接用两份现成字幕渲染双语 ASS。
 */
export async function tryDirectBilingualMerge(params: {
  jobId: number;
  mediaInputPath: string;
  baseName: string;
  outputDir: string;
  style: BilingualAssStyle;
  addLog: (level: "info" | "warn" | "error", message: string) => Promise<void>;
}): Promise<{ chineseSrtPath: string; assPath: string } | null> {
  const directory = path.dirname(params.mediaInputPath);
  const lowerBase = params.baseName.toLowerCase();
  let entries: string[] = [];
  try {
    entries = await fs.readdir(directory);
  } catch (error) {
    await params.addLog("warn", `双语字幕：目录扫描失败：${error instanceof Error ? error.message : String(error)}`);
    return null;
  }
  const matched: string[] = [];
  for (const entry of entries) {
    const ext = path.extname(entry).toLowerCase();
    if (!BILINGUAL_SUBTITLE_EXTS.has(ext)) continue;
    const base = path.basename(entry, path.extname(entry)).toLowerCase();
    if (base !== lowerBase && !base.startsWith(`${lowerBase}.`)) continue;
    matched.push(entry);
  }
  if (matched.length === 0) {
    await params.addLog("info", "双语字幕：目录内未发现与视频同名的外挂字幕，走常规中文逻辑");
    return null;
  }
  // Some subtitle packs use a .ds/.dual suffix for a single file that already
  // contains Chinese and foreign lines. Split those cues by language before
  // rendering; treating the same file as both sides would duplicate Chinese.
  const detected = await detectExistingSubtitleFiles(directory, params.baseName).catch((): DetectedSubtitleFile[] => []);
  const mixed = detected
    .filter((item) => item.language === "bilingual")
    // Prefer the original dual-language sidecar (.ds/.dual) over an already
    // rendered ASS file that may be present from an earlier run.
    .sort((a, b) => {
      const score = (item: DetectedSubtitleFile) => {
        const lower = item.path.toLowerCase();
        if (/\.(?:ds|dual)\.(?:srt|ass|ssa|vtt)$/.test(lower)) return 0;
        if (/\.(?:ass|ssa)$/.test(lower)) return 2;
        return 1;
      };
      return score(a) - score(b);
    })[0];
  if (mixed) {
    // An ASS/SSA file produced by this pipeline is already a display-ready
    // bilingual artifact. Reuse it verbatim instead of parsing and rendering
    // it again (which would duplicate both language lines).
    if (/\.(?:ass|ssa)$/i.test(mixed.path)) {
      const assPath = path.join(params.outputDir, `${params.baseName}.ass`);
      if (path.resolve(assPath) !== path.resolve(mixed.path)) {
        await fs.copyFile(mixed.path, assPath).catch(() => {});
      }
      trackJobOutputFile(params.jobId, assPath);
      await params.addLog("info", `双语字幕：复用现有 ASS 双语文件（跳过翻译/OCR）→ ${assPath}`);
      return { chineseSrtPath: mixed.path, assPath };
    }
    const mixedBlocks = await readSubtitleBlocks(mixed.path).catch(() => [] as SubtitleBlock[]);
    const split = splitDualLanguageSubtitleBlocks(mixedBlocks);
    if (split.chinese.length > 0 && split.foreign.length > 0) {
      const playRes = await probeVideoPlayRes(params.mediaInputPath);
      const ass = renderBilingualAss(split.chinese, split.foreign, params.style, playRes);
      const assPath = path.join(params.outputDir, `${params.baseName}.ass`);
      trackJobOutputFile(params.jobId, assPath);
      await fs.writeFile(assPath, `\uFEFF${ass}`, "utf8");
      await params.addLog("info", `双语字幕：检测到单文件中英字幕，拆分后直接合成（跳过翻译/OCR）→ ${assPath}`);
      return { chineseSrtPath: mixed.path, assPath };
    }
  }
  const suffixOf = (entry: string): string => {
    const base = path.basename(entry, path.extname(entry)).toLowerCase();
    return base.startsWith(`${lowerBase}.`) ? base.slice(lowerBase.length + 1) : "";
  };
  const zhPriority: Record<string, number> = Object.fromEntries(BILINGUAL_ZH_SUFFIXES.map((suffix, index) => [suffix, index]));
  const enPriority: Record<string, number> = Object.fromEntries(BILINGUAL_EN_SUFFIXES.map((suffix, index) => [suffix, index]));
  const zhBySuffix = matched.filter((entry) => BILINGUAL_ZH_SUFFIXES.includes(suffixOf(entry)));
  const enBySuffix = matched.filter((entry) => BILINGUAL_EN_SUFFIXES.includes(suffixOf(entry)));
  let chineseFile: string | null = zhBySuffix.sort((a, b) => zhPriority[suffixOf(a)]! - zhPriority[suffixOf(b)]!)[0] ?? null;
  let foreignFile: string | null = enBySuffix.sort((a, b) => enPriority[suffixOf(a)]! - enPriority[suffixOf(b)]!)[0] ?? null;
  if (!chineseFile || !foreignFile) {
    if (!chineseFile) chineseFile = detected.find((item) => item.language === "zh")?.path ?? null;
    if (!foreignFile) foreignFile = detected.find((item) => item.language === "en")?.path ?? null;
  }
  // 一条同名的无语言后缀字幕（如 Movie.srt）通常就是原版外语轨，作为外语侧备用，
  // 否则“中文 + 无后缀外语”的目录永远配不齐（外语轨若为俄语/日语等非英语会漏配）。
  if (!foreignFile && chineseFile) {
    foreignFile =
      matched.find((entry) => suffixOf(entry) === "") ??
      matched.find((entry) => entry !== chineseFile && !BILINGUAL_ZH_SUFFIXES.includes(suffixOf(entry))) ??
      null;
  }
  if (!chineseFile || !foreignFile) {
    await params.addLog("info", `双语字幕：目录内${!chineseFile ? "缺少中文" : "缺少外语"}外挂字幕，走常规中文逻辑${chineseFile ? `（已找到中文 ${path.basename(chineseFile)}）` : ""}`);
    return null;
  }
  // detectExistingSubtitleFiles 返回绝对路径，后缀扫描返回相对文件名；
  // 统一处理，避免“目录 + 绝对路径”二次拼接导致读取失败。
  const resolveSubPath = (file: string) => (path.isAbsolute(file) ? file : path.join(directory, file));
  const chinesePath = resolveSubPath(chineseFile);
  const foreignPath = resolveSubPath(foreignFile);
  const chineseBlocks = await readSubtitleBlocks(chinesePath).catch((error) => {
    void params.addLog("warn", `双语字幕：中文字幕解析失败 ${path.basename(chineseFile!)}：${error instanceof Error ? error.message : String(error)}`);
    return null;
  });
  if (!chineseBlocks || chineseBlocks.length === 0) return null;
  const foreignBlocks = await readSubtitleBlocks(foreignPath).catch((error) => {
    void params.addLog("warn", `双语字幕：外语字幕解析失败 ${path.basename(foreignFile!)}：${error instanceof Error ? error.message : String(error)}`);
    return null;
  });
  if (!foreignBlocks || foreignBlocks.length === 0) return null;
  const playRes = await probeVideoPlayRes(params.mediaInputPath);
  const ass = renderBilingualAss(chineseBlocks, foreignBlocks, params.style, playRes);
  const assPath = path.join(params.outputDir, `${params.baseName}.ass`);
  // ASS 带中文必须写 UTF-8 BOM，否则部分 Windows 播放器按 ANSI 读取会乱码/无法显示。
  trackJobOutputFile(params.jobId, assPath);
  await fs.writeFile(assPath, `\uFEFF${ass}`, "utf8");
  await params.addLog("info", `双语字幕：检测到现成中英字幕，直接合成（跳过翻译/OCR）→ ${assPath}`);
  return { chineseSrtPath: chinesePath, assPath };
}

/** 双语字幕：中文来自既有中文逻辑产出，外文默认英语轨（无英语取第一条文字字幕轨），渲染 ASS。 */
export async function buildBilingualSubtitle(params: {
  jobId: number;
  mediaInputPath: string;
  chineseSrtPath: string | null;
  /** 外文字幕备用来源：OCR 识别出的原文 SRT（图形字幕轨无法直接提取文本时使用） */
  foreignSrtPath?: string | null;
  baseName: string;
  style: BilingualAssStyle;
  addLog: (level: "info" | "warn" | "error", message: string) => Promise<void>;
}): Promise<{ assPath: string } | null> {
  if (!params.chineseSrtPath) {
    await params.addLog("warn", "双语字幕：未取得中文字幕，跳过组装");
    return null;
  }
  let chineseBlocks: SubtitleBlock[];
  try {
    const chineseText = await fs.readFile(params.chineseSrtPath, "utf8");
    chineseBlocks = toSubtitleBlocks(parseSrt(chineseText.replace(/\r\n/g, "\n")));
  } catch (error) {
    await params.addLog("warn", `双语字幕：中文字幕读取失败：${error instanceof Error ? error.message : String(error)}`);
    return null;
  }
  if (chineseBlocks.length === 0) {
    await params.addLog("warn", "双语字幕：中文字幕为空");
    return null;
  }
  const ffmpegExecutable = await resolveToolPath("ffmpeg");
  const ffprobeExecutable = await resolveToolPath("ffprobe");
  let foreignBlocks: SubtitleBlock[] = [];
  // 优先使用管道已提取的外文字幕（= 按"最全/包数最多"选出的轨道），
  // 避免"英文优先、否则第一条"重新探测出与中文侧不一致的轨道。
  if (params.foreignSrtPath) {
    try {
      const foreignText = await fs.readFile(params.foreignSrtPath, "utf8");
      foreignBlocks = toSubtitleBlocks(parseSrt(foreignText.replace(/\r\n/g, "\n")));
      if (foreignBlocks.length > 0) {
        await params.addLog("info", `双语字幕：复用已提取的外文字幕 ${path.basename(params.foreignSrtPath)}（${foreignBlocks.length} 条）`);
      }
    } catch (error) {
      await params.addLog("warn", `双语字幕：外文字幕读取失败：${error instanceof Error ? error.message : String(error)}`);
    }
  }
  if (foreignBlocks.length === 0 && ffmpegExecutable && ffprobeExecutable) {
    try {
      const probe = await jobToolExecutor.run(params.jobId, ffprobeExecutable, ["-v", "error", "-print_format", "json", "-show_streams", params.mediaInputPath]);
      const parsed = JSON.parse(probe.stdout) as { streams?: Array<{ index: number; codec_type?: string | null; codec_name?: string | null; tags?: { language?: string | null } }> };
      const graphic = ["dvd_subtitle", "hdmv_pgs_subtitle", "pgssub", "vobsub"];
      const textSubs = (parsed.streams ?? []).filter(
        (stream) => stream.codec_type === "subtitle" && !graphic.includes(String(stream.codec_name ?? "").toLowerCase()),
      );
      const english = textSubs.find((stream) => (stream.tags?.language ?? "").toLowerCase().startsWith("en"));
      const foreign = english ?? textSubs[0] ?? null;
      if (foreign) {
        const tempSrt = path.join(os.tmpdir(), `vx-bilingual-${params.jobId}-${Date.now()}.srt`);
        // 注意：不要加 -c:s srt——该参数会让部分 FFmpeg 构建报“codec none”导致提取失败；
        // 输出扩展名 .srt 会自动选择字幕编码器。
        await jobToolExecutor.run(params.jobId, ffmpegExecutable, ["-y", "-i", params.mediaInputPath, "-map", `0:${foreign.index}`, tempSrt]);
        const foreignText = await fs.readFile(tempSrt, "utf8");
        foreignBlocks = toSubtitleBlocks(parseSrt(foreignText.replace(/\r\n/g, "\n")));
        await fs.rm(tempSrt, { force: true }).catch(() => {});
        await params.addLog("info", `双语字幕：外文字幕轨（语言=${foreign.tags?.language ?? "未知"}）就绪，${foreignBlocks.length} 条`);
      } else {
        await params.addLog("warn", "双语字幕：未找到内置文字字幕轨，尝试复用目录中的英文字幕文件…");
      }
    } catch (error) {
      await params.addLog("warn", `双语字幕：内置外文字幕获取失败，尝试复用目录中的英文字幕文件：${error instanceof Error ? error.message : String(error)}`);
    }
    if (foreignBlocks.length === 0) {
      try {
        const existingSubs = await detectExistingSubtitleFiles(
          path.dirname(params.mediaInputPath),
          path.basename(params.mediaInputPath, path.extname(params.mediaInputPath)),
        );
        const englishFile = existingSubs.find((item) => item.language === "en");
        if (englishFile) {
          const englishText = await fs.readFile(englishFile.path, "utf8");
          foreignBlocks = toSubtitleBlocks(parseSrt(englishText.replace(/\r\n/g, "\n")));
          await params.addLog("info", `双语字幕：复用目录英文字幕文件 ${path.basename(englishFile.path)}（${foreignBlocks.length} 条）`);
        }
      } catch (error) {
        await params.addLog("warn", `双语字幕：外挂英文字幕读取失败：${error instanceof Error ? error.message : String(error)}`);
      }
    }
    if (foreignBlocks.length === 0 && params.foreignSrtPath) {
      try {
        const foreignText = await fs.readFile(params.foreignSrtPath, "utf8");
        foreignBlocks = toSubtitleBlocks(parseSrt(foreignText.replace(/\r\n/g, "\n")));
        if (foreignBlocks.length > 0) {
          await params.addLog("info", `双语字幕：复用 OCR 识别的外文字幕 ${path.basename(params.foreignSrtPath)}（${foreignBlocks.length} 条）`);
        } else {
          await params.addLog("warn", "双语字幕：OCR 外文字幕为空，仅输出中文");
        }
      } catch (error) {
        await params.addLog("warn", `双语字幕：OCR 外文字幕读取失败：${error instanceof Error ? error.message : String(error)}`);
      }
    }
    if (foreignBlocks.length === 0) {
      await params.addLog("warn", "双语字幕：未找到可用的外文字幕（内置文字轨/外挂英文/OCR 均无），仅输出中文");
    }
  }
  const playRes = await probeVideoPlayRes(params.mediaInputPath);
  const ass = renderBilingualAss(chineseBlocks, foreignBlocks, params.style, playRes);
  const assPath = path.join(path.dirname(params.chineseSrtPath), `${params.baseName}.ass`);
  // ASS 带中文必须写 UTF-8 BOM，否则部分 Windows 播放器按 ANSI 读取会导致乱码/无法显示。
  trackJobOutputFile(params.jobId, assPath);
  await fs.writeFile(assPath, `\uFEFF${ass}`, "utf8");
  await params.addLog("info", `双语字幕完成 → ${assPath}`);
  return { assPath };
}
