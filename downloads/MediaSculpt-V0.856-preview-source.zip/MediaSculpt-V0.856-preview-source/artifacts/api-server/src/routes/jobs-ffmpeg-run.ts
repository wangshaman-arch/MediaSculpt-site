// Extracted from routes/jobs.ts: ffmpeg capture runner and output verification.
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { lookupAll, metadataIdentityMatches, normalizeTitleEn } from "../lib/metadata";
import { servePreviewSegment, cleanupPreviewSegments } from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import { buildFfconcatFileContent as buildManifest, buildFfconcatChapterContent, buildFfconcatTimedContent, type FfconcatTimedSegment } from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import { addLog } from "./jobs";
import { appendJobRuntimeLog, appendJobToolOutput } from "../lib/job-runtime-log";
import { appendRuntimeToolLog, appendRuntimeToolOutput } from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import { buildCompressionOutputName, buildRemuxOutputName, cleanSegment, encoderBitDepth, selectBestAudioTrack } from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import { renderBilingualAss, DEFAULT_BILINGUAL_STYLE, type BilingualAssStyle, type SubtitleBlock } from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import { ensureLocalPoster, MEDIA_INFO_DIR, POSTER_META_FILE, posterIdentityMatches } from "../lib/poster";
import { ensureFasterWhisperModel, ensureWhisperCliScript } from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import { hasValidSubtitleCues, isGraphicSubtitleCodec, shouldFallbackToWhisper } from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import { buildDvdRemuxArgs, runDvdRemux, verifyDvdTitle } from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import { buildDvdStructurePayload, resolveRemuxPlanWithLlm, validateRemuxPlan } from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import { assertPreviewTaskAllowed, recordPreviewAiCall, settlePreviewTask } from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import { parseCustomTuning, resolveLogicPlaceholders } from "../lib/custom-tuning";
import { decryptSecret, encryptSecret, isEncryptedSecret } from "../lib/secrets";
import { ffmpegPath, resolveOutputDir, resolveRuntimePath, type RuntimePathConfig } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import { assertCompleteMediaTitle, createDvdMediaTitle } from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import { buildPreviewTranscodeArgs, isPreviewVideoCandidate, previewService } from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";

export async function verifyOutputEndPlayable(jobId: number, outputPath: string, durationSeconds: number | null): Promise<{ ok: boolean; error: string | null }> {
  if (!durationSeconds || durationSeconds < 2) return { ok: true, error: null };
  const ffmpegExecutable = await resolveToolPath("ffmpeg");
  if (!ffmpegExecutable) return { ok: true, error: null };
  // Seek from the end of the file (-sseof) so a slightly-off probed duration
  // can never point past EOF and produce a false failure.
  const startFromEnd = Math.min(30, Math.max(1, durationSeconds - 2));
  return new Promise((resolve) => {
    const child = jobProcessController.spawnForJob(jobId, ffmpegExecutable, ["-v", "error", "-sseof", `-${startFromEnd}`, "-i", ffmpegPath(outputPath), "-t", "8", "-f", "null", "-"]);
    let stderr = "";
    let settled = false;
    // 输出末尾校验也加超时，防止校验阶段无限挂起。
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      try { child.kill("SIGKILL"); } catch { /* ignore */ }
      resolve({ ok: false, error: "输出末尾校验超时" });
    }, 60_000);
    if (child.stderr) child.stderr.on("data", (chunk: Buffer) => { stderr += chunk.toString(); });
    child.on("close", (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve(code === 0 ? { ok: true, error: null } : { ok: false, error: stderr.trim().split("\n").slice(-4).join(" ") || `ffmpeg exit ${code}` });
    });
    child.on("error", (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({ ok: false, error: error.message });
    });
  });
}

export function snapshotTitleIndex(taskSnapshot: unknown): number {
  const selectedTitleId = typeof (taskSnapshot as { selectedTitleId?: unknown } | null)?.selectedTitleId === "string"
    ? (taskSnapshot as { selectedTitleId: string }).selectedTitleId
    : "";
  const match = /^(?:mpls|handbrake):(\d+)$/.exec(selectedTitleId);
  return match ? Number(match[1]) - 1 : -1;
}

export async function runFfmpegCapture(jobId: number, args: string[], expectedDurationSeconds?: number | null): Promise<void> {
  const ffmpegExecutable = await resolveToolPath("ffmpeg");
  if (!ffmpegExecutable) throw new Error("未找到项目实际使用的 FFmpeg");
  await addLog(jobId, "info", `FFmpeg 参数：${args.join(" ")}`);
  const [jobRow] = await db.select({ durationSeconds: jobsTable.durationSeconds })
    .from(jobsTable).where(eq(jobsTable.id, jobId)).limit(1);
  const totalDuration = expectedDurationSeconds && expectedDurationSeconds > 0
    ? expectedDurationSeconds
    : (jobRow?.durationSeconds ?? null);
  return new Promise((resolve, reject) => {
    // 必须走 trackSpawnForJob 登记子进程，否则取消时无法终止 ffmpeg。
    const child = jobProcessController.spawnForJob(jobId, ffmpegExecutable, args);
    let errOut = "";
    let lastProgressWrite = 0;
    let lastSecs = 0;
    const startedAt = Date.now();
    let lastActivityAt = Date.now();
    let settled = false;
    // 无进展看门狗：90 秒内没有任何 stderr 输出即判定卡死（源文件/网络停顿），
    // 自动终止，避免任务无限挂起。
    const watchdog = setInterval(() => {
      if (settled) return;
      if (Date.now() - lastActivityAt > 90_000) {
        settled = true;
        try { child.kill("SIGKILL"); } catch { /* ignore */ }
        clearInterval(watchdog);
        reject(new Error("ffmpeg 长时间无进展（可能源文件或网络卡住），已自动终止"));
      }
    }, 15_000);
    if (child.stderr) child.stderr.on("data", (chunk) => {
      lastActivityAt = Date.now();
      const text = String(chunk);
      errOut += text;
      if (!totalDuration || totalDuration <= 0) return;
      const matches = [...text.matchAll(/time=(\d+):(\d+):([0-9.]+)/g)];
      if (matches.length === 0) return;
      const match = matches[matches.length - 1]!;
      const secs = Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3]);
      if (!Number.isFinite(secs)) return;
      lastSecs = Math.max(lastSecs, secs);
      const now = Date.now();
      if (now - lastProgressWrite < 1000) return;
      lastProgressWrite = now;
      const progress = mapExternalToolProgress({
        toolPercent: Math.min(lastSecs / totalDuration, 1) * 100,
        start: 0,
        end: 95,
      });
      const elapsedSec = (now - startedAt) / 1000;
      const etaSeconds = lastSecs > 0 && elapsedSec > 0
        ? Math.max(0, Math.round((totalDuration - lastSecs) * (elapsedSec / lastSecs)))
        : null;
      void db.update(jobsTable).set({ progress, etaSeconds }).where(eq(jobsTable.id, jobId)).catch(() => {});
    });
    child.on("close", (code) => {
      if (settled) return;
      settled = true;
      clearInterval(watchdog);
      if (code === 0) resolve(); else reject(new Error(`ffmpeg 退出码 ${code}: ${errOut.slice(-400)}`));
    });
    child.on("error", (error) => {
      if (settled) return;
      settled = true;
      clearInterval(watchdog);
      reject(error);
    });
  });
}
