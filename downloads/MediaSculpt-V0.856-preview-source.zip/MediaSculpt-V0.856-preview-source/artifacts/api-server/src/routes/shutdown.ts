import { Router } from "express";
import { db, jobsTable } from "@workspace/db";
import { sql } from "drizzle-orm";
import { logger } from "../lib/logger";
import { unmountAllIsoMounts } from "./jobs";

const router = Router();

async function hasActiveJobs(): Promise<boolean> {
  // 只拦截“正在运行”的任务（扫描/转写/压缩）；排队中的任务（pending）不拦截退出，
  // 退出后保持排队状态，下次启动自动继续执行，避免排了一队就永远关不掉软件。
  const activeJobs = await db.select({ id: jobsTable.id }).from(jobsTable).where(
    sql`status IN ('scanning','transcribing','compressing')`,
  ).limit(1);
  return activeJobs.length > 0;
}

router.post("/shutdown", async (_req, res) => {
  if (await hasActiveJobs()) {
    return res.status(409).json({ error: "仍有任务正在执行，不能退出影刻。" });
  }

  res.status(202).json({ ok: true, message: "影刻正在退出。" });
  setTimeout(() => {
    logger.info("Manual shutdown requested from app menu");
    void unmountAllIsoMounts().finally(() => {
      process.kill(process.pid, "SIGTERM");
    });
  }, 250).unref();
  return;
});

export default router;
