import { describe, expect, it } from "vitest";
import {
  chooseBlurayHandBrakeChapterTitle,
  clampBlurayChapters,
  readPersistedBlurayChapters,
} from "./job-bluray-chapter-context";

describe("Blu-ray chapter context", () => {
  it("reads persisted chapter times and applies stable defaults", () => {
    expect(readPersistedBlurayChapters(JSON.stringify({
      chapterTimes: [{ id: 3, startSeconds: 10, endSeconds: 20 }],
    }))).toEqual([{ id: 3, startSeconds: 10, endSeconds: 20, title: null }]);
  });

  it("ignores malformed persisted chapter data", () => {
    expect(readPersistedBlurayChapters("not-json")).toEqual([]);
    expect(readPersistedBlurayChapters(JSON.stringify({ chapterTimes: [] }))).toEqual([]);
  });

  it("prefers the selected HandBrake title and otherwise matches duration", () => {
    const titles = [
      { titleNumber: 1, durationSeconds: 30, chapters: [] },
      { titleNumber: 2, durationSeconds: 100, chapters: [] },
    ];
    expect(chooseBlurayHandBrakeChapterTitle(titles, "handbrake:1", 100)?.titleNumber).toBe(1);
    expect(chooseBlurayHandBrakeChapterTitle(titles, null, 96)?.titleNumber).toBe(2);
  });

  it("clamps, sorts, filters and de-duplicates chapters against the effective duration", () => {
    expect(clampBlurayChapters([
      { id: 2, startSeconds: 20, endSeconds: 40, title: null },
      { id: 1, startSeconds: 0, endSeconds: 10, title: null },
      { id: 3, startSeconds: 20, endSeconds: 30, title: null },
      { id: 4, startSeconds: 50, endSeconds: 60, title: null },
    ], 45)).toEqual([
      { id: 1, startSeconds: 0, endSeconds: 10, title: null },
      { id: 2, startSeconds: 20, endSeconds: 40, title: null },
    ]);
  });
});
