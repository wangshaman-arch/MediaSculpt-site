import fs from "fs/promises";
import os from "os";
import path from "path";
import type { TaskSnapshotV1 } from "../lib/task-snapshot";
import { expectedRemuxSizeBytes } from "../lib/disc-expectations";
import type { DvdTitle } from "../lib/disc";
import {
  assertDvdTitleComplete,
  dvdNavigationTitleWithVerifiedNumber,
  writeDvdConcatListFile,
  buildFfconcatFileContent,
} from "./jobs-dvd";

export type DvdRemuxInputContext = {
  concatListFile: string | null;
  dvdNavigationTitle: DvdTitle | null;
  remuxExpectedSizeBytes: number | null;
};

/** Find content VOBs belonging to an IFO, excluding the menu/index VOB. */
export function findDvdVobFiles(ifoPath: string, entries: string[]): string[] {
  const ifoStem = path.basename(ifoPath, path.extname(ifoPath));
  const vtsGroup = ifoStem.replace(/_0$/i, "");
  const escapedGroup = vtsGroup.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const pattern = new RegExp(`^${escapedGroup}_\\d+\\.VOB$`, "i");
  return entries
    .filter((entry) => pattern.test(entry))
    .map((entry) => ({ name: entry, index: parseInt(entry.match(/_(\d+)\.VOB$/i)?.[1] ?? "0", 10) }))
    .filter((entry) => entry.index > 0)
    .sort((a, b) => a.index - b.index)
    .map((entry) => entry.name);
}

/** Resolve DVD navigation or VOB-concat input without constructing FFmpeg args. */
export async function prepareDvdRemuxInput(input: {
  jobId: number;
  sourcePath: string;
  isIfoInput: boolean;
  isMplsInput: boolean;
  mediaType: string;
  taskSnapshot: TaskSnapshotV1 | null;
  dvdTitle: DvdTitle | null;
  selectedTitleSizeBytes: number | null;
  selectedAnalysisEstimatedSize: number | null;
  resolveDvdTitleForSource: (
    sourcePath: string,
    minSizeBytes?: number,
    requestedTitleNumber?: number,
  ) => Promise<DvdTitle | null>;
  resolveDvdTitleForIfo: (sourcePath: string) => Promise<DvdTitle | null>;
  writeDvdConcatListFile?: (title: DvdTitle, purpose: string) => Promise<string>;
  trackTempFile?: (filePath: string) => void;
  log: (level: "info" | "warn", message: string) => Promise<unknown>;
}): Promise<DvdRemuxInputContext> {
  let concatListFile: string | null = null;
  let dvdNavigationTitle: DvdTitle | null = null;
  let remuxExpectedSizeBytes = input.dvdTitle?.sizeBytes ?? null;
  const writeConcat = input.writeDvdConcatListFile ?? writeDvdConcatListFile;

  if (!input.isIfoInput && !input.isMplsInput && input.mediaType === "dvd") {
    const requestedTitleNumber = input.taskSnapshot?.toolSelections.dvdVtsNumber ?? undefined;
    const resolvedTitle = await input.resolveDvdTitleForSource(
      input.sourcePath,
      0,
      requestedTitleNumber,
    ).catch(() => null);
    assertDvdTitleComplete(resolvedTitle);
    if (resolvedTitle?.titleNumber && resolvedTitle.discRoot) {
      dvdNavigationTitle = dvdNavigationTitleWithVerifiedNumber(resolvedTitle, input.taskSnapshot);
      remuxExpectedSizeBytes = expectedRemuxSizeBytes({
        hasTaskSnapshot: Boolean(input.taskSnapshot),
        selectedTitleSizeBytes: input.selectedTitleSizeBytes,
        selectedAnalysisEstimatedSize: input.selectedAnalysisEstimatedSize,
        resolvedMainTitleSizeBytes: resolvedTitle.sizeBytes,
      });
      const effectiveNumber = dvdNavigationTitle.titleNumber;
      const suffix = effectiveNumber !== resolvedTitle.titleNumber
        ? `（已用 ffprobe 验证的 dvdvideo 标题 ${effectiveNumber} 替换 VTS 序号 ${resolvedTitle.titleNumber}）`
        : "";
      await input.log("info", `DVD 导航模式：使用标题 ${effectiveNumber}，光盘根目录：${resolvedTitle.discRoot}${suffix}`);
    } else if (resolvedTitle?.vobFiles.length) {
      concatListFile = await writeConcat(resolvedTitle, `vob-${input.jobId}`);
      await input.log("warn", "DVD 标题号不可用，退回 VOB concat；这可能无法保留完整 IFO 导航时间轴。");
      await input.log("info", `DVD VOB concat (${resolvedTitle.vobFiles.length} 个): ${resolvedTitle.vobFiles.map((file) => path.basename(file)).join(", ")}`);
    } else {
      await input.log("warn", `未解析到 DVD 标题（${input.sourcePath}），将尝试按普通文件处理`);
    }
  }

  if (input.isIfoInput) {
    const title = input.dvdTitle ?? await input.resolveDvdTitleForIfo(input.sourcePath);
    assertDvdTitleComplete(title);
    if (title?.titleNumber && title.discRoot) {
      dvdNavigationTitle = dvdNavigationTitleWithVerifiedNumber(title, input.taskSnapshot);
      const effectiveNumber = dvdNavigationTitle.titleNumber;
      const suffix = effectiveNumber !== title.titleNumber
        ? `（已用 ffprobe 验证的 dvdvideo 标题 ${effectiveNumber} 替换 VTS 序号 ${title.titleNumber}）`
        : "";
      await input.log("info", `DVD 导航模式：使用标题 ${effectiveNumber}，光盘根目录：${title.discRoot}${suffix}`);
    } else if (title?.vobFiles.length) {
      concatListFile = await writeConcat(title, `vob-${input.jobId}`);
      await input.log("warn", "DVD 标题号不可用，退回 VOB concat；这可能无法保留完整 IFO 导航时间轴。");
      await input.log("info", `DVD VOB concat (${title.vobFiles.length} 个): ${title.vobFiles.map((file) => path.basename(file)).join(", ")}`);
      await input.log("info", `DVD concat 清单：${concatListFile}`);
    }

    if (!dvdNavigationTitle && !concatListFile) {
      const ifoDir = path.dirname(input.sourcePath);
      const entries = await fs.readdir(ifoDir).catch(() => [] as string[]);
      const vobFiles = findDvdVobFiles(input.sourcePath, entries).map((file) => path.join(ifoDir, file));
      if (vobFiles.length > 0) {
        concatListFile = path.join(os.tmpdir(), `vx-vob-${input.jobId}-${Date.now()}.ffconcat`);
        input.trackTempFile?.(concatListFile);
        await fs.writeFile(concatListFile, buildFfconcatFileContent(vobFiles), "utf8");
        await fs.stat(concatListFile);
        await input.log("warn", "DVD IFO 标题解析不足，退回 VOB concat；输出时间轴可能不完整。");
        await input.log("info", `DVD VOB concat (${vobFiles.length} 个): ${vobFiles.map((file) => path.basename(file)).join(", ")}`);
        await input.log("info", `DVD concat 清单：${concatListFile}`);
      } else {
        await input.log("warn", "未找到配套 VOB 文件，将直接尝试读取 IFO（需要 libdvdread）");
      }
    }
  }

  return { concatListFile, dvdNavigationTitle, remuxExpectedSizeBytes };
}
