import fsSync from "fs";
import os from "os";
import path from "path";
import fs from "fs/promises";
import { db, jobsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import {
  buildDvdRemuxArgs,
  runDvdRemux,
  verifyDvdTitle,
  type DvdStream,
} from "../lib/dvd-remux";
import { assertCompleteMediaTitle, createDvdMediaTitle } from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import { buildCompressionArgsForJob } from "../media/compression-pipeline";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import { buildGraphicSubtitleExportArgs, runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import { explicitTranslationFailureMessage, hasValidSubtitleCues, isGraphicSubtitleCodec, shouldFallbackToWhisper, subtitleOnlyOutputDisposition } from "../lib/subtitle-utils";
import { ensureFasterWhisperModel, ensureWhisperCliScript } from "../lib/whisper-runtime";
import { renderBilingualAss, type SubtitleBlock } from "../lib/bilingual-subtitle";
import {
  parseBlurayChapters,
  parseBlurayMpls,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  type DvdTitle,
} from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import { mapExternalToolProgress, shouldUseVerifiedDvdRemux } from "../lib/job-workflow";
import { renderSrtSimplified } from "../media/subtitle-service";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import { buildFfconcatFileContent as buildManifest, buildFfconcatChapterContent, buildFfconcatTimedContent, type FfconcatTimedSegment } from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import { appendJobRuntimeLog, appendJobToolOutput } from "../lib/job-runtime-log";
import { appendRuntimeToolLog, appendRuntimeToolOutput } from "../lib/runtime-tool-log";
import { buildCompressionOutputName, buildRemuxOutputName, cleanSegment, encoderBitDepth } from "../lib/output-naming";
import { dvdOutputBaseName } from "../lib/dvd-source-identity";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import { resolvePosterProxyUrl } from "../lib/http-client";
import { assertPreviewTaskAllowed, recordPreviewAiCall, settlePreviewTask } from "../lib/preview-runtime";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import { resolveToolPath } from "../lib/tool-runtime";
import { ffmpegPath, resolveOutputDir, resolveRuntimePath } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { parseSrt, toSubtitleBlocks, readSubtitleBlocks, type SrtBlock } from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  loadTaskSnapshot,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { parseCustomTuning, resolveLogicPlaceholders } from "../lib/custom-tuning";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { lookupAll, metadataIdentityMatches, normalizeTitleEn } from "../lib/metadata";
import { decryptSecret, encryptSecret, isEncryptedSecret } from "../lib/secrets";
import { buildSourceManifest } from "../lib/source-manifest";
import { isDvdDisc, isBlurayDisc, resolveMainTrack } from "./jobs";
import {
  addLog,
  cancelledJobs,
  clearJobOutputFiles,
  discAnalysisRegistry,
  dvdVideoInputPath,
  ensureAnalysisIsoReady,
  ensureDvdCssSupport,
  getConfig,
  killJobProcesses,
  probeStreams,
  probeMediaStreams,
  registerDiscAnalysisForTaskCreation,
  removeIncompleteJobOutputs,
  resolveJobOutputDirectory,
  resolveJobSubtitleDirectory,
  runningJobStatuses,
  selectExternalSubtitleForJob,
  setQueuePaused,
  settlePreviewTaskSafely,
  snapshotTitleIndex,
  startNextPendingJob,
  trackJobOutputFile,
  validateTaskSnapshotBeforeStart,
  type DvdVerificationResult,
  buildBilingualSubtitle,
  buildDvdTypeMaps,
  buildFfconcatFileContent,
  buildLosslessRemuxArgs,
  buildTranslationPrompt,
  buildWhisperCorrectionPrompt,
  detectInterlacedFromStreams,
  dvdConcatInputArgs,
  dvdInputArg,
  dvdTitleNavigationInputArgs,
  ensureDirectory,
  executeOcrSubtitleFlow,
  ffmpegSupportsDvdTitleNavigation,
  fixAssPlayResForOutput,
  fullSubtitlePacketThreshold,
  isVobConcatList,
  languageTagIsChinese,
  mountBlurayIso,
  ocrTitleIdForTaskSnapshot,
  outputDirectoryForTask,
  pickBestAudioTrack,
  probeAudioTracks,
  probeDvdAudioCodecs,
  probeDvdTitleByNumber,
  probeSubtitlePacketCount,
  processChapterPreviewJob,
  processVerifiedDvdRemuxJob,
  runAiAssetStage,
  runFfmpegCapture,
  sampleEmbeddedSubtitleText,
  selectedDvdAudioCodecs,
  stageSubtitleSidecars,
  SUBTITLE_FILE_EXT_RE,
  textLooksChinese,
  translateBatch,
  translateBatchLibre,
  tryDirectBilingualMerge,
  unmountBlurayIso,
  validateCompressionOutput,
  validateJobViability,
  verifyOutputEndPlayable,
  whisperDetectedLanguage,
  writeDvdConcatListFile,
  blockedReasonMessage,
  detectExistingSubtitleFiles,
} from "./jobs";
import { buildJobExecutionContext } from "./job-execution-context";
import { prepareJobMediaInput } from "./job-media-input-context";
import { probeJobMedia } from "./job-media-probe-context";
import { finalizeRemuxStage } from "./job-remux-finalization";
import { tryRemuxBluRayM2ts } from "./job-remux-bluray-m2ts";
import { buildDvdVobFallbackArgs } from "./job-dvd-remux-fallback";
import { resolveBlurayPlaylistInput } from "./job-bluray-playlist-input";
import { probeAndTrimBluraySegments } from "./job-bluray-segment-context";
import { chooseBlurayHandBrakeChapterTitle, clampBlurayChapters, readPersistedBlurayChapters } from "./job-bluray-chapter-context";
import { prepareDvdRemuxInput } from "./job-dvd-remux-input";
import { prepareMplsRemuxInput } from "./job-mpls-remux-input";
import { parseSelectedChapterIds, readPersistedSelectedChapters, selectChaptersById } from "./job-remux-chapter-selection";
import { isPlayableRemuxProbe } from "./job-remux-output-health";
import { describeOutputCapacity, estimateOutputCapacity, type OutputCapacityMode } from "../lib/output-capacity";
export async function processJob(jobId: number) {
  const config = await getConfig();
  let aiProxyResolved = false;
  let aiProxyUrl: string | null = null;
  const getAiProxyUrl = async () => {
    if (!aiProxyResolved) {
      aiProxyUrl = await resolvePosterProxyUrl(config.posterProxyUrl);
      aiProxyResolved = true;
    }
    return aiProxyUrl;
  };

  await db.update(jobsTable).set({
    status: "scanning",
    startedAt: new Date(),
    progress: 0,
  }).where(eq(jobsTable.id, jobId));
  await addLog(jobId, "info", "任务开始 — 正在扫描文件");

  const jobRows = await db.select().from(jobsTable).where(eq(jobsTable.id, jobId)).limit(1);
  if (!jobRows.length) return;
  let job = {
    ...jobRows[0],
    filePath: resolveRuntimePath(jobRows[0].filePath, config),
    mainTrackPath: jobRows[0].mainTrackPath ? resolveRuntimePath(jobRows[0].mainTrackPath, config) : null,
  };
  const taskSnapshot = loadTaskSnapshot(jobRows[0]);
  // 智能生成优先：说明 → 影评 → 海报，先于 Remux/字幕/压缩完成。
  // 所有任务类型（压缩/Remux/字幕/章节预览/纯生成）统一在此阶段处理，
  // 单项失败只记录日志，不阻塞视频处理。
  await runAiAssetStage(jobId, config, job);
  // Fail fast with a clear message when the output drive is nearly full,
  // instead of failing halfway through a large export.
  try {
    const diskOutputDir = outputDirectoryForTask(config, job);
    const diskStat = await fs.statfs(diskOutputDir);
    const freeGB = (Number(diskStat.bavail) * Number(diskStat.bsize)) / 1_000_000_000;
    if (freeGB < 2) {
      const message = `输出磁盘空间不足（剩余 ${freeGB.toFixed(1)} GB），已中止任务；请清理磁盘或更换输出目录`;
      await db.update(jobsTable).set({ status: "error", errorMessage: message, completedAt: new Date() }).where(eq(jobsTable.id, jobId));
      await addLog(jobId, "error", message);
      cancelledJobs.delete(jobId);
      jobProcessController.clearJob(jobId);
      void startNextPendingJob().catch(() => {});
      return;
    }
  } catch {
    // statfs unavailable or the directory cannot be resolved — skip the precheck.
  }
  const {
    pipelineSteps,
    pipelineNames,
    pipelineRemuxIndex,
    pipelineSubtitleIndex,
    pipelineCompressIndex,
    pipelineHasRemux,
    pipelineHasSubtitle,
    pipelineHasCompress,
    pipelineContinuesAfterRemux,
    isBilingual,
    subtitleMode,
    selectionPlanOptions,
    bilingualStyle,
  } = buildJobExecutionContext({ job: jobRows[0], config });

  if (shouldUseVerifiedDvdRemux({
    mediaType: job.mediaType,
    processingMode: job.processingMode,
    pipelineHasRemux,
    pipelineHasCompress,
    pipelineContinuesAfterRemux,
  })) {
    try {
      await processVerifiedDvdRemuxJob(jobId, jobRows[0], config);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (!cancelledJobs.has(jobId)) {
        await db.update(jobsTable).set({ status: "error", errorMessage: message, completedAt: new Date() }).where(eq(jobsTable.id, jobId));
        await addLog(jobId, "error", `DVD Remux 失败：${message}`);
      }
    } finally {
      cancelledJobs.delete(jobId);
      jobProcessController.clearJob(jobId);
      void startNextPendingJob().catch(() => {});
    }
    return;
  }

  // 章节预览为独立模式：不进入压缩/字幕流水线，生成后任务即结束。
  if (job.processingMode === "chapterPreview") {
    try {
      await processChapterPreviewJob(jobId, job, config);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (!cancelledJobs.has(jobId)) {
        await db.update(jobsTable).set({ status: "error", errorMessage: message, completedAt: new Date() }).where(eq(jobsTable.id, jobId));
        await addLog(jobId, "error", `章节预览失败：${message}`);
        await removeIncompleteJobOutputs(jobId, (logMessage) => addLog(jobId, "info", logMessage));
      }
    } finally {
      cancelledJobs.delete(jobId);
      jobProcessController.clearJob(jobId);
      clearJobOutputFiles(jobId);
      void startNextPendingJob().catch(() => {});
    }
    return;
  }

  const mediaInputContext = await prepareJobMediaInput({
    jobId,
    job,
    taskSnapshot,
    config,
    log: (level, message) => addLog(jobId, level, message),
    probeDvdTitleByNumber: probeDvdTitleByNumber,
  });
  job = mediaInputContext.job;
  const {
    mediaInputPath,
    dvdVideoInput,
    dvdTitle,
    selectedHandBrakePlan,
    selectedTitleSizeBytes,
    selectedAnalysisTitle,
  } = mediaInputContext;
  let handbrakeInputPath = mediaInputContext.handbrakeInputPath;
  let selectedTitleDurationSeconds = mediaInputContext.selectedTitleDurationSeconds;
  let temporaryRemuxPath: string | null = null;

  // Do the size-aware check after disc title/playlist selection. The earlier
  // minimum check catches nearly-full disks; this check catches a large
  // Remux or combined pipeline that would otherwise fail halfway through.
  const capacityMode: OutputCapacityMode = pipelineHasRemux && pipelineHasCompress
    ? "both"
    : pipelineHasRemux || job.processingMode === "remux"
      ? "remux"
      : pipelineHasCompress || job.processingMode === "compress"
        ? "compress"
        : "none";
  if (capacityMode !== "none") {
    try {
      const outputDirectory = outputDirectoryForTask(config, job);
      await ensureDirectory(outputDirectory);
      let sourceBytes = selectedTitleSizeBytes ?? null;
      if (sourceBytes === null) {
        const stat = await fs.stat(mediaInputPath).catch(() => null);
        if (stat?.isFile()) sourceBytes = stat.size;
      }
      const estimate = estimateOutputCapacity(capacityMode, sourceBytes);
      const diskStat = await fs.statfs(outputDirectory);
      const availableBytes = Number(diskStat.bavail) * Number(diskStat.bsize);
      if (availableBytes < estimate.requiredFreeBytes) {
        const message = describeOutputCapacity(availableBytes, estimate);
        await db.update(jobsTable).set({ status: "error", errorMessage: message, completedAt: new Date() }).where(eq(jobsTable.id, jobId));
        await addLog(jobId, "error", message);
        cancelledJobs.delete(jobId);
        jobProcessController.clearJob(jobId);
        void startNextPendingJob().catch(() => {});
        return;
      }
      await addLog(jobId, "info", `输出空间预检通过：可用 ${(availableBytes / 1_000_000_000).toFixed(1)} GB，需要 ${(estimate.requiredFreeBytes / 1_000_000_000).toFixed(1)} GB`);
    } catch (error) {
      await addLog(jobId, "warn", `输出空间预检跳过（不影响任务）：${error instanceof Error ? error.message : String(error)}`);
    }
  }

  try {
    if (selectedTitleSizeBytes) {
      await db.update(jobsTable).set({ fileSizeBefore: selectedTitleSizeBytes }).where(eq(jobsTable.id, jobId));
    } else if (job.mediaType === "dvd" && taskSnapshot) {
      // HandBrake's DVD scan does not provide a reliable per-title byte size.
      // Never substitute the VIDEO_TS directory or the largest title here.
      await db.update(jobsTable).set({ fileSizeBefore: null }).where(eq(jobsTable.id, jobId));
    } else if (dvdTitle?.sizeBytes) {
      await db.update(jobsTable).set({ fileSizeBefore: dvdTitle.sizeBytes }).where(eq(jobsTable.id, jobId));
    } else {
      const statTarget = mediaInputPath;
      try {
        const stat = await fs.stat(statTarget);
        await db.update(jobsTable).set({ fileSizeBefore: stat.size }).where(eq(jobsTable.id, jobId));
      } catch { /* stat failed — fileSizeBefore stays null */ }
    }

  let hasEmbeddedSubs = false;
  let embeddedGraphicSubtitleDetected = false;
  let primaryAudioCodec: string | null = null;
  let sourceHasAudio = true;
  let whisperProducedEmpty = false;
  let graphicSubtitlePreserved = false;
  let expectedTextSubtitle = false;
  let probeVideoHeight: number | null = null;
  let probeSucceeded = false;
  let probeHasVideo = false;
  try {
    const mediaProbe = await probeJobMedia({
      jobId,
      job,
      mediaInputPath,
      taskSnapshotPresent: Boolean(taskSnapshot),
      selectedTitleDurationSeconds,
    });
    hasEmbeddedSubs = mediaProbe.hasEmbeddedSubs;
    primaryAudioCodec = mediaProbe.primaryAudioCodec;
    sourceHasAudio = mediaProbe.sourceHasAudio;
    probeVideoHeight = mediaProbe.probeVideoHeight;
    probeHasVideo = mediaProbe.probeHasVideo;
    probeSucceeded = true;
  } catch {
      if (selectedTitleDurationSeconds) {
        job.durationSeconds = selectedTitleDurationSeconds;
        await db.update(jobsTable).set({ durationSeconds: selectedTitleDurationSeconds }).where(eq(jobsTable.id, jobId));
      }
      if (job.processingMode !== "remux") {
        await addLog(jobId, "warn", "ffprobe 不可用 — 无法检测内嵌字幕");
      }
    }

    await db.update(jobsTable).set({ hasEmbeddedSubtitles: hasEmbeddedSubs }).where(eq(jobsTable.id, jobId));

// 执行前可执行性检查：模式所需流轨缺失时标记“不可执行 + 原因”，不阻塞整个队列
if (probeSucceeded) {
  const viability = validateJobViability(job, { video: probeHasVideo, audio: sourceHasAudio, subtitle: hasEmbeddedSubs });
  if (!viability.ok) {
    const reason = blockedReasonMessage(viability.code);
    await db.update(jobsTable).set({ status: "error", errorMessage: `VX_BLOCKED:${viability.code}`, completedAt: new Date() }).where(eq(jobsTable.id, jobId));
    await addLog(jobId, "error", `不可执行：${reason}`);
    return;
  }
}
  let subtitlePath: string | null = null;
  let graphicSubtitlePaths: string[] = [];
  let subtitleSourceOutcome: string | null = null;
  let bilingualDirectDone = false;
  let explicitTranslationError: string | null = null;

    const outputDir = outputDirectoryForTask(config, job);
    const subtitleDirJob = resolveJobSubtitleDirectory(config, job);
    await ensureDirectory(outputDir);
    await ensureDirectory(subtitleDirJob);

    const baseName = path.basename(job.filePath, path.extname(job.filePath));
    const outputBaseName = job.mediaType === "dvd"
      ? dvdOutputBaseName({ sourcePath: job.filePath, mediaType: "dvd" })
      : (/^(VIDEO_TS|BDMV)$/i.test(baseName)
        ? path.basename(path.dirname(job.filePath))
        : baseName);
    const frozenCompressionFileName = taskSnapshot
      && (taskSnapshot.outputMode === "compress" || taskSnapshot.outputMode === "both")
      ? taskSnapshot.output.fileName
      : null;
    const legacyCompressionBaseName = outputBaseName;
    const compressionFileName = frozenCompressionFileName ?? buildCompressionOutputName({
      baseName: legacyCompressionBaseName,
      mediaType: job.mediaType,
      outputFormat: config.outputFormat,
      encoder: config.encoder,
      crf: config.crf,
      primaryAudioCodec,
      height: probeVideoHeight,
      bitDepth: encoderBitDepth(config.encoder),
      template: config.outputNameTemplate,
    });
    const compressionBaseName = path.basename(compressionFileName, path.extname(compressionFileName));
    const outputFile = path.join(outputDir, compressionFileName);
    trackJobOutputFile(jobId, outputFile);
    // 流水线命名：字幕文件跟随它所在阶段的基准名（Remux 名 / 压缩版名 / 源名）
    const remuxStageFileName = pipelineHasRemux
      ? (pipelineNames.remux ?? buildRemuxOutputName(outputBaseName, job.mediaType, config.outputFormat, config.outputNameTemplate))
      : null;
    const remuxStageBaseName = remuxStageFileName
      ? path.basename(remuxStageFileName, path.extname(remuxStageFileName))
      : null;
    const subtitleStageBaseName = !pipelineHasSubtitle
      ? outputBaseName
      : pipelineHasRemux && pipelineRemuxIndex < pipelineSubtitleIndex && remuxStageBaseName
        ? remuxStageBaseName
        : pipelineHasCompress && pipelineCompressIndex < pipelineSubtitleIndex
          ? compressionBaseName
          : outputBaseName;
    await addLog(jobId, "info", `压缩输出路径已冻结：${outputFile}`);
    const srtFile = path.join(subtitleDirJob, `${subtitleStageBaseName}.original.srt`);

    // Automatic mode prefers a matching external subtitle before probing the
    // container. Keep the original beside the job output; translation below
    // writes a separate .zhs.srt so the source is never destroyed.
    let sourceSubtitleFile: string | null = null;
    let translatedSubtitlePath: string | null = null;
    let sourceLang: string | null = null;
    let externalSubtitleFound: string | null = null;
    let externalChineseBilingualSource = false;
    if (subtitleMode !== "whisper" && subtitleMode !== "ocr") {
      try {
        // 按文件名配对（媒体同名或同名 + 语言后缀）检测外置字幕；同目录其他视频的
        // 字幕不会误判为本文件已含中文/已翻译。
        const detected = await detectExistingSubtitleFiles(
          path.dirname(mediaInputPath),
          path.basename(mediaInputPath, path.extname(mediaInputPath)),
        );
        // 外置中文字幕文件（无论多少）一律不视为“已翻译”：只有视频容器内自带的
        // 中文字幕轨才允许跳过翻译；双语模式仅在它是唯一可用外置字幕时复用，
        // 否则会把同一份中文字幕同时当作源文和译文，生成两行中文。
        const chosen = selectExternalSubtitleForJob(detected, isBilingual);
        if (chosen) {
          const sourceSubtitlePath = chosen.path;
          externalSubtitleFound = sourceSubtitlePath;
          const originalPath = path.join(subtitleDirJob, subtitleStageBaseName + ".original" + path.extname(sourceSubtitlePath));
          await fs.copyFile(sourceSubtitlePath, originalPath);
          subtitlePath = originalPath;
          sourceSubtitleFile = originalPath;
          subtitleSourceOutcome = "external";
          externalChineseBilingualSource = isBilingual && chosen.language === "zh"
            && !detected.some((item) => item.language === "en" || item.language === "other");
          if (subtitleMode === "extract") {
            subtitlePath = null;
            await addLog(jobId, "info", "内置字幕提取：文件夹已存在外置字幕（内容判定），跳过内置提取");
          } else {
            await addLog(jobId, "info", `发现外置字幕（内容判定：${chosen.language}），保留原文：${sourceSubtitlePath} → ${originalPath}${externalChineseBilingualSource ? "；双语模式仅输出中文行，跳过 Whisper/翻译" : ""}`);
          }
        } else if (detected.some((item) => item.language === "zh")) {
          await addLog(jobId, "info", "目录中存在中文字幕文件，但视频未内置中文字幕轨，不视为已翻译，继续执行字幕处理");
        } else {
          await addLog(jobId, "info", "未在目录中发现已有字幕文件（内容判定）");
        }
      } catch (error) {
        await addLog(jobId, "warn", "外置字幕检测失败，将继续检测内置字幕：" + String(error));
      }
    }

    if (job.processingMode === "compress" && job.mediaType === "dvd"
      && taskSnapshot?.compressionSourceStrategy === "temporary-remux") {
      const ffmpegExecutable = await resolveToolPath("ffmpeg");
      const titleNumber = taskSnapshot.toolSelections.dvdVtsNumber;
      if (!ffmpegExecutable || typeof titleNumber !== "number" || titleNumber <= 0) {
        throw new Error("复杂 DVD 压缩需要已验证的 FFmpeg DVD 标题和可执行文件");
      }
      const streamIndexes = (ids: string[]) => ids
        .map((id) => /^stream:(\d+)$/.exec(id)?.[1])
        .filter((value): value is string => Boolean(value))
        .map(Number);
      const videoStreams = streamIndexes(taskSnapshot.streamSelection.videoTrackIds);
      const audioStreams = streamIndexes(taskSnapshot.streamSelection.audioTrackIds);
      const subtitleStreams = streamIndexes(taskSnapshot.streamSelection.subtitleTrackIds);
      const selectedAudioCodecs = selectedDvdAudioCodecs(taskSnapshot, audioStreams, job.selectionPlan);
      if (videoStreams.length === 0) throw new Error("复杂 DVD 压缩至少需要一个视频流");
      temporaryRemuxPath = path.join(os.tmpdir(), `vx-dvd-compress-${jobId}-${Date.now()}.mkv`);
      trackJobOutputFile(jobId, temporaryRemuxPath, { temp: true });
      await addLog(jobId, "info", `复杂 DVD 结构：先使用 FFmpeg 临时 Remux，再交给 HandBrake 压缩；临时文件=${temporaryRemuxPath}`);
      const dvdSourcePath = resolveRuntimePath(taskSnapshot.sourcePath, config);
      const physicalVtsNumber = selectedAnalysisTitle?.toolMappings.physicalVtsNumber
        ?? taskSnapshot?.toolSelections.physicalVtsNumber
        ?? null;
      const fallbackLookupTitleNumber = typeof physicalVtsNumber === "number" && physicalVtsNumber > 0
        ? physicalVtsNumber
        : titleNumber;
      const fallbackTitle = dvdTitle ?? await resolveDvdTitleForSource(dvdSourcePath, 0, fallbackLookupTitleNumber).catch(() => null);
      if (!fallbackTitle) throw new Error("复杂 DVD 压缩无法解析所选标题，已停止以避免把错误标题交给 HandBrake");
      if (physicalVtsNumber && fallbackTitle.titleNumber === physicalVtsNumber) {
        await addLog(jobId, "info", `复杂 DVD 临时 Remux 使用物理 VTS_${String(physicalVtsNumber).padStart(2, "0")} 作为 VOB 回退组；导航仍使用逻辑 Title ${titleNumber}`);
      }
      const fallbackListFile = await writeDvdConcatListFile(fallbackTitle, `compress-fallback-vob-${jobId}`);
      trackJobOutputFile(jobId, fallbackListFile, { temp: true });
      const fallbackArgs = buildDvdVobFallbackArgs({
        concatInputArgs: dvdConcatInputArgs(fallbackListFile),
        typeMaps: buildDvdTypeMaps(taskSnapshot, selectedAnalysisTitle),
        outputPath: temporaryRemuxPath,
        selectedAudioStreams: audioStreams,
        selectedAudioCodecs,
        chapterMetadataPath: null,
      });
      try {
        const remuxResult = await runDvdRemux({
          executable: ffmpegExecutable,
          sourcePath: dvdVideoInputPath(dvdSourcePath),
          titleNumber,
          selectedVideoStreams: videoStreams,
          selectedAudioStreams: audioStreams,
          selectedAudioCodecs,
          selectedSubtitleStreams: subtitleStreams,
          outputPath: temporaryRemuxPath,
          fallbackArgs,
          onFallback: async (error) => {
            await addLog(jobId, "warn", `复杂 DVD 临时 Remux 导航输出无效，回退 VOB concat：${error instanceof Error ? error.message : String(error)}`);
          },
          validateOutput: async (validatedPath) => {
            const outputProbe = await probeStreams(validatedPath);
            if (!isPlayableRemuxProbe(outputProbe)) throw new Error("临时 DVD Remux 没有有效视频流");
            await validateRemuxOutput(validatedPath, selectedTitleDurationSeconds, async () => ({
              duration: outputProbe.duration,
              streams: outputProbe.streams.map((stream) => ({ codecType: stream.codecType, language: stream.language })),
              chapters: outputProbe.chapters,
            }), {
              expectedStreamCounts: {
                video: videoStreams.length,
                audio: audioStreams.length,
                subtitle: subtitleStreams.length,
              },
            });
          },
        });
        await addLog(jobId, "info", `临时 Remux 完成：${remuxResult.fileSize} 字节；FFmpeg 耗时 ${remuxResult.diagnostic.durationMs} ms`);
      } finally {
        await fs.unlink(fallbackListFile).catch(() => {});
      }
      handbrakeInputPath = temporaryRemuxPath;
    }

    // ── SUBTITLE STEP (auto / extract / whisper / ocr) ───────────────────────
    // Subtitle handling is independent from video processing. Compression jobs
    // must continue into HandBrake after subtitle work; only "none" finishes here.
    // 双语字幕：先尝试“目录内现成中英字幕直连合成”（跳过翻译/OCR）。
    if (isBilingual && !bilingualDirectDone) {
      const direct = await tryDirectBilingualMerge({
        jobId,
        mediaInputPath,
        baseName,
        outputDir: subtitleDirJob,
        style: bilingualStyle,
        addLog: (level, message) => addLog(jobId, level, message),
      });
      if (direct) {
        subtitlePath = direct.chineseSrtPath;
        translatedSubtitlePath = direct.assPath;
        subtitleSourceOutcome = "bilingual";
        bilingualDirectDone = true;
        // Direct bilingual merge completes the subtitle-only workflow without
        // entering the normal extraction/translation branch below. Persist the
        // result here so the job does not fall through to the misleading
        // "no executable steps" warning with empty output fields.
        if (job.processingMode === "none") {
          await db.update(jobsTable).set({
            status: "done",
            progress: 100,
            subtitlePath,
            translatedSubtitlePath,
            subtitleSource: subtitleSourceOutcome,
            outputPath: translatedSubtitlePath,
            completedAt: new Date(),
          }).where(eq(jobsTable.id, jobId));
          await addLog(jobId, "info", `只处理字幕完成 — 已生成双语字幕：${translatedSubtitlePath}`);
          return;
        }
      }
    }
    if (subtitleMode === "ocr") {
      const ocrTitleId = ocrTitleIdForTaskSnapshot(taskSnapshot);
      const ocrFlow = await executeOcrSubtitleFlow({
        jobId,
        mediaInputPath,
        config,
        job,
        subtitleDirJob,
        outputBaseName: subtitleStageBaseName,
        ocrTitleId,
        forceChineseTarget: isBilingual,
        failJobOnError: true,
        addLog: (level, message) => addLog(jobId, level, message),
      });
      if (ocrFlow.cancelled || !ocrFlow.ok) return;
      subtitlePath = ocrFlow.subtitlePath;
      translatedSubtitlePath = ocrFlow.translatedSubtitlePath;
      subtitleSourceOutcome = "ocr";
    } else if (subtitleMode !== "skip" && !bilingualDirectDone) {
      let embeddedChineseSkipped = false;
      if (!subtitlePath && !externalSubtitleFound && (subtitleMode === "extract" || subtitleMode === "transcribe_translate" || (subtitleMode === "auto" && hasEmbeddedSubs))) {
        await db.update(jobsTable).set({ status: "transcribing", progress: 10 }).where(eq(jobsTable.id, jobId));
        await addLog(jobId, "info", "正在用 ffmpeg 提取内嵌字幕");
        if (cancelledJobs.has(jobId)) return;
        try {
          // The packaged app does not put ffmpeg/ffprobe on PATH (they live in a
          // nested tools dir), so always spawn the resolved executable path.
          const ffmpegExecutable = (await resolveToolPath("ffmpeg").catch(() => null)) ?? "ffmpeg";
          const ffprobeExecutable = (await resolveToolPath("ffprobe").catch(() => null)) ?? "ffprobe";
          // Extract ALL subtitle tracks (numbered .srt files)
          // DVD（VIDEO_TS 目录）的字幕轨（VOBSUB）只有通过 dvdvideo 标题输入才能被
          // ffprobe 探测到；裸打开目录会把字幕流漏掉，导致自动模式误判“无字幕轨”
          // 而跳过 OCR 直接进入语音识别。
          const isDvdDirectoryInput = job.mediaType === "dvd" && !/\.(ifo|vob)$/i.test(mediaInputPath);
          const ocrTitleIdForProbe = isDvdDirectoryInput ? ocrTitleIdForTaskSnapshot(taskSnapshot) : null;
          const probeArgs = ["-v", "quiet", "-print_format", "json", "-show_streams",
            ...(ocrTitleIdForProbe ? ["-f", "dvdvideo", "-title", String(ocrTitleIdForProbe)] : []),
            dvdInputArg(isDvdDirectoryInput ? dvdVideoInput : mediaInputPath)];
          const graphicSubtitleInputArgs = isDvdDirectoryInput && ocrTitleIdForProbe
            ? ["-f", "dvdvideo", "-title", String(ocrTitleIdForProbe), "-i", dvdInputArg(dvdVideoInput)]
            : ["-i", ffmpegPath(mediaInputPath)];
          const probeForSubs = await new Promise<string>((res2, rej2) => {
            const p = jobProcessController.spawnForJob(jobId, ffprobeExecutable, probeArgs);
            let out = "";
            p.stdout?.on("data", (d: Buffer) => (out += d));
            p.on("close", (code: number | null) => (code === 0 ? res2(out) : rej2(new Error(`ffprobe exit ${code}`))));
            p.on("error", rej2);
          }).catch(() => "{}");
          let subStreams: Array<{ index: number; streamIndex: number; codec: string; language?: string | null }> = [];
          try {
            const pd = JSON.parse(probeForSubs);
            subStreams = (pd.streams ?? [])
              .filter((s: { codec_type: string }) => s.codec_type === "subtitle")
              .map((s: { index?: unknown; codec_name?: unknown; tags?: { language?: string } }, i: number) => ({
                index: i,
                streamIndex: typeof s.index === "number" ? s.index : i,
                codec: String(s.codec_name ?? ""),
                language: s.tags?.language ?? null,
              }));
          } catch {}
          embeddedGraphicSubtitleDetected = subStreams.some((s) => isGraphicSubtitleCodec(s.codec));
          const textSubs = subStreams.filter((s) => !isGraphicSubtitleCodec(s.codec));
          const hasTextSub = textSubs.length > 0;
          expectedTextSubtitle = hasTextSub;

          // 双语 + 内置文字字幕：提取中文轨与外语轨直接合成双语 ASS，
          // 不再因为“已有中文字幕”而跳过/判定失败。
          if (isBilingual && hasTextSub) {
            let zhIndex: number | null = null;
            for (const sub of textSubs) {
              if (languageTagIsChinese(sub.language)) {
                zhIndex = sub.index;
                break;
              }
              const sample = await sampleEmbeddedSubtitleText(mediaInputPath, sub.index);
              if (textLooksChinese(sample)) {
                zhIndex = sub.index;
                break;
              }
            }
            if (zhIndex !== null) {
              const foreignSub = textSubs.find((s) => s.index !== zhIndex);
              if (foreignSub) {
                const zhSrt = path.join(subtitleDirJob, `${subtitleStageBaseName}.zh-embedded.srt`);
                const enSrt = path.join(subtitleDirJob, `${subtitleStageBaseName}.en-embedded.srt`);
                try {
                  await new Promise<void>((resolve, reject) => {
                    const p = jobProcessController.spawnForJob(jobId, ffmpegExecutable, ["-y", "-i", ffmpegPath(mediaInputPath), "-map", `0:s:${zhIndex}`, ffmpegPath(zhSrt)]);
                    p.on("close", (code) => (code === 0 ? resolve() : reject(new Error(`ffmpeg exit ${code}`))));
                    p.on("error", reject);
                  });
                  await new Promise<void>((resolve, reject) => {
                    const p = jobProcessController.spawnForJob(jobId, ffmpegExecutable, ["-y", "-i", ffmpegPath(mediaInputPath), "-map", `0:s:${foreignSub.index}`, ffmpegPath(enSrt)]);
                    p.on("close", (code) => (code === 0 ? resolve() : reject(new Error(`ffmpeg exit ${code}`))));
                    p.on("error", reject);
                  });
                  const bilingual = await buildBilingualSubtitle({
                    jobId,
                    mediaInputPath,
                    chineseSrtPath: zhSrt,
                    foreignSrtPath: enSrt,
                    baseName: subtitleStageBaseName,
                    style: bilingualStyle,
                    addLog: (level, message) => addLog(jobId, level, message),
                  });
                  if (bilingual) {
                    subtitlePath = enSrt;
                    translatedSubtitlePath = bilingual.assPath;
                    subtitleSourceOutcome = "bilingual";
                    bilingualDirectDone = true;
                    await addLog(jobId, "info", `双语字幕：内置中文轨 + ${foreignSub.language ?? "外语"}轨已提取并合成 ${bilingual.assPath}`);
                  }
                } catch (error) {
                  await addLog(jobId, "warn", `双语内置轨合成失败（${error instanceof Error ? error.message : String(error)}），回退常规流程`);
                }
              } else {
                // 只有中文轨：提取并保留，不判定失败。
                const zhSrt = path.join(subtitleDirJob, `${subtitleStageBaseName}.zh-embedded.srt`);
                try {
                  await new Promise<void>((resolve, reject) => {
                    const p = jobProcessController.spawnForJob(jobId, ffmpegExecutable, ["-y", "-i", ffmpegPath(mediaInputPath), "-map", `0:s:${zhIndex}`, ffmpegPath(zhSrt)]);
                    p.on("close", (code) => (code === 0 ? resolve() : reject(new Error(`ffmpeg exit ${code}`))));
                    p.on("error", reject);
                  });
                  subtitlePath = zhSrt;
                  subtitleSourceOutcome = "embedded-chinese";
                  await addLog(jobId, "info", "双语字幕：仅发现内置中文字幕轨（无外语文字轨），保留中文轨，不判定失败");
                } catch (error) {
                  await addLog(jobId, "warn", `双语内置中文字幕提取失败：${error instanceof Error ? error.message : String(error)}`);
                }
              }
            }
          }

          // Auto mode: if the container already has a Chinese subtitle track,
          // extraction/translation is unnecessary - keep the file untouched.
          if (subtitleMode === "auto" && hasTextSub) {
            let chineseTypeIndex: number | null = null;
            for (const sub of textSubs) {
              if (languageTagIsChinese(sub.language)) {
                chineseTypeIndex = sub.index;
                break;
              }
              const sample = await sampleEmbeddedSubtitleText(mediaInputPath, sub.index);
              if (textLooksChinese(sample)) {
                chineseTypeIndex = sub.index;
                break;
              }
            }
            if (chineseTypeIndex !== null) {
              embeddedChineseSkipped = true;
              subtitleSourceOutcome = "embedded-chinese";
              await addLog(jobId, "info", `检测到视频已内置中文字幕（字幕轨序号 ${chineseTypeIndex}），自动模式无需提取或翻译，跳过字幕处理`);
            }
          }

          if (embeddedChineseSkipped) {
            // No extraction / translation needed.
          } else if (subStreams.length === 0) {
            await addLog(jobId, "warn", "未检测到内置字幕轨道");
          } else if (!hasTextSub) {
            // The original graphic subtitle remains inside the source media
            // even when OCR cannot produce a sidecar file.
            graphicSubtitlePreserved = embeddedGraphicSubtitleDetected;
            // Auto mode prefers OCR for graphic subtitles. A failed OCR attempt
            // must not be reinterpreted as a missing subtitle track and sent to
            // Whisper, because that loses the original cue timing/language.
            let ocrSucceeded = false;
            if (subtitleMode === "auto" || subtitleMode === "transcribe_translate") {
              const ocrTitleId = ocrTitleIdForTaskSnapshot(taskSnapshot);
              const ocrFlow = await executeOcrSubtitleFlow({
                jobId,
                mediaInputPath,
                config,
                job,
                subtitleDirJob,
                outputBaseName: subtitleStageBaseName,
                ocrTitleId,
                // 自动选择已安装的 OCR 引擎（Tesseract / RapidOCR / 大模型视觉），
                // 不要再硬编码 tesseract，否则未安装 Tesseract 时永远失败。
                engine: "auto",
                language: "auto",
                forceChineseTarget: isBilingual,
                failJobOnError: false,
                addLog: (level, message) => addLog(jobId, level, message),
              });
              if (ocrFlow.ok && ocrFlow.subtitlePath) {
                subtitlePath = ocrFlow.subtitlePath;
                translatedSubtitlePath = ocrFlow.translatedSubtitlePath;
                subtitleSourceOutcome = "ocr";
                ocrSucceeded = true;
              } else {
                await addLog(jobId, "warn", `图形字幕 OCR 未成功（${ocrFlow.error ?? "未知原因"}），保留原内置图形字幕，不转语音识别`);
              }
            }
            if (!ocrSucceeded) {
              await addLog(jobId, "warn", `内置字幕为图形格式（${subStreams.map((s) => s.codec).join(", ")}），OCR 未产出文本；保留原格式，不改用语音识别`);
            } else {
              await addLog(jobId, "info", "图形字幕 OCR 已产出文本；仍保留全部原始图形字幕轨");
            }
            let preservedCount = 0;
            for (const graphic of subStreams) {
              const outputBasePath = path.join(subtitleDirJob, `${baseName}.graphic-${graphic.index}`);
              const exportArgs = buildGraphicSubtitleExportArgs({
                sourceInputArgs: graphicSubtitleInputArgs,
                subtitleTypeIndex: graphic.index,
                codec: graphic.codec,
                outputBasePath,
              });
              if (!exportArgs) continue;
              const extension = graphic.codec === "hdmv_pgs_subtitle" || graphic.codec === "pgssub" || graphic.codec === "sup"
                ? ".sup"
                : ".mkv";
              const outputPath = `${outputBasePath}${extension}`;
              trackJobOutputFile(jobId, outputPath);
              try {
                await new Promise<void>((resolve, reject) => {
                  const ffmpeg = jobProcessController.spawnForJob(jobId, ffmpegExecutable, exportArgs);
                  ffmpeg.on("close", (code) => (code === 0 ? resolve() : reject(new Error(`ffmpeg exit ${code}`))));
                  ffmpeg.on("error", reject);
                });
                const stat = await fs.stat(outputPath);
                if (!stat.isFile() || stat.size < 10) throw new Error("FFmpeg 退出成功但未生成有效图形字幕文件");
                preservedCount += 1;
                graphicSubtitlePaths.push(outputPath);
                await addLog(jobId, "info", `图形字幕原轨已保留：${outputPath}`);
              } catch (error) {
                await fs.unlink(outputPath).catch(() => {});
                await addLog(jobId, "warn", `图形字幕原轨导出失败（源文件内置字幕仍保留）：${error instanceof Error ? error.message : String(error)}`);
              }
            }
            if (preservedCount === 0) await addLog(jobId, "warn", "未能生成图形字幕旁车文件；源文件内置字幕仍保留");
          } else {
            // Pick the base subtitle track by line count (cues; packets ≈ one
            // cue per line for text subs): prefer a full subtitle (first above
            // the forced/partial threshold), otherwise the one with the most
            // lines. If English is within 10% of the best line count, prefer
            // English as the base.
            const counted: Array<{ index: number; language: string | null; count: number }> = [];
            let bestCount = 0;
            for (const sub of textSubs) {
              const packets = await probeSubtitlePacketCount(mediaInputPath, sub.index);
              counted.push({ index: sub.index, language: sub.language ?? null, count: packets });
              if (packets > bestCount) bestCount = packets;
            }
            const fullTrack = counted.find((c) => c.count >= fullSubtitlePacketThreshold(job.durationSeconds));
            const fullestTrack = counted.reduce((a, b) => (b.count > a.count ? b : a), counted[0] ?? { index: 0, language: null, count: 0 });
            const candidate = fullTrack ?? fullestTrack;
            const englishTrack = counted.find((c) => (c.language ?? "").toLowerCase().startsWith("en"));
            const chosen = englishTrack && candidate.count > 0 && englishTrack.count >= candidate.count * 0.9
              ? englishTrack
              : candidate;
            // Extract candidates independently. A malformed/unsupported track
            // must not make a valid soft-subtitle track fall through to Whisper.
            const extractionOrder = [
              chosen,
              ...counted.filter((track) => track.index !== chosen.index).sort((a, b) => b.count - a.count),
            ];
            for (let attempt = 0; attempt < extractionOrder.length && !subtitlePath; attempt += 1) {
              const track = extractionOrder[attempt];
              const sourceTrack = textSubs.find((sub) => sub.index === track.index);
              const outputPath = attempt === 0 ? srtFile : `${srtFile}.candidate-${track.index}`;
              const streamMap = sourceTrack?.streamIndex ?? track.index;
              let stderr = "";
              try {
                await new Promise<void>((resolve, reject) => {
                  const ffmpeg = jobProcessController.spawnForJob(jobId, ffmpegExecutable, ["-y", "-i", ffmpegPath(mediaInputPath), "-map", `0:${streamMap}`, ffmpegPath(outputPath)]);
                  ffmpeg.stderr?.on("data", (data: Buffer) => { stderr += data.toString(); });
                  ffmpeg.on("close", (code) => (code === 0 ? resolve() : reject(new Error(`ffmpeg exit ${code}`))));
                  ffmpeg.on("error", reject);
                });
                const extracted = await fs.readFile(outputPath, "utf8").catch(() => "");
                if (!hasValidSubtitleCues(extracted)) throw new Error("输出没有有效字幕 cue");
                if (outputPath !== srtFile) await fs.rename(outputPath, srtFile);
                subtitlePath = srtFile;
                sourceSubtitleFile = srtFile;
                subtitleSourceOutcome = "embedded";
                await addLog(jobId, "info", `字幕已提取至 ${srtFile}（选择字幕轨 ${track.index}，源流 ${streamMap}，共 ${textSubs.length} 条文字字幕轨，包数 ${track.count}）`);
              } catch (error) {
                await fs.unlink(outputPath).catch(() => {});
                await addLog(jobId, "warn", `字幕轨 ${track.index} 提取失败，尝试下一条软字幕：${error instanceof Error ? error.message : String(error)}${stderr.trim() ? `；${stderr.trim().slice(-300)}` : ""}`);
              }
            }
            if (!subtitlePath) throw new Error(`所有 ${textSubs.length} 条文字字幕轨均提取失败`);
          }        } catch (error) {
          await addLog(jobId, "warn", `字幕提取失败 — 跳过字幕：${error instanceof Error ? error.message : String(error)}`);
        }
      }

      const whisperFallback = shouldFallbackToWhisper({
        mode: subtitleMode,
        hasEmbeddedSubs,
        hasGraphicSubs: embeddedGraphicSubtitleDetected,
        hasSubtitleOutput: Boolean(subtitlePath),
        embeddedChineseSkipped,
      });
      if (whisperFallback) {
        if (hasEmbeddedSubs) {
          await addLog(jobId, "info", "自动模式：文字字幕提取失败，回退至 Whisper 语音识别");
        } else {
          await addLog(jobId, "info", "自动模式：未检测到内置字幕，回退至 Whisper 语音识别");
        }
      }
      const whisperRequested = subtitleMode === "whisper" || whisperFallback;
      if (whisperRequested && !sourceHasAudio) {
        await addLog(jobId, "warn", "源文件没有音轨，跳过 Whisper 语音识别");
      }
      if (whisperRequested && sourceHasAudio) {
        await db.update(jobsTable).set({ status: "transcribing", progress: 10 }).where(eq(jobsTable.id, jobId));
        const whisperTask = "transcribe";
        const whisperModel = config.whisperModel === "large" ? "large-v3" : config.whisperModel;
        await addLog(jobId, "info", `正在用 faster-whisper 处理音频（模型：${whisperModel} int8/CPU，语言：${config.subtitleLanguage || "自动"}，任务：${whisperTask}）`);
        if (cancelledJobs.has(jobId)) return;
        try {
          // Prepare the best audio source: discs are extracted to a 16k mono
          // wav (faster-whisper cannot read a DVD folder); for files the best
          // audio track is picked by language/quality scoring instead of the
          // container default (Russian dubs on track 1 are often poor).
          let whisperInput = ffmpegPath(mediaInputPath);
          let tempWavPath: string | null = null;
          const isDiscSource = job.mediaType === "dvd" || job.mediaType === "bluray" || job.mediaType === "iso";
          try {
            const audioStreams = await probeAudioTracks(job.mediaType === "dvd" ? dvdVideoInput : mediaInputPath, isDiscSource);
            const best = pickBestAudioTrack(audioStreams);
            const ffmpeg = (await resolveToolPath("ffmpeg")) ?? "ffmpeg";
            if (best) {
              tempWavPath = path.join(os.tmpdir(), `vx-whisper-${jobId}-${Date.now()}.wav`);
              trackJobOutputFile(jobId, tempWavPath, { temp: true });
              const inputArgs = isDiscSource
                ? ["-v", "error", "-y", "-f", "dvdvideo", "-i", dvdInputArg(job.mediaType === "dvd" ? dvdVideoInput : mediaInputPath), "-map", `0:a:${best.typeIndex}`, "-vn", "-ac", "1", "-ar", "16000", tempWavPath]
                : ["-v", "error", "-y", "-i", ffmpegPath(mediaInputPath), "-map", `0:a:${best.typeIndex}`, "-vn", "-ac", "1", "-ar", "16000", tempWavPath];
              await new Promise<void>((resolve, reject) => {
                const proc = jobProcessController.spawnForJob(jobId, ffmpeg, inputArgs);
                proc.on("close", (code) => (code === 0 ? resolve() : reject(new Error(`音频提取失败 ffmpeg exit ${code}`))));
                proc.on("error", reject);
              });
              whisperInput = tempWavPath;
              await addLog(jobId, "info", `选用音轨 ${best.typeIndex + 1}（${best.language ?? "无标记"} · ${best.codec ?? "?"} · ${best.channels ?? "?"}ch）→ ${tempWavPath}`);
            } else {
              await addLog(jobId, "warn", "未探测到音轨，使用源输入直接转写");
            }
          } catch (error) {
            await addLog(jobId, "warn", `音轨准备失败（回退源输入）：${error instanceof Error ? error.message : String(error)}`);
          }
          const whisperExecutable = await resolveToolPath("whisper");
          if (!whisperExecutable) throw new Error("Whisper 未安装或不可执行。请先在工具管理器安装 Whisper 环境和模型。");
          const whisperScript = await ensureWhisperCliScript();
          const whisperModelDir = await ensureFasterWhisperModel(whisperModel, async (message) => addLog(jobId, "info", message));
          await addLog(jobId, "info", `faster-whisper 执行：${whisperExecutable} ${whisperScript}（模型 ${whisperModelDir}）`);
          let whisperErrOut = "";
          // The detected language is printed early, before the long progress
          // stream, so capture it as it arrives while keeping only a bounded
          // tail of stderr for error reporting.
          let whisperDetectedLang: string | null = null;
          await new Promise<void>((resolve, reject) => {
            const whisper = jobProcessController.spawnForJob(jobId, whisperExecutable, [
              whisperScript,
              whisperInput,
              "--model", whisperModelDir,
              "--device", "cpu",
              "--compute_type", "int8",
              "--output_format", "srt",
              "--output_dir", subtitleDirJob,
              ...(config.subtitleLanguage && config.subtitleLanguage !== "auto" ? ["--language", config.subtitleLanguage] : []),
              "--task", whisperTask,
            ], config.processHighPriority ?? false);
            whisper.stderr?.on("data", async (d: Buffer) => {
              const textChunk = d.toString();
              whisperErrOut = (whisperErrOut + textChunk).slice(-65536);
              if (!whisperDetectedLang) whisperDetectedLang = whisperDetectedLanguage(textChunk);
              const pctMatch = textChunk.match(/(\d+)%\|/);
              if (pctMatch) {
                const pct = parseInt(pctMatch[1], 10);
                await db.update(jobsTable).set({ progress: 10 + pct * 0.8 }).where(eq(jobsTable.id, jobId));
              }
            });
            whisper.on("close", (code) => (code === 0 ? resolve() : reject(new Error(`whisper exit ${code}: ${whisperErrOut.slice(-400)}`))));
            whisper.on("error", reject);
          });
          const detectedLang = whisperDetectedLang ?? whisperDetectedLanguage(whisperErrOut);
          sourceLang = detectedLang;
          const sourceSrtPath = detectedLang
            ? path.join(subtitleDirJob, `${subtitleStageBaseName}.${detectedLang}.srt`)
            : srtFile;
          if (tempWavPath) {
            // The wrapper names the SRT after the wav file; relocate it to the
            // job's standard name.
            const wavBase = path.basename(tempWavPath, ".wav");
            const written = (await fs.readdir(subtitleDirJob).catch((): string[] => []))
              .find((name) => name.startsWith(`${wavBase}.`) && name.endsWith(".srt"));
            if (written && path.resolve(path.join(subtitleDirJob, written)) !== path.resolve(sourceSrtPath)) {
              try { await fs.rename(path.join(subtitleDirJob, written), sourceSrtPath); } catch { /* leave as-is */ }
            }
          } else {
            try { await fs.rename(srtFile, sourceSrtPath); } catch { /* may already be named */ }
          }
          if (tempWavPath) await fs.unlink(tempWavPath).catch(() => {});
          // 语音识别必须真的产出内容；空 SRT 会让后续步骤生成空的中文字幕文件，
          // 这里直接判定失败，避免任务“看似成功”却只有空字幕。
          const transcribedSrt = await fs.readFile(sourceSrtPath, "utf-8").catch(() => "");
          if (parseSrt(transcribedSrt.replace(/\r\n/g, "\n")).length === 0) {
            await fs.unlink(sourceSrtPath).catch(() => {});
            whisperProducedEmpty = true;
            throw new Error(`语音识别未产生有效字幕（${sourceSrtPath} 为空或缺失）`);
          }
          subtitlePath = sourceSrtPath;
          sourceSubtitleFile = sourceSrtPath;
          await addLog(jobId, "info", `转录完成：${sourceSrtPath}${detectedLang ? "（检测语言 " + detectedLang + "）" : ""}`);
        } catch (e) {
          await addLog(jobId, "warn", `Whisper 转录失败：${String(e)}`);
        }
      }

      // 语音识别（whisper）任务：AI 纠错 → 简体中文 .zhs.srt
      if (subtitleMode === "whisper" && subtitlePath) {
        await addLog(jobId, "info", "【AI 纠错】语音识别完成，开始 AI 纠错（修正识别错误 + 简体中文）…");
        const apiKey = resolveApiKey(config) || process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
        if (!apiKey && config.aiProvider !== "libretranslate") {
          await addLog(jobId, "warn", "AI 纠错未配置 API Key — 跳过纠错，保留原始识别字幕");
        } else if (config.aiProvider === "libretranslate") {
          await addLog(jobId, "warn", "本地 LibreTranslate 不支持 AI 纠错 — 跳过纠错，保留原始识别字幕");
        } else {
          try {
            let srtContent = await fs.readFile(subtitlePath, "utf-8");
            srtContent = srtContent.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
            const blocks = parseSrt(srtContent);
            if (blocks.length === 0) {
              await addLog(jobId, "warn", "语音识别字幕为空，跳过纠错");
            } else {
              const isChineseSource = /^(zh|zh-cn|zh-tw|yue)/i.test(sourceLang ?? "");
              await addLog(jobId, "info", `共 ${blocks.length} 条字幕，AI 纠错 → 简体中文（源语种 ${sourceLang ?? "未知"}）`);
              const correctedPath = path.join(subtitleDirJob, `${subtitleStageBaseName}.zhs.srt`);
              const correctedBlocks: SrtBlock[] = [];
              const BATCH = 40;
              const { baseUrl, model } = resolveAiEndpoint(config);
              const systemPrompt = buildWhisperCorrectionPrompt(job, isChineseSource, sourceLang);
              for (let i = 0; i < blocks.length; i += BATCH) {
                const batch = blocks.slice(i, i + BATCH);
                const pct = Math.round((i / blocks.length) * 100);
                await addLog(jobId, "info", `纠错进度 ${pct}%（${i + 1}–${Math.min(i + BATCH, blocks.length)} / ${blocks.length}）`);
                const corrected = await translateBatch(batch.map((b) => b.text), systemPrompt, apiKey!, baseUrl, model, await getAiProxyUrl());
                for (let j = 0; j < batch.length; j++) correctedBlocks.push({ ...batch[j], text: corrected[j] || batch[j].text });
              }
              await fs.writeFile(correctedPath, renderSrtSimplified(correctedBlocks, true), "utf-8");
              translatedSubtitlePath = correctedPath;
              await addLog(jobId, "info", `AI 纠错完成 → ${correctedPath}`);
            }
          } catch (e) {
            await addLog(jobId, "warn", `AI 纠错失败：${String(e)}`);
          }
        }
      }

      // "识别+AI翻译" mode: run AI translation immediately after Whisper
      if ((subtitleMode === "transcribe_translate" || (subtitleMode === "auto" && subtitlePath)) && subtitlePath && !externalChineseBilingualSource) {
        await addLog(jobId, "info", "【AI 翻译】识别完成，开始 AI 字幕翻译…");
        const apiKey = resolveApiKey(config) || process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
        if (!apiKey && config.aiProvider !== "libretranslate") {
          explicitTranslationError = "未配置当前 AI 提供商的 API Key";
          await addLog(jobId, "error", "AI 翻译未配置 API Key — 请在设置中填写 API Key");
        } else {
          try {
            let srtContent = await fs.readFile(subtitlePath, "utf-8");
            srtContent = srtContent.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
            const blocks = parseSrt(srtContent);
            if (blocks.length === 0) {
              explicitTranslationError = "字幕文件无法解析（格式异常或内容为空）";
              await addLog(jobId, "error", explicitTranslationError);
            } else {
              const effectiveTargetLang = isBilingual ? "zh-CN" : config.translationTargetLang;
              await addLog(jobId, "info", `共 ${blocks.length} 条字幕，目标语言：${effectiveTargetLang}${isBilingual ? "（双语任务固定简体中文）" : ""}；翻译引擎：${config.aiProvider === "libretranslate" ? "LibreTranslate（本地）" : (config.aiProvider || "OpenAI 兼容 LLM")}`);
                            const translatedPath = path.join(subtitleDirJob, `${subtitleStageBaseName}.zhs.srt`);
              const translatedBlocks: SrtBlock[] = [];
              const BATCH = 40;

              // "转录+翻译" 使用用户选择的 AI 提供商；只有明确选择
              // LibreTranslate 时才走本地翻译服务。此前把模式本身当成
              // LibreTranslate 开关，导致 DeepSeek 配置实际请求不存在的
              // http://libretranslate:5000。
              if (config.aiProvider === "libretranslate") {
                const ltUrl = config.libreTranslateUrl || "http://libretranslate:5000";
                const tgtLang = effectiveTargetLang.split("-")[0];
                for (let i = 0; i < blocks.length; i += BATCH) {
                  const batch = blocks.slice(i, i + BATCH);
                  const pct = Math.round((i / blocks.length) * 100);
                  await addLog(jobId, "info", `本地翻译进度 ${pct}%（${i + 1}–${Math.min(i + BATCH, blocks.length)} / ${blocks.length}）`);
                  await db.update(jobsTable).set({ progress: mapExternalToolProgress({ toolPercent: pct, start: 50, end: 95 }) }).where(eq(jobsTable.id, jobId));
                  const translated = await translateBatchLibre(batch.map(b => b.text), "en", tgtLang, ltUrl);
                  for (let j = 0; j < batch.length; j++) {
                    translatedBlocks.push({ ...batch[j], text: translated[j] || batch[j].text });
                  }
                }
              } else {
                const { baseUrl, model } = resolveAiEndpoint(config);
                const systemPrompt = await buildTranslationPrompt(job, config, effectiveTargetLang, sourceLang);
                for (let i = 0; i < blocks.length; i += BATCH) {
                  const batch = blocks.slice(i, i + BATCH);
                  const pct = Math.round((i / blocks.length) * 100);
                  await addLog(jobId, "info", `翻译进度 ${pct}%（${i + 1}–${Math.min(i + BATCH, blocks.length)} / ${blocks.length}）`);
                  const translated = await translateBatch(batch.map(b => b.text), systemPrompt, apiKey!, baseUrl, model, await getAiProxyUrl());
                  for (let j = 0; j < batch.length; j++) {
                    translatedBlocks.push({ ...batch[j], text: translated[j] || batch[j].text });
                  }
                }
              }

              await fs.writeFile(translatedPath, renderSrtSimplified(translatedBlocks, effectiveTargetLang.startsWith("zh-CN")), "utf-8");
              translatedSubtitlePath = translatedPath;
              await addLog(jobId, "info", `AI 翻译完成 → ${translatedPath}`);
            }
          } catch (e) {
            explicitTranslationError = e instanceof Error ? e.message : String(e);
            await addLog(jobId, "error", `AI 翻译失败：${explicitTranslationError}`);
          }
        }
      }

      // 双语字幕组装必须在公共路径执行：无论任务后续是否还有视频处理
      // （纯字幕 / Remux / 压缩流水线），都要产出合并后的 ASS 文件。
      // 此前该步骤只在 processingMode === "none" 里运行，导致
      // “双语字幕 + Remux”的任务只留下 OCR 英文和中文翻译两个 SRT，
      // 没有生成双语 ASS。
      if (isBilingual && !bilingualDirectDone && subtitleSourceOutcome !== "embedded-chinese" && translatedSubtitlePath) {
        const bilingual = await buildBilingualSubtitle({
          jobId,
          mediaInputPath,
          chineseSrtPath: translatedSubtitlePath,
          // 有翻译（中文）产出时，subtitlePath 通常是原文（如 OCR 英文 SRT），
          // 作为双语的外文侧备用来源。
          foreignSrtPath: subtitlePath,
          // 用管道输出基名（与 remux/compress 产出同名），保证 .ass 与视频输出文件同名。
          baseName: subtitleStageBaseName,
          style: bilingualStyle,
          addLog: (level, message) => addLog(jobId, level, message),
        });
        if (bilingual) {
          translatedSubtitlePath = bilingual.assPath;
          subtitleSourceOutcome = "bilingual";
        }
      }

      if (job.processingMode === "none") {
        const translationFailure = explicitTranslationFailureMessage({
          mode: subtitleMode,
          translatedOutput: Boolean(translatedSubtitlePath),
          error: explicitTranslationError,
        });
        if (translationFailure) {
          const message = `字幕翻译失败：${translationFailure}`;
          await db.update(jobsTable).set({
            status: "error",
            progress: 100,
            subtitlePath: sourceSubtitleFile ?? subtitlePath,
            translatedSubtitlePath: null,
            subtitleSource: subtitleSourceOutcome,
            errorMessage: message,
            completedAt: new Date(),
          }).where(eq(jobsTable.id, jobId));
          await addLog(jobId, "error", message);
          return;
        }
        const hasSubtitleOutput = Boolean(sourceSubtitleFile ?? subtitlePath ?? translatedSubtitlePath);
        const outputDisposition = subtitleOnlyOutputDisposition({
          hasSubtitleOutput,
          sourceHasAudio,
          whisperProducedEmpty,
          graphicSubtitlePreserved,
          expectedTextSubtitle,
          requestedMode: job.subtitleMode,
        });
        // Genuine extraction failures remain errors; no-speech and preserved
        // embedded graphics are valid completed outcomes.
        if (outputDisposition === "error" && job.subtitleMode !== "skip") {
          await db.update(jobsTable).set({
            status: "error",
            progress: 100,
            subtitlePath: sourceSubtitleFile ?? subtitlePath,
            translatedSubtitlePath,
            subtitleSource: subtitleSourceOutcome,
            errorMessage: "字幕处理失败：未生成任何字幕输出（OCR / 语音识别均未成功）",
            completedAt: new Date(),
          }).where(eq(jobsTable.id, jobId));
          await addLog(jobId, "error", "字幕处理失败：未生成任何字幕输出（OCR / 语音识别均未成功）");
          return;
        }
        await db.update(jobsTable).set({
          status: "done", progress: 100, subtitlePath: sourceSubtitleFile ?? subtitlePath, translatedSubtitlePath, subtitleSource: subtitleSourceOutcome, completedAt: new Date(),
          // 双语字幕把 ASS 输出写入 outputPath，任务队列“打开输出文件夹”可直接定位。
          ...(isBilingual && translatedSubtitlePath ? { outputPath: translatedSubtitlePath } : {}),
        }).where(eq(jobsTable.id, jobId));
        const savedSubtitlePaths = [subtitlePath, translatedSubtitlePath].filter((value): value is string => Boolean(value));
        await addLog(jobId, "info", savedSubtitlePaths.length > 0
          ? `只处理字幕完成 — 已保存至 ${savedSubtitlePaths.join("；")}`
          : "只处理字幕完成（无字幕输出）");
        await settlePreviewTaskSafely(jobId, {
          taskKind: "subtitle",
          outputValid: hasSubtitleOutput,
          isPreviewOnly: false,
          cancelled: false,
        });
        return;
      }
      await addLog(jobId, "info", `字幕步骤完成${subtitlePath ? " — 继续视频处理并使用 " + subtitlePath : " — 继续视频处理"}`);
    }
    // ── END SUBTITLE-ONLY MODES ───────────────────────────────────────────────

    if (cancelledJobs.has(jobId)) return;
    if (job.processingMode === "none") {
      const message = "未选择可执行的处理方式：请先选择 Remux、压缩或字幕处理；本次任务未生成输出文件";
      await db.update(jobsTable).set({
        status: "error",
        progress: 100,
        errorMessage: message,
        completedAt: new Date(),
      }).where(eq(jobsTable.id, jobId));
      await addLog(jobId, "error", message);
      return;
    }
    await db.update(jobsTable).set({ status: "compressing", progress: 0, subtitlePath: sourceSubtitleFile ?? subtitlePath, translatedSubtitlePath }).where(eq(jobsTable.id, jobId));

    // ─── REMUX branch (lossless stream copy — for disc/ISO sources) ────────────
    let pipelineRemuxOutputPath: string | null = null;
    if (job.processingMode === "remux" || pipelineHasRemux) {
      const remuxFfmpeg = (await resolveToolPath("ffmpeg").catch(() => null)) ?? "ffmpeg";
      let sourcePath = mediaInputPath;
      const isIfoInput = /\.ifo$/i.test(sourcePath);
      const isMplsInput = /\.mpls$/i.test(sourcePath);
      const discLabel = job.mediaType === "bluray" ? "蓝光" : job.mediaType === "dvd" ? "DVD" : "ISO";
      await addLog(jobId, "info", `无损封装模式 — ${discLabel} 源文件: ${path.basename(sourcePath)}${isIfoInput ? " (DVD IFO 完整标题)" : ""}`);
      let isoRemuxDrive: string | null = null;
      if (job.mediaType === "iso") {
        const mounted = await mountBlurayIso(sourcePath);
        if (!mounted) throw new Error("无法挂载 ISO 镜像，请检查文件是否被占用或系统挂载支持");
        isoRemuxDrive = mounted;
        const mountedVideoTs = await resolveDvdVideoTsDir(mounted);
        if (mountedVideoTs) {
          // DVD-content ISO: route into the DVD dvdvideo navigation path below
          // (libdvdread needs the mounted drive, not the raw ISO file).
          await addLog(jobId, "info", `ISO 内容为 DVD，已挂载到 ${mounted}，按 DVD 标题导航封装`);
          job.mediaType = "dvd";
          sourcePath = mountedVideoTs;
        }
      }

      // Fix output name for disc folders: if filePath is a VIDEO_TS/BDMV subfolder,
      // use the parent directory name so output is "MovieName.mkv" not "VIDEO_TS.mkv".
      const taskSnapshot = loadTaskSnapshot(job);
      const remuxBaseName = job.mediaType === "dvd"
        ? dvdOutputBaseName({ sourcePath: job.filePath, mediaType: "dvd" })
        : (/^(VIDEO_TS|BDMV)$/i.test(baseName)
          ? path.basename(path.dirname(job.filePath))
          : baseName);
      const titleIndex = snapshotTitleIndex(taskSnapshot);
      const remuxTitleSuffix = job.mediaType === "dvd" ? "" : (titleIndex >= 0 ? `.Title${String(titleIndex + 1).padStart(2, "0")}` : "");
      const remuxFileName = taskSnapshot?.outputMode === "remux"
        ? taskSnapshot.output.fileName
        : (pipelineNames.remux ?? buildRemuxOutputName(`${remuxBaseName}${remuxTitleSuffix}`, job.mediaType, config.outputFormat, config.outputNameTemplate));
      const remuxOutputFile = path.join(outputDir, remuxFileName);
      trackJobOutputFile(jobId, remuxOutputFile);
      // Stream indexes the user selected (from the immutable snapshot); null
      // means "no explicit selection", in which case all tracks are kept.
      const remuxSelectedStreams = (() => {
        if (!taskSnapshot) return null;
        const ids = [
          ...taskSnapshot.streamSelection.videoTrackIds,
          ...taskSnapshot.streamSelection.audioTrackIds,
          ...taskSnapshot.streamSelection.subtitleTrackIds,
        ];
        const indexes = ids
          .map((id) => Number(String(id).replace(/^stream:/, "")))
          .filter((index) => Number.isInteger(index) && index >= 0);
        return indexes.length > 0 ? indexes : null;
      })();

      const isDiscRemux = job.mediaType === "bluray" || job.mediaType === "iso" || isMplsInput;
      if (isDiscRemux) {
        const discSourcePath = job.filePath;
        // Blu-ray titles from the m2ts fallback (playlist-less discs) are remuxed
        // directly from their BDMV/STREAM file without playlist concat.
        const m2tsRemux = await tryRemuxBluRayM2ts({
          jobId,
          discSourcePath,
          selectedTitleId: taskSnapshot?.selectedTitleId,
          remuxSelectedStreams,
          remuxOutputFile,
          expectedDurationSeconds: job.durationSeconds,
          pipelineContinuesAfterRemux,
          subtitlePath,
          translatedSubtitlePath,
          graphicSubtitlePaths,
          log: (level, message) => addLog(jobId, level, message),
        });
        pipelineRemuxOutputPath = m2tsRemux.pipelineRemuxOutputPath;
        if (m2tsRemux.handled && !pipelineContinuesAfterRemux) return;
        await addLog(jobId, "info", `FFmpeg 播放列表 Remux：源 ${discSourcePath}`);
        const blurayPlaylistInput = await resolveBlurayPlaylistInput({
          mediaType: job.mediaType,
          sourcePath,
          discSourcePath,
          taskSnapshot,
          expectedTitleSeconds: job.durationSeconds && job.durationSeconds > 0 ? job.durationSeconds : null,
          log: (level, message) => addLog(jobId, level, message),
        });
        const { discRoot, mplsPath } = blurayPlaylistInput;
        const parsedSegments = await parseBlurayMpls(mplsPath, discRoot);
        if (parsedSegments.length === 0) throw new Error("播放列表未解析到有效片段");
        const segmentContext = await probeAndTrimBluraySegments({
          segments: parsedSegments,
          probeDuration: async (streamPath) => {
            const probe = await probeStreams(streamPath);
            return probe.duration ?? null;
          },
          log: (message) => addLog(jobId, "info", message),
        });
        const { segments, playlistDuration, keptDurationSeconds } = segmentContext;

        // Resolve chapters BEFORE the single ffmpeg pass so the chapter
        // metadata is written by the same invocation that creates the output
        // file — no intermediate "no-chapter" file, no double output.
        let chapters: Array<{ id: number; startSeconds: number; endSeconds: number; title: string | null }> = readPersistedBlurayChapters(job.selectionPlan);
        if (chapters.length === 0) {
          try {
            const chapterSnapshot = loadTaskSnapshot(job);
            const chapterAnalysis = chapterSnapshot?.analysisId
              ? discAnalysisRegistry.find(chapterSnapshot.analysisId)
              : undefined;
            const chapterTitle = chapterAnalysis?.titles.find((candidate) => candidate.titleId === chapterSnapshot?.selectedTitleId);
            if (chapterTitle?.chapters && chapterTitle.chapters.length > 0) {
              chapters = chapterTitle.chapters.map((chapter) => ({
                id: chapter.id,
                startSeconds: chapter.startSeconds,
                endSeconds: chapter.endSeconds,
                title: chapter.title ?? null,
              }));
            }
          } catch {
            chapters = [];
          }
        }
        if (chapters.length === 0) {
          // Legacy jobs created before chapter persistence have no saved
          // chapter times. Recover them with a quick HandBrake scan so a
          // re-run still gets the real layout instead of broken marks.
          try {
            const hbExecutable = await resolveToolPath("handbrake");
            if (hbExecutable) {
              const hbScan = await scanHandBrakeTitles(discRoot, hbExecutable);
              let chapterSnapshotForScan: { selectedTitleId?: string } | null = null;
              try { chapterSnapshotForScan = loadTaskSnapshot(job); } catch { chapterSnapshotForScan = null; }
              const match = chooseBlurayHandBrakeChapterTitle(hbScan, chapterSnapshotForScan?.selectedTitleId ?? null, job.durationSeconds);
              if (match && match.chapters.length > 0) {
                chapters = match.chapters.map((chapter) => ({
                  id: chapter.id,
                  startSeconds: chapter.startSeconds,
                  endSeconds: chapter.endSeconds,
                  title: chapter.title ?? null,
                }));
              }
            }
          } catch {
            chapters = [];
          }
        }
        if (chapters.length === 0) chapters = await parseBlurayChapters(mplsPath, discRoot);
        const effectiveDuration = keptDurationSeconds > 0 ? keptDurationSeconds : (playlistDuration ?? job.durationSeconds ?? Number.MAX_SAFE_INTEGER);
        const validChapters = clampBlurayChapters(chapters, effectiveDuration);
        let metaPath: string | null = null;
        if (validChapters.length > 1) {
          metaPath = path.join(os.tmpdir(), `vx-bd-${Date.now()}-${Math.random().toString(36).slice(2)}.ffmeta`);
          trackJobOutputFile(jobId, metaPath, { temp: true });
          const metaLines = [";FFMETADATA1", "TIMEBASE=1/90000"];
          for (const chapter of validChapters) {
            metaLines.push(`[CHAPTER]`);
            metaLines.push(`TIMEBASE=1/90000`);
            metaLines.push(`START=${Math.round(chapter.startSeconds * 90000)}`);
            metaLines.push(`END=${Math.round(chapter.endSeconds * 90000)}`);
            metaLines.push("title=Chapter " + (chapter.id + 1));
          }
          await fs.writeFile(metaPath, metaLines.join("\r\n"), "utf8");
        } else if (chapters.length > 1) {
          await addLog(jobId, "warn", `章节时间信息不完整（${chapters.length} 个章节标记无效），已跳过章节封装；无损封装结果不受影响`);
        }

        await db.update(jobsTable).set({ progress: 10 }).where(eq(jobsTable.id, jobId));
        const remuxBuild = await buildLosslessRemuxArgs(segments[0].streamPath, undefined, remuxSelectedStreams);
        if (remuxBuild.transcodedPcmBluray) {
          await addLog(jobId, "info", "检测到蓝光 LPCM（pcm_bluray）音轨，已无损转换为 MKV 兼容的 PCM（pcm_s24le）");
        }
        const concatList = path.join(os.tmpdir(), `vx-bd-${Date.now()}-${Math.random().toString(36).slice(2)}.ffconcat`);
        trackJobOutputFile(jobId, concatList, { temp: true });
        await fs.writeFile(concatList, buildFfconcatFileContent(segments.map((segment) => segment.streamPath)), "utf8");
        const legacyBdArgs = [
          "-f", "concat", "-safe", "0", "-i", ffmpegPath(concatList),
          ...(metaPath ? ["-i", metaPath, "-map_chapters", "1"] : []),
          ...remuxBuild.args, "-fflags", "+genpts", "-y", remuxOutputFile,
        ];
        // The unified planner must reproduce the legacy command byte for byte;
        // otherwise fall back to it so the output cannot silently change.
        let plannedBdArgs: string[] | null = null;
        try {
          const bdAnalysisTitle = discAnalysisRegistry
            .find(taskSnapshot?.analysisId ?? "")
            ?.titles.find((candidate) => candidate.titleId === taskSnapshot?.selectedTitleId) ?? null;
          const bdManifest = buildMediaPipelineManifestFromSnapshot({
            snapshot: taskSnapshot as NonNullable<typeof taskSnapshot>,
            title: bdAnalysisTitle,
            selectionPlan: job.selectionPlan,
            sourcePath: segments[0].streamPath,
          });
          plannedBdArgs = buildRemuxCommandPlan({
            manifest: bdManifest,
            executable: remuxFfmpeg,
            inputMode: "concat",
            concatListPath: concatList,
            chapterMetadataPath: metaPath ?? undefined,
          }).args as string[];
        } catch (error) {
          await addLog(jobId, "warn", `蓝光 Remux planner 构建失败，回退旧命令：${error instanceof Error ? error.message : String(error)}`);
        }
        const bdPlannerMatches = plannedBdArgs !== null && JSON.stringify(plannedBdArgs) === JSON.stringify(legacyBdArgs);
        if (!bdPlannerMatches) {
          await addLog(jobId, "warn", "蓝光 Remux planner 与旧命令不一致，已回退旧命令（请检查）");
        }
        try {
          await runFfmpegCapture(jobId, bdPlannerMatches ? (plannedBdArgs as string[]) : legacyBdArgs, keptDurationSeconds > 0 ? keptDurationSeconds : (playlistDuration ?? job.durationSeconds));
        } finally {
          await fs.unlink(concatList).catch(() => {});
          if (metaPath) await fs.unlink(metaPath).catch(() => {});
        }
        await db.update(jobsTable).set({ progress: 60 }).where(eq(jobsTable.id, jobId));
        if (cancelledJobs.has(jobId)) {
          await fs.rm(remuxOutputFile, { force: true }).catch(() => {});
          throw new Error("任务已取消");
        }

        let fileSizeAfter: number;
        let outputDuration: number | null;
        try {
          const validation = await validateRemuxOutput(remuxOutputFile, effectiveDuration, probeStreams, {
            expectedSizeBytes: null,
            minimumSizeRatio: 0.6,
          });
          fileSizeAfter = validation.fileSize;
          outputDuration = validation.duration;
          if (validation.drift !== null && validation.drift > 0.05) {
            await addLog(jobId, "warn", `Remux 输出时长与播放列表差异 ${(validation.drift * 100).toFixed(1)}%`);
          }
        } catch (probeError) {
          await addLog(jobId, "error", `FFmpeg Remux 输出校验失败：${String(probeError)}`);
          throw probeError;
        }
        const endPlayable = await verifyOutputEndPlayable(jobId, remuxOutputFile, outputDuration ?? effectiveDuration);
        if (!endPlayable.ok) {
          throw new Error(`输出后段解码失败，文件可能损坏：${endPlayable.error}`);
        }
        pipelineRemuxOutputPath = (await finalizeRemuxStage({
          jobId,
          remuxOutputFile,
          fileSizeAfter,
          outputDuration,
          pipelineContinuesAfterRemux,
          subtitlePath,
          translatedSubtitlePath,
          log: (level, message) => addLog(jobId, level, message),
        })).pipelineRemuxOutputPath;
        if (!pipelineContinuesAfterRemux) return;
      }

      // DVD IFO is not a plain video file. Prefer ffmpeg's dvdvideo demuxer so
      // title navigation, IFO timing, and chapter/cell boundaries are read from
      // the disc structure. Raw VOB concat is only a sparse-extract fallback.
      let inputPath = sourcePath;
      let concatListFile: string | null = null;
      let chapterMetadataFile: string | null = null;
      let dvdNavigationTitle: DvdTitle | null = null;
      let remuxExpectedSizeBytes: number | null = dvdTitle?.sizeBytes ?? null;
      const dvdRemuxInput = await prepareDvdRemuxInput({
        jobId,
        sourcePath,
        isIfoInput,
        isMplsInput,
        mediaType: job.mediaType,
        taskSnapshot,
        dvdTitle,
        selectedTitleSizeBytes,
        selectedAnalysisEstimatedSize: selectedAnalysisTitle?.estimatedSize ?? null,
        resolveDvdTitleForSource,
        resolveDvdTitleForIfo,
        writeDvdConcatListFile,
        trackTempFile: (filePath) => trackJobOutputFile(jobId, filePath, { temp: true }),
        log: (level, message) => addLog(jobId, level, message),
      });
      concatListFile = dvdRemuxInput.concatListFile;
      dvdNavigationTitle = dvdRemuxInput.dvdNavigationTitle;
      remuxExpectedSizeBytes = dvdRemuxInput.remuxExpectedSizeBytes;
      if (isMplsInput) {
        const mplsRemuxInput = await prepareMplsRemuxInput({
          jobId,
          sourcePath,
          discRoot: path.dirname(path.dirname(path.dirname(sourcePath))),
          trackTempFile: (filePath) => trackJobOutputFile(jobId, filePath, { temp: true }),
          log: (level, message) => addLog(jobId, level, message),
        });
        remuxExpectedSizeBytes = mplsRemuxInput.remuxExpectedSizeBytes;
        concatListFile = mplsRemuxInput.concatListFile;
      }

      // Rebuild the chapter metadata from the user's selected chapter IDs.
      // This keeps stream-copy lossless while preventing unselected chapter
      // markers from leaking into the output container.
      if (job.selectedChapters) {
        try {
          const selected = parseSelectedChapterIds(job.selectedChapters);
          if (Array.isArray(selected) && selected.length > 0) remuxExpectedSizeBytes = null;
          let probed: { chapters?: Array<{ id: number; startSeconds: number; endSeconds: number; title?: string | null }> } | null = null;
          try {
            probed = await probeMediaStreams(sourcePath, job.mediaType);
          } catch {
            probed = null;
          }
          let chapters = selectChaptersById(probed?.chapters ?? [], selected);
          if (chapters.length === 0) {
            // The source probe failed (e.g. CSS-protected DVD directory or a
            // disc root). Recover the selected title's chapters from the
            // persisted selection plan or the analysis so the remux still
            // gets a proper chapter layout.
            chapters = readPersistedSelectedChapters(job.selectionPlan, selected);
          }
          if (chapters.length === 0) {
            try {
              const snap = loadTaskSnapshot(job);
              const title = snap?.analysisId
                ? discAnalysisRegistry.find(snap.analysisId)?.titles.find((candidate) => candidate.titleId === snap?.selectedTitleId)
                : undefined;
              if (title?.chapters?.length) {
                chapters = selectChaptersById(title.chapters, selected)
                  .map((chapter) => ({ id: chapter.id, startSeconds: chapter.startSeconds, endSeconds: chapter.endSeconds, title: chapter.title ?? null }));
              }
            } catch {
              chapters = [];
            }
          }
          if (chapters.length > 0) {
            chapterMetadataFile = path.join(os.tmpdir(), `vx-chapters-${jobId}-${Date.now()}.ffmeta`);
            trackJobOutputFile(jobId, chapterMetadataFile, { temp: true });
            const metadata = buildSelectedChapterMetadata(chapters, selected);
            if (!metadata) throw new Error("未找到选定章节");
            await fs.writeFile(chapterMetadataFile, metadata, "utf8");
            await addLog(jobId, "info", `已生成 ${chapters.length} 个选定章节的元数据`);
            if (isMplsInput && concatListFile) {
              const playlistSegments = await parseBlurayMpls(sourcePath, path.dirname(path.dirname(path.dirname(sourcePath))));
              const selectedSegments = mapBlurayChaptersToSegments(playlistSegments, chapters).filter((segment) => fsSync.existsSync(segment.file));
              if (selectedSegments.length > 0) {
                await fs.writeFile(concatListFile, buildFfconcatTimedContent(selectedSegments), "utf8");
                await addLog(jobId, "info", `蓝光章节已映射到 ${selectedSegments.length} 个 m2ts 时间片段`);
              }
            }
            if (job.mediaType !== "dvd" && !isIfoInput && !isMplsInput && !concatListFile) {
              concatListFile = path.join(os.tmpdir(), `vx-chapter-${jobId}-${Date.now()}.ffconcat`);
              trackJobOutputFile(jobId, concatListFile, { temp: true });
              await fs.writeFile(concatListFile, buildFfconcatChapterContent(sourcePath, chapters), "utf8");
              await addLog(jobId, "info", `普通视频将只封装 ${chapters.length} 个选定章节片段`);
            }
          }
        } catch { await addLog(jobId, "warn", "章节选择解析失败，将保留原始章节元数据"); }
      }

      let selectedChapterCount = 0;
      if (job.selectedChapters) {
        try {
          selectedChapterCount = parseSelectedChapterIds(job.selectedChapters).length;
        } catch { selectedChapterCount = 0; }
      }

      const appendRemuxSelectionArgs = async (ffmpegArgs: string[], usesConcatInput: boolean, vobProtocol = false) => {
        if (chapterMetadataFile) ffmpegArgs.push("-i", chapterMetadataFile);

        if (vobProtocol) {
          // concat-protocol input exposes dvd_nav data at stream 0, video at 1
          // and audio after it, so map by type/order instead of raw indexes.
          if (job.selectedStreams) {
            try {
              ffmpegArgs.push("-map", "0:v");
              // Map the audio tracks actually selected in the task snapshot
              // (the raw stream list also contains video/subtitle indexes).
              const audioIndexes = (taskSnapshot?.streamSelection.audioTrackIds ?? [])
                .map((id) => {
                  const match = /^stream:(\d+)$/.exec(id);
                  return match ? Number(match[1]) : null;
                })
                .filter((index): index is number => index !== null && index > 0)
                .sort((a, b) => a - b);
              for (const index of audioIndexes) ffmpegArgs.push("-map", `0:a:${index - 1}`);
              await addLog(jobId, "info", "DVD VOB 拼接：按类型映射视频与所选音轨");
            } catch {
              ffmpegArgs.push("-map", "0:v", "-map", "0:a");
            }
          } else {
            ffmpegArgs.push("-map", "0:v", "-map", "0:a");
          }
        } else if (isIfoInput) {
          // DVD vobsub (dvd_subtitle) subtitles are bitmap-based and cannot be
          // reliably stream-copied into MKV without special handling — skip them.
          if (job.selectedStreams) {
            ffmpegArgs.push(...buildRemuxMapArgs(job.selectedStreams));
            await addLog(jobId, "info", "DVD 模式：按已选择的流轨封装");
          } else {
            ffmpegArgs.push("-map", "0:v?", "-map", "0:a?");
            await addLog(jobId, "info", "DVD 模式：封装视频和音频流（跳过字幕）");
          }
        } else if (dvdNavigationTitle && job.mediaType === "dvd") {
          // dvdvideo input: use type-based maps so re-probed duplicate stream
          // lists on some discs cannot corrupt the MKV container.
          const analysisTitle = taskSnapshot?.analysisId
            ? discAnalysisRegistry.find(taskSnapshot.analysisId)?.titles.find(
                (candidate) => candidate.titleId === taskSnapshot?.selectedTitleId,
              )
            : undefined;
          const typedMaps = buildDvdTypeMaps(taskSnapshot, analysisTitle);
          if (typedMaps) {
            ffmpegArgs.push(...typedMaps);
            await addLog(jobId, "info", "DVD 模式：按类型映射所选流轨（避免 dvdvideo 流轨重复导致 MKV 损坏）");
          } else {
            ffmpegArgs.push(...buildRemuxMapArgs(job.selectedStreams ?? null));
          }
        } else {
          const mapArgs = buildRemuxMapArgs(job.selectedStreams ?? null);
          ffmpegArgs.push(...mapArgs);
        }

        // Regenerate the container timeline from zero while stream-copying payloads.
        // Preserving raw input timestamps (-copyts) caused broken durations after
        // DVD/BD concat and selected-chapter remuxes on Windows.
        ffmpegArgs.push(...buildRemuxCopyArgs({ usesConcatInput, selectedChapters: job.selectedChapters }));
        // Matroska has no pcm_dvd codec tag; convert LPCM DVD audio losslessly
        // to little-endian PCM (same samples, MKV-safe) — like the verified
        // DVD remux path already does. Without this the mux header fails with
        // "No wav codec tag found for codec pcm_dvd".
        if (dvdNavigationTitle && job.mediaType === "dvd") {
          const audioInputIndexes = (taskSnapshot?.streamSelection.audioTrackIds ?? [])
            .map((id) => {
              const match = /^stream:(\d+)$/.exec(id);
              return match ? Number(match[1]) : null;
            })
            .filter((index): index is number => index !== null && index >= 0)
            .sort((a, b) => a - b);
          if (audioInputIndexes.length > 0) {
            const ffprobe = await resolveToolPath("ffprobe").catch(() => null);
            if (ffprobe) {
              const codecs = await probeDvdAudioCodecs(
                ffprobe,
                dvdInputArg(dvdVideoInputPath(sourcePath)),
                dvdNavigationTitle.titleNumber,
                audioInputIndexes,
              );
              let audioOutIndex = 0;
              for (const codec of codecs) {
                if (codec.codecName?.toLowerCase() === "pcm_dvd") {
                  ffmpegArgs.push(`-c:a:${audioOutIndex}`, "pcm_s16le");
                  await addLog(jobId, "info", `检测到 pcm_dvd 音轨 ${codec.inputIndex}：为兼容 MKV 将按无损 PCM 方式封装（不重新编码视频）`);
                }
                audioOutIndex += 1;
              }
            }
          }
        }
        if (chapterMetadataFile) ffmpegArgs.push("-map_metadata", "1", "-map_chapters", "1");
        if (selectedChapterCount > 0) {
          if (/\.mpls$/i.test(sourcePath) || /\.ifo$/i.test(sourcePath)) {
            await addLog(jobId, "info", `当前光盘 Remux 已保存 ${selectedChapterCount} 个选定章节；蓝光/DVD 章节范围将随后续片段时间映射处理。`);
          } else {
            await addLog(jobId, "info", `当前 Remux 将处理 ${selectedChapterCount} 个选定章节片段。`);
          }
        }
        ffmpegArgs.push(ffmpegPath(remuxOutputFile));
      };

      const buildRemuxFfmpegArgs = async (mode: "dvd-navigation" | "concat" | "file", listFile?: string) => {
        const ffmpegArgs: string[] = ["-y"];
        if (mode === "dvd-navigation") {
          if (!dvdNavigationTitle) throw new Error(`DVD 标题未找到可导航输入：${sourcePath}`);
          ffmpegArgs.push(
            "-analyzeduration", "100M",
            "-probesize", "100M",
            ...dvdTitleNavigationInputArgs(dvdNavigationTitle),
          );
          await appendRemuxSelectionArgs(ffmpegArgs, false);
        } else if (mode === "concat") {
          if (!listFile) throw new Error(`DVD 标题未找到可封装的 VOB concat 输入：${sourcePath}`);
          const vobProtocol = isVobConcatList(listFile);
          ffmpegArgs.push(
            "-fflags", "+genpts",
            "-analyzeduration", "100M",
            "-probesize", "100M",
            ...dvdConcatInputArgs(listFile),
          );
          await appendRemuxSelectionArgs(ffmpegArgs, true, vobProtocol);
        } else {
          if (isIfoInput) throw new Error(`DVD 标题未找到可封装的 IFO/VOB 输入：${sourcePath}`);
          ffmpegArgs.push("-i", ffmpegPath(inputPath));
          await appendRemuxSelectionArgs(ffmpegArgs, false);
        }
        return ffmpegArgs;
      };

      const runFfmpegRemux = async (ffmpegArgs: string[]) => {
        await new Promise<void>((resolve, reject) => {
          const ff = jobProcessController.spawnForJob(jobId, remuxFfmpeg, ffmpegArgs, config.processHighPriority ?? false);
          let stderrBuf = "";
          ff.stderr?.on("data", async (chunk) => {
            const text: string = chunk.toString();
            stderrBuf += text;
            // Parse progress from "time=HH:MM:SS.xx" in ffmpeg output
            const timeMatch = text.match(/time=(\d+):(\d+):([0-9.]+)/);
            if (timeMatch && job.durationSeconds && job.durationSeconds > 0) {
              const secs = parseInt(timeMatch[1]) * 3600 + parseInt(timeMatch[2]) * 60 + parseFloat(timeMatch[3]);
              const pct = mapExternalToolProgress({ toolPercent: Math.min(secs / job.durationSeconds, 1) * 100, start: 0, end: 95 });
              await db.update(jobsTable).set({ progress: pct }).where(eq(jobsTable.id, jobId));
            }
          });
          ff.on("close", async (code) => {
            if (code === 0) {
              resolve();
            } else {
              // Log the last meaningful lines of stderr to help diagnose failures
              const errLines = stderrBuf.split("\n")
                .map(l => l.trim()).filter(l => l.length > 0)
                .slice(-20).join("\n");
              if (errLines) await addLog(jobId, "error", `ffmpeg stderr:\n${errLines}`);
              reject(new Error(errLines ? `ffmpeg exit ${code}: ${errLines}` : `ffmpeg exit ${code}`));
            }
          });
          ff.on("error", (e) => reject(new Error(`ffmpeg 未找到：${e.message}`)));
        });
      };

      try {
        if (dvdNavigationTitle) {
          const ffmpegArgs = await buildRemuxFfmpegArgs("dvd-navigation");
          await addLog(jobId, "info", `ffmpeg 参数: ${ffmpegArgs.join(" ")}`);
          try {
            await runFfmpegRemux(ffmpegArgs);
            const navigationProbe = await probeStreams(remuxOutputFile).catch(() => null);
            if (!isPlayableRemuxProbe(navigationProbe)) {
              await fs.rm(remuxOutputFile, { force: true }).catch(() => {});
              throw new Error("DVD 导航未产生有效视频输出，自动回退 VOB concat");
            }
          } catch (error) {
            if (!ffmpegSupportsDvdTitleNavigation(error)) {
              throw new Error(`本机 FFmpeg 不支持 DVD title 导航；请安装带 dvdvideo/libdvdread/libdvdnav 支持的 FFmpeg 后再执行 DVD Remux。原始错误：${error instanceof Error ? error.message : String(error)}`);
            }
            await addLog(jobId, "warn", `DVD 导航模式失败，退回 VOB concat：${error instanceof Error ? error.message : String(error)}`);
            const fallbackConcatListFile = await writeDvdConcatListFile(dvdNavigationTitle, `fallback-vob-${jobId}`);
            try {
              const fallbackArgs = await buildRemuxFfmpegArgs("concat", fallbackConcatListFile);
              await addLog(jobId, "info", `ffmpeg 参数(退回 VOB concat): ${fallbackArgs.join(" ")}`);
              await runFfmpegRemux(fallbackArgs);
            } finally {
              await fs.unlink(fallbackConcatListFile).catch(() => {});
            }
          }
        } else if (concatListFile) {
          const ffmpegArgs = await buildRemuxFfmpegArgs("concat", concatListFile);
          await addLog(jobId, "info", `ffmpeg 参数: ${ffmpegArgs.join(" ")}`);
          await runFfmpegRemux(ffmpegArgs);
        } else {
          const ffmpegArgs = await buildRemuxFfmpegArgs("file");
          await addLog(jobId, "info", `ffmpeg 参数: ${ffmpegArgs.join(" ")}`);
          await runFfmpegRemux(ffmpegArgs);
        }
      } finally {
        // Always clean up the temporary concat list file
        if (concatListFile) await fs.unlink(concatListFile).catch(() => {});
        if (chapterMetadataFile) await fs.unlink(chapterMetadataFile).catch(() => {});
        if (isoRemuxDrive) await unmountBlurayIso(mediaInputPath).catch(() => {});
      }

      await addLog(jobId, "info", "无损封装完成");
      if (job.mediaType === "dvd" && taskSnapshot?.streamSelection.subtitleTrackIds.length) {
        await addLog(jobId, "warn", "DVD 字幕（vobsub）为图形字幕，无法无损复制进 MKV，本次 Remux 已跳过字幕轨");
      }

      let fileSizeAfter: number;
      let outputDuration: number | null;
      try {
        const validation = await validateRemuxOutput(remuxOutputFile, job.durationSeconds, probeStreams, {
          expectedSizeBytes: remuxExpectedSizeBytes,
          minimumSizeRatio: 0.65,
          maximumSizeRatio: job.mediaType === "dvd" ? 1.05 : undefined,
          maximumSizeOverheadBytes: job.mediaType === "dvd" ? 16 * 1024 * 1024 : undefined,
          maximumDurationDrift: job.mediaType === "dvd" ? 0.02 : undefined,
          expectedStreamCounts: taskSnapshot ? {
            video: taskSnapshot.streamSelection.videoTrackIds.length,
            audio: taskSnapshot.streamSelection.audioTrackIds.length,
            // DVD vobsub (dvd_subtitle) tracks cannot be stream-copied into
            // MKV; the remux intentionally skips them, so do not require them.
            subtitle: job.mediaType === "dvd" ? 0 : taskSnapshot.streamSelection.subtitleTrackIds.length,
          } : undefined,
          // Only require the selected chapters when the chapter metadata was
          // actually written (DVD navigation can fail on CSS discs and the
          // analysis fallback may not always provide a chapter layout).
          expectedChapterCount: chapterMetadataFile ? taskSnapshot?.chapterSelection.chapterIds.length : undefined,
        });
        fileSizeAfter = validation.fileSize;
        outputDuration = validation.duration;
        if (validation.drift !== null && validation.drift > 0.05) await addLog(jobId, "warn", `Remux 输出时长与源文件差异 ${(validation.drift * 100).toFixed(1)}%（源 ${job.durationSeconds?.toFixed(1)} 秒，输出 ${outputDuration?.toFixed(1)} 秒）`);
      } catch (probeError) {
        await addLog(jobId, "error", `Remux 输出校验失败：${String(probeError)}`);
        throw probeError;
      }
      const endPlayable = await verifyOutputEndPlayable(jobId, remuxOutputFile, outputDuration ?? job.durationSeconds);
      if (!endPlayable.ok) {
        throw new Error(`输出后段解码失败，文件可能损坏：${endPlayable.error}`);
      }
      pipelineRemuxOutputPath = (await finalizeRemuxStage({
        jobId,
        remuxOutputFile,
        fileSizeAfter,
        outputDuration,
        pipelineContinuesAfterRemux,
        subtitlePath,
        translatedSubtitlePath,
        graphicSubtitlePaths,
        log: (level, message) => addLog(jobId, level, message),
      })).pipelineRemuxOutputPath;
      if (!pipelineContinuesAfterRemux) return;
    }
    // ─── END REMUX branch ──────────────────────────────────────────────────────

    if (pipelineRemuxOutputPath) {
      handbrakeInputPath = pipelineRemuxOutputPath;
      await addLog(jobId, "info", `流水线：压缩阶段基于 Remux 输出 — ${pipelineRemuxOutputPath}`);
    }

    // 流水线未选择压缩步骤时（如 仅 Remux+字幕），在 Remux/字幕完成后结束任务。
    const shouldRunCompression = pipelineSteps.length === 0
      ? job.processingMode === "compress"
      : pipelineHasCompress;
    if (cancelledJobs.has(jobId)) {
      if (pipelineRemuxOutputPath) await fs.rm(pipelineRemuxOutputPath, { force: true }).catch(() => {});
      return;
    }
    if (!shouldRunCompression) {
      await db.update(jobsTable).set({
        status: "done",
        progress: 100,
        ...(pipelineRemuxOutputPath ? { outputPath: pipelineRemuxOutputPath } : {}),
        subtitlePath: sourceSubtitleFile ?? subtitlePath,
        translatedSubtitlePath,
        completedAt: new Date(),
      }).where(eq(jobsTable.id, jobId));
      await addLog(jobId, "info", `流水线任务完成（无压缩步骤）${pipelineRemuxOutputPath ? ` — 输出：${pipelineRemuxOutputPath}` : ""}`);
      await settlePreviewTaskSafely(jobId, {
        taskKind: pipelineRemuxOutputPath ? "remux" : "subtitle",
        outputValid: Boolean(pipelineRemuxOutputPath || sourceSubtitleFile || subtitlePath || translatedSubtitlePath),
        isPreviewOnly: false,
        cancelled: false,
      });
      return;
    }

    const isDiscCompressionSource = job.processingMode === "compress"
      && (job.mediaType === "dvd" || job.mediaType === "bluray" || job.mediaType === "iso");
    if (isDiscCompressionSource) {
      await addLog(jobId, "info", "光盘压缩模式 — HandBrake 直接分析 DVD/蓝光/ISO；FFmpeg 用于 Remux 无损封装");
    }

    // 执行以任务快照的压缩参数为准（用户在智能助手/工作流里确认的参数），
    // 快照未指定的项（调优/配置/级别等）才回退到全局设置。
    const compressionConfig = {
      ...config,
      ...(taskSnapshot?.compression ? {
        encoder: taskSnapshot.compression.encoder ?? config.encoder,
        crf: taskSnapshot.compression.crf ?? config.crf,
        encoderPreset: taskSnapshot.compression.preset ?? config.encoderPreset,
        encoderTune: taskSnapshot.compression.encoderTune ?? config.encoderTune,
        encoderProfile: taskSnapshot.compression.encoderProfile ?? config.encoderProfile,
        encoderLevel: taskSnapshot.compression.encoderLevel ?? config.encoderLevel,
        outputResolution: taskSnapshot.compression.resolution ?? config.outputResolution,
        outputFormat: taskSnapshot.compression.outputFormat ?? config.outputFormat,
        audioCopy: taskSnapshot.compression.audioCopy ?? config.audioCopy,
        frameRate: taskSnapshot.compression.frameRate ?? config.frameRate,
        deinterlace: taskSnapshot.compression.deinterlace ?? config.deinterlace,
      } : {}),
    };

    const encSummary = [
      `编码器：${compressionConfig.encoder}`,
      `CRF：${compressionConfig.crf}`,
      `预设：${compressionConfig.encoderPreset || "medium"}`,
      compressionConfig.encoderTune && compressionConfig.encoderTune !== "none" ? `调优：${compressionConfig.encoderTune}` : null,
      compressionConfig.encoderProfile && compressionConfig.encoderProfile !== "auto" ? `配置：${compressionConfig.encoderProfile}` : null,
      compressionConfig.encoderLevel && compressionConfig.encoderLevel !== "auto" ? `级别：${compressionConfig.encoderLevel}` : null,
      compressionConfig.outputResolution && compressionConfig.outputResolution !== "source" ? `分辨率：${compressionConfig.outputResolution}` : "分辨率：保持原始",
      compressionConfig.frameRate !== "same" ? `帧率：${compressionConfig.frameRate}fps` : "帧率：保持原始",
    ].filter(Boolean).join("，");
    await addLog(jobId, "info", `正在压缩 — ${encSummary}`);

    const parsedHandBrakeSelectionPlan = parseHandBrakeSelectionPlan(job.selectionPlan);
    const frozenHandBrakeTitleNumber = taskSnapshot?.toolSelections.handbrakeTitleNumber
      ?? parsedHandBrakeSelectionPlan?.handbrake?.titleNumber
      ?? null;
    if (job.mediaType === "dvd" && !temporaryRemuxPath && !pipelineRemuxOutputPath
      && (typeof frozenHandBrakeTitleNumber !== "number" || frozenHandBrakeTitleNumber <= 0)) {
      throw new Error("DVD 压缩缺少不可变任务快照中的 HandBrake 标题编号，拒绝回退到默认标题");
    }
    const frozenSelectionPlan = parsedHandBrakeSelectionPlan && job.mediaType === "dvd" && !temporaryRemuxPath && !pipelineRemuxOutputPath
      ? {
        ...parsedHandBrakeSelectionPlan,
        handbrake: {
          ...(parsedHandBrakeSelectionPlan.handbrake ?? {}),
          titleNumber: frozenHandBrakeTitleNumber,
        },
      }
      : parsedHandBrakeSelectionPlan;
    const handBrakeSelectionPlan = temporaryRemuxPath && taskSnapshot
      ? {
        version: 1 as const,
        video: parsedHandBrakeSelectionPlan?.video ?? [],
        audio: parsedHandBrakeSelectionPlan?.audio ?? [],
        subtitle: parsedHandBrakeSelectionPlan?.subtitle ?? [],
        chapters: parsedHandBrakeSelectionPlan?.chapters ?? [],
        handbrake: {
          audioTrackNumbers: taskSnapshot.streamSelection.audioTrackIds.map((_, index) => index + 1),
          subtitleTrackNumbers: taskSnapshot.streamSelection.subtitleTrackIds.map((_, index) => index + 1),
          chapterNumbers: parsedHandBrakeSelectionPlan?.handbrake?.chapterNumbers ?? [],
        },
      }
      : frozenSelectionPlan;
    // Deinterlace filter (yadif) — fixes horizontal line artifacts from
    // interlaced sources. Auto-detects interlaced video from the selected
    // title's media file; the manual setting can force it on as well.
    let deinterlace = compressionConfig.deinterlace === true;
    try {
      const deintAnalysis = taskSnapshot?.analysisId
        ? discAnalysisRegistry.find(taskSnapshot.analysisId)
        : undefined;
      const deintTitle = deintAnalysis?.titles.find((candidate) => candidate.titleId === taskSnapshot?.selectedTitleId);
      const probeTarget = deintTitle?.previewSourcePath ?? null;
      if (probeTarget) {
        const deintProbe = await probeStreams(probeTarget);
        if (detectInterlacedFromStreams(deintProbe.streams)) deinterlace = true;
      } else if (deintTitle?.videoTracks?.[0]?.frameRate) {
        const video = deintTitle.videoTracks[0];
        if (detectInterlacedFromStreams([{ codecType: "video", frameRate: video.frameRate, height: video.height ?? null }])) deinterlace = true;
      }
    } catch {
      // Probe failed — keep the current decision.
    }
    if (deinterlace) {
      await addLog(jobId, "info", compressionConfig.deinterlace === true ? "已启用去隔行 (yadif)" : "检测到隔行源，已自动启用去隔行 (yadif)");
    }

    const useCompressionManifest = Boolean(
      taskSnapshot
      && taskSnapshot.outputMode === "compress"
      && taskSnapshot.compressionSourceStrategy === "direct-disc"
      && selectedAnalysisTitle
      && !temporaryRemuxPath
      && !pipelineRemuxOutputPath
      && (job.mediaType === "dvd" || job.mediaType === "bluray" || job.mediaType === "iso"),
    );
    const compressionArguments = buildCompressionArgsForJob({
      snapshot: taskSnapshot,
      title: selectedAnalysisTitle ?? null,
      inputPath: handbrakeInputPath,
      outputPath: outputFile,
      config: compressionConfig,
      selectionPlan: handBrakeSelectionPlan,
      deinterlace,
      useManifest: useCompressionManifest,
    });
    const hbArgs = compressionArguments.args;
    const handBrakeSelectionArgs = compressionArguments.selectionArgs;
    if (compressionArguments.usedManifest) {
      await addLog(jobId, "info", "压缩参数来自已验证媒体清单：标题、音轨、字幕和章节选择已冻结");
    } else {
      await addLog(jobId, "info", "压缩参数使用兼容旧任务路径：当前来源未满足已验证媒体清单条件");
    }
    if (handBrakeSelectionArgs.length > 0) {
      await addLog(jobId, "info", `HandBrake 选择参数：${handBrakeSelectionArgs.join(" ")}`);
    } else {
      await addLog(jobId, "info", "HandBrake 未收到精确流轨选择，使用默认全部音轨/全部字幕");
    }

    if (job.mediaType === "dvd" && !temporaryRemuxPath && !pipelineRemuxOutputPath) {
      if (!handBrakeSelectionArgs.includes("--title")) {
        throw new Error("DVD 压缩选择参数未包含所选 HandBrake 标题编号");
      }
      await addLog(jobId, "info", `HandBrake DVD 标题：Title ${frozenHandBrakeTitleNumber}（来自 selectedTitleId=${taskSnapshot?.selectedTitleId ?? "legacy-selection-plan"}）`);
    }

    // Add external SRT if subtitle extraction/transcription was done in a prior job.
    // Guard against a transcription that reported success without writing a file
    // (e.g. Whisper on a clip with no audio) — HandBrake exits 3 on a missing SRT.
    if (subtitlePath && fsSync.existsSync(subtitlePath)) {
      hbArgs.push("--srt-file", ffmpegPath(subtitlePath), "--srt-default");
    } else if (subtitlePath) {
      await addLog(jobId, "warn", `字幕文件不存在，跳过 --srt-file：${subtitlePath}`);
    }

    const hbCli = config.handbrakeCliPath || await resolveToolPath("handbrake") || "HandBrakeCLI";
    await addLog(jobId, "info", `HandBrakeCLI 参数: ${hbArgs.join(" ")}`);

    const handBrakeStartedAt = Date.now();
    await new Promise<void>((resolve, reject) => {
      const hb = jobProcessController.spawnForJob(jobId, hbCli, hbArgs, config.processHighPriority ?? false);
      let lastProgress = 0;
      let lastDbWrite = 0;
      // A full encode is long; keep only the output tail for diagnostics.
      const hbStdout = new BoundedOutput(1024 * 1024);
      const hbStderr = new BoundedOutput(1024 * 1024);

      // HandBrake outputs progress to stdout (or stderr depending on version).
      // We normalise \r → \n so every "Encoding: task …" line is parsed reliably.
      let hbBuffer = "";
      const handleHbChunk = async (chunk: Buffer) => {
        // Replace carriage returns with newlines so partial lines become full lines
        hbBuffer += chunk.toString().replace(/\r/g, "\n");
        const lines = hbBuffer.split("\n");
        hbBuffer = lines.pop() ?? "";
        for (const line of lines) {
          const match = line.match(
            /Encoding: task \d+ of \d+, ([0-9.]+) %(?:[^(]*\(([0-9.]+) fps, avg ([0-9.]+) fps, ETA (\d+)h(\d+)m(\d+)s\))?/
          );
          if (match) {
            const pct = parseFloat(match[1]);
            const mapped = mapExternalToolProgress({ toolPercent: pct, start: 0, end: 95 });
            const currentFps = match[2] ? parseFloat(match[2]) : null;
            const avgFps = match[3] ? parseFloat(match[3]) : null;
            const etaSeconds = match[4]
              ? parseInt(match[4]) * 3600 + parseInt(match[5]) * 60 + parseInt(match[6])
              : null;
            const now = Date.now();
            if (mapped - lastProgress > 0.5 || now - lastDbWrite > 2000) {
              lastProgress = mapped;
              lastDbWrite = now;
              await db.update(jobsTable)
                .set({ progress: mapped, currentFps, avgFps, etaSeconds })
                .where(eq(jobsTable.id, jobId));
            }
          }
        }
      };

      const safeHandleHbChunk = (chunk: Buffer) => {
        void handleHbChunk(chunk).catch(async (error) => {
          await addLog(jobId, "warn", `HandBrake 进度解析失败：${error instanceof Error ? error.message : String(error)}`).catch(() => {});
        });
      };

      hb.stdout?.on("data", (chunk: Buffer) => {
        hbStdout.append(chunk);
        safeHandleHbChunk(chunk);
      });
      hb.stderr?.on("data", (chunk: Buffer) => {
        hbStderr.append(chunk);
        safeHandleHbChunk(chunk);
      });
      hb.on("close", (code) => {
        void appendJobToolOutput(jobId, {
          tool: "HandBrakeCLI",
          executable: hbCli,
          args: hbArgs,
          exitCode: code,
          durationMs: Date.now() - handBrakeStartedAt,
          stdout: hbStdout.toString(),
          stderr: hbStderr.toString(),
        }).catch(() => {});
        void addLog(jobId, code === 0 ? "info" : "error", `HandBrakeCLI 退出码：${code ?? "unknown"}；输出路径：${outputFile}`)
          .catch(() => {});
        if (code === 0) {
          if (cancelledJobs.has(jobId)) {
            // 取消后 HandBrake 若仍正常退出，不写完成状态并删除刚生成的输出。
            void fs.rm(outputFile, { force: true }).then(() => reject(new Error("任务已取消"))).catch(() => reject(new Error("任务已取消")));
          } else {
            resolve();
          }
        }
        else reject(new Error(`HandBrakeCLI exit ${code}`));
      });
      hb.on("error", (e) => reject(new Error(`HandBrakeCLI 未找到：${e.message}`)));
    });

    await addLog(jobId, "info", `HandBrake 压缩完成；耗时 ${Date.now() - handBrakeStartedAt} ms；工具=${hbCli}`);

    const compressionValidation = await validateCompressionOutput({
      jobId,
      outputFile,
      expectedDurationSeconds: job.durationSeconds,
      expectedStreamCounts: taskSnapshot?.outputMode === "compress" ? {
        video: taskSnapshot.streamSelection.videoTrackIds.length,
        audio: taskSnapshot.streamSelection.audioTrackIds.length,
        subtitle: taskSnapshot.streamSelection.subtitleTrackIds.length,
      } : undefined,
      expectedChapterCount: taskSnapshot?.outputMode === "compress" ? taskSnapshot.chapterSelection.chapterIds.length : undefined,
      requiredAudioCount: taskSnapshot?.outputMode === "compress" && taskSnapshot.streamSelection.audioTrackIds.length > 0 ? 1 : 0,
    });
    const fileSizeAfter = compressionValidation.fileSize;
    await addLog(jobId, "info", `HandBrake 输出验证通过：文件大小=${fileSizeAfter} 字节；时长=${compressionValidation.durationSeconds ?? "未知"} 秒；后置校验未发现致命错误`);

    await db.update(jobsTable).set({
      status: "done",
      progress: 100,
      currentFps: null,
      avgFps: null,
      etaSeconds: null,
      outputPath: outputFile,
      fileSizeAfter,
      durationSeconds: compressionValidation.durationSeconds ?? undefined,
      completedAt: new Date(),
    }).where(eq(jobsTable.id, jobId));

    await addLog(jobId, "info", `任务完成 — 输出：${outputFile}`);
    await settlePreviewTaskSafely(jobId, { taskKind: "compress", outputValid: true, isPreviewOnly: false, cancelled: false });
    await fixAssPlayResForOutput(outputFile, translatedSubtitlePath, (level, message) => addLog(jobId, level, message));
    await stageSubtitleSidecars(jobId, outputFile, subtitlePath, translatedSubtitlePath, (level, message) => addLog(jobId, level, message), graphicSubtitlePaths);

    // 流水线：压缩完成后，为压缩版生成同名 srt（字幕跟随 Remux 名时自动适配压缩版文件名）
    if (subtitleStageBaseName && subtitleStageBaseName !== compressionBaseName && pipelineHasSubtitle) {
      try {
        const srtEntries = await fs.readdir(subtitleDirJob).catch(() => [] as string[]);
        for (const name of srtEntries) {
          if (!SUBTITLE_FILE_EXT_RE.test(name) || !name.startsWith(`${subtitleStageBaseName}.`)) continue;
          const target = path.join(subtitleDirJob, `${compressionBaseName}.${name.slice(subtitleStageBaseName.length + 1)}`);
          if (path.resolve(target) === path.resolve(path.join(subtitleDirJob, name))) continue;
          await fs.copyFile(path.join(subtitleDirJob, name), target);
          await addLog(jobId, "info", `已为压缩版生成同名字幕：${target}`);
        }
      } catch (error) {
        await addLog(jobId, "warn", `压缩版字幕适配失败：${error instanceof Error ? error.message : String(error)}`);
      }
    }

  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    // Don't overwrite the "用户取消" status set by the cancel route
    if (!cancelledJobs.has(jobId)) {
      await db.update(jobsTable).set({
        status: "error",
        errorMessage: msg,
        completedAt: new Date(),
      }).where(eq(jobsTable.id, jobId));
      await addLog(jobId, "error", `任务失败：${msg}`);
      // 失败时删除本次产生的未完成输出（按运行前快照，保留上次成功输出）
      await removeIncompleteJobOutputs(jobId, (message) => addLog(jobId, "info", message));
    }
  } finally {
    if (temporaryRemuxPath) {
      await fs.rm(temporaryRemuxPath, { force: true }).catch(async (error) => {
        await addLog(jobId, "warn", `临时 Remux 文件清理失败，已保留日志：${String(error)}`).catch(() => {});
      });
    }
    // Always clean up tracking state when job finishes
    cancelledJobs.delete(jobId);
    jobProcessController.clearJob(jobId);
    clearJobOutputFiles(jobId);
    void startNextPendingJob().catch(() => {});
  }

  // ── Shutdown-after-complete check ─────────────────────────────────────────
  try {
    const latestConfig = await getConfig();
    if (latestConfig.shutdownAfterComplete) {
      const activeJobs = await db.select({ id: jobsTable.id }).from(jobsTable).where(
        sql`status IN ('pending','scanning','transcribing','compressing','remuxing')`
      );
      if (activeJobs.length === 0) {
        const signalPath = path.join(resolveOutputDir(latestConfig.outputDirectory, latestConfig), "mediasculpt-shutdown-signal.txt");
        await fs.writeFile(signalPath, `MediaSculpt 全部任务完成，关机信号\n${new Date().toISOString()}\n`, "utf-8");
        await addLog(jobId, "info", `✅ 全部任务完成 — 已写出关机信号：${signalPath}`);
      }
    }
  } catch { /* ignore shutdown check errors */ }
}

// ─── Routes ──────────────────────────────────────────────────────────────────

// GET /jobs
// ─── Shared readme generation ─────────────────────────────────────────────────
