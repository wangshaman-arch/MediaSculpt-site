import { Router } from "express";
import os from "os";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import {
  CreateJobBody,
  ListJobsQueryParams,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
  ScanDirectoryBody,
} from "@workspace/api-zod";
import {
  createStandaloneTaskSnapshotV1,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotSettings,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  defaultRemuxOutputDirectory,
  hasExecutableWorkflowSelection,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { buildCompressionOutputName, buildRemuxOutputName, encoderBitDepth } from "../lib/output-naming";
import { cleanupPreviewSegments } from "../lib/preview-segments";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import { assertPreviewTaskAllowed } from "../lib/preview-runtime";
import { normalizeDiscSourcePath, type DiscAnalysisResult } from "../lib/disc-analysis";
import { assessDiscComplexity } from "../lib/disc-complexity";
import { buildDvdStructurePayload, resolveRemuxPlanWithLlm, validateRemuxPlan } from "../lib/dvd-llm";
import { buildSourceManifest } from "../lib/source-manifest";
import { normalizeTitleEn } from "../lib/metadata";
import { dvdOutputBaseName } from "../lib/dvd-source-identity";
import { resolveDvdVideoTsDir } from "../lib/disc";
import { resolveRuntimePath } from "../lib/runtime-paths";
import { resolveToolPath } from "../lib/tool-runtime";
import { appendRuntimeToolLog } from "../lib/runtime-tool-log";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { verifyDvdTitle } from "../lib/dvd-remux";
import { isActiveJobStatus } from "../application/job-errors";
import {
  addLog,
  blockedReasonMessage,
  cancelledJobs,
  clearJobOutputFiles,
  defaultTaskSnapshotOutputMode,
  discAnalysisRegistry,
  dvdVideoInputPath,
  ensureAnalysisIsoReady,
  getConfig,
  isBlurayDisc,
  isDvdDisc,
  isQueuePaused,
  jobRunner,
  jobService,
  killJobProcesses,
  normalizePipelineSteps,
  outputDirectoryForTask,
  parsePipelineNames,
  parsePipelineSteps,
  parseTaskSnapshotIndexArray,
  resolveJobOutputDirectory,
  resolveJobSubtitleDirectory,
  resolveMainTrack,
  runningJobStatuses,
  setQueuePaused,
  settlePreviewTaskSafely,
  snapshotTitleIndex,
  SOURCE_DIRECTORY_VALUE,
  startJobWhenQueueIdle,
  startNextPendingJob,
  trackJobOutputFile,
  validateJobViability,
  validateTaskSnapshotBeforeStart,
  validateWritableDirectory,
  VIDEO_EXTENSIONS,
} from "./jobs";

const router = Router();

router.get("/jobs", async (req, res) => {
  const parsed = ListJobsQueryParams.safeParse(req.query);
  const params = parsed.success ? parsed.data : { limit: 50 };

  const conditions = [];
  if (params.status) {
    conditions.push(eq(jobsTable.status, params.status));
  }

  const rows: Array<typeof jobsTable.$inferSelect> = await db.select()
    .from(jobsTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(jobsTable.createdAt))
    .limit(params.limit ?? 50);

  if (rows.length > 0) {
    const logRows = await db.select({ jobId: jobLogsTable.jobId, message: jobLogsTable.message, createdAt: jobLogsTable.createdAt })
      .from(jobLogsTable)
      .where(inArray(jobLogsTable.jobId, rows.map((row) => row.id)))
      .orderBy(desc(jobLogsTable.createdAt));
    const lastByJob = new Map<number, string>();
    for (const log of logRows) {
      if (!lastByJob.has(log.jobId)) lastByJob.set(log.jobId, log.message);
    }
    return res.json(rows.map((row) => ({ ...row, lastLog: lastByJob.get(row.id) ?? null })));
  }

  return res.json(rows);
});

import { requestedWorkflowOutputFileName, resolveLlmRemuxPlanForCreate } from "./jobs-crud-helpers";
export { requestedWorkflowOutputFileName, resolveLlmRemuxPlanForCreate } from "./jobs-crud-helpers";

// POST /jobs
/** Keep the persisted overview consistent with the authoritative task IMDb id. */
function reconcileMovieOverview(raw: string | null, imdbId: string | null): string | null {
  if (!raw && !imdbId) return null;
  let lines = (raw ?? "").split(/\r?\n/);
  const contentIndex = lines.findIndex((line) => /^\s*(内容简介|简介|overview)\s*[:：]/i.test(line));
  if (contentIndex >= 0) lines = lines.slice(contentIndex + 1);
  const cleaned = lines
    .filter((line) => !/^\s*IMDBID\s*=/i.test(line))
    .filter((line) => !/^\s*IMDb\s*(?:编号|ID|评分)?\s*[:：=]/i.test(line))
    .filter((line) => !/^\s*豆瓣评分\s*[:：=]/i.test(line))
    .filter((line) => !/^\s*主创\s*[:：]?\s*$/i.test(line))
    .filter((line) => !/待确认|未检索到|未找到|未知|N\/?A/i.test(line))
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  if (!imdbId) return cleaned || null;
  const authoritative = `IMDb 编号：${imdbId}`;
  return cleaned ? `${cleaned}\n${authoritative}` : authoritative;
}

router.post("/jobs", async (req, res) => {
  const parsed = CreateJobBody.safeParse(req.body);
  if (!parsed.success) {
    await appendRuntimeToolLog(`创建任务失败：请求体无效 ${JSON.stringify(parsed.error.flatten())}`).catch(() => {});
    return res.status(400).json({ error: "请求体无效" });
  }

  const {
    filePath, subtitleMode, ocrEngine, ocrLanguage, processingMode, mainTrackPath, selectedStreams, selectedChapters, selectionPlan, mediaType,
    analysisId, sourceFingerprint, selectedTitleId, outputMode, remuxExportCandidateIndex, forceSmartRemux, pipelineSteps, pipelineNames,
    compressionSettings,
  } = parsed.data;
  const config = await getConfig();
  // A workflow preset is selected per item. Freeze its concrete values into
  // this task before it enters the queue; later global setting changes must
  // not alter an already-created job.
  const taskSettings: TaskSnapshotSettings = {
    ...config,
    ...(compressionSettings ?? {}),
  };
  const workflowOutputFileName = requestedWorkflowOutputFileName(selectionPlan);
  let smartOutcome: { invoked: boolean; applied: boolean; reason?: string } | undefined;
  const runtimeFilePath = resolveRuntimePath(filePath, config);
  let runtimeMainTrackPath = mainTrackPath ? resolveRuntimePath(mainTrackPath, config) : null;
  let normalizedMediaType = mediaType ?? "video";

  // ISO 镜像按光盘源处理：无论前端提交 bluray/dvd，都以 iso 类型执行（执行器会挂载镜像）。
  if (/\.iso$/i.test(runtimeFilePath)) normalizedMediaType = "iso";

  if (normalizedMediaType === "dvd" || await isDvdDisc(runtimeFilePath)) {
    normalizedMediaType = "dvd";
    // The verified dvdvideo title is the only execution input. Do not resolve an
    // IFO/VOB "main track" here because that would reintroduce title guessing.
    runtimeMainTrackPath = (await resolveDvdVideoTsDir(runtimeFilePath)) ?? runtimeFilePath;
  } else if (normalizedMediaType === "bluray" || await isBlurayDisc(runtimeFilePath)) {
    normalizedMediaType = "bluray";
    runtimeMainTrackPath = runtimeMainTrackPath || await resolveMainTrack(runtimeFilePath, "bluray");
  }
  let normalizedProcessingMode = normalizeRequestedProcessingMode({
    mediaType: normalizedMediaType,
    processingMode: processingMode ?? "compress",
  });
  let normalizedSubtitleMode = subtitleMode ?? "auto";
  // 流水线（多选 压缩/Remux/仅字幕）：Remux 仅对光盘源有效；视频文件自动剔除 Remux。
  const normalizedPipelineSteps = normalizePipelineSteps(pipelineSteps, normalizedMediaType);
  if (normalizedPipelineSteps.length > 0) {
    normalizedProcessingMode = normalizedPipelineSteps.includes("compress")
      ? "compress"
      : normalizedPipelineSteps.includes("remux")
        ? "remux"
        : "none";
    if (!normalizedPipelineSteps.includes("subtitle")) normalizedSubtitleMode = "skip";
  }

  const normalizedOutputMode = outputMode ?? defaultTaskSnapshotOutputMode({
    processingMode: normalizedProcessingMode,
    subtitleMode: normalizedSubtitleMode,
  });
  if (!requiresWorkflowSelection(selectionPlan) && !hasExecutableWorkflowSelection({
    processingMode: normalizedProcessingMode,
    subtitleMode: normalizedSubtitleMode,
    outputMode: normalizedOutputMode,
    pipelineSteps: normalizedPipelineSteps,
  })) {
    return res.status(400).json({
      error: "未选择可执行的处理方式：请至少选择 Remux、压缩或字幕处理；如果只想保留原文件，请不要创建任务。",
    });
  }
  if (normalizedOutputMode === "both") {
    return res.status(400).json({ error: "同时 Remux 和压缩的执行器将在下一阶段迁移；请先分别创建任务" });
  }

  const discTaskSourcePath = normalizedMediaType === "dvd"
    ? (await resolveDvdVideoTsDir(runtimeFilePath)) ?? runtimeFilePath
    : normalizeDiscSourcePath(runtimeFilePath);
  let taskSnapshot;
  try {
    const selectedStreamIndexes = parseTaskSnapshotIndexArray(selectedStreams);
    const selectedChapterIds = parseTaskSnapshotIndexArray(selectedChapters);
    if (normalizedMediaType === "dvd" || normalizedMediaType === "bluray" || normalizedMediaType === "iso") {
      if (!analysisId || !sourceFingerprint || !selectedTitleId || !outputMode) {
        return res.status(400).json({ error: "光盘任务必须提交 analysisId、sourceFingerprint、selectedTitleId 和 outputMode；请重新分析后创建任务" });
      }
      // ISO analyses store the mounted drive path (e.g. E:\VIDEO_TS), while the
      // create request carries the ISO file path. Use the analysis' mounted
      // sourcePath (re-mounted on demand) so the snapshot matches the registry.
      const registeredAnalysis = discAnalysisRegistry.find(analysisId);
      const requestSourcePath = registeredAnalysis?.isoPath
        ? await ensureAnalysisIsoReady(registeredAnalysis)
        : discTaskSourcePath;
      // DVD Remux requires a verified title. Auto-verify it here (fresh, bypassing
      // any stale cached failure) so remux + bilingual just works instead of being
      // blocked by "title not verified / verification failed".
      if (registeredAnalysis?.mediaType === "dvd" && normalizedOutputMode === "remux") {
        const targetTitle = registeredAnalysis.titles.find((candidate) => candidate.titleId === selectedTitleId);
        const titleNumber = targetTitle?.toolMappings.handbrakeTitleNumber;
        if (targetTitle && targetTitle.verificationStatus !== "verified" && typeof titleNumber === "number" && titleNumber > 0) {
          const ffprobeExecutable = await resolveToolPath("ffprobe");
          if (ffprobeExecutable) {
            const verification = await verifyDvdTitle({
              sourcePath: dvdVideoInputPath(registeredAnalysis.sourcePath),
              titleNumber,
              handbrakeDurationSeconds: targetTitle.durationSeconds,
              handbrakeChapterCount: targetTitle.chapterCount,
              handbrakeStreams: targetTitle.streams,
              ffprobeExecutable,
            }).catch(() => null);
            if (verification?.verified) {
              targetTitle.verificationStatus = "verified";
              targetTitle.verificationFailureReason = null;
              targetTitle.toolMappings.dvdVtsNumber = titleNumber;
              targetTitle.durationSeconds = verification.durationSeconds ?? targetTitle.durationSeconds;
              targetTitle.chapters = verification.chapters;
              targetTitle.chapterCount = verification.chapters.length;
              targetTitle.streams = verification.streams;
              targetTitle.videoTracks = verification.videoTracks;
              targetTitle.audioTracks = verification.audioTracks;
              targetTitle.subtitleTracks = verification.subtitleTracks;
              targetTitle.verificationWarnings = verification.warnings;
              discAnalysisRegistry.remember(registeredAnalysis);
              await appendRuntimeToolLog(`DVD Remux 自动验证成功 analysis=${analysisId} title=${titleNumber}`).catch(() => {});
            }
          }
        }
      }
      const smartResult = await resolveLlmRemuxPlanForCreate({
        analysis: registeredAnalysis,
        selectedTitleId,
        outputMode: normalizedOutputMode,
        config,
        forceSmartRemux,
      });
      smartOutcome = smartResult.outcome;
      taskSnapshot = prepareTaskSnapshotForJobCreation({
        registry: discAnalysisRegistry,
        request: {
           analysisId,
           sourcePath: requestSourcePath,
           sourceFingerprint,
           selectedTitleId,
           smartManifestId: (() => {
             try {
               const parsedPlan = selectionPlan ? JSON.parse(selectionPlan) as { smartManifestId?: unknown } : {};
               return typeof parsedPlan.smartManifestId === "string" ? parsedPlan.smartManifestId : null;
             } catch {
               return null;
             }
           })(),
           outputMode: normalizedOutputMode,
           physicalVtsNumber: registeredAnalysis?.titles.find((candidate) => candidate.titleId === selectedTitleId)?.toolMappings.physicalVtsNumber ?? null,
          remuxExportCandidateIndex: remuxExportCandidateIndex ?? null,
          selectedStreamIndexes,
          selectedChapterIds,
          outputFileName: workflowOutputFileName,
          // 复杂光碟（结构含糊/多义）：把真实结构推给 LLM，用其校验过的流选择精确 remux。
          // 仅在 LLM 与该标题一致且经真实流校验通过时生效；任何失败一律回退确定性路径。
          llmRemuxPlan: smartResult.plan,
        },
        settings: taskSettings,
      }).snapshot;
    } else {
      taskSnapshot = createStandaloneTaskSnapshotV1({
        sourcePath: runtimeFilePath,
        sourceType: "video",
        outputMode: normalizedOutputMode,
        selectedStreamIndexes,
        selectedChapterIds,
        settings: taskSettings,
        outputFileName: workflowOutputFileName,
      });
    }
  } catch (error) {
    const code = error instanceof TaskSnapshotError ? error.code : "TASK_SNAPSHOT_INVALID";
    const detail = error instanceof Error ? error.message : String(error);
    if (code === "TASK_SNAPSHOT_ANALYSIS_NOT_FOUND") {
      const registered = discAnalysisRegistry.find(analysisId ?? "");
      await appendRuntimeToolLog(
        `创建任务诊断 analysisId=${analysisId ?? ""} registryFound=${Boolean(registered)} `
        + `registrySource=${registered?.sourcePath ?? "n/a"} requestSource=${discTaskSourcePath} `
        + `registryFp=${registered?.sourceFingerprint ?? "n/a"} requestFp=${sourceFingerprint ?? "n/a"}`
        + `requestFpLen=${String(sourceFingerprint ?? "").length} registryFpLen=${String(registered?.sourceFingerprint ?? "").length}`
      ).catch(() => {});
    }
    await appendRuntimeToolLog(`创建任务失败：taskSnapshot ${code} source=${runtimeFilePath} detail=${detail}`).catch(() => {});
    return res.status(400).json({ error: `创建任务失败：${code}。${detail !== code ? detail : "请重新分析并确认标题、流轨和章节选择。"}` });
  }

  if (["dvd", "bluray", "iso"].includes(normalizedMediaType) && normalizedProcessingMode === "remux") {
    const remuxDirectory = taskSnapshot.output.directory === SOURCE_DIRECTORY_VALUE
      ? (/\.iso$/i.test(runtimeFilePath)
          ? defaultRemuxOutputDirectory(runtimeFilePath, "iso")
          : defaultRemuxOutputDirectory(taskSnapshot.sourcePath, normalizedMediaType))
      : resolveRuntimePath(taskSnapshot.output.directory, config);
    try {
      await validateWritableDirectory(remuxDirectory);
      await appendRuntimeToolLog(`Remux 输出目录已验证：${remuxDirectory}`).catch(() => {});
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      await appendRuntimeToolLog(`Remux 输出目录不可写：${remuxDirectory} ${reason}`).catch(() => {});
      return res.status(400).json({ error: `Remux 输出目录不可用或不可写：${remuxDirectory}` });
    }
  }

  if (normalizedMediaType === "dvd" && normalizedProcessingMode === "remux") {
    const activeRows = await db.select().from(jobsTable).where(sql`${jobsTable.status} in ('pending', 'scanning', 'transcribing', 'compressing', 'remuxing')`);
    const duplicate = activeRows.some((row: typeof jobsTable.$inferSelect) => {
      const activeSnapshot = loadTaskSnapshot(row);
      return activeSnapshot?.sourceType === "dvd"
        && activeSnapshot.outputMode === "remux"
        && activeSnapshot.sourceFingerprint === taskSnapshot.sourceFingerprint
        && activeSnapshot.selectedTitleId === taskSnapshot.selectedTitleId;
    });
    if (duplicate) return res.status(409).json({ error: "同一 DVD 标题的 Remux 任务已在队列或运行中" });
  }

  // For regular video files, verify the file exists.
  // Remux jobs point to a disc directory — skip the file check (ffmpeg validates at runtime).
  if (normalizedProcessingMode !== "remux") {
    try {
      await fs.access(runtimeFilePath);
    } catch {
      await appendRuntimeToolLog(`创建任务失败：文件未找到 ${runtimeFilePath}`).catch(() => {});
      return res.status(400).json({ error: `文件未找到：${runtimeFilePath}` });
    }
  }

  // Optional confirmed movie metadata from the smart workflow identity.
  const rawBody = (req.body ?? {}) as Record<string, unknown>;
  const movieTitle = typeof rawBody.movieTitle === "string" && rawBody.movieTitle.trim() ? rawBody.movieTitle.trim() : null;
  const movieTitleEnRaw = typeof rawBody.movieTitleEn === "string" ? rawBody.movieTitleEn.trim() : "";
  const movieTitleEn = normalizeTitleEn(movieTitleEnRaw) || movieTitleEnRaw || null;
  const movieYear = typeof rawBody.movieYear === "number" && Number.isFinite(rawBody.movieYear) ? rawBody.movieYear : null;
  const movieImdbId = typeof rawBody.movieImdbId === "string" && /^tt\d{7,8}$/i.test(rawBody.movieImdbId.trim())
    ? rawBody.movieImdbId.trim()
    : null;
  const movieOverview = reconcileMovieOverview(
    typeof rawBody.movieOverview === "string" && rawBody.movieOverview.trim() ? rawBody.movieOverview.trim() : null,
    movieImdbId,
  );
  const moviePoster = typeof rawBody.moviePoster === "string" && rawBody.moviePoster.trim() ? rawBody.moviePoster.trim() : null;

  // Persist the selected title's chapter times so the Remux chapter pass can
  // write the real chapter layout even after the in-memory analysis cache
  // expires (e.g. when a queued job runs later).
  let persistedSelectionPlan = selectionPlan;
  try {
    const chapterAnalysis = discAnalysisRegistry.find(taskSnapshot.analysisId);
    const chapterTitle = chapterAnalysis?.titles.find((candidate) => candidate.titleId === taskSnapshot.selectedTitleId);
    if (chapterTitle?.chapters && chapterTitle.chapters.length > 0) {
      const parsedPlan = selectionPlan ? JSON.parse(selectionPlan) as Record<string, unknown> : {};
      parsedPlan.chapterTimes = chapterTitle.chapters.map((chapter) => ({
        id: chapter.id,
        startSeconds: chapter.startSeconds,
        endSeconds: chapter.endSeconds,
      }));
      persistedSelectionPlan = JSON.stringify(parsedPlan);
    }
  } catch {
    persistedSelectionPlan = selectionPlan;
  }
  // 双语字幕的自定义参数写入 selectionPlan，供执行阶段读取。
  try {
    const customPlan = persistedSelectionPlan ? JSON.parse(persistedSelectionPlan) as Record<string, unknown> : {};
    let customChanged = false;
    if (rawBody.bilingualLayout === "zh-top" || rawBody.bilingualLayout === "foreign-top") {
      customPlan.bilingualLayout = rawBody.bilingualLayout;
      customChanged = true;
    }
    if (customChanged) persistedSelectionPlan = JSON.stringify(customPlan);
  } catch {
    // 保持原 selectionPlan 不变。
  }

  const [job] = await db.insert(jobsTable).values({
    filePath: runtimeFilePath,
    subtitleMode: normalizedSubtitleMode,
    ocrEngine: subtitleMode === "ocr" ? (ocrEngine ?? "auto") : null,
    ocrLanguage: subtitleMode === "ocr" ? (ocrLanguage ?? "auto") : null,
    generateReadme: typeof rawBody.generateReadme === "boolean" ? rawBody.generateReadme : false,
    generatePoster: typeof rawBody.generatePoster === "boolean" ? rawBody.generatePoster : false,
    generateReview: typeof rawBody.generateReview === "boolean" ? rawBody.generateReview : false,
    processingMode: normalizedProcessingMode,
    mediaType: normalizedMediaType,
    mainTrackPath: runtimeMainTrackPath,
    movieTitle,
    movieTitleEn,
    movieYear,
    movieImdbId,
    movieOverview,
    moviePoster,
    selectedStreams: selectedStreams ?? null,
    selectedChapters: selectedChapters ?? null,
    selectionPlan: persistedSelectionPlan ?? null,
    pipelineSteps: normalizedPipelineSteps.length > 0
      ? JSON.stringify({
        steps: normalizedPipelineSteps,
        names: {
          remux: typeof pipelineNames?.remux === "string" && pipelineNames.remux.trim() ? pipelineNames.remux.trim() : null,
          compress: typeof pipelineNames?.compress === "string" && pipelineNames.compress.trim() ? pipelineNames.compress.trim() : null,
        },
      })
      : null,
    taskSnapshot: serializeTaskSnapshot(taskSnapshot),
    taskSnapshotVersion: taskSnapshot.snapshotVersion,
    legacyTask: false,
    sourceManifest: JSON.stringify(buildSourceManifest({ filePath: runtimeFilePath, mediaType: normalizedMediaType, mainTrackPath: runtimeMainTrackPath })),
  }).returning();

  const snapshotSummary = taskSnapshotSummary(taskSnapshot);
  await addLog(job.id, "info", `任务快照已创建：version=${snapshotSummary.snapshotVersion} analysis=${snapshotSummary.analysisId} title=${snapshotSummary.selectedTitleId} mode=${snapshotSummary.outputMode} sourceStrategy=${snapshotSummary.compressionSourceStrategy} handbrake=${snapshotSummary.handbrakeTitleNumber ?? "n/a"}`);
  await appendRuntimeToolLog(`创建任务成功：job=${job.id} mode=${normalizedProcessingMode} media=${normalizedMediaType} file=${runtimeFilePath} analysis=${snapshotSummary.analysisId} title=${snapshotSummary.selectedTitleId}`).catch(() => {});

  return res.status(201).json({ ...job, snapshot: snapshotSummary, smartOutcome: smartOutcome ?? undefined });
});

// POST /jobs/scan
router.post("/jobs/scan", async (req, res) => {
  const parsed = ScanDirectoryBody.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "请求体无效" });
  }

  const {
    directory,
    recursive,
    subtitleMode = "auto",
    processingMode = "compress",
  } = parsed.data;
  const config = await getConfig();
  const runtimeDirectory = resolveRuntimePath(directory, config);

  interface DiscoveredItem {
    filePath: string;
    mediaType: "video" | "bluray" | "dvd" | "iso";
    mainTrackPath?: string;
    processingMode: WorkflowProcessingMode;
    subtitleMode: "auto" | "extract" | "whisper" | "transcribe_translate" | "skip" | "ocr" | "bilingual";
  }

  async function scanDir(dir: string): Promise<DiscoveredItem[]> {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    const items: DiscoveredItem[] = [];

    // Check if this directory is a disc root first
    if (await isBlurayDisc(dir)) {
      const mainTrackPath = await resolveMainTrack(dir, "bluray");
      const itemProcessingMode = normalizeRequestedProcessingMode({ mediaType: "bluray", processingMode });
      items.push({
        filePath: dir,
        mediaType: "bluray",
        mainTrackPath,
        processingMode: itemProcessingMode,
        subtitleMode: itemProcessingMode === "remux" ? "skip" : subtitleMode,
      });
      return items; // don't recurse into disc folders
    }
    if (await isDvdDisc(dir)) {
      const mainTrackPath = await resolveMainTrack(dir, "dvd");
      const itemProcessingMode = normalizeRequestedProcessingMode({ mediaType: "dvd", processingMode });
      items.push({
        filePath: dir,
        mediaType: "dvd",
        mainTrackPath,
        processingMode: itemProcessingMode,
        subtitleMode: itemProcessingMode === "remux" ? "skip" : subtitleMode,
      });
      return items;
    }

    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (recursive) items.push(...(await scanDir(fullPath)));
      } else if (entry.isFile()) {
        const ext = path.extname(entry.name).toLowerCase();
        if (!VIDEO_EXTENSIONS.includes(ext)) continue;
        if (ext === ".iso") {
          const itemProcessingMode = normalizeRequestedProcessingMode({ mediaType: "iso", processingMode });
          items.push({ filePath: fullPath, mediaType: "iso", processingMode: itemProcessingMode, subtitleMode: itemProcessingMode === "remux" ? "skip" : subtitleMode });
        } else if (ext === ".m2ts" || ext === ".ts") {
          // Standalone BD transport stream
          const itemProcessingMode = normalizeRequestedProcessingMode({ mediaType: "bluray", processingMode });
          items.push({ filePath: fullPath, mediaType: "bluray", processingMode: itemProcessingMode, subtitleMode: itemProcessingMode === "remux" ? "skip" : subtitleMode });
        } else if (ext === ".vob") {
          const itemProcessingMode = normalizeRequestedProcessingMode({ mediaType: "dvd", processingMode });
          items.push({ filePath: fullPath, mediaType: "dvd", processingMode: itemProcessingMode, subtitleMode: itemProcessingMode === "remux" ? "skip" : subtitleMode });
        } else {
          items.push({ filePath: fullPath, mediaType: "video", processingMode, subtitleMode: processingMode === "remux" ? "skip" : subtitleMode });
        }
      }
    }
    return items;
  }

  let items: DiscoveredItem[] = [];
  try {
    items = await scanDir(runtimeDirectory);
  } catch (e) {
    return res.status(400).json({ error: `无法扫描目录：${String(e)}` });
  }

  const existing = await db.select({ fp: jobsTable.filePath }).from(jobsTable);
  const existingSet = new Set(existing.map((r: typeof existing[number]) => r.fp));

  let created = 0;
  let skipped = 0;
  const createdFiles: string[] = [];

  for (const item of items) {
    if (existingSet.has(item.filePath)) {
      skipped++;
    } else {
      await db.insert(jobsTable).values({
        filePath: item.filePath,
        subtitleMode: item.subtitleMode,
        mediaType: item.mediaType,
        mainTrackPath: item.mainTrackPath ?? null,
        processingMode: item.processingMode,
        legacyTask: true,
        sourceManifest: JSON.stringify(buildSourceManifest({
          filePath: item.filePath,
          mediaType: item.mediaType,
          mainTrackPath: item.mainTrackPath ?? null,
        })),
      });
      created++;
      createdFiles.push(item.filePath);
    }
  }

  return res.json({ found: items.length, created, skipped, files: createdFiles });
});

// 队列暂停状态查询。必须注册在 GET /jobs/:id 之前，否则 “queue-status” 会被当成任务 ID 返回 400。
router.get("/jobs/queue-status", async (_req, res) => {
  return res.json({ paused: isQueuePaused() });
});

// GET /jobs/:id
router.get("/jobs/:id", async (req, res) => {
  const parsed = GetJobParams.safeParse(req.params);
  if (!parsed.success) return res.status(400).json({ error: "无效的任务 ID" });

  const rows = await db.select().from(jobsTable).where(eq(jobsTable.id, parsed.data.id)).limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });

  return res.json(rows[0]);
});

// DELETE /jobs/:id
router.delete("/jobs/:id", async (req, res) => {
  const parsed = DeleteJobParams.safeParse(req.params);
  if (!parsed.success) return res.status(400).json({ error: "无效的任务 ID" });

  const rows = await db.select().from(jobsTable).where(eq(jobsTable.id, parsed.data.id)).limit(1);
  if (rows[0] && isActiveJobStatus(rows[0].status)) {
    return res.status(409).json({ error: "运行中的任务不能直接删除，请先暂停或取消" });
  }
  await db.delete(jobsTable).where(eq(jobsTable.id, parsed.data.id));
  if (rows[0]?.filePath) void cleanupPreviewSegments(rows[0].filePath).catch(() => {});
  return res.status(204).send();
});

// POST /jobs/:id/start
router.post("/jobs/:id/start", async (req, res) => {
  const parsed = StartJobParams.safeParse(req.params);
  if (!parsed.success) return res.status(400).json({ error: "无效的任务 ID" });

  const result = await jobService.start(parsed.data.id);
  if (result.kind === "not-found") return res.status(404).json({ error: "任务未找到" });
  if (result.kind === "invalid-state") return res.status(400).json({ error: `任务状态为 ${result.job.status}，无法启动` });
  if (result.kind === "needs-confirmation") return res.status(400).json({ error: "请先在智能助手中选择处理项目并确认" });
  if (result.kind === "preview-blocked") return res.status(409).json({ errorCode: result.code, error: result.message, preview: result.preview });
  return res.json(result.job);
});

// POST /jobs/:id/retry
router.post("/jobs/:id/retry", async (req, res) => {
  const parsed = RetryJobParams.safeParse(req.params);
  if (!parsed.success) return res.status(400).json({ error: "无效的任务 ID" });

  const rows = await db.select().from(jobsTable).where(eq(jobsTable.id, parsed.data.id)).limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });

  try {
    await assertPreviewTaskAllowed();
  } catch (error) {
    if (isPreviewLimitError(error)) return res.status(409).json({ errorCode: error.errorCode, error: error.message, preview: error.preview });
    throw error;
  }

  // 重试时，Remux 任务的输出目录与字幕目录跟随当前配置（默认“与源文件同目录”），
  // 避免旧任务快照里的旧目录把输出写到别处。
  const retryConfig = await getConfig();
  const retrySnapshot = loadTaskSnapshot(rows[0]);
  if (retrySnapshot && !hasExecutableWorkflowSelection({
    processingMode: rows[0].processingMode,
    subtitleMode: rows[0].subtitleMode,
    outputMode: retrySnapshot.outputMode,
  })) {
    const message = "该旧任务没有可执行步骤：原任务保存为‘跳过字幕 + 不处理视频’。请打开任务详情，在智能助手中选择 Remux 或压缩后再确认，不能直接重试。";
    await addLog(parsed.data.id, "error", message);
    return res.status(409).json({ errorCode: "TASK_NO_EXECUTABLE_STEP", error: message });
  }
  if (retrySnapshot && retrySnapshot.outputMode === "remux") {
    const remuxTargetDir = retryConfig.remuxOutputDirectory ?? retryConfig.outputDirectory;
    const subtitleTargetDir = retryConfig.subtitleDirectory ?? "";
    if (retrySnapshot.output.directory !== remuxTargetDir || (retrySnapshot.output.subtitleDirectory ?? "") !== subtitleTargetDir) {
      const refreshed = {
        ...retrySnapshot,
        output: {
          ...retrySnapshot.output,
          directory: remuxTargetDir,
          subtitleDirectory: subtitleTargetDir,
        },
      };
      await db.update(jobsTable).set({ taskSnapshot: serializeTaskSnapshot(refreshed) }).where(eq(jobsTable.id, parsed.data.id));
      await addLog(parsed.data.id, "info", `重试已同步输出目录到当前配置：${remuxTargetDir === SOURCE_DIRECTORY_VALUE ? "源文件同目录" : remuxTargetDir}`);
    }
  }

  await db.update(jobsTable).set({
    status: "pending",
    errorMessage: null,
    progress: null,
    startedAt: null,
    completedAt: null,
  }).where(eq(jobsTable.id, parsed.data.id));

  await startJobWhenQueueIdle(parsed.data.id);
  const [updated] = await db.select().from(jobsTable).where(eq(jobsTable.id, parsed.data.id)).limit(1);
  return res.json(updated);
});

// 队列调度暂停：当前任务继续跑完，但不再自动开始下一个 pending 任务。
router.post("/jobs/queue/pause", async (_req, res) => {
  setQueuePaused(true);
  await appendRuntimeToolLog("队列已暂停：不再自动开始新任务").catch(() => {});
  return res.json({ paused: true });
});

// 队列调度恢复：恢复自动调度，并立即尝试启动下一个待处理任务。
router.post("/jobs/queue/resume", async (_req, res) => {
  setQueuePaused(false);
  await appendRuntimeToolLog("队列已恢复自动调度").catch(() => {});
  void startNextPendingJob().catch(() => {});
  return res.json({ paused: false });
});

// 暂停单个任务：终止运行中的子进程并标记为“已暂停”（不阻塞队列调度），
// 之后可用重试/恢复重新执行。
router.post("/jobs/:id/pause", async (req, res) => {
  const parsed = CancelJobParams.safeParse(req.params);
  if (!parsed.success) return res.status(400).json({ error: "无效的任务 ID" });
  const result = await jobService.pause(parsed.data.id);
  if (result.kind === "not-found") return res.status(404).json({ error: "任务未找到" });
  if (result.kind === "stop-failed") return res.status(409).json({ error: "未能确认外部处理进程已退出，任务仍在运行，请稍后重试停止" });
  return res.json(result.job);
});

// POST /jobs/:id/cancel
router.post("/jobs/:id/cancel", async (req, res) => {
  const parsed = CancelJobParams.safeParse(req.params);
  if (!parsed.success) return res.status(400).json({ error: "无效的任务 ID" });

  const result = await jobService.cancel(parsed.data.id);
  if (result.kind === "not-found") return res.status(404).json({ error: "任务未找到" });
  if (result.kind === "stop-failed") return res.status(409).json({ error: "未能确认外部处理进程已退出，任务仍在运行，请稍后重试停止" });
  return res.json(result.job);
});

// PATCH /jobs/:id/execution - apply assistant-confirmed execution options.
// Pending/queued/error jobs are updated in place (and reset to pending when
// they previously errored); completed jobs are cloned into a new pending job
// so the newly confirmed options actually run.
router.patch("/jobs/:id/execution", async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ error: "invalid job id" });

  const rows = await db.select().from(jobsTable).where(eq(jobsTable.id, id)).limit(1);
  if (!rows.length) return res.status(404).json({ error: "job not found" });
  const job = rows[0];
  if (["scanning", "transcribing", "compressing", "remuxing"].includes(job.status)) {
    return res.status(409).json({ error: "job is running" });
  }

  const raw = (req.body ?? {}) as Record<string, unknown>;
  const requestedPipelineSteps = Array.isArray(raw.pipelineSteps)
    ? raw.pipelineSteps.filter((step): step is string => typeof step === "string")
    : undefined;
  const requestedSubtitleMode = typeof raw.subtitleMode === "string" ? raw.subtitleMode : undefined;
  const requestedPresetId = Object.prototype.hasOwnProperty.call(raw, "presetId")
    ? (typeof raw.presetId === "string" && raw.presetId.trim() ? raw.presetId.trim() : null)
    : undefined;
  const requestedCompressionSettings = (() => {
    const value = raw.compressionSettings;
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    const source = value as Record<string, unknown>;
    const result: Record<string, string | number> = {};
    for (const key of ["encoder", "encoderPreset", "encoderTune", "encoderProfile", "encoderLevel", "frameRate", "outputResolution"]) {
      if (typeof source[key] === "string" && source[key].trim()) result[key] = source[key].trim();
    }
    if (typeof source.crf === "number" && Number.isFinite(source.crf)) result.crf = source.crf;
    return Object.keys(result).length > 0 ? result : null;
  })();
  const requestedChapterSamplePosition =
    raw.chapterSamplePosition === "middle" || raw.chapterSamplePosition === "start" || raw.chapterSamplePosition === "end"
      ? raw.chapterSamplePosition
      : undefined;
  const movieTitle = typeof raw.movieTitle === "string" && raw.movieTitle.trim() ? raw.movieTitle.trim() : undefined;
  const movieTitleEn = typeof raw.movieTitleEn === "string" && raw.movieTitleEn.trim() ? raw.movieTitleEn.trim() : undefined;
  const movieYear = Object.prototype.hasOwnProperty.call(raw, "movieYear")
    ? (typeof raw.movieYear === "number" && Number.isFinite(raw.movieYear) ? raw.movieYear : raw.movieYear === null ? null : undefined)
    : undefined;
  const movieImdbId = Object.prototype.hasOwnProperty.call(raw, "movieImdbId")
    ? (typeof raw.movieImdbId === "string" && /^tt\d{7,8}$/i.test(raw.movieImdbId.trim())
      ? raw.movieImdbId.trim()
      : raw.movieImdbId === null ? null : undefined)
    : undefined;

  const allowedSubtitleModes = ["auto", "extract", "whisper", "transcribe_translate", "skip", "ocr", "bilingual"];
  if (requestedSubtitleMode !== undefined && !allowedSubtitleModes.includes(requestedSubtitleMode)) {
    return res.status(400).json({ error: "invalid subtitleMode" });
  }

  const config = await getConfig();
  const currentSteps = parsePipelineSteps(job);
  const currentNames = parsePipelineNames(job);
  const steps = requestedPipelineSteps !== undefined
    ? normalizePipelineSteps(requestedPipelineSteps, job.mediaType ?? "video")
    : currentSteps;
  const stepsChanged = requestedPipelineSteps !== undefined
    && JSON.stringify(steps) !== JSON.stringify(currentSteps);

  let selectionPlan: Record<string, unknown> | null = null;
  try {
    selectionPlan = job.selectionPlan ? JSON.parse(job.selectionPlan) as Record<string, unknown> : null;
  } catch {
    selectionPlan = null;
  }
  const currentPresetId = selectionPlan && typeof selectionPlan.presetId === "string" ? selectionPlan.presetId : null;
  const presetChanged = requestedPresetId !== undefined && (requestedPresetId ?? null) !== currentPresetId;

  const finalSubtitleMode = steps.length > 0 && !steps.includes("subtitle")
    ? "skip"
    : (requestedSubtitleMode !== undefined ? requestedSubtitleMode : (job.subtitleMode ?? "auto"));
  const subtitleChanged = requestedSubtitleMode !== undefined && finalSubtitleMode !== (job.subtitleMode ?? "auto");

  // 用户明确提交空流水线（如关闭压缩/Remux/字幕）时，处理模式应为 none：
  // 只做元数据/AI 生成，不执行任何视频处理。
  const processingMode = steps.length > 0
    ? (steps.includes("chapterPreview") ? "chapterPreview" : steps.includes("compress") ? "compress" : steps.includes("remux") ? "remux" : "none")
    : (requestedPipelineSteps !== undefined ? "none" : (job.processingMode ?? "compress"));
  const processingChanged = processingMode !== (job.processingMode ?? "compress");

  const metadataChanged = movieTitle !== undefined || movieTitleEn !== undefined || movieYear !== undefined || movieImdbId !== undefined;
  const compressionSettingsChanged = requestedCompressionSettings !== null;
  const executionChanged = stepsChanged || subtitleChanged || presetChanged || processingChanged || compressionSettingsChanged;
  if (!executionChanged && !metadataChanged) {
    return res.status(200).json({ id, recreated: false, unchanged: true, job });
  }

  let snapshot: TaskSnapshotV1 | null = null;
  try {
    snapshot = loadTaskSnapshot(job);
  } catch {
    snapshot = null;
  }

  const outputMode = steps.length > 0
    ? defaultTaskSnapshotOutputMode({ processingMode, subtitleMode: finalSubtitleMode })
    : null;
  const mediaType = job.mediaType ?? "video";
  const rawBaseName = path.basename(job.filePath ?? "");
  const baseName = mediaType === "dvd"
    ? dvdOutputBaseName({
      sourcePath: job.filePath ?? "",
      mediaType: "dvd",
      titleNumber: snapshot?.toolSelections.handbrakeTitleNumber ?? snapshot?.toolSelections.dvdVtsNumber,
      titleCount: 1,
    })
    : (/^(VIDEO_TS|BDMV)$/i.test(rawBaseName)
      ? path.basename(path.dirname(job.filePath ?? ""))
      : path.basename(job.filePath ?? "", path.extname(job.filePath ?? "")));
  const titleIndex = snapshotTitleIndex(snapshot);
  const outputBase = mediaType === "dvd" ? baseName : `${baseName}${titleIndex >= 0 ? `.Title${String(titleIndex + 1).padStart(2, "0")}` : ""}`;
  const buildCompressName = () => buildCompressionOutputName({
    baseName: outputBase,
    mediaType,
    outputFormat: config.outputFormat ?? "mkv",
    encoder: config.encoder,
    crf: config.crf,
    primaryAudioCodec: null,
    bitDepth: encoderBitDepth(config.encoder),
    template: config.outputNameTemplate,
  });
  const names = {
    remux: steps.includes("remux") ? (currentNames.remux ?? buildRemuxOutputName(outputBase, mediaType, config.outputFormat ?? "mkv", config.outputNameTemplate)) : null,
    compress: steps.includes("compress") ? (currentNames.compress ?? buildCompressName()) : null,
  };

  let nextSnapshot: TaskSnapshotV1 | null = snapshot;
  if (snapshot && executionChanged) {
    const nextMode = outputMode ?? snapshot.outputMode;
    const modeChanged = nextMode !== snapshot.outputMode;
    const nextFileName = modeChanged
      ? (outputMode === "remux"
        ? buildRemuxOutputName(outputBase, mediaType, config.outputFormat ?? "mkv", config.outputNameTemplate)
        : outputMode === "compress"
          ? buildCompressName()
          : `${outputBase}.MediaSculpt.srt`)
      : snapshot.output.fileName;
    // Remux 输出目录始终跟随当前配置（默认“与源文件同目录”），避免克隆/确认
    // 旧任务时沿用旧快照里冻结的目录。字幕目录同步跟随。
    const nextOutputDirectory = nextMode === "remux"
      ? (config.remuxOutputDirectory ?? config.outputDirectory)
      : snapshot.output.directory;
    const nextSubtitleDirectory = nextMode === "remux"
      ? (config.subtitleDirectory ?? "")
      : snapshot.output.subtitleDirectory;
    nextSnapshot = {
      ...snapshot,
      outputMode: nextMode,
      compression: compressionSettingsChanged
        ? { ...snapshot.compression, ...requestedCompressionSettings }
        : snapshot.compression,
      output: {
        ...snapshot.output,
        fileName: nextFileName,
        directory: nextOutputDirectory,
        subtitleDirectory: nextSubtitleDirectory,
      },
    };
  }

  const nextSelectionPlan = selectionPlan && (requestedPresetId !== undefined || requestedChapterSamplePosition !== undefined || (requestedPipelineSteps !== undefined && steps.length > 0))
    ? JSON.stringify({
        ...selectionPlan,
        ...(requestedPipelineSteps !== undefined && steps.length > 0 ? { needsUserSelection: false } : {}),
        ...(requestedPresetId !== undefined ? { presetId: requestedPresetId ?? null } : {}),
        ...(requestedChapterSamplePosition !== undefined ? { chapterSamplePosition: requestedChapterSamplePosition } : {}),
      })
    : (job.selectionPlan ?? undefined);
  const nextPipelineJson = steps.length > 0 ? JSON.stringify({ steps, names }) : null;

  const rowUpdates: Partial<typeof jobsTable.$inferInsert> = {
    pipelineSteps: requestedPipelineSteps !== undefined ? nextPipelineJson : undefined,
    processingMode: processingChanged ? processingMode : undefined,
    subtitleMode: subtitleChanged ? finalSubtitleMode : undefined,
    ocrEngine: subtitleChanged && finalSubtitleMode === "ocr" ? (job.ocrEngine ?? "auto") : undefined,
    ocrLanguage: subtitleChanged && finalSubtitleMode === "ocr" ? (job.ocrLanguage ?? "auto") : undefined,
    selectionPlan: requestedPresetId !== undefined || requestedChapterSamplePosition !== undefined ? nextSelectionPlan : undefined,
    movieTitle: movieTitle !== undefined ? movieTitle : undefined,
    movieTitleEn: movieTitleEn !== undefined ? movieTitleEn : undefined,
    movieYear: movieYear !== undefined ? movieYear : undefined,
    movieImdbId: movieImdbId !== undefined ? movieImdbId : undefined,
    taskSnapshot: nextSnapshot ? serializeTaskSnapshot(nextSnapshot) : undefined,
    taskSnapshotVersion: nextSnapshot?.snapshotVersion ?? undefined,
  };

  if (job.status === "done") {
    if (!executionChanged) {
      // 已完成任务的执行计划是历史事实，确认时只能改元数据（片名/年代），
      // 绝不允许原地改写 processingMode/pipeline/subtitle/taskSnapshot，
      // 否则记录会与真实输出不一致（例如“压缩”任务实际输出了 Remux）。
      const metadataOnly: Partial<typeof jobsTable.$inferInsert> = {};
      if (movieTitle !== undefined) metadataOnly.movieTitle = movieTitle;
      if (movieTitleEn !== undefined) metadataOnly.movieTitleEn = movieTitleEn;
      if (movieYear !== undefined) metadataOnly.movieYear = movieYear;
      if (movieImdbId !== undefined) metadataOnly.movieImdbId = movieImdbId;
      if (Object.keys(metadataOnly).length === 0) {
        return res.status(200).json({ id, recreated: false, unchanged: true, job });
      }
      await db.update(jobsTable).set(metadataOnly).where(eq(jobsTable.id, id));
      const [updated] = await db.select().from(jobsTable).where(eq(jobsTable.id, id)).limit(1);
      return res.json({ id, recreated: false, job: updated });
    }
    const [cloned] = await db.insert(jobsTable).values({
      filePath: job.filePath,
      status: "pending",
      subtitleMode: subtitleChanged ? finalSubtitleMode : (job.subtitleMode ?? "auto"),
      ocrEngine: finalSubtitleMode === "ocr" ? (job.ocrEngine ?? "auto") : null,
      ocrLanguage: finalSubtitleMode === "ocr" ? (job.ocrLanguage ?? "auto") : null,
      generateReadme: job.generateReadme ?? false,
      generatePoster: job.generatePoster ?? false,
      generateReview: job.generateReview ?? false,
      processingMode,
      mediaType: job.mediaType ?? "video",
      mainTrackPath: job.mainTrackPath,
      movieTitle: movieTitle !== undefined ? movieTitle : job.movieTitle,
      movieTitleEn: movieTitleEn !== undefined ? movieTitleEn : job.movieTitleEn,
      movieYear: movieYear !== undefined ? movieYear : job.movieYear,
      movieImdbId: movieImdbId !== undefined ? movieImdbId : job.movieImdbId,
      movieOverview: job.movieOverview,
      moviePoster: job.moviePoster,
      selectedStreams: job.selectedStreams,
      selectedChapters: job.selectedChapters,
      sourceManifest: job.sourceManifest,
      selectionPlan: requestedPresetId !== undefined ? nextSelectionPlan : job.selectionPlan,
      taskSnapshot: nextSnapshot ? serializeTaskSnapshot(nextSnapshot) : job.taskSnapshot,
      taskSnapshotVersion: nextSnapshot?.snapshotVersion ?? job.taskSnapshotVersion,
      legacyTask: job.legacyTask ?? false,
      pipelineSteps: nextPipelineJson,
      durationSeconds: job.durationSeconds,
      hasEmbeddedSubtitles: job.hasEmbeddedSubtitles,
      fileSizeBefore: job.fileSizeBefore,
    }).returning();
    await addLog(cloned.id, "info", `rebuilt job #${id} with confirmed options: mode=${processingMode} pipeline=${steps.join("->") || "none"}`);
    return res.status(201).json({ id: cloned.id, recreated: true, job: cloned });
  }

  if (job.status === "error") {
    rowUpdates.status = "pending";
    rowUpdates.errorMessage = null;
    rowUpdates.progress = null;
    rowUpdates.startedAt = null;
    rowUpdates.completedAt = null;
  }
  await db.update(jobsTable).set(rowUpdates).where(eq(jobsTable.id, id));
  const [updated] = await db.select().from(jobsTable).where(eq(jobsTable.id, id)).limit(1);
  await addLog(id, "info", `applied confirmed options: mode=${processingMode} pipeline=${steps.join("->") || "none"}`);
  return res.json({ id, recreated: false, job: updated });
});

// GET /jobs/:id/logs
router.get("/jobs/:id/logs", async (req, res) => {
  const parsed = GetJobLogsParams.safeParse(req.params);
  if (!parsed.success) return res.status(400).json({ error: "无效的任务 ID" });

  const logs = await db.select()
    .from(jobLogsTable)
    .where(eq(jobLogsTable.jobId, parsed.data.id))
    .orderBy(jobLogsTable.createdAt);

  return res.json(logs);
});

// PUT /jobs/:id/metadata
router.put("/jobs/:id/metadata", async (req, res) => {
  const idParsed = GetJobParams.safeParse(req.params);
  if (!idParsed.success) return res.status(400).json({ error: "无效的任务 ID" });

  const jobId = idParsed.data.id;
  const rows = await db.select().from(jobsTable).where(eq(jobsTable.id, jobId)).limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });

  const {
    movieTitle, movieTitleEn, movieYear, movieRating,
    movieDirector, movieGenres, movieOverview, moviePoster,
    standardizedName, tmdbId, movieImdbId,
  } = req.body as Record<string, unknown>;
  const requestedImdbId = typeof movieImdbId === "string" && /^tt\d{7,8}$/i.test(movieImdbId.trim())
    ? movieImdbId.trim()
    : null;
  const existingImdbId = typeof rows[0].movieImdbId === "string" && /^tt\d{7,8}$/i.test(rows[0].movieImdbId.trim())
    ? rows[0].movieImdbId.trim()
    : null;

  const cleanedTitleEn = typeof movieTitleEn === "string"
    ? normalizeTitleEn(movieTitleEn) || movieTitleEn
    : movieTitleEn;

  await db.update(jobsTable).set({
    movieTitle: typeof movieTitle === "string" ? movieTitle : undefined,
    movieTitleEn: typeof cleanedTitleEn === "string" ? cleanedTitleEn : undefined,
    movieYear: typeof movieYear === "number" ? movieYear : undefined,
    movieImdbId: requestedImdbId ?? undefined,
    movieRating: typeof movieRating === "number" ? movieRating : undefined,
    movieDirector: typeof movieDirector === "string" ? movieDirector : undefined,
    movieGenres: typeof movieGenres === "string" ? movieGenres : undefined,
    movieOverview: typeof movieOverview === "string"
      ? reconcileMovieOverview(movieOverview, requestedImdbId ?? existingImdbId)
      : undefined,
    moviePoster: typeof moviePoster === "string" ? moviePoster : undefined,
    standardizedName: typeof standardizedName === "string" ? standardizedName : undefined,
    tmdbId: typeof tmdbId === "number" ? tmdbId : undefined,
  }).where(eq(jobsTable.id, jobId));

  const [updated] = await db.select().from(jobsTable).where(eq(jobsTable.id, jobId)).limit(1);
  return res.json(updated);
});


export const jobsCrudRouter = router;
