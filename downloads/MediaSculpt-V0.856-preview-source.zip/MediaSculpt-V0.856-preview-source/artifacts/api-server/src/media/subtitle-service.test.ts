import { mkdtemp, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { describe, expect, it } from "vitest";
import {
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
} from "./subtitle-service";

describe("subtitle service", () => {
  it("parses and renders SRT without changing cue timing", () => {
    const source = "1\n00:01:02,345 --> 00:01:04,500\nHello\n";
    const blocks = parseSrt(source);

    expect(blocks).toEqual([
      {
        index: "1",
        timestamp: "00:01:02,345 --> 00:01:04,500",
        text: "Hello",
      },
    ]);
    expect(renderSrt(blocks)).toBe(source);
  });

  it("renders simplified Chinese text while preserving cue metadata", () => {
    const blocks = parseSrt("1\n00:00:01,000 --> 00:00:02,000\n繁體字幕\n");

    expect(renderSrtSimplified(blocks, true)).toContain("繁体字幕");
    expect(renderSrtSimplified(blocks, false)).toContain("繁體字幕");
  });

  it("reads SRT, VTT and ASS files into common timed blocks", async () => {
    const directory = await mkdtemp(
      path.join(os.tmpdir(), "mediasculpt-subtitles-"),
    );
    const fixtures = {
      srt: "1\n00:00:01,000 --> 00:00:02,000\nSRT\n",
      vtt: "WEBVTT\n\n00:00:01.000 --> 00:00:02.000\nVTT\n",
      ass: "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\nDialogue: 0,0:00:01.00,0:00:02.00,Default,,0,0,0,,ASS\n",
    };

    for (const [extension, content] of Object.entries(fixtures)) {
      const filePath = path.join(directory, `subtitle.${extension}`);
      await writeFile(filePath, content, "utf8");
      await expect(readSubtitleBlocks(filePath)).resolves.toMatchObject([
        { startMs: 1000, endMs: 2000 },
      ]);
    }
  });
});
