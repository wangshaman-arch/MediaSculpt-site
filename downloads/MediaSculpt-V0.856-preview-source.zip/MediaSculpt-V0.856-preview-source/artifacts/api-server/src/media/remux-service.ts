import path from "node:path";
import { assertCompleteMediaTitle, type MediaTitle } from "./dvd-source";
import type { MediaPipelineManifest } from "./media-pipeline-contract";
import {
  buildDvdRemuxArgs,
  runDvdRemux,
  type ExternalToolRunner,
} from "../lib/dvd-remux";

type DvdRemuxRequest = Parameters<typeof runDvdRemux>[0];

export type DvdRemuxJobInput = Omit<DvdRemuxRequest, "run"> & {
  sourceTitle: MediaTitle;
  run?: ExternalToolRunner;
};

export function buildDvdRemuxRequest(input: DvdRemuxJobInput): DvdRemuxRequest {
  assertCompleteMediaTitle(input.sourceTitle);
  return {
    executable: input.executable,
    sourcePath: input.sourcePath,
    titleNumber: input.titleNumber,
    selectedVideoStreams: [...input.selectedVideoStreams],
    selectedAudioStreams: [...input.selectedAudioStreams],
    selectedAudioCodecs: input.selectedAudioCodecs?.map((codec) => ({
      ...codec,
    })),
    selectedSubtitleStreams: [...input.selectedSubtitleStreams],
    outputPath: input.outputPath,
    args: input.args,
    run: input.run,
  };
}

/** Convert the immutable selection contract into the legacy DVD executor shape. */
export function buildDvdRemuxRequestFromManifest(input: {
  manifest: MediaPipelineManifest;
  executable: string;
  run?: ExternalToolRunner;
}): DvdRemuxRequest {
  const { manifest } = input;
  if (manifest.source.kind !== "dvd" && manifest.source.kind !== "iso") {
    throw new Error("DVD Remux 只接受 DVD 文件夹或 ISO 来源");
  }
  if (manifest.output.mode !== "remux") {
    throw new Error("输出模式必须是 remux");
  }
  const titleNumber = manifest.title.titleNumber;
  if (
    typeof titleNumber !== "number" ||
    !Number.isInteger(titleNumber) ||
    titleNumber <= 0
  ) {
    throw new Error("DVD 标题编号无效");
  }
  const streamsById = new Map(
    manifest.title.streams.map((stream) => [stream.id, stream]),
  );
  const indexesFor = (
    ids: readonly string[],
    type: "video" | "audio" | "subtitle",
  ): number[] =>
    ids.map((id) => {
      const stream = streamsById.get(id);
      if (!stream || stream.type !== type)
        throw new Error(`清单中的${type}流轨选择无效：${id}`);
      return stream.index;
    });
  const selectedAudioStreams = indexesFor(
    manifest.selection.audioStreamIds,
    "audio",
  );
  return {
    executable: input.executable,
    sourcePath: manifest.source.path,
    titleNumber,
    selectedVideoStreams: indexesFor(
      manifest.selection.videoStreamIds,
      "video",
    ),
    selectedAudioStreams,
    selectedAudioCodecs: manifest.selection.audioStreamIds.map((id) => {
      const stream = streamsById.get(id);
      return {
        inputIndex: stream!.index,
        codecName: stream!.codec,
        bitsPerRawSample: stream!.bitsPerRawSample ?? null,
      };
    }),
    selectedSubtitleStreams: indexesFor(
      manifest.selection.subtitleStreamIds,
      "subtitle",
    ),
    outputPath: path.join(manifest.output.directory, manifest.output.fileName),
    run: input.run,
  };
}

export async function executeDvdRemux(
  input: DvdRemuxJobInput,
): Promise<Awaited<ReturnType<typeof runDvdRemux>>> {
  return runDvdRemux(buildDvdRemuxRequest(input));
}

export { buildDvdRemuxArgs };
