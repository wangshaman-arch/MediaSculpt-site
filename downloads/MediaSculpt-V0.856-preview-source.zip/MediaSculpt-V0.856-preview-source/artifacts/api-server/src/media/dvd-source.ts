import {
  findDvdTitles,
  resolveDvdTitleForIfo,
  type DvdTitle,
} from "../lib/disc";
import type { MediaSource, MediaTitle } from "./media-source";
import { IncompleteMediaTitleError } from "./media-source";

export function createDvdMediaTitle(title: DvdTitle): Readonly<MediaTitle> {
  const orderedInputs = Object.freeze([...title.vobFiles]);
  return Object.freeze({
    stableId: `dvd:${title.titleNumber}:${title.ifoPath}`,
    ordinal: title.titleNumber,
    sourceFile: title.ifoPath,
    sourceSizeBytes: title.sizeBytes,
    missingInputs: Object.freeze([...(title.missingVobFiles ?? [])]),
    durationSeconds: null,
    videoStreams: Object.freeze([]),
    audioStreams: Object.freeze([]),
    subtitleStreams: Object.freeze([]),
    chapters: Object.freeze([]),
    orderedInputs,
  });
}

export function createDvdMediaSource(input: {
  sourcePath: string;
  titles: readonly DvdTitle[];
}): Readonly<MediaSource> {
  const titles = Object.freeze(input.titles.map(createDvdMediaTitle));
  const firstTitle = input.titles[0];
  return Object.freeze({
    kind: "dvd" as const,
    sourcePath: input.sourcePath,
    analysisPath: firstTitle?.ifoPath,
    titles,
  });
}

export async function analyzeDvdSource(input: {
  sourcePath: string;
  minSizeBytes?: number;
}): Promise<Readonly<MediaSource>> {
  const titles = /\.ifo$/i.test(input.sourcePath)
    ? await resolveDvdTitleForIfo(input.sourcePath).then((title) =>
        title ? [title] : [],
      )
    : await findDvdTitles(input.sourcePath, input.minSizeBytes ?? 0);
  if (titles.length === 0)
    throw new Error(`未找到可用的 DVD 标题：${input.sourcePath}`);
  return createDvdMediaSource({ sourcePath: input.sourcePath, titles });
}

export function orderedDvdInputs(title: MediaTitle): readonly string[] {
  return title.orderedInputs;
}

export function assertCompleteMediaTitle(title: MediaTitle): void {
  if (title.missingInputs.length > 0) {
    throw new IncompleteMediaTitleError(title.missingInputs);
  }
  if (title.orderedInputs.length === 0) {
    throw new Error(`媒体标题没有可处理的输入文件：${title.stableId}`);
  }
}

export type {
  MediaChapter,
  MediaSource,
  MediaSourceKind,
  MediaStream,
  MediaTitle,
} from "./media-source";
export { IncompleteMediaTitleError } from "./media-source";
