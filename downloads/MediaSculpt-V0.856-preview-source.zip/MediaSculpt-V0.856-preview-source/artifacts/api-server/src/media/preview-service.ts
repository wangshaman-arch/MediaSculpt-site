import fs from "node:fs/promises";
import path from "node:path";
import { ffmpegPath } from "../lib/runtime-paths";
import { resolveToolPath } from "../lib/tool-runtime";
import {
  processRunner,
  type ProcessRunner,
} from "../infrastructure/process-runner";

const PREVIEW_VIDEO_EXTENSIONS = new Set([
  ".mp4",
  ".mkv",
  ".ts",
  ".m2ts",
  ".mov",
  ".avi",
  ".webm",
  ".vob",
  ".mpg",
  ".mpeg",
  ".wmv",
  ".flv",
  ".m4v",
  ".mp2",
  ".3gp",
  ".ogv",
  ".iso",
]);

export interface PreviewMetadata {
  durationSeconds: number | null;
  sizeBytes: number | null;
  fileName: string;
}

type PreviewProbeOutput = {
  format?: { duration?: string | number };
  streams?: Array<{ duration?: string | number }>;
};

type SubtitleProbeOutput = {
  streams?: Array<{ index?: number | string; codec_type?: string }>;
};

export function isPreviewVideoCandidate(filePath: string): boolean {
  const extension = path.extname(filePath).toLowerCase();
  // A disc directory has no extension and is resolved to its main title later.
  return !extension || PREVIEW_VIDEO_EXTENSIONS.has(extension);
}

export function buildPreviewTranscodeArgs(
  hasSub: boolean,
  subTypeIndex: number | null,
): string[] {
  const videoFilter =
    "yadif=mode=send_frame:parity=auto:deint=interlaced,scale=trunc(min(1280\\,iw)/2)*2:-2";
  return [
    ...(hasSub && subTypeIndex !== null
      ? [
          "-filter_complex",
          `[0:v:0]${videoFilter}[v];[0:s:${subTypeIndex}]format=rgba[sraw];[sraw][v]scale2ref[s][vmain];[vmain][s]overlay=0:0:eof_action=pass[vout]`,
          "-map",
          "[vout]",
          "-map",
          "0:a:0?",
        ]
      : ["-map", "0:v:0", "-map", "0:a:0?", "-vf", videoFilter]),
    "-c:v",
    "libx264",
    "-preset",
    "veryfast",
    "-g",
    "48",
    "-keyint_min",
    "48",
    "-sc_threshold",
    "0",
    "-pix_fmt",
    "yuv420p",
    "-b:v",
    "3200k",
    "-maxrate",
    "4500k",
    "-bufsize",
    "6000k",
    "-c:a",
    "aac",
    "-ac",
    "2",
    "-b:a",
    "128k",
    "-avoid_negative_ts",
    "make_zero",
    "-max_muxing_queue_size",
    "1024",
    "-fps_mode",
    "vfr",
    "-movflags",
    "frag_keyframe+empty_moov+default_base_moof",
    "-f",
    "mp4",
    "pipe:1",
  ];
}

export class PreviewService {
  private readonly subtitleIndexCache = new Map<
    string,
    { at: number; indices: number[] }
  >();

  constructor(
    private readonly runner: ProcessRunner = processRunner,
    private readonly resolveFfprobe: () => Promise<string | null> = () =>
      resolveToolPath("ffprobe").catch(() => null),
    private readonly cacheTtlMs = 10 * 60_000,
  ) {}

  async probeMetadata(filePath: string): Promise<PreviewMetadata> {
    const stat = await fs.stat(filePath).catch(() => null);
    const fallback = (): PreviewMetadata => ({
      durationSeconds: null,
      sizeBytes: stat?.size ?? null,
      fileName: path.basename(filePath),
    });
    const executable = (await this.resolveFfprobe()) ?? "ffprobe";
    try {
      const result = await this.runner.run({
        executable,
        stage: "preview-metadata",
        args: [
          "-v",
          "quiet",
          "-print_format",
          "json",
          "-show_streams",
          "-show_format",
          ffmpegPath(filePath),
        ],
      });
      if (result.code !== 0) return fallback();
      const parsed = JSON.parse(result.stdout) as PreviewProbeOutput;
      const durationSeconds = Number(parsed.format?.duration);
      const streamDuration = Array.isArray(parsed.streams)
        ? parsed.streams
            .map((stream) => Number(stream.duration))
            .find((value) => Number.isFinite(value) && value > 0)
        : null;
      return {
        durationSeconds:
          Number.isFinite(durationSeconds) && durationSeconds > 0
            ? durationSeconds
            : (streamDuration ?? null),
        sizeBytes: stat?.size ?? null,
        fileName: path.basename(filePath),
      };
    } catch {
      return fallback();
    }
  }

  async subtitleContainerIndices(filePath: string): Promise<number[]> {
    const cached = this.subtitleIndexCache.get(filePath);
    if (cached && Date.now() - cached.at < this.cacheTtlMs)
      return [...cached.indices];

    const executable = (await this.resolveFfprobe()) ?? "ffprobe";
    let indices: number[] = [];
    try {
      const result = await this.runner.run({
        executable,
        stage: "preview-subtitle-probe",
        args: [
          "-v",
          "quiet",
          "-print_format",
          "json",
          "-show_entries",
          "stream=index,codec_type",
          ffmpegPath(filePath),
        ],
      });
      if (result.code === 0) {
        const parsed = JSON.parse(result.stdout) as SubtitleProbeOutput;
        indices = (parsed.streams ?? [])
          .filter((stream) => stream.codec_type === "subtitle")
          .map((stream) => Number(stream.index))
          .filter((value) => Number.isInteger(value));
      }
    } catch {
      indices = [];
    }
    this.subtitleIndexCache.set(filePath, { at: Date.now(), indices });
    return [...indices];
  }
}

export const previewService = new PreviewService();
