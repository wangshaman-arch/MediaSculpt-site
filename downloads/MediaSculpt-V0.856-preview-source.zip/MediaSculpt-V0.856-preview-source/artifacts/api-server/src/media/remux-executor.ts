import fs from "node:fs/promises";
import { jobToolExecutor } from "../application/job-tool-executor";
import type { RemuxCommandPlan } from "./remux-pipeline";

export interface RemuxProcessExecutor {
  run(input: {
    jobId: number;
    executable: string;
    args: readonly string[];
    outputPath: string;
  }): Promise<{ stdout: string; stderr: string }>;
}

const defaultProcesses: RemuxProcessExecutor = {
  run: ({ jobId, executable, args }) =>
    jobToolExecutor.run(jobId, executable, [...args]),
};

export async function executeRemuxPlan(input: {
  jobId: number;
  plan: RemuxCommandPlan;
  processes?: RemuxProcessExecutor;
}): Promise<{ fileSize: number; stdout: string; stderr: string }> {
  const processes = input.processes ?? defaultProcesses;
  await fs.rm(input.plan.outputPath, { force: true }).catch(() => {});
  try {
    const result = await processes.run({
      jobId: input.jobId,
      executable: input.plan.executable,
      args: input.plan.args,
      outputPath: input.plan.outputPath,
    });
    const stat = await fs.stat(input.plan.outputPath).catch(() => null);
    if (!stat?.isFile() || stat.size <= 0)
      throw new Error("Remux 命令完成但未生成有效输出");
    return {
      fileSize: stat.size,
      stdout: result.stdout,
      stderr: result.stderr,
    };
  } catch (error) {
    await fs.rm(input.plan.outputPath, { force: true }).catch(() => {});
    throw error;
  }
}
