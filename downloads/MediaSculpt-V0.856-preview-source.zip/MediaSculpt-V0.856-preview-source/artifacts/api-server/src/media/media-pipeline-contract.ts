import type { MediaSourceKind } from "./media-source";

export type MediaPipelineStreamType = "video" | "audio" | "subtitle";

export type MediaPipelineStream = {
  id: string;
  index: number;
  type: MediaPipelineStreamType;
  codec: string | null;
  language?: string | null;
  title?: string | null;
  handbrakeTrackNumber?: number | null;
  /** Raw audio bit depth; DVD `pcm_dvd` needs it to pick `pcm_s16le` vs `pcm_s24le`. */
  bitsPerRawSample?: number | null;
};

export type MediaPipelineChapter = {
  id: number;
  startSeconds: number;
  endSeconds: number;
  title: string | null;
};

export type MediaPipelineInput = {
  source: {
    kind: MediaSourceKind;
    path: string;
    fingerprint: string;
    /** Physical source size only; it is never used as the output size. */
    physicalBytes: number | null;
  };
  title: {
    id: string;
    titleNumber: number | null;
    durationSeconds: number | null;
    streams: readonly MediaPipelineStream[];
    chapters: readonly MediaPipelineChapter[];
  };
  selection: {
    streamIds: readonly string[];
    chapterIds: readonly number[];
  };
  output: {
    mode: "remux" | "compress" | "subtitle";
    directory: string;
    fileName: string;
    estimatedBytes?: number | null;
  };
};

export type MediaPipelineManifest = Readonly<{
  manifestVersion: 1;
  source: Readonly<MediaPipelineInput["source"]>;
  title: Readonly<MediaPipelineInput["title"]>;
  selection: Readonly<{
    streamIds: readonly string[];
    videoStreamIds: readonly string[];
    audioStreamIds: readonly string[];
    subtitleStreamIds: readonly string[];
    chapterIds: readonly number[];
  }>;
  output: Readonly<{
    mode: MediaPipelineInput["output"]["mode"];
    directory: string;
    fileName: string;
    estimatedBytes: number | null;
  }>;
}>;

function freeze<T extends object>(value: T): Readonly<T> {
  return Object.freeze(value);
}

function requireText(value: string, label: string): string {
  const normalized = value.trim();
  if (!normalized) throw new Error(`${label}不能为空`);
  return normalized;
}

function normalizeNonNegative(
  value: number | null,
  label: string,
): number | null {
  if (value === null) return null;
  if (!Number.isFinite(value) || value < 0) throw new Error(`${label}无效`);
  return value;
}

function unique<T>(values: readonly T[], label: string): T[] {
  const result = [...values];
  if (new Set(result).size !== result.length)
    throw new Error(`${label}不能重复`);
  return result;
}

export function createMediaPipelineManifest(
  input: MediaPipelineInput,
): MediaPipelineManifest {
  const source = freeze({
    kind: input.source.kind,
    path: requireText(input.source.path, "来源路径"),
    fingerprint: requireText(input.source.fingerprint, "来源指纹"),
    physicalBytes: normalizeNonNegative(
      input.source.physicalBytes,
      "物理源容量",
    ),
  });
  const titleId = requireText(input.title.id, "标题 ID");
  const streams = input.title.streams.map((stream) =>
    freeze({
      id: requireText(stream.id, "流轨 ID"),
      index: stream.index,
      type: stream.type,
      codec: stream.codec ?? null,
      language: stream.language ?? null,
      title: stream.title ?? null,
      handbrakeTrackNumber: stream.handbrakeTrackNumber ?? null,
      bitsPerRawSample: stream.bitsPerRawSample ?? null,
    }),
  );
  const chapters = input.title.chapters.map((chapter) =>
    freeze({
      id: chapter.id,
      startSeconds: chapter.startSeconds,
      endSeconds: chapter.endSeconds,
      title: chapter.title ?? null,
    }),
  );
  const streamsById = new Map(streams.map((stream) => [stream.id, stream]));
  const chaptersById = new Map(
    chapters.map((chapter) => [chapter.id, chapter]),
  );
  const streamIds = unique(input.selection.streamIds, "流轨选择");
  const chapterIds = unique(input.selection.chapterIds, "章节选择");
  const selectedStreams = streamIds.map((id) => {
    const stream = streamsById.get(id);
    if (!stream) throw new Error(`选择了不存在的流轨：${id}`);
    return stream;
  });
  for (const id of chapterIds) {
    if (!chaptersById.has(id)) throw new Error(`选择了不存在的章节：${id}`);
  }
  if (!selectedStreams.some((stream) => stream.type === "video")) {
    throw new Error("至少选择一个视频流");
  }
  const selectedVideoStreamIds = selectedStreams
    .filter((stream) => stream.type === "video")
    .map((stream) => stream.id);
  const selectedAudioStreamIds = selectedStreams
    .filter((stream) => stream.type === "audio")
    .map((stream) => stream.id);
  const selectedSubtitleStreamIds = selectedStreams
    .filter((stream) => stream.type === "subtitle")
    .map((stream) => stream.id);
  const title = freeze({
    id: titleId,
    titleNumber: input.title.titleNumber,
    durationSeconds: normalizeNonNegative(
      input.title.durationSeconds,
      "标题时长",
    ),
    streams: freeze(streams),
    chapters: freeze(chapters),
  });
  const selection = freeze({
    streamIds: freeze(streamIds),
    videoStreamIds: freeze(selectedVideoStreamIds),
    audioStreamIds: freeze(selectedAudioStreamIds),
    subtitleStreamIds: freeze(selectedSubtitleStreamIds),
    chapterIds: freeze(chapterIds),
  });
  const output = freeze({
    mode: input.output.mode,
    directory: requireText(input.output.directory, "输出目录"),
    fileName: requireText(input.output.fileName, "输出文件名"),
    estimatedBytes: normalizeNonNegative(
      input.output.estimatedBytes ?? null,
      "输出大小估计",
    ),
  });
  return freeze({
    manifestVersion: 1 as const,
    source,
    title,
    selection,
    output,
  });
}
