import { describe, expect, it } from "vitest";
import {
  createMediaPipelineManifest,
  type MediaPipelineInput,
} from "./media-pipeline-contract";
import { buildRemuxCommandPlan } from "./remux-pipeline";

function manifest(kind: "dvd" | "bluray" = "dvd") {
  const input: MediaPipelineInput = {
    source: {
      kind,
      path: kind === "dvd" ? "D:\\DVD" : "D:\\BDMV",
      fingerprint: `${kind}-v1`,
      physicalBytes: 25_000_000_000,
    },
    title: {
      id: kind === "dvd" ? "handbrake:7" : "mpls:00800",
      titleNumber: kind === "dvd" ? 7 : null,
      durationSeconds: 5_400,
      streams: [
        {
          id: "video:0",
          index: 0,
          type: "video",
          codec: kind === "dvd" ? "mpeg2video" : "h264",
        },
        {
          id: "audio:1",
          index: 1,
          type: "audio",
          codec: "ac3",
          language: "en",
        },
        {
          id: "subtitle:2",
          index: 2,
          type: "subtitle",
          codec: kind === "dvd" ? "dvd_subtitle" : "hdmv_pgs_subtitle",
          language: "en",
        },
      ],
      chapters: [
        { id: 1, startSeconds: 0, endSeconds: 2_700, title: "Part 1" },
        { id: 2, startSeconds: 2_700, endSeconds: 5_400, title: "Part 2" },
      ],
    },
    selection: {
      streamIds: ["video:0", "audio:1", "subtitle:2"],
      chapterIds: [1, 2],
    },
    output: { mode: "remux", directory: "D:\\Output", fileName: "Movie.mkv" },
  };
  return createMediaPipelineManifest(input);
}

describe("Remux command planner", () => {
  it("plans DVD title navigation with selected streams and all selected chapters", () => {
    const plan = buildRemuxCommandPlan({
      manifest: manifest("dvd"),
      executable: "ffmpeg.exe",
      inputMode: "dvd-navigation",
    });

    // The DVD branch passes the caller-resolved input path through verbatim so
    // the command matches the legacy route byte for byte (no separator rewrite).
    expect(plan.args).toEqual(
      expect.arrayContaining([
        "-f",
        "dvdvideo",
        "-title",
        "7",
        "-i",
        "D:\\DVD",
        // Absolute-index maps: video 0, audio 1, subtitle 2.
        "-map",
        "0:0",
        "-map",
        "0:1",
        "-map",
        "0:2",
        "-map_chapters",
        "0",
        "-c",
        "copy",
        "D:\\Output\\Movie.mkv",
      ]),
    );
    expect(plan.expected).toEqual({
      video: 1,
      audio: 1,
      subtitle: 1,
      chapters: 2,
      durationSeconds: 5_400,
    });
  });

  it("places DVD chapter metadata input before output mapping options", () => {
    const plan = buildRemuxCommandPlan({
      manifest: manifest("dvd"),
      executable: "ffmpeg.exe",
      inputMode: "dvd-navigation",
      chapterMetadataPath: "C:\\Temp\\chapters.ffmeta",
    });
    const args = [...plan.args];
    const metadataInput = args.indexOf("C:/Temp/chapters.ffmeta");
    const firstMap = args.indexOf("-map");
    expect(metadataInput).toBeGreaterThan(args.indexOf("-i"));
    expect(metadataInput).toBeLessThan(firstMap);
    expect(args).toEqual(
      expect.arrayContaining(["-map_metadata", "1", "-map_chapters", "1"]),
    );
  });

  it("plans a Blu-ray playlist concat with selected chapter metadata", () => {
    const plan = buildRemuxCommandPlan({
      manifest: manifest("bluray"),
      executable: "ffmpeg.exe",
      inputMode: "concat",
      concatListPath: "C:\\Temp\\playlist.ffconcat",
      chapterMetadataPath: "C:\\Temp\\chapters.ffmeta",
    });

    expect(plan.args).toEqual(
      expect.arrayContaining([
        "-f",
        "concat",
        "-safe",
        "0",
        "-i",
        "C:/Temp/playlist.ffconcat",
        "-i",
        "C:\\Temp\\chapters.ffmeta",
        "-map_chapters",
        "1",
        "-dn",
        "-ignore_unknown",
        "-avoid_negative_ts",
        "make_zero",
        "-map",
        "0:0",
        "-c:v",
        "copy",
        "-map",
        "0:1",
        "-c:a:0",
        "copy",
        "-map",
        "0:2",
        "-c:s",
        "copy",
        "-fflags",
        "+genpts",
        "-y",
        "D:\\Output\\Movie.mkv",
      ]),
    );
  });

  it("converts selected pcm_bluray audio to pcm_s24le so Matroska can be written", () => {
    const input: MediaPipelineInput = {
      source: {
        kind: "bluray",
        path: "D:\\BDMV",
        fingerprint: "bd-pcm",
        physicalBytes: 25_000_000_000,
      },
      title: {
        id: "mpls:00000",
        titleNumber: null,
        durationSeconds: 5_400,
        streams: [
          { id: "video:0", index: 0, type: "video", codec: "h264" },
          { id: "audio:1", index: 1, type: "audio", codec: "pcm_bluray" },
          { id: "audio:2", index: 2, type: "audio", codec: "dts" },
        ],
        chapters: [],
      },
      selection: {
        streamIds: ["video:0", "audio:1", "audio:2"],
        chapterIds: [],
      },
      output: { mode: "remux", directory: "D:\\Output", fileName: "Movie.mkv" },
    };
    const plan = buildRemuxCommandPlan({
      manifest: createMediaPipelineManifest(input),
      executable: "ffmpeg.exe",
      inputMode: "file",
    });
    const joined = plan.args.join(" ");
    expect(joined).toContain("-c:a:0 pcm_s24le");
    // The DTS track is copied, not transcoded.
    expect(joined).toContain("-c:a:1 copy");
  });

  it("rejects a missing concat list instead of silently switching input mode", () => {
    expect(() =>
      buildRemuxCommandPlan({
        manifest: manifest("bluray"),
        executable: "ffmpeg.exe",
        inputMode: "concat",
      }),
    ).toThrow("缺少 concat 输入清单");
  });
});
