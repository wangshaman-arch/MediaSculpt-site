import path from "node:path";
import { describe, expect, it } from "vitest";
import type {
  DiscAnalysisStream,
  UnifiedDiscTitle,
} from "../lib/disc-analysis";
import { buildDvdRemuxArgs } from "../lib/dvd-remux";
import type { TaskSnapshotV1 } from "../lib/task-snapshot";
import { buildRemuxCommandPlan } from "./remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "./task-snapshot-manifest";

/**
 * Pre-switch safety net: the unified manifest + planner must reproduce the
 * legacy route's DVD Remux command byte for byte before `jobs.ts` is migrated.
 * Any divergence here is a real behavior change, not a refactor.
 */

const VIDEO_TS = "D:\\Rips\\Bonzo Dog Band disc 1\\VIDEO_TS";

function audioStream(
  codec: string,
  bitsPerRawSample: number | null,
): DiscAnalysisStream {
  return {
    index: 1,
    codecType: "audio",
    codecName: codec,
    language: "en",
    title: "English",
    handbrakeTrackNumber: 1,
    bitsPerRawSample,
  };
}

function title(audio: DiscAnalysisStream): UnifiedDiscTitle {
  return {
    titleId: "handbrake:1",
    titleIndex: 0,
    sourcePath: VIDEO_TS,
    displayName: "Bonzo Dog Band",
    durationSeconds: 4_878,
    chapterCount: 0,
    chapters: [],
    videoTracks: [
      {
        index: 0,
        codecType: "video",
        codecName: "mpeg2video",
        language: null,
        title: null,
      },
    ],
    audioTracks: [audio],
    subtitleTracks: [
      {
        index: 2,
        codecType: "subtitle",
        codecName: "dvd_subtitle",
        language: "en",
        title: null,
        handbrakeTrackNumber: 2,
      },
    ],
    estimatedSize: null,
    streams: [
      {
        index: 0,
        codecType: "video",
        codecName: "mpeg2video",
        language: null,
        title: null,
      },
      audio,
      {
        index: 2,
        codecType: "subtitle",
        codecName: "dvd_subtitle",
        language: "en",
        title: null,
        handbrakeTrackNumber: 2,
      },
    ],
    toolMappings: {
      handbrakeTitleNumber: 1,
      makemkvTitleIndex: null,
      playlistId: null,
      dvdVtsNumber: 7,
    },
    mappingStatus: "not-required",
  };
}

function snapshot(): TaskSnapshotV1 {
  return {
    snapshotVersion: 1,
    analysisId: "disc-bonzo",
    sourcePath: VIDEO_TS,
    sourceFingerprint: "dvd-fp-bonzo",
    sourceType: "dvd",
    selectedTitleId: "handbrake:1",
    outputMode: "remux",
    compressionSourceStrategy: "auto",
    toolSelections: {
      handbrakeTitleNumber: 1,
      makemkvTitleIndex: null,
      playlistId: null,
      dvdVtsNumber: 7,
      remuxExportCandidateIndex: null,
    },
    streamSelection: {
      videoTrackIds: ["stream:0"],
      audioTrackIds: ["stream:1"],
      subtitleTrackIds: ["stream:2"],
    },
    chapterSelection: { mode: "all", start: null, end: null, chapterIds: [] },
    remux: { container: "mkv" },
    compression: {
      encoder: "x265",
      crf: 20,
      resolution: "1080p",
      preset: "slow",
      audioCopy: true,
      frameRate: "same",
      outputFormat: "mkv",
      deinterlace: false,
    },
    whisper: { inputSource: "original-title", language: "zh", model: "medium" },
    output: {
      directory: "D:\\Output",
      fileName: "Bonzo Dog Band.mkv",
      format: "mkv",
      subtitleDirectory: null,
    },
    toolVersions: {
      handbrake: null,
      makemkv: null,
      ffmpeg: null,
      whisper: null,
      configVersion: "config-x",
    },
    createdAt: "2026-09-15T00:00:00.000Z",
  };
}

function legacyArgs(audio: DiscAnalysisStream): string[] {
  const s = snapshot();
  return buildDvdRemuxArgs({
    sourcePath: s.sourcePath,
    titleNumber: s.toolSelections.dvdVtsNumber!,
    selectedVideoStreams: [0],
    selectedAudioStreams: [1],
    selectedAudioCodecs: [
      {
        inputIndex: 1,
        codecName: audio.codecName,
        bitsPerRawSample: audio.bitsPerRawSample ?? null,
      },
    ],
    selectedSubtitleStreams: [2],
    outputPath: path.join(s.output.directory, s.output.fileName),
  });
}

function plannedArgs(audio: DiscAnalysisStream): string[] {
  const manifest = buildMediaPipelineManifestFromSnapshot({
    snapshot: snapshot(),
    title: title(audio),
  });
  return buildRemuxCommandPlan({
    manifest,
    executable: "ffmpeg.exe",
    inputMode: "dvd-navigation",
  }).args as string[];
}

describe("DVD Remux legacy/new command equivalence", () => {
  it("reproduces the legacy command byte for byte for AC-3 audio", () => {
    const audio = audioStream("ac3", null);
    expect(plannedArgs(audio)).toEqual(legacyArgs(audio));
  });

  it("preserves the pcm_dvd 24-bit lossless PCM conversion", () => {
    const audio = audioStream("pcm_dvd", 24);
    const planned = plannedArgs(audio);
    expect(planned).toEqual(legacyArgs(audio));
    // The 24-bit path must still select pcm_s24le, not the 16-bit default.
    expect(planned).toContain("pcm_s24le");
  });
});
