export type MediaSourceKind = "file" | "dvd" | "bluray" | "iso";

export interface MediaStream {
  index: number;
  codecType: "video" | "audio" | "subtitle" | "unknown";
  codecName: string | null;
  language?: string | null;
  title?: string | null;
}

export interface MediaChapter {
  id: number;
  startSeconds: number;
  endSeconds: number;
  title: string | null;
}

export interface MediaTitle {
  stableId: string;
  ordinal: number;
  sourceFile: string | null;
  sourceSizeBytes: number | null;
  missingInputs: readonly string[];
  durationSeconds: number | null;
  videoStreams: readonly MediaStream[];
  audioStreams: readonly MediaStream[];
  subtitleStreams: readonly MediaStream[];
  chapters: readonly MediaChapter[];
  orderedInputs: readonly string[];
}

export interface MediaSource {
  kind: MediaSourceKind;
  sourcePath: string;
  analysisPath?: string;
  titles: readonly MediaTitle[];
}

export class IncompleteMediaTitleError extends Error {
  readonly code = "MEDIA_TITLE_INCOMPLETE" as const;

  constructor(readonly missingInputs: readonly string[]) {
    super(
      `光盘文件不完整：缺少 ${missingInputs.join("、")}。请重新抓轨该 DVD，或改用完整的 ISO 镜像处理。`,
    );
    this.name = "IncompleteMediaTitleError";
  }
}
