import path from "node:path";
import type { UnifiedDiscTitle } from "../lib/disc-analysis";
import type { HandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import type { TaskSnapshotV1 } from "../lib/task-snapshot";
import {
  buildHandBrakeCompressionArgs,
  buildHandBrakeCompressionArgsFromManifest,
  type BuiltHandBrakeCompressionArgs,
  type HandBrakeCompressionConfig,
} from "./compression-service";
import { buildMediaPipelineManifestFromSnapshot } from "./task-snapshot-manifest";

export type CompressionArgsForJobInput = {
  snapshot: TaskSnapshotV1 | null;
  title: UnifiedDiscTitle | null;
  inputPath: string;
  outputPath: string;
  config: HandBrakeCompressionConfig;
  selectionPlan: HandBrakeSelectionPlan | null;
  deinterlace: boolean;
  /** True only when inputPath is the verified direct-disc source. */
  useManifest: boolean;
};

export type CompressionArgsForJobResult = BuiltHandBrakeCompressionArgs & {
  usedManifest: boolean;
};

/**
 * Build compression arguments from the immutable task selection when the
 * caller has verified that the input is still the direct disc source. Legacy
 * jobs and Remux-output pipelines retain the old builder until their source
 * mappings can be represented without guessing.
 */
export function buildCompressionArgsForJob(
  input: CompressionArgsForJobInput,
): CompressionArgsForJobResult {
  if (input.useManifest) {
    if (!input.snapshot || !input.title) {
      throw new Error("压缩清单模式需要完整任务快照和已验证标题");
    }
    const manifest = buildMediaPipelineManifestFromSnapshot({
      snapshot: input.snapshot,
      title: input.title,
      selectionPlan: null,
      sourcePath: input.inputPath,
    });
    const normalizedManifest = Object.freeze({
      ...manifest,
      output: Object.freeze({
        ...manifest.output,
        directory: path.dirname(input.outputPath),
        fileName: path.basename(input.outputPath),
      }),
    });
    return {
      ...buildHandBrakeCompressionArgsFromManifest({
        manifest: normalizedManifest,
        config: input.config,
        deinterlace: input.deinterlace,
      }),
      usedManifest: true,
    };
  }

  return {
    ...buildHandBrakeCompressionArgs({
      inputPath: input.inputPath,
      outputPath: input.outputPath,
      config: input.config,
      selectionPlan: input.selectionPlan,
      deinterlace: input.deinterlace,
    }),
    usedManifest: false,
  };
}
