#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
export NODE_ENV="${NODE_ENV:-development}"
export DATABASE_DRIVER="${DATABASE_DRIVER:-sqlite}"
# Native source mode only. Tauri owns the API sidecar and the single desktop
# window; no browser tab or second service supervisor is started here.
export PORT="${PORT:-5173}"
export API_PORT="${API_PORT:-18080}"
export MEDIASCULPT_NATIVE_SOURCE="1"
cd "$ROOT_DIR/desktop-tauri"
exec pnpm exec tauri dev
