# MediaSculpt 第三方组件说明

> **Version:** V 0.856 · 版本：V 0.856
MediaSculpt 本身是专有软件。下列组件可能随 Windows 基础安装器提供，或由软件的工具管理器按用户选择下载和管理；它们各自适用原许可证。重新分发具体组件时，应一并保留其原始许可证、版权和源代码获取信息（如许可证要求）。

## 当前运行时组件

- Tauri 2：桌面窗口和原生宿主，Apache-2.0 / MIT，具体依赖以对应发行包为准。
- Node.js：本地 API 侧车运行时，MIT license。
- React、Vite、TypeScript 及 `pnpm-lock.yaml` 中的 JavaScript 依赖：依各自许可证执行。
- FFmpeg / FFprobe：本地媒体探测、提取、无损封装和转码；构建配置及 GPL/LGPL 义务须按实际分发二进制核验。
- HandBrakeCLI：本地视频压缩；按其 GPLv2 及随包许可证说明执行。
- Whisper / faster-whisper 运行时和模型：本地语音识别；运行时、模型和模型权利分别按各自说明执行。
- Tesseract OCR、RapidOCR 及其语言数据：本地图形字幕识别；按各自许可证和数据包说明执行。
- LibreTranslate：可选的本地字幕翻译服务；只有用户启用并安装时使用。

## 许可证核验

发布具体安装器时，应对实际打入安装器的二进制、模型、语言数据和 JavaScript 依赖生成逐项清单，并保留对应许可证文件。本文是产品级说明，不替代具体组件的许可证文本。
