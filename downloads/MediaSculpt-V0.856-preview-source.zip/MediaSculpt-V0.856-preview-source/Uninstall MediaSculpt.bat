@echo off
title MediaSculpt uninstaller
cd /d "%~dp0"

echo MediaSculpt uninstaller
echo.
echo 1. only uninstall software
echo 2. clear download cache
echo 3. remove local tools
echo 4. complete uninstall
echo.
set /p VX_UNINSTALL_CHOICE=Choose 1-4:

set "MODE=software"
if "%VX_UNINSTALL_CHOICE%"=="2" set "MODE=cache"
if "%VX_UNINSTALL_CHOICE%"=="3" set "MODE=tools"
if "%VX_UNINSTALL_CHOICE%"=="4" set "MODE=all"

if "%MODE%"=="all" (
  echo.
  echo Complete uninstall removes software marker, cache, tools, and local data.
  set /p VX_CONFIRM=Type YES to continue:
  if /i not "%VX_CONFIRM%"=="YES" (
    echo Cancelled.
    pause
    exit /b 0
  )
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows-setup\stop-services.ps1" >nul 2>&1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows-setup\uninstall.ps1" -Mode "%MODE%"
set "EXITCODE=%errorlevel%"
echo.
echo Uninstaller finished with code %EXITCODE%.
if "%EXITCODE%"=="0" if "%MODE%"=="software" goto schedule_project_delete
if "%EXITCODE%"=="0" if "%MODE%"=="all" goto schedule_project_delete
pause
exit /b %EXITCODE%

:schedule_project_delete
echo The software folder will be removed after this window closes.
set "VX_PROJECT_DIR=%~dp0"
start "" /min cmd /d /c "ping 127.0.0.1 -n 3 >nul & rmdir /s /q \"%VX_PROJECT_DIR%\""
exit /b 0
