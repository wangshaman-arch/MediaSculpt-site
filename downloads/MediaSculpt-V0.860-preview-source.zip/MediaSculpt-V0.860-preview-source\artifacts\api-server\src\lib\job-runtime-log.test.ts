import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { afterEach, describe, expect, it } from "vitest";
import { appendJobRuntimeLog, jobRuntimeLogPath } from "./job-runtime-log";

const originalLogPath = process.env.VX_AGENT_JOB_LOG_PATH;
const originalDiagnosticsLogPath = process.env.VX_AGENT_DIAGNOSTICS_LOG;
const originalServiceLogDir = process.env.VX_AGENT_SERVICE_LOG_DIR;

afterEach(() => {
  if (originalLogPath === undefined) delete process.env.VX_AGENT_JOB_LOG_PATH;
  else process.env.VX_AGENT_JOB_LOG_PATH = originalLogPath;
  if (originalDiagnosticsLogPath === undefined)
    delete process.env.VX_AGENT_DIAGNOSTICS_LOG;
  else process.env.VX_AGENT_DIAGNOSTICS_LOG = originalDiagnosticsLogPath;
  if (originalServiceLogDir === undefined)
    delete process.env.VX_AGENT_SERVICE_LOG_DIR;
  else process.env.VX_AGENT_SERVICE_LOG_DIR = originalServiceLogDir;
});

describe("job runtime log", () => {
  it("defaults job diagnostics into a service log that avoids locking the upload diagnostics file", () => {
    delete process.env.VX_AGENT_JOB_LOG_PATH;
    delete process.env.VX_AGENT_DIAGNOSTICS_LOG;

    expect(path.basename(jobRuntimeLogPath())).toBe("job-events.tmp.log");
  });

  it("uses the service log directory when the job-specific path is not set", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-job-log-"));
    delete process.env.VX_AGENT_JOB_LOG_PATH;
    process.env.VX_AGENT_SERVICE_LOG_DIR = dir;

    expect(jobRuntimeLogPath()).toBe(path.join(dir, "job-events.tmp.log"));
  });

  it("writes remux execution details to the configured diagnostics log file", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-job-log-"));
    const file = path.join(dir, "job-events.tmp.log");
    const diagnosticsFile = path.join(dir, "vx-agent-diagnostics.log");
    process.env.VX_AGENT_JOB_LOG_PATH = file;
    process.env.VX_AGENT_DIAGNOSTICS_LOG = diagnosticsFile;

    await appendJobRuntimeLog(7, "info", "ffmpeg 参数: sample");

    expect(jobRuntimeLogPath()).toBe(file);
    await expect(fs.readFile(file, "utf8")).resolves.toContain(
      "job=7 level=info ffmpeg 参数: sample",
    );
    await expect(fs.readFile(diagnosticsFile, "utf8")).resolves.toContain(
      "===== JOB 7 INFO =====",
    );
  });

  it("writes complete external tool output as a structured job record", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-job-log-output-"));
    const diagnosticsFile = path.join(dir, "vx-agent-diagnostics.log");
    process.env.VX_AGENT_JOB_LOG_PATH = path.join(dir, "job-events.tmp.log");
    process.env.VX_AGENT_DIAGNOSTICS_LOG = diagnosticsFile;

    const { appendJobToolOutput } = await import("./job-runtime-log");
    await appendJobToolOutput(11, {
      tool: "HandBrakeCLI",
      executable: "C:\\Tools\\HandBrakeCLI.exe",
      args: ["-i", "C:\\DVD Folder\\VIDEO_TS", "--title", "2"],
      exitCode: 3,
      durationMs: 1234,
      stdout: "scan output",
      stderr: "fatal dvd error",
    });

    const content = await fs.readFile(diagnosticsFile, "utf8");
    expect(content).toContain("===== JOB 11 TOOL HANDBRAKECLI =====");
    expect(content).toContain("exitCode=3");
    expect(content).toContain("fatal dvd error");
    expect(content).toContain('"--title","2"');
  });
});
