// Extracted from smart-workflow.ts: compression / subtitle decision policy.
import path from "node:path";
import {
  bitDepthTag,
  buildRemuxOutputName,
  encoderBitDepth,
  normalizeAudioCodec,
  resolutionTag,
  selectBestAudioTrack,
} from "./output-naming";
import { logicValue, type CustomTuningLogic } from "./custom-tuning";
import {
  lower,
  isTextSubtitle,
  isGraphicSubtitle,
  isChinese,
  chooseMainAudio,
  type SmartWorkflowStream,
  type SmartWorkflowMediaInput,
  type CompressionDecision,
  type SubtitleDecision,
} from "./smart-workflow";

export function decideCompression(
  input: Pick<
    SmartWorkflowMediaInput,
    "streams" | "sizeBytes" | "durationSeconds" | "displayName"
  > & { mediaType?: "movie" | "tv" | null },
  tuning?: CustomTuningLogic,
): CompressionDecision {
  // 触发基准（可在“设置 → 自定义调优”中调整）：
  // - 电视纪录片：折合 50 分钟体积 > X GB 触发压缩（H.265 按比例下调）
  // - 电影：整部绝对体积 > Y GB 触发压缩
  const DOCUMENTARY_TRIGGER_BYTES_PER_50_MIN =
    logicValue(tuning, "documentaryGbPer50min", 2) * 1_000_000_000;
  const MOVIE_TRIGGER_BYTES = logicValue(tuning, "movieGb", 8) * 1_000_000_000;
  const H265_TRIGGER_REDUCTION = logicValue(tuning, "h265Ratio", 0.7);
  const MIN_CLIP_SECONDS = logicValue(tuning, "minClipMinutes", 5) * 60;

  const video = input.streams.find((stream) => stream.type === "video");
  const codec = lower(video?.codec);
  const bitrate = Number(video?.bitrate ?? 0);
  const duration = Number(input.durationSeconds ?? 0);
  const size = Number(input.sizeBytes ?? 0);
  const isMovie = input.mediaType === "movie";
  const isTv = input.mediaType === "tv";
  const isH265 = ["hevc", "h265"].includes(codec);
  const isEfficientVideoCodec = [
    "h264",
    "avc",
    "avc1",
    "hevc",
    "h265",
    "vp9",
    "av1",
  ].includes(codec);
  const explicitVideoBitrate = bitrate > 0 ? bitrate : 0;
  const bitsPerSecondFromSize =
    duration > 0 && size > 0 ? (size * 8) / duration : 0;
  const effectiveBitrate = Math.max(bitrate, bitsPerSecondFromSize);
  const sizePer50Min = duration > 0 && size > 0 ? size * (50 / duration) : 0;
  const name = lower(input.displayName ?? "");
  const isDocumentary =
    /documentary|纪录片|docu|nature|历史|自然|science|科学|bbc|pbs/i.test(name);

  // Short clips / samples never trigger compression.
  if (duration > 0 && duration < MIN_CLIP_SECONDS) {
    return {
      recommendation: "do-not-compress",
      estimated: true,
      rationale: `短片/样片（< ${MIN_CLIP_SECONDS / 60} 分钟）不触发压缩决策，避免样例片被压缩；保留原文件。`,
      presetId: null,
      estimatedOutputBytes: null,
      documentary: isDocumentary,
    };
  }

  // A low-bitrate modern encode has already gone through a meaningful
  // compression decision. Re-encoding it usually loses detail without useful
  // savings, even when audio/container size crosses a broad capacity rule.
  // Legacy MPEG/DVD sources continue through the normal compression policy.
  if (
    isEfficientVideoCodec &&
    explicitVideoBitrate > 0 &&
    explicitVideoBitrate <= 6_000_000
  ) {
    return {
      recommendation: "do-not-compress",
      estimated: true,
      rationale: `源视频为高效编码且视频码率 ${(explicitVideoBitrate / 1_000_000).toFixed(2)}Mbps，不建议二次压缩；优先保留原视频或单独处理字幕。`,
      presetId: null,
      estimatedOutputBytes: null,
      documentary: isDocumentary,
    };
  }

  const docThreshold =
    DOCUMENTARY_TRIGGER_BYTES_PER_50_MIN *
    (isH265 ? H265_TRIGGER_REDUCTION : 1);
  const movieThreshold =
    MOVIE_TRIGGER_BYTES * (isH265 ? H265_TRIGGER_REDUCTION : 1);
  const docTriggered = sizePer50Min > 0 && sizePer50Min > docThreshold;
  const movieTriggered = size > 0 && size > movieThreshold;
  // 未知类型同时按两个基准判定，任一超线即触发，避免长片被时长归一化误判为小体积。
  const triggered = isMovie
    ? movieTriggered
    : isTv
      ? docTriggered
      : docTriggered || movieTriggered;

  const standards: string[] = [];
  const measures: string[] = [];
  const docStandardGb =
    (DOCUMENTARY_TRIGGER_BYTES_PER_50_MIN *
      (isH265 ? H265_TRIGGER_REDUCTION : 1)) /
    1_000_000_000;
  const movieStandardGb =
    (MOVIE_TRIGGER_BYTES * (isH265 ? H265_TRIGGER_REDUCTION : 1)) /
    1_000_000_000;
  if (!isMovie)
    standards.push(`纪录片基准 ${docStandardGb.toFixed(1)}GB/50分钟`);
  if (!isTv) standards.push(`电影基准 ${movieStandardGb.toFixed(1)}GB/部`);
  if (isMovie)
    measures.push(size > 0 ? `${(size / 1_000_000_000).toFixed(2)}GB` : "未知");
  if (!isMovie)
    measures.push(
      sizePer50Min > 0
        ? `${(sizePer50Min / 1_000_000_000).toFixed(2)}GB/50分钟`
        : "未知",
    );
  const standardLabel = standards.join("或");
  const measureLabel = measures.join("，");

  // Capacity-based output estimate: target capacity × time ratio (documentary
  // uses the 2GB/50min rate; movie uses a flat 8GB), reduced 30% for H.265.
  const targetCapacityBytes = isMovie
    ? MOVIE_TRIGGER_BYTES
    : duration > 0
      ? Math.round((duration / 3000) * DOCUMENTARY_TRIGGER_BYTES_PER_50_MIN)
      : null;
  const estimateBytes =
    targetCapacityBytes != null
      ? Math.round(targetCapacityBytes * (isH265 ? H265_TRIGGER_REDUCTION : 1))
      : null;
  const estimateLabel =
    estimateBytes != null
      ? `${(estimateBytes / 1_000_000_000).toFixed(2)}GB`
      : "未知";

  if (!triggered) {
    return {
      recommendation: "do-not-compress",
      estimated: true,
      rationale: `按${standardLabel}核算（${measureLabel}），未超过触发线，默认不压缩；进入字幕/语音处理，压缩 preset 跳过。`,
      presetId: null,
      estimatedOutputBytes: null,
      documentary: isDocumentary,
    };
  }
  if (isH265) {
    return {
      recommendation: "optional-compress",
      estimated: true,
      rationale: `体积超过${standardLabel}（${measureLabel}）；H.265 已属高效编码，仅在需要观看版时压缩。预计输出 ≈ ${estimateLabel}（按容量模型折算）。`,
      presetId: null,
      estimatedOutputBytes: estimateBytes,
      documentary: isDocumentary,
    };
  }
  if (["mpeg2video", "mpeg1video", "mpeg4", "msmpeg4", "vc1"].includes(codec)) {
    return {
      recommendation: "recommend-compress",
      estimated: true,
      rationale: `体积超过${standardLabel}（${measureLabel}），且使用低效编码，适合生成收藏级 H.264 10bit 观看版。预计输出 ≈ ${estimateLabel}。`,
      presetId: null,
      estimatedOutputBytes: estimateBytes,
      documentary: isDocumentary,
    };
  }
  if (effectiveBitrate >= 6_000_000) {
    return {
      recommendation: "recommend-compress",
      estimated: true,
      rationale: `体积超过${standardLabel}（${measureLabel}）且码率较高，适合压缩。预计输出 ≈ ${estimateLabel}。`,
      presetId: null,
      estimatedOutputBytes: estimateBytes,
      documentary: isDocumentary,
    };
  }
  return {
    recommendation: "optional-compress",
    estimated: true,
    rationale: `体积超过${standardLabel}（${measureLabel}），建议由用户确认压缩方案。预计输出 ≈ ${estimateLabel}。`,
    presetId: null,
    estimatedOutputBytes: estimateBytes,
    documentary: isDocumentary,
  };
}

export function decideSubtitlePlan(
  streams: SmartWorkflowStream[],
  targetLanguage = "zh-CN",
  externalSubtitles: Array<{
    path: string;
    hasChinese: boolean;
    language?: string | null;
  }> = [],
): SubtitleDecision {
  const externalChinese = externalSubtitles.find(
    (subtitle) => subtitle.hasChinese,
  );
  if (externalChinese) {
    return {
      mode: "keep",
      runWhisper: false,
      runOcr: false,
      translate: false,
      sourceSubtitleId: null,
      sourceAudioId: null,
      sourceLanguage: externalChinese.language ?? "chi",
      targetLanguage,
      rationale:
        "目录中已检测到包含中文的外置字幕，默认保留，不进入语音识别或字幕翻译。",
    };
  }
  const subtitles = streams.filter((stream) => stream.type === "subtitle");
  const chineseText = subtitles.find(
    (stream) => isTextSubtitle(stream) && isChinese(stream.language),
  );
  if (chineseText) {
    return {
      mode: "keep",
      runWhisper: false,
      runOcr: false,
      translate: false,
      sourceSubtitleId: chineseText.id,
      sourceAudioId: null,
      sourceLanguage: chineseText.language ?? null,
      targetLanguage,
      rationale: "已存在中文字幕，默认保留且不重复识别。",
    };
  }
  const foreignText = subtitles.find((stream) => isTextSubtitle(stream));
  if (foreignText) {
    return {
      mode: "translate-text",
      runWhisper: false,
      runOcr: false,
      translate: true,
      sourceSubtitleId: foreignText.id,
      sourceAudioId: null,
      sourceLanguage: foreignText.language ?? null,
      targetLanguage,
      rationale: "已有外语文本字幕，直接翻译，不运行 Whisper。",
    };
  }
  const graphic = subtitles.find((stream) => isGraphicSubtitle(stream));
  if (graphic) {
    return {
      mode: "ocr-graphic",
      runWhisper: false,
      runOcr: true,
      translate: true,
      sourceSubtitleId: graphic.id,
      sourceAudioId: null,
      sourceLanguage: graphic.language ?? null,
      targetLanguage,
      rationale: "图形字幕优先 OCR、纠错和翻译；原始图形字幕继续保留。",
    };
  }
  const audio = chooseMainAudio(streams);
  if (audio) {
    return {
      mode: "whisper",
      runWhisper: true,
      runOcr: false,
      translate: true,
      sourceSubtitleId: null,
      sourceAudioId: audio.id,
      sourceLanguage: audio.language ?? null,
      targetLanguage,
      rationale: "没有可用文本字幕，绑定主音轨生成原文并翻译。",
    };
  }
  return {
    mode: "none",
    runWhisper: false,
    runOcr: false,
    translate: false,
    sourceSubtitleId: null,
    sourceAudioId: null,
    sourceLanguage: null,
    targetLanguage,
    rationale: "没有可用字幕或主音轨，暂不生成字幕。",
  };
}

/**
 * Decide the automatic subtitle route without creating a second executor.
 * The returned IDs are consumed by the existing task/Whisper/translation
 * pipeline after the user confirms the plan. External files have priority,
 * then text subtitles, and only then the main audio track.
 */
export type AutomaticSubtitleStrategy =
  | "external-translate"
  | "embedded-extract-translate"
  | "whisper-original-translate"
  | "none";

export type AutomaticSubtitleDecision = {
  strategy: AutomaticSubtitleStrategy;
  sourcePath: string | null;
  sourceSubtitleId: string | null;
  sourceAudioId: string | null;
  runWhisper: boolean;
  preserveOriginal: boolean;
  translate: boolean;
  targetLanguage: string;
  rationale: string;
};

export function decideAutomaticSubtitleStrategy(input: {
  streams: SmartWorkflowStream[];
  externalSubtitleFiles?: string[];
  targetLanguage?: string;
}): AutomaticSubtitleDecision {
  const targetLanguage = input.targetLanguage ?? "zh-CN";
  const externalPath =
    input.externalSubtitleFiles?.find((value) => value.trim().length > 0) ??
    null;
  if (externalPath) {
    return {
      strategy: "external-translate",
      sourcePath: externalPath,
      sourceSubtitleId: null,
      sourceAudioId: null,
      runWhisper: false,
      preserveOriginal: true,
      translate: true,
      targetLanguage,
      rationale: "目录中已有外置字幕，保留原字幕并交给现有 LLM 翻译链路。",
    };
  }

  const embedded = input.streams.find((stream) => stream.type === "subtitle");
  if (embedded) {
    return {
      strategy: "embedded-extract-translate",
      sourcePath: null,
      sourceSubtitleId: embedded.id,
      sourceAudioId: null,
      runWhisper: false,
      preserveOriginal: true,
      translate: true,
      targetLanguage,
      rationale:
        "未发现外置字幕，提取当前字幕轨并保留原文，再交给现有 LLM 翻译链路。",
    };
  }

  const audio = chooseMainAudio(input.streams);
  if (audio) {
    return {
      strategy: "whisper-original-translate",
      sourcePath: null,
      sourceSubtitleId: null,
      sourceAudioId: audio.id,
      runWhisper: true,
      preserveOriginal: true,
      translate: true,
      targetLanguage,
      rationale:
        "没有字幕，先从主音轨生成原语言字幕，再交给现有 LLM 翻译链路。",
    };
  }

  return {
    strategy: "none",
    sourcePath: null,
    sourceSubtitleId: null,
    sourceAudioId: null,
    runWhisper: false,
    preserveOriginal: false,
    translate: false,
    targetLanguage,
    rationale: "没有可用字幕或音轨，保持传统任务流程并明确跳过字幕处理。",
  };
}
