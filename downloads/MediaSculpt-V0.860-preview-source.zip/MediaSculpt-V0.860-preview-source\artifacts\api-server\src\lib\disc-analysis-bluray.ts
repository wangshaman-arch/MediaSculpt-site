// Extracted from disc-analysis.ts: Blu-ray disc scanning/probing and title analysis.
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs/promises";
import path from "node:path";
import {
  parseHandBrakeScanOutput,
  type HandBrakeTitle,
} from "./handbrake-scan";
import { scanBlurayPlaylists, type BlurayPlaylistInfo } from "./disc";
import { resolveToolPath } from "./tool-runtime";
import {
  safeNumber,
  consolidateDiscTitles,
  persistDiscAnalysisDiagnostics,
  buildDiscAnalysisId,
  type DiscAnalysisStream,
  type DiscToolDiagnostic,
  type UnifiedDiscTitle,
  type DiscAnalysisResult,
  type DiscAnalysisInput,
  type DiscPreviewSegment,
} from "./disc-analysis-shared";

const execFileAsync = promisify(execFile);
function buildBlurayPreviewSegments(
  playlist: BlurayPlaylistInfo,
): DiscPreviewSegment[] {
  let startSeconds = 0;
  return playlist.segments.flatMap((segment) => {
    const durationSeconds =
      Math.max(0, segment.outTime45k - segment.inTime45k) / 45_000;
    if (!Number.isFinite(durationSeconds) || durationSeconds <= 0) return [];
    const previewSegment = {
      sourcePath: segment.streamPath,
      startSeconds,
      endSeconds: startSeconds + durationSeconds,
    };
    startSeconds += durationSeconds;
    return [previewSegment];
  });
}

export function buildBlurayTitleDisplayName(input: {
  kind: "playlist" | "stream" | "handbrake";
  index: number;
  playlistId?: string | null;
  handbrakeTitleNumber?: number | null;
  streamFileName?: string | null;
}): string {
  const playlistId = input.playlistId?.trim() || null;
  if (input.kind === "playlist") {
    return playlistId ? `Playlist ${playlistId}` : `Title ${input.index + 1}`;
  }
  if (input.kind === "handbrake") {
    const title =
      input.handbrakeTitleNumber && input.handbrakeTitleNumber > 0
        ? `HandBrake Title ${input.handbrakeTitleNumber}`
        : `HandBrake Title ${input.index + 1}`;
    return playlistId ? `${title} · Playlist ${playlistId}` : title;
  }
  const streamMatch = /(?:^|[\\/])([0-9]{5})\.m2ts$/i.exec(
    input.streamFileName ?? "",
  );
  return streamMatch ? `M2TS ${streamMatch[1]}` : `M2TS ${input.index + 1}`;
}

export async function probeBlurayTitleStreams(
  ffprobe: string,
  playlist: BlurayPlaylistInfo,
): Promise<DiscAnalysisStream[]> {
  const samplePath = playlist.segments[0]?.streamPath;
  if (!samplePath) return [];
  return probeBlurayStreamFile(ffprobe, samplePath, playlist.durationSeconds);
}

async function probeBlurayStreamFile(
  ffprobe: string,
  streamPath: string,
  durationSeconds: number | null,
): Promise<DiscAnalysisStream[]> {
  try {
    const result = await execFileAsync(
      ffprobe,
      ["-v", "error", "-print_format", "json", "-show_streams", streamPath],
      {
        timeout: 30_000,
        maxBuffer: 16 * 1024 * 1024,
        windowsHide: true,
      },
    );
    const parsed = JSON.parse(String(result.stdout || "{}")) as {
      streams?: Array<Record<string, unknown>>;
    };
    const streams = (parsed.streams ?? []).flatMap((stream) => {
      const codecType =
        stream.codec_type === "video" ||
        stream.codec_type === "audio" ||
        stream.codec_type === "subtitle"
          ? (stream.codec_type as "video" | "audio" | "subtitle")
          : null;
      if (!codecType) return [];
      const tags = (stream.tags ?? {}) as Record<string, string>;
      const disposition = (stream.disposition ?? {}) as Record<string, unknown>;
      const bitrate = safeNumber(stream.bit_rate);
      return [
        {
          index: safeNumber(stream.index) ?? 0,
          codecType,
          codecName:
            typeof stream.codec_name === "string" ? stream.codec_name : null,
          ...(typeof stream.profile === "string" && stream.profile.trim()
            ? { profile: stream.profile.trim() }
            : {}),
          language: tags.language ?? null,
          title: tags.title ?? null,
          width: safeNumber(stream.width),
          height: safeNumber(stream.height),
          channels: safeNumber(stream.channels),
          channelLayout: typeof tags.layout === "string" ? tags.layout : null,
          sampleRate: safeNumber(stream.sample_rate),
          frameRate:
            typeof stream.avg_frame_rate === "string"
              ? stream.avg_frame_rate
              : null,
          bitrate,
          estimatedSizeBytes:
            bitrate && durationSeconds
              ? Math.round((bitrate * durationSeconds) / 8)
              : null,
          default: disposition.default === 1 || disposition.default === "1",
          forced: disposition.forced === 1 || disposition.forced === "1",
        },
      ];
    });
    // Drop true duplicates (same physical stream reported multiple times) so
    // the UI never shows two identical-looking tracks.
    const seen = new Set<string>();
    return streams.filter((stream) => {
      const signature = [
        stream.codecType,
        stream.codecName ?? "",
        stream.profile ?? "",
        stream.language ?? "",
        stream.channels ?? "",
        stream.channelLayout ?? "",
        stream.bitrate ?? "",
      ].join("|");
      if (seen.has(signature)) return false;
      seen.add(signature);
      return true;
    });
  } catch {
    return [];
  }
}

export async function probeBlurayStreamDuration(
  ffprobe: string,
  streamPath: string,
): Promise<number | null> {
  try {
    const result = await execFileAsync(
      ffprobe,
      ["-v", "error", "-print_format", "json", "-show_format", streamPath],
      {
        timeout: 30_000,
        maxBuffer: 4 * 1024 * 1024,
        windowsHide: true,
      },
    );
    const parsed = JSON.parse(String(result.stdout || "{}")) as {
      format?: { duration?: string | number };
    };
    return safeNumber(parsed.format?.duration);
  } catch {
    return null;
  }
}

/**
 * Fallback for Blu-ray discs whose BDMV/PLAYLIST entries contain no playable
 * PlayItems (e.g. subpath-only or partially authored discs).  In that case the
 * actual video lives in BDMV/STREAM/*.m2ts, so each m2ts file becomes a title.
 * Chapters are unknown for these titles; previews and single-file remux still work.
 */
export async function fallbackBlurayStreamTitles(
  discRoot: string,
  ffprobe: string | null,
): Promise<UnifiedDiscTitle[]> {
  const streamDir = path.join(discRoot, "BDMV", "STREAM");
  const entries = await fs.readdir(streamDir).catch(() => []);
  const files = entries.filter((name) => /\.m2ts$/i.test(name)).sort();
  const titles: UnifiedDiscTitle[] = [];
  for (const [index, name] of files.entries()) {
    const streamPath = path.join(streamDir, name);
    let durationSeconds: number | null = null;
    let streams: DiscAnalysisStream[] = [];
    if (ffprobe) {
      durationSeconds = await probeBlurayStreamDuration(ffprobe, streamPath);
      streams = await probeBlurayStreamFile(
        ffprobe,
        streamPath,
        durationSeconds,
      );
    }
    const stat = await fs.stat(streamPath).catch(() => null);
    // Each m2ts can be compressed directly with HandBrake as its own title 1,
    // and HandBrake numbers streams 1-based for a single-file input.
    const handbrakeStreams = streams.map((stream) => ({
      ...stream,
      handbrakeTrackNumber: stream.index + 1,
    }));
    titles.push({
      titleId: `m2ts:${path.basename(name, path.extname(name))}`,
      titleIndex: index,
      sourcePath: streamPath,
      titleKind: "m2ts",
      displayName: buildBlurayTitleDisplayName({
        kind: "stream",
        index,
        streamFileName: name,
      }),
      durationSeconds,
      chapterCount: 0,
      chapters: [],
      estimatedSize: stat?.size ?? null,
      streams: handbrakeStreams,
      videoTracks: handbrakeStreams.filter(
        (stream) => stream.codecType === "video",
      ),
      audioTracks: handbrakeStreams.filter(
        (stream) => stream.codecType === "audio",
      ),
      subtitleTracks: handbrakeStreams.filter(
        (stream) => stream.codecType === "subtitle",
      ),
      toolMappings: {
        handbrakeTitleNumber: 1,
        makemkvTitleIndex: null,
        dvdVtsNumber: null,
        playlistId: null,
      },
      mappingStatus: "not-required",
    });
  }
  return titles;
}

export async function scanBlurayWithHandBrake(
  discRoot: string,
  executable: string,
): Promise<{ titles: HandBrakeTitle[]; diagnostic: DiscToolDiagnostic }> {
  const startedAt = new Date();
  let stdout = "";
  let stderr = "";
  let exitCode: number | null = null;
  let failureReason: string | null = null;
  try {
    const result = await execFileAsync(
      executable,
      ["--input", discRoot, "--title", "0", "--scan", "--json"],
      {
        timeout: 10 * 60_000,
        maxBuffer: 32 * 1024 * 1024,
        windowsHide: true,
      },
    );
    stdout = String(result.stdout ?? "");
    stderr = String(result.stderr ?? "");
    exitCode = 0;
  } catch (error) {
    const err = error as {
      code?: unknown;
      stdout?: unknown;
      stderr?: unknown;
      message?: string;
    };
    exitCode = typeof err.code === "number" ? err.code : null;
    stdout = String(err.stdout ?? "");
    stderr = String(err.stderr ?? "");
    failureReason = err.message ?? String(error);
  }
  const finishedAt = new Date();
  const titles = parseHandBrakeScanOutput(`${stdout}\n${stderr}`);
  if (titles.length === 0 && !failureReason)
    failureReason = "HandBrake 扫描未返回可用标题";
  return {
    titles,
    diagnostic: {
      tool: "handbrake",
      executable,
      args: ["--input", discRoot, "--title", "0", "--scan", "--json"],
      startedAt: startedAt.toISOString(),
      finishedAt: finishedAt.toISOString(),
      durationMs: finishedAt.getTime() - startedAt.getTime(),
      exitCode,
      stdout,
      stderr,
      failureReason,
    },
  };
}

/**
 * Convert HandBrake scan titles (which may merge several m2ts segments, e.g. a
 * full ballet) into UnifiedDiscTitles used for compression.  Remux keeps using
 * the per-m2ts fallback titles; preview frames come from the closest m2ts.
 */
export function handBrakeTitlesToUnified(
  discRoot: string,
  scan: HandBrakeTitle[],
  m2tsTitles: UnifiedDiscTitle[],
  baseIndex: number,
): UnifiedDiscTitle[] {
  return scan.map((hb, index) => {
    const streams: DiscAnalysisStream[] = hb.streams.map((stream) => ({
      index: stream.index,
      codecType: stream.codecType,
      codecName: stream.codecName,
      ...(stream.description ? { description: stream.description } : {}),
      language: stream.language ?? null,
      title: stream.title ?? null,
      width: stream.width ?? null,
      height: stream.height ?? null,
      channels: stream.channels ?? null,
      channelLayout: stream.channelLayout ?? null,
      sampleRate: stream.sampleRate ?? null,
      frameRate: stream.frameRate ?? null,
      bitrate: stream.bitrate ?? null,
      handbrakeTrackNumber: stream.handbrakeTrackNumber ?? stream.index,
    }));
    const duration = hb.durationSeconds;
    let previewSourcePath: string | null = null;
    let previewSegments: UnifiedDiscTitle["previewSegments"];
    let bestDelta = Number.POSITIVE_INFINITY;
    let bestPlaylistTitle: UnifiedDiscTitle | null = null;
    for (const m2ts of m2tsTitles) {
      const candidate = m2ts.durationSeconds;
      if (candidate == null) continue;
      const delta = Math.abs(candidate - (duration ?? 0));
      if (delta < bestDelta) {
        bestDelta = delta;
        bestPlaylistTitle = m2ts;
        // The playlist title's sourcePath is the .mpls file, which ffmpeg
        // cannot open directly; preview frames must come from its first m2ts
        // segment (previewSourcePath).
        previewSourcePath = m2ts.previewSourcePath ?? m2ts.sourcePath;
        previewSegments = m2ts.previewSegments;
      }
    }
    const playlistId = bestPlaylistTitle?.toolMappings.playlistId ?? null;
    return {
      titleId: `handbrake:${hb.titleNumber}`,
      titleIndex: baseIndex + index,
      sourcePath: discRoot,
      titleKind: "handbrake",
      previewSourcePath,
      previewSegments,
      displayName: buildBlurayTitleDisplayName({
        kind: "handbrake",
        index,
        handbrakeTitleNumber: hb.titleNumber,
        playlistId,
      }),
      durationSeconds: duration,
      chapterCount: hb.chapters.length,
      chapters: hb.chapters.map((chapter) => ({
        id: chapter.id,
        startSeconds: chapter.startSeconds,
        endSeconds: chapter.endSeconds,
        title: chapter.title,
      })),
      estimatedSize: null,
      streams,
      videoTracks: streams.filter((stream) => stream.codecType === "video"),
      audioTracks: streams.filter((stream) => stream.codecType === "audio"),
      subtitleTracks: streams.filter(
        (stream) => stream.codecType === "subtitle",
      ),
      // Bind the HandBrake title to its matching playlist so Remux can use the
      // real playlist segments for this title instead of the longest-playlist
      // fallback.
      toolMappings: {
        handbrakeTitleNumber: hb.titleNumber,
        makemkvTitleIndex: null,
        dvdVtsNumber: null,
        playlistId,
      },
      mappingStatus: "not-required",
    };
  });
}

/**
 * Collapse the two Blu-ray analyzers into one user-facing title list.
 *
 * The MPLS scanner is authoritative for the physical playlist used by Remux,
 * while HandBrake is authoritative for compression title/stream numbering.
 * They describe the same content, so exposing both records makes one movie
 * look like two titles. Keep the playlist record as the stable identity and
 * attach the matching HandBrake mapping to it.
 */
export function mergeBluRayToolTitles(
  playlistTitles: UnifiedDiscTitle[],
  handbrakeTitles: UnifiedDiscTitle[],
): UnifiedDiscTitle[] {
  const usedHandBrakeIndices = new Set<number>();
  const seenPlaylistIds = new Set<string>();
  const merged: UnifiedDiscTitle[] = [];

  for (const playlistTitle of playlistTitles) {
    const playlistId = playlistTitle.toolMappings.playlistId?.trim() || null;
    if (playlistId && seenPlaylistIds.has(playlistId)) continue;
    if (playlistId) seenPlaylistIds.add(playlistId);

    const handbrakeIndex = playlistId
      ? handbrakeTitles.findIndex((candidate, index) => {
          if (usedHandBrakeIndices.has(index)) return false;
          return candidate.toolMappings.playlistId?.trim() === playlistId;
        })
      : -1;
    if (handbrakeIndex < 0) {
      merged.push(playlistTitle);
      continue;
    }

    usedHandBrakeIndices.add(handbrakeIndex);
    const handbrakeTitle = handbrakeTitles[handbrakeIndex];
    merged.push({
      ...handbrakeTitle,
      titleId: playlistTitle.titleId,
      titleIndex: playlistTitle.titleIndex,
      titleKind: "handbrake",
      displayName: playlistTitle.displayName,
      estimatedSize: playlistTitle.estimatedSize,
      previewSourcePath:
        handbrakeTitle.previewSourcePath ?? playlistTitle.previewSourcePath,
      previewSegments:
        handbrakeTitle.previewSegments ?? playlistTitle.previewSegments,
      toolMappings: {
        ...playlistTitle.toolMappings,
        ...handbrakeTitle.toolMappings,
        playlistId,
      },
    });
  }

  for (const [index, handbrakeTitle] of handbrakeTitles.entries()) {
    if (!usedHandBrakeIndices.has(index)) merged.push(handbrakeTitle);
  }
  return merged;
}

export async function analyzeBlurayDiscSource(
  input: DiscAnalysisInput,
): Promise<DiscAnalysisResult> {
  const handbrakeExecutable =
    input.handbrakeCliPath || (await resolveToolPath("handbrake"));
  const ffprobe = await resolveToolPath("ffprobe");
  const startedAt = new Date();
  const playlists = await scanBlurayPlaylists(input.sourcePath);
  const titles: UnifiedDiscTitle[] = [];
  const analysisNotes: string[] = [];
  const diagnostics: DiscToolDiagnostic[] = [
    {
      tool: "ffprobe",
      executable: ffprobe,
      args: ["-show_streams", "-show_format", "-show_chapters"],
      startedAt: startedAt.toISOString(),
      finishedAt: new Date().toISOString(),
      durationMs: 0,
      exitCode: playlists.length > 0 ? 0 : 1,
      stdout: "",
      stderr: "",
      failureReason:
        playlists.length > 0 ? null : "BDMV/PLAYLIST 未解析到播放列表",
    },
  ];
  for (const [index, playlist] of playlists.entries()) {
    const streams = ffprobe
      ? await probeBlurayTitleStreams(ffprobe, playlist)
      : [];
    const firstSegmentPath = playlist.segments[0]?.streamPath ?? null;
    const probedDuration =
      firstSegmentPath && ffprobe && playlist.durationSeconds == null
        ? await probeBlurayStreamDuration(ffprobe, firstSegmentPath)
        : null;
    titles.push({
      titleId: `mpls:${playlist.playlistId}`,
      titleIndex: index,
      titleKind: "m2ts",
      sourcePath: playlist.mplsPath,
      previewSourcePath: firstSegmentPath,
      previewSegments: buildBlurayPreviewSegments(playlist),
      displayName: buildBlurayTitleDisplayName({
        kind: "playlist",
        index,
        playlistId: playlist.playlistId,
      }),
      durationSeconds: playlist.durationSeconds ?? probedDuration,
      chapterCount: playlist.chapterCount,
      chapters: playlist.chapters.map((chapter) => ({
        id: chapter.id,
        startSeconds: chapter.startSeconds,
        endSeconds: chapter.endSeconds,
        title: chapter.title,
      })),
      estimatedSize: playlist.sizeBytes,
      streams,
      videoTracks: streams.filter((stream) => stream.codecType === "video"),
      audioTracks: streams.filter((stream) => stream.codecType === "audio"),
      subtitleTracks: streams.filter(
        (stream) => stream.codecType === "subtitle",
      ),
      availabilityStatus:
        playlist.missingSegments.length > 0 ? "unavailable" : "confirmed",
      availabilityFailureReason:
        playlist.missingSegments.length > 0
          ? `播放列表 ${playlist.playlistId} 缺少源文件：${playlist.missingSegments
              .map((file) => path.basename(file))
              .join(", ")}`
          : null,
      toolMappings: {
        handbrakeTitleNumber: null,
        makemkvTitleIndex: null,
        dvdVtsNumber: null,
        playlistId: playlist.playlistId,
      },
      mappingStatus: "not-required",
    });
    if (playlist.missingSegments.length > 0) {
      analysisNotes.push(
        `播放列表 ${playlist.playlistId} 不可读取：缺少源文件 ${playlist.missingSegments
          .map((file) => path.basename(file))
          .join(", ")}`,
      );
    }
  }
  // Authoring tools sometimes ship several playlists pointing at the same
  // content (identical duration, size and stream signature). Keep only the
  // first copy so the title list never shows "identical" entries.
  const seenTitles = new Set<string>();
  for (let index = titles.length - 1; index >= 0; index -= 1) {
    const title = titles[index];
    const signature = [
      title.durationSeconds ?? "",
      title.estimatedSize ?? "",
      title.streams
        .map((stream) =>
          [
            stream.codecType,
            stream.codecName ?? "",
            stream.profile ?? "",
            stream.description ?? "",
            stream.language ?? "",
            stream.channels ?? "",
            stream.bitrate ?? "",
          ].join("|"),
        )
        .join(";"),
    ].join("#");
    if (seenTitles.has(signature)) {
      titles.splice(index, 1);
    } else {
      seenTitles.add(signature);
    }
  }
  if (titles.length === 0) {
    const fallbackTitles = await fallbackBlurayStreamTitles(
      input.sourcePath,
      ffprobe,
    );
    titles.push(...fallbackTitles);
  }
  // HandBrake's own title grouping is required for compression (it owns the
  // title numbers), so it runs for every Blu-ray regardless of whether
  // playlists were parsed. Playlist titles stay available for Remux/preview.
  if (handbrakeExecutable) {
    const hbScan = await scanBlurayWithHandBrake(
      input.sourcePath,
      handbrakeExecutable,
    );
    diagnostics.push(hbScan.diagnostic);
    if (hbScan.titles.length > 0) {
      const baseIndex = titles.length;
      titles.push(
        ...handBrakeTitlesToUnified(
          input.sourcePath,
          hbScan.titles,
          titles,
          baseIndex,
        ),
      );
      // HandBrake lists the same content twice when a disc carries duplicate
      // playlists (e.g. 00000/01007). Collapse entries with the same duration
      // and stream signature, keeping the one with the richer chapter layout.
      const handbrakeSeen = new Map<string, UnifiedDiscTitle>();
      for (const title of titles) {
        if (title.titleKind !== "handbrake") continue;
        const signature = [
          Math.round((title.durationSeconds ?? 0) * 10),
          title.streams
            .map((stream) =>
              [
                stream.codecType,
                stream.codecName ?? "",
                stream.language ?? "",
                stream.channels ?? "",
              ].join("|"),
            )
            .join(";"),
        ].join("#");
        const existing = handbrakeSeen.get(signature);
        if (
          !existing ||
          (title.chapterCount ?? 0) > (existing.chapterCount ?? 0)
        ) {
          handbrakeSeen.set(signature, title);
        }
      }
      const keptHandbrake = Array.from(handbrakeSeen.values());
      if (
        keptHandbrake.length <
        titles.filter((title) => title.titleKind === "handbrake").length
      ) {
        const handbrakeSet = new Set(keptHandbrake);
        for (let index = titles.length - 1; index >= 0; index -= 1) {
          if (
            titles[index].titleKind === "handbrake" &&
            !handbrakeSet.has(titles[index])
          ) {
            titles.splice(index, 1);
          }
        }
      }
    }
  }
  // Final consolidation: merge cross-tool duplicates first, then remove menu
  // stubs, put the main feature first, and cap the usable title list.
  const mplsTitles = titles.filter((title) => title.titleKind !== "handbrake");
  const handbrakeTitles = titles.filter(
    (title) => title.titleKind === "handbrake",
  );
  const mergedTitles = mergeBluRayToolTitles(mplsTitles, handbrakeTitles);
  const consolidatedTitles = consolidateDiscTitles(mergedTitles, (message) =>
    analysisNotes.push(message),
  );
  titles.length = 0;
  titles.push(...consolidatedTitles);
  const warnings = [
    ...analysisNotes,
    ...(titles.length > 0
      ? playlists.length > 0
        ? []
        : [
            "未解析到蓝光播放列表，已将 BDMV/STREAM 中的 m2ts 片段作为标题（无章节信息，预览与无损封装仍可用）。",
          ]
      : ["未从 BDMV/PLAYLIST 解析到可用蓝光标题；请检查光盘结构和诊断日志。"]),
  ];
  const diagnosticLogPath = await persistDiscAnalysisDiagnostics(
    buildDiscAnalysisId(input),
    diagnostics,
  ).catch(() => null);
  return {
    analysisId: buildDiscAnalysisId(input),
    sourcePath: input.sourcePath,
    sourceFingerprint: input.sourceFingerprint,
    mediaType: input.mediaType,
    createdAt: startedAt.toISOString(),
    titles,
    exportCandidates: [],
    diagnostics,
    diagnosticLogPath,
    warnings,
  };
}
