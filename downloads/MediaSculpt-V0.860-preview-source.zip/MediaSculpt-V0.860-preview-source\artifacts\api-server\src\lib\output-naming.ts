export type OutputMediaType =
  | "dvd"
  | "bluray"
  | "iso"
  | "video"
  | string
  | null
  | undefined;

export function cleanSegment(value: string): string {
  return (
    value
      // 输出文件名不保留中文字符（含全角字符、中文标点及名字中的间隔点）：
      // "All.Things.Fair.1995.教室别恋" → "All.Things.Fair.1995"
      // "Helene.Grimaud.2023.海伦·格里莫" → "Helene.Grimaud.2023"
      .replace(
        /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3000-\u303f\uff00-\uffef\u00b7\u2022\u2027\u30fb\uff65]/g,
        "",
      )
      .replace(/[<>:"/\\|?*\x00-\x1f]/g, " ")
      .replace(/\s+/g, ".")
      .replace(/\.+/g, ".")
      .replace(/^\.|\.$/g, "") || "Untitled"
  );
}

export function sourceLabel(mediaType: OutputMediaType): string {
  if (mediaType === "dvd") return "DVD";
  if (mediaType === "bluray") return "BluRay";
  if (mediaType === "iso") return "ISO";
  return "Video";
}

/**
 * Resolution tag used in compressed output file names. SD sources (DVD) omit
 * the tag; HD sources are labelled 720p / 1080p / 2160p / 4K.
 */
export function resolutionTag(height: number | null | undefined): string {
  const h = Math.floor(Number(height ?? 0));
  if (h >= 3500) return "4K";
  if (h >= 2000) return "2160p";
  if (h >= 1300) return "1440p";
  if (h >= 1000) return "1080p";
  if (h >= 700) return "720p";
  return "";
}

/** 10bit+ bit depth tag; 8bit is intentionally omitted from file names. */
export function bitDepthTag(bitDepth: number | null | undefined): string {
  const depth = Math.floor(Number(bitDepth ?? 0));
  return depth >= 10 ? `${depth}bit` : "";
}

/** Infer output bit depth from the configured encoder name (x264_10bit → 10). */
export function encoderBitDepth(
  encoder: string | null | undefined,
): number | null {
  const value = (encoder ?? "").toLowerCase();
  const match = /(?:^|[^a-z0-9])(10|12|16)(?:bit|-bit)/i.exec(value);
  return match ? Number(match[1]) : null;
}

export function normalizeEncoderName(
  encoder: string | null | undefined,
): string {
  const value = (encoder ?? "").toLowerCase();
  if (
    value.includes("x265") ||
    value.includes("h265") ||
    value.includes("hevc")
  ) {
    return value.includes("10") ? "H265-10bit" : "H265";
  }
  if (
    value.includes("x264") ||
    value.includes("h264") ||
    value.includes("avc")
  ) {
    return value.includes("10") ? "H264-10bit" : "H264";
  }
  if (value.includes("av1")) return "AV1";
  return cleanSegment(encoder || "Encode");
}

export function normalizeAudioCodec(codec: string | null | undefined): string {
  const value = (codec ?? "").toLowerCase();
  if (!value) return "Audio";
  if (value === "dca" || value.includes("dts")) return "DTS";
  if (value.includes("truehd")) return "TrueHD";
  if (value.includes("eac3") || value.includes("e-ac-3")) return "EAC3";
  if (value.includes("ac3") || value.includes("ac-3")) return "AC3";
  if (value.includes("aac")) return "AAC";
  if (value.includes("flac")) return "FLAC";
  if (value.includes("mp3")) return "MP3";
  if (value.includes("pcm")) return "PCM";
  return cleanSegment(codec ?? "Audio").toUpperCase();
}

export type AudioCandidate = {
  codec?: string | null;
  channels?: number | null;
  bitrate?: number | null;
  language?: string | null;
};

/**
 * Pick the best audio track for the file-name label (lossless codecs win,
 * then high-channel/high-bitrate lossy codecs, mirroring the Whisper track
 * scorer so the label always reflects the best retained track).
 */
export function selectBestAudioTrack(
  tracks: AudioCandidate[],
): AudioCandidate | null {
  const audio = tracks
    .filter((track) => track && track.codec)
    .map((track) => ({
      ...track,
      codec: (track.codec ?? "").toLowerCase(),
    }));
  if (audio.length === 0) return null;
  const lossless = new Set([
    "pcm",
    "pcm_s16le",
    "pcm_s24le",
    "pcm_s32le",
    "truehd",
    "dts_hd_ma",
    "dtshd_ma",
    "flac",
  ]);
  const score = (track: AudioCandidate): number => {
    const codec = (track.codec ?? "").toLowerCase();
    let value = 0;
    if (lossless.has(codec)) value += 80;
    else if (/dts|truehd|eac3|ac3/.test(codec)) value += 40;
    else if (/aac|mp3/.test(codec)) value += 10;
    const channels = Number(track.channels ?? 0);
    if (channels >= 6) value += 15;
    else if (channels >= 2) value += 5;
    const bitrate = Number(track.bitrate ?? 0);
    if (bitrate >= 1_500_000) value += 10;
    else if (bitrate >= 384_000) value += 5;
    return value;
  };
  return audio.reduce((best, current) =>
    score(current) > score(best) ? current : best,
  );
}

function compressionCodecTag(encoder: string | null | undefined): string {
  // Bit depth is emitted as its own token (H264.10bit), so the encoder label
  // keeps only the codec family (H264 / H265 / AV1).
  return normalizeEncoderName(encoder)
    .replace(/-10bit$/i, "")
    .replace(/-12bit$/i, "")
    .replace(/-16bit$/i, "");
}

export function buildRemuxOutputName(
  baseName: string,
  mediaType: OutputMediaType,
  outputFormat: string,
  template?: string | null,
): string {
  if (template?.trim()) {
    return renderOutputNameTemplate({
      template,
      baseName,
      mediaType,
      kind: "Remux",
      outputFormat,
    });
  }
  return `${cleanSegment(baseName)}.${sourceLabel(mediaType)}.Remux.${cleanSegment(outputFormat || "mkv")}`;
}

export type OutputNameTemplateContext = {
  /** 用户配置的命名模板 */
  template: string;
  /** 含年份与 Title 序号的原始基础名（如 All.Things.Fair.1995.Title01） */
  baseName: string;
  mediaType: OutputMediaType;
  kind: "Remux" | "Compress";
  encoder?: string | null;
  crf?: number | null;
  primaryAudioCodec?: string | null;
  height?: number | null;
  bitDepth?: number | null;
  outputFormat: string;
};

/**
 * 用户自定义输出文件名模板渲染。
 * 支持 {title} {year} {titleNo} {source} {kind} {resolution} {encoder} {bitdepth} {audio} {crf} {ext}；
 * 不适用当前类型的变量为空值并连同分隔符一起清理；分隔符统一规范为 "."。
 * 渲染为空或非法时回退到 “title.ext”。
 */
export function renderOutputNameTemplate(
  input: OutputNameTemplateContext,
): string {
  const base = input.baseName;
  const titleNoMatch = /\.Title(\d+)$/i.exec(base);
  const titleNo = titleNoMatch ? titleNoMatch[1] : "";
  const withoutTitle = titleNoMatch
    ? base.slice(0, -titleNoMatch[0].length)
    : base;
  const yearMatch = /(?:^|[._\-\s])((?:19|20)\d{2})(?:$|[._\-\s])/.exec(
    withoutTitle,
  );
  const year = yearMatch ? yearMatch[1] : "";
  const title = cleanSegment(
    year ? withoutTitle.replace(yearMatch?.[0] ?? "", "") : withoutTitle,
  );
  const isRemux = input.kind === "Remux";
  const tokens: Record<string, string> = {
    title,
    year,
    titleNo,
    source: sourceLabel(input.mediaType),
    kind: input.kind,
    resolution: isRemux ? "" : resolutionTag(input.height),
    encoder: isRemux ? "" : compressionCodecTag(input.encoder),
    bitdepth: isRemux
      ? ""
      : bitDepthTag(input.bitDepth ?? encoderBitDepth(input.encoder)),
    audio: isRemux ? "" : normalizeAudioCodec(input.primaryAudioCodec),
    crf: isRemux || input.crf == null ? "" : String(Math.round(input.crf)),
    ext: cleanSegment(input.outputFormat || "mkv"),
  };
  const hasExtToken = input.template.includes("{ext}");
  let name = input.template;
  for (const [key, value] of Object.entries(tokens)) {
    name = name.split(`{${key}}`).join(value);
  }
  const rendered = name
    .split(/[._\- ]+/)
    .filter((segment) => segment.length > 0)
    .join(".")
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, "");
  if (!rendered) return `${title || "Untitled"}.${tokens.ext}`;
  const withExt = hasExtToken ? rendered : `${rendered}.${tokens.ext}`;
  return (
    withExt.replace(/\.+/g, ".").replace(/^\.|\.$/g, "") ||
    `${title || "Untitled"}.${tokens.ext}`
  );
}

export function buildCompressionOutputName(input: {
  baseName: string;
  mediaType: OutputMediaType;
  outputFormat: string;
  encoder: string | null | undefined;
  crf?: number | null | undefined;
  primaryAudioCodec: string | null | undefined;
  height?: number | null | undefined;
  bitDepth?: number | null | undefined;
  template?: string | null;
}): string {
  if (input.template?.trim()) {
    return renderOutputNameTemplate({
      template: input.template,
      baseName: input.baseName,
      mediaType: input.mediaType,
      kind: "Compress",
      encoder: input.encoder,
      crf: input.crf,
      primaryAudioCodec: input.primaryAudioCodec,
      height: input.height,
      bitDepth: input.bitDepth,
      outputFormat: input.outputFormat,
    });
  }
  // 压缩版命名：英文名.年份.[分辨率.][来源.][编码.]位深.音频格式.扩展名（不含码率）
  // DVD → XXX.1995.DVDrip.H264.10bit.AC3.mkv
  // BluRay → XXX.2007.1080p.BluRay.10bit.DTS.mkv
  // 未知来源 → XXX.2010.1080p.H264.10bit.AC3.mkv
  const source =
    input.mediaType === "dvd"
      ? "DVDrip"
      : input.mediaType === "bluray" || input.mediaType === "iso"
        ? "BluRay"
        : "";
  const codec =
    input.mediaType === "bluray" || input.mediaType === "iso"
      ? ""
      : compressionCodecTag(input.encoder);
  const depth = bitDepthTag(input.bitDepth ?? encoderBitDepth(input.encoder));
  return (
    [
      cleanSegment(input.baseName),
      resolutionTag(input.height),
      source,
      codec,
      depth,
      normalizeAudioCodec(input.primaryAudioCodec),
    ]
      .filter(Boolean)
      .join(".") + `.${cleanSegment(input.outputFormat || "mkv")}`
  );
}
