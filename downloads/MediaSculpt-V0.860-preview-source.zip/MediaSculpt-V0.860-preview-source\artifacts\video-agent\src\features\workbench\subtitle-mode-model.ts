import type { SubtitleMode } from "../../hooks/useWorkbenchState";

export type SubtitleModeAccent =
  | "amber-active"
  | "amber-tool"
  | "primary-active"
  | "default";

export function subtitleModeAccent(
  mode: SubtitleMode,
  active: boolean,
): SubtitleModeAccent {
  if (active && mode === "auto") return "amber-active";
  if (active) return "primary-active";
  if (mode === "ocr" || mode === "whisper" || mode === "transcribe_translate")
    return "amber-tool";
  return "default";
}
