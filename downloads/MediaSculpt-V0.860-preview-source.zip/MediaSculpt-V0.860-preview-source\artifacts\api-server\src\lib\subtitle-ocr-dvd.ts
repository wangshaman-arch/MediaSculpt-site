// Extracted from subtitle-ocr.ts: DVD VobSub OCR (HandBrake passthrough + ffmpeg frame decode).
import { deflateSync, inflateSync } from "node:zlib";
import { createHash } from "node:crypto";
import path from "node:path";
import { access } from "node:fs/promises";
import {
  resolveAiEndpoint,
  resolveApiKey,
  type AiProviderConfig,
} from "./ai-provider";
import { resolveToolPath } from "./tool-runtime";
import { findDvdTitles, resolveDvdVideoTsDir } from "./disc";
import { isGraphicSubtitleCodec } from "./subtitle-utils";
import { encodePng, toBlackOnWhite, decodePngRgba } from "./subtitle-ocr-png";
import { parsePgsSup } from "./subtitle-ocr-pgs";
import {
  type OcrEvent,
  type OcrEngine,
  type OcrResult,
  isDirectFrameGraphicCodec,
  computeOcrQuality,
  detectScriptLanguage,
  languageMatchesRequest,
  detectAutoTesseractLanguage,
  resolveOcrEngineAndLanguage,
  ocrWithTesseract,
  ocrWithRapidOcr,
  formatSrtTime,
  assembleSrt,
  validateOcrCompleteness,
  detectChineseVariant,
  ISO_TO_TESSERACT,
  ocrWithLlm,
  writeSrtBesideSource,
} from "./subtitle-ocr";

// ── DVD VobSub OCR (HandBrake passthrough → ffmpeg frame decode) ─────────────
type DvdOcrTarget = {
  discRoot: string;
  handbrakeTitleNumber: number;
  subtitleTrackNumber: number;
  subtitleLanguage: string | null;
};

type VobFrame = { ptsMs: number; png: Buffer; hash: string; size: number };

/** Resolve a DVD disc root from a folder (or an .IFO file), searching one
 *  level down so a parent folder containing several disc folders still works. */
async function resolveDiscRootForOcr(
  sourcePath: string,
): Promise<string | null> {
  const { stat, readdir } = await import("node:fs/promises");
  const { join, dirname } = await import("node:path");
  if (/\.ifo$/i.test(sourcePath)) {
    const videoTs = await resolveDvdVideoTsDir(dirname(sourcePath));
    return videoTs ? dirname(videoTs) : null;
  }
  if (await resolveDvdVideoTsDir(sourcePath)) return sourcePath;
  let entries: string[] = [];
  try {
    entries = await readdir(sourcePath);
  } catch {
    return null;
  }
  const candidates: string[] = [];
  for (const entry of entries) {
    const child = join(sourcePath, entry);
    try {
      const childStat = await stat(child);
      if (!childStat.isDirectory()) continue;
    } catch {
      continue;
    }
    if (await resolveDvdVideoTsDir(child)) candidates.push(child);
  }
  if (candidates.length === 0) return null;
  // Multiple disc folders: pick the one with the most VOB/IFO bytes.
  let best = candidates[0];
  let bestSize = -1;
  for (const disc of candidates) {
    const videoTs = await resolveDvdVideoTsDir(disc);
    if (!videoTs) continue;
    const discEntries = await readdir(videoTs).catch(() => [] as string[]);
    let size = 0;
    for (const name of discEntries) {
      if (!/\.(vob|ifo)$/i.test(name)) continue;
      try {
        size += (await stat(join(videoTs, name))).size;
      } catch {
        // ignore unreadable files
      }
    }
    if (size > bestSize) {
      bestSize = size;
      best = disc;
    }
  }
  return best;
}

async function resolveDvdSubtitleTrack(
  discRoot: string,
  titleNumber: number,
  preferredLanguage: string,
): Promise<{ trackNumber: number; language: string | null }> {
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const execFileAsync = promisify(execFile);
  const handbrake = await resolveToolPath("handbrake");
  if (!handbrake) return { trackNumber: 1, language: null };
  try {
    const { stdout } = await execFileAsync(
      handbrake,
      ["--input", discRoot, "--title", String(titleNumber), "--scan", "--json"],
      { timeout: 120_000 },
    );
    const parsed = extractHandBrakeJson(stdout) as {
      TitleList?: Array<{
        SubtitleList?: Array<{ TrackNumber?: number; LanguageCode?: string }>;
      }>;
    };
    const list = parsed?.TitleList?.[0]?.SubtitleList ?? [];
    if (!Array.isArray(list) || list.length === 0)
      return { trackNumber: 1, language: null };
    const requested = (preferredLanguage || "auto").trim().toLowerCase();
    const languageOf = (sub: { LanguageCode?: string } | undefined): string =>
      String(sub?.LanguageCode ?? "")
        .trim()
        .toLowerCase();
    const pick =
      requested === "auto"
        ? (list.find((sub) =>
            ["zho", "chi", "zh", "cmn"].includes(languageOf(sub)),
          ) ??
          list.find((sub) => languageOf(sub) === "eng") ??
          list.find((sub) => languageOf(sub).length > 0) ??
          list[0])
        : (list.find((sub) =>
            languageMatchesRequest(String(sub.LanguageCode ?? ""), requested),
          ) ?? list[0]);
    return {
      trackNumber: Number(pick?.TrackNumber) > 0 ? Number(pick.TrackNumber) : 1,
      language: languageOf(pick) || null,
    };
  } catch {
    return { trackNumber: 1, language: null };
  }
}

/**
 * HandBrake CLI prints a version banner and libdvdnav messages before the JSON
 * document, so raw `JSON.parse` always throws. Extract the outermost JSON
 * object instead (HandBrake wraps it as `JSON Title Set: { ... }`).
 */
export function extractHandBrakeJson(
  output: string,
): Record<string, unknown> | null {
  const ranges: Array<[number, number]> = [];
  // HandBrake prints a "Progress: {...}" object before the final scan JSON, so
  // anchor on the explicit "JSON Title Set:" marker when present.
  const marker = output.indexOf("JSON Title Set:");
  if (marker >= 0) {
    const start = output.indexOf("{", marker);
    const end = output.lastIndexOf("}");
    if (start >= 0 && end > start) ranges.push([start, end]);
  }
  const fallbackStart = output.indexOf("{");
  const fallbackEnd = output.lastIndexOf("}");
  if (fallbackStart >= 0 && fallbackEnd > fallbackStart)
    ranges.push([fallbackStart, fallbackEnd]);
  for (const [start, end] of ranges) {
    try {
      const parsed = JSON.parse(output.slice(start, end + 1));
      if (parsed && typeof parsed === "object")
        return parsed as Record<string, unknown>;
    } catch {
      // Try the next candidate range.
    }
  }
  return null;
}

export async function detectDvdOcrTarget(
  sourcePath: string,
  requestedTitleId?: string | null,
  preferredLanguage = "auto",
): Promise<DvdOcrTarget | null> {
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const execFileAsync = promisify(execFile);
  const discRoot = await resolveDiscRootForOcr(sourcePath);
  if (!discRoot) return null;
  const handbrake = await resolveToolPath("handbrake");
  if (!handbrake) {
    throw new Error(
      "未找到 HandBrakeCLI。DVD VobSub 字幕 OCR 需要 HandBrake 完成字幕轨直通提取，请先在工具管理器安装 HandBrake。",
    );
  }
  // The job snapshot stores the selected title as "handbrake:1" / "hb:1" /
  // "dvd:1" or a bare number. Always honor the user's choice instead of
  // re-picking the longest title (which can be a menu or short extra).
  const titleMatch = /^(?:handbrake|hb|dvd)[:_ ](\d+)$/i.exec(
    requestedTitleId ?? "",
  );
  const bareTitle =
    requestedTitleId && /^\d+$/.test(requestedTitleId)
      ? Number(requestedTitleId)
      : null;
  if (titleMatch || bareTitle !== null) {
    const titleNumber = titleMatch
      ? Number(titleMatch[1])
      : (bareTitle as number);
    const subtitleTrack = await resolveDvdSubtitleTrack(
      discRoot,
      titleNumber,
      preferredLanguage,
    );
    return {
      discRoot,
      handbrakeTitleNumber: titleNumber,
      subtitleTrackNumber: subtitleTrack.trackNumber,
      subtitleLanguage: subtitleTrack.language,
    };
  }
  try {
    const { stdout } = await execFileAsync(
      handbrake,
      ["--input", discRoot, "--title", "0", "--scan", "--json"],
      { timeout: 120_000 },
    );
    const parsed = extractHandBrakeJson(stdout) as {
      TitleList?: Array<{ Index?: number; Duration?: { Seconds?: number } }>;
    } | null;
    const titles = (parsed?.TitleList ?? []).filter(
      (title) => typeof title.Index === "number" && title.Index > 0,
    );
    const longest = titles.sort(
      (a, b) => (b.Duration?.Seconds ?? 0) - (a.Duration?.Seconds ?? 0),
    )[0];
    if (longest?.Index) {
      const subtitleTrack = await resolveDvdSubtitleTrack(
        discRoot,
        longest.Index,
        preferredLanguage,
      );
      return {
        discRoot,
        handbrakeTitleNumber: longest.Index,
        subtitleTrackNumber: subtitleTrack.trackNumber,
        subtitleLanguage: subtitleTrack.language,
      };
    }
  } catch {
    // scan failed — fall through to the IFO-based title number
  }
  const ifoTitles = await findDvdTitles(discRoot);
  const largest = ifoTitles.sort((a, b) => b.sizeBytes - a.sizeBytes)[0];
  if (!largest) return null;
  const subtitleTrack = await resolveDvdSubtitleTrack(
    discRoot,
    largest.titleNumber,
    preferredLanguage,
  );
  return {
    discRoot,
    handbrakeTitleNumber: largest.titleNumber,
    subtitleTrackNumber: subtitleTrack.trackNumber,
    subtitleLanguage: subtitleTrack.language,
  };
}

async function extractDvdSubtitleMkv(target: DvdOcrTarget): Promise<string> {
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const { mkdir, stat } = await import("node:fs/promises");
  const { tmpdir } = await import("node:os");
  const { join } = await import("node:path");
  const execFileAsync = promisify(execFile);
  const handbrake = await resolveToolPath("handbrake");
  if (!handbrake) throw new Error("未找到 HandBrakeCLI");
  const cacheDir = join(tmpdir(), "MediaSculpt", "ocr-cache");
  await mkdir(cacheDir, { recursive: true });
  // Include the subtitle track so switching tracks never reuses a cache built
  // from a different track.
  const key = createHash("sha256")
    .update(
      `${target.discRoot.toLowerCase()}|${target.handbrakeTitleNumber}|${target.subtitleTrackNumber ?? 1}`,
    )
    .digest("hex")
    .slice(0, 16);
  const mkvPath = join(
    cacheDir,
    `dvd-${key}-t${target.handbrakeTitleNumber}.mkv`,
  );
  try {
    await stat(mkvPath);
    return mkvPath;
  } catch {
    // cache miss — encode once
  }
  await execFileAsync(
    handbrake,
    [
      "--input",
      target.discRoot,
      "--title",
      String(target.handbrakeTitleNumber),
      "--output",
      mkvPath,
      "-e",
      "x264",
      "--encoder-preset",
      "ultrafast",
      "--quality",
      "51",
      "--audio",
      "1",
      "--aencoder",
      "copy",
      "--subtitle",
      String(target.subtitleTrackNumber ?? 1),
      "--no-deinterlace",
      "--no-detelecine",
      "--no-comb-detect",
    ],
    { timeout: 60 * 60_000 },
  );
  return mkvPath;
}

/**
 * 一次转换把标题的全部字幕轨带进 MKV（用于逐轨统计行数后择优识别），
 * 缓存按“标题”区分，不再绑定单条字幕轨。
 */
async function extractDvdSubtitleMkvAll(target: DvdOcrTarget): Promise<string> {
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const { mkdir, stat } = await import("node:fs/promises");
  const { tmpdir } = await import("node:os");
  const { join } = await import("node:path");
  const execFileAsync = promisify(execFile);
  const handbrake = await resolveToolPath("handbrake");
  if (!handbrake) throw new Error("未找到 HandBrakeCLI");
  const scanOut = await execFileAsync(
    handbrake,
    [
      "--input",
      target.discRoot,
      "--title",
      String(target.handbrakeTitleNumber),
      "--scan",
      "--json",
    ],
    { timeout: 120_000 },
  );
  const parsed = extractHandBrakeJson(scanOut.stdout) as {
    TitleList?: Array<{ SubtitleList?: Array<{ TrackNumber?: number }> }>;
  };
  const subList = parsed?.TitleList?.[0]?.SubtitleList ?? [];
  const trackNumbers = subList
    .map((sub) => Number(sub.TrackNumber))
    .filter((num) => Number.isFinite(num) && num > 0);
  const subtitleArg =
    trackNumbers.length > 0
      ? trackNumbers.join(",")
      : String(target.subtitleTrackNumber ?? 1);
  const cacheDir = join(tmpdir(), "MediaSculpt", "ocr-cache");
  await mkdir(cacheDir, { recursive: true });
  const key = createHash("sha256")
    .update(
      `${target.discRoot.toLowerCase()}|${target.handbrakeTitleNumber}|all`,
    )
    .digest("hex")
    .slice(0, 16);
  const mkvPath = join(
    cacheDir,
    `dvd-${key}-t${target.handbrakeTitleNumber}-all.mkv`,
  );
  try {
    await stat(mkvPath);
    return mkvPath;
  } catch {
    // cache miss — encode once
  }
  await execFileAsync(
    handbrake,
    [
      "--input",
      target.discRoot,
      "--title",
      String(target.handbrakeTitleNumber),
      "--output",
      mkvPath,
      "-e",
      "x264",
      "--encoder-preset",
      "ultrafast",
      "--quality",
      "51",
      "--audio",
      "1",
      "--aencoder",
      "copy",
      "--subtitle",
      subtitleArg,
      "--no-deinterlace",
      "--no-detelecine",
      "--no-comb-detect",
    ],
    { timeout: 60 * 60_000 },
  );
  return mkvPath;
}

/**
 * 逐轨统计 VobSub 字幕事件数，选行数最多的一轨用于识别；
 * 默认偏好：西方语言轨（英/西/法/德/意/葡等）优先，
 * 与首选轨行数差 ≤10% 或 ≤20 条时以首选轨为准；默认不识别日语/韩语字幕轨（跳过）。
 */
/**
 * 轨道筛选只使用一次性统计结果；这里不读取图像，也不执行 OCR。
 */
export type DvdSubtitleTrackStat = {
  subTypeIndex: number;
  count: number;
  language: string | null;
  coverage: number;
};

const DVD_LANGUAGE_NAMES: Record<string, string> = {
  chi: "中文",
  zho: "中文",
  zh: "中文",
  cmn: "中文",
  eng: "英语",
  en: "英语",
  spa: "西班牙语",
  es: "西班牙语",
  fra: "法语",
  fre: "法语",
  fr: "法语",
  deu: "德语",
  ger: "德语",
  de: "德语",
  ita: "意大利语",
  it: "意大利语",
  por: "葡萄牙语",
  pt: "葡萄牙语",
  nld: "荷兰语",
  dut: "荷兰语",
  nl: "荷兰语",
  swe: "瑞典语",
  sv: "瑞典语",
  nor: "挪威语",
  no: "挪威语",
  dan: "丹麦语",
  da: "丹麦语",
  fin: "芬兰语",
  fi: "芬兰语",
  pol: "波兰语",
  pl: "波兰语",
  ces: "捷克语",
  cze: "捷克语",
  cs: "捷克语",
  slk: "斯洛伐克语",
  slo: "斯洛伐克语",
  sk: "斯洛伐克语",
  hun: "匈牙利语",
  hu: "匈牙利语",
  rum: "罗马尼亚语",
  ron: "罗马尼亚语",
  ro: "罗马尼亚语",
  ell: "希腊语",
  gre: "希腊语",
  el: "希腊语",
  jpn: "日语",
  ja: "日语",
  kor: "韩语",
  ko: "韩语",
};

export function normalizeDvdSubtitleLanguage(
  language: string | null | undefined,
): string | null {
  const value = String(language ?? "")
    .trim()
    .toLowerCase();
  return value || null;
}

export function dvdSubtitleLanguageLabel(
  language: string | null | undefined,
): string {
  const code = normalizeDvdSubtitleLanguage(language);
  if (!code) return "未标记";
  return `${DVD_LANGUAGE_NAMES[code] ?? "未知语言"}（${code.toUpperCase()}）`;
}

function median(values: number[]): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.floor(sorted.length / 2)] ?? 0;
}

export function chooseDvdSubtitleTrack(
  tracks: DvdSubtitleTrackStat[],
  preferredLanguage?: string,
): DvdSubtitleTrackStat {
  const candidates = tracks.filter(
    (track) =>
      track.count > 0 && !BLOCKED_OCR_LANGUAGES.has(track.language ?? ""),
  );
  const poolBase =
    candidates.length > 0
      ? candidates
      : tracks.filter((track) => track.count > 0);
  if (poolBase.length === 0)
    throw new Error("DVD 中未解析到任何 VobSub 字幕事件");
  const longEnough = poolBase.filter((track) => track.coverage >= 0.8);
  const pool = longEnough.length > 0 ? longEnough : poolBase;
  const best = pool.reduce((a, b) => (b.count > a.count ? b : a));
  const requested = (preferredLanguage ?? "").trim().toLowerCase();
  const wantsSpecific = requested !== "" && requested !== "auto";
  const requestedTesseract = ISO_TO_TESSERACT[requested] ?? requested;
  const specificallyChinese =
    requestedTesseract === "chi_sim" || requestedTesseract === "chi_tra";
  const languageMatches = (language: string | null): boolean => {
    if (!language) return false;
    const value = language.toLowerCase();
    if (value === requested || value.startsWith(requested)) return true;
    const valueTess = ISO_TO_TESSERACT[value] ?? value;
    return requestedTesseract === valueTess;
  };
  // A Chinese-target workflow must not lose its Chinese source track merely
  // because another language has a longer reported coverage. Coverage is a
  // warning/quality signal; the matching Chinese track remains the primary OCR
  // source and foreign tracks are selected separately as references.
  const requestedTracks = wantsSpecific
    ? (specificallyChinese ? candidates : pool).filter((track) =>
        languageMatches(track.language),
      )
    : [];
  const autoChineseTracks = !wantsSpecific
    ? candidates.filter((track) =>
        CHINESE_DVD_LANGUAGES.has(
          normalizeDvdSubtitleLanguage(track.language) ?? "",
        ),
      )
    : [];
  const englishTracks = pool.filter((track) =>
    ["en", "eng"].some((code) =>
      (track.language ?? "").toLowerCase().startsWith(code),
    ),
  );
  const westernTracks = pool.filter((track) =>
    WESTERN_OCR_LANGUAGES.has(track.language ?? ""),
  );
  const preferred =
    englishTracks.length > 0
      ? englishTracks.reduce((a, b) => (b.count > a.count ? b : a))
      : westernTracks.length > 0
        ? westernTracks.reduce((a, b) => (b.count > a.count ? b : a))
        : undefined;
  const closeEnough = (candidate: DvdSubtitleTrackStat) =>
    best.count - candidate.count <= Math.max(best.count * 0.1, 20);
  return requestedTracks.length > 0
    ? requestedTracks.reduce((a, b) => (b.count > a.count ? b : a))
    : // MediaSculpt's auto OCR is intended to produce the user's readable
      // subtitle, not an arbitrary foreign track. When a DVD explicitly labels
      // a Chinese graphic track, prefer it; foreign tracks are selected later
      // as reference material for bilingual correction.
      autoChineseTracks.length > 0
      ? autoChineseTracks.reduce((a, b) => (b.count > a.count ? b : a))
      : preferred !== undefined &&
          (best === preferred || closeEnough(preferred))
        ? preferred
        : best;
}

const CHINESE_DVD_LANGUAGES = new Set(["chi", "zho", "zh", "cmn", "zht"]);
const isEnglishDvdLanguage = (language: string | null | undefined) =>
  /^(?:en|eng)(?:[-_]|$)/i.test(language ?? "");

/**
 * Select an OCR reference track for a Chinese DVD subtitle. English is the
 * preferred semantic reference; otherwise choose a non-Chinese foreign track
 * whose actual cue count is close enough to align reliably with the Chinese.
 */
export function chooseDvdSubtitleReferenceTrack(
  tracks: DvdSubtitleTrackStat[],
  chineseTrack: DvdSubtitleTrackStat,
): DvdSubtitleTrackStat | null {
  const usable = tracks.filter(
    (track) =>
      track.subTypeIndex !== chineseTrack.subTypeIndex && track.count > 0,
  );
  const english = usable.filter((track) =>
    isEnglishDvdLanguage(track.language),
  );
  if (english.length > 0)
    return english.reduce((a, b) => (b.count > a.count ? b : a));

  const foreign = usable.filter((track) => {
    const language = normalizeDvdSubtitleLanguage(track.language);
    return (
      !language ||
      (!CHINESE_DVD_LANGUAGES.has(language) &&
        !BLOCKED_OCR_LANGUAGES.has(language))
    );
  });
  if (foreign.length === 0 || chineseTrack.count <= 0) return null;
  const closest = foreign.reduce((a, b) =>
    Math.abs(b.count - chineseTrack.count) <
    Math.abs(a.count - chineseTrack.count)
      ? b
      : a,
  );
  const difference = Math.abs(closest.count - chineseTrack.count);
  const allowedDifference = Math.max(20, Math.round(chineseTrack.count * 0.15));
  return difference <= allowedDifference ? closest : null;
}

const BLOCKED_OCR_LANGUAGES = new Set(["jpn", "ja", "kor", "ko"]);
/** 西方语言（拉丁字母欧洲语言）ISO 639-1/2/3 代码。 */
const WESTERN_OCR_LANGUAGES = new Set([
  "en",
  "eng",
  "es",
  "spa",
  "fr",
  "fra",
  "de",
  "deu",
  "it",
  "ita",
  "pt",
  "por",
  "nl",
  "nld",
  "da",
  "dan",
  "sv",
  "swe",
  "no",
  "nor",
  "fi",
  "fin",
  "pl",
  "pol",
  "cs",
  "ces",
  "sk",
  "slk",
  "hu",
  "hun",
  "ro",
  "ron",
  "rum",
  "el",
  "ell",
]);

async function pickBestDvdSubtitleTrack(
  mkvPath: string,
  target: DvdOcrTarget,
  progress: (message: string) => Promise<void>,
  preferredLanguage?: string,
  preferredSubTypeIndex?: number,
): Promise<{
  frames: VobFrame[];
  subTypeIndex: number;
  streamLanguage: string | null;
  referenceTrack: DvdSubtitleTrackStat | null;
}> {
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const execFileAsync = promisify(execFile);
  const ffprobe = (await resolveToolPath("ffprobe")) ?? "ffprobe";
  const probeOut = await execFileAsync(
    ffprobe,
    [
      "-v",
      "error",
      "-print_format",
      "json",
      "-show_streams",
      "-count_packets",
      mkvPath,
    ],
    { timeout: 30_000 },
  );
  const parsed = JSON.parse(probeOut.stdout) as {
    streams?: Array<{
      codec_type?: string;
      duration?: string;
      nb_read_packets?: string;
      tags?: { language?: string };
    }>;
  };
  const vStream = (parsed.streams ?? []).find(
    (stream) => stream.codec_type === "video",
  );
  const videoDurationMs =
    Number(vStream?.duration) > 0 ? Number(vStream?.duration) * 1000 : 0;
  const subStreams = (parsed.streams ?? []).filter(
    (stream) => stream.codec_type === "subtitle",
  );
  if (subStreams.length === 0)
    throw new Error("HandBrake 提取的 MKV 中没有字幕轨");
  let tracks: DvdSubtitleTrackStat[] = subStreams.map((stream, i) => {
    const count = Number(stream.nb_read_packets);
    const durationMs =
      Number(stream.duration) > 0 ? Number(stream.duration) * 1000 : 0;
    const coverage =
      videoDurationMs > 0 && durationMs > 0
        ? Math.min(1, durationMs / videoDurationMs)
        : count > 0
          ? 1
          : 0;
    return {
      subTypeIndex: i,
      count: Number.isFinite(count) && count > 0 ? count : 0,
      language:
        String(stream.tags?.language ?? "")
          .trim()
          .toLowerCase() || null,
      coverage,
    };
  });
  await progress(`已一次统计 ${tracks.length} 条图形字幕轨，暂不执行 OCR`);
  if (!tracks.some((track) => track.count > 0)) {
    await progress("字幕包数不可用，回退为逐轨事件统计");
    tracks = [];
    for (let i = 0; i < subStreams.length; i += 1) {
      let frames: VobFrame[] = [];
      try {
        frames = await decodeVobSubToFrames(mkvPath, i);
      } catch {
        frames = [];
      }
      const built = buildEventsFromVobFrames(frames);
      const lastEndMs = built.events.length
        ? built.events[built.events.length - 1].endMs
        : 0;
      tracks.push({
        subTypeIndex: i,
        count: built.events.length,
        language:
          String(subStreams[i]?.tags?.language ?? "")
            .trim()
            .toLowerCase() || null,
        coverage:
          videoDurationMs > 0
            ? Math.min(1, lastEndMs / videoDurationMs)
            : built.events.length > 0
              ? 1
              : 0,
      });
    }
  }
  // VobSub packet counts are not reliable for every DVD stream. A forced or
  // malformed stream may report one packet even when it contains hundreds of
  // timed bitmap events. Repair only suspicious outliers by decoding frames;
  // this avoids OCR on every language while keeping the displayed counts real.
  const typicalCount = median(
    tracks.map((track) => track.count).filter((count) => count > 1),
  );
  for (const track of tracks) {
    // The second OCR pass pins the exact reference stream selected by the
    // first pass. Do not decode other tracks just to re-count them; their
    // packet counts have already been inspected and they will not be OCR'd.
    if (
      preferredSubTypeIndex !== undefined &&
      track.subTypeIndex !== preferredSubTypeIndex
    )
      continue;
    const suspicious =
      track.count <= 1 ||
      (typicalCount >= 20 && track.count < typicalCount * 0.1);
    if (!suspicious) continue;
    await progress(
      `字幕轨 ${track.subTypeIndex + 1}（${dvdSubtitleLanguageLabel(track.language)}）包数异常，正在校正实际字幕条数…`,
    );
    try {
      const repairedFrames = await decodeVobSubToFrames(
        mkvPath,
        track.subTypeIndex,
      );
      const repaired = buildEventsFromVobFrames(repairedFrames).events;
      if (repaired.length > track.count) {
        track.count = repaired.length;
        const lastEndMs = repaired[repaired.length - 1]?.endMs ?? 0;
        track.coverage =
          videoDurationMs > 0
            ? Math.min(1, lastEndMs / videoDurationMs)
            : repaired.length > 0
              ? 1
              : 0;
      }
    } catch {
      // Keep the probe value if the repair decode itself is unavailable.
    }
  }
  for (const track of tracks) {
    const blocked =
      track.language !== null && BLOCKED_OCR_LANGUAGES.has(track.language);
    await progress(
      `字幕轨 ${track.subTypeIndex + 1}：${dvdSubtitleLanguageLabel(track.language)}，约 ${track.count} 条，覆盖 ${Math.round(track.coverage * 100)}%${blocked ? "（默认跳过日语/韩语）" : ""}`,
    );
  }
  const chosen =
    preferredSubTypeIndex === undefined
      ? chooseDvdSubtitleTrack(tracks, preferredLanguage)
      : (tracks.find(
          (track) =>
            track.subTypeIndex === preferredSubTypeIndex && track.count > 0,
        ) ?? chooseDvdSubtitleTrack(tracks, preferredLanguage));
  // In the primary pass, choose a single foreign reference from the packet
  // counts gathered above. Decode/OCR only that chosen reference later; never
  // walk every foreign subtitle image stream for semantic comparison.
  const chineseTrack =
    preferredSubTypeIndex === undefined
      ? CHINESE_DVD_LANGUAGES.has(
          normalizeDvdSubtitleLanguage(chosen.language) ?? "",
        )
        ? chosen
        : (tracks.find((track) =>
            CHINESE_DVD_LANGUAGES.has(
              normalizeDvdSubtitleLanguage(track.language) ?? "",
            ),
          ) ?? null)
      : null;
  const referenceTrack = chineseTrack
    ? chooseDvdSubtitleReferenceTrack(tracks, chineseTrack)
    : null;
  await progress(
    referenceTrack
      ? `对照轨候选：${dvdSubtitleLanguageLabel(referenceTrack.language)}，约 ${referenceTrack.count} 条`
      : "未找到英语或字幕行数匹配的外语参考轨，将仅使用中文字幕 OCR 结果",
  );
  const frames = await decodeVobSubToFrames(mkvPath, chosen.subTypeIndex);
  await progress(
    `已选字幕轨：Track ${chosen.subTypeIndex + 1}（${dvdSubtitleLanguageLabel(chosen.language)}，${chosen.count} 条，覆盖 ${Math.round(chosen.coverage * 100)}%）`,
  );
  return {
    frames,
    subTypeIndex: chosen.subTypeIndex,
    streamLanguage: chosen.language,
    referenceTrack,
  };
}

async function decodeVobSubToFrames(
  mkvPath: string,
  preferredSubTypeIndex?: number,
): Promise<VobFrame[]> {
  const { execFile } = await import("node:child_process");
  const { promisify } = await import("node:util");
  const { mkdtemp, readdir, readFile, rm } = await import("node:fs/promises");
  const { tmpdir } = await import("node:os");
  const { join } = await import("node:path");
  const execFileAsync = promisify(execFile);
  const ffprobe = (await resolveToolPath("ffprobe")) ?? "ffprobe";
  const ffmpeg = (await resolveToolPath("ffmpeg")) ?? "ffmpeg";
  const probeOut = await execFileAsync(
    ffprobe,
    ["-v", "error", "-print_format", "json", "-show_streams", mkvPath],
    { timeout: 30_000 },
  );
  const parsed = JSON.parse(probeOut.stdout) as {
    streams?: Array<{
      index: number;
      codec_type?: string;
      codec_name?: string;
      width?: number;
      height?: number;
    }>;
  };
  const parsedStreams = parsed.streams ?? [];
  const subtitleStreams = parsedStreams.filter(
    (stream) => stream.codec_type === "subtitle",
  );
  const graphic = parsedStreams.find((stream) =>
    isDirectFrameGraphicCodec(String(stream.codec_name ?? "")),
  );
  if (!graphic)
    throw new Error("HandBrake 提取的 MKV 中没有可直接解码的图形字幕轨");
  // Filtergraph stream specifiers use the type-relative index (0-based among
  // subtitle streams), not the container stream index.
  const subTypeIndex =
    preferredSubTypeIndex ??
    subtitleStreams.findIndex((stream) => stream.index === graphic.index);
  if (subTypeIndex < 0) throw new Error("无法定位图形字幕轨序号");
  const video = parsedStreams.find((stream) => stream.codec_type === "video");
  const videoWidth = Number(video?.width) > 0 ? Number(video?.width) : 720;
  const videoHeight = Number(video?.height) > 0 ? Number(video?.height) : 480;
  const scaleW = videoWidth * 2;
  const scaleH = videoHeight * 2;
  const dir = await mkdtemp(join(tmpdir(), "vx-vob-"));
  try {
    await execFileAsync(
      ffmpeg,
      [
        "-v",
        "error",
        "-y",
        "-i",
        mkvPath,
        "-filter_complex",
        `[0:s:${subTypeIndex}]format=rgba,scale=${scaleW}:${scaleH}:flags=lanczos,settb=AVTB[s]`,
        "-map",
        "[s]",
        "-fps_mode",
        "vfr",
        "-frame_pts",
        "1",
        "-c:v",
        "png",
        "-f",
        "image2",
        join(dir, "frame_%d.png"),
      ],
      { timeout: 10 * 60_000 },
    );
    const files = await readdir(dir);
    const frames: VobFrame[] = [];
    for (const name of files) {
      const match = /^frame_(\d+)\.png$/.exec(name);
      if (!match) continue;
      const full = join(dir, name);
      const rawPng = await readFile(full);
      const decoded = decodePngRgba(rawPng);
      const png = encodePng(
        toBlackOnWhite(decoded.rgba, decoded.width, decoded.height),
        decoded.width,
        decoded.height,
      );
      frames.push({
        ptsMs: Math.round(Number(match[1]) / 1000),
        png,
        hash: createHash("md5").update(png).digest("hex"),
        size: png.length,
      });
    }
    frames.sort((a, b) => a.ptsMs - b.ptsMs);
    return frames;
  } finally {
    await rm(dir, { recursive: true, force: true }).catch(() => {});
  }
}

function buildEventsFromVobFrames(frames: VobFrame[]): {
  events: OcrEvent[];
  images: Array<{ index: number; png: Buffer }>;
} {
  if (frames.length === 0) return { events: [], images: [] };
  // The transparent "clear" bitmap is always the smallest identical frame set.
  const emptyHash = frames.reduce(
    (min, frame) => (frame.size < min.size ? frame : min),
    frames[0],
  ).hash;
  const events: OcrEvent[] = [];
  const images: Array<{ index: number; png: Buffer }> = [];
  let current: { startMs: number; hash: string; png: Buffer } | null = null;
  for (const frame of frames) {
    if (frame.hash === emptyHash) {
      if (current) {
        events.push({
          index: events.length,
          startMs: current.startMs,
          endMs: frame.ptsMs,
          text: "",
        });
        images.push({ index: events.length - 1, png: current.png });
        current = null;
      }
      continue;
    }
    if (!current) {
      current = { startMs: frame.ptsMs, hash: frame.hash, png: frame.png };
    } else if (current.hash !== frame.hash) {
      events.push({
        index: events.length,
        startMs: current.startMs,
        endMs: frame.ptsMs,
        text: "",
      });
      images.push({ index: events.length - 1, png: current.png });
      current = { startMs: frame.ptsMs, hash: frame.hash, png: frame.png };
    }
  }
  if (current) {
    events.push({
      index: events.length,
      startMs: current.startMs,
      endMs: current.startMs + 3000,
      text: "",
    });
    images.push({ index: events.length - 1, png: current.png });
  }
  return { events, images };
}

export async function runDvdVobSubOcr(
  params: {
    sourcePath: string;
    config: AiProviderConfig;
    engine?: OcrEngine;
    language?: string;
    localOnly?: boolean;
    preferredSubtitleLanguage?: string;
    preferredSubtitleTrackIndex?: number;
    titleId?: string | null;
    onProgress?: (message: string) => void;
  },
  target: DvdOcrTarget,
): Promise<OcrResult> {
  const progress = async (message: string) => {
    await params.onProgress?.(message);
  };
  await progress(
    "检测到 DVD 目录，正在提取全部 VobSub 字幕轨（首次需 HandBrake 转码，可能需 10-20 分钟）…",
  );
  const mkvPath = await extractDvdSubtitleMkvAll(target);
  const picked = await pickBestDvdSubtitleTrack(
    mkvPath,
    target,
    progress,
    params.preferredSubtitleLanguage ?? params.language,
    params.preferredSubtitleTrackIndex,
  );
  const result = await runVobSubOcr(
    params,
    mkvPath,
    picked.subTypeIndex,
    picked.streamLanguage,
    {
      frames: picked.frames,
      streamLanguage: picked.streamLanguage,
    },
  );
  return { ...result, dvdReferenceTrack: picked.referenceTrack };
}

export async function runVobSubOcr(
  params: {
    sourcePath: string;
    config: AiProviderConfig;
    engine?: OcrEngine;
    language?: string;
    localOnly?: boolean;
    titleId?: string | null;
    outputBaseName?: string;
    onProgress?: (message: string) => void;
  },
  videoPath: string,
  preferredSubTypeIndex?: number,
  streamLanguage?: string | null,
  preDecoded?: { frames: VobFrame[]; streamLanguage: string | null },
): Promise<OcrResult> {
  const progress = async (message: string) => {
    await params.onProgress?.(message);
  };
  const language = params.language ?? "auto";
  await progress("图形字幕轨已就绪，正在解码字幕画面…");
  const frames =
    preDecoded?.frames ??
    (await decodeVobSubToFrames(videoPath, preferredSubTypeIndex));
  const effectiveStreamLanguage = preDecoded?.streamLanguage ?? streamLanguage;
  const { events, images } = buildEventsFromVobFrames(frames);
  if (images.length === 0) throw new Error("图形字幕中未解析到字幕事件");
  const coverageStart = formatSrtTime(events[0]?.startMs ?? 0);
  const coverageEnd = formatSrtTime(events[events.length - 1]?.endMs ?? 0);
  await progress(
    `解析到 ${images.length} 条图形字幕（时间范围 ${coverageStart} → ${coverageEnd}），正在识别…`,
  );

  const { engine, ocrLanguage: preflightOcrLanguage } =
    await resolveOcrEngineAndLanguage({
      config: params.config,
      engine: params.engine,
      language,
      streamLanguage: effectiveStreamLanguage,
      localOnly: params.localOnly,
    });
  let ocrLanguage = preflightOcrLanguage;
  if (effectiveStreamLanguage && language === "auto") {
    await progress(
      `字幕轨语言标记：${effectiveStreamLanguage.toUpperCase()}，自动使用对应 OCR 语言`,
    );
  }
  if (
    engine === "tesseract" &&
    language === "auto" &&
    !effectiveStreamLanguage
  ) {
    const tesseractPath = await resolveToolPath("tesseract");
    if (tesseractPath) {
      ocrLanguage = await detectAutoTesseractLanguage(tesseractPath, images);
      await progress(`字幕轨无语言标记，自动检测 OCR 语言：${ocrLanguage}`);
    }
  }
  if (
    engine === "tesseract" &&
    (ocrLanguage === "chi_sim" || ocrLanguage === "chi_tra")
  ) {
    const tesseractPath = await resolveToolPath("tesseract");
    if (tesseractPath) {
      const variant = await detectChineseVariant(tesseractPath, images);
      if (variant !== ocrLanguage) {
        ocrLanguage = variant;
        await progress(
          `中文字幕检测为${variant === "chi_tra" ? "繁体" : "简体"}，切换 OCR 语言：${variant}`,
        );
      }
    }
  }
  let recognized: Array<{
    index: number;
    text: string;
    language: string;
    confidence?: number | null;
  }>;
  if (engine === "tesseract") {
    await progress(
      `正在使用本地 Tesseract（${ocrLanguage}）识别 ${images.length} 条字幕…`,
    );
    recognized = await ocrWithTesseract(images, ocrLanguage);
  } else if (engine === "llm") {
    await progress(`正在调用大模型识别 ${images.length} 条字幕…`);
    recognized = await ocrWithLlm(images, params.config, language);
  } else if (engine === "rapidocr") {
    await progress(
      `正在使用 RapidOCR（中文优化）识别 ${images.length} 条字幕…`,
    );
    recognized = await ocrWithRapidOcr(images);
  } else {
    throw new Error(`OCR 引擎 "${engine}" 尚未实现`);
  }

  const filled = events.map((event) => {
    const item = recognized.find((entry) => entry.index === event.index);
    return { ...event, text: item?.text ?? "" };
  });
  const detectedLanguage =
    language !== "auto"
      ? language
      : (recognized.find((item) => item.language !== "unknown")?.language ??
        detectScriptLanguage(filled.map((event) => event.text).join("\n")));
  const srtContent = assembleSrt(filled);
  if (!srtContent.trim()) throw new Error("OCR 识别结果为空");
  await validateOcrCompleteness({
    events: filled,
    label: "该字幕轨",
    onProgress: progress,
  });
  const quality = computeOcrQuality(recognized, images.length);
  const srtPath = await writeSrtBesideSource(
    params.sourcePath,
    srtContent,
    params.outputBaseName,
  );
  await progress(`已完成，生成 ${srtPath}`);
  return {
    srtPath,
    srtContent,
    events: filled,
    language: detectedLanguage,
    engine,
    qualityScore: quality.score,
    qualityConfidenceBased: quality.confidenceBased,
  };
}
