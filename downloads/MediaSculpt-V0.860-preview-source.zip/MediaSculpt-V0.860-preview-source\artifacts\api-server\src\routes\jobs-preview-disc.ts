import { Router } from "express";
import { appendRuntimeToolLog } from "../lib/runtime-tool-log";
import { resolveToolPath } from "../lib/tool-runtime";
import {
  buildDiscPreviewInputArgs,
  extractLastJpegFrame,
} from "../lib/disc-preview";
import type { DiscAnalysisResult } from "../lib/disc-analysis";
import {
  buildPreviewTranscodeArgs,
  previewService,
} from "../media/preview-service";
import { processRunner } from "../infrastructure/process-runner";
import { discAnalysisRegistry } from "../lib/disc-analysis-registry";
import { dvdVideoInputPath, ensureDvdCssSupport } from "./jobs-dvd";
import { ensureAnalysisIsoReady } from "./jobs-iso";
import { streamFfmpegPreview } from "./jobs-preview-stream";

const router = Router();
type DiscTitlePreviewCacheEntry = {
  previews: string[];
  createdAt: number;
  warning?: string;
  source: "cache" | "ffmpeg-validated-input" | "unavailable";
};

const discTitlePreviewCache = new Map<string, DiscTitlePreviewCacheEntry>();

function previewFallbackSvg(
  title: { displayName: string; durationSeconds: number | null },
  index = 1,
): string {
  const label =
    `${title.displayName} · ${title.durationSeconds ? Math.round(title.durationSeconds) + "s" : "时长未知"}`.replace(
      /[<&>]/g,
      "",
    );
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360"><rect width="640" height="360" fill="#07121f"/><path d="M280 145h80v70h-80z" fill="#1e9bcf" opacity=".65"/><path d="M314 160l32 20-32 20z" fill="#fff"/><text x="320" y="250" fill="#cbd5e1" font-family="sans-serif" font-size="18" text-anchor="middle">${label}</text><text x="320" y="280" fill="#64748b" font-family="sans-serif" font-size="13" text-anchor="middle">Title Preview ${index}</text><text x="320" y="305" fill="#64748b" font-family="sans-serif" font-size="13" text-anchor="middle">预览不可用，但不影响任务创建</text></svg>`;
  return `data:image/svg+xml;base64,${Buffer.from(svg).toString("base64")}`;
}

export function buildDiscTitlePreviewArgs(input: {
  analysis: DiscAnalysisResult;
  title: DiscAnalysisResult["titles"][number];
  offsetSeconds: number;
  ffmpeg: string;
}): {
  executable: string;
  args: string[];
  source: "ffmpeg-validated-input" | "unavailable";
  frameCount: number;
} {
  if (input.analysis.mediaType === "dvd" && !input.title.previewSourcePath) {
    const titleNumber = input.title.toolMappings.handbrakeTitleNumber;
    if (
      typeof titleNumber !== "number" ||
      !Number.isInteger(titleNumber) ||
      titleNumber <= 0
    )
      return {
        executable: input.ffmpeg,
        args: [],
        source: "unavailable",
        frameCount: 1,
      };
    // HandBrake is the sole title authority.  The FFmpeg fallback uses the
    // already verified dvdvideo input contract and the exact HandBrake title;
    // it never opens the VIDEO_TS directory as a generic media file.
    return {
      executable: input.ffmpeg,
      args: [
        "-hide_banner",
        "-loglevel",
        "error",
        ...buildDiscPreviewInputArgs({
          mediaType: "dvd",
          sourcePath: dvdVideoInputPath(input.analysis.sourcePath),
          handbrakeTitleNumber: titleNumber,
          offsetSeconds: Math.max(0, input.offsetSeconds),
        }),
        "-frames:v",
        "1",
        "-vf",
        "yadif,scale=640:-2",
        "-f",
        "image2pipe",
        "-vcodec",
        "mjpeg",
        "pipe:1",
      ],
      source: "ffmpeg-validated-input",
      frameCount: 1,
    };
  }
  // HandBrake titles point at the disc root; preview frames must come from a
  // real media file, so prefer the mapped m2ts preview source.
  const previewSourcePath =
    input.title.previewSourcePath ?? input.title.sourcePath;
  const titleDuration =
    input.title.durationSeconds && input.title.durationSeconds > 0
      ? input.title.durationSeconds
      : null;
  const safeOffset =
    titleDuration != null
      ? Math.min(
          Math.max(0, input.offsetSeconds),
          Math.max(0, titleDuration - 1),
        )
      : Math.max(0, input.offsetSeconds);
  // VC-1 Blu-ray streams often begin a random seek on a non-reference frame.
  // Decode a short warmup window from the mapped M2TS and use its last frame;
  // this is fast and avoids the multi-minute MPLS seek on slow optical drives.
  const vc1Warmup =
    input.analysis.mediaType === "bluray" &&
    Boolean(previewSourcePath) &&
    input.title.videoTracks.some(
      (stream) => stream.codecName?.toLowerCase() === "vc1",
    );
  return {
    executable: input.ffmpeg,
    args: [
      "-hide_banner",
      "-loglevel",
      "error",
      ...buildDiscPreviewInputArgs({
        mediaType: input.analysis.mediaType,
        sourcePath: input.analysis.sourcePath,
        previewSourcePath,
        previewSegments: input.title.previewSegments,
        playlistId: vc1Warmup ? null : input.title.toolMappings.playlistId,
        offsetSeconds: safeOffset,
      }),
      "-frames:v",
      String(vc1Warmup ? 180 : 1),
      "-vf",
      "yadif,scale=640:-2",
      "-f",
      "image2pipe",
      "-vcodec",
      "mjpeg",
      "pipe:1",
    ],
    source: "ffmpeg-validated-input",
    frameCount: vc1Warmup ? 180 : 1,
  };
}
async function renderDiscTitlePreviewFrame(
  executable: string,
  args: string[],
  frameCount = 1,
): Promise<{ data: Buffer; stderr: string; code: number | null }> {
  return new Promise((resolve) => {
    const managed = processRunner.spawn({
      executable,
      args,
      stage: "disc-title-preview",
      timeoutMs: 15_000,
    });
    const child = managed.child;
    const chunks: Buffer[] = [];
    let stderr = "";
    const timer = setTimeout(() => managed.kill("SIGKILL"), 15_000);
    child.stdout?.on("data", (chunk: Buffer) => chunks.push(chunk));
    child.stderr?.on("data", (chunk: Buffer) => {
      if (stderr.length < 64_000) stderr += chunk.toString();
    });
    child.once("error", () => {
      clearTimeout(timer);
      resolve({ data: Buffer.alloc(0), stderr: "FFmpeg 不可用", code: null });
    });
    child.once("close", (code) => {
      clearTimeout(timer);
      const data = Buffer.concat(chunks);
      resolve({
        data: frameCount > 1 ? extractLastJpegFrame(data) : data,
        stderr,
        code,
      });
    });
  });
}

// Generates cached low-resolution title images for the disc dialog.  Preview
// failures are deliberately non-blocking: title selection and task creation
// continue to use the HandBrake analysis and task snapshot.
router.get("/disc/title-preview", async (req, res) => {
  const analysisId = String(req.query.analysisId ?? "");
  const titleId = String(req.query.titleId ?? "");
  if (!analysisId || !titleId)
    return res.status(400).json({ error: "analysisId 和 titleId 不能为空" });
  const analysis = discAnalysisRegistry.find(analysisId);
  const title = analysis?.titles.find((item) => item.titleId === titleId);
  if (!analysis || !title)
    return res.status(404).json({ error: "标题分析结果已过期，请重新分析" });
  await ensureAnalysisIsoReady(analysis);

  const cacheKey = `${analysis.sourceFingerprint}:${titleId}`;
  const cached = discTitlePreviewCache.get(cacheKey);
  if (cached && Date.now() - cached.createdAt < 15 * 60_000)
    return res.json({
      url: cached.previews[0],
      previews: cached.previews,
      warning: cached.warning,
      source: cached.source,
      cached: true,
    });

  const ffmpeg = (await resolveToolPath("ffmpeg")) ?? "ffmpeg";
  if (analysis.mediaType === "dvd") await ensureDvdCssSupport(ffmpeg);
  const duration =
    title.durationSeconds && title.durationSeconds > 0
      ? title.durationSeconds
      : 0;
  // Preview frames follow the chapter list (one frame per chapter, capped),
  // so the dialog shows one preview per chapter. Titles without chapters get
  // two frames at 25% / 75% so the preview area is never empty.
  const MAX_PREVIEWS = 6;
  const chapters = Array.isArray(title.chapters) ? title.chapters : [];
  // Only trust chapter positions when they actually span the title. Some
  // authored discs carry broken chapter timestamps (e.g. all within the first
  // seconds), which would produce a row of identical opening frames.
  const lastChapterEnd = chapters.reduce(
    (max, chapter) => Math.max(max, Number(chapter.endSeconds ?? 0)),
    0,
  );
  const chaptersCoverTitle = duration > 0 && lastChapterEnd >= duration * 0.5;
  let offsets: number[];
  if (chapters.length > 0 && chaptersCoverTitle) {
    offsets = chapters.slice(0, MAX_PREVIEWS).map((chapter) => {
      const start = Number(chapter.startSeconds ?? 0);
      const end = Number(chapter.endSeconds ?? start);
      const frameOffset =
        end > start ? start + Math.max(0.5, (end - start) * 0.25) : start + 0.5;
      return duration > 0
        ? Math.min(frameOffset, Math.max(0, duration - 0.01))
        : frameOffset;
    });
  } else if (duration > 0) {
    offsets = [Math.max(0, duration * 0.25), Math.max(0, duration * 0.75)];
  } else {
    offsets = [0];
  }
  const previews: string[] = [];
  const diagnostics: string[] = [];
  let source: DiscTitlePreviewCacheEntry["source"] = "unavailable";
  for (const [index, offsetSeconds] of offsets.entries()) {
    const command = buildDiscTitlePreviewArgs({
      analysis,
      title,
      offsetSeconds,
      ffmpeg,
    });
    if (!command.args.length) {
      diagnostics.push(`preview-${index + 1}: 没有有效标题编号`);
      previews.push(previewFallbackSvg(title, index + 1));
      continue;
    }
    const output = await renderDiscTitlePreviewFrame(
      command.executable,
      command.args,
      command.frameCount,
    );
    if (output.code === 0 && output.data.length > 128) {
      previews.push(`data:image/jpeg;base64,${output.data.toString("base64")}`);
      source = command.source;
    } else {
      diagnostics.push(
        `preview-${index + 1}: exit=${output.code ?? "n/a"} ${output.stderr.trim().slice(-300)}`,
      );
      previews.push(previewFallbackSvg(title, index + 1));
    }
  }
  const allFallback = previews.every((preview) =>
    preview.startsWith("data:image/svg+xml"),
  );
  const warning = allFallback
    ? "预览不可用，但不影响任务创建"
    : diagnostics.length > 0
      ? "部分预览不可用，但不影响任务创建"
      : undefined;
  if (allFallback) source = "unavailable";
  const entry = {
    previews,
    createdAt: Date.now(),
    warning,
    source,
  } satisfies DiscTitlePreviewCacheEntry;
  discTitlePreviewCache.set(cacheKey, entry);
  await appendRuntimeToolLog(
    `标题预览 title=${titleId} source=${source} tool=${ffmpeg} frames=${previews.length} warning=${warning ?? "none"} diagnostics=${diagnostics.join(" | ") || "none"}`,
  ).catch(() => {});
  return res.json({
    url: previews[0],
    previews,
    warning,
    source,
    cached: false,
  });
});

// 光盘标题预览元信息（时长），供播放器校准进度条/时长显示。
router.get("/disc/title-preview/meta", async (req, res) => {
  const analysisId =
    typeof req.query.analysisId === "string" ? req.query.analysisId : "";
  const titleId =
    typeof req.query.titleId === "string" ? req.query.titleId : "";
  if (!analysisId || !titleId)
    return res.status(400).json({ error: "analysisId 和 titleId 不能为空" });
  const analysis = discAnalysisRegistry.find(analysisId);
  const title = analysis?.titles.find((item) => item.titleId === titleId);
  if (!analysis || !title)
    return res.status(404).json({ error: "标题分析结果已过期，请重新分析" });
  return res.json({ durationSeconds: title.durationSeconds ?? null });
});

// 光盘标题预览流（批量确认阶段无需任务即可预览）；DVD 与缩略图共用实体 VTS 输入。
router.get("/disc/title-preview.mp4", async (req, res) => {
  const analysisId =
    typeof req.query.analysisId === "string" ? req.query.analysisId : "";
  const titleId =
    typeof req.query.titleId === "string" ? req.query.titleId : "";
  if (!analysisId || !titleId)
    return res.status(400).json({ error: "analysisId 和 titleId 不能为空" });
  const analysis = discAnalysisRegistry.find(analysisId);
  const title = analysis?.titles.find((item) => item.titleId === titleId);
  if (!analysis || !title)
    return res.status(404).json({ error: "标题分析结果已过期，请重新分析" });
  await ensureAnalysisIsoReady(analysis);
  const seekRaw = typeof req.query.seek === "string" ? req.query.seek : "";
  const seekSeconds = Number(seekRaw);
  const hasSeek =
    seekRaw !== "" && Number.isFinite(seekSeconds) && seekSeconds > 0;
  const ffmpegExecutable =
    (await resolveToolPath("ffmpeg").catch(() => null)) ?? "ffmpeg";
  if (analysis.mediaType === "dvd") await ensureDvdCssSupport(ffmpegExecutable);
  let inputArgs: string[];
  let transcodeArgs: string[];
  if (analysis.mediaType === "dvd") {
    const titleNumber = title.toolMappings.handbrakeTitleNumber;
    if (
      typeof titleNumber !== "number" ||
      !Number.isInteger(titleNumber) ||
      titleNumber <= 0
    ) {
      return res
        .status(400)
        .json({ error: "该标题没有有效的 HandBrake 标题编号，无法预览" });
    }
    const previewSourcePath = title.previewSourcePath ?? null;
    inputArgs = [
      "-hide_banner",
      "-loglevel",
      "error",
      "-fflags",
      "+genpts",
      ...buildDiscPreviewInputArgs({
        mediaType: "dvd",
        sourcePath: analysis.sourcePath,
        previewSourcePath,
        handbrakeTitleNumber: titleNumber,
        offsetSeconds: hasSeek ? seekSeconds : 0,
      }),
    ];
    transcodeArgs = buildPreviewTranscodeArgs(false, null);
  } else {
    const previewSourcePath = title.previewSourcePath ?? title.sourcePath;
    if (!previewSourcePath)
      return res.status(404).json({ error: "该标题没有可预览的媒体文件" });
    inputArgs = [
      "-hide_banner",
      "-loglevel",
      "error",
      "-fflags",
      "+genpts",
      ...buildDiscPreviewInputArgs({
        mediaType: analysis.mediaType,
        sourcePath: analysis.sourcePath,
        previewSourcePath,
        previewSegments: title.previewSegments,
        playlistId: title.toolMappings.playlistId,
        offsetSeconds: hasSeek ? seekSeconds : 0,
      }),
    ];
    // 蓝光标题支持按字幕轨烧录预览（?sub=容器轨索引）。
    const subRaw = typeof req.query.sub === "string" ? req.query.sub : "";
    const subIndex = Number(subRaw);
    const hasSub = subRaw !== "" && Number.isInteger(subIndex) && subIndex >= 0;
    let subTypeIndex: number | null = null;
    if (hasSub) {
      const containerIndices =
        await previewService.subtitleContainerIndices(previewSourcePath);
      const found = containerIndices.indexOf(subIndex);
      subTypeIndex = found >= 0 ? found : null;
    }
    transcodeArgs = buildPreviewTranscodeArgs(hasSub, subTypeIndex);
  }
  return streamFfmpegPreview(res, ffmpegExecutable, [
    ...inputArgs,
    ...transcodeArgs,
  ]);
});
export const discPreviewRouter = router;
