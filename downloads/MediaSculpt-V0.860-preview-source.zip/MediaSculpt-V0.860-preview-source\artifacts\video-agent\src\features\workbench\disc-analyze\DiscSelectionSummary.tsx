import type { ReactNode } from "react";
import { useI18n } from "@/i18n";
import type { ScanCopy } from "@/pages/Scan";
import type { DiscTrackWithMakeMkv } from "../disc-display-model";
import { countSelectedTrackStreams } from "../disc-selection-model";

export type DiscSelectionSummaryProps = {
  uiText: ScanCopy;
  selectedTrack: DiscTrackWithMakeMkv | undefined;
  selectedTitleCount: number;
  selectedTrackIndices: Set<number>;
  selectedStreamIndices: Set<number>;
  selectedChapterIds: Set<number>;
  verifyingTracks: Set<number>;
  processingLabel: string;
  analysisOnly: boolean;
  onSetAllStreamsForSelectedTitles: (selected: boolean) => void;
  expandedControls: ReactNode;
};

export function DiscSelectionSummary({
  uiText,
  selectedTrack,
  selectedTitleCount,
  selectedTrackIndices,
  selectedStreamIndices,
  selectedChapterIds,
  verifyingTracks,
  processingLabel,
  analysisOnly,
  onSetAllStreamsForSelectedTitles,
  expandedControls,
}: DiscSelectionSummaryProps) {
  const { t } = useI18n();

  return (
    <div className="flex h-full min-h-[220px] max-lg:h-[120px] max-lg:min-h-0 min-w-0 flex-col overflow-visible max-lg:overflow-y-auto rounded-lg border bg-secondary/10 p-3 text-xs">
      <div className="mb-2 flex items-center justify-between gap-2">
        <div className="font-medium">{t("scan.selectionSummary")}</div>
        <div className="flex shrink-0 gap-1">
          <button
            type="button"
            className="rounded border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-secondary/50 disabled:cursor-not-allowed disabled:opacity-40"
            onClick={() => onSetAllStreamsForSelectedTitles(true)}
            disabled={
              selectedTitleCount === 0 ||
              Array.from(selectedTrackIndices).some((idx) =>
                verifyingTracks.has(idx),
              )
            }
          >
            {uiText.selectAllStreams}
          </button>
          <button
            type="button"
            className="rounded border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-secondary/50 disabled:cursor-not-allowed disabled:opacity-40"
            onClick={() => onSetAllStreamsForSelectedTitles(false)}
            disabled={selectedTitleCount === 0}
          >
            {uiText.clearAllStreams}
          </button>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 text-muted-foreground">
        <span>
          {t("scan.summaryTitle")}
          {selectedTitleCount}
        </span>
        <span>
          {t("scan.summaryVideo")}
          {countSelectedTrackStreams(
            selectedTrack,
            selectedStreamIndices,
            "video",
          )}
        </span>
        <span>
          {t("scan.summaryAudio")}
          {countSelectedTrackStreams(
            selectedTrack,
            selectedStreamIndices,
            "audio",
          )}
        </span>
        <span>
          {t("scan.summarySubtitle")}
          {countSelectedTrackStreams(
            selectedTrack,
            selectedStreamIndices,
            "subtitle",
          )}
        </span>
        <span>
          {t("scan.summaryChapters")}
          {selectedChapterIds.size}
        </span>
        {!analysisOnly && (
          <span>
            {t("scan.summaryMode")}
            {processingLabel}
          </span>
        )}
      </div>
      <div className="mt-3">{expandedControls}</div>
      <div className="mt-3 rounded border border-primary/20 bg-primary/5 p-2 text-muted-foreground">
        {t("scan.outputNamingHint")}
      </div>
    </div>
  );
}
