import { isGraphicSubtitleCodec } from "../lib/subtitle-utils";
import type { MediaPipelineManifest } from "./media-pipeline-contract";

export type SubtitlePipelineMode =
  | "auto"
  | "ocr"
  | "whisper"
  | "translate-text"
  | "skip";
export type SubtitlePipelineStrategy =
  | "keep-chinese"
  | "translate-text"
  | "ocr-graphic"
  | "whisper-audio"
  | "none";

export type SubtitlePipelineDecision = Readonly<{
  strategy: SubtitlePipelineStrategy;
  sourceSubtitleId: string | null;
  sourceAudioId: string | null;
  runOcr: boolean;
  runWhisper: boolean;
  translate: boolean;
  preserveOriginal: boolean;
  targetLanguage: string;
  rationale: string;
  warning?: string;
}>;

const TEXT_CODECS = new Set([
  "subrip",
  "srt",
  "ass",
  "ssa",
  "webvtt",
  "mov_text",
  "text",
  "tx3g",
]);

function normalized(value: string | null | undefined): string {
  return (value ?? "").trim().toLowerCase();
}

function isChinese(language: string | null | undefined): boolean {
  const value = normalized(language);
  return (
    ["zh", "zho", "chi", "cmn", "yue", "chinese"].includes(value) ||
    value.startsWith("zh-")
  );
}

function decision(
  input: Omit<SubtitlePipelineDecision, "targetLanguage"> & {
    targetLanguage: string;
  },
): SubtitlePipelineDecision {
  return Object.freeze(input);
}

export function decideSubtitlePipeline(input: {
  manifest: MediaPipelineManifest;
  mode?: SubtitlePipelineMode;
  targetLanguage?: string;
  ocrFailed?: boolean;
}): SubtitlePipelineDecision {
  const mode = input.mode ?? "auto";
  const targetLanguage = input.targetLanguage ?? "zh-CN";
  const streamsById = new Map(
    input.manifest.title.streams.map((stream) => [stream.id, stream]),
  );
  const subtitles = input.manifest.selection.subtitleStreamIds
    .map((id) => streamsById.get(id))
    .filter((stream): stream is NonNullable<typeof stream> => Boolean(stream));
  const audios = input.manifest.selection.audioStreamIds
    .map((id) => streamsById.get(id))
    .filter((stream): stream is NonNullable<typeof stream> => Boolean(stream));
  const text = subtitles.filter((stream) =>
    TEXT_CODECS.has(normalized(stream.codec)),
  );
  const graphic = subtitles.find((stream) =>
    isGraphicSubtitleCodec(stream.codec ?? ""),
  );
  const chineseText = text.find((stream) => isChinese(stream.language));
  const foreignText = text.find((stream) => !isChinese(stream.language));
  const audio = audios[0];

  if (mode === "skip") {
    return decision({
      strategy: "none",
      sourceSubtitleId: null,
      sourceAudioId: null,
      runOcr: false,
      runWhisper: false,
      translate: false,
      preserveOriginal: false,
      targetLanguage,
      rationale: "用户选择跳过字幕处理。",
    });
  }
  if (mode === "whisper") {
    if (!audio) throw new Error("Whisper 模式需要至少一个已选择的音轨");
    return decision({
      strategy: "whisper-audio",
      sourceSubtitleId: null,
      sourceAudioId: audio.id,
      runOcr: false,
      runWhisper: true,
      translate: true,
      preserveOriginal: true,
      targetLanguage,
      rationale: "用户明确要求从选定音轨进行语音识别和翻译。",
    });
  }
  if (mode === "ocr") {
    if (!graphic) throw new Error("OCR 模式需要至少一个已选择的图形字幕轨");
    return decision({
      strategy: "ocr-graphic",
      sourceSubtitleId: graphic.id,
      sourceAudioId: null,
      runOcr: true,
      runWhisper: false,
      translate: true,
      preserveOriginal: true,
      targetLanguage,
      rationale: "用户明确要求对选定图形字幕进行 OCR、纠错和翻译。",
      ...(input.ocrFailed
        ? { warning: "OCR 未成功；保留原图形字幕，不转入 Whisper。" }
        : {}),
    });
  }
  if (mode === "translate-text") {
    if (!foreignText)
      throw new Error("文字字幕翻译模式需要至少一个已选择的外语文字字幕轨");
    return decision({
      strategy: "translate-text",
      sourceSubtitleId: foreignText.id,
      sourceAudioId: null,
      runOcr: false,
      runWhisper: false,
      translate: true,
      preserveOriginal: true,
      targetLanguage,
      rationale: "用户明确要求翻译已选择的外语文字字幕。",
    });
  }
  if (chineseText) {
    return decision({
      strategy: "keep-chinese",
      sourceSubtitleId: chineseText.id,
      sourceAudioId: null,
      runOcr: false,
      runWhisper: false,
      translate: false,
      preserveOriginal: true,
      targetLanguage,
      rationale: "已存在中文字幕，保留原字幕，不重复识别或翻译。",
    });
  }
  if (foreignText) {
    return decision({
      strategy: "translate-text",
      sourceSubtitleId: foreignText.id,
      sourceAudioId: null,
      runOcr: false,
      runWhisper: false,
      translate: true,
      preserveOriginal: true,
      targetLanguage,
      rationale: "已存在外语文字字幕，直接翻译，不运行 OCR 或 Whisper。",
    });
  }
  if (graphic) {
    return decision({
      strategy: "ocr-graphic",
      sourceSubtitleId: graphic.id,
      sourceAudioId: null,
      runOcr: true,
      runWhisper: false,
      translate: true,
      preserveOriginal: true,
      targetLanguage,
      rationale:
        "发现图形字幕，优先 OCR、纠错和翻译；无论 OCR 是否成功都不改走 Whisper。",
      ...(input.ocrFailed
        ? { warning: "OCR 未成功；保留原图形字幕，不转入 Whisper。" }
        : {}),
    });
  }
  if (audio) {
    return decision({
      strategy: "whisper-audio",
      sourceSubtitleId: null,
      sourceAudioId: audio.id,
      runOcr: false,
      runWhisper: true,
      translate: true,
      preserveOriginal: true,
      targetLanguage,
      rationale: "没有可用字幕，才从选定主音轨进行语音识别和翻译。",
    });
  }
  return decision({
    strategy: "none",
    sourceSubtitleId: null,
    sourceAudioId: null,
    runOcr: false,
    runWhisper: false,
    translate: false,
    preserveOriginal: false,
    targetLanguage,
    rationale: "没有可用字幕或音轨，明确跳过字幕处理。",
  });
}
