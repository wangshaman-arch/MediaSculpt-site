const NETWORK_PATH_EXAMPLES = [
  "\\\\NAS\\Movies",
  "\\\\192.168.1.10\\video",
] as const;

export function networkPathExamples(): string[] {
  return [...NETWORK_PATH_EXAMPLES];
}
