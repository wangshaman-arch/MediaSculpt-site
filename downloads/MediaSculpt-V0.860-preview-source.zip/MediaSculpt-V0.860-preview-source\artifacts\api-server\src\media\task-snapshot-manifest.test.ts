import { describe, expect, it } from "vitest";
import type {
  DiscAnalysisStream,
  UnifiedDiscTitle,
} from "../lib/disc-analysis";
import type { TaskSnapshotV1 } from "../lib/task-snapshot";
import { buildMediaPipelineManifestFromSnapshot } from "./task-snapshot-manifest";

const STREAMS: DiscAnalysisStream[] = [
  {
    index: 0,
    codecType: "video",
    codecName: "mpeg2video",
    language: null,
    title: null,
    handbrakeTrackNumber: null,
  },
  {
    index: 1,
    codecType: "audio",
    codecName: "ac3",
    language: "en",
    title: "English",
    handbrakeTrackNumber: 1,
  },
  {
    index: 2,
    codecType: "subtitle",
    codecName: "dvd_subtitle",
    language: "en",
    title: null,
    handbrakeTrackNumber: 2,
  },
];

function title(overrides: Partial<UnifiedDiscTitle> = {}): UnifiedDiscTitle {
  return {
    titleId: "handbrake:1",
    titleIndex: 0,
    sourcePath: "D:\\DVD",
    displayName: "Movie",
    durationSeconds: 5_400,
    chapterCount: 2,
    chapters: [
      { id: 1, startSeconds: 0, endSeconds: 2_700, title: "Part 1" },
      { id: 2, startSeconds: 2_700, endSeconds: 5_400, title: "Part 2" },
    ],
    videoTracks: [STREAMS[0]],
    audioTracks: [STREAMS[1]],
    subtitleTracks: [STREAMS[2]],
    estimatedSize: null,
    streams: STREAMS,
    toolMappings: {
      handbrakeTitleNumber: 1,
      makemkvTitleIndex: null,
      playlistId: null,
      dvdVtsNumber: 7,
    },
    mappingStatus: "not-required",
    ...overrides,
  };
}

function snapshot(overrides: Partial<TaskSnapshotV1> = {}): TaskSnapshotV1 {
  return {
    snapshotVersion: 1,
    analysisId: "disc-abc",
    sourcePath: "D:\\DVD",
    sourceFingerprint: "dvd-fp-1",
    sourceType: "dvd",
    selectedTitleId: "handbrake:1",
    outputMode: "remux",
    compressionSourceStrategy: "auto",
    toolSelections: {
      handbrakeTitleNumber: 1,
      makemkvTitleIndex: null,
      playlistId: null,
      dvdVtsNumber: 7,
      remuxExportCandidateIndex: null,
    },
    streamSelection: {
      videoTrackIds: ["stream:0"],
      audioTrackIds: ["stream:1"],
      subtitleTrackIds: ["stream:2"],
    },
    chapterSelection: { mode: "all", start: null, end: null, chapterIds: [] },
    remux: { container: "mkv" },
    compression: {
      encoder: "x265",
      crf: 20,
      resolution: "1080p",
      preset: "slow",
      audioCopy: true,
      frameRate: "same",
      outputFormat: "mkv",
      deinterlace: false,
    },
    whisper: { inputSource: "original-title", language: "zh", model: "medium" },
    output: {
      directory: "D:\\Output",
      fileName: "Movie.mkv",
      format: "mkv",
      subtitleDirectory: null,
    },
    toolVersions: {
      handbrake: null,
      makemkv: null,
      ffmpeg: null,
      whisper: null,
      configVersion: "config-x",
    },
    createdAt: "2026-09-15T00:00:00.000Z",
    ...overrides,
  };
}

describe("task snapshot → media pipeline manifest", () => {
  it("maps source, verified title number, output naming and physical capacity", () => {
    const manifest = buildMediaPipelineManifestFromSnapshot({
      snapshot: snapshot(),
      title: title(),
      physicalBytes: 7_000_000_000,
    });

    expect(manifest.source.kind).toBe("dvd");
    expect(manifest.source.path).toBe("D:\\DVD");
    expect(manifest.source.fingerprint).toBe("dvd-fp-1");
    expect(manifest.source.physicalBytes).toBe(7_000_000_000);
    expect(manifest.title.titleNumber).toBe(7);
    expect(manifest.title.durationSeconds).toBe(5_400);
    expect(manifest.output.mode).toBe("remux");
    expect(manifest.output.directory).toBe("D:\\Output");
    expect(manifest.output.fileName).toBe("Movie.mkv");
    // Source capacity must never be reused as the output size estimate.
    expect(manifest.output.estimatedBytes).toBeNull();
  });

  it("carries codec, language and HandBrake track numbers from the verified title", () => {
    const manifest = buildMediaPipelineManifestFromSnapshot({
      snapshot: snapshot(),
      title: title(),
    });
    const audio = manifest.title.streams.find(
      (stream) => stream.id === "stream:1",
    );
    const subtitle = manifest.title.streams.find(
      (stream) => stream.id === "stream:2",
    );

    expect(audio).toMatchObject({
      type: "audio",
      codec: "ac3",
      language: "en",
      handbrakeTrackNumber: 1,
    });
    expect(subtitle).toMatchObject({
      type: "subtitle",
      codec: "dvd_subtitle",
      handbrakeTrackNumber: 2,
    });
    expect(manifest.selection.videoStreamIds).toEqual(["stream:0"]);
    expect(manifest.selection.audioStreamIds).toEqual(["stream:1"]);
    expect(manifest.selection.subtitleStreamIds).toEqual(["stream:2"]);
  });

  it("resolves the full chapter selection from the verified title", () => {
    const manifest = buildMediaPipelineManifestFromSnapshot({
      snapshot: snapshot(),
      title: title(),
    });
    expect(manifest.selection.chapterIds).toEqual([1, 2]);
  });

  it("keeps an explicit chapter subset and rejects unknown chapters", () => {
    const selected = buildMediaPipelineManifestFromSnapshot({
      snapshot: snapshot({
        chapterSelection: {
          mode: "selected",
          start: null,
          end: null,
          chapterIds: ["chapter:2"],
        },
      }),
      title: title(),
    });
    expect(selected.selection.chapterIds).toEqual([2]);

    expect(() =>
      buildMediaPipelineManifestFromSnapshot({
        snapshot: snapshot({
          chapterSelection: {
            mode: "selected",
            start: null,
            end: null,
            chapterIds: ["chapter:9"],
          },
        }),
        title: title(),
      }),
    ).toThrow("不存在的章节");
  });

  it("falls back to the persisted selection plan for DVD audio codecs without a title", () => {
    const manifest = buildMediaPipelineManifestFromSnapshot({
      snapshot: snapshot(),
      selectionPlan: JSON.stringify({
        audioStreams: [{ inputIndex: 1, codecName: "ac3" }],
      }),
    });
    expect(
      manifest.title.streams.find((stream) => stream.id === "stream:1")?.codec,
    ).toBe("ac3");
  });

  it("maps the remaining output modes and never reuses snapshot ids as stream ids", () => {
    const compress = buildMediaPipelineManifestFromSnapshot({
      snapshot: snapshot({ outputMode: "compress" }),
      title: title(),
    });
    expect(compress.output.mode).toBe("compress");

    const subtitle = buildMediaPipelineManifestFromSnapshot({
      snapshot: snapshot({ outputMode: "subtitle" }),
      title: title(),
    });
    expect(subtitle.output.mode).toBe("subtitle");

    const whisper = buildMediaPipelineManifestFromSnapshot({
      snapshot: snapshot({ outputMode: "whisper" }),
      title: title(),
    });
    expect(whisper.output.mode).toBe("subtitle");
  });

  it("rejects output modes that cannot be represented by one manifest", () => {
    expect(() =>
      buildMediaPipelineManifestFromSnapshot({
        snapshot: snapshot({ outputMode: "both" }),
      }),
    ).toThrow("both 模式");
    expect(() =>
      buildMediaPipelineManifestFromSnapshot({
        snapshot: snapshot({ outputMode: "audio" }),
      }),
    ).toThrow("audio 模式");
  });

  it("uses the resolved runtime source path when the route supplies one", () => {
    const manifest = buildMediaPipelineManifestFromSnapshot({
      snapshot: snapshot(),
      title: title(),
      sourcePath: "D:\\Rips\\Bonzo\\VIDEO_TS",
    });
    expect(manifest.source.path).toBe("D:\\Rips\\Bonzo\\VIDEO_TS");
  });

  it("uses the HandBrake title number for Blu-ray so compression encodes the right title", () => {
    const manifest = buildMediaPipelineManifestFromSnapshot({
      snapshot: snapshot({
        sourceType: "bluray",
        toolSelections: {
          ...snapshot().toolSelections,
          dvdVtsNumber: null,
          handbrakeTitleNumber: 3,
        },
      }),
      title: title({ titleId: "handbrake:3" }),
    });
    expect(manifest.source.kind).toBe("bluray");
    expect(manifest.title.titleNumber).toBe(3);

    const noTitle = buildMediaPipelineManifestFromSnapshot({
      snapshot: snapshot({
        sourceType: "bluray",
        toolSelections: {
          ...snapshot().toolSelections,
          dvdVtsNumber: null,
          handbrakeTitleNumber: null,
        },
      }),
      title: title({ titleId: "mpls:00000" }),
    });
    expect(noTitle.title.titleNumber).toBeNull();
  });
});
