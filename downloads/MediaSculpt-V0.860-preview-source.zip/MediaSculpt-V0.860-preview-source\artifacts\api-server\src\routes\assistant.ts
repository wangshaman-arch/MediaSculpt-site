import { Router } from "express";
import { db, jobsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getConfig } from "./jobs-config";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import {
  buildTuningLogicContext,
  parseCustomTuning,
  resolveLogicPlaceholders,
} from "../lib/custom-tuning";
import {
  bindPosterIdentityToUrl,
  ensureLocalPoster,
  findPosterCandidatesByOnline,
  isTrustedPosterSource,
  orderPosterCandidates,
  prioritizePosterCandidates,
  MEDIA_INFO_DIR,
  type PosterCandidate,
} from "../lib/poster";
import { resolvePosterProxyUrl } from "../lib/http-client";
import {
  lookupAll,
  mergeMetadataByIdentity,
  metadataIdentityMatches,
  normalizeTitleEn,
  parseFilename,
  searchImdbByTconst,
  searchImdbLocal,
  searchImdbTitlePage,
  type MetadataResult,
} from "../lib/metadata";
import {
  persistResolvedMetadata,
  resolveFromCache,
  tierForResolution,
} from "../lib/metadata-cache";
import {
  applyAiEnrichment,
  buildAiEnrichmentPrompt,
  missingEnrichableFields,
} from "../lib/metadata-ai";
import {
  buildAssistantMetadataSnapshot,
  buildAuthoritativeMetadataBlock,
  type AssistantMetadataSnapshot,
} from "../lib/assistant-summary";
import {
  extractAssistantImdbId,
  extractAssistantMetadata,
  extractAssistantOverview,
} from "../lib/assistant-overview";
import { resolveAssistantImdbId } from "../lib/assistant-identity";
import { mediaInfoDirectoryForSource } from "../lib/source-path";
import { recordPreviewAiCall } from "../lib/preview-runtime";

const router = Router();

/** 从上下文路径提取用于展示/检索的源名称（文件去扩展名；DVD/蓝光取影片文件夹名）。 */
function sourceNameFromPath(rawPath: string): string {
  const parts = rawPath.split(/[\\/]/).filter(Boolean);
  const last = parts[parts.length - 1] ?? "";
  if (/^(VIDEO_TS|BDMV|DVD|AUDIO_TS)$/i.test(last))
    return parts[parts.length - 2] ?? last;
  return last.replace(/\.[^.]+$/, "") || last;
}

/** 海报保存目录：文件 → 所在目录；目录 → 自身；VIDEO_TS/BDMV 等 → 上层影片目录；统一放进 MediaInfo 子目录。 */
function posterDirectoryForSource(rawPath: string): string {
  return mediaInfoDirectoryForSource(rawPath, MEDIA_INFO_DIR);
}

/** Persist only fields supplied by a title/year/IMDb-verified provider result. */
async function persistVerifiedJobMetadata(
  jobIdValue: unknown,
  metadata: MetadataResult,
  posterUrl: string | null,
): Promise<void> {
  const jobId = Number(jobIdValue);
  if (!Number.isInteger(jobId) || jobId <= 0) return;
  const patch: Partial<typeof jobsTable.$inferInsert> = {};
  if (metadata.titleEn || metadata.title)
    patch.movieTitleEn = metadata.titleEn || metadata.title;
  if (metadata.year !== undefined) patch.movieYear = metadata.year;
  if (metadata.imdbId && /^tt\d{7,8}$/i.test(metadata.imdbId))
    patch.movieImdbId = metadata.imdbId;
  if (metadata.rating !== undefined) patch.movieRating = metadata.rating;
  if (metadata.director) patch.movieDirector = metadata.director;
  if (metadata.genres) patch.movieGenres = metadata.genres;
  if (metadata.overview) patch.movieOverview = metadata.overview;
  const metadataSnapshot = buildAssistantMetadataSnapshot(metadata);
  if (metadataSnapshot) patch.movieMetadata = JSON.stringify(metadataSnapshot);
  if (posterUrl) patch.moviePoster = posterUrl;
  if (metadata.tmdbId !== undefined) patch.tmdbId = metadata.tmdbId;
  if (Object.keys(patch).length === 0) return;
  await db.update(jobsTable).set(patch).where(eq(jobsTable.id, jobId));
}

/** 本地资料卡：LLM 简介为空或失败时也能给出规范片名、年代与来源技术信息。 */
function buildLocalInfoCard(params: {
  sourcePath: string;
  standardTitle: string;
  year?: number | null;
  sourceType?: string;
  durationSeconds?: number;
  audioTracks?: number;
  subtitleTracks?: number;
  metadataOverview?: string;
  metadataGenres?: string;
  metadataRating?: number;
  metadataRuntime?: number;
  metadataSource?: string;
  metadataImdbId?: string | null;
  metadataDoubanId?: string | null;
  metadataDoubanRating?: number | null;
  metadataRottenTomatoesRating?: number | null;
  metadataMetacriticRating?: number | null;
  metadataDirector?: string | null;
  metadataCast?: string | null;
}): string {
  const lines: string[] = [];
  const sourceName = sourceNameFromPath(params.sourcePath);
  lines.push(`来源名称：${sourceName}`);
  if (params.standardTitle) lines.push(`规范化名称：${params.standardTitle}`);
  lines.push(`发行年代：${params.year ?? "待确认"}`);
  if (params.sourceType)
    lines.push(`来源类型：${params.sourceType.toUpperCase()}`);
  if (params.metadataGenres) lines.push(`类型：${params.metadataGenres}`);
  if (params.metadataDirector) lines.push(`导演：${params.metadataDirector}`);
  if (params.metadataCast) lines.push(`主要演员：${params.metadataCast}`);
  if (params.metadataRuntime)
    lines.push(`片长：${params.metadataRuntime} 分钟`);
  if (typeof params.metadataRating === "number" && params.metadataRating > 0)
    lines.push(`评分：${params.metadataRating.toFixed(1)}`);
  const authoritative = buildAuthoritativeMetadataBlock({
    imdbId: params.metadataImdbId,
    doubanId: params.metadataDoubanId,
    rating: params.metadataRating,
    ratingLabel:
      params.metadataSource === "imdb" || params.metadataSource === "omdb"
        ? "IMDb评分"
        : "资料评分",
    doubanRating: params.metadataDoubanRating,
    rottenTomatoesRating: params.metadataRottenTomatoesRating,
    metacriticRating: params.metadataMetacriticRating,
  });
  if (authoritative) {
    lines.push("");
    lines.push(authoritative);
  }
  if (
    typeof params.durationSeconds === "number" &&
    params.durationSeconds > 0
  ) {
    const total = Math.round(params.durationSeconds);
    lines.push(
      `时长：${Math.floor(total / 3600)}:${String(Math.floor((total % 3600) / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`,
    );
  }
  if (typeof params.audioTracks === "number")
    lines.push(`音轨数：${params.audioTracks}`);
  if (typeof params.subtitleTracks === "number")
    lines.push(`字幕轨数：${params.subtitleTracks}`);
  if (params.metadataOverview) {
    lines.push("");
    lines.push(`内容简介（${params.metadataSource ?? "多源资料"}）：`);
    lines.push(params.metadataOverview);
  }
  lines.push(
    "说明：当前无 AI API 或 AI 未返回简介，以上为本地可核验的基础资料，可再次点击分析获取完整简介。",
  );
  return lines.join("\n");
}

/** 清理分析正文：去掉 Markdown 残留（*、#、列表符、反引号、引用符等），保证专业纯文本。 */
function cleanAnalysisText(text: string): string {
  return text
    .replace(/^#{1,6}\s*/gm, "")
    .replace(/^\s*[*_\-+]\s+/gm, "")
    .replace(/[*_`~]/g, "")
    .replace(/!?\[([^\]]*)\]\([^)]*\)/g, "$1")
    .replace(/^>\s*/gm, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/** 剥离识别过程性内容：无论 LLM 是否遵守，都去掉“识别依据/综合判断/技术特征”等段落与句子。 */
function stripProcessText(text: string): string {
  const lines = text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  const kept = lines.filter((line) => {
    if (/^(识别依据|综合判断|技术特征|结论|分析过程)/.test(line)) return false;
    if (
      /与来源文件的技术特征相符|与来源(文件名|路径|文件).*吻合|用户提示词明确给出|无其他同名候选版本/.test(
        line,
      )
    )
      return false;
    return true;
  });
  return kept.join("\n").trim();
}

/** 让 LLM 返回一张公开可访问的真实海报直链（兜底；绝不生成图片）。 */
async function findPosterUrlByLlm(params: {
  titleZh?: string;
  titleEn?: string;
  year?: number;
  apiKey: string;
  endpoint: { baseUrl: string; model: string };
}): Promise<string[]> {
  const system =
    "你是影视资料助手。请根据片名返回 1-3 张公开可访问的真实海报/封面图片直链（jpg/png），每行一个 URL，不要任何解释或编号。来源优先级：1) Wikipedia/维基百科页图（upload.wikimedia.org，最可靠）；2) 豆瓣图床（img1-9.doubanio.com，需带上原始 jpg 直链）；3) TMDb 图库（image.tmdb.org）；4) 其他知名图床。禁止返回 Amazon 图床（m.media-amazon.com）链接，这类链接经常失效或无法直连。找不到就只输出 NONE。";
  const user = `片名：${params.titleZh || ""}；英文名：${params.titleEn || ""}；年份：${params.year || ""}`;
  try {
    const response = await fetch(
      `${params.endpoint.baseUrl.replace(/\/$/, "")}/chat/completions`,
      {
        method: "POST",
        signal: AbortSignal.timeout(15_000),
        headers: {
          Authorization: `Bearer ${params.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: params.endpoint.model,
          temperature: 0.1,
          max_tokens: 200,
          messages: [
            { role: "system", content: system },
            { role: "user", content: user },
          ],
        }),
      },
    );
    void recordPreviewAiCall("poster").catch(() => {});
    if (!response.ok) return [];
    const payload = (await response.json().catch(() => ({}))) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const content = payload.choices?.[0]?.message?.content?.trim() ?? "";
    const urls = content
      .split(/\s+/)
      .map((part) => part.trim().replace(/[),.;]+$/, ""))
      .filter((part) => /^https?:\/\//i.test(part))
      .filter((part) => !/^NONE$/i.test(part));
    return [...new Set(urls)];
  } catch {
    return [];
  }
}

type AssistantAction =
  | { kind: "plan-edit"; itemId: string; field: string; value: unknown }
  | { kind: "identity-edit"; field: string; value: unknown }
  | { kind: "advice"; title: string; detail: string };

const PLAN_FIELDS = new Set(["enabled", "action", "presetId", "outputName"]);
const IDENTITY_FIELDS = new Set(["title", "titleEn", "year"]);

function sanitizeActions(raw: unknown): AssistantAction[] {
  if (!Array.isArray(raw)) return [];
  const result: AssistantAction[] = [];
  for (const item of raw) {
    if (!item || typeof item !== "object") continue;
    const value = item as Record<string, unknown>;
    const kind = value.kind;
    if (
      kind === "plan-edit" &&
      typeof value.itemId === "string" &&
      typeof value.field === "string" &&
      PLAN_FIELDS.has(value.field)
    ) {
      result.push({
        kind: "plan-edit",
        itemId: value.itemId,
        field: value.field,
        value: value.value,
      });
    } else if (
      kind === "identity-edit" &&
      typeof value.field === "string" &&
      IDENTITY_FIELDS.has(value.field)
    ) {
      result.push({
        kind: "identity-edit",
        field: value.field,
        value: value.value,
      });
    } else if (
      kind === "advice" &&
      typeof value.title === "string" &&
      typeof value.detail === "string"
    ) {
      result.push({ kind: "advice", title: value.title, detail: value.detail });
    }
  }
  return result;
}

router.post("/assistant/chat", async (req, res) => {
  const contextType = req.body?.contextType === "job" ? "job" : "workflow";
  const analysisMode = req.body?.analysis === true;
  const messages = Array.isArray(req.body?.messages)
    ? (req.body.messages as Array<{ role?: string; content?: unknown }>).slice(
        -12,
      )
    : [];
  const structuredInput =
    req.body?.structuredInput && typeof req.body.structuredInput === "object"
      ? req.body.structuredInput
      : {};
  const context =
    req.body?.context && typeof req.body.context === "object"
      ? req.body.context
      : {};
  const config = await getConfig();
  const tuning = parseCustomTuning(config.customTuning);
  const endpoint = resolveAiEndpoint(config);
  const apiKey = resolveApiKey(config);
  const rawPath =
    (typeof context.filePath === "string" && context.filePath.trim()) ||
    (typeof context.sourcePath === "string" && context.sourcePath.trim()) ||
    "";
  const rawName = rawPath ? sourceNameFromPath(rawPath) : "";
  if (!apiKey || endpoint.provider === "libretranslate") {
    return res.status(503).json({ error: "未配置可用于 AI 助手的 API Key" });
  }
  const system = analysisMode
    ? resolveLogicPlaceholders(tuning.prompts.analysis, tuning.logic)
    : contextType === "workflow"
      ? '你是影刻智能工作流助手。你只修改计划草稿，绝不执行任务或删除文件。回答简洁，使用当前界面语言。如需修改计划，在回复末尾输出 JSON：{"actions":[{...}]}。允许的 plan-edit 字段：enabled/action/presetId/outputName；identity-edit 字段：title/titleEn/year。不要编造媒体事实，不要给出计划外的执行命令。'
      : '你是影刻任务队列助手。你基于任务与日志给建议，绝不自动执行或修改任务。回答简洁，使用当前界面语言。如需建议，在回复末尾输出 JSON：{"actions":[{"kind":"advice","title":"...","detail":"..."}]}。';
  try {
    // 分析模式：并行采集多源资料（TMDb/OMDb/本地 IMDb/维基百科+豆瓣），
    // 注入 LLM 作为可核验背景；任一来源失败不阻塞分析。
    let metadataBlock = "";
    let metadataBest: MetadataResult | null = null;
    let metadataSnapshot: AssistantMetadataSnapshot | null = null;
    let doubanLookup: MetadataResult | null = null;
    let bestLookup: MetadataResult | null = null;
    let rawCleanTitle = "";
    let posterProxyUrl: string | null = null;
    /** True when the optional AI tier actually filled at least one field. */
    let aiEnrichmentUsed = false;
    /** Field -> provider id, so AI-sourced values stay distinguishable. */
    let aiEnrichmentSources: Record<string, string> | null = null;
    if (analysisMode) {
      posterProxyUrl = await resolvePosterProxyUrl(config.posterProxyUrl);
      const filename = rawPath.split(/[\\/]/).pop() ?? "";
      // 优先用清洗后的英文名检索，避免 2DVD5/Rus/Kinosvalka&rutracker 等发布标签污染查询
      rawCleanTitle = normalizeTitleEn(rawName);
      const parsedTitle = rawCleanTitle || parseFilename(filename).title;
      const yearFromPath = /(?:19|20)\d{2}/.exec(`${rawPath}`)?.[0];
      // 用户填写的 IMDb 号：按 tconst 精确锁定本地 IMDb 库记录，作为权威身份，
      // 优先于模糊检索（同名异年 / 发布标签污染时唯一性最高）。
      // Cache-first: a title that is already resolved beside the media is
      // served from disk. Customers without API keys — or with no working
      // network — still see the full record from the previous run instead of an
      // empty panel, and repeat runs stop re-querying every provider.
      const durableDir = posterDirectoryForSource(rawPath);
      const cached = await resolveFromCache(durableDir);
      let best: MetadataResult | null = cached.result;
      let bestResolvedFromCache = cached.reason === "hit";
      // Declared outside the network branch so the persistence step below can
      // still tell whether the local IMDb dataset supplied the identity.
      let imdbDirect: MetadataResult | null = null;
      if (!best) {
        const imdbIdInput =
          typeof req.body?.imdbId === "string" ? req.body.imdbId.trim() : "";
        imdbDirect = imdbIdInput
          ? await searchImdbByTconst(imdbIdInput, {
              originalQuery: parsedTitle,
            }).catch(() => null)
          : null;
        const lookup: { results: MetadataResult[]; errors: string[] } =
          await lookupAll({
            rawQuery: parsedTitle || rawName || filename,
            language: req.body?.language ?? "zh-CN",
            config,
            proxyUrl: posterProxyUrl,
          }).catch(() => ({ results: [], errors: [] as string[] }));
        const queryYearNumber = yearFromPath ? Number(yearFromPath) : undefined;
        const identityQuery = parsedTitle || rawName || filename;
        // Do not stop at the first identity hit: IMDb suggestion supplies the
        // tconst/poster, while other providers may supply rating/crew/genres.
        // Merge only title/year-compatible candidates and keep conflicting IMDb
        // ids isolated so enrichment can never change the canonical identity.
        const trustedLookup = mergeMetadataByIdentity(
          lookup.results,
          identityQuery,
          queryYearNumber,
        );
        best = imdbDirect
          ? (mergeMetadataByIdentity(
              [imdbDirect, ...lookup.results],
              identityQuery,
              queryYearNumber,
            ) ?? imdbDirect)
          : trustedLookup;
        if (best?.imdbId) {
          const imdbPage = await searchImdbTitlePage(best.imdbId, {
            originalQuery: identityQuery,
            proxyUrl: posterProxyUrl,
          }).catch(() => null);
          if (imdbPage) {
            best =
              mergeMetadataByIdentity(
                [best, imdbPage],
                identityQuery,
                queryYearNumber,
              ) ?? best;
          }
        }
        bestLookup = best;
        doubanLookup =
          lookup.results.find(
            (item) =>
              Boolean(item.doubanId) &&
              metadataIdentityMatches({
                candidate: item,
                queryTitle: parsedTitle || rawName || filename,
                queryYear: queryYearNumber,
              }),
          ) ?? null;
      }
      if (best && best.rating == null && doubanLookup?.doubanRating != null) {
        // A free Douban match can still provide a useful rating when IMDb,
        // TMDb and OMDb do not expose one; keep it attached to the same
        // title/year identity instead of leaving the field blank.
        best = {
          ...best,
          rating: doubanLookup.doubanRating,
          ratingSource: "douban",
        };
        bestLookup = best;
      }
      if (best) {
        metadataBest = {
          ...best,
          doubanId: best.doubanId ?? doubanLookup?.doubanId,
          doubanRating: best.doubanRating ?? doubanLookup?.doubanRating,
        };
        metadataSnapshot = buildAssistantMetadataSnapshot(metadataBest);
        // Optional last tier: fill only the fields no source could reach, and
        // record every AI-supplied value as AI-sourced. Identity fields are
        // never touched, and populated fields are never replaced. Skipped
        // entirely on a cache hit — a cached record already has whatever the
        // previous run could establish.
        if (!bestResolvedFromCache && config.aiMetadataEnrichment === true) {
          const missing = missingEnrichableFields(metadataBest);
          if (missing.length > 0) {
            try {
              const aiKey = resolveApiKey(config);
              const aiEndpoint = resolveAiEndpoint(config);
              if (aiKey) {
                const aiResponse = await fetch(
                  `${aiEndpoint.baseUrl.replace(/\/$/, "")}/chat/completions`,
                  {
                    method: "POST",
                    signal: AbortSignal.timeout(30_000),
                    headers: {
                      Authorization: `Bearer ${aiKey}`,
                      "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                      model: aiEndpoint.model,
                      temperature: 0.1,
                      max_tokens: 600,
                      messages: [
                        {
                          role: "user",
                          content: buildAiEnrichmentPrompt({
                            title: metadataBest.title,
                            titleEn: metadataBest.titleEn,
                            year: metadataBest.year,
                            imdbId: metadataBest.imdbId,
                            missing,
                          }),
                        },
                      ],
                    }),
                  },
                );
                if (aiResponse.ok) {
                  const payload = (await aiResponse
                    .json()
                    .catch(() => ({}))) as {
                    choices?: Array<{ message?: { content?: string } }>;
                  };
                  const content = payload.choices?.[0]?.message?.content ?? "";
                  const jsonMatch = content.match(/\{[\s\S]*\}/);
                  const suggestion = jsonMatch ? JSON.parse(jsonMatch[0]) : {};
                  const enriched = applyAiEnrichment({
                    result: metadataBest,
                    suggestion,
                    enabled: true,
                    sources: aiEnrichmentSources,
                  });
                  if (enriched.used) {
                    metadataBest = enriched.result;
                    aiEnrichmentUsed = true;
                    aiEnrichmentSources = enriched.sources;
                    metadataSnapshot =
                      buildAssistantMetadataSnapshot(metadataBest);
                  }
                }
              }
            } catch {
              // AI enrichment is best-effort and must never fail a job.
            }
          }
        }
        const details: string[] = [];
        if (best.titleEn || best.title)
          details.push(`英文名/原名：${best.titleEn || best.title}`);
        if (best.year) details.push(`年份：${best.year}`);
        if (best.mediaType)
          details.push(`类型：${best.mediaType === "tv" ? "剧集" : "电影"}`);
        if (best.genres) details.push(`题材：${best.genres}`);
        if (best.director) details.push(`导演：${best.director}`);
        if (best.rating) details.push(`评分：${best.rating.toFixed(1)}`);
        if (best.doubanId ?? doubanLookup?.doubanId)
          details.push(`豆瓣号：${best.doubanId ?? doubanLookup?.doubanId}`);
        if (best.doubanRating ?? doubanLookup?.doubanRating)
          details.push(
            `豆瓣评分：${(best.doubanRating ?? doubanLookup?.doubanRating)?.toFixed(1)}`,
          );
        if (best.runtimeMinutes)
          details.push(`片长：${best.runtimeMinutes} 分钟`);
        if (best.overview) details.push(`简介：${best.overview.slice(0, 800)}`);
        if (details.length > 0) {
          const sourceLabel =
            best.source === "tvmaze"
              ? "TVmaze"
              : best.source === "imdb"
                ? "IMDb 资料源"
                : best.source === "wikipedia"
                  ? "维基百科/豆瓣/iTunes"
                  : best.source.toUpperCase();
          const yearHint = yearFromPath
            ? `来源年份：${yearFromPath}（首选参照；外部资料年份与它相差 ±1 年内视为同一部作品；官方录像发行年份晚于实际演出/录制多年时仍可能是同一场演出）\n`
            : "";
          metadataBlock = `外部检索资料（来源：${sourceLabel}；仅作参考，请结合你的检索交叉核对）：\n${yearHint}${details.join("\n")}`;
        }
        // Persist beside the media so the next run — and any machine without
        // keys or network — can serve this record from disk. Cache hits are not
        // rewritten: nothing new was learned.
        if (!bestResolvedFromCache) {
          const tier = tierForResolution({
            source: best.source,
            usedLocalDataset: Boolean(
              imdbDirect && best.imdbId === imdbDirect.imdbId,
            ),
            usedAi: aiEnrichmentUsed,
          });
          await persistResolvedMetadata({
            targetDirectory: durableDir,
            result: metadataBest,
            tier,
            sources: aiEnrichmentSources,
          }).catch(() => null);
        }
      }
    }
    const userContent = [
      `界面语言：${req.body?.language ?? "zh-CN"}`,
      `上下文：${JSON.stringify(context).slice(0, 6000)}`,
      Object.keys(structuredInput).length > 0
        ? `用户结构化输入：${JSON.stringify(structuredInput)}`
        : "",
      `用户调优逻辑参数：\n${buildTuningLogicContext(tuning.logic)}`,
      ...(metadataBlock ? [metadataBlock] : []),
      ...messages.map(
        (m) => `${String(m.role ?? "user")}: ${String(m.content ?? "")}`,
      ),
    ]
      .filter(Boolean)
      .join("\n");
    const response = await fetch(
      `${endpoint.baseUrl.replace(/\/$/, "")}/chat/completions`,
      {
        method: "POST",
        signal: AbortSignal.timeout(30_000),
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: endpoint.model,
          temperature: 0.3,
          max_tokens: 1500,
          messages: [
            { role: "system", content: system },
            { role: "user", content: userContent },
          ],
        }),
      },
    );
    void recordPreviewAiCall(analysisMode ? "analysis" : "assistant").catch(
      () => {},
    );
    const payload = (await response.json().catch(() => ({}))) as {
      choices?: Array<{ message?: { content?: unknown } }>;
      error?: { message?: string };
    };
    if (!response.ok)
      throw new Error(
        `AI 助手返回 HTTP ${response.status}${payload.error?.message ? `：${payload.error.message}` : ""}`,
      );
    const content =
      typeof payload.choices?.[0]?.message?.content === "string"
        ? payload.choices[0].message.content
        : "";
    let reply = content;
    let actions: AssistantAction[] = [];
    let corrected: {
      titleEn?: string;
      titleZh?: string;
      year?: number;
      imdbId?: string | null;
      imdbIdSource?: "verified" | "assistant";
      doubanId?: string | null;
      doubanRating?: number | null;
    } | null = null;
    let posterUrl: string | null = null;
    let posterCandidates: PosterCandidate[] = [];
    if (analysisMode) {
      const titleEnMatch = /TITLE_EN\s*=\s*([^\r\n]+)/i.exec(content);
      const titleZhMatch = /TITLE_ZH\s*=\s*([^\r\n]+)/i.exec(content);
      const yearMatch = /YEAR\s*=\s*(\d{4})/i.exec(content);
      const correctedTitleEnRaw = titleEnMatch?.[1]?.trim() ?? "";
      // 外文名修正：LLM 结构化行优先；缺失/为空时依次用资料库规范名、源名清洗结果兜底，
      // 保证分析后回写的英文名是干净的片名（绝不含年份/季集号/分辨率/编码/发布标签）。
      let correctedTitleEn =
        normalizeTitleEn(correctedTitleEnRaw) || correctedTitleEnRaw;
      const identityTitleEn = bestLookup?.titleEn ?? metadataBest?.titleEn;
      if (!correctedTitleEn && identityTitleEn)
        correctedTitleEn = normalizeTitleEn(identityTitleEn);
      if (!correctedTitleEn && rawCleanTitle) correctedTitleEn = rawCleanTitle;
      const correctedTitleZh = titleZhMatch?.[1]?.trim();
      const correctedYear = yearMatch ? Number(yearMatch[1]) : undefined;
      const imdbIdInput =
        (typeof req.body?.imdbId === "string" ? req.body.imdbId.trim() : "") ||
        "";
      // LLM text is not an identity authority. Only an explicitly entered ID
      // or a provider result whose title/year matched the source may be used.
      // The cache-first path fills metadataBest without running the lookup, so
      // reading only the fresh lookup dropped the id on every cache hit.
      let resolvedImdbId = resolveAssistantImdbId({
        imdbIdInput,
        metadataBest,
        lookup: bestLookup,
      });
      const fallbackTitle = correctedTitleEn || correctedTitleZh;
      if (
        !resolvedImdbId &&
        fallbackTitle &&
        (config.imdbTitleCount ?? 0) > 0
      ) {
        const fallbackRows = await searchImdbLocal(fallbackTitle, {
          year: Number.isFinite(correctedYear) ? correctedYear : undefined,
          originalQuery: rawCleanTitle || fallbackTitle,
        }).catch(() => []);
        const fallback = fallbackRows.find((candidate) =>
          metadataIdentityMatches({
            candidate,
            queryTitle: fallbackTitle,
            queryYear: Number.isFinite(correctedYear)
              ? correctedYear
              : undefined,
          }),
        );
        if (fallback?.imdbId) resolvedImdbId = fallback.imdbId;
      }
      // 多源并行查找可核验海报（IMDb/豆瓣精确匹配；有 TMDb/OMDb
      // key 也参与）。优先复用 lookup 已确认的同一身份候选，避免
      // “IMDb 号来自 A、海报来自 B”错配；无法核验时不保存相关图片。
      const posterYear = Number.isFinite(correctedYear)
        ? correctedYear
        : (metadataBest?.year ??
          bestLookup?.year ??
          (/\d{4}/.exec(rawPath)?.[0]
            ? Number(/\d{4}/.exec(rawPath)?.[0])
            : undefined));
      const onlinePosterCandidates =
        fallbackTitle || bestLookup
          ? await findPosterCandidatesByOnline({
              title: correctedTitleZh || rawName,
              titleEn: correctedTitleEn || bestLookup?.titleEn || rawName,
              year: posterYear,
              imdbId: resolvedImdbId,
              tmdbId: metadataBest?.tmdbId ?? bestLookup?.tmdbId,
              tmdbApiKey: config.tmdbApiKey,
              omdbApiKey: config.omdbApiKey,
              posterMirrorUrl: config.posterMirrorUrl,
              proxyUrl: posterProxyUrl,
            })
          : [];
      const onlinePosterUrls = onlinePosterCandidates.map(
        (candidate) => candidate.url,
      );
      const posterSource = metadataBest?.poster ? metadataBest : bestLookup;
      const metadataPoster =
        posterSource?.poster &&
        isTrustedPosterSource(
          posterSource.posterSource ?? posterSource.source,
        ) &&
        (!resolvedImdbId ||
          !posterSource.imdbId ||
          posterSource.imdbId.toLowerCase() === resolvedImdbId.toLowerCase())
          ? posterSource.poster
          : null;
      const confirmedPosterUrls = prioritizePosterCandidates(
        [metadataPoster ?? "", ...onlinePosterUrls],
        metadataPoster ? [metadataPoster] : [],
      );
      posterCandidates = [
        ...(metadataPoster
          ? [
              {
                url: metadataPoster,
                source: (bestLookup?.posterSource ??
                  bestLookup?.source) as PosterCandidate["source"],
                confidence: "high",
                matchedBy: resolvedImdbId ? "imdb" : "title-year",
              } satisfies PosterCandidate,
            ]
          : []),
        ...onlinePosterCandidates,
      ]
        .filter(
          (candidate, index, all) =>
            all.findIndex((item) => item.url === candidate.url) === index,
        )
        .slice(0, 8);
      // 在线查找全部失败时，再让 LLM 找公开海报 URL（返回多个候选逐行尝试）。
      // LLM-only URLs are suggestions, not identity evidence.  They may be
      // shown as a transient candidate, but must never be persisted as the
      // task poster: a hallucinated or similarly titled image is worse than
      // an empty poster.  Only URLs tied to the verified metadata lookup are
      // allowed into the automatic save path.
      const posterIdentity = {
        imdbId: resolvedImdbId,
        title: correctedTitleZh || null,
        titleEn: correctedTitleEn || bestLookup?.titleEn || null,
        year: posterYear,
      };
      const rawPosterUrl = confirmedPosterUrls[0] ?? null;
      posterUrl = rawPosterUrl
        ? bindPosterIdentityToUrl(rawPosterUrl, posterIdentity)
        : null;
      posterCandidates = posterCandidates.map((candidate) => ({
        ...candidate,
        url: bindPosterIdentityToUrl(candidate.url, posterIdentity),
      }));
      // Keep the JobDetail basic-information card backed by the same verified
      // provider result used for the analysis response.  The frontend may
      // still update the title/overview, but it must not be the only place
      // where rating/director/genre/IMDb fields are persisted.
      if (bestLookup) {
        await persistVerifiedJobMetadata(
          context.jobId,
          metadataBest ?? bestLookup,
          posterUrl,
        ).catch((err) => console.warn("assistant: 持久化任务元数据失败", err));
      }
      // 概要预览识别到的 IMDb 编号（LLM 按要求输出“IMDb 编号：ttXXXXXXX”或
      // IMDB_ID=tt… 时提取），用于回填输入栏；资料库命中的权威值优先。
      // The model's own id is not an identity authority, but it is still the only
      // source for a title no provider can reach, so it fills the input field as
      // an unverified suggestion and never pins a poster by itself.
      const assistantImdbId = resolvedImdbId
        ? null
        : extractAssistantImdbId(reply);
      if (
        correctedTitleEn ||
        correctedTitleZh ||
        correctedYear ||
        resolvedImdbId ||
        assistantImdbId
      ) {
        corrected = {
          ...(correctedTitleEn ? { titleEn: correctedTitleEn } : {}),
          ...(correctedTitleZh ? { titleZh: correctedTitleZh } : {}),
          ...(Number.isFinite(correctedYear) ? { year: correctedYear } : {}),
          ...(resolvedImdbId
            ? { imdbId: resolvedImdbId, imdbIdSource: "verified" as const }
            : {}),
          ...(!resolvedImdbId && assistantImdbId
            ? { imdbId: assistantImdbId, imdbIdSource: "assistant" as const }
            : {}),
          ...(metadataBest?.doubanId
            ? { doubanId: metadataBest.doubanId }
            : {}),
          ...(metadataBest?.doubanRating
            ? { doubanRating: metadataBest.doubanRating }
            : {}),
        };
      }
      // 标准化片名（英文名.年份.中文名），用于替换正文中回显的原始文件名
      const titleParts: Array<string | number> = [];
      if (correctedTitleEn) titleParts.push(correctedTitleEn);
      if (correctedYear) titleParts.push(correctedYear);
      if (correctedTitleZh) titleParts.push(correctedTitleZh);
      const standardTitle = titleParts.length ? titleParts.join(".") : "";
      // 服务端直接保存海报到源目录（多源 + 信息卡兜底），不再依赖前端二次请求；
      // 保存失败只记录日志，不影响分析正文返回。
      if (rawPath) {
        try {
          const savedPosterPath = await ensureLocalPoster({
            title: correctedTitleZh || null,
            titleEn: correctedTitleEn || null,
            imdbId: resolvedImdbId,
            allowTitleSearch: Boolean(
              resolvedImdbId || metadataBest || bestLookup,
            ),
            posterUrl: rawPosterUrl,
            posterUrls:
              confirmedPosterUrls.length > 0 ? confirmedPosterUrls : null,
            tmdbApiKey: config.tmdbApiKey,
            omdbApiKey: config.omdbApiKey,
            posterMirrorUrl: config.posterMirrorUrl,
            posterProxyUrl,
            // 常规来源都失败时，用已配置的 LLM 兜底找公开海报直链（助手侧返回数组，取首个）。
            findPosterUrlByLlm: async (info) => {
              if (!apiKey || endpoint.provider === "libretranslate")
                return null;
              const rawYear =
                typeof info.year === "number"
                  ? info.year
                  : info.year
                    ? Number(info.year)
                    : NaN;
              const urls = await findPosterUrlByLlm({
                titleZh: info.title ?? undefined,
                titleEn: info.titleEn ?? undefined,
                year: Number.isFinite(rawYear) ? rawYear : undefined,
                apiKey,
                endpoint: { baseUrl: endpoint.baseUrl, model: endpoint.model },
              });
              return urls[0] ?? null;
            },
            year: posterYear,
            tmdbId: metadataBest?.tmdbId ?? bestLookup?.tmdbId,
            targetDirectory: posterDirectoryForSource(rawPath),
            onLog: async (message) => console.info(message),
          });
          // Return the identity-checked local endpoint to the UI instead of
          // making the remote candidate the final displayed poster.
          if (savedPosterPath) {
            const localPosterQuery = new URLSearchParams({
              path: rawPath,
              t: String(Date.now()),
            });
            if (resolvedImdbId) localPosterQuery.set("imdbId", resolvedImdbId);
            if (correctedTitleZh)
              localPosterQuery.set("title", correctedTitleZh);
            if (correctedTitleEn)
              localPosterQuery.set("titleEn", correctedTitleEn);
            if (Number.isFinite(posterYear))
              localPosterQuery.set("year", String(posterYear));
            posterUrl = `/api/media/poster?${localPosterQuery.toString()}`;
            await persistVerifiedJobMetadata(
              context.jobId,
              metadataBest ?? bestLookup!,
              posterUrl,
            ).catch((err) =>
              console.warn("assistant: 持久化任务元数据失败", err),
            );
          }
        } catch (posterError) {
          console.warn("assistant: 海报保存失败", posterError);
        }
      }
      // 去掉结构化行，保留简介正文；权威编号在清洗后重新追加，避免被 LLM 格式影响。
      reply = stripProcessText(
        cleanAnalysisText(
          content
            .replace(/^TITLE_EN\s*=\s*[^\r\n]*\r?\n?/im, "")
            .replace(/^TITLE_ZH\s*=\s*[^\r\n]*\r?\n?/im, "")
            .replace(/^YEAR\s*=\s*[^\r\n]*\r?\n?/im, "")
            .replace(/^POSTER_URL\s*=\s*[^\r\n]*\r?\n?/im, "")
            .trim(),
        ),
      );
      // 正文里出现的原始文件名（含 720p/x264 等发布标签）统一替换为标准化片名
      if (rawName && standardTitle && rawName.length >= 8) {
        reply = reply.split(rawName).join(standardTitle);
      }
      const authoritative = buildAuthoritativeMetadataBlock({
        imdbId: resolvedImdbId,
        doubanId: metadataBest?.doubanId,
        rating: metadataBest?.rating,
        ratingLabel:
          metadataBest?.source === "imdb" || metadataBest?.source === "omdb"
            ? "IMDb评分"
            : "资料评分",
        doubanRating: metadataBest?.doubanRating,
      });
      if (authoritative && !reply.includes("资料信息：")) {
        reply = reply ? `${reply}\n\n${authoritative}` : authoritative;
      }
      if (!reply) {
        reply = buildLocalInfoCard({
          sourcePath: rawPath,
          standardTitle,
          year: Number.isFinite(correctedYear) ? correctedYear : null,
          sourceType:
            typeof context.sourceType === "string"
              ? context.sourceType
              : undefined,
          durationSeconds:
            typeof context.durationSeconds === "number"
              ? context.durationSeconds
              : undefined,
          audioTracks:
            typeof context.audioTracks === "number"
              ? context.audioTracks
              : undefined,
          subtitleTracks:
            typeof context.subtitleTracks === "number"
              ? context.subtitleTracks
              : undefined,
          metadataOverview: metadataBest?.overview,
          metadataGenres: metadataBest?.genres,
          metadataRating: metadataBest?.rating,
          metadataRuntime: metadataBest?.runtimeMinutes,
          metadataSource: metadataBest?.source,
          metadataImdbId: resolvedImdbId,
          metadataDoubanId: metadataBest?.doubanId,
          metadataDoubanRating: metadataBest?.doubanRating,
          metadataRottenTomatoesRating: metadataBest?.rottenTomatoesRating,
          metadataMetacriticRating: metadataBest?.metacriticRating,
          metadataDirector: metadataBest?.director,
          metadataCast: metadataBest?.cast,
        });
      }
      // Persist fields explicitly returned in the same analysis reply so a
      // refreshed task keeps the rating and crew rows visible. These remain
      // display metadata; provider-backed identity is kept unchanged.
      const replyMetadata = extractAssistantMetadata(reply);
      if (metadataSnapshot) {
        if (Object.keys(replyMetadata).length > 0) {
          metadataSnapshot = {
            ...metadataSnapshot,
            imdb:
              replyMetadata.rating != null || replyMetadata.ratingVotes != null
                ? {
                    ...metadataSnapshot.imdb,
                    rating:
                      replyMetadata.rating ?? metadataSnapshot.imdb?.rating,
                    votes:
                      replyMetadata.ratingVotes ?? metadataSnapshot.imdb?.votes,
                  }
                : metadataSnapshot.imdb,
            douban:
              replyMetadata.doubanRating != null
                ? {
                    ...metadataSnapshot.douban,
                    rating: replyMetadata.doubanRating,
                  }
                : metadataSnapshot.douban,
            director: replyMetadata.director ?? metadataSnapshot.director,
            credits: replyMetadata.credits ?? metadataSnapshot.credits,
            cast: replyMetadata.cast ?? metadataSnapshot.cast,
            genres: replyMetadata.genres ?? metadataSnapshot.genres,
            runtimeMinutes:
              replyMetadata.runtimeMinutes ?? metadataSnapshot.runtimeMinutes,
            sourceLabels: [
              ...new Set([...metadataSnapshot.sourceLabels, "AI助手"]),
            ],
          };
        }
      } else if (Object.keys(replyMetadata).length > 0) {
        // No provider reached this title, so the reply is all the panel has.
        // Keep it as a candidate snapshot with no identity: nothing is pinned,
        // but the crew, genres and overview still reach the UI instead of being
        // thrown away because the provider came back empty.
        metadataSnapshot = {
          identityStatus: "candidate",
          sourceLabels: ["AI助手"],
          imdb:
            replyMetadata.rating != null || replyMetadata.ratingVotes != null
              ? {
                  rating: replyMetadata.rating,
                  votes: replyMetadata.ratingVotes,
                }
              : undefined,
          douban:
            replyMetadata.doubanRating != null
              ? { rating: replyMetadata.doubanRating }
              : undefined,
          director: replyMetadata.director,
          credits: replyMetadata.credits,
          cast: replyMetadata.cast,
          genres: replyMetadata.genres,
          runtimeMinutes: replyMetadata.runtimeMinutes,
        };
      }
    } else {
      const jsonMatch = content.match(/\{[\s\S]*"actions"[\s\S]*\}/);
      if (jsonMatch) {
        try {
          const parsed = JSON.parse(jsonMatch[0]) as { actions?: unknown };
          actions = sanitizeActions(parsed.actions);
          reply =
            content.replace(jsonMatch[0], "").trim() ||
            "已根据你的要求生成调整建议。";
        } catch {
          // Keep the full text reply when the JSON block cannot be parsed.
        }
      }
    }
    if (analysisMode) {
      const extractedOverview = extractAssistantOverview(reply);
      if (extractedOverview && metadataSnapshot)
        metadataSnapshot = { ...metadataSnapshot, overview: extractedOverview };
      const jobId = Number(context.jobId);
      if (Number.isInteger(jobId) && jobId > 0) {
        const overviewPatch: Partial<typeof jobsTable.$inferInsert> = {};
        if (extractedOverview) overviewPatch.movieOverview = extractedOverview;
        if (metadataSnapshot)
          overviewPatch.movieMetadata = JSON.stringify(metadataSnapshot);
        if (Object.keys(overviewPatch).length > 0) {
          await db
            .update(jobsTable)
            .set(overviewPatch)
            .where(eq(jobsTable.id, jobId))
            .catch((err: unknown) =>
              console.warn("assistant: 写入任务简介失败", err),
            );
        }
      }
    }
    return res.json({
      reply,
      actions,
      corrected,
      posterUrl,
      posterCandidates,
      metadata: metadataSnapshot,
    });
  } catch (error) {
    return res
      .status(500)
      .json({ error: error instanceof Error ? error.message : String(error) });
  }
});

export default router;
