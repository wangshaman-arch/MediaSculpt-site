export type CompressionOutputProbe = {
  durationSeconds: number | null;
  streams: Array<{ codecType: string }>;
  chapters: unknown[];
};

export type CompressionOutputGrade = {
  errors: string[];
  warnings: string[];
};

/**
 * Grades the observable result of HandBrake separately from optional DVD
 * metadata.  DVD chapter/subtitle availability is not a proof that the
 * selected title was encoded incorrectly, so those differences are warnings.
 */
export function gradeCompressionOutput(input: {
  probe: CompressionOutputProbe;
  expectedDurationSeconds?: number | null;
  expectedVideoCount: number;
  expectedAudioCount: number;
  requiredAudioCount: number;
  expectedSubtitleCount: number;
  expectedChapterCount: number;
}): CompressionOutputGrade {
  const actual = {
    video: input.probe.streams.filter((stream) => stream.codecType === "video")
      .length,
    audio: input.probe.streams.filter((stream) => stream.codecType === "audio")
      .length,
    subtitle: input.probe.streams.filter(
      (stream) => stream.codecType === "subtitle",
    ).length,
  };
  const errors: string[] = [];
  const warnings: string[] = [];

  if (actual.video < Math.max(1, input.expectedVideoCount)) {
    errors.push(
      `缺少视频流 ${actual.video}/${Math.max(1, input.expectedVideoCount)}`,
    );
  }
  if (actual.audio < input.requiredAudioCount) {
    errors.push(`缺少主音轨 ${actual.audio}/${input.requiredAudioCount}`);
  }
  if (
    input.expectedAudioCount > input.requiredAudioCount &&
    actual.audio < input.expectedAudioCount
  ) {
    warnings.push(
      `可选音轨未全部保留 ${actual.audio}/${input.expectedAudioCount}`,
    );
  }
  if (actual.subtitle < input.expectedSubtitleCount) {
    warnings.push(
      `字幕未全部保留 ${actual.subtitle}/${input.expectedSubtitleCount}`,
    );
  }
  if (
    input.expectedChapterCount > 0 &&
    input.probe.chapters.length < input.expectedChapterCount
  ) {
    warnings.push(
      `章节数量变化 ${input.probe.chapters.length}/${input.expectedChapterCount}`,
    );
  }

  if (
    input.expectedDurationSeconds &&
    input.probe.durationSeconds &&
    input.expectedDurationSeconds > 0
  ) {
    const differenceSeconds = Math.abs(
      input.probe.durationSeconds - input.expectedDurationSeconds,
    );
    const drift = differenceSeconds / input.expectedDurationSeconds;
    if (drift > 0.1) {
      errors.push(
        `输出时长与所选标题严重不符 ${(drift * 100).toFixed(1)}%（源 ${input.expectedDurationSeconds.toFixed(1)} 秒，输出 ${input.probe.durationSeconds.toFixed(1)} 秒）`,
      );
    } else if (drift > 0.05) {
      warnings.push(
        `输出时长与所选标题有小幅差异 ${(drift * 100).toFixed(1)}%（源 ${input.expectedDurationSeconds.toFixed(1)} 秒，输出 ${input.probe.durationSeconds.toFixed(1)} 秒）`,
      );
    }
  }

  return { errors, warnings };
}
