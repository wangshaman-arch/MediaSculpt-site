import { describe, it, expect, vi, afterEach } from "vitest";
import type { configTable } from "@workspace/db";
import {
  buildStandardizedName,
  normalizeTitleEn,
  parseFilename,
  mergeResults,
  mergeMetadataByIdentity,
  searchTmdb,
  searchOmdb,
  searchDouban,
  searchImdbSuggestion,
  searchImdbTitlePage,
  lookupAll,
  metadataIdentityMatches,
  sequenceMarkers,
  proxyAwareFetch,
  searchWikipediaPoster,
  type MetadataResult,
} from "./metadata";
import { buildAssistantMetadataSnapshot } from "./assistant-summary";

describe("metadataIdentityMatches", () => {
  it("rejects a similarly named result", () => {
    expect(
      metadataIdentityMatches({
        queryTitle: "Simply Anne Sophie",
        queryYear: 2007,
        candidate: { title: "Simply Red", titleEn: "Simply Red", year: 2007 },
      }),
    ).toBe(false);
  });

  it("accepts an exact title and nearby release year", () => {
    expect(
      metadataIdentityMatches({
        queryTitle: "Simply Anne Sophie",
        queryYear: 2007,
        candidate: {
          title: "Simply Anne Sophie",
          titleEn: "Simply Anne Sophie",
          year: 2006,
        },
      }),
    ).toBe(true);
  });

  it("rejects a shorter title that only shares the final words", () => {
    expect(
      metadataIdentityMatches({
        queryTitle: "The Making of King Arthur",
        queryYear: 2010,
        candidate: { title: "King Arthur", titleEn: "King Arthur", year: 2010 },
      }),
    ).toBe(false);
  });

  // Regression, found by adversarial review: normalizeTitleEn drops a trailing
  // Roman numeral, so the exact-match branch accepted a sequel as the original.
  it("rejects a sequel of the requested work", () => {
    const sequel = (candidate: string, year: number) =>
      metadataIdentityMatches({
        queryTitle: "A Better Tomorrow",
        queryYear: 1986,
        candidate: { title: candidate, titleEn: candidate, year },
      });
    expect(sequel("A Better Tomorrow II", 1987)).toBe(false);
    expect(sequel("A Better Tomorrow III", 1989)).toBe(false);
    expect(
      metadataIdentityMatches({
        queryTitle: "Rocky II",
        queryYear: 1979,
        candidate: { title: "Rocky", titleEn: "Rocky", year: 1976 },
      }),
    ).toBe(false);
  });

  it("still matches a work to itself when the title carries a sequence marker", () => {
    expect(
      metadataIdentityMatches({
        queryTitle: "A Better Tomorrow II",
        queryYear: 1987,
        candidate: {
          title: "A Better Tomorrow II",
          titleEn: "A Better Tomorrow II",
          year: 1987,
        },
      }),
    ).toBe(true);
    expect(
      metadataIdentityMatches({
        queryTitle: "Rocky IV",
        queryYear: 1985,
        candidate: { title: "Rocky IV", titleEn: "Rocky IV", year: 1985 },
      }),
    ).toBe(true);
  });

  it("matches the same work written with accents", () => {
    expect(
      metadataIdentityMatches({
        queryTitle: "La Bayadere",
        queryYear: 1980,
        candidate: { title: "La Bayadère", titleEn: "La Bayadère", year: 1980 },
      }),
    ).toBe(true);
  });

  it("only treats a standalone Roman numeral as a sequence marker", () => {
    // `iv` inside `Survivor` must not be read as a sequel marker.
    expect(sequenceMarkers("Survivor")).toEqual([]);
    expect(sequenceMarkers("Rocky IV")).toEqual(["iv"]);
    expect(sequenceMarkers("Come and See Part 2")).toEqual(["part2"]);
    expect(sequenceMarkers("A Better Tomorrow")).toEqual([]);
  });
});

describe("standardized metadata names", () => {
  it("does not append a second year when the Chinese title already contains it", () => {
    const name = buildStandardizedName(
      "流浪地球（2019）",
      "The Wandering Earth",
      2019,
      "movie.mkv",
      "x264-10bit",
      "mkv",
    );
    expect(name).not.toContain("2019.2019");
  });
});

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

afterEach(() => {
  vi.unstubAllGlobals();
});

// ─── parseFilename ────────────────────────────────────────────────────────────

describe("parseFilename", () => {
  it("extracts title and year from a scene-style filename", () => {
    expect(parseFilename("Hamlet.1996.1080p.BluRay.x264.mkv")).toEqual({
      title: "Hamlet",
      year: 1996,
    });
  });

  it("strips episode markers", () => {
    const r = parseFilename("Some.Show.S01E02.720p.mkv");
    expect(r.title).toBe("Some Show");
  });

  it("handles filenames without a year", () => {
    expect(parseFilename("VIDEO_TS.mkv").year).toBeUndefined();
  });

  it("preserves dotted search titles when no media extension is present", () => {
    expect(parseFilename("In.the.Opinion.of.the.Censor")).toEqual({
      title: "In the Opinion of the Censor",
    });
  });

  // Regression, measured against ~1,900 real library entries: a release year
  // was only recognised when an ASCII separator followed it, so years before
  // CJK text, year ranges, and trailing years were missed and the raw tail
  // leaked into the search title.
  it("extracts the year when CJK text follows it directly", () => {
    expect(parseFilename("The.Age.of.Innocence.1993纯真年代")).toEqual({
      title: "The Age of Innocence",
      year: 1993,
    });
    expect(parseFilename("From.Beijing.with.Love.1994国产凌凌漆")).toEqual({
      title: "From Beijing with Love",
      year: 1994,
    });
  });

  it("extracts the first year of a year range", () => {
    expect(parseFilename("Johnny.English.2003-2018.憨豆特工")).toEqual({
      title: "Johnny English",
      year: 2003,
    });
    expect(
      parseFilename("Fight.Back.to.School.1991-1993.逃学威龙三部曲"),
    ).toEqual({
      title: "Fight Back to School",
      year: 1991,
    });
  });

  it("extracts a trailing year", () => {
    expect(parseFilename("U-571.2000")).toEqual({ title: "U-571", year: 2000 });
    expect(parseFilename("Ballet.Now.2018")).toEqual({
      title: "Ballet Now",
      year: 2018,
    });
  });

  // Year-titled works must keep the year as their title and take the release
  // year from the second occurrence.
  it("keeps a year-titled work while still reading its release year", () => {
    expect(parseFilename("2046.2004")).toEqual({ title: "2046", year: 2004 });
    expect(parseFilename("1917.2019")).toEqual({ title: "1917", year: 2019 });
    expect(parseFilename("1984.1984.一九八四")).toEqual({
      title: "1984",
      year: 1984,
    });
  });

  it("keeps numeric titles intact through parsing and normalisation", () => {
    expect(parseFilename("500.Days.of.Summer.2009.和莎莫的500天")).toEqual({
      title: "500 Days of Summer",
      year: 2009,
    });
    expect(parseFilename("A.Better.Tomorrow.II.1987.英雄本色")).toEqual({
      title: "A Better Tomorrow II",
      year: 1987,
    });
  });
});

// ─── normalizeTitleEn ─────────────────────────────────────────────────────────

describe("normalizeTitleEn", () => {
  it("strips disc, language and release-group tags from a DVD folder name", () => {
    expect(
      normalizeTitleEn(
        "Kronprinz.Rudolf.2006.2DVD5.Rus.Eng.Kinosvalka&rutracker",
      ),
    ).toBe("Kronprinz.Rudolf");
  });

  it("strips resolution, codec, audio and source tags", () => {
    expect(
      normalizeTitleEn("Kronprinz.Rudolf.2006.576P.H264.10bit.AC3.P2"),
    ).toBe("Kronprinz.Rudolf");
  });

  it("strips episode markers and container extension", () => {
    expect(normalizeTitleEn("Some.Show.S01E03.720p.WEB-DL.x264.mkv")).toBe(
      "Some.Show",
    );
  });

  it("keeps a clean canonical title untouched", () => {
    expect(normalizeTitleEn("Prisoners.of.Terpsichore")).toBe(
      "Prisoners.of.Terpsichore",
    );
  });

  it("strips bracket-wrapped tags and empty brackets", () => {
    expect(normalizeTitleEn("August.Rush.[2007].1080p.BluRay.x264")).toBe(
      "August.Rush",
    );
    expect(normalizeTitleEn("August.Rush.[].720p")).toBe("August.Rush");
  });

  it("truncates at release markers and drops unknown release groups", () => {
    expect(
      normalizeTitleEn("Panic Room (2002) (1080p AMZN WEB-DL x265 Silence)"),
    ).toBe("Panic.Room");
    expect(normalizeTitleEn("Panic.Room.AMZN.Silence")).toBe("Panic.Room");
  });

  // Regression: standalone numbers and `Part N` used to be dropped as release
  // tags, which destroyed real titles and emptied year-titled works entirely.
  it("keeps numbers that belong to the title", () => {
    expect(normalizeTitleEn("11 Days 11 Nights Part 3")).toBe(
      "11.Days.11.Nights.Part.3",
    );
    expect(normalizeTitleEn("Apollo 13")).toBe("Apollo.13");
    expect(normalizeTitleEn("Catch 22")).toBe("Catch.22");
    expect(normalizeTitleEn("The 39 Steps")).toBe("The.39.Steps");
    expect(normalizeTitleEn("12 Angry Men")).toBe("12.Angry.Men");
    expect(normalizeTitleEn("8 Mile")).toBe("8.Mile");
    expect(normalizeTitleEn("Ocean's 11")).toBe("Ocean's.11");
    expect(normalizeTitleEn("Match of the Day 2")).toBe("Match.of.the.Day.2");
  });

  it("keeps numeric classical titles, including numbers joined by ampersand", () => {
    expect(normalizeTitleEn("Symphony No. 5")).toBe("Symphony.No.5");
    expect(normalizeTitleEn("Piano Concerto No. 2")).toBe(
      "Piano.Concerto.No.2",
    );
    expect(normalizeTitleEn("Symphonies Nos. 1 & 2")).toBe(
      "Symphonies.Nos.1.&.2",
    );
  });

  it("keeps year-titled works instead of emptying them", () => {
    expect(normalizeTitleEn("1923")).toBe("1923");
    expect(normalizeTitleEn("1917")).toBe("1917");
    expect(normalizeTitleEn("24")).toBe("24");
    expect(normalizeTitleEn("2001 A Space Odyssey")).toBe(
      "2001.A.Space.Odyssey",
    );
  });

  it("still drops genuine release tags after the change", () => {
    // Disc-count and codec forms must keep working, and a release year that
    // follows the title still truncates the tail.
    expect(normalizeTitleEn("Movie.2019.2DVD5.Rus")).toBe("Movie");
    expect(normalizeTitleEn("Movie.1080p.BluRay.x264.5.1")).toBe("Movie");
    expect(normalizeTitleEn("Some.Show.S01E03.720p.WEB-DL.x264.mkv")).toBe(
      "Some.Show",
    );
    expect(
      normalizeTitleEn("Kronprinz.Rudolf.2006.576P.H264.10bit.AC3.P2"),
    ).toBe("Kronprinz.Rudolf");
  });
});

// ─── buildStandardizedName ────────────────────────────────────────────────────

describe("buildStandardizedName", () => {
  it("builds name with year, resolution and source", () => {
    const name = buildStandardizedName(
      "哈姆雷特",
      "Hamlet",
      1996,
      "Hamlet.1996.2160p.Remux.mkv",
      "x264_10bit",
      "mkv",
    );
    expect(name).toBe("哈姆雷特.Hamlet.1996.2160p.Remux.x264-10bit.mkv");
  });

  it("strips filesystem-unsafe characters from titles", () => {
    const name = buildStandardizedName(
      "A:B?C",
      undefined,
      2000,
      "x.mkv",
      "x264",
      "mkv",
    );
    expect(name.startsWith("ABC.")).toBe(true);
  });
});

// ─── mergeResults ─────────────────────────────────────────────────────────────

const base = (over: Partial<MetadataResult>): MetadataResult => ({
  title: "Hamlet",
  mediaType: "movie",
  source: "tmdb",
  ...over,
});

describe("mergeResults", () => {
  it("dedupes by imdbId across providers, first list wins", () => {
    const tmdb = [base({ imdbId: "tt0116477", tmdbId: 10549, year: 1996 })];
    const omdb = [
      base({
        imdbId: "tt0116477",
        source: "omdb",
        year: 1996,
        director: "Kenneth Branagh",
      }),
    ];
    const merged = mergeResults(tmdb, omdb);
    expect(merged).toHaveLength(1);
    expect(merged[0].source).toBe("tmdb");
    expect(merged[0].tmdbId).toBe(10549);
    // missing field backfilled from the shadowed duplicate
    expect(merged[0].director).toBe("Kenneth Branagh");
  });

  it("keeps different versions of the same title separate by year", () => {
    const merged = mergeResults([
      base({ title: "Hamlet", titleEn: "Hamlet", year: 1948 }),
      base({ title: "Hamlet", titleEn: "Hamlet", year: 1996 }),
      base({ title: "Hamlet", titleEn: "Hamlet", year: 2000 }),
    ]);
    expect(merged).toHaveLength(3);
  });

  it("backfills an IMDb id when a richer provider has no id but another provider does", () => {
    const tmdb = [
      base({
        title: "Hamlet",
        titleEn: "Hamlet",
        year: 1996,
        overview: "A drama",
      }),
    ];
    const omdb = [
      base({
        title: "Hamlet",
        titleEn: "Hamlet",
        year: 1996,
        source: "omdb",
        imdbId: "tt0116477",
      }),
    ];
    const merged = mergeResults(tmdb, omdb);
    expect(merged).toHaveLength(1);
    expect(merged[0].imdbId).toBe("tt0116477");
  });

  it("does not overwrite existing fields with empty strings", () => {
    const merged = mergeResults(
      [base({ imdbId: "tt1", overview: "剧情简介" })],
      [base({ imdbId: "tt1", source: "omdb", overview: "" })],
    );
    expect(merged[0].overview).toBe("剧情简介");
  });
});

// ─── searchOmdb ───────────────────────────────────────────────────────────────

describe("searchOmdb", () => {
  const opts = { apiKey: "k", originalQuery: "Hamlet.1996.mkv" };

  it("maps search + detail responses into results", async () => {
    const fetchFn = vi.fn(async (url: string | URL) => {
      const u = String(url);
      if (u.includes("s=")) {
        return jsonResponse({
          Response: "True",
          Search: [
            {
              imdbID: "tt0116477",
              Title: "Hamlet",
              Year: "1996",
              Type: "movie",
              Poster: "N/A",
            },
          ],
        });
      }
      return jsonResponse({
        Director: "Kenneth Branagh",
        Genre: "Drama",
        imdbRating: "7.8",
        imdbVotes: "123,456",
        Metascore: "72",
        Ratings: [{ Source: "Rotten Tomatoes", Value: "85%" }],
        Plot: "Prince of Denmark…",
        Runtime: "242 min",
      });
    }) as unknown as typeof fetch;

    const results = await searchOmdb("Hamlet", opts, fetchFn);
    expect(results).toHaveLength(1);
    expect(results[0]).toMatchObject({
      imdbId: "tt0116477",
      source: "omdb",
      director: "Kenneth Branagh",
      rating: 7.8,
      runtimeMinutes: 242,
      year: 1996,
      ratingVotes: 123456,
      rottenTomatoesRating: 85,
      metacriticRating: 72,
    });
  });

  it("returns [] on 'Movie not found!' instead of throwing", async () => {
    const fetchFn = vi.fn(async () =>
      jsonResponse({ Response: "False", Error: "Movie not found!" }),
    ) as unknown as typeof fetch;
    expect(await searchOmdb("zzz", opts, fetchFn)).toEqual([]);
  });

  // Regression: the detail request never asked for `Actors`, so cast was blank
  // for every title while the user could see full cast lists anywhere else.
  it("keeps every actor and director instead of only the first", async () => {
    const fetchFn = vi.fn(async (url: string | URL) => {
      const u = String(url);
      if (u.includes("s=")) {
        return jsonResponse({
          Response: "True",
          Search: [
            {
              imdbID: "tt0116477",
              Title: "Hamlet",
              Year: "1996",
              Type: "movie",
              Poster: "N/A",
            },
          ],
        });
      }
      return jsonResponse({
        Director: "Kenneth Branagh",
        Actors: "Kenneth Branagh, Julie Christie, Derek Jacobi, Kate Winslet",
        Genre: "Drama, Romance",
        Plot: "Prince of Denmark…",
        Runtime: "242 min",
      });
    }) as unknown as typeof fetch;

    const results = await searchOmdb("Hamlet", opts, fetchFn);
    expect(results[0].director).toBe("Kenneth Branagh");
    expect(results[0].cast).toBe(
      "Kenneth Branagh、Julie Christie、Derek Jacobi、Kate Winslet",
    );
    expect(results[0].genres).toBe("Drama、Romance");
  });

  it("throws on real provider errors (bad key)", async () => {
    const fetchFn = vi.fn(async () =>
      jsonResponse({ Response: "False", Error: "Invalid API key!" }),
    ) as unknown as typeof fetch;
    await expect(searchOmdb("Hamlet", opts, fetchFn)).rejects.toThrow(
      /Invalid API key/,
    );
  });
});

describe("mergeMetadataByIdentity", () => {
  it("uses richer matching providers to fill fields on an IMDb suggestion", () => {
    const merged = mergeMetadataByIdentity(
      [
        base({
          title: "In the Opinion of the Censor",
          titleEn: "In the Opinion of the Censor",
          year: 2025,
          imdbId: "tt36988628",
          poster: "https://m.media-amazon.com/poster.jpg",
          source: "imdb",
        }),
        base({
          title: "In the Opinion of the Censor",
          titleEn: "In the Opinion of the Censor",
          year: 2025,
          imdbId: "tt36988628",
          rating: 7.4,
          director: "Jane Doe",
          genres: "Documentary",
          source: "omdb",
        }),
      ],
      "In.the.Opinion.of.the.Censor",
      2025,
    );

    expect(merged).toMatchObject({
      imdbId: "tt36988628",
      rating: 7.4,
      director: "Jane Doe",
      genres: "Documentary",
      poster: "https://m.media-amazon.com/poster.jpg",
    });
  });

  it("builds a compact structured snapshot without mixing ratings", () => {
    const snapshot = buildAssistantMetadataSnapshot({
      title: "Hamlet",
      titleEn: "Hamlet",
      year: 1996,
      imdbId: "tt0116477",
      rating: 7.8,
      ratingSource: "imdb",
      ratingVotes: 123456,
      doubanId: "1295644",
      doubanRating: 8.2,
      rottenTomatoesRating: 85,
      metacriticRating: 72,
      director: "Kenneth Branagh",
      cast: "Kenneth Branagh, Derek Jacobi",
      genres: "Drama",
      mediaType: "movie",
      source: "omdb",
    });

    if (!snapshot) throw new Error("expected structured metadata snapshot");
    expect(snapshot).toMatchObject({
      identityStatus: "confirmed",
      imdb: { id: "tt0116477", rating: 7.8, votes: 123456 },
      douban: { id: "1295644", rating: 8.2 },
      rottenTomatoes: 85,
      metacritic: 72,
      director: "Kenneth Branagh",
    });
    expect(snapshot.cast).toEqual(["Kenneth Branagh", "Derek Jacobi"]);
  });
});

describe("mergeMetadataByIdentity poster provenance", () => {
  it("does not promote a Wikipedia-related image to the canonical poster", () => {
    const merged = mergeMetadataByIdentity(
      [
        {
          title: "Example Film",
          titleEn: "Example Film",
          year: 2020,
          imdbId: "tt1234567",
          mediaType: "movie",
          source: "imdb",
        },
        {
          title: "Example Film",
          titleEn: "Example Film",
          year: 2020,
          overview: "Useful context",
          poster: "https://upload.wikimedia.org/related.jpg",
          mediaType: "movie",
          source: "wikipedia",
        },
      ],
      "Example Film",
      2020,
    );
    expect(merged?.poster).toBeUndefined();
    expect(merged?.imdbId).toBe("tt1234567");
  });
});

// ─── IMDb suggestion (no-key identity + poster fallback) ────────────────────

describe("searchImdbSuggestion", () => {
  it("maps the same IMDb suggestion to both identity and poster", async () => {
    const fetchFn = vi.fn(async (url: string | URL) => {
      expect(String(url)).toContain(
        "v3.sg.media-imdb.com/suggestion/x/Hamlet.json",
      );
      return jsonResponse({
        d: [
          {
            id: "tt0116477",
            l: "Hamlet",
            y: 1996,
            q: "feature",
            i: { imageUrl: "https://m.media-amazon.com/images/M/hamlet.jpg" },
          },
          { id: "tt0000001", l: "Hamlet", y: 1948, q: "feature" },
        ],
      });
    }) as unknown as typeof fetch;

    const results = await searchImdbSuggestion(
      "Hamlet",
      {
        year: 1996,
        originalQuery: "Hamlet.1996.mkv",
      },
      fetchFn,
    );

    expect(results[0]).toMatchObject({
      imdbId: "tt0116477",
      title: "Hamlet",
      titleEn: "Hamlet",
      year: 1996,
      poster: "https://m.media-amazon.com/images/M/hamlet.jpg",
      mediaType: "movie",
      source: "imdb",
    });
  });
});

describe("searchImdbTitlePage", () => {
  it("extracts rating, director and genres from IMDb JSON-LD", async () => {
    const fetchFn = vi.fn(
      async () =>
        new Response(
          `<!doctype html><script type="application/ld+json">${JSON.stringify({
            "@type": "Movie",
            name: "In the Opinion of the Censor",
            datePublished: "2025-01-01",
            genre: ["Documentary"],
            director: [{ name: "Jane Doe" }],
            aggregateRating: { ratingValue: "7.4" },
            image: "https://m.media-amazon.com/images/M/exact.jpg",
          })}</script>`,
        ),
    ) as unknown as typeof fetch;

    await expect(
      searchImdbTitlePage(
        "tt36988628",
        { originalQuery: "In the Opinion of the Censor" },
        fetchFn,
      ),
    ).resolves.toMatchObject({
      imdbId: "tt36988628",
      rating: 7.4,
      director: "Jane Doe",
      genres: "Documentary",
      year: 2025,
      poster: "https://m.media-amazon.com/images/M/exact.jpg",
    });
  });
});

// ─── proxyAwareFetch ─────────────────────────────────────────────────────────

describe("proxyAwareFetch", () => {
  // Regression, confirmed against a live run: the poster proxy is auto-detected
  // from a listening local port (10809/10808), so an unrelated process owning
  // that port silently routed every metadata request into an unusable proxy.
  // Every provider reported "代理请求失败" while a direct request to the same
  // URL succeeded, which made metadata look broken at the source.
  it("fails over to a direct request when the proxy cannot serve it", async () => {
    const calls: Array<string | null> = [];
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => {
        calls.push("direct");
        return new Response(JSON.stringify({ d: [] }), {
          status: 200,
          headers: { "Content-Type": "application/json" },
        });
      }),
    );
    // Nothing is listening on this port, so the tunnel path fails immediately.
    const request = proxyAwareFetch("http://127.0.0.1:1");
    const response = await request(
      "https://v3.sg.media-imdb.com/suggestion/x/2046.json",
    );
    expect(response.status).toBe(200);
    expect(calls).toContain("direct");
  });

  it("reports an error only when both the proxy and the direct path fail", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => {
        throw new Error("network down");
      }),
    );
    const request = proxyAwareFetch("http://127.0.0.1:1");
    await expect(
      request("https://v3.sg.media-imdb.com/suggestion/x/2046.json"),
    ).rejects.toThrow(/代理与直连均失败/);
  });

  it("uses the direct path when no proxy is configured", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => new Response("{}", { status: 200 })),
    );
    const request = proxyAwareFetch(null);
    const response = await request(
      "https://v3.sg.media-imdb.com/suggestion/x/2046.json",
    );
    expect(response.status).toBe(200);
  });
});

// ─── searchTmdb ───────────────────────────────────────────────────────────────

describe("searchTmdb", () => {
  const opts = {
    language: "zh-CN",
    apiKey: "k",
    originalQuery: "Hamlet.1996.mkv",
  };

  it("maps results and picks up imdb_id from external_ids", async () => {
    const fetchFn = vi.fn(async (url: string | URL) => {
      const u = String(url);
      if (u.includes("/search/multi")) {
        return jsonResponse({
          results: [
            {
              id: 10549,
              title: "哈姆雷特",
              original_title: "Hamlet",
              release_date: "1996-12-25",
              vote_average: 7.6,
              overview: "…",
              poster_path: "/p.jpg",
              media_type: "movie",
            },
          ],
        });
      }
      return jsonResponse({
        credits: { crew: [{ job: "Director", name: "Kenneth Branagh" }] },
        genres: [{ name: "剧情" }],
        external_ids: { imdb_id: "tt0116477" },
        runtime: 242,
      });
    }) as unknown as typeof fetch;

    const results = await searchTmdb("Hamlet", opts, fetchFn);
    expect(results[0]).toMatchObject({
      tmdbId: 10549,
      imdbId: "tt0116477",
      title: "哈姆雷特",
      source: "tmdb",
      runtimeMinutes: 242,
    });
  });

  it("throws on non-ok responses", async () => {
    const fetchFn = vi.fn(async () =>
      jsonResponse({}, 401),
    ) as unknown as typeof fetch;
    await expect(searchTmdb("Hamlet", opts, fetchFn)).rejects.toThrow(/401/);
  });

  // Regression: the detail call already appended `credits`, but only `crew`
  // was typed and read, so `credits.cast` was downloaded and thrown away and
  // the actor field stayed empty for every TMDb lookup.
  it("keeps the cast list and every credited director", async () => {
    const fetchFn = vi.fn(async (url: string | URL) => {
      const u = String(url);
      if (u.includes("/search/multi")) {
        return jsonResponse({
          results: [
            {
              id: 10549,
              title: "哈姆雷特",
              original_title: "Hamlet",
              release_date: "1996-12-25",
              vote_average: 7.6,
              overview: "…",
              poster_path: "/p.jpg",
              media_type: "movie",
            },
          ],
        });
      }
      return jsonResponse({
        credits: {
          crew: [
            { job: "Director", name: "Kenneth Branagh" },
            { job: "Producer", name: "David Barron" },
          ],
          cast: [
            { name: "Kate Winslet", order: 2 },
            { name: "Kenneth Branagh", order: 0 },
            { name: "Julie Christie", order: 1 },
          ],
        },
        genres: [{ name: "剧情" }],
        external_ids: { imdb_id: "tt0116477" },
        runtime: 242,
      });
    }) as unknown as typeof fetch;

    const results = await searchTmdb("Hamlet", opts, fetchFn);
    // Billing order is the meaningful order, not the payload order.
    expect(results[0].cast).toBe(
      "Kenneth Branagh、Julie Christie、Kate Winslet",
    );
    expect(results[0].director).toBe("Kenneth Branagh");
  });

  it("falls back to the creators for a series that has no director credit", async () => {
    const fetchFn = vi.fn(async (url: string | URL) => {
      const u = String(url);
      if (u.includes("/search/multi")) {
        return jsonResponse({
          results: [
            {
              id: 1396,
              name: "绝命毒师",
              original_name: "Breaking Bad",
              first_air_date: "2008-01-20",
              vote_average: 8.9,
              overview: "…",
              poster_path: "/bb.jpg",
              media_type: "tv",
            },
          ],
        });
      }
      return jsonResponse({
        credits: { crew: [], cast: [{ name: "Bryan Cranston", order: 0 }] },
        created_by: [{ name: "Vince Gilligan" }],
        genres: [{ name: "剧情" }],
      });
    }) as unknown as typeof fetch;

    const results = await searchTmdb("Breaking Bad", opts, fetchFn);
    expect(results[0].director).toBe("Vince Gilligan");
    expect(results[0].cast).toBe("Bryan Cranston");
  });
});

// ─── lookupAll — the OMDb-fallback regression ─────────────────────────────────

describe("lookupAll", () => {
  const config = {
    tmdbApiKey: "bad-key",
    omdbApiKey: "good-key",
    imdbTitleCount: 0,
  } as unknown as typeof configTable.$inferSelect;

  it("still returns OMDb results when TMDb fails (the original bug)", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async (url: string | URL) => {
        const u = String(url);
        if (u.includes("themoviedb.org")) return jsonResponse({}, 401);
        if (u.includes("omdbapi.com") && u.includes("s=")) {
          return jsonResponse({
            Response: "True",
            Search: [
              {
                imdbID: "tt0116477",
                Title: "Hamlet",
                Year: "1996",
                Type: "movie",
                Poster: "N/A",
              },
            ],
          });
        }
        return jsonResponse({ Director: "Kenneth Branagh" });
      }),
    );

    const { results, errors } = await lookupAll({
      rawQuery: "Hamlet.1996.mkv",
      language: "zh-CN",
      config,
    });
    expect(results).toHaveLength(1);
    expect(results[0].imdbId).toBe("tt0116477");
    expect(errors.some((e) => e.startsWith("TMDb"))).toBe(true);
  });

  it("skips providers with no key configured", async () => {
    const fetchSpy = vi.fn(async (url: string | URL) => {
      const u = String(url);
      expect(u).not.toContain("themoviedb.org");
      return jsonResponse({ Response: "False", Error: "Movie not found!" });
    });
    vi.stubGlobal("fetch", fetchSpy);

    const cfg = {
      tmdbApiKey: null,
      omdbApiKey: "k",
      imdbTitleCount: 0,
    } as unknown as typeof configTable.$inferSelect;
    const { results, errors } = await lookupAll({
      rawQuery: "zzz.mkv",
      language: "zh-CN",
      config: cfg,
    });
    expect(results).toEqual([]);
    expect(errors).toEqual([]);
  });

  it("normalizes dotted titles before querying IMDb suggestion", async () => {
    const fetchSpy = vi.fn(async (url: string | URL) => {
      const u = String(url);
      if (u.includes("v3.sg.media-imdb.com")) {
        expect(u).toContain("In%20the%20Opinion%20of%20the%20Censor");
        return jsonResponse({
          d: [
            {
              id: "tt36988628",
              l: "In the Opinion of the Censor",
              y: 2025,
              q: "feature",
            },
          ],
        });
      }
      if (u.includes("itunes.apple.com")) return jsonResponse({ results: [] });
      if (u.includes("tvmaze.com")) return jsonResponse([]);
      if (u.includes("wikipedia.org"))
        return jsonResponse({ query: { pages: {} } });
      if (u.includes("douban.com")) return jsonResponse([]);
      return jsonResponse({});
    });
    vi.stubGlobal("fetch", fetchSpy);

    const cfg = {
      tmdbApiKey: null,
      omdbApiKey: null,
      imdbTitleCount: 0,
    } as unknown as typeof configTable.$inferSelect;
    const { results } = await lookupAll({
      rawQuery: "RTE.In.the.Opinion.of.the.Censor",
      language: "zh-CN",
      config: cfg,
    });
    expect(results[0]).toMatchObject({ imdbId: "tt36988628", year: 2025 });
  });
});

// ─── searchDouban (keyless, Chinese titles) ───────────────────────────────────

describe("searchDouban", () => {
  const opts = { originalQuery: "A.Beautiful.Mind.2001.美丽心灵" };
  const response = () =>
    jsonResponse([
      {
        id: "1306029",
        title: "美丽心灵",
        sub_title: "A Beautiful Mind",
        year: "2001",
        img: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p1665997400.jpg",
        type: "movie",
      },
    ]);

  // The unique value of this source: one response carries both the Chinese and
  // the English title, so a folder named in either language resolves.
  it("maps the Douban id and both titles onto one identity", async () => {
    const fetchFn = vi.fn(async () => response()) as unknown as typeof fetch;
    const results = await searchDouban("A Beautiful Mind", {
      year: 2001,
      ...opts,
      fetchFn,
    });
    expect(results).toHaveLength(1);
    expect(results[0]).toMatchObject({
      doubanId: "1306029",
      title: "美丽心灵",
      titleEn: "A Beautiful Mind",
      year: 2001,
      source: "douban",
      mediaType: "movie",
    });
    expect(results[0].poster).toContain("doubanio.com");
  });

  it("matches a Chinese query against the English title it returns", async () => {
    const fetchFn = vi.fn(async () => response()) as unknown as typeof fetch;
    const results = await searchDouban("美丽心灵", { ...opts, fetchFn });
    expect(results[0].doubanId).toBe("1306029");
  });

  it("drops entries without an id or title", async () => {
    const fetchFn = vi.fn(async () =>
      jsonResponse([
        { id: "", title: "无号" },
        { id: "1", title: "" },
        { id: "2", title: "有效", sub_title: "Valid" },
      ]),
    ) as unknown as typeof fetch;
    const results = await searchDouban("有效", { ...opts, fetchFn });
    expect(results).toHaveLength(1);
    expect(results[0].doubanId).toBe("2");
  });

  it("treats a non-array payload as no results", async () => {
    const fetchFn = vi.fn(async () =>
      jsonResponse({ unexpected: true }),
    ) as unknown as typeof fetch;
    expect(await searchDouban("x", { ...opts, fetchFn })).toEqual([]);
  });

  it("returns nothing for an empty query without requesting", async () => {
    const fetchFn = vi.fn(async () => response()) as unknown as typeof fetch;
    expect(await searchDouban("   ", { ...opts, fetchFn })).toEqual([]);
    expect(fetchFn).not.toHaveBeenCalled();
  });

  it("surfaces an HTTP failure as an error", async () => {
    const fetchFn = vi.fn(async () =>
      jsonResponse({}, 500),
    ) as unknown as typeof fetch;
    await expect(searchDouban("x", { ...opts, fetchFn })).rejects.toThrow(
      /500/,
    );
  });
});

describe("title cleaning keeps names that collide with language tags", () => {
  it("keeps a person's name inside the title", () => {
    expect(
      normalizeTitleEn(
        "The.Odyssey.with.Dan.Snow.1080p.HDTV.x265.AAC.MVGroup.org",
      ),
    ).toBe("The.Odyssey.with.Dan.Snow");
    expect(normalizeTitleEn("Dan.in.Real.Life.2007")).toBe("Dan.in.Real.Life");
  });

  it("still drops a trailing language, region or edition code", () => {
    expect(normalizeTitleEn("Some.Movie.2019.MULTI.1080p")).toBe("Some.Movie");
    expect(normalizeTitleEn("Some.Movie.ENG")).toBe("Some.Movie");
  });

  it("never empties a one-word title that looks like a code", () => {
    expect(normalizeTitleEn("Us")).toBe("Us");
  });
});

describe("identity matching rejects a different work of the same shape", () => {
  it("does not accept another documentary by the same presenter", () => {
    expect(
      metadataIdentityMatches({
        candidate: {
          title: "The Colosseum with Dan Snow",
          titleEn: "The Colosseum with Dan Snow",
          year: 2024,
        },
        queryTitle: "The.Odyssey.with.Dan.Snow",
        queryYear: 2026,
      }),
    ).toBe(false);
  });

  it("still accepts the work that was asked for", () => {
    expect(
      metadataIdentityMatches({
        candidate: {
          title: "The Odyssey with Dan Snow",
          titleEn: "The Odyssey with Dan Snow",
          year: 2026,
        },
        queryTitle: "The.Odyssey.with.Dan.Snow",
        queryYear: 2026,
      }),
    ).toBe(true);
  });
});
