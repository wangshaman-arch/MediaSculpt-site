import { Pencil, Save, SlidersHorizontal, X } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Card, CardContent } from "../../components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../components/ui/select";
import {
  ENCODER_OPTIONS,
  FRAME_RATE_OPTIONS,
  LEVEL_OPTIONS,
  PRESET_SPEED_OPTIONS,
  PROFILE_OPTIONS,
  RESOLUTION_OPTIONS,
  TUNE_OPTIONS,
  CUSTOM_COMPRESSION_PRESET_ID,
  type CompressionPresetValues,
  type ArchivePreset,
} from "../../lib/compression-presets";
import { cn } from "../../lib/utils";
import {
  compressionPresetSummary,
  customPresetSummary,
} from "./compression-preset-model";

type Translate = (
  key: string,
  params?: Record<string, string | number>,
) => string;
export interface CompressionPresetPanelProps {
  presets: ArchivePreset[];
  selectedPresetLabel: string;
  customCompression: CompressionPresetValues;
  editingPresetId: string | null;
  editDraft: CompressionPresetValues | null;
  t: Translate;
  onSelectPreset: (preset: ArchivePreset) => void;
  onSelectCustomPreset: () => void;
  onStartEditCustomPreset: () => void;
  onStartEdit: (preset: ArchivePreset) => void;
  onResetEditedPreset: () => void;
  onUpdateEditDraft: (next: Partial<CompressionPresetValues>) => void;
  onSaveEditedPreset: () => void | Promise<void>;
  onCancelEdit: () => void;
}

export function CompressionPresetPanel({
  presets,
  selectedPresetLabel,
  customCompression,
  editingPresetId,
  editDraft,
  t,
  onSelectPreset,
  onSelectCustomPreset,
  onStartEditCustomPreset,
  onStartEdit,
  onResetEditedPreset,
  onUpdateEditDraft,
  onSaveEditedPreset,
  onCancelEdit,
}: CompressionPresetPanelProps) {
  return (
    <Card>
      <CardContent className="px-3 pb-2 pt-2">
        <p className="mb-1.5 text-xs font-medium text-muted-foreground">
          {t("jobDetail.compressionPresetTitle")}
        </p>
        <div
          data-testid="compression-preset-grid"
          className="grid grid-cols-3 gap-2.5"
        >
          {presets.map((preset) => (
            <div
              key={preset.id}
              className={cn(
                "flex min-h-24 min-w-0 overflow-hidden rounded-lg border transition",
                selectedPresetLabel === preset.id
                  ? "border-primary bg-primary/10"
                  : "bg-background/55 hover:border-primary/50 hover:bg-primary/5",
              )}
            >
              <button
                type="button"
                onClick={() => onSelectPreset(preset)}
                className="flex min-w-0 flex-1 items-center gap-3 p-3 text-left"
              >
                <span
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-md bg-primary/10 text-2xl leading-none"
                  aria-hidden="true"
                >
                  {preset.icon}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-semibold">
                    {t(preset.labelKey)}
                  </span>
                  <span className="mt-1 block truncate text-[11px] text-primary">
                    {compressionPresetSummary(preset.values, t)}
                  </span>
                  <span className="mt-1 block max-h-8 overflow-hidden text-[11px] leading-4 text-muted-foreground">
                    {t(preset.descriptionKey)}
                  </span>
                </span>
              </button>
              <button
                type="button"
                onClick={() => onStartEdit(preset)}
                className={cn(
                  "flex w-10 shrink-0 items-center justify-center border-l transition-colors",
                  editingPresetId === preset.id
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground",
                )}
                title={t("settings.editPresetTitle")}
              >
                {editingPresetId === preset.id ? (
                  <X className="h-4 w-4" />
                ) : (
                  <Pencil className="h-4 w-4" />
                )}
              </button>
            </div>
          ))}
          <div
            className={cn(
              "flex min-h-24 min-w-0 overflow-hidden rounded-lg border transition",
              selectedPresetLabel === CUSTOM_COMPRESSION_PRESET_ID
                ? "border-primary bg-primary/10"
                : "bg-background/55 hover:border-primary/50 hover:bg-primary/5",
            )}
          >
            <button
              type="button"
              onClick={onSelectCustomPreset}
              className="flex min-w-0 flex-1 items-center gap-3 p-3 text-left"
              data-testid="compression-custom-preset"
            >
              <span
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary"
                aria-hidden="true"
              >
                <SlidersHorizontal className="h-6 w-6" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-semibold">
                  {t("settings.customPreset")}
                </span>
                <span className="mt-1 block truncate text-[11px] text-primary">
                  {customPresetSummary(customCompression, t)}
                </span>
                <span className="mt-1 block max-h-8 overflow-hidden text-[11px] leading-4 text-muted-foreground">
                  {t("settings.customPresetDesc")}
                </span>
              </span>
            </button>
            <button
              type="button"
              onClick={onStartEditCustomPreset}
              className={cn(
                "flex w-10 shrink-0 items-center justify-center border-l transition-colors",
                editingPresetId === CUSTOM_COMPRESSION_PRESET_ID
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground",
              )}
              title={t("settings.editCustomPreset")}
            >
              {editingPresetId === CUSTOM_COMPRESSION_PRESET_ID ? (
                <X className="h-4 w-4" />
              ) : (
                <Pencil className="h-4 w-4" />
              )}
            </button>
          </div>
        </div>

        {editingPresetId && editDraft && (
          <div className="mt-3 space-y-3 rounded-lg border border-primary/30 bg-primary/5 p-4">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold">
                {t("settings.editingPreset", {
                  name:
                    editingPresetId === CUSTOM_COMPRESSION_PRESET_ID
                      ? t("settings.customPreset")
                      : t(
                          presets.find(
                            (preset) => preset.id === editingPresetId,
                          )?.labelKey ?? "",
                        ),
                })}
              </p>
              <button
                type="button"
                onClick={onResetEditedPreset}
                className="text-xs text-muted-foreground underline underline-offset-2 transition-colors hover:text-foreground"
              >
                {t("settings.resetDefaults")}
              </button>
            </div>
            <div className="grid gap-3 sm:grid-cols-4">
              <div className="space-y-1">
                <label className="block text-xs font-medium">
                  {t("settings.crfQuality", { value: editDraft.crf })}
                </label>
                <input
                  type="range"
                  min={0}
                  max={51}
                  step={1}
                  value={editDraft.crf}
                  onChange={(event) =>
                    onUpdateEditDraft({
                      crf: parseInt(event.currentTarget.value),
                    })
                  }
                  className="vx-range w-full"
                />
                <div className="flex justify-between text-[10px] text-muted-foreground">
                  <span>{t("settings.lossless")}</span>
                  <span>{t("settings.worst")}</span>
                </div>
              </div>
              <div className="space-y-1">
                <label className="block text-xs font-medium">
                  {t("settings.encoderLabel")}
                </label>
                <Select
                  value={editDraft.encoder}
                  onValueChange={(value) =>
                    onUpdateEditDraft({ encoder: value })
                  }
                >
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ENCODER_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {t(option.labelKey)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <label className="block text-xs font-medium">
                  {t("settings.speedPreset")}
                </label>
                <Select
                  value={editDraft.encoderPreset}
                  onValueChange={(value) =>
                    onUpdateEditDraft({ encoderPreset: value })
                  }
                >
                  <SelectTrigger className="h-8 text-xs font-mono">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PRESET_SPEED_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {t(option.labelKey)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <label className="block text-xs font-medium">
                  {t("settings.tuneLabel")}
                </label>
                <Select
                  value={editDraft.encoderTune}
                  onValueChange={(value) =>
                    onUpdateEditDraft({ encoderTune: value })
                  }
                >
                  <SelectTrigger className="h-8 text-xs font-mono">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TUNE_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {t(option.labelKey)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <label className="block text-xs font-medium">
                  {t("settings.profileLabel")}
                </label>
                <Select
                  value={editDraft.encoderProfile}
                  onValueChange={(value) =>
                    onUpdateEditDraft({ encoderProfile: value })
                  }
                >
                  <SelectTrigger className="h-8 text-xs font-mono">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PROFILE_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {t(option.labelKey)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <label className="block text-xs font-medium">
                  {t("settings.levelLabel")}
                </label>
                <Select
                  value={editDraft.encoderLevel}
                  onValueChange={(value) =>
                    onUpdateEditDraft({ encoderLevel: value })
                  }
                >
                  <SelectTrigger className="h-8 text-xs font-mono">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {LEVEL_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {t(option.labelKey)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <label className="block text-xs font-medium">
                  {t("settings.frameRate")}
                </label>
                <Select
                  value={editDraft.frameRate}
                  onValueChange={(value) =>
                    onUpdateEditDraft({ frameRate: value })
                  }
                >
                  <SelectTrigger className="h-8 text-xs font-mono">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {FRAME_RATE_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {t(option.labelKey)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <label className="block text-xs font-medium">
                  {t("jobDetail.resolutionTag")}
                </label>
                <Select
                  value={editDraft.outputResolution ?? "source"}
                  onValueChange={(value) =>
                    onUpdateEditDraft({ outputResolution: value })
                  }
                >
                  <SelectTrigger className="h-8 text-xs font-mono">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {RESOLUTION_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {t(option.labelKey)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex gap-2 pt-1">
              <Button
                type="button"
                size="sm"
                className="h-8"
                onClick={() => void onSaveEditedPreset()}
              >
                <Save className="mr-1.5 h-3.5 w-3.5" />
                {t("settings.savePresetApply")}
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-8"
                onClick={onCancelEdit}
              >
                {t("common.cancel")}
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
