import { Router } from "express";
import os from "node:os";
import path from "node:path";
import fs from "node:fs/promises";
import { createHash } from "node:crypto";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { resolveToolPath } from "../lib/tool-runtime";
import { recordPreviewAiCall } from "../lib/preview-runtime";
import {
  detectExternalSubtitles,
  listSmartWorkflowMediaFiles,
} from "../lib/smart-workflow-media";
import { isBlurayDisc, isDvdDisc } from "../lib/disc";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import { getConfig } from "./jobs-config";
import { normalizeTitleEn } from "../lib/metadata";
import {
  buildTuningLogicContext,
  parseCustomTuning,
  resolveLogicPlaceholders,
} from "../lib/custom-tuning";
import {
  buildSmartWorkflowPlan,
  validateSmartWorkflowPlan,
  type SmartWorkflowMediaInput,
  type SmartWorkflowIdentity,
  type SmartWorkflowPlan,
} from "../lib/smart-workflow";

const execFileAsync = promisify(execFile);
const router = Router();

function redactClientLog(value: unknown, limit = 1200): string {
  return String(value ?? "")
    .replace(
      /(api[_-]?key|authorization|token|secret)\s*[:=]\s*[^,\s}]+/gi,
      "$1=[redacted]",
    )
    .slice(0, limit);
}

/** Find DVD/Blu-ray disc folders below a directory (bounded depth). */
async function findDiscSubdirectories(
  directory: string,
  maxDepth = 3,
): Promise<string[]> {
  const found: string[] = [];
  const visit = async (current: string, depth: number): Promise<void> => {
    if (depth > maxDepth) return;
    if (
      current !== directory &&
      ((await isDvdDisc(current).catch(() => false)) ||
        (await isBlurayDisc(current).catch(() => false)))
    ) {
      found.push(current);
      return;
    }
    let entries;
    try {
      entries = await fs.readdir(current, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      if (!entry.isDirectory() || entry.name.startsWith(".")) continue;
      await visit(path.join(current, entry.name), depth + 1);
    }
  };
  await visit(directory, 0);
  return found;
}

function safeNumber(value: unknown): number | null {
  const result = Number(value);
  return Number.isFinite(result) ? result : null;
}

async function fingerprint(
  filePath: string,
  stat: { size: number; mtimeMs: number },
): Promise<string> {
  return createHash("sha256")
    .update(`${path.resolve(filePath)}:${stat.size}:${stat.mtimeMs}`)
    .digest("hex");
}

/** Probe ordinary media once. Disc folders deliberately continue through /disc/analyze. */
router.post("/smart-workflow/probe", async (req, res) => {
  const sourcePath =
    typeof req.body?.sourcePath === "string" ? req.body.sourcePath.trim() : "";
  if (!sourcePath)
    return res.status(400).json({ error: "sourcePath 不能为空" });
  const absolute = path.resolve(sourcePath);
  const stat = await fs.stat(absolute).catch(() => null);
  const ffprobe = await resolveToolPath("ffprobe");
  if (!ffprobe)
    return res.status(503).json({ error: "未找到项目实际使用的 FFprobe" });

  if (stat?.isDirectory()) {
    // BD/DVD folders must go through /disc/analyze; probing their internal
    // VOB/MKV files as standalone videos would misclassify them as speech
    // recognition targets.
    if ((await isDvdDisc(absolute)) || (await isBlurayDisc(absolute))) {
      return res.status(422).json({
        error:
          "该目录是 DVD/蓝光目录，请使用光盘分析（Remux/压缩），不会把其中的 VOB/MKV 当作独立视频处理。",
      });
    }
    // A directory that contains disc folders is a media-collection root, not
    // a single analyzable source. Analyzing it as loose files would probe
    // hundreds of m2ts/VOB files and misclassify them as standalone videos.
    const discDirs = await findDiscSubdirectories(absolute);
    if (discDirs.length > 0) {
      return res.status(422).json({
        error: `该目录包含 ${discDirs.length} 个光盘文件夹；请选择具体的光盘文件夹进行分析（智能工作流按单部影片/单张光盘处理）`,
        discDirectories: discDirs,
      });
    }
    const files = await listSmartWorkflowMediaFiles(absolute).catch(() => []);
    if (files.length === 0)
      return res
        .status(422)
        .json({ error: "该目录中没有找到可分析的媒体文件" });
    if (files.length > 120) {
      return res.status(422).json({
        error: `该目录包含 ${files.length} 个媒体文件，请选择包含单部影片的子目录进行分析`,
      });
    }
    const results = [];
    for (const filePath of files) {
      const fileStat = await fs.stat(filePath);
      const response = await probeSmartWorkflowFile(
        ffprobe,
        filePath,
        fileStat,
      );
      if (response.ok) results.push(response.value);
    }
    if (results.length === 0)
      return res
        .status(422)
        .json({ error: "目录中的媒体文件均无法完成 FFprobe 分析" });
    return res.json({
      sourcePath: absolute,
      sourceType: "directory",
      files: results,
      diagnostics: {
        tool: "ffprobe",
        executable: ffprobe,
        fileCount: results.length,
      },
    });
  }
  if (!stat?.isFile())
    return res.status(400).json({ error: "来源不是可读取的文件或目录" });
  const response = await probeSmartWorkflowFile(ffprobe, absolute, stat);
  if (!response.ok) return res.status(response.status).json(response.body);
  return res.json(response.value);
});

/** Record browser-side workflow failures in the same root diagnostics file. */
router.post("/smart-workflow/client-log", async (req, res) => {
  const level =
    req.body?.level === "error" || req.body?.level === "warn"
      ? req.body.level
      : "info";
  const event = redactClientLog(req.body?.event, 120);
  const message = redactClientLog(req.body?.message, 1000);
  const details = redactClientLog(req.body?.details, 1600);
  if (!event || !message)
    return res
      .status(400)
      .json({ error: "event 和 message 不能为空", logPath: null });
  const { appendRuntimeToolLog, diagnosticsLogPath } =
    await import("../lib/runtime-tool-log");
  await appendRuntimeToolLog(
    `智能工作流客户端 level=${level} event=${event} message=${message}${details ? ` details=${details}` : ""}`,
  ).catch(() => {});
  return res.json({ logged: true, logPath: diagnosticsLogPath() });
});

/**
 * Ask the configured OpenAI-compatible provider for title candidates. This is
 * a planning/confirmation aid only: HandBrake/ffprobe remain authoritative
 * for media identity and the confirmed plan still enters the existing jobs
 * executor. If the provider is unavailable the client falls back to the
 * existing TMDb/OMDb/local lookup route.
 */
router.post("/smart-workflow/metadata", async (req, res) => {
  const query =
    typeof req.body?.query === "string" ? req.body.query.trim() : "";
  const language =
    typeof req.body?.language === "string" ? req.body.language : "zh-CN";
  const mediaContext = (Array.isArray(req.body?.media) ? req.body.media : [])
    .slice(0, 12)
    .map((media: Record<string, unknown>) => ({
      sourceType: media.sourceType,
      displayName: media.displayName,
      titleId: typeof media.titleId === "string" ? media.titleId : null,
      titleIndex: safeNumber(media.titleIndex),
      analysisId:
        typeof media.analysisId === "string" ? media.analysisId : null,
      durationSeconds: safeNumber(media.durationSeconds),
      sizeBytes: safeNumber(media.sizeBytes),
      chapterCount: Array.isArray(media.chapters) ? media.chapters.length : 0,
      streams: Array.isArray(media.streams)
        ? media.streams.slice(0, 16).map((stream: Record<string, unknown>) => ({
            type: stream.type,
            language: stream.language,
            codec: stream.codec,
            width: safeNumber(stream.width),
            height: safeNumber(stream.height),
            channels: safeNumber(stream.channels),
            frameRate:
              typeof stream.frameRate === "string" ? stream.frameRate : null,
            bitRate: safeNumber(stream.bitrate) ?? safeNumber(stream.bitRate),
            profile: typeof stream.profile === "string" ? stream.profile : null,
            hdr: stream.hdr === true,
            sampleRate: safeNumber(stream.sampleRate),
            channelLayout:
              typeof stream.channelLayout === "string"
                ? stream.channelLayout
                : null,
            default: stream.default === true,
            forced: stream.forced === true,
          }))
        : [],
    }));
  if (!query) return res.status(400).json({ error: "查询不能为空" });
  const config = await getConfig();
  const tuning = parseCustomTuning(config.customTuning);
  const endpoint = resolveAiEndpoint(config);
  const apiKey = resolveApiKey(config);
  if (!apiKey || endpoint.provider === "libretranslate") {
    return res
      .status(503)
      .json({ error: "未配置可用于影片资料确认的 LLM API Key" });
  }
  const startedAt = Date.now();
  const prompt = [
    resolveLogicPlaceholders(tuning.prompts.identity, tuning.logic),
    `查询：${query}`,
    `目标语言：${language}`,
    `媒体技术摘要：${JSON.stringify(mediaContext)}`,
    "请结合时长、章节数量、分辨率和轨道信息区分主片与花絮；不要修改 HandBrake/ffprobe 的标题 ID。若能可靠确认公开资料，请同时返回 imdbId（tt 开头）；无法确认时留空，不要猜测。",
    `用户调优逻辑参数：\n${buildTuningLogicContext(tuning.logic)}`,
  ].join("\n");
  try {
    const response = await fetch(
      `${endpoint.baseUrl.replace(/\/$/, "")}/chat/completions`,
      {
        method: "POST",
        signal: AbortSignal.timeout(20_000),
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: endpoint.model,
          temperature: 0.1,
          max_tokens: 1200,
          messages: [
            { role: "system", content: "你是影视资料确认助手。" },
            { role: "user", content: prompt },
          ],
        }),
      },
    );
    void recordPreviewAiCall("workflow-metadata").catch(() => {});
    const payload = (await response.json().catch(() => ({}))) as {
      choices?: Array<{ message?: { content?: unknown } }>;
      error?: { message?: string };
    };
    if (!response.ok)
      throw new Error(
        `LLM 返回 HTTP ${response.status}${payload.error?.message ? `：${payload.error.message}` : ""}`,
      );
    const content =
      typeof payload.choices?.[0]?.message?.content === "string"
        ? payload.choices[0].message.content
        : "[]";
    const jsonText = content
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/i, "")
      .trim();
    const parsed = JSON.parse(jsonText) as unknown;
    const candidates = Array.isArray(parsed)
      ? parsed.flatMap((item) => {
          if (!item || typeof item !== "object") return [];
          const value = item as Record<string, unknown>;
          const title =
            typeof value.title === "string" ? value.title.trim() : "";
          if (!title) return [];
          const mediaType = value.mediaType === "tv" ? "tv" : "movie";
          const confidence = Number(value.confidence);
          return [
            {
              title,
              titleEn:
                typeof value.titleEn === "string"
                  ? normalizeTitleEn(value.titleEn) || value.titleEn
                  : undefined,
              imdbId:
                typeof value.imdbId === "string" &&
                /^tt\d{7,8}$/i.test(value.imdbId.trim())
                  ? value.imdbId.trim()
                  : undefined,
              poster:
                typeof value.poster === "string" &&
                /^https?:\/\//i.test(value.poster.trim())
                  ? value.poster.trim()
                  : undefined,
              year: Number.isFinite(Number(value.year))
                ? Number(value.year)
                : undefined,
              overview:
                typeof value.overview === "string" ? value.overview : undefined,
              matchReason:
                typeof value.matchReason === "string"
                  ? value.matchReason
                  : undefined,
              technicalAssessment:
                typeof value.technicalAssessment === "string"
                  ? value.technicalAssessment
                  : undefined,
              recommendedAction:
                typeof value.recommendedAction === "string"
                  ? value.recommendedAction
                  : undefined,
              mediaType,
              confidence: Number.isFinite(confidence)
                ? Math.max(0, Math.min(1, confidence))
                : 0.5,
              source: `llm:${endpoint.provider}`,
            },
          ];
        })
      : [];
    await import("../lib/runtime-tool-log").then(({ appendRuntimeToolLog }) =>
      appendRuntimeToolLog(
        `智能工作流 LLM 影片确认：provider=${endpoint.provider} candidates=${candidates.length} durationMs=${Date.now() - startedAt}`,
      ).catch(() => {}),
    );
    return res.json(candidates);
  } catch (error) {
    await import("../lib/runtime-tool-log").then(({ appendRuntimeToolLog }) =>
      appendRuntimeToolLog(
        `智能工作流 LLM 影片确认失败：provider=${endpoint.provider} durationMs=${Date.now() - startedAt} error=${redactClientLog(error instanceof Error ? error.message : String(error))}`,
      ).catch(() => {}),
    );
    return res.status(502).json({
      error: `LLM 影片资料确认失败：${error instanceof Error ? error.message : String(error)}`,
    });
  }
});

async function probeSmartWorkflowFile(
  ffprobe: string,
  absolute: string,
  stat: { size: number; mtimeMs: number },
): Promise<
  | { ok: true; value: Record<string, unknown> }
  | { ok: false; status: number; body: Record<string, unknown> }
> {
  const startedAt = Date.now();
  const args = [
    "-hide_banner",
    "-v",
    "error",
    "-print_format",
    "json",
    "-show_format",
    "-show_streams",
    "-show_chapters",
    absolute,
  ];
  try {
    const result = await execFileAsync(ffprobe, args, {
      timeout: 60_000,
      maxBuffer: 32 * 1024 * 1024,
      windowsHide: true,
    });
    const parsed = JSON.parse(String(result.stdout || "{}")) as {
      format?: {
        duration?: string;
        format_name?: string;
        tags?: Record<string, string>;
      };
      streams?: Array<Record<string, unknown>>;
      chapters?: Array<Record<string, unknown>>;
    };
    const durationSeconds = safeNumber(parsed.format?.duration);
    const streams = (parsed.streams ?? []).flatMap((stream) => {
      const type =
        stream.codec_type === "video" ||
        stream.codec_type === "audio" ||
        stream.codec_type === "subtitle"
          ? stream.codec_type
          : null;
      if (!type) return [];
      const tags = (stream.tags ?? {}) as Record<string, string>;
      const disposition = (stream.disposition ?? {}) as Record<string, unknown>;
      const bitrate = safeNumber(stream.bit_rate);
      return [
        {
          id: `stream-${String(stream.index ?? 0)}`,
          index: safeNumber(stream.index) ?? 0,
          type,
          codec:
            typeof stream.codec_name === "string" ? stream.codec_name : null,
          profile: typeof stream.profile === "string" ? stream.profile : null,
          durationSeconds: safeNumber(stream.duration),
          bitrate,
          estimatedSizeBytes:
            bitrate && durationSeconds
              ? Math.round((bitrate * durationSeconds) / 8)
              : null,
          language: tags.language ?? null,
          title: tags.title ?? null,
          default: disposition.default === 1 || disposition.default === "1",
          forced: disposition.forced === 1 || disposition.forced === "1",
          width: safeNumber(stream.width),
          height: safeNumber(stream.height),
          channels: safeNumber(stream.channels),
          frameRate:
            typeof stream.avg_frame_rate === "string" &&
            stream.avg_frame_rate !== "0/0"
              ? stream.avg_frame_rate
              : typeof stream.r_frame_rate === "string"
                ? stream.r_frame_rate
                : null,
          channelLayout:
            typeof stream.channel_layout === "string"
              ? stream.channel_layout
              : null,
          sampleRate: safeNumber(stream.sample_rate),
          hdr:
            (typeof stream.color_transfer === "string" &&
              ["smpte2084", "arib-std-b67", "smpte428"].includes(
                stream.color_transfer,
              )) ||
            (typeof stream.color_primaries === "string" &&
              stream.color_primaries === "bt2020"),
        },
      ];
    });
    const videoStream = streams.find((stream) => stream.type === "video");
    if (videoStream && !videoStream.bitrate && stat.size && durationSeconds) {
      // Loose files rarely report a video bitrate; derive it from the overall
      // file size so the plan can still show a stream size estimate.
      const overallBitrate = Math.round((stat.size * 8) / durationSeconds);
      videoStream.bitrate = overallBitrate;
      videoStream.estimatedSizeBytes = stat.size;
    }
    const chapters = (parsed.chapters ?? []).map((chapter, index) => ({
      id: String(index),
      startSeconds: safeNumber(chapter.start_time) ?? 0,
      endSeconds: safeNumber(chapter.end_time) ?? 0,
      title: ((chapter.tags ?? {}) as Record<string, string>).title ?? null,
    }));
    return {
      ok: true,
      value: {
        sourcePath: absolute,
        sourceType: "video",
        sourceFingerprint: await fingerprint(absolute, stat),
        sizeBytes: stat.size,
        durationSeconds,
        formatName: parsed.format?.format_name ?? null,
        streams,
        chapters,
        externalSubtitles: await detectExternalSubtitles(absolute),
        diagnostics: {
          tool: "ffprobe",
          executable: ffprobe,
          args,
          durationMs: Date.now() - startedAt,
          exitCode: 0,
          stderr: String(result.stderr ?? ""),
        },
      },
    };
  } catch (error) {
    const err = error as {
      code?: number | string;
      stdout?: string;
      stderr?: string;
      message?: string;
    };
    return {
      ok: false,
      status: 422,
      body: {
        error: `FFprobe 探测失败：${err.message ?? String(error)}`,
        diagnostics: {
          tool: "ffprobe",
          executable: ffprobe,
          args,
          durationMs: Date.now() - startedAt,
          exitCode: err.code ?? null,
          stdout: err.stdout ?? "",
          stderr: err.stderr ?? "",
        },
      },
    };
  }
}

router.post("/smart-workflow/plan", async (req, res) => {
  const mediaInput = req.body?.media as
    | SmartWorkflowMediaInput
    | SmartWorkflowMediaInput[]
    | undefined;
  const mediaList = Array.isArray(mediaInput)
    ? mediaInput
    : mediaInput
      ? [mediaInput]
      : [];
  if (
    mediaList.length === 0 ||
    mediaList.some(
      (media) =>
        typeof media.sourcePath !== "string" ||
        !Array.isArray(media.streams) ||
        !Array.isArray(media.chapters),
    )
  ) {
    return res.status(400).json({ error: "媒体技术信息不完整" });
  }
  const identity = (req.body?.identity ?? {}) as Partial<SmartWorkflowIdentity>;
  const appConfig = await getConfig();
  const options = {
    identity,
    candidates: Array.isArray(req.body?.candidates) ? req.body.candidates : [],
    presetIds: Array.isArray(req.body?.presetIds)
      ? req.body.presetIds.filter(
          (id: unknown): id is string => typeof id === "string",
        )
      : [],
    aiUnavailable: req.body?.aiUnavailable !== false,
    metadataUnavailable: req.body?.metadataUnavailable !== false,
    encoder: appConfig.encoder,
    tuning: parseCustomTuning(appConfig.customTuning).logic,
    requireExplicitAction: req.body?.requireExplicitAction === true,
  };
  const first = buildSmartWorkflowPlan(mediaList[0], options);
  const additional = mediaList
    .slice(1)
    .map((media) => buildSmartWorkflowPlan(media, options).items[0]);
  const plan = { ...first, items: [...first.items, ...additional] };
  return res.json(plan);
});

router.post("/smart-workflow/validate", async (req, res) => {
  const plan = req.body?.plan as SmartWorkflowPlan | undefined;
  if (!plan) return res.status(400).json({ error: "处理计划不能为空" });
  const errors = validateSmartWorkflowPlan(plan, {
    availablePresetIds: Array.isArray(req.body?.availablePresetIds)
      ? req.body.availablePresetIds
      : undefined,
  });
  return res
    .status(errors.length > 0 ? 422 : 200)
    .json({ valid: errors.length === 0, errors });
});

router.post("/smart-workflow/save-plan", async (req, res) => {
  const plan = req.body?.plan as SmartWorkflowPlan | undefined;
  if (!plan) return res.status(400).json({ error: "处理计划不能为空" });
  const errors = validateSmartWorkflowPlan(plan);
  if (errors.length > 0)
    return res.status(422).json({ error: "处理计划校验失败", errors });
  // New plans always belong to the MediaSculpt profile.  VX-Agent is only a
  // migration/compatibility source and must never receive new writes.
  const planDirectory =
    process.env.MEDIASCULPT_WORKFLOW_DIR ??
    path.join(os.homedir(), ".MediaSculpt", "plans");
  await fs.mkdir(planDirectory, { recursive: true });
  const planPath = path.join(planDirectory, "processing-plan.json");
  await fs.writeFile(planPath, `${JSON.stringify(plan, null, 2)}\n`, "utf8");
  return res.json({ saved: true, path: planPath, planId: plan.planId });
});

export default router;
