import { describe, expect, it } from "vitest";
import {
  fileMagicMatches,
  isDirectDownloadUrl,
  rankDownloadSources,
  type SourceProbeResult,
} from "./tool-downloader";

function probe(
  url: string,
  ok: boolean,
  bytesPerSecond: number | null,
  latencyMs = 100,
): SourceProbeResult {
  return {
    url,
    ok,
    latencyMs,
    bytesPerSecond,
    status: ok ? 200 : 0,
    directFile: isDirectDownloadUrl(url),
  };
}

describe("tool download source ranking", () => {
  it("recognizes direct file URLs vs releases pages", () => {
    expect(
      isDirectDownloadUrl(
        "https://ghfast.top/https://github.com/x/y/releases/download/v1/tool.zip",
      ),
    ).toBe(true);
    expect(
      isDirectDownloadUrl(
        "https://github.com/x/y/releases/download/v1/tool-1.0.0.exe",
      ),
    ).toBe(true);
    expect(isDirectDownloadUrl("https://github.com/x/y/releases")).toBe(false);
    expect(isDirectDownloadUrl("https://pypi.org/project/whisper/")).toBe(
      false,
    );
  });

  it("ranks working direct-file sources by speed, then latency, and keeps failures last", () => {
    const sources = [
      "https://slow.example/file.zip",
      "https://fast.example/file.zip",
      "https://page.example/releases",
      "https://dead.example/file.zip",
    ];
    const probes: SourceProbeResult[] = [
      probe("https://slow.example/file.zip", true, 500_000, 80),
      probe("https://fast.example/file.zip", true, 2_000_000, 120),
      probe("https://page.example/releases", true, 8_000_000, 10),
      probe("https://dead.example/file.zip", false, null),
    ];
    const ranked = rankDownloadSources(sources, probes);
    expect(ranked).toEqual([
      "https://fast.example/file.zip",
      "https://slow.example/file.zip",
      "https://page.example/releases",
      "https://dead.example/file.zip",
    ]);
  });

  it("preserves original order for unprobed sources", () => {
    const sources = [
      "https://a.example/file.zip",
      "https://b.example/file.zip",
    ];
    expect(rankDownloadSources(sources, [])).toEqual(sources);
  });

  it("rejects HTTP-200 error pages by file magic", () => {
    const mz = new Uint8Array([0x4d, 0x5a, 0x90, 0x00, 0x03, 0x00]);
    const pk = new Uint8Array([0x50, 0x4b, 0x03, 0x04, 0x14, 0x00]);
    const html = new Uint8Array([
      0x3c, 0x21, 0x44, 0x4f, 0x43, 0x54, 0x59, 0x50, 0x45,
    ]); // "<!DOCTYPE"
    expect(fileMagicMatches("tool.exe", mz)).toBe(true);
    expect(fileMagicMatches("tool.exe", html)).toBe(false);
    expect(fileMagicMatches("tool.zip", pk)).toBe(true);
    expect(fileMagicMatches("tool.zip", html)).toBe(false);
    expect(fileMagicMatches("tool.dmg", html)).toBe(true); // unknown ext stays lenient
  });
});
