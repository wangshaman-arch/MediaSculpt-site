import type { Dispatch, SetStateAction } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { RotateCcw, Save } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  defaultBilingualDraft,
  type BilingualStyleDraft,
} from "./scan-bilingual-model";

type Translate = (key: string) => string;

export function ScanBilingualSettingsPanel({
  t,
  draft,
  setDraft,
  onSave,
  onClose,
}: {
  t: Translate;
  draft: BilingualStyleDraft;
  setDraft: Dispatch<SetStateAction<BilingualStyleDraft | null>>;
  onSave: () => void;
  onClose: () => void;
}) {
  return (
    <div
      className="mt-3 rounded-lg border border-primary/25 bg-primary/5 p-2.5"
      data-testid="bilingual-settings-panel"
    >
      <div className="flex flex-wrap items-end gap-x-3 gap-y-1.5">
        <div className="min-w-[215px] flex-1 space-y-0.5">
          <label className="block text-[11px] font-medium text-muted-foreground">
            {t("scan.bilingualLayoutOption")}
          </label>
          <div className="flex gap-0.5">
            <button
              type="button"
              onClick={() =>
                setDraft((current) =>
                  current ? { ...current, layout: "zh-top" } : current,
                )
              }
              className={cn(
                "h-8 rounded-md border px-2.5 text-xs transition-colors",
                draft.layout === "zh-top"
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border hover:border-primary/50",
              )}
            >
              {t("scan.bilingualZhTop")}
            </button>
            <button
              type="button"
              onClick={() =>
                setDraft((current) =>
                  current ? { ...current, layout: "foreign-top" } : current,
                )
              }
              className={cn(
                "h-8 rounded-md border px-2.5 text-xs transition-colors",
                draft.layout === "foreign-top"
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border hover:border-primary/50",
              )}
            >
              {t("scan.bilingualForeignTop")}
            </button>
          </div>
        </div>
        <div className="min-w-[96px] flex-1 space-y-0.5">
          <label className="block text-[11px] font-medium text-muted-foreground">
            {t("scan.bilingualOutlineWidth")}
          </label>
          <Input
            type="number"
            min={0}
            max={4}
            step={0.1}
            value={draft.outlineWidth}
            onChange={(event) =>
              setDraft((current) =>
                current
                  ? {
                      ...current,
                      outlineWidth: Number(event.currentTarget.value),
                    }
                  : current,
              )
            }
            className="h-8 w-full text-xs"
          />
        </div>
        <div className="min-w-[96px] flex-1 space-y-0.5">
          <label className="block text-[11px] font-medium text-muted-foreground">
            {t("scan.bilingualShadowWidth")}
          </label>
          <Input
            type="number"
            min={0}
            max={4}
            step={0.1}
            value={draft.shadowWidth}
            onChange={(event) =>
              setDraft((current) =>
                current
                  ? {
                      ...current,
                      shadowWidth: Number(event.currentTarget.value),
                    }
                  : current,
              )
            }
            className="h-8 w-full text-xs"
          />
        </div>
        <div className="min-w-[96px] flex-1 space-y-0.5">
          <label className="block text-[11px] font-medium text-muted-foreground">
            {t("scan.bilingualFontSizeTop")}
          </label>
          <Input
            type="number"
            min={6}
            max={48}
            step={0.5}
            value={draft.fontSizeTop}
            onChange={(event) =>
              setDraft((current) =>
                current
                  ? {
                      ...current,
                      fontSizeTop: Number(event.currentTarget.value),
                    }
                  : current,
              )
            }
            className="h-8 w-full text-xs"
          />
        </div>
        <div className="min-w-[96px] flex-1 space-y-0.5">
          <label className="block text-[11px] font-medium text-muted-foreground">
            {t("scan.bilingualFontSizeBottom")}
          </label>
          <Input
            type="number"
            min={4}
            max={36}
            step={0.5}
            value={draft.fontSizeBottom}
            onChange={(event) =>
              setDraft((current) =>
                current
                  ? {
                      ...current,
                      fontSizeBottom: Number(event.currentTarget.value),
                    }
                  : current,
              )
            }
            className="h-8 w-full text-xs"
          />
        </div>
        <div className="min-w-[180px] flex-1 space-y-0.5">
          <label className="block text-[11px] font-medium text-muted-foreground">
            {t("scan.bilingualOutlineColor")}
          </label>
          <div className="flex w-full items-center gap-1">
            <input
              type="color"
              value={draft.outlineColor}
              onChange={(event) =>
                setDraft((current) =>
                  current
                    ? { ...current, outlineColor: event.currentTarget.value }
                    : current,
                )
              }
              className="h-8 w-8 shrink-0 cursor-pointer rounded-md border border-border bg-transparent"
              aria-label={t("scan.bilingualOutlineColor")}
            />
            <Input
              value={draft.outlineColor}
              onChange={(event) =>
                setDraft((current) =>
                  current
                    ? { ...current, outlineColor: event.currentTarget.value }
                    : current,
                )
              }
              className="h-8 w-full min-w-0 font-mono text-xs"
            />
          </div>
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="h-8 w-8 shrink-0 px-0"
          title={t("scan.bilingualRestoreDefaults")}
          onClick={() => setDraft(defaultBilingualDraft())}
        >
          <RotateCcw className="h-3.5 w-3.5" />
        </Button>
        <Button
          type="button"
          size="sm"
          className="h-8 shrink-0"
          onClick={onSave}
        >
          <Save className="mr-1 h-3.5 w-3.5" />
          {t("scan.bilingualSettingsSave")}
        </Button>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="h-8 shrink-0"
          onClick={onClose}
        >
          {t("common.cancel")}
        </Button>
      </div>
    </div>
  );
}
