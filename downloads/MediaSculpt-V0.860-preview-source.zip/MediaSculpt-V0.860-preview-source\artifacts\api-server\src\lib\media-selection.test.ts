import { describe, expect, it } from "vitest";
import { buildSelectionPlan, parseSelectionPlan } from "./media-selection";

describe("media selection plan", () => {
  const analysis = {
    sourcePath: "/tmp/a.mkv",
    mediaType: "video" as const,
    durationSeconds: 10,
    streams: [
      { index: 0, codecType: "video" as const, codecName: "h264" },
      { index: 1, codecType: "audio" as const, codecName: "aac" },
    ],
    chapters: [],
  };

  it("builds a versioned plan", () => {
    expect(buildSelectionPlan(analysis, [0, 1])).toEqual({
      version: 1,
      video: [0],
      audio: [1],
      subtitle: [],
      chapters: [],
    });
  });

  it("rejects malformed plans", () => {
    expect(parseSelectionPlan('{"version":2}')).toBeNull();
    expect(
      parseSelectionPlan(
        '{"version":1,"video":[],"audio":[],"subtitle":[],"chapters":[]}',
      ),
    ).toEqual({ version: 1, video: [], audio: [], subtitle: [], chapters: [] });
  });
});
