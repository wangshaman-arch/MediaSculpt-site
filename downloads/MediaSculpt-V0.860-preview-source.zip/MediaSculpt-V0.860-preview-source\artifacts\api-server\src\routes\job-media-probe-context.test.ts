import { describe, expect, it } from "vitest";
import {
  probeJobMedia,
  resolveProbedDuration,
  summarizeMediaProbeStreams,
} from "./job-media-probe-context";

describe("job media probe context", () => {
  it("summarizes video, audio, subtitle and primary audio information", () => {
    expect(
      summarizeMediaProbeStreams([
        { codecType: "video", codecName: "mpeg2video", height: 576 },
        {
          codecType: "audio",
          codecName: "ac3",
          channels: 2,
          bitRate: 192000,
          tags: { language: "en" },
        },
        { codecType: "subtitle", codecName: "dvd_subtitle" },
      ]),
    ).toEqual({
      hasEmbeddedSubs: true,
      primaryAudioCodec: "ac3",
      sourceHasAudio: true,
      probeVideoHeight: 576,
      probeHasVideo: true,
    });
  });

  it("uses the selected disc title duration instead of another probe title", () => {
    expect(
      resolveProbedDuration({
        mediaType: "dvd",
        hasTaskSnapshot: true,
        probeDuration: 3600,
        selectedTitleDurationSeconds: 120,
      }),
    ).toBe(120);
  });

  it("uses the media probe for ordinary video jobs", () => {
    expect(
      resolveProbedDuration({
        mediaType: "video",
        hasTaskSnapshot: false,
        probeDuration: 3600,
        selectedTitleDurationSeconds: null,
      }),
    ).toBe(3600);
  });

  it("probes DVD streams from the frozen selected title", async () => {
    let probedTitle: number | null = null;
    const result = await probeJobMedia({
      jobId: 1,
      job: { mediaType: "dvd" } as never,
      mediaInputPath: "D:/disc/VIDEO_TS",
      taskSnapshotPresent: true,
      selectedDvdTitleNumber: 3,
      selectedTitleDurationSeconds: null,
      probeDvdTitleByNumber: async (_sourcePath, titleNumber) => {
        probedTitle = titleNumber;
        return {
          streams: [
            { codecType: "video", codecName: "mpeg2video", height: 480 },
            { codecType: "audio", codecName: "ac3", channels: 2 },
            { codecType: "subtitle", codecName: "dvd_subtitle" },
          ],
          sourcePath: "D:/disc/VIDEO_TS",
          formatName: "dvdvideo",
          duration: 5000,
          bitRate: null,
          chapters: [],
        };
      },
    });

    expect(probedTitle).toBe(3);
    expect(result.hasEmbeddedSubs).toBe(true);
    expect(result.sourceHasAudio).toBe(true);
  });
});
