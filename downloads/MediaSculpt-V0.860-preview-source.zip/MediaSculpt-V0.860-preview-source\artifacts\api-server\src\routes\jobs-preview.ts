import { Router } from "express";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { db, jobsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { servePreviewSegment } from "../lib/preview-segments";
import {
  isPreviewVideoCandidate,
  previewService,
} from "../media/preview-service";
import {
  resolveDvdTitleForIfo,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";
import { discPreviewRouter } from "./jobs-preview-disc";
import { mediaPreviewRouter } from "./jobs-preview-media";
import { subtitlePreviewRouter } from "./jobs-preview-subtitles";
import { streamContinuousPreview } from "./jobs-preview-stream";

const router = Router();

router.use(discPreviewRouter);
router.get("/jobs/:id/preview", async (req, res) => {
  const id = Number(req.params.id);
  const filePath = await resolveJobPreviewFilePath(id);
  if (!filePath) return res.status(404).json({ error: "没有可预览的视频文件" });
  try {
    const stat = await fs.stat(filePath);
    const range = req.headers.range;
    const extension = path.extname(filePath).toLowerCase();
    const contentType =
      extension === ".webm"
        ? "video/webm"
        : extension === ".mkv"
          ? "video/x-matroska"
          : extension === ".ts" || extension === ".m2ts"
            ? "video/mp2t"
            : extension === ".mov"
              ? "video/quicktime"
              : "video/mp4";
    if (!range) {
      res.setHeader("Content-Length", stat.size);
      res.setHeader("Content-Type", contentType);
      return fsSync.createReadStream(filePath).pipe(res);
    }
    const match = range.match(/bytes=(\d*)-(\d*)/);
    if (!match) return res.status(416).end();
    const start = match[1] ? Number(match[1]) : 0;
    const end = match[2]
      ? Math.min(Number(match[2]), stat.size - 1)
      : Math.min(start + 1024 * 1024 - 1, stat.size - 1);
    if (start >= stat.size || end < start) return res.status(416).end();
    res.status(206).set({
      "Content-Range": `bytes ${start}-${end}/${stat.size}`,
      "Accept-Ranges": "bytes",
      "Content-Length": String(end - start + 1),
      "Content-Type": contentType,
    });
    return fsSync.createReadStream(filePath, { start, end }).pipe(res);
  } catch {
    return res.status(404).json({ error: "视频文件不存在或无法读取" });
  }
});

async function resolveJobPreviewFilePath(id: number): Promise<string | null> {
  const [job] = await db
    .select({
      filePath: jobsTable.filePath,
      mainTrackPath: jobsTable.mainTrackPath,
      outputPath: jobsTable.outputPath,
      mediaType: jobsTable.mediaType,
    })
    .from(jobsTable)
    .where(eq(jobsTable.id, id))
    .limit(1);
  // 按优先级逐个尝试：输出文件 → 光盘主标题轨 → 源文件。
  // 某个候选不存在/读不到（文件被移动、改名、云盘未下载）时跳过继续试下一个，
  // 避免“输出路径失效就整条预览 404（浏览器报错码 4）”。
  const candidates = [job?.outputPath, job?.mainTrackPath, job?.filePath]
    .filter((candidate): candidate is string => Boolean(candidate))
    // 字幕任务的 outputPath 是 .ass/.srt 字幕文件，不是视频，必须跳过，
    // 否则 ffmpeg 无视频流 → 空响应 → 浏览器报错误码 4。
    .filter(isPreviewVideoCandidate);
  for (const candidate of candidates) {
    let filePath = candidate;
    try {
      const stat = await fs.stat(filePath);
      if (stat.isDirectory()) {
        filePath = await resolveDiscMainTrack(
          filePath,
          job?.mediaType ?? "video",
        );
      }
    } catch {
      continue;
    }
    if (/\.ifo$/i.test(filePath)) {
      const title = await resolveDvdTitleForIfo(filePath).catch(() => null);
      filePath = title?.vobFiles[0] ?? filePath;
    }
    try {
      const stat = await fs.stat(filePath);
      if (stat.isFile()) return filePath;
    } catch {
      // 当前候选解析出的文件不可读，继续尝试下一个候选。
    }
  }
  return null;
}

router.get("/jobs/:id/preview/meta", async (req, res) => {
  const id = Number(req.params.id);
  const filePath = await resolveJobPreviewFilePath(id);
  if (!filePath) return res.status(404).json({ error: "没有可预览的视频文件" });
  const metadata = await previewService.probeMetadata(filePath);
  return res.json(metadata);
});

router.get("/jobs/:id/preview.mp4", async (req, res) => {
  const id = Number(req.params.id);
  const filePath = await resolveJobPreviewFilePath(id);
  if (!filePath) return res.status(404).json({ error: "没有可预览的视频文件" });
  const seekRaw = typeof req.query.seek === "string" ? req.query.seek : "";
  const seekSeconds = Number(seekRaw);
  const hasSeek =
    seekRaw !== "" && Number.isFinite(seekSeconds) && seekSeconds > 0;
  const subRaw = typeof req.query.sub === "string" ? req.query.sub : "";
  const subIndex = Number(subRaw);
  const hasSub = subRaw !== "" && Number.isInteger(subIndex) && subIndex >= 0;
  let subTypeIndex: number | null = null;
  if (hasSub) {
    const containerIndices =
      await previewService.subtitleContainerIndices(filePath);
    const found = containerIndices.indexOf(subIndex);
    subTypeIndex = found >= 0 ? found : null;
  }
  // 默认使用连续流；旧的分段模式仅在显式 segment=1 时启用。
  if (req.query.segment === "1") {
    return servePreviewSegment(
      res,
      filePath,
      subTypeIndex,
      hasSeek ? seekSeconds : 0,
    );
  }
  return streamContinuousPreview(
    res,
    filePath,
    subTypeIndex,
    hasSeek ? seekSeconds : 0,
  );
});

router.get("/jobs/:id/preview/raw", async (req, res) => {
  const id = Number(req.params.id);
  const filePath = await resolveJobPreviewFilePath(id);
  if (!filePath) return res.status(404).json({ error: "没有可预览的视频文件" });
  try {
    const stat = await fs.stat(filePath);
    const range = req.headers.range;
    const extension = path.extname(filePath).toLowerCase();
    const contentType =
      extension === ".webm"
        ? "video/webm"
        : extension === ".mkv"
          ? "video/x-matroska"
          : extension === ".ts" || extension === ".m2ts"
            ? "video/mp2t"
            : extension === ".mov"
              ? "video/quicktime"
              : "video/mp4";
    if (!range) {
      res.setHeader("Content-Length", stat.size);
      res.setHeader("Content-Type", contentType);
      return fsSync.createReadStream(filePath).pipe(res);
    }
    const match = range.match(/bytes=(\d*)-(\d*)/);
    if (!match) return res.status(416).end();
    const start = match[1] ? Number(match[1]) : 0;
    const end = match[2]
      ? Math.min(Number(match[2]), stat.size - 1)
      : Math.min(start + 1024 * 1024 - 1, stat.size - 1);
    if (start >= stat.size || end < start) return res.status(416).end();
    res.status(206).set({
      "Content-Range": `bytes ${start}-${end}/${stat.size}`,
      "Accept-Ranges": "bytes",
      "Content-Length": String(end - start + 1),
      "Content-Type": contentType,
    });
    return fsSync.createReadStream(filePath, { start, end }).pipe(res);
  } catch {
    return res.status(404).json({ error: "视频文件不存在或无法读取" });
  }
});
router.use(mediaPreviewRouter);
router.use(subtitlePreviewRouter);

export const previewRouter = router;
