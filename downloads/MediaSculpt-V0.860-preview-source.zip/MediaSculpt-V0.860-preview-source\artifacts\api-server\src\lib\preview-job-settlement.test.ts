import { describe, expect, it, vi } from "vitest";
import { createPreviewJobSettlement } from "./preview-job-settlement";

describe("preview job settlement", () => {
  it("charges one valid non-preview task", async () => {
    const chargeTaskOnce = vi.fn(async () => ({
      charged: true,
      successfulTaskCount: 1,
    }));
    const settle = createPreviewJobSettlement({ chargeTaskOnce });

    await expect(
      settle({
        jobId: 7,
        taskKind: "compress",
        outputValid: true,
        isPreviewOnly: false,
        cancelled: false,
      }),
    ).resolves.toEqual({ charged: true, successfulTaskCount: 1 });
    expect(chargeTaskOnce).toHaveBeenCalledWith(
      expect.objectContaining({ jobId: 7, taskKind: "compress" }),
    );
  });

  it("does not charge failures, cancellations or preview-only tasks", async () => {
    const chargeTaskOnce = vi.fn(async () => ({
      charged: true,
      successfulTaskCount: 1,
    }));
    const settle = createPreviewJobSettlement({ chargeTaskOnce });

    await settle({
      jobId: 8,
      taskKind: "compress",
      outputValid: false,
      isPreviewOnly: false,
      cancelled: false,
    });
    await settle({
      jobId: 9,
      taskKind: "compress",
      outputValid: true,
      isPreviewOnly: false,
      cancelled: true,
    });
    await settle({
      jobId: 10,
      taskKind: "chapter-preview",
      outputValid: true,
      isPreviewOnly: true,
      cancelled: false,
    });

    expect(chargeTaskOnce).not.toHaveBeenCalled();
  });
});
