import fs from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { resolveToolPath } from "./tool-runtime";
import {
  fetchLike,
  resolvePosterProxyUrl,
  type FetchLike,
} from "./http-client";

const execFileAsync = promisify(execFile);

/**
 * Spelled-out numerals map onto their digits so `Ocean's 11` and
 * `Ocean's Eleven` compare as the same title. Deliberately capped at a small
 * range: numerals are sequence markers far more often than arbitrary title
 * words, and a wider table would invent matches that do not exist.
 */
const SPOKEN_NUMERALS: Record<string, string> = {
  "1": "one",
  "2": "two",
  "3": "three",
  "4": "four",
  "5": "five",
  "6": "six",
  "7": "seven",
  "8": "eight",
  "9": "nine",
  "10": "ten",
  "11": "eleven",
  "12": "twelve",
  "13": "thirteen",
  "14": "fourteen",
  "15": "fifteen",
  "16": "sixteen",
  "17": "seventeen",
  "18": "eighteen",
  "19": "nineteen",
  "20": "twenty",
  "21": "twentyone",
  "22": "twentytwo",
  "23": "twentythree",
  "24": "twentyfour",
  "25": "twentyfive",
  "30": "thirty",
  "40": "forty",
  "50": "fifty",
  "100": "hundred",
};

/** IMDb poster standard: 1024x1532 JPEG (2:3). */
export const IMDB_POSTER = { width: 1024, height: 1532 };

export type PosterIdentity = {
  imdbId?: string | null;
  title?: string | null;
  titleEn?: string | null;
  year?: string | number | null;
};

export type PosterSource = "imdb" | "tmdb" | "omdb" | "douban";

/** 海报候选的来源与匹配方式，供自动保存和人工挑选使用。 */
export type PosterCandidate = {
  url: string;
  source: PosterSource;
  confidence: "high" | "medium";
  matchedBy: "imdb" | "tmdb" | "title-year";
};

export function isTrustedPosterSource(source?: string | null): boolean {
  return (
    source === "imdb" ||
    source === "tmdb" ||
    source === "omdb" ||
    source === "douban"
  );
}

/** Search results must carry enough identity data before their image is saved. */
export function posterSearchIdentityMatches(params: {
  actualTitle?: string | null;
  actualYear?: string | number | null;
  expectedTitle?: string | null;
  expectedTitleEn?: string | null;
  expectedYear?: string | number | null;
}): boolean {
  const normalize = (value?: string | null) =>
    (value ?? "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/['’`´]/g, "")
      .toLowerCase()
      .replace(/\b\d{1,3}\b/g, (match) => SPOKEN_NUMERALS[match] ?? match)
      .replace(/[^\p{L}\p{N}\u3400-\u9fff]+/gu, "")
      .trim();
  const actualTitle = normalize(params.actualTitle);
  const expectedTitles = [params.expectedTitleEn, params.expectedTitle]
    .map((value) => normalize(value))
    .filter(Boolean);
  if (
    !actualTitle ||
    expectedTitles.length === 0 ||
    !expectedTitles.includes(actualTitle)
  )
    return false;

  const expectedYear =
    params.expectedYear == null
      ? NaN
      : Number(String(params.expectedYear).slice(0, 4));
  const actualYear =
    params.actualYear == null
      ? NaN
      : Number(String(params.actualYear).slice(0, 4));
  if (Number.isFinite(expectedYear)) {
    if (!Number.isFinite(actualYear) || Math.abs(expectedYear - actualYear) > 1)
      return false;
  }
  return true;
}

/** Ensure a saved poster belongs to the task currently requesting it. */
export function posterIdentityMatches(
  actual: PosterIdentity,
  expected: PosterIdentity,
): boolean {
  const expectedImdb = expected.imdbId?.trim().toLowerCase();
  const actualImdb = actual.imdbId?.trim().toLowerCase();
  // A recorded id that contradicts the expected one is fatal.
  if (expectedImdb && actualImdb && actualImdb !== expectedImdb) return false;
  if (!expectedImdb && actualImdb && expected.titleEn && !actual.titleEn)
    return false;

  const normalize = (value?: string | null) =>
    (value ?? "")
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\u3400-\u9fff]+/gu, "")
      .trim();
  const expectedTitle = normalize(expected.titleEn || expected.title);
  const actualTitle = normalize(actual.titleEn || actual.title);
  if (expectedTitle && actualTitle && expectedTitle !== actualTitle)
    return false;

  const expectedYear =
    expected.year == null ? undefined : Number(expected.year);
  const actualYear = actual.year == null ? undefined : Number(actual.year);
  if (
    Number.isFinite(expectedYear) &&
    Number.isFinite(actualYear) &&
    Math.abs(expectedYear! - actualYear!) > 1
  )
    return false;

  // A sidecar saved before the lookup resolved the id carries no imdbId at all.
  // That is not a contradiction, and treating it as one hid an otherwise
  // matching poster behind a 404: require the recorded title to agree, or the
  // year when the sidecar records no title at all.
  if (expectedImdb && !actualImdb) {
    if (actualTitle)
      return Boolean(expectedTitle && expectedTitle === actualTitle);
    return (
      Number.isFinite(expectedYear) &&
      Number.isFinite(actualYear) &&
      Math.abs(expectedYear! - actualYear!) <= 1
    );
  }
  if (expectedTitle && !actualTitle && !expectedImdb) return false;
  if (
    Number.isFinite(expectedYear) &&
    !Number.isFinite(actualYear) &&
    !expectedImdb
  )
    return false;
  return true;
}

/** Bind a remote candidate to its verified identity so the UI can safely reuse it. */
export function bindPosterIdentityToUrl(
  url: string,
  identity: PosterIdentity,
): string {
  if (!/^https?:\/\//i.test(url)) return url;
  try {
    const parsed = new URL(url);
    if (identity.imdbId?.trim())
      parsed.searchParams.set("imdbId", identity.imdbId.trim());
    if (identity.titleEn?.trim())
      parsed.searchParams.set("titleEn", identity.titleEn.trim());
    else if (identity.title?.trim())
      parsed.searchParams.set("title", identity.title.trim());
    if (identity.year != null && String(identity.year).trim())
      parsed.searchParams.set("year", String(identity.year).trim());
    return parsed.toString();
  } catch {
    return url;
  }
}

/** 资料与海报子目录（readme/poster/folder 统一存放，首字母大写）。 */
export const MEDIA_INFO_DIR = "MediaInfo";

/** 同一影片的成功海报 URL 缓存：文件放在系统临时目录，跨分析复用，显著提升稳定性。 */
const POSTER_CACHE_FILE = path.join(
  os.tmpdir(),
  "MediaSculpt",
  "poster-url-cache.json",
);
export const POSTER_META_FILE = "poster.meta.json";

async function loadPosterCache(): Promise<Record<string, string>> {
  try {
    const raw = await fs.readFile(POSTER_CACHE_FILE, "utf8");
    const parsed = JSON.parse(raw) as Record<string, string>;
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

async function savePosterCache(cache: Record<string, string>): Promise<void> {
  try {
    await fs.mkdir(path.dirname(POSTER_CACHE_FILE), { recursive: true });
    await fs.writeFile(POSTER_CACHE_FILE, JSON.stringify(cache), "utf8");
  } catch {
    // 缓存写入失败不影响海报流程
  }
}

export async function fetchJson<T>(
  url: string,
  proxyUrl: string | null,
  timeoutMs: number,
): Promise<T | null> {
  const response = await fetchLike(url, proxyUrl, timeoutMs);
  if (!response?.ok || !response.body) return null;
  return (await new Response(response.body as ReadableStream)
    .json()
    .catch(() => null)) as T | null;
}

/** 稳定缓存键：英文名/中文名 + 年份归一化，命中后优先尝试。 */
export function posterCacheKey(
  title?: string | null,
  titleEn?: string | null,
  year?: string | number | null,
  imdbId?: string | null,
): string {
  if (imdbId && /^tt\d{7,8}$/i.test(imdbId.trim()))
    return `id:${imdbId.trim().toLowerCase()}`;
  const name = (titleEn || title || "")
    .toLowerCase()
    .replace(/[^a-z0-9\u3400-\u9fff]+/g, "");
  const y = year ? String(year) : "";
  return `${name}:${y}`;
}

/**
 * Amazon's image CDN serves the same artwork on several equivalent hosts, and
 * some networks can only reach one of them: m.media-amazon.com times out here
 * while images-na.ssl-images-amazon.com, ia.media-imdb.com and
 * images.amazon.com answer the identical bytes for the identical path. IMDb
 * suggestion only ever hands back the m.media-amazon.com form, so without this
 * expansion a title that has a perfectly good poster ends up with none.
 *
 * Only the host changes; the path and the identity parameters (imdbId,
 * titleEn, year) are preserved, so the downloaded file is the same asset.
 */
/** A blocked image host answers by timing out, so keep the per-URL budget
 *  short enough that the next equivalent host is still tried quickly. */
const POSTER_DOWNLOAD_TIMEOUT_MS = 20_000;

const AMAZON_IMAGE_HOSTS = [
  "m.media-amazon.com",
  "images-na.ssl-images-amazon.com",
  "ia.media-imdb.com",
  "images.amazon.com",
];

export function expandPosterHostVariants(url: string): string[] {
  try {
    const parsed = new URL(url);
    if (!AMAZON_IMAGE_HOSTS.includes(parsed.host.toLowerCase())) return [url];
    return AMAZON_IMAGE_HOSTS.map((host) => {
      const next = new URL(parsed.toString());
      next.host = host;
      return next.toString();
    });
  } catch {
    return [url];
  }
}

async function downloadTo(
  url: string,
  target: string,
  proxyUrl: string | null,
  timeoutMs = 60_000,
): Promise<boolean> {
  const response = await fetchLike(url, proxyUrl, timeoutMs);
  if (!response || !response.ok || !response.body) return false;
  const temp = `${target}.download`;
  const handle = await fs.open(temp, "w");
  try {
    for await (const chunk of response.body) await handle.write(chunk);
  } finally {
    await handle.close();
  }
  await fs.rename(temp, target);
  return true;
}

/** Scale+crop any poster image to the IMDb-standard 1024x1532 JPEG. */
async function adaptPoster(
  input: string,
  outputJpg: string,
  log?: (message: string) => void | Promise<void>,
): Promise<boolean> {
  const ffmpeg = (await resolveToolPath("ffmpeg")) ?? "ffmpeg";
  try {
    await execFileAsync(
      ffmpeg,
      [
        "-y",
        "-v",
        "error",
        "-i",
        input,
        "-vf",
        `scale=${IMDB_POSTER.width}:${IMDB_POSTER.height}:force_original_aspect_ratio=increase,crop=${IMDB_POSTER.width}:${IMDB_POSTER.height}`,
        "-frames:v",
        "1",
        "-q:v",
        "2",
        outputJpg,
      ],
      { timeout: 120_000 },
    );
    return true;
  } catch (error) {
    await log?.(
      `poster: 尺寸适配失败 ${error instanceof Error ? error.message : String(error)}`,
    );
    return false;
  }
}

/** folder.jpg：老播放器兼容缩略图（同源同图，缩小到 400px 宽，避免与 poster.jpg 字节重复）。 */
async function adaptFolderThumb(
  input: string,
  outputJpg: string,
  log?: (message: string) => void | Promise<void>,
): Promise<boolean> {
  const ffmpeg = (await resolveToolPath("ffmpeg")) ?? "ffmpeg";
  try {
    await execFileAsync(
      ffmpeg,
      [
        "-y",
        "-v",
        "error",
        "-i",
        input,
        "-vf",
        "scale=400:-2",
        "-frames:v",
        "1",
        "-q:v",
        "5",
        outputJpg,
      ],
      { timeout: 120_000 },
    );
    return true;
  } catch (error) {
    await log?.(
      `poster: folder.jpg 缩略图生成失败 ${error instanceof Error ? error.message : String(error)}`,
    );
    return false;
  }
}

/** 豆瓣 subject_suggest：免 key，仅接受标题/年份均匹配的真实海报图。 */
export async function doubanPosterUrl(
  title: string,
  identity: Pick<PosterIdentity, "title" | "titleEn" | "year">,
  proxyUrl: string | null,
): Promise<string | null> {
  if (!title) return null;
  try {
    const data = await fetchJson<
      Array<{
        img?: string;
        title?: string;
        sub_title?: string;
        year?: string | number;
      }>
    >(
      `https://movie.douban.com/j/subject_suggest?q=${encodeURIComponent(title)}`,
      proxyUrl,
      15_000,
    );
    if (!data) return null;
    // 豆瓣的 item.title 常为中文名，sub_title 才是原名/英文名；两者都参与身份匹配，
    // 否则英文片名会因中文标题不一致而被拒绝（"中文可达源却拿不到海报"的主因之一）。
    return (
      data.find((item) => {
        if (!item.img || !/^https?:\/\//i.test(item.img)) return false;
        const candidates = [item.title, item.sub_title].filter(
          (value): value is string =>
            typeof value === "string" && value.length > 0,
        );
        return candidates.some((actualTitle) =>
          posterSearchIdentityMatches({
            actualTitle,
            actualYear: item.year,
            expectedTitle: identity.title,
            expectedTitleEn: identity.titleEn,
            expectedYear: identity.year,
          }),
        );
      })?.img ?? null
    );
  } catch {
    return null;
  }
}

/**
 * 多源并行查找可核验的真实海报 URL。只有返回了匹配标题/年份或明确 ID 的
 * 来源才进入自动保存链路；维基缩略图、iTunes 搜索等相关图片不再作为海报。
 */
export function orderPosterCandidates(urls: string[]): string[] {
  const seen = new Set<string>();
  const unique = urls.filter((url) => {
    if (!url || !/^https?:\/\//i.test(url) || seen.has(url)) return false;
    seen.add(url);
    return true;
  });
  // IMDb's suggestion feed commonly points at Amazon's image CDN. Keep it as
  // a real fallback, but prefer identity-confirmed domestic/TMDb sources first
  // because they are more consistently reachable in restricted networks.
  return unique.sort((a, b) => {
    const amazon = (url: string) =>
      /(?:m\.media-amazon\.com|images-na\.ssl-images-amazon\.com|ia\.media-imdb\.com)/i.test(
        url,
      );
    return Number(amazon(a)) - Number(amazon(b));
  });
}

/** Keep URLs tied to the verified metadata candidate ahead of generic search results. */
export function prioritizePosterCandidates(
  urls: string[],
  preferred: string[] = [],
): string[] {
  const normalizedPreferred = orderPosterCandidates(preferred);
  const preferredSet = new Set(normalizedPreferred);
  const remainder = orderPosterCandidates(
    urls.filter((url) => !preferredSet.has(url)),
  );
  return [...normalizedPreferred, ...remainder];
}

import { findPosterCandidatesByOnline } from "./poster-online";
export { findPosterCandidatesByOnline } from "./poster-online";

export async function findPosterUrlsByOnline(
  params: Parameters<typeof findPosterCandidatesByOnline>[0],
): Promise<string[]> {
  return orderPosterCandidates(
    (await findPosterCandidatesByOnline(params)).map(
      (candidate) => candidate.url,
    ),
  );
}

/** Backwards-compatible single-URL helper for callers that only need a preview. */
export async function findPosterUrlByOnline(
  params: Parameters<typeof findPosterUrlsByOnline>[0],
): Promise<string | null> {
  return (await findPosterUrlsByOnline(params))[0] ?? null;
}

/**
 * 下载真实海报到媒体目录 poster.jpg（+folder.jpg 兼容老播放器），适配 IMDb 标准。
 * 来源尽力查找（真实图片）：已确认 URL → TMDb/OMDb（key）→ 豆瓣精确匹配（免 key）→
 * 可选的 LLM 公开海报 URL（仅在明确调用该兜底时）。无法核验时不落盘，避免相关图片冒充海报。
 */
export async function ensureLocalPoster(params: {
  title?: string | null;
  titleEn?: string | null;
  posterUrl?: string | null;
  /** 多个候选海报 URL（分析链路 LLM 可能返回多个，逐个尝试下载） */
  posterUrls?: string[] | null;
  tmdbId?: number | null;
  tmdbApiKey?: string | null;
  omdbApiKey?: string | null;
  /** Verified IMDb identity, used to isolate poster cache and keyed lookups. */
  imdbId?: string | null;
  /** Disable fuzzy title searches when metadata identity is not verified. */
  allowTitleSearch?: boolean;
  /** TMDb 海报图片镜像前缀（国内网络可达时填写） */
  posterMirrorUrl?: string | null;
  /** 海报下载代理地址（http://127.0.0.1:10809 等） */
  posterProxyUrl?: string | null;
  year?: string | number | null;
  targetDirectory: string;
  onLog?: (message: string) => void | Promise<void>;
  /** 最后兜底：让 LLM 返回一个公开可访问的真实海报 URL（不生成图片）。 */
  findPosterUrlByLlm?: (info: {
    title?: string | null;
    titleEn?: string | null;
    year?: string | number | null;
  }) => Promise<string | null>;
}): Promise<string | null> {
  const { onLog: log } = params;
  const posterProxyUrl = await resolvePosterProxyUrl(
    params.posterProxyUrl ?? null,
  );
  const posterJpg = path.join(params.targetDirectory, "poster.jpg");
  const folderJpg = path.join(params.targetDirectory, "folder.jpg");
  // 历史遗留：旧版本 folder.jpg 与 poster.jpg 字节完全相同，检测到后自动转成缩略图
  try {
    const [posterStat, folderStat] = await Promise.all([
      fs.stat(posterJpg).catch(() => null),
      fs.stat(folderJpg).catch(() => null),
    ]);
    if (posterStat && folderStat && posterStat.size === folderStat.size) {
      const [posterBuf, folderBuf] = await Promise.all([
        fs.readFile(posterJpg),
        fs.readFile(folderJpg),
      ]);
      if (posterBuf.equals(folderBuf)) {
        await adaptFolderThumb(posterJpg, folderJpg, log);
        await log?.(
          "poster: 检测到 folder.jpg 与 poster.jpg 重复，已转为 400px 缩略图",
        );
      }
    }
  } catch {
    // 转换失败不阻塞海报流程
  }
  const exists = await fs
    .access(posterJpg)
    .then(() => true)
    .catch(() => false);
  if (exists) {
    // 有明确的海报候选（在线源/LLM URL）时，允许覆盖更新，避免旧信息卡长期滞留；
    // 没有任何候选时直接复用现有文件。
    const hasCandidate = Boolean(
      params.posterUrl ||
      (params.posterUrls && params.posterUrls.length > 0) ||
      params.tmdbId ||
      params.title ||
      params.titleEn,
    );
    if (!hasCandidate) {
      await log?.("poster: poster.jpg 已存在且无新候选，跳过");
      return posterJpg;
    }
    await log?.("poster: poster.jpg 已存在但有新候选，尝试更新真实海报…");
  }
  await fs.mkdir(params.targetDirectory, { recursive: true });

  const candidates: string[] = [];
  const seen = new Set<string>();
  const push = (url: string | null | undefined) => {
    if (!url || !/^https?:\/\//i.test(url)) return;
    // Queue the equivalent hosts of one asset together: the blocked host fails
    // and the next variant of the same poster succeeds.
    for (const variant of expandPosterHostVariants(url)) {
      if (!seen.has(variant)) {
        seen.add(variant);
        candidates.push(variant);
      }
    }
  };

  // 1) 已确认的海报 URL（分析/LLM 返回）暂存，最后再尝试（图床可达性最不确定）
  const confirmedUrl = params.posterUrl;
  for (const url of params.posterUrls ?? []) push(url);
  // 2) 多源并行查找：有 key（TMDb/OMDb）+ 免 key（标题/年份精确匹配的豆瓣）。
  //    即使已有 LLM 给的 URL 也照常查找，命中后排在 LLM URL 之前优先尝试，
  //    避免 LLM 给的图床（如 Amazon）在当前网络不可达时直接失败。
  const onlineUrls =
    params.allowTitleSearch === false
      ? []
      : await findPosterUrlsByOnline({
          title: params.title,
          titleEn: params.titleEn,
          year: params.year,
          tmdbId: params.tmdbId,
          imdbId: params.imdbId,
          tmdbApiKey: params.tmdbApiKey,
          omdbApiKey: params.omdbApiKey,
          posterMirrorUrl: params.posterMirrorUrl,
          proxyUrl: posterProxyUrl,
        });
  // Add every online candidate. A successful JSON response can still point to
  // an image host that is blocked; retaining all candidates lets the download
  // loop move on to the next source instead of failing the whole poster job.
  for (let index = onlineUrls.length - 1; index >= 0; index -= 1) {
    const onlineUrl = onlineUrls[index];
    if (!seen.has(onlineUrl)) {
      seen.add(onlineUrl);
      candidates.unshift(onlineUrl);
    }
  }
  // 3) 有 key 的按 ID 精确来源（并行，优先级高）
  const keyed = await Promise.all([
    (async (): Promise<string | null> => {
      if (!params.tmdbId || !params.tmdbApiKey) return null;
      try {
        const data = await fetchJson<{ poster_path?: string | null }>(
          `https://api.themoviedb.org/3/movie/${params.tmdbId}?api_key=${encodeURIComponent(params.tmdbApiKey)}&language=en-US`,
          posterProxyUrl,
          15_000,
        );
        if (!data?.poster_path) return null;
        const base = params.posterMirrorUrl?.trim()
          ? params.posterMirrorUrl.replace(/\/+$/, "")
          : "https://image.tmdb.org/t/p/original";
        return `${base}${data.poster_path}`;
      } catch {
        return null;
      }
    })(),
    (async (): Promise<string | null> => {
      const title = params.titleEn || params.title;
      if (!params.omdbApiKey || (!title && !params.imdbId)) return null;
      try {
        const query =
          params.imdbId && /^tt\d{7,8}$/i.test(params.imdbId.trim())
            ? `i=${encodeURIComponent(params.imdbId.trim())}`
            : `t=${encodeURIComponent(title ?? "")}`;
        const data = await fetchJson<{ Poster?: string }>(
          `https://www.omdbapi.com/?apikey=${encodeURIComponent(params.omdbApiKey)}&${query}`,
          posterProxyUrl,
          15_000,
        );
        return data?.Poster && data.Poster !== "N/A" ? data.Poster : null;
      } catch {
        return null;
      }
    })(),
  ]);
  keyed.forEach(push);
  push(confirmedUrl);
  // 4) LLM 找公开海报 URL（真实来源都失败后再试）
  if (candidates.length === 0 && params.findPosterUrlByLlm) {
    await log?.("poster: 常规来源均未找到，尝试 LLM 查找公开海报 URL…");
    push(
      await params.findPosterUrlByLlm({
        title: params.title,
        titleEn: params.titleEn,
        year: params.year,
      }),
    );
  }
  const orderedCandidates = prioritizePosterCandidates(candidates, [
    ...(params.posterUrls ?? []),
    params.posterUrl ?? "",
  ]);
  candidates.splice(0, candidates.length, ...orderedCandidates);
  // 同一影片的成功 URL 缓存优先尝试（跨分析复用，显著提升“同片时好时坏”问题）
  const cache = await loadPosterCache();
  const cacheHit = params.imdbId
    ? cache[
        posterCacheKey(params.title, params.titleEn, params.year, params.imdbId)
      ]
    : null;
  if (cacheHit && /^https?:\/\//i.test(cacheHit) && !seen.has(cacheHit)) {
    await log?.("poster: 命中历史成功缓存，优先尝试");
    candidates.unshift(cacheHit);
    seen.add(cacheHit);
  }

  // 多轮重试：每轮按顺序尝试全部候选；网络抖动导致的偶发失败可通过重试吸收。
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-poster-"));
  let successUrl: string | null = null;
  try {
    for (let attempt = 1; attempt <= 3 && successUrl === null; attempt += 1) {
      for (const sourceUrl of candidates) {
        if (attempt === 1)
          await log?.(`poster: 尝试来源 ${sourceUrl.slice(0, 90)}…`);
        const tmp = path.join(tmpDir, `candidate-${attempt}.img`);
        try {
          if (
            !(await downloadTo(
              sourceUrl,
              tmp,
              posterProxyUrl,
              POSTER_DOWNLOAD_TIMEOUT_MS,
            ))
          ) {
            if (attempt === 3) await log?.("poster: 下载失败，尝试下一个来源");
            continue;
          }
          // 校验下载内容确为可解码图片（非 HTML/错误页），避免把垃圾当海报
          try {
            const head = await fs.readFile(tmp);
            if (head.length < 1000) throw new Error("内容过短，疑似错误响应");
            const signature = head.subarray(0, 12).toString("hex");
            const jpgOk = signature.startsWith("ffd8ff");
            const pngOk = signature.startsWith("89504e47");
            // 现代图床常返回 WebP，也有 AVIF/HEIF/GIF；交给 ffmpeg 解码转换，
            // 不要因为签名不是 JPG/PNG 就丢弃有效海报。
            const webpOk =
              signature.startsWith("52494646") &&
              signature.slice(8, 16) === "57454250";
            const gifOk = signature.startsWith("47494638");
            const ftypOk = signature.slice(8, 16) === "66747970";
            if (!jpgOk && !pngOk && !webpOk && !gifOk && !ftypOk)
              throw new Error("非图片内容（可能是 HTML 或错误页）");
          } catch (contentError) {
            await log?.(
              `poster: 内容校验失败（${contentError instanceof Error ? contentError.message : String(contentError)}），尝试下一个来源`,
            );
            continue;
          }
          if (!(await adaptPoster(tmp, posterJpg, log))) {
            await log?.("poster: 图片适配失败，尝试下一个来源");
            continue;
          }
          // 只有真实海报成功时才落盘并更新缓存；失败路径绝不触碰已有海报。
          // folder.jpg 是同图的 400px 缩略图（老播放器兼容），缩略图失败时退回原样复制。
          if (!(await adaptFolderThumb(posterJpg, folderJpg, log))) {
            await fs.copyFile(posterJpg, folderJpg).catch(() => {});
          }
          successUrl = sourceUrl;
          await fs
            .writeFile(
              path.join(params.targetDirectory, POSTER_META_FILE),
              JSON.stringify({
                imdbId: params.imdbId ?? null,
                title: params.title ?? null,
                titleEn: params.titleEn ?? null,
                year: params.year ?? null,
                sourceUrl,
                savedAt: new Date().toISOString(),
              }),
              "utf8",
            )
            .catch(() => {
              void log?.(
                "poster: 写入 poster.meta.json 失败（GET /media/poster 已容错，不影响显示）",
              );
            });
          if (params.imdbId)
            cache[
              posterCacheKey(
                params.title,
                params.titleEn,
                params.year,
                params.imdbId,
              )
            ] = sourceUrl;
          await savePosterCache(cache);
          await log?.(
            `poster: 已生成 ${posterJpg}（1024×1532）+ folder.jpg 缩略图（400px 宽）`,
          );
          return posterJpg;
        } finally {
          await fs.unlink(tmp).catch(() => {});
        }
      }
      if (successUrl === null && attempt < 3) {
        await log?.("poster: 本轮全部候选失败，稍作间隔后重试…");
        await new Promise((resolve) => setTimeout(resolve, 800));
      }
    }
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true }).catch(() => {});
  }
  // 全部真实来源失败：绝不生成信息卡、绝不落盘、绝不替换已有海报。
  // 目录里已有海报（poster.jpg/folder.jpg）时原样保留；没有则不产生任何文件。
  const keptExisting =
    exists ||
    (await fs
      .access(posterJpg)
      .then(() => true)
      .catch(() => false));
  if (keptExisting) {
    await log?.(
      "poster: 真实海报下载失败，保留目录中已有海报（不替换为信息卡）",
    );
    return posterJpg;
  }
  await log?.("poster: 未能成功生成真实海报，不落盘、不生成占位图");
  return null;
}
