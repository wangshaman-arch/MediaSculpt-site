import { Router, type IRouter } from "express";
import healthRouter from "./health";
import assistantRouter from "./assistant";
import jobsRouter from "./jobs";
import browseRouter from "./browse";
import imdbRouter from "./imdb";
import runtimeRouter from "./runtime";
import shutdownRouter from "./shutdown";
import smartWorkflowRouter from "./smart-workflow";
import previewRouter from "./preview";

const router: IRouter = Router();

router.use(assistantRouter);
router.use(healthRouter);
router.use(browseRouter);
router.use(imdbRouter);
router.use(runtimeRouter);
router.use(shutdownRouter);
router.use(smartWorkflowRouter);
router.use(previewRouter);
router.use(jobsRouter);

export default router;
