import { describe, expect, it } from "vitest";
import { subtitleModeAccent } from "./subtitle-mode-model";

describe("subtitle mode model", () => {
  it("keeps automatic mode amber and tool-dependent modes highlighted", () => {
    expect(subtitleModeAccent("auto", true)).toBe("amber-active");
    expect(subtitleModeAccent("ocr", false)).toBe("amber-tool");
    expect(subtitleModeAccent("extract", true)).toBe("primary-active");
    expect(subtitleModeAccent("bilingual", false)).toBe("default");
  });
});
