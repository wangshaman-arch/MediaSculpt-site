import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  BookOpen,
  ChevronDown,
  ChevronUp,
  Download,
  RotateCcw,
  Save,
  Upload,
} from "lucide-react";
import { useI18n } from "@/i18n";
import {
  DEFAULT_CUSTOM_TUNING,
  type CustomTuning,
  type CustomTuningPrompts,
} from "@/lib/custom-tuning";

const PROMPT_KEYS: Array<{
  key: keyof CustomTuningPrompts;
  required: boolean;
}> = [
  { key: "analysis", required: true },
  { key: "identity", required: true },
  { key: "translate", required: false },
  { key: "readme", required: false },
  { key: "review", required: false },
];

const PROMPT_PLACEHOLDERS = [
  "{{titleEn}}",
  "{{titleZh}}",
  "{{year}}",
  "{{sourcePath}}",
  "{{sourceType}}",
  "{{duration}}",
  "{{prompt}}",
  "{{logic.<key>}}",
];

const GLOSSARY: Array<{ token: string; meaningKey: string }> = [
  { token: "TITLE_EN", meaningKey: "settings.tuningGlossary.titleEn" },
  { token: "TITLE_ZH", meaningKey: "settings.tuningGlossary.titleZh" },
  { token: "YEAR", meaningKey: "settings.tuningGlossary.year" },
  { token: "POSTER_URL", meaningKey: "settings.tuningGlossary.posterUrl" },
  { token: "title", meaningKey: "settings.tuningGlossary.jsonTitle" },
  { token: "titleEn", meaningKey: "settings.tuningGlossary.jsonTitleEn" },
  { token: "year", meaningKey: "settings.tuningGlossary.jsonYear" },
  { token: "overview", meaningKey: "settings.tuningGlossary.overview" },
  { token: "mediaType", meaningKey: "settings.tuningGlossary.mediaType" },
  { token: "confidence", meaningKey: "settings.tuningGlossary.confidence" },
  { token: "matchReason", meaningKey: "settings.tuningGlossary.matchReason" },
  {
    token: "technicalAssessment",
    meaningKey: "settings.tuningGlossary.technicalAssessment",
  },
  {
    token: "recommendedAction",
    meaningKey: "settings.tuningGlossary.recommendedAction",
  },
  {
    token: "{{titleEn}} {{titleZh}} {{year}} {{sourcePath}} …",
    meaningKey: "settings.tuningGlossary.placeholders",
  },
  {
    token: "{{logic.<key>}}",
    meaningKey: "settings.tuningGlossary.logicPlaceholder",
  },
];

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

type TuningPromptsCardProps = {
  tuning: CustomTuning;
  onChange: (next: CustomTuning) => void;
  onSave: (next: CustomTuning) => Promise<void>;
};

export function TuningPromptsCard({
  tuning,
  onChange,
  onSave,
}: TuningPromptsCardProps) {
  const { t } = useI18n();
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);
  const [glossaryOpen, setGlossaryOpen] = useState(false);

  const save = async () => {
    setBusy(true);
    try {
      await onSave(tuning);
      setSaved(true);
      window.setTimeout(() => setSaved(false), 2000);
    } finally {
      setBusy(false);
    }
  };

  const restoreDefaults = () => {
    onChange({ ...tuning, prompts: { ...DEFAULT_CUSTOM_TUNING.prompts } });
  };

  const exportJson = () => {
    const blob = new Blob(
      [
        JSON.stringify(
          {
            schema: "mediasculpt-tuning",
            section: "prompts",
            prompts: tuning.prompts,
          },
          null,
          2,
        ),
      ],
      { type: "application/json" },
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "mediasculpt-tuning-prompts.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const importJson = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result ?? "")) as {
          prompts?: Partial<CustomTuningPrompts>;
        };
        if (!isPlainObject(parsed.prompts)) return;
        // 只替换提示词部分；逻辑参数保持不变（兼容旧版整份 {prompts, logic} 导出文件）
        onChange({
          ...tuning,
          prompts: { ...DEFAULT_CUSTOM_TUNING.prompts, ...parsed.prompts },
        });
      } catch {
        /* ignore invalid files */
      }
    };
    reader.readAsText(file);
  };

  const updatePrompt = (key: keyof CustomTuningPrompts, value: string) => {
    onChange({ ...tuning, prompts: { ...tuning.prompts, [key]: value } });
  };

  return (
    <div className="space-y-4" data-testid="settings-tuning-prompts">
      <Card className="border-amber-400/25">
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <CardTitle>{t("settings.tuningPromptsTitle")}</CardTitle>
              <CardDescription className="mt-1">
                {t("settings.tuningPromptsDesc")}
              </CardDescription>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={restoreDefaults}
              >
                <RotateCcw className="mr-1.5 h-3.5 w-3.5" />
                {t("settings.tuningRestore")}
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={exportJson}
              >
                <Download className="mr-1.5 h-3.5 w-3.5" />
                {t("settings.tuningExport")}
              </Button>
              <label className="inline-flex h-8 cursor-pointer items-center gap-1.5 rounded-md border px-3 text-xs text-muted-foreground hover:border-primary/50 hover:text-foreground">
                <Upload className="h-3.5 w-3.5" />
                {t("settings.tuningImport")}
                <input
                  type="file"
                  accept="application/json,.json"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.currentTarget.files?.[0];
                    if (file) importJson(file);
                    e.currentTarget.value = "";
                  }}
                />
              </label>
              <Button
                type="button"
                size="sm"
                disabled={busy}
                onClick={() => void save()}
              >
                <Save className="mr-1.5 h-3.5 w-3.5" />
                {saved ? t("settings.tuningSaved") : t("settings.tuningSave")}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <p className="text-xs leading-relaxed text-muted-foreground">
            {t("settings.tuningPromptsIntro")}
          </p>

          {/* 英文标记释义（默认收起） */}
          <Collapsible open={glossaryOpen} onOpenChange={setGlossaryOpen}>
            <CollapsibleTrigger asChild>
              <button
                type="button"
                className="flex w-full items-center justify-between rounded-lg border border-amber-400/25 bg-background/50 px-3 py-2 text-left text-xs font-medium text-foreground hover:border-primary/50"
              >
                <span className="flex items-center gap-1.5">
                  <BookOpen className="h-3.5 w-3.5 text-amber-400" />
                  {t("settings.tuningGlossaryTitle")}
                </span>
                {glossaryOpen ? (
                  <ChevronUp className="h-3.5 w-3.5 text-muted-foreground" />
                ) : (
                  <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
                )}
              </button>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <div className="mt-2 overflow-hidden rounded-lg border bg-background/50">
                <table className="w-full text-left text-[11px]">
                  <thead>
                    <tr className="border-b bg-secondary/30 text-muted-foreground">
                      <th className="px-3 py-2 font-medium">
                        {t("settings.tuningGlossaryToken")}
                      </th>
                      <th className="px-3 py-2 font-medium">
                        {t("settings.tuningGlossaryMeaning")}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {GLOSSARY.map((entry) => (
                      <tr key={entry.token} className="border-b last:border-0">
                        <td className="whitespace-nowrap px-3 py-1.5 font-mono text-[10px] text-amber-400/90">
                          {entry.token}
                        </td>
                        <td className="px-3 py-1.5 text-muted-foreground">
                          {t(entry.meaningKey)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CollapsibleContent>
          </Collapsible>

          {/* 提示词模板（大文本编辑 + 占位符列表） */}
          <div>
            <p className="mb-2 text-xs font-medium text-amber-400">
              {t("settings.tuningPromptsLabel")}
            </p>
            <div className="space-y-3">
              {PROMPT_KEYS.map(({ key, required }) => (
                <div
                  key={key}
                  className="rounded-lg border bg-background/60 p-3"
                >
                  <div className="mb-1 flex items-center justify-between">
                    <span className="text-xs font-medium text-foreground">
                      {t(`settings.tuningPrompt.${key}`)}
                    </span>
                    <span className="flex items-center gap-2">
                      {required && (
                        <Badge
                          variant="secondary"
                          className="text-[10px] font-normal"
                        >
                          {t("settings.tuningPromptRequired")}
                        </Badge>
                      )}
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        className="h-6 px-2 text-[10px] text-muted-foreground"
                        onClick={() =>
                          updatePrompt(key, DEFAULT_CUSTOM_TUNING.prompts[key])
                        }
                      >
                        {t("settings.tuningPromptRestore")}
                      </Button>
                    </span>
                  </div>
                  <textarea
                    value={tuning.prompts[key]}
                    onChange={(e) => updatePrompt(key, e.currentTarget.value)}
                    rows={required ? 8 : 5}
                    className="min-h-24 w-full resize-y rounded-md border bg-background px-2 py-1.5 font-mono text-[11px] leading-relaxed outline-none focus:border-primary/60"
                  />
                  <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground/80">
                    {t(`settings.tuningPrompt.${key}Hint`)}
                  </p>
                  <p className="mt-1 flex flex-wrap gap-1">
                    {PROMPT_PLACEHOLDERS.map((placeholder) => (
                      <code
                        key={placeholder}
                        className="rounded bg-secondary/70 px-1 py-0.5 font-mono text-[10px] text-muted-foreground"
                      >
                        {placeholder}
                      </code>
                    ))}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
