import type { ChildProcess } from "node:child_process";
import { JobProcessRegistry } from "./job-process-registry";
import { processRunner } from "./process-runner";
import type { ProcessRunner } from "./process-types";

export class JobProcessController {
  readonly activeChildren = new Set<ChildProcess>();

  constructor(
    private readonly runner: ProcessRunner = processRunner,
    private readonly jobs = new JobProcessRegistry(),
    private readonly platform: NodeJS.Platform = process.platform,
  ) {}

  spawn(executable: string, args: string[], timeoutMs?: number): ChildProcess {
    const child = this.runner.spawn({ executable, args }).child;
    this.activeChildren.add(child);
    child.once("close", () => this.activeChildren.delete(child));
    child.once("error", () => this.activeChildren.delete(child));
    // 可选超时：悬挂的探测类进程（如卡住的 ffprobe）到点强制结束，避免 Promise 永不结算。
    if (timeoutMs && timeoutMs > 0) {
      const timer = setTimeout(() => {
        try {
          child.kill("SIGKILL");
        } catch {
          /* 进程可能已退出 */
        }
      }, timeoutMs);
      child.once("close", () => clearTimeout(timer));
      child.once("error", () => clearTimeout(timer));
    }
    return child;
  }

  spawnForJob(
    jobId: number,
    executable: string,
    args: string[],
    highPriority = false,
  ): ChildProcess {
    let command = executable;
    let commandArgs = args;
    if (this.platform !== "win32") {
      command = "nice";
      commandArgs = ["-n", highPriority ? "-5" : "10", executable, ...args];
    }
    return this.jobs.track(jobId, this.spawn(command, commandArgs));
  }

  killJob(jobId: number): Promise<boolean> {
    return this.jobs.kill(jobId);
  }

  clearJob(jobId: number): void {
    this.jobs.clear(jobId);
  }

  /** 该任务当前是否仍有被跟踪的活跃子进程（供运行时卡死任务回收判断）。 */
  hasActiveJobProcess(jobId: number): boolean {
    return this.jobs.size(jobId) > 0;
  }
}

export const jobProcessController = new JobProcessController();
