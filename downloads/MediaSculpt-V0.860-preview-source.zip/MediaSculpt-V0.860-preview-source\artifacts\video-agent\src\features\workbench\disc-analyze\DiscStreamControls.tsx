import type { DiscStream } from "@workspace/api-client-react";
import { Music, Subtitles, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import type { ProcessingMode } from "@/hooks/useWorkbenchState";
import { useI18n } from "@/i18n";
import { cn } from "@/lib/utils";
import type { ScanCopy } from "@/pages/Scan";
import { streamKindLabel } from "@/pages/Scan";
import {
  streamLanguageDisplay as languageLabel,
  streamTechnicalBadges,
  type DiscTrackWithMakeMkv,
} from "../disc-display-model";
import { discVerificationMessage } from "../disc-verification-model";

export type DiscStreamControlsProps = {
  uiText: ScanCopy;
  selectedTrack: DiscTrackWithMakeMkv;
  activeTrackIdx: number;
  verifying: boolean;
  selectableStreams: DiscStream[];
  selectedStreamIndices: Set<number>;
  selectedTitleCount: number;
  discType: "dvd" | "bluray";
  processingMode: ProcessingMode;
  verifyDvdTitles: boolean;
  processingMappingBlocked: boolean;
  onToggleStream: (index: number) => void;
  onSetAllStreams: (selected: boolean) => void;
  onRequestReverification: (idx: number) => void;
  onSelectMode?: (mode: ProcessingMode) => void;
};

export function DiscStreamControls({
  uiText,
  selectedTrack,
  activeTrackIdx,
  verifying,
  selectableStreams,
  selectedStreamIndices,
  selectedTitleCount,
  discType,
  processingMode,
  verifyDvdTitles,
  processingMappingBlocked,
  onToggleStream,
  onSetAllStreams,
  onRequestReverification,
  onSelectMode,
}: DiscStreamControlsProps) {
  const { t } = useI18n();
  const warning = discVerificationMessage(
    {
      track: selectedTrack,
      isVerifying: verifying,
      verifyDvdTitles,
      discType,
      processingMode,
    },
    t,
  );
  const canReverify =
    discType === "dvd" &&
    processingMode === "remux" &&
    selectedTrack?.verificationStatus === "failed";
  const canSwitchToRemux =
    discType === "bluray" &&
    processingMode === "compress" &&
    (typeof selectedTrack.handbrakeTitleNumber !== "number" ||
      selectedTrack.handbrakeTitleNumber <= 0);

  return (
    <div data-testid="title-level-stream-controls">
      <div className="mb-2 flex items-center justify-between gap-2">
        <p className="text-xs font-medium text-muted-foreground">
          {uiText.selectStreams}
        </p>
        <div className="flex shrink-0 gap-1">
          <button
            type="button"
            className="rounded border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-secondary/50"
            onClick={() => onSetAllStreams(true)}
            disabled={verifying}
          >
            {uiText.selectAllStreams}
          </button>
          <button
            type="button"
            className="rounded border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-secondary/50"
            onClick={() => onSetAllStreams(false)}
            disabled={verifying}
          >
            {uiText.clearAllStreams}
          </button>
        </div>
      </div>
      <div className="space-y-1 rounded-lg border divide-y">
        {selectableStreams.map((s) => {
          const checked = selectedStreamIndices.has(s.index);
          const icon =
            s.codecType === "video" ? (
              <Video className="h-3.5 w-3.5 text-blue-400 shrink-0" />
            ) : s.codecType === "audio" ? (
              <Music className="h-3.5 w-3.5 text-green-400 shrink-0" />
            ) : (
              <Subtitles className="h-3.5 w-3.5 text-yellow-400 shrink-0" />
            );
          return (
            <label
              key={s.index}
              onPointerDown={(event) => event.stopPropagation()}
              onClick={(event) => event.stopPropagation()}
              className={cn(
                "flex cursor-pointer items-center gap-3 px-3 py-2 text-sm transition-colors",
                checked ? "bg-primary/5" : "hover:bg-secondary/30",
              )}
            >
              <Checkbox
                checked={checked}
                disabled={verifying}
                onCheckedChange={() => onToggleStream(s.index)}
                className="shrink-0"
              />
              {icon}
              <span className="min-w-0 flex-1">
                <span className="flex flex-wrap items-center gap-1.5">
                  <span className="font-medium">
                    {streamKindLabel(s.codecType, t)}
                  </span>
                  <span className="text-muted-foreground">
                    {languageLabel(s, t)}
                  </span>
                  {s.title && (
                    <span className="truncate text-muted-foreground">
                      · {s.title}
                    </span>
                  )}
                </span>
                <span className="mt-1 flex flex-wrap gap-1">
                  {streamTechnicalBadges(s).map((badge) => (
                    <span
                      key={badge}
                      className="rounded border bg-background/60 px-1.5 py-0.5 text-[10px] font-mono text-muted-foreground"
                    >
                      {badge}
                    </span>
                  ))}
                </span>
              </span>
              {s.default && (
                <span className="shrink-0 rounded bg-primary/10 px-1.5 py-0.5 text-[10px] text-primary">
                  {t("streamSelector.default")}
                </span>
              )}
              {s.forced && (
                <span className="shrink-0 rounded bg-orange-500/10 px-1.5 py-0.5 text-[10px] text-orange-500">
                  {t("streamSelector.forced")}
                </span>
              )}
              <span className="shrink-0 font-mono text-xs text-muted-foreground">
                #{s.index}
              </span>
            </label>
          );
        })}
      </div>
      <p className="mt-1.5 text-xs text-muted-foreground">
        {t("scan.titleSelectedSummary", {
          selected: selectedStreamIndices.size,
          total: selectableStreams.length,
          titles: selectedTitleCount,
        })}
      </p>
      {processingMappingBlocked && warning && (
        <div className="mt-1.5 flex items-center gap-2 text-xs text-orange-400">
          <span>{warning}</span>
          {canReverify && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => onRequestReverification(activeTrackIdx)}
            >
              {t("scan.reVerify")}
            </Button>
          )}
          {canSwitchToRemux && onSelectMode && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => onSelectMode("remux")}
            >
              {t("scan.switchToRemux")}
            </Button>
          )}
        </div>
      )}
      {processingMode === "remux" &&
        selectedTrack.verificationStatus === "verified" &&
        (selectedTrack.verificationWarnings?.length ?? 0) > 0 && (
          <div className="mt-1.5 rounded border border-yellow-500/30 bg-yellow-500/5 px-2 py-1.5 text-xs text-yellow-300">
            <p>{t("scan.titleVerifiedHint")}</p>
            <ul className="mt-1 list-disc space-y-0.5 pl-4">
              {selectedTrack.verificationWarnings?.map(
                (verificationWarning) => (
                  <li key={verificationWarning}>{verificationWarning}</li>
                ),
              )}
            </ul>
          </div>
        )}
      {processingMode === "compress" && discType === "dvd" && verifying && (
        <p className="mt-1.5 text-xs text-muted-foreground">
          {t("scan.readingStreams")}
        </p>
      )}
      {processingMode === "compress" &&
        discType === "dvd" &&
        selectedTrack.verificationStatus === "failed" && (
          <p className="mt-1.5 text-xs text-orange-400">{warning}</p>
        )}
      {verifying && (
        <p className="mt-1.5 text-xs text-muted-foreground">
          {t("scan.readingStreams")}
        </p>
      )}
    </div>
  );
}
