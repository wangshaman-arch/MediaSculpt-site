import { describe, expect, it } from "vitest";
import {
  resolveDefaultSubtitlePreviewKind,
  subtitleCueUrl,
  type ExternalSubtitleFile,
} from "./useJobSourceInfo";

const files: ExternalSubtitleFile[] = [
  { name: "movie.srt", path: "/a/movie.srt", kind: "original" },
  { name: "movie.zh.srt", path: "/a/movie.zh.srt", kind: "translated" },
  { name: "movie.forced.srt", path: "/a/movie.forced.srt", kind: "other" },
];

describe("useJobSourceInfo helpers", () => {
  it("prefers translated subtitles when nothing is selected yet", () => {
    expect(resolveDefaultSubtitlePreviewKind(files, "off")).toBe(
      "file:movie.zh.srt",
    );
  });

  it("falls back to original then first file", () => {
    expect(resolveDefaultSubtitlePreviewKind([files[0], files[2]], "off")).toBe(
      "file:movie.srt",
    );
    expect(resolveDefaultSubtitlePreviewKind([files[2]], "off")).toBe(
      "file:movie.forced.srt",
    );
  });

  it("keeps an existing selection and stays off with no files", () => {
    expect(resolveDefaultSubtitlePreviewKind(files, "translated")).toBe(
      "translated",
    );
    expect(resolveDefaultSubtitlePreviewKind([], "off")).toBe("off");
  });

  it("builds the correct subtitle cue endpoint", () => {
    expect(subtitleCueUrl(5, "off")).toBeNull();
    expect(subtitleCueUrl(5, "subtitle")).toBe(
      "/api/jobs/5/subtitle-preview?kind=subtitle",
    );
    expect(subtitleCueUrl(5, "translated")).toBe(
      "/api/jobs/5/subtitle-preview?kind=translated",
    );
    expect(subtitleCueUrl(5, "embedded:3")).toBe(
      "/api/jobs/5/subtitle-vtt?stream=3",
    );
    expect(subtitleCueUrl(5, "file:my subs.srt")).toBe(
      "/api/jobs/5/subtitle-preview?file=my%20subs.srt",
    );
  });
});
