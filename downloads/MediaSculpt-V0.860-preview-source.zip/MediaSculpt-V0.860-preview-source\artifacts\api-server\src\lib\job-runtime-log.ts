import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { diagnosticsLogPath } from "./runtime-tool-log";

export type JobToolOutput = {
  tool: string;
  executable: string;
  args: string[];
  exitCode: number | null;
  durationMs: number;
  stdout: string;
  stderr: string;
};

export function serviceLogDirectory(): string {
  return (
    process.env.MEDIASCULPT_SERVICE_LOG_DIR ??
    process.env.VX_AGENT_SERVICE_LOG_DIR ??
    path.join(os.tmpdir(), "MediaSculpt", "logs")
  );
}

export function jobRuntimeLogPath(): string {
  return (
    process.env.MEDIASCULPT_JOB_LOG_PATH ??
    process.env.VX_AGENT_JOB_LOG_PATH ??
    path.join(serviceLogDirectory(), "job-events.tmp.log")
  );
}

export async function appendJobRuntimeLog(
  jobId: number,
  level: string,
  message: string,
): Promise<void> {
  const logPath = jobRuntimeLogPath();
  await fs.mkdir(path.dirname(logPath), { recursive: true });
  const timestamp = new Date().toISOString();
  const line = `[${timestamp}] job=${jobId} level=${level} ${message}\n`;
  await fs.appendFile(logPath, line, "utf8");
  const diagnosticsPath = diagnosticsLogPath();
  await fs
    .mkdir(path.dirname(diagnosticsPath), { recursive: true })
    .catch(() => {});
  await fs
    .appendFile(
      diagnosticsPath,
      `===== JOB ${jobId} ${level.toUpperCase()} =====\n${line}`,
      "utf8",
    )
    .catch(() => {});
}

/** Persist the complete child-process result so failures are diagnosable without guessing. */
export async function appendJobToolOutput(
  jobId: number,
  output: JobToolOutput,
): Promise<void> {
  const timestamp = new Date().toISOString();
  const section = [
    `===== JOB ${jobId} TOOL ${output.tool.toUpperCase()} =====`,
    `timestamp=${timestamp}`,
    `executable=${output.executable}`,
    `args=${JSON.stringify(output.args)}`,
    `exitCode=${output.exitCode ?? "null"}`,
    `durationMs=${output.durationMs}`,
    "--- stdout ---",
    output.stdout || "(empty)",
    "--- stderr ---",
    output.stderr || "(empty)",
    "--- end tool output ---",
    "",
  ].join("\n");
  const logPath = jobRuntimeLogPath();
  await fs.mkdir(path.dirname(logPath), { recursive: true });
  await fs.appendFile(logPath, section, "utf8");
  const diagnosticsPath = diagnosticsLogPath();
  await fs
    .mkdir(path.dirname(diagnosticsPath), { recursive: true })
    .catch(() => {});
  await fs.appendFile(diagnosticsPath, section, "utf8").catch(() => {});
}
