import { describe, expect, it } from "vitest";
import {
  doesNotSupportFfmpegProgressOption,
  formatFfmpegTimestamp,
  parseFfmpegProgressSeconds,
} from "./ffmpeg-progress";

describe("FFmpeg progress protocol", () => {
  it("parses the timestamp from progress records", () => {
    expect(
      parseFfmpegProgressSeconds(
        "frame=42\nout_time=00:01:23.500000\nprogress=continue\n",
      ),
    ).toBe(83.5);
  });

  it("accepts the microsecond timestamp fields emitted by FFmpeg", () => {
    expect(
      parseFfmpegProgressSeconds("out_time_us=9050000\nprogress=continue\n"),
    ).toBe(9.05);
  });

  it("returns null when no valid output timestamp is present", () => {
    expect(
      parseFfmpegProgressSeconds("frame=42\nprogress=continue\n"),
    ).toBeNull();
    expect(parseFfmpegProgressSeconds("out_time=N/A\n")).toBeNull();
  });

  it("formats long media timestamps as hours, minutes and seconds", () => {
    expect(formatFfmpegTimestamp(7942.9)).toBe("02:12:22");
    expect(formatFfmpegTimestamp(83)).toBe("00:01:23");
    expect(formatFfmpegTimestamp(-1)).toBe("00:00:00");
  });

  it("detects an unsupported progress option without treating unrelated FFmpeg errors as a compatibility issue", () => {
    expect(
      doesNotSupportFfmpegProgressOption(1, "Unrecognized option 'progress'."),
    ).toBe(true);
    expect(
      doesNotSupportFfmpegProgressOption(
        1,
        "Error splitting the argument list: Option not found: progress",
      ),
    ).toBe(true);
    expect(doesNotSupportFfmpegProgressOption(1, "Invalid input file")).toBe(
      false,
    );
    expect(
      doesNotSupportFfmpegProgressOption(0, "Unrecognized option 'progress'."),
    ).toBe(false);
  });
});
