import fs from "node:fs";
import path from "node:path";

export const projectRoot = path.resolve(import.meta.dirname, "../../../..");

const videoAgentSrc = path.join(projectRoot, "artifacts/video-agent/src");

/**
 * Page/component containers whose contract is built from the modules they
 * actually compose. Inclusion is derived from relative imports instead of a
 * directory scan so a component that is never imported by its container can no
 * longer satisfy an assertion by accident.
 */
const frontendReachableContainers = new Set([
  "artifacts/video-agent/src/pages/Scan.tsx",
  "artifacts/video-agent/src/pages/Settings.tsx",
  "artifacts/video-agent/src/pages/JobDetail.tsx",
  "artifacts/video-agent/src/features/workbench/DiscAnalyzeDialog.tsx",
  "artifacts/video-agent/src/components/AssistantPanel.tsx",
]);

/**
 * Hooks a container composes through the `@/` alias. These are explicit
 * single-file companions (not blanket directory scans), so they cannot mask an
 * orphaned component; they stay listed the same way the backend route modules
 * are.
 */
const frontendHookCompanions: Record<string, string[]> = {
  "artifacts/video-agent/src/pages/Scan.tsx": [
    "artifacts/video-agent/src/hooks/useWorkbenchState.ts",
  ],
  "artifacts/video-agent/src/pages/Settings.tsx": [
    "artifacts/video-agent/src/hooks/useSettingsSections.ts",
  ],
  "artifacts/video-agent/src/pages/JobDetail.tsx": [
    "artifacts/video-agent/src/hooks/useJobActions.ts",
    "artifacts/video-agent/src/hooks/useJobAssistantExecution.ts",
    "artifacts/video-agent/src/hooks/useJobPresets.ts",
    "artifacts/video-agent/src/hooks/useJobSourceInfo.ts",
  ],
};

/** Guards against import cycles and keep the bundle bounded. */
const maxImportDepth = 12;

/**
 * Shared infrastructure is not part of a component's composed surface. The
 * locale packs are asserted separately through `zhPack()`/`enPack()`, so
 * pulling them into every bundle would only make `not.toContain` checks
 * meaningless.
 */
const excludedSharedRoots = [
  path.join(videoAgentSrc, "i18n"),
  path.join(videoAgentSrc, "lib"),
  path.join(videoAgentSrc, "hooks"),
  path.join(videoAgentSrc, "components", "ui"),
];

function isExcludedShared(file: string): boolean {
  return excludedSharedRoots.some(
    (root) => file === root || file.startsWith(`${root}${path.sep}`),
  );
}

const staticImportRe =
  /\b(?:import|export)\b[^"'`]*?\bfrom\s*["']([^"']+)["']/g;
const sideEffectImportRe = /\bimport\s*["']([^"']+)["']/g;
const dynamicImportRe = /\bimport\s*\(\s*["']([^"']+)["']/g;
const typeOnlyImportRe = /^\s*(?:import|export)\s+type\b/;

function isFile(candidate: string): boolean {
  try {
    return fs.statSync(candidate).isFile();
  } catch {
    return false;
  }
}

/** Resolve a relative import specifier to a real source file on disk. */
function resolveRelativeSpecifier(
  fromFile: string,
  specifier: string,
): string | null {
  if (!specifier.startsWith(".")) return null;
  const base = path.resolve(path.dirname(fromFile), specifier);
  const candidates: string[] = [];
  if (/\.(ts|tsx|js|jsx|mjs|cjs)$/.test(specifier)) {
    candidates.push(base);
    if (/\.(js|jsx|mjs|cjs)$/.test(specifier)) {
      // A compiled ".js" specifier can still point at its TypeScript source.
      candidates.push(base.replace(/\.(?:js|jsx|mjs|cjs)$/, ".ts"));
      candidates.push(base.replace(/\.(?:js|jsx|mjs|cjs)$/, ".tsx"));
    }
  } else {
    candidates.push(
      base,
      `${base}.ts`,
      `${base}.tsx`,
      `${base}.d.ts`,
      path.join(base, "index.ts"),
      path.join(base, "index.tsx"),
    );
  }
  for (const candidate of candidates) {
    if (isFile(candidate)) return path.normalize(candidate);
  }
  return null;
}

function extractRelativeSpecifiers(source: string): string[] {
  const specifiers: string[] = [];
  for (const pattern of [staticImportRe, sideEffectImportRe, dynamicImportRe]) {
    pattern.lastIndex = 0;
    let match: RegExpExecArray | null;
    while ((match = pattern.exec(source)) !== null) {
      const specifier = match[1];
      if (!specifier || !specifier.startsWith(".")) continue;
      // Type-only imports are erased at build time: they do not compose the
      // runtime surface, so they must not drag a module into the bundle.
      if (pattern === staticImportRe && typeOnlyImportRe.test(match[0])) {
        continue;
      }
      specifiers.push(specifier);
    }
  }
  return specifiers;
}

/**
 * The container source plus every module reachable from it by following
 * relative import specifiers (`./x`, `./dir/x`, `./x.tsx`, `./x/index.ts`,
 * dynamic `import()`). Bounded depth and deduplicated.
 */
export function readReachableSources(containerRelativePath: string): string {
  const container = path.join(projectRoot, containerRelativePath);
  const visited = new Set<string>();
  const sources: string[] = [];
  const queue: Array<{ file: string; depth: number }> = [
    { file: path.normalize(container), depth: 0 },
  ];
  while (queue.length > 0) {
    const current = queue.shift();
    if (!current) break;
    const { file, depth } = current;
    if (visited.has(file) || !isFile(file)) continue;
    visited.add(file);
    const source = fs.readFileSync(file, "utf8");
    sources.push(source);
    if (depth >= maxImportDepth) continue;
    for (const specifier of extractRelativeSpecifiers(source)) {
      const resolved = resolveRelativeSpecifier(file, specifier);
      if (!resolved || !resolved.startsWith(videoAgentSrc)) continue;
      if (isExcludedShared(resolved)) continue;
      if (/\.(test|spec)\.(ts|tsx)$/.test(resolved)) continue;
      if (!visited.has(resolved)) {
        queue.push({ file: resolved, depth: depth + 1 });
      }
    }
  }
  return sources.join("\n");
}

export function readProjectFile(relativePath: string): string {
  const absolutePath = path.join(projectRoot, relativePath);
  if (!fs.existsSync(absolutePath)) return "";
  const source = fs.readFileSync(absolutePath, "utf8");
  if (frontendReachableContainers.has(relativePath)) {
    const hookSources = (frontendHookCompanions[relativePath] ?? []).map(
      (hook) => {
        const hookPath = path.join(projectRoot, hook);
        return fs.existsSync(hookPath) ? fs.readFileSync(hookPath, "utf8") : "";
      },
    );
    return [readReachableSources(relativePath), ...hookSources].join("\n");
  }
  // The jobs route was split into focused router modules; contract assertions
  // about the job API should see the whole surface regardless of which file a
  // handler now lives in. These backend companions stay explicit.
  const routeCompanions = {
    "artifacts/api-server/src/routes/jobs.ts": [
      // jobs.ts became a thin composition entry; these modules hold the code
      // that used to live inline (operations endpoints, encoding validation,
      // queue/runtime wiring).
      "artifacts/api-server/src/routes/jobs-operations.ts",
      "artifacts/api-server/src/routes/job-encoding.ts",
      "artifacts/api-server/src/routes/job-runtime.ts",
      "artifacts/api-server/src/routes/jobs-preview.ts",
      "artifacts/api-server/src/routes/jobs-preview-disc.ts",
      "artifacts/api-server/src/routes/jobs-preview-media.ts",
      "artifacts/api-server/src/routes/jobs-preview-subtitles.ts",
      "artifacts/api-server/src/routes/jobs-preview-stream.ts",
      "artifacts/api-server/src/routes/disc.ts",
      "artifacts/api-server/src/routes/admin.ts",
      "artifacts/api-server/src/routes/jobs-crud.ts",
      "artifacts/api-server/src/routes/jobs-crud-helpers.ts",
      "artifacts/api-server/src/routes/jobs-crud-list.ts",
      "artifacts/api-server/src/routes/jobs-crud-create.ts",
      "artifacts/api-server/src/routes/jobs-crud-scan.ts",
      "artifacts/api-server/src/routes/jobs-crud-queue.ts",
      "artifacts/api-server/src/routes/jobs-crud-detail.ts",
      "artifacts/api-server/src/routes/jobs-crud-lifecycle.ts",
      "artifacts/api-server/src/routes/jobs-crud-execution.ts",
      "artifacts/api-server/src/routes/job-orchestrator.ts",
      "artifacts/api-server/src/routes/jobs-bilingual.ts",
      "artifacts/api-server/src/routes/jobs-iso.ts",
      "artifacts/api-server/src/routes/jobs-probe.ts",
      "artifacts/api-server/src/routes/jobs-subtitle-files.ts",
      "artifacts/api-server/src/routes/jobs-output-paths.ts",
      "artifacts/api-server/src/routes/jobs-dvd.ts",
      "artifacts/api-server/src/routes/jobs-tracking.ts",
      "artifacts/api-server/src/routes/jobs-ffmpeg-run.ts",
      "artifacts/api-server/src/routes/jobs-pipeline.ts",
      "artifacts/api-server/src/routes/jobs-config.ts",
      "artifacts/api-server/src/routes/job-ocr-flow.ts",
      "artifacts/api-server/src/routes/jobs-translation.ts",
      "artifacts/api-server/src/routes/jobs-prompts.ts",
      "artifacts/api-server/src/routes/jobs-audio.ts",
      "artifacts/api-server/src/routes/jobs-subtitle-probe.ts",
      "artifacts/api-server/src/routes/jobs-subtitle-pipeline.ts",
      "artifacts/api-server/src/routes/job-chapter-preview.ts",
      "artifacts/api-server/src/routes/job-readme-ai.ts",
      "artifacts/api-server/src/routes/job-dvd-remux.ts",
      "artifacts/api-server/src/routes/jobs-dvd-audio.ts",
      "artifacts/api-server/src/routes/jobs-subtitle-select.ts",
      "artifacts/api-server/src/routes/jobs-subtitle-sidecars.ts",
      "artifacts/api-server/src/routes/job-remux-stage.ts",
      "artifacts/api-server/src/routes/job-compression-stage.ts",
      "artifacts/api-server/src/routes/job-subtitle-stage.ts",
    ],
    // The orchestrator's large Remux/compression/subtitle branches moved into
    // dedicated stage modules; assertions that read the orchestrator must still
    // see them.
    "artifacts/api-server/src/routes/job-orchestrator.ts": [
      "artifacts/api-server/src/routes/job-remux-stage.ts",
      "artifacts/api-server/src/routes/job-compression-stage.ts",
      "artifacts/api-server/src/routes/job-subtitle-stage.ts",
    ],
    // The preview route was split into cohesive modules (disc title preview,
    // media preview/poster, subtitle/download, shared transcode streaming);
    // assertions that read jobs-preview.ts must still see them.
    "artifacts/api-server/src/routes/jobs-preview.ts": [
      "artifacts/api-server/src/routes/jobs-preview-disc.ts",
      "artifacts/api-server/src/routes/jobs-preview-media.ts",
      "artifacts/api-server/src/routes/jobs-preview-subtitles.ts",
      "artifacts/api-server/src/routes/jobs-preview-stream.ts",
    ],
    "artifacts/api-server/src/lib/disc-analysis.ts": [
      "artifacts/api-server/src/lib/disc-analysis-shared.ts",
      "artifacts/api-server/src/lib/disc-analysis-bluray.ts",
      "artifacts/api-server/src/lib/disc-analysis-dvd.ts",
    ],
    "artifacts/api-server/src/lib/metadata.ts": [
      "artifacts/api-server/src/lib/metadata-providers.ts",
      "artifacts/api-server/src/lib/metadata-imdb.ts",
    ],
    "artifacts/api-server/src/lib/tool-downloader.ts": [
      "artifacts/api-server/src/lib/tool-install-tesseract.ts",
    ],
    "artifacts/api-server/src/lib/smart-workflow.ts": [
      "artifacts/api-server/src/lib/smart-workflow-decisions.ts",
    ],
    "artifacts/api-server/src/lib/subtitle-ocr.ts": [
      "artifacts/api-server/src/lib/subtitle-ocr-dvd.ts",
      "artifacts/api-server/src/lib/subtitle-ocr-png.ts",
      "artifacts/api-server/src/lib/subtitle-ocr-pgs.ts",
      "artifacts/api-server/src/lib/subtitle-ocr-tesseract.ts",
      "artifacts/api-server/src/lib/subtitle-ocr-language.ts",
    ],
  }[relativePath];
  if (routeCompanions) {
    return [
      source,
      ...routeCompanions.map((companion) => {
        const companionPath = path.join(projectRoot, companion);
        return fs.existsSync(companionPath)
          ? fs.readFileSync(companionPath, "utf8")
          : "";
      }),
    ].join("\n");
  }
  const extractedImplementation = {
    "artifacts/api-server/src/lib/preview-service.ts":
      "artifacts/api-server/src/media/preview-service.ts",
    "artifacts/api-server/src/lib/compression-service.ts":
      "artifacts/api-server/src/media/compression-service.ts",
  }[relativePath];
  if (extractedImplementation) {
    const implementationPath = path.join(projectRoot, extractedImplementation);
    if (fs.existsSync(implementationPath)) {
      return [source, fs.readFileSync(implementationPath, "utf8")].join("\n");
    }
  }
  return source;
}

/** UI copy now lives in the locale packs; assertions accept source or pack occurrences. */
export const zhPack = () =>
  readProjectFile("artifacts/video-agent/src/i18n/zh-CN.ts");
export const enPack = () =>
  readProjectFile("artifacts/video-agent/src/i18n/en-US.ts");
