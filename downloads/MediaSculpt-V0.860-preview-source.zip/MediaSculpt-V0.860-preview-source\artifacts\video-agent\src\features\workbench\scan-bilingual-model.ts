export type BilingualStyleDraft = {
  layout: "zh-top" | "foreign-top";
  outlineWidth: number;
  shadowWidth: number;
  outlineColor: string;
  fontSizeTop: number;
  fontSizeBottom: number;
};

export function defaultBilingualDraft(): BilingualStyleDraft {
  return {
    layout: "zh-top",
    outlineWidth: 0.2,
    shadowWidth: 0,
    outlineColor: "#404040",
    fontSizeTop: 16,
    fontSizeBottom: 9.6,
  };
}

/** ASS 颜色（&HBBGGRR / &HAABBGGRR）与网页 hex（#RRGGBB）互转，供样式设置面板使用。 */
export function assColorToHex(assColor: string | null | undefined): string {
  const raw = (assColor ?? "").trim();
  const hex = raw.replace(/^&H/i, "").slice(-6);
  if (!/^[0-9a-fA-F]{6}$/.test(hex)) return "#404040";
  const b = hex.slice(0, 2);
  const g = hex.slice(2, 4);
  const r = hex.slice(4, 6);
  return `#${r}${g}${b}`;
}

export function hexToAssColor(hexColor: string): string {
  const raw = (hexColor ?? "").replace(/^#/, "").replace(/^0x/i, "").slice(-6);
  if (!/^[0-9a-fA-F]{6}$/.test(raw)) return "&H00404040";
  const r = raw.slice(0, 2);
  const g = raw.slice(2, 4);
  const b = raw.slice(4, 6);
  return `&H00${b}${g}${r}`;
}
