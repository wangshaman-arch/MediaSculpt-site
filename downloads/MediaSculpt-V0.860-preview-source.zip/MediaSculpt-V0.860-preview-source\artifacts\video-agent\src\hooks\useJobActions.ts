import { useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import {
  getGetJobQueryKey,
  useCancelJob,
  useDeleteJob,
  useRetryJob,
  useStartJob,
} from "@workspace/api-client-react";
import { useToast } from "./use-toast";
import { useI18n } from "../i18n";

export type JobAction = "pause" | "cancel";

export function jobActionUrl(jobId: number, action: JobAction): string {
  return `/api/jobs/${encodeURIComponent(String(jobId))}/${action}`;
}

type JobMutation = { mutateAsync: (input: { id: number }) => Promise<unknown> };

export function useJobActions(jobId: number) {
  const { t } = useI18n();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const startJob = useStartJob();
  const cancelJob = useCancelJob();
  const retryJob = useRetryJob();
  const deleteJob = useDeleteJob();

  const handleAction = useCallback(
    async (action: JobMutation, message: string, isDelete = false) => {
      try {
        await action.mutateAsync({ id: jobId });
        toast({ title: message });
        if (isDelete) setLocation("/jobs");
        else
          void queryClient.invalidateQueries({
            queryKey: getGetJobQueryKey(jobId),
          });
      } catch (error: unknown) {
        toast({
          title: t("jobs.operationFailed"),
          description:
            error instanceof Error ? error.message : t("common.unknownError"),
          variant: "destructive",
        });
      }
    },
    [jobId, queryClient, setLocation, t, toast],
  );

  const pauseJob = useCallback(async () => {
    try {
      const response = await fetch(jobActionUrl(jobId, "pause"), {
        method: "POST",
      });
      const body = (await response.json().catch(() => null)) as {
        error?: string;
      } | null;
      if (!response.ok)
        throw new Error(body?.error ?? `HTTP ${response.status}`);
      void queryClient.invalidateQueries({
        queryKey: getGetJobQueryKey(jobId),
      });
      toast({ title: t("jobs.taskPaused") });
    } catch (error: unknown) {
      toast({
        title: t("jobs.taskPauseFailed"),
        description: error instanceof Error ? error.message : String(error),
      });
    }
  }, [jobId, queryClient, t, toast]);

  return { startJob, cancelJob, retryJob, deleteJob, handleAction, pauseJob };
}
