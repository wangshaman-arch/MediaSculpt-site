export type JobErrorCode =
  | "JOB_NOT_FOUND"
  | "JOB_ALREADY_RUNNING"
  | "JOB_INVALID_STATE"
  | "JOB_CONFIRMATION_REQUIRED";

export class JobCommandError extends Error {
  constructor(
    readonly code: JobErrorCode,
    message: string,
  ) {
    super(message);
    this.name = "JobCommandError";
  }
}

export const ACTIVE_JOB_STATUSES = [
  "scanning",
  "transcribing",
  "compressing",
  "remuxing",
] as const;

export function isActiveJobStatus(status: string): boolean {
  return (ACTIVE_JOB_STATUSES as readonly string[]).includes(status);
}

export function canStartJobStatus(status: string): boolean {
  return status === "pending" || status === "error";
}
