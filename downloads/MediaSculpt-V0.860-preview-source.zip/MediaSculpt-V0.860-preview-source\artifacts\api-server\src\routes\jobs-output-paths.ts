// Extracted from routes/jobs.ts: job output/subtitle directory resolution.
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import {
  lookupAll,
  metadataIdentityMatches,
  normalizeTitleEn,
} from "../lib/metadata";
import {
  servePreviewSegment,
  cleanupPreviewSegments,
} from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import {
  buildFfconcatFileContent as buildManifest,
  buildFfconcatChapterContent,
  buildFfconcatTimedContent,
  type FfconcatTimedSegment,
} from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import {
  appendJobRuntimeLog,
  appendJobToolOutput,
} from "../lib/job-runtime-log";
import {
  appendRuntimeToolLog,
  appendRuntimeToolOutput,
} from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import {
  buildCompressionOutputName,
  buildRemuxOutputName,
  cleanSegment,
  encoderBitDepth,
  selectBestAudioTrack,
} from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import {
  renderBilingualAss,
  DEFAULT_BILINGUAL_STYLE,
  type BilingualAssStyle,
  type SubtitleBlock,
} from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import {
  ensureLocalPoster,
  MEDIA_INFO_DIR,
  POSTER_META_FILE,
  posterIdentityMatches,
} from "../lib/poster";
import {
  ensureFasterWhisperModel,
  ensureWhisperCliScript,
} from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import {
  hasValidSubtitleCues,
  isGraphicSubtitleCodec,
  shouldFallbackToWhisper,
} from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import {
  buildDvdRemuxArgs,
  runDvdRemux,
  verifyDvdTitle,
} from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import {
  buildDvdStructurePayload,
  resolveRemuxPlanWithLlm,
  validateRemuxPlan,
} from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import {
  assertPreviewTaskAllowed,
  recordPreviewAiCall,
  settlePreviewTask,
} from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import {
  parseCustomTuning,
  resolveLogicPlaceholders,
} from "../lib/custom-tuning";
import {
  decryptSecret,
  encryptSecret,
  isEncryptedSecret,
} from "../lib/secrets";
import {
  ffmpegPath,
  resolveOutputDir,
  resolveRuntimePath,
  type RuntimePathConfig,
} from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import {
  assertCompleteMediaTitle,
  createDvdMediaTitle,
} from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import {
  buildPreviewTranscodeArgs,
  isPreviewVideoCandidate,
  previewService,
} from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";

export const SOURCE_DIRECTORY_VALUE = "__source__";

async function sha256File(filePath: string): Promise<string | null> {
  return new Promise((resolve) => {
    const hash = createHash("sha256");
    const stream = fsSync.createReadStream(filePath);
    stream.on("data", (chunk) => hash.update(chunk));
    stream.on("error", () => resolve(null));
    stream.on("end", () => resolve(hash.digest("hex")));
  });
}

export async function describeFfmpegExecutable(
  executable: string,
): Promise<string> {
  const stat = await fs.stat(executable).catch(() => null);
  const sha256 = await sha256File(executable);
  const isAdmin =
    process.platform === "win32"
      ? (process.env.MEDIASCULPT_ADMINISTRATOR ??
          process.env.VX_AGENT_ADMINISTRATOR) === "1"
        ? "true"
        : "unknown"
      : typeof process.getuid === "function"
        ? String(process.getuid() === 0)
        : "unknown";
  return `path=${executable} size=${stat?.size ?? "unknown"} sha256=${sha256 ?? "unknown"} downloadSource=${process.env.MEDIASCULPT_FFMPEG_SOURCE ?? process.env.VX_AGENT_FFMPEG_SOURCE ?? "unknown"} installTime=${process.env.MEDIASCULPT_FFMPEG_INSTALL_TIME ?? process.env.VX_AGENT_FFMPEG_INSTALL_TIME ?? "unknown"} administrator=${isAdmin}`;
}

export function isSourceDirectoryValue(
  value: string | null | undefined,
): boolean {
  return value === SOURCE_DIRECTORY_VALUE;
}

export function sourceDirectoryForJob(job: {
  filePath: string;
  mainTrackPath?: string | null;
  mediaType?: string | null;
}): string {
  const sourcePath = job.mainTrackPath || job.filePath;
  if (
    job.mediaType === "dvd" ||
    job.mediaType === "bluray" ||
    job.mediaType === "iso"
  ) {
    return defaultRemuxOutputDirectory(sourcePath, job.mediaType);
  }
  return path.extname(sourcePath) ? path.dirname(sourcePath) : sourcePath;
}

export function resolveJobOutputDirectory(
  config: RuntimePathConfig,
  job: {
    filePath: string;
    mainTrackPath?: string | null;
    mediaType?: string | null;
    processingMode?: string | null;
  },
): string {
  if (
    isSourceDirectoryValue(config.outputDirectory) ||
    isSourceDirectoryValue(config.hostOutputPath)
  ) {
    return sourceDirectoryForJob(job);
  }
  return resolveOutputDir(config.outputDirectory || "", config);
}

export async function validateWritableDirectory(
  directory: string,
): Promise<void> {
  // 验证 Remux 输出目录：创建并写入临时文件后立即清理。
  await ensureDirectory(directory);
  const probe = path.join(
    directory,
    `.mediasculpt-write-test-${process.pid}-${Date.now()}`,
  );
  await fs.writeFile(probe, "ok", "utf8");
  await fs.rm(probe, { force: true });
}

export function outputDirectoryForTask(
  config: typeof configTable.$inferSelect,
  job: typeof jobsTable.$inferSelect,
): string {
  // ISO jobs read the disc from a temporary mounted drive; the snapshot's
  // sourcePath is that drive, which is read-only. Write the output next to
  // the ISO file instead.
  if (/\.iso$/i.test(job.filePath)) return sourceDirectoryForJob(job);
  const snapshot = loadTaskSnapshot(job);
  if (
    snapshot &&
    (snapshot.outputMode === "remux" ||
      snapshot.outputMode === "compress" ||
      snapshot.outputMode === "both")
  ) {
    const sourcePath = resolveRuntimePath(snapshot.sourcePath, config);
    return snapshot.output.directory === SOURCE_DIRECTORY_VALUE
      ? defaultRemuxOutputDirectory(sourcePath, snapshot.sourceType)
      : resolveRuntimePath(snapshot.output.directory, config);
  }
  return resolveJobOutputDirectory(config, job);
}

export function resolveJobSubtitleDirectory(
  config: RuntimePathConfig & { subtitleDirectory?: string | null },
  job: {
    filePath: string;
    mainTrackPath?: string | null;
    mediaType?: string | null;
  },
): string {
  // 字幕文件默认输出到视频源文件同目录；也支持用户在设置中显式选择“与源文件同目录”。
  if (
    !config.subtitleDirectory ||
    isSourceDirectoryValue(config.subtitleDirectory)
  ) {
    return sourceDirectoryForJob(job);
  }
  return resolveOutputDir(config.subtitleDirectory, config);
}

/** 确保目录存在；Windows 下对已存在的盘符根目录（如 F:\）mkdir 会返回 EPERM，而不是 EEXIST。 */
export async function ensureDirectory(directory: string): Promise<void> {
  try {
    await fs.mkdir(directory, { recursive: true });
  } catch (error) {
    try {
      const stat = await fs.stat(directory);
      if (stat.isDirectory()) return;
    } catch {
      // 路径不存在且 mkdir 失败时，继续抛出原始错误
    }
    throw error;
  }
}
