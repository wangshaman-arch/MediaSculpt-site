// Shared disc-analysis types, caching and source helpers.
import { createHash } from "node:crypto";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import fs from "node:fs/promises";
import type { Dirent } from "node:fs";
import os from "node:os";
import path from "node:path";
import { resolveDvdVideoTsDir } from "./disc";
import type {
  HandBrakeChapter,
  HandBrakeStream,
  HandBrakeTitle,
} from "./handbrake-scan";
import type { ExternalToolRunner } from "./dvd-remux";

export type DiscAnalysisInput = {
  sourcePath: string;
  mediaType: DiscMediaType;
  sourceFingerprint: string;
  handbrakeCliPath?: string | null;
  toolRunner?: ExternalToolRunner;
};
const execFileAsync = promisify(execFile);
const HANDBRAKE_SCAN_TIMEOUT_MS = 10 * 60_000;
const MAX_TOOL_BUFFER = 32 * 1024 * 1024;

export function safeNumber(value: unknown): number | null {
  const result = Number(value);
  return Number.isFinite(result) ? result : null;
}

export type DiscMediaType = "dvd" | "bluray";
export type DiscToolName = "handbrake" | "ffprobe";
export type DiscAnalysisTrackType = "video" | "audio" | "subtitle" | "unknown";

export type DiscAnalysisStream = {
  index: number;
  trackUid?: string;
  codecType: DiscAnalysisTrackType;
  codecName: string | null;
  /** ffprobe stream profile (e.g. "DTS-HD MA", "High 10") or null. */
  profile?: string | null;
  /** Tool-provided human description (e.g. HandBrake "DTS-HD MA, 5.1 ch"). */
  description?: string | null;
  language: string | null;
  title: string | null;
  width?: number | null;
  height?: number | null;
  channels?: number | null;
  channelLayout?: string | null;
  sampleRate?: number | null;
  bitrate?: number | null;
  estimatedSizeBytes?: number | null;
  bitsPerRawSample?: number | null;
  frameRate?: string | null;
  handbrakeTrackNumber?: number | null;
  default?: boolean;
  forced?: boolean;
};

export type DiscAnalysisChapter = {
  id: number;
  startSeconds: number;
  endSeconds: number;
  title: string | null;
};

export type DiscPhysicalRange = {
  path: string;
  startByte: number;
  endByte: number;
};

export type DiscToolDiagnostic = {
  tool: DiscToolName;
  executable: string | null;
  args: string[];
  startedAt: string;
  finishedAt: string;
  durationMs: number;
  exitCode: number | null;
  stdout: string;
  stderr: string;
  failureReason: string | null;
};

export type DiscToolDiagnosticSummary = Omit<
  DiscToolDiagnostic,
  "stdout" | "stderr"
> & {
  stdoutBytes: number;
  stderrBytes: number;
};

export type UnifiedDiscTitle = {
  titleId: string;
  titleUid?: string;
  titleIndex: number;
  sourcePath: string;
  /** Playlist-less m2ts fallback vs HandBrake-scan compression title. */
  titleKind?: "m2ts" | "handbrake" | null;
  /** File used to render preview frames when sourcePath is a disc root. */
  previewSourcePath?: string | null;
  /** Ordered Blu-ray stream segments with playlist-relative time ranges. */
  previewSegments?: DiscPreviewSegment[];
  displayName: string;
  durationSeconds: number | null;
  chapterCount: number;
  chapters: DiscAnalysisChapter[];
  videoTracks: DiscAnalysisStream[];
  audioTracks: DiscAnalysisStream[];
  subtitleTracks: DiscAnalysisStream[];
  estimatedSize: number | null;
  /** Exact physical VOB ranges proven by IFO/PGC/Cell navigation. */
  physicalRanges?: DiscPhysicalRange[];
  /** IFO/PGC duration and chapters must survive later stream verification. */
  dvdNavigationDurationSeconds?: number | null;
  dvdNavigationChapters?: DiscAnalysisChapter[];
  streams: DiscAnalysisStream[];
  toolMappings: {
    handbrakeTitleNumber: number | null;
    makemkvTitleIndex: number | null;
    playlistId?: string | null;
    /** Logical dvdvideo/HandBrake title number used for navigation and jobs. */
    dvdVtsNumber: number | null;
    /** Physical VTS file group, only when an exact IFO/PGC mapping is known. */
    physicalVtsNumber?: number | null;
  };
  mappingStatus: "not-required" | "unmapped";
  verificationStatus?: "pending" | "verified" | "failed";
  verificationFailureReason?: string | null;
  verificationWarnings?: string[];
  availabilityStatus?: "confirmed" | "unavailable";
  availabilityFailureReason?: string | null;
};

export type DiscPreviewSegment = {
  sourcePath: string;
  startSeconds: number;
  endSeconds: number;
};

/** Menus/stubs and ultra-short clips are noise for title selection. */
export const MIN_DISC_TITLE_SECONDS = 10;
/** Keep the main feature plus the most substantial extras. */
export const MAX_DISC_TITLES = 15;

/**
 * Consolidate a disc's title list so the user sees a usable set: drop menu
 * stubs/very short fragments, sort the longest (main) title first, and cap
 * the list so discs with dozens of HandBrake PGCs do not flood the UI.
 */
export function consolidateDiscTitles(
  titles: UnifiedDiscTitle[],
  log?: (message: string) => void,
  options?: { preserveAll?: boolean },
): UnifiedDiscTitle[] {
  const meaningful = titles.filter(
    (title) =>
      ((title.videoTracks?.length ?? 0) > 0 ||
        title.availabilityStatus === "unavailable") &&
      (title.durationSeconds ?? 0) >= MIN_DISC_TITLE_SECONDS,
  );
  const longestUnavailable = meaningful.reduce(
    (longest, title) =>
      title.availabilityStatus === "unavailable"
        ? Math.max(longest, title.durationSeconds ?? 0)
        : longest,
    0,
  );
  // If the only readable candidates are tiny clips while a much longer
  // playlist is known but unavailable, do not let a menu/preview clip appear
  // to be the main title. The unavailable playlist is the deterministic result
  // and carries the exact missing-file reason for the user.
  const hasDominantUnavailableTitle =
    longestUnavailable >= 600 &&
    meaningful.some((title) => title.availabilityStatus !== "unavailable") &&
    meaningful
      .filter((title) => title.availabilityStatus !== "unavailable")
      .every(
        (title) => (title.durationSeconds ?? 0) < longestUnavailable * 0.5,
      );
  const filtered = hasDominantUnavailableTitle
    ? meaningful.filter((title) => title.availabilityStatus === "unavailable")
    : meaningful;
  const sorted = filtered
    .slice()
    .sort((a, b) => (b.durationSeconds ?? 0) - (a.durationSeconds ?? 0));
  if (!options?.preserveAll && sorted.length > MAX_DISC_TITLES) {
    const dropped = sorted.length - MAX_DISC_TITLES;
    log?.(
      `已折叠 ${dropped} 个短片/碎片标题，仅保留最长的主片与主要花絮（共 ${MAX_DISC_TITLES} 个）`,
    );
    return sorted.slice(0, MAX_DISC_TITLES);
  }
  return sorted;
}

export type MakeMkvExportCandidate = {
  makemkvTitleIndex: number;
  name: string;
  sourcePath: string;
  estimatedSize: number | null;
  durationSeconds: number | null;
  mappedTitleId: string | null;
  mappingStatus: "not-required" | "unmapped";
};

export type HandBrakeDiscScanResult = {
  titles: Array<{
    handbrakeTitleNumber: number;
    sourcePath: string;
    estimatedSize: number | null;
    durationSeconds: number | null;
    streams: DiscAnalysisStream[];
    chapters: DiscAnalysisChapter[];
  }>;
};

export type DiscAnalysisResult = {
  analysisId: string;
  sourcePath: string;
  /** Original ISO file path when the analysis was created from an ISO image. */
  isoPath?: string;
  sourceFingerprint: string;
  /** Total bytes physically present under DVD VIDEO_TS; title sizes may overlap this payload. */
  sourceSizeBytes?: number | null;
  mediaType: DiscMediaType;
  createdAt: string;
  titles: UnifiedDiscTitle[];
  exportCandidates: MakeMkvExportCandidate[];
  diagnostics: DiscToolDiagnostic[];
  diagnosticLogPath: string | null;
  warnings: string[];
};

export type CachedDiscAnalysis<T> = {
  value: T;
  cached: boolean;
  shared: boolean;
};

type CacheEntry<T> = { value: T; createdAtMs: number };

export class DiscAnalysisCache<T> {
  private readonly entries = new Map<string, CacheEntry<T>>();
  private readonly inFlight = new Map<string, Promise<T>>();

  constructor(private readonly maxAgeMs = 5 * 60_000) {}

  async getOrAnalyze(
    input: { cacheKey: string; force: boolean },
    analyze: () => Promise<T>,
  ): Promise<CachedDiscAnalysis<T>> {
    const now = Date.now();
    const cached = this.entries.get(input.cacheKey);
    if (!input.force && cached && now - cached.createdAtMs <= this.maxAgeMs) {
      return { value: cached.value, cached: true, shared: false };
    }

    const active = this.inFlight.get(input.cacheKey);
    if (active) return { value: await active, cached: false, shared: true };

    const activeAnalysis = Promise.resolve().then(analyze);
    this.inFlight.set(input.cacheKey, activeAnalysis);
    try {
      const value = await activeAnalysis;
      this.entries.set(input.cacheKey, { value, createdAtMs: Date.now() });
      return { value, cached: false, shared: false };
    } finally {
      this.inFlight.delete(input.cacheKey);
    }
  }

  clear(): void {
    this.entries.clear();
  }
}

export function normalizeDiscSourcePath(sourcePath: string): string {
  const resolved = path.resolve(sourcePath);
  const base = path.basename(resolved).toUpperCase();
  return base === "VIDEO_TS" || base === "BDMV"
    ? path.dirname(resolved)
    : resolved;
}

export function buildDiscAnalysisId(input: {
  sourcePath: string;
  sourceFingerprint: string;
}): string {
  return `disc-${createHash("sha256")
    .update(
      `${normalizeDiscSourcePath(input.sourcePath).replace(/\\/g, "/").toLowerCase()}\n${input.sourceFingerprint}`,
    )
    .digest("hex")
    .slice(0, 24)}`;
}

export function buildDiscAnalysisCacheKey(input: {
  sourcePath: string;
  sourceFingerprint: string;
  mediaType: DiscMediaType;
}): string {
  return `${input.mediaType}:${buildDiscAnalysisId(input)}`;
}

export function buildFfprobeAnalysisArgs(
  sourcePath: string,
  inputArgs?: string[],
): string[] {
  return [
    "-v",
    "error",
    "-print_format",
    "json",
    "-show_streams",
    "-show_format",
    "-show_chapters",
    ...(inputArgs ?? [
      process.platform === "win32"
        ? sourcePath.replace(/\\/g, "/")
        : sourcePath,
    ]),
  ];
}

function toDiscStream(stream: HandBrakeStream): DiscAnalysisStream {
  return {
    index: stream.index,
    codecType: stream.codecType,
    codecName: stream.codecName,
    ...(stream.description ? { description: stream.description } : {}),
    language: stream.language ?? null,
    title: stream.title ?? null,
    ...("width" in stream
      ? {
          width: stream.width ?? null,
          height: stream.height ?? null,
          frameRate: stream.frameRate ?? null,
        }
      : {}),
    ...("bitrate" in stream
      ? {
          bitrate: (stream as { bitrate?: number | null }).bitrate ?? null,
          estimatedSizeBytes:
            "estimatedSizeBytes" in stream
              ? ((stream as { estimatedSizeBytes?: number | null })
                  .estimatedSizeBytes ?? null)
              : null,
        }
      : {}),
    ...("channels" in stream
      ? {
          channels: stream.channels ?? null,
          channelLayout: stream.channelLayout ?? null,
          sampleRate: stream.sampleRate ?? null,
          bitrate:
            "bitrate" in stream
              ? ((stream as { bitrate?: number | null }).bitrate ?? null)
              : null,
          estimatedSizeBytes:
            "estimatedSizeBytes" in stream
              ? ((stream as { estimatedSizeBytes?: number | null })
                  .estimatedSizeBytes ?? null)
              : null,
          bitsPerRawSample:
            "bitsPerRawSample" in stream
              ? ((stream as { bitsPerRawSample?: number | null })
                  .bitsPerRawSample ?? null)
              : null,
        }
      : {}),
    ...("handbrakeTrackNumber" in stream
      ? { handbrakeTrackNumber: stream.handbrakeTrackNumber ?? null }
      : {}),
  };
}

/**
 * Fill in per-stream size estimates when the tool result did not provide them:
 * known bitrates are multiplied by the title duration; a video stream without
 * bitrate approximates the whole title size (video dominates disc payloads).
 * Existing estimates are preserved.
 */
export function fillStreamSizeEstimates(
  streams: DiscAnalysisStream[],
  durationSeconds: number | null,
  estimatedTitleSize: number | null,
): DiscAnalysisStream[] {
  const estimates = streams.map((stream) => {
    if (stream.estimatedSizeBytes && stream.estimatedSizeBytes > 0)
      return stream.estimatedSizeBytes;
    if (stream.bitrate && durationSeconds)
      return Math.round((stream.bitrate * durationSeconds) / 8);
    return null;
  });
  const unknownVideoIndexes = streams
    .map((stream, index) =>
      stream.codecType === "video" && estimates[index] === null ? index : -1,
    )
    .filter((index) => index >= 0);
  const targetSize =
    estimatedTitleSize && estimatedTitleSize > 0
      ? Math.floor(estimatedTitleSize)
      : null;
  if (targetSize !== null && unknownVideoIndexes.length > 0) {
    const knownTotal = estimates.reduce<number>(
      (sum, value) => sum + (value ?? 0),
      0,
    );
    const remaining = Math.max(0, targetSize - knownTotal);
    const share = Math.floor(remaining / unknownVideoIndexes.length);
    let remainder = remaining - share * unknownVideoIndexes.length;
    for (const index of unknownVideoIndexes) {
      estimates[index] = share + (remainder > 0 ? 1 : 0);
      remainder -= 1;
    }
  }
  if (targetSize !== null) {
    const total = estimates.reduce<number>(
      (sum, value) => sum + (value ?? 0),
      0,
    );
    if (total > targetSize && total > 0) {
      // Bitrate metadata can describe a logical title more than once. Scale
      // the display-only estimates so their sum never exceeds the physical
      // title size supplied by the caller.
      let remaining = targetSize;
      estimates.forEach((value, index) => {
        if (value === null) return;
        const scaled =
          index === estimates.length - 1
            ? remaining
            : Math.floor((value * targetSize) / total);
        estimates[index] = Math.max(0, Math.min(remaining, scaled));
        remaining -= estimates[index] ?? 0;
      });
    }
  }
  return streams.map((stream, index) => {
    const estimate = estimates[index];
    if (estimate === null) return stream;
    return {
      ...stream,
      estimatedSizeBytes: estimate,
      ...(stream.codecType === "video" && !stream.bitrate && durationSeconds
        ? { bitrate: Math.round((estimate * 8) / durationSeconds) }
        : {}),
    };
  });
}

/** Measure the physical DVD payload once; logical titles are allowed to share these bytes. */
export async function measureDvdSourceBytes(
  sourcePath: string,
): Promise<number | null> {
  const videoTsDir = await resolveDvdVideoTsDir(sourcePath);
  if (!videoTsDir) return null;
  const entries = await fs
    .readdir(videoTsDir, { withFileTypes: true })
    .catch(() => [] as Dirent[]);
  let total = 0;
  for (const entry of entries) {
    if (!entry.isFile()) continue;
    const stat = await fs
      .stat(path.join(videoTsDir, entry.name))
      .catch(() => null);
    if (stat) total += stat.size;
  }
  return total > 0 ? total : null;
}

function toDiscChapters(chapters: HandBrakeChapter[]): DiscAnalysisChapter[] {
  return chapters.map((chapter) => ({
    id: chapter.id,
    startSeconds: chapter.startSeconds,
    endSeconds: chapter.endSeconds,
    title: chapter.title,
  }));
}

function handBrakeResult(
  sourcePath: string,
  titles: HandBrakeTitle[],
): HandBrakeDiscScanResult {
  return {
    titles: titles.map((title) => ({
      handbrakeTitleNumber: title.titleNumber,
      sourcePath,
      estimatedSize: null,
      durationSeconds: title.durationSeconds,
      streams: fillStreamSizeEstimates(
        title.streams.map(toDiscStream),
        title.durationSeconds,
        null,
      ),
      chapters: toDiscChapters(title.chapters),
    })),
  };
}

function splitTracks(streams: DiscAnalysisStream[]) {
  return {
    videoTracks: streams.filter((stream) => stream.codecType === "video"),
    audioTracks: streams.filter((stream) => stream.codecType === "audio"),
    subtitleTracks: streams.filter((stream) => stream.codecType === "subtitle"),
  };
}

export async function buildDiscSourceFingerprint(
  sourcePath: string,
  mediaType: DiscMediaType,
): Promise<string> {
  const root = normalizeDiscSourcePath(sourcePath);
  const discDir =
    mediaType === "dvd" ? path.join(root, "VIDEO_TS") : path.join(root, "BDMV");
  const entries = await fs
    .readdir(discDir, { withFileTypes: true })
    .catch((): Dirent[] => []);
  const relevant = entries
    .filter(
      (entry) =>
        entry.isFile() &&
        (mediaType === "dvd"
          ? /\.(ifo|bup|vob)$/i.test(entry.name)
          : /\.(mpls|bdmv)$/i.test(entry.name)),
    )
    .sort((a, b) => a.name.localeCompare(b.name));
  const parts = await Promise.all(
    relevant.map(async (entry) => {
      const stat = await fs.stat(path.join(discDir, entry.name));
      return `${entry.name}:${stat.size}:${Math.floor(stat.mtimeMs)}`;
    }),
  );
  return createHash("sha256")
    .update([root, mediaType, ...parts].join("\n"))
    .digest("hex");
}

export async function persistDiscAnalysisDiagnostics(
  analysisId: string,
  diagnostics: DiscToolDiagnostic[],
): Promise<string> {
  // Keep diagnostics under the current product profile; legacy VX-Agent logs
  // may still be read by migration tooling, but are never appended to.
  const directory = path.join(
    os.homedir(),
    ".MediaSculpt",
    "logs",
    "disc-analysis",
  );
  const logPath = path.join(directory, `${analysisId}.log`);
  const content = diagnostics
    .map((diagnostic) =>
      [
        `[${diagnostic.tool}] executable=${diagnostic.executable ?? "<unavailable>"}`,
        `started=${diagnostic.startedAt} finished=${diagnostic.finishedAt} durationMs=${diagnostic.durationMs} exitCode=${diagnostic.exitCode ?? "n/a"}`,
        `args=${JSON.stringify(diagnostic.args)}`,
        `failure=${diagnostic.failureReason ?? "<none>"}`,
        "--- stdout ---",
        diagnostic.stdout,
        "--- stderr ---",
        diagnostic.stderr,
        "",
      ].join("\n"),
    )
    .join("\n");
  await fs.mkdir(directory, { recursive: true });
  await fs.writeFile(logPath, content, "utf8");
  return logPath;
}

export function summarizeDiscDiagnostics(
  diagnostics: DiscToolDiagnostic[],
): DiscToolDiagnosticSummary[] {
  return diagnostics.map(({ stdout, stderr, ...diagnostic }) => ({
    ...diagnostic,
    stdoutBytes: Buffer.byteLength(stdout),
    stderrBytes: Buffer.byteLength(stderr),
  }));
}
