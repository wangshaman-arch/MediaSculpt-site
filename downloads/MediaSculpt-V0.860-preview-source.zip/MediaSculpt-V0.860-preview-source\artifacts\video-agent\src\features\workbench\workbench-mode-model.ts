import type { WorkbenchTab } from "../../hooks/useWorkbenchState";

export function modeTechnology(mode: WorkbenchTab): string {
  if (mode === "workflow") return "AI 辅助";
  if (mode === "compress") return "HandBrake";
  if (mode === "remux") return "FFmpeg（DVD / BD 播放列表）";
  return "Whisper / AI";
}
