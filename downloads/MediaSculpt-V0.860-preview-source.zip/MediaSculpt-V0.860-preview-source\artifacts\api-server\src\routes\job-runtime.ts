// Job queue/runtime wiring (runner, service, queue pump, snapshot gating).
// Extracted from routes/jobs.ts so the route entry is no longer the import hub.
import { db, jobsTable } from "@workspace/db";
import { eq, asc, sql } from "drizzle-orm";
import { addLog } from "../lib/job-logging";
import { assertPreviewTaskAllowed } from "../lib/preview-runtime";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import {
  loadTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
} from "../lib/task-snapshot";
import { requiresWorkflowSelection } from "../lib/job-workflow";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import {
  cancelledJobs,
  killJobProcesses,
  removeIncompleteJobOutputs,
  isQueuePaused,
} from "./jobs-tracking";
import { processJob } from "./job-orchestrator";

export async function validateTaskSnapshotBeforeStart(
  jobId: number,
): Promise<boolean> {
  const rows = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, jobId))
    .limit(1);
  const job = rows[0];
  if (!job) return false;
  try {
    await assertPreviewTaskAllowed();
  } catch (error) {
    if (isPreviewLimitError(error)) {
      await addLog(
        jobId,
        "warn",
        `任务启动被预览版限制阻止：${error.errorCode} ${error.message}`,
      );
      return false;
    }
    throw error;
  }
  try {
    const snapshot = loadTaskSnapshot(job);
    if (!snapshot) {
      await db
        .update(jobsTable)
        .set({
          status: "error",
          errorMessage: "旧任务没有不可变任务快照，请重新分析并创建任务",
          completedAt: new Date(),
        })
        .where(eq(jobsTable.id, jobId));
      await addLog(
        jobId,
        "error",
        "任务启动被阻止：legacy 任务没有不可变 taskSnapshot，未重新猜测默认标题或当前设置",
      );
      return false;
    }
    const summary = taskSnapshotSummary(snapshot);
    await addLog(
      jobId,
      "info",
      `任务快照校验通过：version=${summary.snapshotVersion} analysis=${summary.analysisId} title=${summary.selectedTitleId} mode=${summary.outputMode} sourceStrategy=${summary.compressionSourceStrategy} handbrake=${summary.handbrakeTitleNumber ?? "n/a"}`,
    );
    if (summary.outputMode !== (job.processingMode ?? null)) {
      await addLog(
        jobId,
        "warn",
        `计划不一致：快照 outputMode=${summary.outputMode}，任务记录 processingMode=${job.processingMode ?? "null"}，执行以快照为准`,
      );
    }
    return true;
  } catch (error) {
    const message =
      error instanceof TaskSnapshotError ? error.code : String(error);
    await db
      .update(jobsTable)
      .set({
        status: "error",
        errorMessage: `任务快照无效：${message}`,
        completedAt: new Date(),
      })
      .where(eq(jobsTable.id, jobId));
    await addLog(
      jobId,
      "error",
      `任务启动被阻止：taskSnapshot 校验失败 ${message}`,
    );
    return false;
  }
}

export async function runningJobStatuses(): Promise<string[]> {
  const rows = await db
    .select({ status: jobsTable.status })
    .from(jobsTable)
    .where(
      sql`${jobsTable.status} in ('scanning', 'transcribing', 'compressing', 'remuxing')`,
    );
  return rows.map((row: { status: string }) => row.status);
}

export const jobRunner = new JobRunner({
  getRunningStatuses: runningJobStatuses,
  validateBeforeStart: validateTaskSnapshotBeforeStart,
  start: async (jobId) => {
    await db
      .update(jobsTable)
      .set({
        status: "scanning",
        startedAt: new Date(),
        progress: 0,
        currentFps: null,
        avgFps: null,
        etaSeconds: null,
        errorMessage: null,
      })
      .where(eq(jobsTable.id, jobId));
    processJob(jobId).catch(async (error: unknown) => {
      // 兜底：processJob 的顶层异常（准备阶段抛错、未进入内部 try/finally）过去被
      // `.catch(() => {})` 静默吞掉，任务会永远停在 scanning → 队列被判定为"有活跃
      // 任务"而永久死锁。这里把任务标记为 error 并推进队列。
      const message = error instanceof Error ? error.message : String(error);
      try {
        await db
          .update(jobsTable)
          .set({
            status: "error",
            errorMessage: message,
            completedAt: new Date(),
          })
          .where(eq(jobsTable.id, jobId));
        await addLog(jobId, "error", `任务执行异常：${message}`).catch(
          () => {},
        );
      } catch {
        /* best effort */
      }
      await startNextPendingJob().catch(() => {});
    });
  },
  findNextPending: async () => {
    const rows = await db
      .select({ id: jobsTable.id })
      .from(jobsTable)
      .where(eq(jobsTable.status, "pending"))
      .orderBy(asc(jobsTable.createdAt))
      .limit(1);
    return rows[0]?.id ?? null;
  },
  logQueued: (jobId) =>
    addLog(jobId, "info", "任务已加入顺序队列，等待当前任务完成后自动开始"),
  logNextPending: (jobId) =>
    addLog(jobId, "info", "顺序队列：前一个任务已结束，开始当前任务"),
});

export const jobService = new JobService<typeof jobsTable.$inferSelect>({
  findById: async (jobId) => {
    const rows = await db
      .select()
      .from(jobsTable)
      .where(eq(jobsTable.id, jobId))
      .limit(1);
    return rows[0] ?? null;
  },
  update: async (jobId, patch) => {
    await db
      .update(jobsTable)
      .set(patch as Partial<typeof jobsTable.$inferInsert>)
      .where(eq(jobsTable.id, jobId));
  },
  startWhenIdle: startJobWhenQueueIdle,
  requiresWorkflowSelection,
  markCancelled: (jobId) => cancelledJobs.add(jobId),
  killProcesses: killJobProcesses,
  clearCancelled: (jobId) => cancelledJobs.delete(jobId),
  removeIncompleteOutputs: (jobId) => removeIncompleteJobOutputs(jobId),
  addLog,
  assertPreviewTaskAllowed,
});

export function startJobWhenQueueIdle(jobId: number): Promise<boolean> {
  return jobRunner.startWhenIdle(jobId);
}

export async function startNextPendingJob(): Promise<void> {
  await jobRunner.startNextPending(isQueuePaused());
}
