import type { DiscStream } from "@workspace/api-client-react";
import type {
  ProcessingMode,
  SubtitleMode,
} from "../../hooks/useWorkbenchState";
import type { BatchItem } from "../../pages/BatchConfirmPage";
import { isDirectM2tsTitle } from "../../pages/scan-model";
import {
  handBrakeTrackNumbers,
  type DiscTrackWithMakeMkv,
} from "./disc-display-model";
import { canCreateDiscJobsWithMode } from "./disc-job-mode-model";

export type DiscJobOutputMode = "remux" | "compress" | "whisper" | "subtitle";

export function discOutputMode(
  processingMode: ProcessingMode,
  subtitleMode: SubtitleMode,
): DiscJobOutputMode {
  if (processingMode === "remux") return "remux";
  if (processingMode === "compress") return "compress";
  return subtitleMode === "whisper" || subtitleMode === "transcribe_translate"
    ? "whisper"
    : "subtitle";
}

export function buildDiscSelectionPlan(input: {
  track: DiscTrackWithMakeMkv;
  streamSet: Set<number>;
  chapterIds: number[];
  smartManifestId: string | null;
  analysisId: string | null;
}): string {
  const { track, streamSet, chapterIds, smartManifestId, analysisId } = input;
  const handbrakeTitleNumber =
    typeof track.handbrakeTitleNumber === "number" &&
    track.handbrakeTitleNumber > 0
      ? track.handbrakeTitleNumber
      : null;
  return JSON.stringify({
    version: 1,
    smartManifestId,
    analysis: {
      analysisId: analysisId ?? null,
      titleId: track.titleId ?? null,
      titleIndex:
        typeof track.titleIndex === "number" ? track.titleIndex : null,
      mappingStatus: track.mappingStatus ?? "not-required",
    },
    video: track.streams
      .filter((s) => s.codecType === "video" && streamSet.has(s.index))
      .map((s) => s.index),
    audio: track.streams
      .filter((s) => s.codecType === "audio" && streamSet.has(s.index))
      .map((s) => s.index),
    audioStreams: track.streams
      .filter((s) => s.codecType === "audio" && streamSet.has(s.index))
      .map((s) => ({
        inputIndex: s.index,
        codecName: s.codecName ?? null,
        bitsPerRawSample:
          (s as typeof s & { bitsPerRawSample?: number | null })
            .bitsPerRawSample ?? null,
      })),
    subtitle: track.streams
      .filter((s) => s.codecType === "subtitle" && streamSet.has(s.index))
      .map((s) => s.index),
    chapters: chapterIds,
    handbrake: {
      titleNumber: handbrakeTitleNumber,
      titleSizeBytes: track.sizeBytes ?? null,
      durationSeconds: track.durationSeconds ?? null,
      audioTrackNumbers: handBrakeTrackNumbers(track, streamSet, "audio"),
      subtitleTrackNumbers: handBrakeTrackNumbers(track, streamSet, "subtitle"),
      chapterNumbers: chapterIds.map((id) => id + 1),
    },
    playlistId: track.playlistId ?? null,
    dvdvideo: {
      titleNumber: track.dvdVtsNumber ?? null,
      verified: track.verificationStatus === "verified",
    },
    analyzer: track.analyzer ?? "unified",
  });
}

export function buildDiscBatchItems(input: {
  discPath: string;
  discType: "dvd" | "bluray";
  analysisId?: string | null;
  sourceFingerprint?: string | null;
  selectedTrackIndices: Iterable<number>;
  getTrack: (idx: number) => DiscTrackWithMakeMkv | undefined;
  getStreamSelection: (idx: number) => Set<number> | undefined;
  getChapterSelection: (idx: number) => Set<number> | undefined;
  defaultStreamSelection: (track: DiscTrackWithMakeMkv) => Set<number>;
  defaultChapterSelection: (track: DiscTrackWithMakeMkv) => Set<number>;
}): BatchItem[] {
  return Array.from(input.selectedTrackIndices)
    .sort((a, b) => a - b)
    .map((trackIdx): BatchItem | null => {
      const track = input.getTrack(trackIdx);
      if (!track) return null;
      const streamSet =
        input.getStreamSelection(trackIdx) ??
        input.defaultStreamSelection(track);
      const chapterSet =
        input.getChapterSelection(trackIdx) ??
        input.defaultChapterSelection(track);
      return {
        key: `${input.discPath}::${track.titleId ?? trackIdx}`,
        path: input.discPath,
        kind: input.discType === "bluray" ? "bluray" : "dvd",
        label: track.name ?? `Title ${track.titleIndex ?? trackIdx + 1}`,
        durationSeconds: track.durationSeconds ?? null,
        titleId: track.titleId ?? null,
        analysisId: input.analysisId ?? null,
        sourceFingerprint: input.sourceFingerprint ?? null,
        handbrakeTitleNumber: track.handbrakeTitleNumber ?? null,
        playlistId: track.playlistId ?? null,
        mappingStatus: track.mappingStatus ?? null,
        verificationStatus: track.verificationStatus ?? null,
        dvdVtsNumber: track.dvdVtsNumber ?? null,
        streams: track.streams.map((stream) => ({
          index: stream.index,
          codecType: stream.codecType,
          codecName: stream.codecName ?? null,
          language: stream.language ?? null,
          channels: stream.channels ?? null,
          width: stream.width ?? null,
          height: stream.height ?? null,
          frameRate:
            (stream as DiscStream & { frameRate?: string | number | null })
              .frameRate ?? null,
        })),
        chapterCount: track.chapters?.length ?? 0,
        selectedStreamIndices: Array.from(streamSet).sort((a, b) => a - b),
        selectedChapterIds: Array.from(chapterSet).sort((a, b) => a - b),
        preview: null,
      };
    })
    .filter((item): item is BatchItem => item !== null);
}

type RunningJob = {
  status?: string | null;
  processingMode?: string | null;
  taskSnapshot?: string | null;
};

export function hasRunningRemuxDuplicate(
  jobs: RunningJob[] | undefined,
  track: { titleId?: string; path: string },
): boolean {
  return (jobs ?? []).some((job) => {
    if (
      !["pending", "scanning", "transcribing", "compressing"].includes(
        job.status ?? "",
      )
    )
      return false;
    if (job.processingMode !== "remux") return false;
    try {
      const snapshot = JSON.parse(job.taskSnapshot ?? "{}") as {
        selectedTitleId?: string;
        sourcePath?: string;
      };
      return (
        snapshot.selectedTitleId === track.titleId &&
        snapshot.sourcePath?.replace(/\\/g, "/").toLowerCase() ===
          track.path.replace(/\\/g, "/").toLowerCase()
      );
    } catch {
      return false;
    }
  });
}

export function canCreateDiscJobSelection(input: {
  allowJobCreation: boolean;
  hasData: boolean;
  processingMode: ProcessingMode;
  subtitleMode: SubtitleMode;
  selectedTitleCount: number;
  creating: boolean;
  remuxBlocked: boolean;
  discType: "dvd" | "bluray";
  selectedTracks: Array<{
    track: DiscTrackWithMakeMkv;
    selectedStreams: Set<number>;
    duplicate: boolean;
  }>;
}): boolean {
  if (
    !(
      input.allowJobCreation &&
      input.hasData &&
      canCreateDiscJobsWithMode({
        processingMode: input.processingMode,
        subtitleMode: input.subtitleMode,
        selectedTitleCount: input.selectedTitleCount,
      }) &&
      !input.creating &&
      !input.remuxBlocked
    )
  )
    return false;
  return input.selectedTracks.every(({ track, selectedStreams, duplicate }) => {
    if (track.availabilityStatus === "unavailable") return false;
    if (
      input.processingMode === "remux" &&
      input.discType === "dvd" &&
      (track.verificationStatus !== "verified" ||
        typeof track.dvdVtsNumber !== "number" ||
        track.streams.every((stream) => stream.codecType !== "video"))
    )
      return false;
    if (
      input.processingMode === "remux" &&
      input.discType !== "dvd" &&
      !isDirectM2tsTitle(track) &&
      (typeof track.playlistId !== "string" ||
        track.mappingStatus === "unmapped")
    )
      return false;
    if (input.processingMode === "remux" && duplicate) return false;
    if (
      input.processingMode === "compress" &&
      (typeof track.handbrakeTitleNumber !== "number" ||
        track.handbrakeTitleNumber <= 0)
    )
      return false;
    const requiredTypes =
      input.processingMode === "none" ? ["audio", "subtitle"] : ["video"];
    return track.streams.some(
      (stream) =>
        requiredTypes.includes(stream.codecType) &&
        selectedStreams.has(stream.index),
    );
  });
}
