import { ChevronDown, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import type {
  AssistantPreferences,
  AiGenerateOptions,
  ProcessingStep,
} from "../AssistantPanel";
import { AssistantChip } from "./AssistantChip";
import { DEFAULT_STEP_ORDER } from "./assistant-panel-model";

type Translate = (
  path: string,
  params?: Record<string, string | number>,
) => string;

export function AssistantModesColumn({
  t,
  aiAvailable,
  gen,
  generateOpen,
  setGenerateOpen,
  toggleGen,
  prefs,
  dragIndex,
  setDragIndex,
  allowRemux,
  allowChapterPreview,
  processingLocked,
  toggleProcessing,
  moveProcessing,
  stepLabel,
}: {
  t: Translate;
  aiAvailable: boolean;
  gen: AiGenerateOptions;
  generateOpen: boolean;
  setGenerateOpen: (open: boolean) => void;
  toggleGen: (key: keyof AiGenerateOptions) => void;
  prefs: AssistantPreferences;
  dragIndex: number | null;
  setDragIndex: (index: number | null) => void;
  allowRemux: boolean;
  allowChapterPreview: boolean;
  processingLocked: boolean;
  toggleProcessing: (step: ProcessingStep) => void;
  moveProcessing: (from: number, to: number) => void;
  stepLabel: (step: ProcessingStep) => string;
}) {
  return (
    <div
      className={cn(
        "ml-auto flex shrink-0 flex-col justify-center gap-1",
        "ml-0 w-full min-w-0",
      )}
    >
      {generateOpen ? (
        <div
          className={cn(
            "flex items-center gap-1",
            "flex-nowrap overflow-x-auto",
          )}
          data-testid="assistant-generate-bar"
        >
          <button
            type="button"
            onClick={() => setGenerateOpen(false)}
            aria-expanded
            data-testid="assistant-generate-toggle"
            className="flex shrink-0 items-center gap-1 whitespace-nowrap text-[10px] font-medium text-amber-400"
          >
            <span className="whitespace-nowrap">
              {t("assistant.generateLabel")}
            </span>
            <ChevronDown className="h-3 w-3 shrink-0" />
          </button>
          {(
            ["generateReadme", "generatePoster", "generateReview"] as const
          ).map((key) => (
            <AssistantChip
              key={key}
              amber={aiAvailable}
              disabled={key === "generateReview" && !aiAvailable}
              title={
                aiAvailable
                  ? undefined
                  : key === "generateReview"
                    ? t("assistant.aiNeedsKey")
                    : t(
                        key === "generateReadme"
                          ? "assistant.readmeFallbackHint"
                          : "assistant.posterFallbackHint",
                      )
              }
              active={gen[key]}
              label={t(
                `assistant.generate${key === "generateReadme" ? "Readme" : key === "generatePoster" ? "Poster" : "Review"}`,
              )}
              onClick={() => toggleGen(key)}
              className="grow px-1.5 text-center"
            />
          ))}
        </div>
      ) : (
        <button
          type="button"
          onClick={() => setGenerateOpen(true)}
          aria-expanded={false}
          data-testid="assistant-generate-toggle"
          title={t("assistant.generateLabel")}
          className="flex h-4 w-4 shrink-0 items-center justify-center self-end rounded text-amber-400/70 transition-colors hover:bg-amber-400/10 hover:text-amber-400"
        >
          <ChevronRight className="h-3.5 w-3.5" />
        </button>
      )}
      {generateOpen && <div className="h-px w-full bg-border/70" />}
      <div
        className={cn("flex items-center gap-1", "flex-nowrap overflow-x-auto")}
      >
        <span className="w-14 shrink-0 text-[10px] text-muted-foreground">
          {t("assistant.processingField")}
        </span>
        {DEFAULT_STEP_ORDER.map((step) => {
          const selected = prefs.processing.includes(step);
          const stepIndex = prefs.processing.indexOf(step);
          const remuxDisabled = step === "remux" && !allowRemux;
          const chapterPreviewDisabled =
            step === "chapterPreview" && !allowChapterPreview;
          const optionDisabled =
            processingLocked || remuxDisabled || chapterPreviewDisabled;
          // A confirmed mode is immutable, but the selected chip must
          // remain visibly active. Only alternative modes use the muted
          // disabled treatment; otherwise the whole assistant appears
          // unavailable after the user confirms the disc mode.
          const visuallyDisabled =
            (processingLocked && !selected) ||
            remuxDisabled ||
            chapterPreviewDisabled;
          return (
            <button
              key={step}
              type="button"
              disabled={optionDisabled}
              draggable={selected && !processingLocked}
              onDragStart={(event) => {
                if (stepIndex < 0) return;
                setDragIndex(stepIndex);
                event.dataTransfer.effectAllowed = "move";
              }}
              onDragOver={(event) => {
                if (selected && dragIndex !== null) event.preventDefault();
              }}
              onDrop={(event) => {
                event.preventDefault();
                if (dragIndex !== null && stepIndex >= 0)
                  moveProcessing(dragIndex, stepIndex);
              }}
              onDragEnd={() => setDragIndex(null)}
              onClick={() => toggleProcessing(step)}
              className={cn(
                "relative flex h-7 shrink-0 items-center gap-1 rounded-md border px-2.5 text-[11px] leading-none transition-colors",
                "grow justify-center px-1.5",
                visuallyDisabled
                  ? "cursor-not-allowed border-border/40 text-muted-foreground/40"
                  : selected
                    ? "border-blue-500 bg-blue-500/15 text-blue-400"
                    : "border-blue-500/40 text-muted-foreground hover:border-blue-400 hover:bg-blue-500/10 hover:text-foreground",
              )}
              title={
                processingLocked
                  ? t("assistant.processingLocked")
                  : chapterPreviewDisabled
                    ? t("assistant.chapterPreviewUnavailable")
                    : step === "chapterPreview"
                      ? t("assistant.chapterPreviewSeparateTask")
                      : selected
                        ? t("assistant.dragToReorder")
                        : undefined
              }
            >
              <span className="whitespace-nowrap">{stepLabel(step)}</span>
              {selected && (
                <span className="absolute -right-1 -top-1 flex h-3.5 min-w-3.5 items-center justify-center rounded-full bg-blue-500 px-0.5 font-mono text-[9px] leading-none text-white">
                  {stepIndex + 1}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
