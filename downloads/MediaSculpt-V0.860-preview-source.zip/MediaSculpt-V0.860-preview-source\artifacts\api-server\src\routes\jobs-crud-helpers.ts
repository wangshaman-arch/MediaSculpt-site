// Extracted from routes/jobs-crud.ts: job creation helpers.
import { Router } from "express";
import os from "os";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import {
  CreateJobBody,
  ListJobsQueryParams,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
  ScanDirectoryBody,
} from "@workspace/api-zod";
import {
  createStandaloneTaskSnapshotV1,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotSettings,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  defaultRemuxOutputDirectory,
  normalizeRequestedProcessingMode,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import {
  buildCompressionOutputName,
  buildRemuxOutputName,
  encoderBitDepth,
} from "../lib/output-naming";
import { cleanupPreviewSegments } from "../lib/preview-segments";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import { assertPreviewTaskAllowed } from "../lib/preview-runtime";
import {
  normalizeDiscSourcePath,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import { assessDiscComplexity } from "../lib/disc-complexity";
import {
  buildDvdStructurePayload,
  resolveRemuxPlanWithLlm,
  validateRemuxPlan,
} from "../lib/dvd-llm";
import { buildSourceManifest } from "../lib/source-manifest";
import { normalizeTitleEn } from "../lib/metadata";
import { resolveDvdVideoTsDir } from "../lib/disc";
import { resolveRuntimePath } from "../lib/runtime-paths";
import { resolveToolPath } from "../lib/tool-runtime";
import { appendRuntimeToolLog } from "../lib/runtime-tool-log";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { verifyDvdTitle } from "../lib/dvd-remux";
import { addLog } from "../lib/job-logging";
import { discAnalysisRegistry } from "../lib/disc-analysis-registry";
import { isBlurayDisc, isDvdDisc, resolveMainTrack } from "../lib/disc";
import { settlePreviewTaskSafely } from "../lib/preview-runtime";
import { VIDEO_EXTENSIONS } from "../lib/media-extensions";
import {
  blockedReasonMessage,
  defaultTaskSnapshotOutputMode,
  normalizePipelineSteps,
  parsePipelineNames,
  parsePipelineSteps,
  parseTaskSnapshotIndexArray,
  validateJobViability,
} from "./jobs-pipeline";
import {
  cancelledJobs,
  clearJobOutputFiles,
  isQueuePaused,
  killJobProcesses,
  setQueuePaused,
  trackJobOutputFile,
} from "./jobs-tracking";
import {
  jobRunner,
  jobService,
  runningJobStatuses,
  startJobWhenQueueIdle,
  startNextPendingJob,
  validateTaskSnapshotBeforeStart,
} from "./job-runtime";
import {
  outputDirectoryForTask,
  resolveJobOutputDirectory,
  resolveJobSubtitleDirectory,
  SOURCE_DIRECTORY_VALUE,
  validateWritableDirectory,
} from "./jobs-output-paths";
import { dvdVideoInputPath } from "./jobs-dvd";
import { ensureAnalysisIsoReady } from "./jobs-iso";
import { getConfig } from "./jobs-config";
import { snapshotTitleIndex } from "./jobs-ffmpeg-run";

export function requestedWorkflowOutputFileName(
  selectionPlan: string | null | undefined,
): string | null {
  if (!selectionPlan) return null;
  try {
    const parsed = JSON.parse(selectionPlan) as {
      workflow?: unknown;
      outputName?: unknown;
    };
    if (
      parsed.workflow !== "smart-workflow-v1" ||
      typeof parsed.outputName !== "string"
    )
      return null;
    const name = parsed.outputName.trim();
    if (
      !name ||
      name === "." ||
      name === ".." ||
      /[\\/\x00-\x1f]/.test(name) ||
      name.includes("..")
    )
      return null;
    return name;
  } catch {
    return null;
  }
}

/**
 * 复杂光碟（结构含糊/多义）在创建 remux 任务时，把真实结构推给 LLM，得到校验后的流选择。
 * 仅在 LLM 方案通过真实流校验且与用户所选标题一致时生效；任何失败一律返回 `plan:null`（回退确定性路径）。
 * `forceSmartRemux` 为 true 时无条件启用（供"智能解析"按钮强制）；outcome 描述结果供前端展示。
 */
export async function resolveLlmRemuxPlanForCreate(input: {
  analysis: DiscAnalysisResult | null | undefined;
  selectedTitleId: string;
  outputMode: string;
  config: Awaited<ReturnType<typeof getConfig>>;
  forceSmartRemux?: boolean;
}): Promise<{
  plan: NonNullable<TaskSnapshotJobCreationRequest["llmRemuxPlan"]> | null;
  outcome: { invoked: boolean; applied: boolean; reason?: string };
}> {
  const analysis = input.analysis;
  const outcome = {
    invoked: false,
    applied: false,
    reason: undefined as string | undefined,
  };
  if (!analysis || !input.selectedTitleId) return { plan: null, outcome };
  if (input.outputMode !== "remux" || analysis.mediaType !== "dvd")
    return { plan: null, outcome };

  const verdict = assessDiscComplexity(analysis);
  if (!input.forceSmartRemux && !verdict.complex)
    return { plan: null, outcome };
  outcome.invoked = true;
  await appendRuntimeToolLog(
    `当前光碟${input.forceSmartRemux ? "（用户强制）" : "结构复杂"}，交由 AI 解析 remux 方案：${verdict.reasons.slice(0, 3).join("；") || "用户强制智能解析"}`,
  ).catch(() => {});

  const structure = buildDvdStructurePayload(analysis);
  let raw;
  try {
    raw = await resolveRemuxPlanWithLlm({ structure, config: input.config });
  } catch (error) {
    outcome.reason = `AI 解析失败：${error instanceof Error ? error.message : String(error)}`;
    await appendRuntimeToolLog(`${outcome.reason}（已回退确定性解析）`).catch(
      () => {},
    );
    return { plan: null, outcome };
  }
  if (!raw) {
    outcome.reason = "AI 未给出有效 remux 方案";
    await appendRuntimeToolLog(`${outcome.reason}（已回退确定性解析）`).catch(
      () => {},
    );
    return { plan: null, outcome };
  }

  const validated = validateRemuxPlan(raw, analysis);
  if (!validated.ok || !validated.plan || validated.plan.videoIndex === null) {
    outcome.reason = `AI 方案未通过真实流校验：${validated.reason ?? "未知"}`;
    await appendRuntimeToolLog(`${outcome.reason}（已回退确定性解析）`).catch(
      () => {},
    );
    return { plan: null, outcome };
  }
  if (validated.plan.titleId !== input.selectedTitleId) {
    outcome.reason = `AI 建议标题 ${validated.plan.titleId} 与所选 ${input.selectedTitleId} 不同，保留用户选择`;
    await appendRuntimeToolLog(`${outcome.reason}（不静默切换）`).catch(
      () => {},
    );
    return { plan: null, outcome };
  }

  outcome.applied = true;
  await appendRuntimeToolLog(
    `AI remux 方案生效：标题=${validated.plan.titleId} 视频=${validated.plan.videoIndex} 音频=[${validated.plan.audioIndices.join(", ")}] 字幕=[${validated.plan.subtitleIndices.join(", ")}]（${validated.plan.confidence}）${validated.plan.reason ? "：" + validated.plan.reason : ""}`,
  ).catch(() => {});
  return {
    plan: {
      videoIndex: validated.plan.videoIndex,
      audioIndices: validated.plan.audioIndices,
      subtitleIndices: validated.plan.subtitleIndices,
      reason: validated.plan.reason,
    },
    outcome,
  };
}

// Extracted from routes/jobs-crud.ts: reconcile a stored overview with the authoritative IMDb id.
export function reconcileMovieOverview(
  raw: string | null,
  imdbId: string | null,
): string | null {
  if (!raw && !imdbId) return null;
  let lines = (raw ?? "").split(/\r?\n/);
  const contentIndex = lines.findIndex((line) =>
    /^\s*(内容简介|简介|overview)\s*[:：]/i.test(line),
  );
  if (contentIndex >= 0) lines = lines.slice(contentIndex + 1);
  const cleaned = lines
    .filter((line) => !/^\s*IMDBID\s*=/i.test(line))
    .filter((line) => !/^\s*IMDb\s*(?:编号|ID|评分)?\s*[:：=]/i.test(line))
    .filter((line) => !/^\s*豆瓣评分\s*[:：=]/i.test(line))
    .filter((line) => !/^\s*主创\s*[:：]?\s*$/i.test(line))
    .filter((line) => !/待确认|未检索到|未找到|未知|N\/?A/i.test(line))
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  if (!imdbId) return cleaned || null;
  const authoritative = `IMDb 编号：${imdbId}`;
  return cleaned ? `${cleaned}\n${authoritative}` : authoritative;
}
