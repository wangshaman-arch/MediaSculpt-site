import { Converter } from "opencc-js";

let t2sConverter: ((input: string) => string) | null = null;

/**
 * 繁体中文 → 简体中文 的确定性转换（不依赖 LLM 自觉）。
 * 用于所有 .zhs 字幕输出前的最终兜底，保证简体承诺在任何模型输出下都成立。
 */
export function toSimplifiedChinese(input: string): string {
  if (!t2sConverter) {
    t2sConverter = Converter({ from: "t", to: "cn" });
  }
  return t2sConverter(input);
}
