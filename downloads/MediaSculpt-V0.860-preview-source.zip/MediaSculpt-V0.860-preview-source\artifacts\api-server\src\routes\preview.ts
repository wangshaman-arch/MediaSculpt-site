import { Router } from "express";
import { getPreviewStatus } from "../lib/preview-runtime";

const router = Router();

router.get("/preview/status", async (_req, res) => {
  try {
    return res.json(await getPreviewStatus());
  } catch (error) {
    return res.status(503).json({
      errorCode: "PREVIEW_STATUS_UNAVAILABLE",
      error: `预览版状态不可用：${error instanceof Error ? error.message : String(error)}`,
    });
  }
});

export default router;
