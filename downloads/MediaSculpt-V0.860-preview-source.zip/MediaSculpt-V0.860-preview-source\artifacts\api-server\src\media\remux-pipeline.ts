import path from "node:path";
import { buildDvdRemuxArgs } from "../lib/dvd-remux";
import { ffmpegPath } from "../lib/runtime-paths";
import type { MediaPipelineManifest } from "./media-pipeline-contract";
import { buildDvdRemuxRequestFromManifest } from "./remux-service";

export type RemuxInputMode = "dvd-navigation" | "concat" | "file";

export type RemuxCommandPlan = Readonly<{
  executable: string;
  args: readonly string[];
  outputPath: string;
  temporaryInputs: readonly string[];
  expected: Readonly<{
    video: number;
    audio: number;
    subtitle: number;
    chapters: number;
    durationSeconds: number | null;
  }>;
}>;

export function buildRemuxCommandPlan(input: {
  manifest: MediaPipelineManifest;
  executable: string;
  inputMode: RemuxInputMode;
  concatListPath?: string;
  chapterMetadataPath?: string;
}): RemuxCommandPlan {
  const { manifest } = input;
  if (manifest.output.mode !== "remux") throw new Error("输出模式必须是 remux");
  const outputPath = path.join(
    manifest.output.directory,
    manifest.output.fileName,
  );
  const temporaryInputs = [
    input.concatListPath,
    input.chapterMetadataPath,
  ].filter((value): value is string => Boolean(value));
  const expected = {
    video: manifest.selection.videoStreamIds.length,
    audio: manifest.selection.audioStreamIds.length,
    subtitle: manifest.selection.subtitleStreamIds.length,
    chapters: manifest.selection.chapterIds.length,
    durationSeconds: manifest.title.durationSeconds,
  };

  if (input.inputMode === "dvd-navigation") {
    if (manifest.source.kind !== "dvd" && manifest.source.kind !== "iso") {
      throw new Error("dvd-navigation 只接受 DVD 文件夹或 ISO 来源");
    }
    // The caller supplies the already-resolved `dvdvideo` input path in
    // `manifest.source.path` (see `resolveDvdVideoInputPath`), so the planner
    // passes it through verbatim. This keeps the generated command byte-for-byte
    // identical to the legacy route instead of re-normalizing the path here.
    const request = buildDvdRemuxRequestFromManifest({
      manifest,
      executable: input.executable,
    });
    const args = buildDvdRemuxArgs(request);
    if (input.chapterMetadataPath) {
      const chapterIndex = args.indexOf("-map_chapters");
      if (chapterIndex < 0) throw new Error("DVD Remux 未生成章节映射参数");
      const firstMapIndex = args.indexOf("-map");
      if (firstMapIndex < 0) throw new Error("DVD Remux 未生成流轨映射参数");
      const chapterMetadataInputIndex = args
        .slice(0, firstMapIndex)
        .filter((arg) => arg === "-i").length;
      args.splice(
        chapterIndex,
        2,
        "-map_metadata",
        String(chapterMetadataInputIndex),
        "-map_chapters",
        String(chapterMetadataInputIndex),
      );
      // Declare ffmeta after all media inputs but before output mappings. DVD
      // subtitle isolation adds a second dvdvideo input, so its index is
      // counted rather than assumed to be 1.
      args.splice(
        firstMapIndex,
        0,
        "-i",
        ffmpegPath(input.chapterMetadataPath),
      );
    }
    return Object.freeze({
      executable: input.executable,
      args: Object.freeze(args),
      outputPath,
      temporaryInputs: Object.freeze(temporaryInputs),
      expected: Object.freeze(expected),
    });
  }

  if (input.inputMode === "concat") {
    if (!input.concatListPath) throw new Error("缺少 concat 输入清单");
    // Byte-for-byte match with the legacy Blu-ray route
    // (`buildLosslessRemuxArgs`): concat input, optional chapter-metadata input,
    // then per-stream maps with copy (pcm_bluray → pcm_s24le), `-fflags +genpts`.
    const args = [
      "-f",
      "concat",
      "-safe",
      "0",
      "-i",
      ffmpegPath(input.concatListPath),
      ...(input.chapterMetadataPath
        ? ["-i", input.chapterMetadataPath, "-map_chapters", "1"]
        : []),
      "-dn",
      "-ignore_unknown",
      "-avoid_negative_ts",
      "make_zero",
      ...perStreamMapCodecArgs(manifest),
      "-fflags",
      "+genpts",
      "-y",
      outputPath,
    ];
    return Object.freeze({
      executable: input.executable,
      args: Object.freeze(args),
      outputPath,
      temporaryInputs: Object.freeze(temporaryInputs),
      expected: Object.freeze(expected),
    });
  }

  // Direct-file input (Blu-ray playlist-less m2ts fallback), matching the
  // legacy `buildLosslessRemuxArgs` invocation as well.
  const args = [
    "-i",
    ffmpegPath(manifest.source.path),
    ...(input.chapterMetadataPath
      ? ["-i", input.chapterMetadataPath, "-map_chapters", "1"]
      : []),
    "-dn",
    "-ignore_unknown",
    "-avoid_negative_ts",
    "make_zero",
    ...perStreamMapCodecArgs(manifest),
    "-fflags",
    "+genpts",
    "-y",
    outputPath,
  ];
  return Object.freeze({
    executable: input.executable,
    args: Object.freeze(args),
    outputPath,
    temporaryInputs: Object.freeze(temporaryInputs),
    expected: Object.freeze(expected),
  });
}

/**
 * Per-stream `-map 0:<index>` plus the codec choice the legacy route used:
 * video/subtitle copy, audio copy except `pcm_bluray` which becomes `pcm_s24le`
 * (Matroska has no Blu-ray LPCM tag).
 */
function perStreamMapCodecArgs(manifest: MediaPipelineManifest): string[] {
  const streamsById = new Map(
    manifest.title.streams.map((stream) => [stream.id, stream]),
  );
  const args: string[] = [];
  let audioOutIndex = 0;
  for (const id of manifest.selection.streamIds) {
    const stream = streamsById.get(id);
    if (!stream) throw new Error(`Remux 清单中的流轨不存在：${id}`);
    args.push("-map", `0:${stream.index}`);
    if (stream.type === "audio") {
      args.push(
        `-c:a:${audioOutIndex}`,
        stream.codec?.toLowerCase() === "pcm_bluray" ? "pcm_s24le" : "copy",
      );
      audioOutIndex += 1;
    } else if (stream.type === "video") {
      args.push("-c:v", "copy");
    } else if (stream.type === "subtitle") {
      args.push("-c:s", "copy");
    }
  }
  return args;
}
