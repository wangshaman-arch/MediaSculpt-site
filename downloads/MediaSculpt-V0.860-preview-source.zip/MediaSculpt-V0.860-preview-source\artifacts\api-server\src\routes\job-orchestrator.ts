import os from "os";
import path from "path";
import fs from "fs/promises";
import { db, jobsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { runDvdRemux } from "../lib/dvd-remux";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { shouldInspectExternalSubtitles } from "../lib/subtitle-utils";
import { resolveDvdTitleForSource } from "../lib/disc";
import { shouldUseVerifiedDvdRemux } from "../lib/job-workflow";
import { validateRemuxOutput } from "../lib/remux-validation";
import {
  buildCompressionOutputName,
  buildRemuxOutputName,
  cleanSegment,
  encoderBitDepth,
} from "../lib/output-naming";
import { dvdOutputBaseName } from "../lib/dvd-source-identity";
import { resolvePosterProxyUrl } from "../lib/http-client";
import { resolveToolPath } from "../lib/tool-runtime";
import { resolveOutputDir, resolveRuntimePath } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { loadTaskSnapshot } from "../lib/task-snapshot";
import { addLog } from "../lib/job-logging";
import {
  cancelledJobs,
  clearJobOutputFiles,
  removeIncompleteJobOutputs,
  trackJobOutputFile,
} from "./jobs-tracking";
import {
  dvdVideoInputPath,
  buildDvdTypeMaps,
  dvdConcatInputArgs,
  writeDvdConcatListFile,
} from "./jobs-dvd";
import { getConfig } from "./jobs-config";
import { probeStreams, probeDvdTitleByNumber } from "./jobs-probe";
import {
  resolveJobSubtitleDirectory,
  ensureDirectory,
  outputDirectoryForTask,
} from "./jobs-output-paths";
import {
  selectExternalSubtitleForJob,
  detectExistingSubtitleFiles,
} from "./jobs-subtitle-select";
import { startNextPendingJob } from "./job-runtime";
import {
  ocrTitleIdForTaskSnapshot,
  validateJobViability,
  blockedReasonMessage,
} from "./jobs-pipeline";
import { processChapterPreviewJob } from "./job-chapter-preview";
import { processVerifiedDvdRemuxJob } from "./job-dvd-remux";
import { runAiAssetStage } from "./job-readme-ai";
import { selectedDvdAudioCodecs } from "./jobs-dvd-audio";
import { buildJobExecutionContext } from "./job-execution-context";
import { prepareJobMediaInput } from "./job-media-input-context";
import { probeJobMedia } from "./job-media-probe-context";
import { buildDvdVobFallbackArgs } from "./job-dvd-remux-fallback";
import { isPlayableRemuxProbe } from "./job-remux-output-health";
import { runRemuxStage } from "./job-remux-stage";
import { runCompressionStage } from "./job-compression-stage";
import { runSubtitleStage } from "./job-subtitle-stage";
import {
  describeOutputCapacity,
  estimateOutputCapacity,
  type OutputCapacityMode,
} from "../lib/output-capacity";
export async function processJob(jobId: number) {
  const config = await getConfig();
  let aiProxyResolved = false;
  let aiProxyUrl: string | null = null;
  const getAiProxyUrl = async () => {
    if (!aiProxyResolved) {
      aiProxyUrl = await resolvePosterProxyUrl(config.posterProxyUrl);
      aiProxyResolved = true;
    }
    return aiProxyUrl;
  };

  await db
    .update(jobsTable)
    .set({
      status: "scanning",
      startedAt: new Date(),
      progress: 0,
    })
    .where(eq(jobsTable.id, jobId));
  await addLog(jobId, "info", "任务开始 — 正在扫描文件");

  const jobRows = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, jobId))
    .limit(1);
  if (!jobRows.length) return;
  let job = {
    ...jobRows[0],
    filePath: resolveRuntimePath(jobRows[0].filePath, config),
    mainTrackPath: jobRows[0].mainTrackPath
      ? resolveRuntimePath(jobRows[0].mainTrackPath, config)
      : null,
  };
  // A queued task can outlive its source file (user moved/deleted the file
  // after creating the task). Detect that before metadata/processing stages so
  // the queue reports the real cause instead of a misleading tool failure.
  try {
    await fs.access(job.filePath);
  } catch (error) {
    const code =
      typeof error === "object" && error && "code" in error
        ? String((error as { code?: unknown }).code ?? "")
        : "";
    const sourceMessage =
      code === "ENOENT"
        ? `源文件已删除或不存在：${job.filePath}`
        : `源文件不可访问${code ? `（${code}）` : ""}：${job.filePath}`;
    await db
      .update(jobsTable)
      .set({
        status: "error",
        errorMessage: sourceMessage,
        completedAt: new Date(),
      })
      .where(eq(jobsTable.id, jobId));
    await addLog(jobId, "error", sourceMessage);
    cancelledJobs.delete(jobId);
    jobProcessController.clearJob(jobId);
    void startNextPendingJob().catch(() => {});
    return;
  }
  const taskSnapshot = loadTaskSnapshot(jobRows[0]);
  // 智能生成优先：说明 → 影评 → 海报，先于 Remux/字幕/压缩完成。
  // 所有任务类型（压缩/Remux/字幕/章节预览/纯生成）统一在此阶段处理，
  // 单项失败只记录日志，不阻塞视频处理。
  await runAiAssetStage(jobId, config, job);
  // Fail fast with a clear message when the output drive is nearly full,
  // instead of failing halfway through a large export.
  try {
    const diskOutputDir = outputDirectoryForTask(config, job);
    const diskStat = await fs.statfs(diskOutputDir);
    const freeGB =
      (Number(diskStat.bavail) * Number(diskStat.bsize)) / 1_000_000_000;
    if (freeGB < 2) {
      const message = `输出磁盘空间不足（剩余 ${freeGB.toFixed(1)} GB），已中止任务；请清理磁盘或更换输出目录`;
      await db
        .update(jobsTable)
        .set({
          status: "error",
          errorMessage: message,
          completedAt: new Date(),
        })
        .where(eq(jobsTable.id, jobId));
      await addLog(jobId, "error", message);
      cancelledJobs.delete(jobId);
      jobProcessController.clearJob(jobId);
      void startNextPendingJob().catch(() => {});
      return;
    }
  } catch {
    // statfs unavailable or the directory cannot be resolved — skip the precheck.
  }
  const {
    pipelineSteps,
    pipelineNames,
    pipelineRemuxIndex,
    pipelineSubtitleIndex,
    pipelineCompressIndex,
    pipelineHasRemux,
    pipelineHasSubtitle,
    pipelineHasCompress,
    pipelineContinuesAfterRemux,
    isBilingual,
    subtitleMode,
    bilingualStyle,
  } = buildJobExecutionContext({ job: jobRows[0], config });

  if (
    shouldUseVerifiedDvdRemux({
      mediaType: job.mediaType,
      processingMode: job.processingMode,
      pipelineHasRemux,
      pipelineHasCompress,
      pipelineContinuesAfterRemux,
    })
  ) {
    try {
      await processVerifiedDvdRemuxJob(jobId, jobRows[0], config);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (!cancelledJobs.has(jobId)) {
        await db
          .update(jobsTable)
          .set({
            status: "error",
            errorMessage: message,
            completedAt: new Date(),
          })
          .where(eq(jobsTable.id, jobId));
        await addLog(jobId, "error", `DVD Remux 失败：${message}`);
      }
    } finally {
      cancelledJobs.delete(jobId);
      jobProcessController.clearJob(jobId);
      void startNextPendingJob().catch(() => {});
    }
    return;
  }

  // 章节预览为独立模式：不进入压缩/字幕流水线，生成后任务即结束。
  if (job.processingMode === "chapterPreview") {
    try {
      await processChapterPreviewJob(jobId, job, config);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (!cancelledJobs.has(jobId)) {
        await db
          .update(jobsTable)
          .set({
            status: "error",
            errorMessage: message,
            completedAt: new Date(),
          })
          .where(eq(jobsTable.id, jobId));
        await addLog(jobId, "error", `章节预览失败：${message}`);
        await removeIncompleteJobOutputs(jobId, (logMessage) =>
          addLog(jobId, "info", logMessage),
        );
      }
    } finally {
      cancelledJobs.delete(jobId);
      jobProcessController.clearJob(jobId);
      clearJobOutputFiles(jobId);
      void startNextPendingJob().catch(() => {});
    }
    return;
  }

  const mediaInputContext = await prepareJobMediaInput({
    jobId,
    job,
    taskSnapshot,
    config,
    log: (level, message) => addLog(jobId, level, message),
    probeDvdTitleByNumber: probeDvdTitleByNumber,
  });
  job = mediaInputContext.job;
  const {
    mediaInputPath,
    dvdVideoInput,
    dvdTitle,
    selectedTitleSizeBytes,
    selectedAnalysisTitle,
  } = mediaInputContext;
  let handbrakeInputPath = mediaInputContext.handbrakeInputPath;
  let selectedTitleDurationSeconds =
    mediaInputContext.selectedTitleDurationSeconds;
  let temporaryRemuxPath: string | null = null;

  // Do the size-aware check after disc title/playlist selection. The earlier
  // minimum check catches nearly-full disks; this check catches a large
  // Remux or combined pipeline that would otherwise fail halfway through.
  const capacityMode: OutputCapacityMode =
    pipelineHasRemux && pipelineHasCompress
      ? "both"
      : pipelineHasRemux || job.processingMode === "remux"
        ? "remux"
        : pipelineHasCompress || job.processingMode === "compress"
          ? "compress"
          : "none";
  if (capacityMode !== "none") {
    try {
      const outputDirectory = outputDirectoryForTask(config, job);
      await ensureDirectory(outputDirectory);
      let sourceBytes = selectedTitleSizeBytes ?? null;
      if (sourceBytes === null) {
        const stat = await fs.stat(mediaInputPath).catch(() => null);
        if (stat?.isFile()) sourceBytes = stat.size;
      }
      const estimate = estimateOutputCapacity(capacityMode, sourceBytes);
      const diskStat = await fs.statfs(outputDirectory);
      const availableBytes = Number(diskStat.bavail) * Number(diskStat.bsize);
      if (availableBytes < estimate.requiredFreeBytes) {
        const message = describeOutputCapacity(availableBytes, estimate);
        await db
          .update(jobsTable)
          .set({
            status: "error",
            errorMessage: message,
            completedAt: new Date(),
          })
          .where(eq(jobsTable.id, jobId));
        await addLog(jobId, "error", message);
        cancelledJobs.delete(jobId);
        jobProcessController.clearJob(jobId);
        void startNextPendingJob().catch(() => {});
        return;
      }
      await addLog(
        jobId,
        "info",
        `输出空间预检通过：可用 ${(availableBytes / 1_000_000_000).toFixed(1)} GB，需要 ${(estimate.requiredFreeBytes / 1_000_000_000).toFixed(1)} GB`,
      );
    } catch (error) {
      await addLog(
        jobId,
        "warn",
        `输出空间预检跳过（不影响任务）：${error instanceof Error ? error.message : String(error)}`,
      );
    }
  }

  try {
    if (selectedTitleSizeBytes) {
      await db
        .update(jobsTable)
        .set({ fileSizeBefore: selectedTitleSizeBytes })
        .where(eq(jobsTable.id, jobId));
    } else if (job.mediaType === "dvd" && taskSnapshot) {
      // HandBrake's DVD scan does not provide a reliable per-title byte size.
      // Never substitute the VIDEO_TS directory or the largest title here.
      await db
        .update(jobsTable)
        .set({ fileSizeBefore: null })
        .where(eq(jobsTable.id, jobId));
    } else if (dvdTitle?.sizeBytes) {
      await db
        .update(jobsTable)
        .set({ fileSizeBefore: dvdTitle.sizeBytes })
        .where(eq(jobsTable.id, jobId));
    } else {
      const statTarget = mediaInputPath;
      try {
        const stat = await fs.stat(statTarget);
        await db
          .update(jobsTable)
          .set({ fileSizeBefore: stat.size })
          .where(eq(jobsTable.id, jobId));
      } catch {
        /* stat failed — fileSizeBefore stays null */
      }
    }

    let hasEmbeddedSubs = false;
    let primaryAudioCodec: string | null = null;
    let sourceHasAudio = true;
    let probeVideoHeight: number | null = null;
    let probeSucceeded = false;
    let probeHasVideo = false;
    try {
      const mediaProbe = await probeJobMedia({
        jobId,
        job,
        mediaInputPath,
        taskSnapshotPresent: Boolean(taskSnapshot),
        selectedDvdTitleNumber:
          job.mediaType === "dvd"
            ? Number(ocrTitleIdForTaskSnapshot(taskSnapshot)) || null
            : null,
        selectedTitleDurationSeconds,
        probeDvdTitleByNumber,
      });
      hasEmbeddedSubs = mediaProbe.hasEmbeddedSubs;
      primaryAudioCodec = mediaProbe.primaryAudioCodec;
      sourceHasAudio = mediaProbe.sourceHasAudio;
      probeVideoHeight = mediaProbe.probeVideoHeight;
      probeHasVideo = mediaProbe.probeHasVideo;
      probeSucceeded = true;
    } catch (error) {
      await addLog(
        jobId,
        "warn",
        `媒体流探测失败${job.mediaType === "dvd" ? `（所选 DVD Title ${ocrTitleIdForTaskSnapshot(taskSnapshot) ?? "未知"}）` : ""}：${error instanceof Error ? error.message : String(error)}`,
      );
      if (selectedTitleDurationSeconds) {
        job.durationSeconds = selectedTitleDurationSeconds;
        await db
          .update(jobsTable)
          .set({ durationSeconds: selectedTitleDurationSeconds })
          .where(eq(jobsTable.id, jobId));
      }
      if (job.processingMode !== "remux") {
        await addLog(jobId, "warn", "ffprobe 不可用 — 无法检测内嵌字幕");
      }
    }

    await db
      .update(jobsTable)
      .set({ hasEmbeddedSubtitles: hasEmbeddedSubs })
      .where(eq(jobsTable.id, jobId));

    // 执行前可执行性检查：模式所需流轨缺失时标记“不可执行 + 原因”，不阻塞整个队列
    if (probeSucceeded) {
      const viability = validateJobViability(job, {
        video: probeHasVideo,
        audio: sourceHasAudio,
        subtitle: hasEmbeddedSubs,
      });
      if (!viability.ok) {
        const reason = blockedReasonMessage(viability.code);
        await db
          .update(jobsTable)
          .set({
            status: "error",
            errorMessage: `VX_BLOCKED:${viability.code}`,
            completedAt: new Date(),
          })
          .where(eq(jobsTable.id, jobId));
        await addLog(jobId, "error", `不可执行：${reason}`);
        return;
      }
    }
    let subtitlePath: string | null = null;
    let graphicSubtitlePaths: string[] = [];
    let subtitleSourceOutcome: string | null = null;

    const outputDir = outputDirectoryForTask(config, job);
    const subtitleDirJob = resolveJobSubtitleDirectory(config, job);
    await ensureDirectory(outputDir);
    await ensureDirectory(subtitleDirJob);

    const baseName = path.basename(job.filePath, path.extname(job.filePath));
    const outputBaseName =
      job.mediaType === "dvd"
        ? dvdOutputBaseName({ sourcePath: job.filePath, mediaType: "dvd" })
        : /^(VIDEO_TS|BDMV)$/i.test(baseName)
          ? path.basename(path.dirname(job.filePath))
          : baseName;
    // Subtitle-only jobs must finish after OCR/translation.  A task snapshot
    // can use outputMode=subtitle while the legacy job row still says
    // processingMode=none, so accept both representations here.
    const subtitleOnlyTask =
      job.processingMode === "none" ||
      taskSnapshot?.outputMode === "subtitle" ||
      taskSnapshot?.outputMode === "whisper";
    const frozenCompressionFileName =
      taskSnapshot &&
      (taskSnapshot.outputMode === "compress" ||
        taskSnapshot.outputMode === "both")
        ? taskSnapshot.output.fileName
        : null;
    const legacyCompressionBaseName = outputBaseName;
    const compressionFileName =
      frozenCompressionFileName ??
      buildCompressionOutputName({
        baseName: legacyCompressionBaseName,
        mediaType: job.mediaType,
        outputFormat: config.outputFormat,
        encoder: config.encoder,
        crf: config.crf,
        primaryAudioCodec,
        height: probeVideoHeight,
        bitDepth: encoderBitDepth(config.encoder),
        template: config.outputNameTemplate,
      });
    const compressionBaseName = path.basename(
      compressionFileName,
      path.extname(compressionFileName),
    );
    const outputFile = path.join(outputDir, compressionFileName);
    trackJobOutputFile(jobId, outputFile);
    // A disc has no playable filename of its own.  For a standalone subtitle
    // task, use the exact filename stem that a DVD compression task would use
    // so the generated .srt/.ass is auto-discovered beside that video.
    let standaloneSubtitleBaseName =
      subtitleOnlyTask && ["dvd", "bluray", "iso"].includes(job.mediaType)
        ? compressionBaseName
        : outputBaseName;
    if (subtitleOnlyTask && ["dvd", "bluray", "iso"].includes(job.mediaType)) {
      // A subtitle-only disc task may be created after the video was already
      // remuxed. Prefer that real video's complete stem over a newly predicted
      // compression name, otherwise players cannot auto-load the subtitle.
      const canonicalPrefix = `${cleanSegment(outputBaseName).toLowerCase()}.`;
      const videoFiles = new Set<string>();
      for (const directory of new Set([outputDir, subtitleDirJob])) {
        const entries = await fs.readdir(directory).catch(() => [] as string[]);
        for (const entry of entries) {
          if (!/\.(?:mkv|mp4|m4v|avi|ts|m2ts|vob)$/i.test(entry)) continue;
          if (/\.graphic-\d+\.(?:mkv|mp4)$/i.test(entry)) continue;
          const stem = path.basename(entry, path.extname(entry));
          const normalizedStem = cleanSegment(stem).toLowerCase();
          if (
            normalizedStem === cleanSegment(outputBaseName).toLowerCase() ||
            normalizedStem.startsWith(canonicalPrefix)
          ) {
            videoFiles.add(stem);
          }
        }
      }
      const selectedDvdTitleNumber =
        job.mediaType === "dvd"
          ? (taskSnapshot?.toolSelections.handbrakeTitleNumber ??
            parseHandBrakeSelectionPlan(job.selectionPlan)?.handbrake
              ?.titleNumber ??
            null)
          : null;
      const titleMarker = selectedDvdTitleNumber
        ? new RegExp(`\\.Title0*${selectedDvdTitleNumber}(?:\\.|$)`, "i")
        : null;
      const matchingTitleVideo = titleMarker
        ? [...videoFiles].find((name) => titleMarker.test(name))
        : undefined;
      const existingVideo = selectedDvdTitleNumber
        ? matchingTitleVideo
        : [...videoFiles].sort((a, b) => {
            const score = (name: string) =>
              /\.DVD\.Remux$/i.test(name)
                ? 0
                : /\.BluRay\.Remux$/i.test(name)
                  ? 1
                  : /\.Remux$/i.test(name)
                    ? 2
                    : 3;
            return score(a) - score(b) || a.localeCompare(b);
          })[0];
      if (existingVideo) {
        standaloneSubtitleBaseName = existingVideo;
        await addLog(
          jobId,
          "info",
          `字幕文件名跟随所选标题视频：${existingVideo}${selectedDvdTitleNumber ? `（DVD Title ${selectedDvdTitleNumber}）` : ""}`,
        );
      } else if (selectedDvdTitleNumber) {
        // Never bind a Title N subtitle to another title just because it sorts
        // first; produce an explicitly title-scoped sidecar name instead.
        standaloneSubtitleBaseName = dvdOutputBaseName({
          sourcePath: job.filePath,
          mediaType: "dvd",
          titleNumber: selectedDvdTitleNumber,
          titleCount: 2,
        });
        await addLog(
          jobId,
          "warn",
          `没有找到 DVD Title ${selectedDvdTitleNumber} 对应的视频文件；字幕按所选标题独立命名，未绑定到其他 Title`,
        );
      }
    }
    // 流水线命名：字幕文件跟随它所在阶段的基准名（Remux 名 / 压缩版名 / 源名）
    const remuxStageFileName = pipelineHasRemux
      ? (pipelineNames.remux ??
        buildRemuxOutputName(
          outputBaseName,
          job.mediaType,
          config.outputFormat,
          config.outputNameTemplate,
        ))
      : null;
    const remuxStageBaseName = remuxStageFileName
      ? path.basename(remuxStageFileName, path.extname(remuxStageFileName))
      : null;
    const subtitleStageBaseName = !pipelineHasSubtitle
      ? standaloneSubtitleBaseName
      : pipelineHasRemux &&
          pipelineRemuxIndex < pipelineSubtitleIndex &&
          remuxStageBaseName
        ? remuxStageBaseName
        : pipelineHasCompress && pipelineCompressIndex < pipelineSubtitleIndex
          ? compressionBaseName
          : standaloneSubtitleBaseName;
    await addLog(jobId, "info", `压缩输出路径已冻结：${outputFile}`);
    const srtFile = path.join(
      subtitleDirJob,
      `${subtitleStageBaseName}.original.srt`,
    );

    // Automatic mode prefers a matching external subtitle before probing the
    // container. Keep the original beside the job output; translation below
    // writes a separate .zhs.srt so the source is never destroyed.
    let sourceSubtitleFile: string | null = null;
    let translatedSubtitlePath: string | null = null;
    let externalSubtitleFound: string | null = null;
    let externalChineseBilingualSource = false;
    if (shouldInspectExternalSubtitles(subtitleMode)) {
      try {
        // 按文件名配对（媒体同名或同名 + 语言后缀）检测外置字幕；同目录其他视频的
        // 字幕不会误判为本文件已含中文/已翻译。
        const detected = await detectExistingSubtitleFiles(
          path.dirname(mediaInputPath),
          path.basename(mediaInputPath, path.extname(mediaInputPath)),
        );
        // 外置中文字幕文件（无论多少）一律不视为“已翻译”：只有视频容器内自带的
        // 中文字幕轨才允许跳过翻译；双语模式仅在它是唯一可用外置字幕时复用，
        // 否则会把同一份中文字幕同时当作源文和译文，生成两行中文。
        const chosen = selectExternalSubtitleForJob(detected, isBilingual);
        if (chosen) {
          const sourceSubtitlePath = chosen.path;
          externalSubtitleFound = sourceSubtitlePath;
          const originalPath = path.join(
            subtitleDirJob,
            subtitleStageBaseName +
              ".original" +
              path.extname(sourceSubtitlePath),
          );
          await fs.copyFile(sourceSubtitlePath, originalPath);
          subtitlePath = originalPath;
          sourceSubtitleFile = originalPath;
          subtitleSourceOutcome = "external";
          externalChineseBilingualSource =
            isBilingual &&
            chosen.language === "zh" &&
            !detected.some(
              (item) => item.language === "en" || item.language === "other",
            );
          if (externalChineseBilingualSource) {
            // A Chinese sidecar is only the Chinese half of a bilingual DVD
            // task. Do not let it suppress the DVD's embedded foreign graphic
            // track; keep it as the target side and continue probing the disc.
            translatedSubtitlePath = originalPath;
            subtitlePath = null;
            sourceSubtitleFile = null;
            externalSubtitleFound = null;
            await addLog(
              jobId,
              "info",
              `双语模式：复用外置中文字幕作为中文侧，继续探测 DVD 内置外语字幕轨：${originalPath}`,
            );
          }
          if (externalChineseBilingualSource) {
            await addLog(
              jobId,
              "info",
              `双语模式：已保留外置中文字幕作为中文侧，不跳过 DVD 内置外语字幕探测：${originalPath}`,
            );
          } else if (subtitleMode === "extract") {
            subtitlePath = null;
            await addLog(
              jobId,
              "info",
              "内置字幕提取：文件夹已存在外置字幕（内容判定），跳过内置提取",
            );
          } else {
            await addLog(
              jobId,
              "info",
              `发现外置字幕（内容判定：${chosen.language}），保留原文：${sourceSubtitlePath} → ${originalPath}${externalChineseBilingualSource ? "；双语模式仅输出中文行，跳过 Whisper/翻译" : ""}`,
            );
          }
        } else if (detected.some((item) => item.language === "zh")) {
          await addLog(
            jobId,
            "info",
            "目录中存在中文字幕文件，但视频未内置中文字幕轨，不视为已翻译，继续执行字幕处理",
          );
        } else {
          await addLog(jobId, "info", "未在目录中发现已有字幕文件（内容判定）");
        }
      } catch (error) {
        await addLog(
          jobId,
          "warn",
          "外置字幕检测失败，将继续检测内置字幕：" + String(error),
        );
      }
    }

    if (
      job.processingMode === "compress" &&
      job.mediaType === "dvd" &&
      taskSnapshot?.compressionSourceStrategy === "temporary-remux"
    ) {
      const ffmpegExecutable = await resolveToolPath("ffmpeg");
      const titleNumber = taskSnapshot.toolSelections.dvdVtsNumber;
      if (
        !ffmpegExecutable ||
        typeof titleNumber !== "number" ||
        titleNumber <= 0
      ) {
        throw new Error(
          "复杂 DVD 压缩需要已验证的 FFmpeg DVD 标题和可执行文件",
        );
      }
      const streamIndexes = (ids: string[]) =>
        ids
          .map((id) => /^stream:(\d+)$/.exec(id)?.[1])
          .filter((value): value is string => Boolean(value))
          .map(Number);
      const videoStreams = streamIndexes(
        taskSnapshot.streamSelection.videoTrackIds,
      );
      const audioStreams = streamIndexes(
        taskSnapshot.streamSelection.audioTrackIds,
      );
      const subtitleStreams = streamIndexes(
        taskSnapshot.streamSelection.subtitleTrackIds,
      );
      const selectedAudioCodecs = selectedDvdAudioCodecs(
        taskSnapshot,
        audioStreams,
        job.selectionPlan,
      );
      if (videoStreams.length === 0)
        throw new Error("复杂 DVD 压缩至少需要一个视频流");
      temporaryRemuxPath = path.join(
        os.tmpdir(),
        `vx-dvd-compress-${jobId}-${Date.now()}.mkv`,
      );
      trackJobOutputFile(jobId, temporaryRemuxPath, { temp: true });
      await addLog(
        jobId,
        "info",
        `复杂 DVD 结构：先使用 FFmpeg 临时 Remux，再交给 HandBrake 压缩；临时文件=${temporaryRemuxPath}`,
      );
      const dvdSourcePath = resolveRuntimePath(taskSnapshot.sourcePath, config);
      const physicalVtsNumber =
        selectedAnalysisTitle?.toolMappings.physicalVtsNumber ??
        taskSnapshot?.toolSelections.physicalVtsNumber ??
        null;
      const fallbackLookupTitleNumber =
        typeof physicalVtsNumber === "number" && physicalVtsNumber > 0
          ? physicalVtsNumber
          : titleNumber;
      const fallbackTitle =
        dvdTitle ??
        (await resolveDvdTitleForSource(
          dvdSourcePath,
          0,
          fallbackLookupTitleNumber,
        ).catch(() => null));
      if (!fallbackTitle)
        throw new Error(
          "复杂 DVD 压缩无法解析所选标题，已停止以避免把错误标题交给 HandBrake",
        );
      if (
        physicalVtsNumber &&
        fallbackTitle.titleNumber === physicalVtsNumber
      ) {
        await addLog(
          jobId,
          "info",
          `复杂 DVD 临时 Remux 使用物理 VTS_${String(physicalVtsNumber).padStart(2, "0")} 作为 VOB 回退组；导航仍使用逻辑 Title ${titleNumber}`,
        );
      }
      const fallbackListFile = await writeDvdConcatListFile(
        fallbackTitle,
        `compress-fallback-vob-${jobId}`,
      );
      trackJobOutputFile(jobId, fallbackListFile, { temp: true });
      const fallbackArgs = buildDvdVobFallbackArgs({
        concatInputArgs: dvdConcatInputArgs(fallbackListFile),
        typeMaps: buildDvdTypeMaps(taskSnapshot, selectedAnalysisTitle),
        outputPath: temporaryRemuxPath,
        selectedAudioStreams: audioStreams,
        selectedAudioCodecs,
        selectedSubtitleStreams: subtitleStreams,
        subtitleMetadata: subtitleStreams.map((inputIndex) => {
          const stream = selectedAnalysisTitle?.streams.find(
            (candidate) => candidate.index === inputIndex,
          );
          return {
            inputIndex,
            language: stream?.language ?? null,
            title: stream?.title ?? null,
          };
        }),
        chapterMetadataPath: null,
      });
      try {
        const remuxResult = await runDvdRemux({
          executable: ffmpegExecutable,
          sourcePath: dvdVideoInputPath(dvdSourcePath),
          titleNumber,
          selectedVideoStreams: videoStreams,
          selectedAudioStreams: audioStreams,
          selectedAudioCodecs,
          selectedSubtitleStreams: subtitleStreams,
          selectedSubtitleMetadata: subtitleStreams.map((inputIndex) => {
            const stream = selectedAnalysisTitle?.streams.find(
              (candidate) => candidate.index === inputIndex,
            );
            return {
              inputIndex,
              language: stream?.language ?? null,
              title: stream?.title ?? null,
            };
          }),
          outputPath: temporaryRemuxPath,
          fallbackArgs,
          onFallback: async (error) => {
            await addLog(
              jobId,
              "warn",
              `复杂 DVD 临时 Remux 导航输出无效，回退 VOB concat：${error instanceof Error ? error.message : String(error)}`,
            );
          },
          validateOutput: async (validatedPath) => {
            const outputProbe = await probeStreams(validatedPath);
            if (!isPlayableRemuxProbe(outputProbe))
              throw new Error("临时 DVD Remux 没有有效视频流");
            await validateRemuxOutput(
              validatedPath,
              selectedTitleDurationSeconds,
              async () => ({
                duration: outputProbe.duration,
                streams: outputProbe.streams.map((stream) => ({
                  codecType: stream.codecType,
                  language: stream.language,
                })),
                chapters: outputProbe.chapters,
              }),
              {
                expectedStreamCounts: {
                  video: videoStreams.length,
                  audio: audioStreams.length,
                  subtitle: subtitleStreams.length,
                },
              },
            );
          },
        });
        await addLog(
          jobId,
          "info",
          `临时 Remux 完成：${remuxResult.fileSize} 字节；FFmpeg 耗时 ${remuxResult.diagnostic.durationMs} ms`,
        );
      } finally {
        await fs.unlink(fallbackListFile).catch(() => {});
      }
      handbrakeInputPath = temporaryRemuxPath;
    }

    const subtitleStageResult = await runSubtitleStage({
      jobId,
      job,
      config,
      taskSnapshot,
      mediaInputPath,
      dvdVideoInput,
      subtitleMode,
      isBilingual,
      bilingualStyle,
      dvdTitle,
      outputBaseName,
      subtitleStageBaseName,
      subtitleDirJob,
      srtFile,
      subtitleOnlyTask,
      hasEmbeddedSubs,
      sourceHasAudio,
      externalSubtitleFound,
      externalChineseBilingualSource,
      getAiProxyUrl,
      subtitlePath,
      translatedSubtitlePath,
      sourceSubtitleFile,
      subtitleSourceOutcome,
    });
    subtitlePath = subtitleStageResult.subtitlePath;
    translatedSubtitlePath = subtitleStageResult.translatedSubtitlePath;
    sourceSubtitleFile = subtitleStageResult.sourceSubtitleFile;
    subtitleSourceOutcome = subtitleStageResult.subtitleSourceOutcome;
    graphicSubtitlePaths = subtitleStageResult.graphicSubtitlePaths;
    if (subtitleStageResult.shouldReturn) return;

    await db
      .update(jobsTable)
      .set({
        status: "compressing",
        progress: 0,
        subtitlePath: sourceSubtitleFile ?? subtitlePath,
        translatedSubtitlePath,
      })
      .where(eq(jobsTable.id, jobId));

    // ─── REMUX branch (lossless stream copy — for disc/ISO sources) ────────────
    const remuxStageResult = await runRemuxStage({
      jobId,
      job,
      config,
      mediaInputPath,
      outputDir,
      baseName,
      pipelineNames,
      pipelineHasRemux,
      pipelineContinuesAfterRemux,
      subtitlePath,
      translatedSubtitlePath,
      graphicSubtitlePaths,
      dvdTitle,
      selectedTitleSizeBytes,
      selectedAnalysisTitle,
    });
    const pipelineRemuxOutputPath = remuxStageResult.pipelineRemuxOutputPath;
    if (remuxStageResult.shouldReturn) return;
    // ─── END REMUX branch ──────────────────────────────────────────────────────

    const compressionStageResult = await runCompressionStage({
      jobId,
      job,
      config,
      taskSnapshot,
      pipelineSteps,
      pipelineHasCompress,
      pipelineHasSubtitle,
      pipelineRemuxOutputPath,
      handbrakeInputPath,
      outputFile,
      compressionBaseName,
      subtitleStageBaseName,
      subtitleDirJob,
      sourceSubtitleFile,
      subtitlePath,
      translatedSubtitlePath,
      graphicSubtitlePaths,
      selectedAnalysisTitle,
      temporaryRemuxPath,
    });
    if (compressionStageResult.shouldReturn) return;
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    // Don't overwrite the "用户取消" status set by the cancel route
    if (!cancelledJobs.has(jobId)) {
      await db
        .update(jobsTable)
        .set({
          status: "error",
          errorMessage: msg,
          completedAt: new Date(),
        })
        .where(eq(jobsTable.id, jobId));
      await addLog(jobId, "error", `任务失败：${msg}`);
      // 失败时删除本次产生的未完成输出（按运行前快照，保留上次成功输出）
      await removeIncompleteJobOutputs(jobId, (message) =>
        addLog(jobId, "info", message),
      );
    }
  } finally {
    if (temporaryRemuxPath) {
      await fs.rm(temporaryRemuxPath, { force: true }).catch(async (error) => {
        await addLog(
          jobId,
          "warn",
          `临时 Remux 文件清理失败，已保留日志：${String(error)}`,
        ).catch(() => {});
      });
    }
    // Always clean up tracking state when job finishes
    cancelledJobs.delete(jobId);
    jobProcessController.clearJob(jobId);
    clearJobOutputFiles(jobId);
    void startNextPendingJob().catch(() => {});
  }

  // ── Shutdown-after-complete check ─────────────────────────────────────────
  try {
    const latestConfig = await getConfig();
    if (latestConfig.shutdownAfterComplete) {
      const activeJobs = await db
        .select({ id: jobsTable.id })
        .from(jobsTable)
        .where(
          sql`status IN ('pending','scanning','transcribing','compressing','remuxing')`,
        );
      if (activeJobs.length === 0) {
        const signalPath = path.join(
          resolveOutputDir(latestConfig.outputDirectory, latestConfig),
          "mediasculpt-shutdown-signal.txt",
        );
        await fs.writeFile(
          signalPath,
          `MediaSculpt 全部任务完成，关机信号\n${new Date().toISOString()}\n`,
          "utf-8",
        );
        await addLog(
          jobId,
          "info",
          `✅ 全部任务完成 — 已写出关机信号：${signalPath}`,
        );
      }
    }
  } catch {
    /* ignore shutdown check errors */
  }
}

// ─── Routes ──────────────────────────────────────────────────────────────────

// GET /jobs
// ─── Shared readme generation ─────────────────────────────────────────────────
