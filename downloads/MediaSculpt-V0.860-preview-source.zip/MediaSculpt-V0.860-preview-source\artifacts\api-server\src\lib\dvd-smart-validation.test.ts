import { describe, expect, it } from "vitest";
import {
  validateDvdCandidates,
  type DvdSmartCandidateInput,
} from "./dvd-smart-validation";

function candidate(
  overrides: Partial<DvdSmartCandidateInput> = {},
): DvdSmartCandidateInput {
  return {
    titleId: "handbrake:1",
    titleNumber: 1,
    durationSeconds: 3600,
    chapterStarts: [0, 1200, 2400],
    videoSignature: "mpeg2video|720x576|25/1",
    audioSignature: "ac3|eng|6",
    subtitleSignature: "dvd_subtitle|zho",
    availabilityStatus: "confirmed",
    validationStatus: "passed",
    ...overrides,
  };
}

describe("validateDvdCandidates", () => {
  it("selects three independent readable features with similar durations", () => {
    const result = validateDvdCandidates({
      physicalBytes: 9_000,
      vtsSizes: new Map([
        [1, 3_000],
        [2, 3_000],
        [3, 3_000],
      ]),
      candidates: [
        candidate({
          titleId: "handbrake:1",
          titleNumber: 1,
          physicalVtsNumbers: [1],
        }),
        candidate({
          titleId: "handbrake:2",
          titleNumber: 2,
          durationSeconds: 3602,
          physicalVtsNumbers: [2],
        }),
        candidate({
          titleId: "handbrake:3",
          titleNumber: 3,
          durationSeconds: 3598,
          physicalVtsNumbers: [3],
        }),
      ],
    });

    expect(result.selectedTitleIds).toEqual([
      "handbrake:1",
      "handbrake:2",
      "handbrake:3",
    ]);
    expect(result.confidence).toBe("high");
    expect(result.requiresUserSelection).toBe(false);
    expect(result.capacity).toMatchObject({
      countedPhysicalBytes: 9_000,
      coveragePercent: 100,
    });
  });

  it("keeps only one title when the stream and chapter fingerprint is an exact duplicate", () => {
    const result = validateDvdCandidates({
      physicalBytes: 10_000,
      vtsSizes: new Map([[1, 10_000]]),
      candidates: [
        candidate({
          titleId: "handbrake:5",
          titleNumber: 5,
          physicalVtsNumbers: [1],
        }),
        candidate({
          titleId: "handbrake:6",
          titleNumber: 6,
          physicalVtsNumbers: [1],
        }),
      ],
    });

    expect(result.selectedTitleIds).toEqual(["handbrake:5"]);
    expect(
      result.candidates.find((item) => item.titleId === "handbrake:6"),
    ).toMatchObject({
      status: "duplicate",
    });
    expect(result.capacity.countedPhysicalBytes).toBe(10_000);
  });

  it("rejects unavailable, failed, and short menu candidates", () => {
    const result = validateDvdCandidates({
      physicalBytes: 20_000,
      vtsSizes: new Map(),
      candidates: [
        candidate({ titleId: "good", titleNumber: 1 }),
        candidate({
          titleId: "failed",
          titleNumber: 2,
          validationStatus: "failed",
          validationFailureReason: "中段读取失败",
        }),
        candidate({
          titleId: "unavailable",
          titleNumber: 3,
          availabilityStatus: "unavailable",
        }),
        candidate({ titleId: "menu", titleNumber: 4, durationSeconds: 45 }),
      ],
    });

    expect(result.selectedTitleIds).toEqual(["good"]);
    expect(
      result.candidates.find((item) => item.titleId === "failed"),
    ).toMatchObject({ status: "rejected", reason: "中段读取失败" });
    expect(
      result.candidates.find((item) => item.titleId === "unavailable"),
    ).toMatchObject({ status: "rejected" });
    expect(
      result.candidates.find((item) => item.titleId === "menu"),
    ).toMatchObject({ status: "rejected" });
    expect(result.confidence).toBe("medium");
  });

  it("does not claim physical coverage when title-to-VTS mapping is unknown", () => {
    const result = validateDvdCandidates({
      physicalBytes: 10_000,
      vtsSizes: new Map([[1, 10_000]]),
      candidates: [candidate({ physicalVtsNumbers: undefined })],
    });

    expect(result.capacity).toMatchObject({
      countedPhysicalBytes: 0,
      coveragePercent: 0,
      mappingComplete: false,
    });
    expect(result.confidence).toBe("medium");
  });

  it("does not auto-select multiple long logical titles when their physical payload is unknown", () => {
    const result = validateDvdCandidates({
      physicalBytes: 10_000,
      vtsSizes: new Map([[1, 10_000]]),
      candidates: [
        candidate({
          titleId: "handbrake:7",
          titleNumber: 7,
          durationSeconds: 3600,
        }),
        candidate({
          titleId: "handbrake:8",
          titleNumber: 8,
          durationSeconds: 3599,
        }),
      ],
    });

    expect(result.selectedTitleIds).toEqual(["handbrake:7"]);
    expect(result.requiresUserSelection).toBe(true);
    expect(
      result.candidates.find((item) => item.titleId === "handbrake:8"),
    ).toMatchObject({
      status: "rejected",
    });
    expect(result.reasons.join(" ")).toContain("物理 VTS");
  });

  it("clamps an inconsistent mapped total to the physical source size", () => {
    const result = validateDvdCandidates({
      physicalBytes: 5_000,
      vtsSizes: new Map([
        [1, 4_000],
        [2, 4_000],
      ]),
      candidates: [
        candidate({ titleId: "a", titleNumber: 1, physicalVtsNumbers: [1] }),
        candidate({
          titleId: "b",
          titleNumber: 2,
          chapterStarts: [0, 900, 1800],
          physicalVtsNumbers: [2],
        }),
      ],
    });

    expect(result.capacity.countedPhysicalBytes).toBe(5_000);
    expect(result.capacity.coveragePercent).toBe(100);
    expect(result.capacity.warnings.join(" ")).toContain("超过物理容量");
  });
});
