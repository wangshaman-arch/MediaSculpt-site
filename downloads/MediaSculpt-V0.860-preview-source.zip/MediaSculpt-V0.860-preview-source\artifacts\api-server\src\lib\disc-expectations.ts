/**
 * Disc-job expectation helpers.
 *
 * A disc job must always be measured against the title the user selected.
 * Neither the main-track probe (largest VTS / longest playlist) nor the per-VTS
 * index describes the selected title: the dvdvideo demuxer numbers titles
 * globally by PGC, so on discs where one VTS holds several titles the VTS index
 * points at a different clip (MC.14.22: VTS_03 is the 53:55 feature, but
 * dvdvideo title 3 is a 1.1 s clip and the feature is title 4).
 *
 * Reusing the largest VTS's byte size as the expectation is what made a correct
 * 20.9 s / 5.3 MB remux fail validation against a 2009 MB baseline.
 */

function isPositive(value: number | null | undefined): value is number {
  return typeof value === "number" && Number.isFinite(value) && value > 0;
}

export type DiscRemuxSizeInput = {
  /** True when the job carries a task snapshot that names the selected title. */
  hasTaskSnapshot: boolean;
  /** Byte size carried by the task snapshot / selection plan for that title. */
  selectedTitleSizeBytes?: number | null;
  /** Byte size estimate from the analysed title for that title. */
  selectedAnalysisEstimatedSize?: number | null;
  /** Byte size of the disc-resolved largest title (legacy jobs only). */
  resolvedMainTitleSizeBytes?: number | null;
};

/**
 * Expected remux output size, or null to skip the size check.
 *
 * With a task snapshot only the selected title's own size may be used; the
 * largest VTS may belong to a different title, so it is never substituted.
 * Legacy jobs (no snapshot) keep the previous behaviour and use the resolved
 * title's size.
 */
export function expectedRemuxSizeBytes(
  input: DiscRemuxSizeInput,
): number | null {
  if (input.hasTaskSnapshot) {
    if (isPositive(input.selectedTitleSizeBytes))
      return input.selectedTitleSizeBytes;
    if (isPositive(input.selectedAnalysisEstimatedSize))
      return input.selectedAnalysisEstimatedSize;
    return null;
  }
  return isPositive(input.resolvedMainTitleSizeBytes)
    ? input.resolvedMainTitleSizeBytes
    : null;
}

/**
 * A HandBrake/DVDVideo title number is a logical playlist/PGC number.  A
 * VTS number is a physical file group.  They are only interchangeable when
 * the numbers are explicitly equal; otherwise using the largest VTS as a
 * concat fallback can produce a valid MKV for the wrong programme.
 */
export function canUsePhysicalDvdVobFallback(input: {
  requestedLogicalTitleNumber: number | null | undefined;
  physicalVtsNumber: number | null | undefined;
  /** True only when analysis matched this logical title to this VTS by evidence. */
  mappingConfirmed?: boolean;
}): boolean {
  return (
    Number.isInteger(input.requestedLogicalTitleNumber) &&
    Number(input.requestedLogicalTitleNumber) > 0 &&
    Number.isInteger(input.physicalVtsNumber) &&
    (Number(input.physicalVtsNumber) ===
      Number(input.requestedLogicalTitleNumber) ||
      input.mappingConfirmed === true)
  );
}

/**
 * Whether a disc job may adopt the main-track probe duration.
 *
 * The probe resolves the largest VTS / longest playlist, which is a different
 * title whenever the job selected something else. Jobs with a task snapshot must
 * therefore never fall back to it; when the selected duration is unknown they
 * keep a null duration and the validation skips its drift check.
 */
export function mayAdoptMainTrackProbeDuration(input: {
  mediaType: string | null | undefined;
  hasTaskSnapshot: boolean;
}): boolean {
  const isDisc =
    input.mediaType === "dvd" ||
    input.mediaType === "bluray" ||
    input.mediaType === "iso";
  return !(isDisc && input.hasTaskSnapshot);
}
