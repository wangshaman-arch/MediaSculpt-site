import { cn } from "@/lib/utils";

export function AssistantChip({
  active,
  label,
  onClick,
  disabled = false,
  amber = false,
  title,
  className,
}: {
  active: boolean;
  label: string;
  onClick: () => void;
  disabled?: boolean;
  amber?: boolean;
  title?: string;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      title={title}
      className={cn(
        "inline-flex h-7 shrink-0 items-center justify-center rounded-md border px-2.5 text-[11px] leading-none transition-colors disabled:cursor-not-allowed",
        className,
        disabled
          ? "border-border/40 text-muted-foreground/40"
          : amber
            ? active
              ? "border-amber-400/60 bg-amber-400/20 text-foreground"
              : "border-amber-400/50 text-foreground hover:border-amber-400/70 hover:bg-amber-400/5"
            : active
              ? "border-primary/60 bg-primary/20 text-primary"
              : "border-border/70 text-muted-foreground hover:border-primary/50 hover:text-foreground",
      )}
    >
      <span className="block w-full truncate">{label}</span>
    </button>
  );
}
