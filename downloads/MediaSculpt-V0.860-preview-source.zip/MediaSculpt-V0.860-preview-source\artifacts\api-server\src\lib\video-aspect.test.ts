import { describe, expect, it } from "vitest";
import { playResFromVideoStreams } from "./video-aspect";

describe("video aspect ratio to ASS canvas", () => {
  it("uses the display aspect ratio for anamorphic DVD video", () => {
    expect(
      playResFromVideoStreams([
        {
          codecType: "video",
          width: 720,
          height: 480,
          sampleAspectRatio: "32:27",
          displayAspectRatio: "16:9",
        },
      ]),
    ).toEqual({ playResX: 512, playResY: 288 });
  });

  it("derives display ratio from sample aspect ratio when DAR is absent", () => {
    expect(
      playResFromVideoStreams([
        {
          codecType: "video",
          width: 720,
          height: 480,
          sampleAspectRatio: "32:27",
        },
      ]),
    ).toEqual({ playResX: 512, playResY: 288 });
  });

  it("ignores attached cover art and rejects unusable geometry", () => {
    expect(
      playResFromVideoStreams([
        {
          codecType: "video",
          attachedPicture: true,
          width: 1000,
          height: 1000,
        },
        {
          codecType: "video",
          width: 720,
          height: 576,
          sampleAspectRatio: "16:15",
          displayAspectRatio: "4:3",
        },
      ]),
    ).toEqual({ playResX: 384, playResY: 288 });
    expect(
      playResFromVideoStreams([{ codecType: "video", width: 0, height: 0 }]),
    ).toBeNull();
  });
});
