import { describe, expect, it } from "vitest";
import { resolveAssistantImdbId } from "./assistant-identity";

describe("resolveAssistantImdbId", () => {
  it("keeps the id from a cache hit, where no provider lookup ran", () => {
    // The sidecar holds tt0060176, so the lookup block is skipped and only
    // metadataBest is populated. This case used to return null, which dropped
    // the IMDb id from the analysis response and lost the panel back-fill.
    expect(
      resolveAssistantImdbId({
        imdbIdInput: "",
        metadataBest: { imdbId: "tt0060176" },
        lookup: null,
      }),
    ).toBe("tt0060176");
  });

  it("prefers an entered id, then the cached record, then the fresh lookup", () => {
    expect(
      resolveAssistantImdbId({
        imdbIdInput: "tt0000001",
        metadataBest: { imdbId: "tt0060176" },
        lookup: { imdbId: "tt9999999" },
      }),
    ).toBe("tt0000001");
    expect(
      resolveAssistantImdbId({
        imdbIdInput: "   ",
        metadataBest: { imdbId: " tt0060176 " },
        lookup: { imdbId: "tt9999999" },
      }),
    ).toBe("tt0060176");
    expect(resolveAssistantImdbId({ lookup: { imdbId: "tt0060176" } })).toBe(
      "tt0060176",
    );
  });

  it("returns null when nothing supplied an id", () => {
    expect(resolveAssistantImdbId({})).toBeNull();
    expect(
      resolveAssistantImdbId({
        imdbIdInput: "",
        metadataBest: { imdbId: null },
        lookup: { imdbId: "  " },
      }),
    ).toBeNull();
  });
});
