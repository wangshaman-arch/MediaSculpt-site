export type RemuxChapter = {
  id: number;
  startSeconds: number;
  endSeconds: number;
  title?: string | null;
};

export type RemuxChapterSelection = {
  mode: "all" | "range" | "selected";
  start?: number | null;
  end?: number | null;
  chapterIds?: string[];
};

/** Resolve the immutable task selection into verified source chapter ids. */
export function resolveRemuxChapterIds(
  chapters: RemuxChapter[],
  selection: RemuxChapterSelection,
): number[] {
  if (selection.mode === "all") return chapters.map((chapter) => chapter.id);
  if (selection.mode === "range") {
    const start = selection.start ?? 1;
    const end = selection.end ?? Number.MAX_SAFE_INTEGER;
    return chapters
      .filter((chapter) => chapter.id >= start && chapter.id <= end)
      .map((chapter) => chapter.id);
  }

  const requested = (selection.chapterIds ?? []).map((value) => {
    const match = /^chapter:(\d+)$/.exec(value);
    if (!match) throw new Error(`章节选择包含无效的章节 ID：${value}`);
    return Number(match[1]);
  });
  const available = new Set(chapters.map((chapter) => chapter.id));
  if (requested.some((id) => !available.has(id))) {
    throw new Error("章节选择引用了不存在的章节");
  }
  return requested;
}

export function buildSelectedChapterMetadata(
  chapters: RemuxChapter[],
  selectedIds: number[],
): string | null {
  const selected = chapters.filter((chapter) =>
    selectedIds.includes(chapter.id),
  );
  if (selected.length === 0) return null;
  const lines = [";FFMETADATA1"];
  for (const chapter of selected) {
    const sourceOrdinal = chapters.indexOf(chapter) + 1;
    lines.push(
      "[CHAPTER]",
      "TIMEBASE=1/1000",
      `START=${Math.round(chapter.startSeconds * 1000)}`,
      `END=${Math.round(chapter.endSeconds * 1000)}`,
      `title=${(chapter.title ?? `Chapter ${sourceOrdinal}`).replace(/[\\\n\r=;]/g, " ")}`,
    );
  }
  return `${lines.join("\n")}\n`;
}
