import { describe, expect, it } from "vitest";
import {
  buildTuningLogicContext,
  logicParam,
  logicValue,
  parseCustomTuning,
  resolveLogicPlaceholders,
} from "./custom-tuning";

describe("custom tuning parameter table (V 0.826+)", () => {
  it("migrates the old fixed-field object shape into a parameter table", () => {
    const tuning = parseCustomTuning(
      JSON.stringify({
        prompts: { analysis: "custom-analysis" },
        logic: { documentaryGbPer50min: 3, movieGb: 10 },
      }),
    );
    expect(tuning.prompts.analysis).toBe("custom-analysis");
    expect(tuning.logic.parameters.length).toBe(6);
    expect(logicValue(tuning.logic, "documentaryGbPer50min", 2)).toBe(3);
    expect(logicValue(tuning.logic, "movieGb", 8)).toBe(10);
    expect(logicValue(tuning.logic, "h265Ratio", 0.7)).toBe(0.7);
  });

  it("keeps user-added custom parameters and validates the new shape", () => {
    const tuning = parseCustomTuning(
      JSON.stringify({
        prompts: {},
        logic: {
          parameters: [
            {
              key: "subtitlePreference",
              label: "字幕偏好",
              value: "中文优先",
              kind: "text",
              default: "中文优先",
              custom: true,
            },
            {
              key: "movieGb",
              value: 12,
              kind: "number",
              min: 2,
              max: 20,
              step: 0.5,
              default: 8,
              custom: false,
            },
          ],
        },
      }),
    );
    expect(tuning.logic.parameters).toHaveLength(2);
    expect(logicValue(tuning.logic, "subtitlePreference", "fallback")).toBe(
      "中文优先",
    );
    expect(logicValue(tuning.logic, "movieGb", 8)).toBe(12);
    expect(logicParam(tuning.logic, "subtitlePreference")?.custom).toBe(true);
  });

  it("falls back to built-in defaults when a built-in parameter was deleted", () => {
    const tuning = parseCustomTuning(
      JSON.stringify({
        prompts: {},
        logic: {
          parameters: [
            {
              key: "movieGb",
              value: 9,
              kind: "number",
              default: 8,
              custom: false,
            },
          ],
        },
      }),
    );
    expect(logicParam(tuning.logic, "documentaryGbPer50min")).toBeUndefined();
    expect(logicValue(tuning.logic, "documentaryGbPer50min", 2)).toBe(2);
    expect(logicValue(tuning.logic, "movieGb", 8)).toBe(9);
  });

  it("rejects invalid parameter rows but keeps valid ones", () => {
    const tuning = parseCustomTuning(
      JSON.stringify({
        prompts: {},
        logic: {
          parameters: [
            { value: 1, kind: "number", default: 1, custom: true },
            {
              key: "okParam",
              value: "ok",
              kind: "text",
              default: "ok",
              custom: true,
            },
            "not-an-object",
          ],
        },
      }),
    );
    expect(tuning.logic.parameters.map((param) => param.key)).toEqual([
      "okParam",
    ]);
  });

  it("resolves {{logic.<key>}} placeholders and leaves unknown keys untouched", () => {
    const tuning = parseCustomTuning(
      JSON.stringify({
        prompts: {},
        logic: {
          parameters: [
            {
              key: "movieGb",
              value: 8,
              kind: "number",
              default: 8,
              custom: false,
            },
          ],
        },
      }),
    );
    const resolved = resolveLogicPlaceholders(
      "电影阈值 {{logic.movieGb}} GB，未知 {{logic.nope}}",
      tuning.logic,
    );
    expect(resolved).toBe("电影阈值 8 GB，未知 {{logic.nope}}");
  });

  it("builds a readable LLM context block with labels and units", () => {
    const tuning = parseCustomTuning(
      JSON.stringify({
        prompts: {},
        logic: {
          parameters: [
            {
              key: "documentaryGbPer50min",
              value: 2,
              kind: "number",
              unit: "GB",
              default: 2,
              custom: false,
            },
            {
              key: "subtitlePreference",
              label: "字幕偏好",
              value: "中文优先",
              kind: "text",
              default: "中文优先",
              custom: true,
            },
          ],
        },
      }),
    );
    const context = buildTuningLogicContext(tuning.logic);
    expect(context).toContain("纪录片容量基准：2 GB");
    expect(context).toContain("字幕偏好：中文优先");
  });
});
