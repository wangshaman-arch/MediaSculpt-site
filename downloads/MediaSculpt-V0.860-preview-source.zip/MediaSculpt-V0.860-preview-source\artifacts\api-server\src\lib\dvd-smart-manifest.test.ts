import { describe, expect, it, vi } from "vitest";
import type { DiscAnalysisResult } from "./disc-analysis";
import type { ExternalToolRunner } from "./dvd-remux";
import { buildDvdSmartManifest } from "./dvd-smart-manifest";

function analysis(): DiscAnalysisResult {
  const makeTitle = (number: number, durationSeconds: number) => ({
    titleId: `handbrake:${number}`,
    titleUid: `uid-${number}`,
    titleIndex: number - 1,
    sourcePath: "D:\\DVD",
    displayName: `Title ${number}`,
    durationSeconds,
    chapterCount: 1,
    chapters: [
      { id: 0, startSeconds: 0, endSeconds: durationSeconds, title: null },
    ],
    videoTracks: [
      {
        index: 0,
        codecType: "video" as const,
        codecName: "mpeg2video",
        language: null,
        title: null,
        width: 720,
        height: 576,
        frameRate: "25/1",
      },
    ],
    audioTracks: [],
    subtitleTracks: [],
    estimatedSize: null,
    streams: [
      {
        index: 0,
        codecType: "video" as const,
        codecName: "mpeg2video",
        language: null,
        title: null,
        width: 720,
        height: 576,
        frameRate: "25/1",
      },
    ],
    toolMappings: {
      handbrakeTitleNumber: number,
      makemkvTitleIndex: null,
      dvdVtsNumber: null,
      physicalVtsNumber: null,
    },
    mappingStatus: "not-required" as const,
    availabilityStatus: "confirmed" as const,
  });
  return {
    analysisId: "analysis-1",
    sourcePath: "D:\\DVD",
    sourceFingerprint: "fingerprint",
    sourceSizeBytes: 9_000,
    mediaType: "dvd",
    createdAt: new Date().toISOString(),
    titles: [makeTitle(1, 3600), makeTitle(2, 3599), makeTitle(3, 3601)],
    exportCandidates: [],
    diagnostics: [],
    diagnosticLogPath: null,
    warnings: [],
  };
}

const probe = JSON.stringify({
  streams: [{ index: 0, codec_type: "video", codec_name: "mpeg2video" }],
  chapters: [{ id: 0, start_time: "0", end_time: "3600" }],
  format: { duration: "3600" },
});

describe("buildDvdSmartManifest", () => {
  it("selects every independently readable long title and exposes one shared selection map", async () => {
    const independentAnalysis = analysis();
    independentAnalysis.titles.forEach((title, index) => {
      title.toolMappings.physicalVtsNumber = index + 1;
    });
    const timestampProbe = JSON.stringify({
      packets: [
        { pts_time: "0", dts_time: "0" },
        { pts_time: "0.04", dts_time: "0.04" },
      ],
    });
    const run = vi.fn(async (request) =>
      request.tool === "ffprobe"
        ? {
            tool: request.tool,
            executable: request.executable,
            args: request.args,
            exitCode: 0,
            stdout: request.args.includes("-show_packets")
              ? timestampProbe
              : probe,
            stderr: "",
            durationMs: 1,
            failureReason: null,
          }
        : {
            tool: request.tool,
            executable: request.executable,
            args: request.args,
            exitCode: 0,
            stdout: "frame=12\nout_time_ms=4000000\nprogress=end\n",
            stderr: "",
            durationMs: 1,
            failureReason: null,
          },
    ) as ExternalToolRunner;
    const result = await buildDvdSmartManifest({
      analysis: independentAnalysis,
      ffprobeExecutable: "ffprobe.exe",
      ffmpegExecutable: "ffmpeg.exe",
      run,
      vtsSizes: new Map(),
    });
    expect(result.selectedTitleIds).toEqual([
      "handbrake:1",
      "handbrake:2",
      "handbrake:3",
    ]);
    expect(result.selectedStreamsByTitle).toEqual({
      "handbrake:1": [0],
      "handbrake:2": [0],
      "handbrake:3": [0],
    });
    expect(
      result.candidates.every((candidate) => candidate.status === "selected"),
    ).toBe(true);
    expect(run).toHaveBeenCalledTimes(15);
  });

  it("deduplicates long titles that point to the same physical VTS group", async () => {
    const duplicateAnalysis = analysis();
    duplicateAnalysis.titles.forEach((title) => {
      title.toolMappings.physicalVtsNumber = 3;
    });
    const timestampProbe = JSON.stringify({
      packets: [
        { pts_time: "0", dts_time: "0" },
        { pts_time: "0.04", dts_time: "0.04" },
      ],
    });
    const run = vi.fn(async (request) =>
      request.tool === "ffprobe"
        ? {
            tool: request.tool,
            executable: request.executable,
            args: request.args,
            exitCode: 0,
            stdout: request.args.includes("-show_packets")
              ? timestampProbe
              : probe,
            stderr: "",
            durationMs: 1,
            failureReason: null,
          }
        : {
            tool: request.tool,
            executable: request.executable,
            args: request.args,
            exitCode: 0,
            stdout: "frame=12\nout_time_ms=4000000\nprogress=end\n",
            stderr: "",
            durationMs: 1,
            failureReason: null,
          },
    ) as ExternalToolRunner;

    const result = await buildDvdSmartManifest({
      analysis: duplicateAnalysis,
      ffprobeExecutable: "ffprobe.exe",
      ffmpegExecutable: "ffmpeg.exe",
      run,
      vtsSizes: new Map([[3, 9_000]]),
    });

    expect(result.selectedTitleIds).toEqual(["handbrake:1"]);
    expect(
      result.candidates.filter((candidate) => candidate.status === "duplicate"),
    ).toHaveLength(2);
    expect(result.capacity.countedPhysicalBytes).toBe(9_000);
  });

  it("never treats a logical dvdvideo title number as a physical VTS mapping", async () => {
    const logicalOnlyAnalysis = analysis();
    logicalOnlyAnalysis.titles.forEach((title, index) => {
      title.toolMappings.dvdVtsNumber = index + 7;
    });
    const timestampProbe = JSON.stringify({
      packets: [
        { pts_time: "0", dts_time: "0" },
        { pts_time: "0.04", dts_time: "0.04" },
      ],
    });
    const run = vi.fn(async (request) =>
      request.tool === "ffprobe"
        ? {
            tool: request.tool,
            executable: request.executable,
            args: request.args,
            exitCode: 0,
            stdout: request.args.includes("-show_packets")
              ? timestampProbe
              : probe,
            stderr: "",
            durationMs: 1,
            failureReason: null,
          }
        : {
            tool: request.tool,
            executable: request.executable,
            args: request.args,
            exitCode: 0,
            stdout: "frame=12\nout_time_ms=4000000\nprogress=end\n",
            stderr: "",
            durationMs: 1,
            failureReason: null,
          },
    ) as ExternalToolRunner;

    const result = await buildDvdSmartManifest({
      analysis: logicalOnlyAnalysis,
      ffprobeExecutable: "ffprobe.exe",
      ffmpegExecutable: "ffmpeg.exe",
      run,
      vtsSizes: new Map([
        [7, 9_000],
        [8, 9_000],
        [9, 9_000],
      ]),
    });

    expect(result.selectedTitleIds).toEqual(["handbrake:3"]);
    expect(result.capacity.countedPhysicalBytes).toBe(0);
    expect(result.requiresUserSelection).toBe(true);
  });
});
