import {
  resolveAiEndpoint,
  resolveApiKey,
  type AiEndpoint,
} from "./ai-provider";
import type { configTable } from "@workspace/db";
import type { DiscAnalysisResult } from "./disc-analysis";

/** AI 配置（与其它 AI 调用一致）。 */
export type DvdLlmConfig = Parameters<typeof resolveApiKey>[0];

const SYSTEM = `你是高端影音封装专家，负责在"离线确定性解析难以判断"的复杂光碟上，从给出的真实结构里挑选正确的 remux 方案。

要求：
- payload 是这张光碟由 ffprobe/HandBrake 直接读到的<b>真实结构</b>（每个标题的时长、轨道、流的绝对 index）。
- 只能引用 payload 中<b>真实存在的</b>绝对流 index；绝不能虚构流或编造 index。
- 正片通常是<b>最长且内容完整</b>的那个标题；若存在多个时长接近的正片候选，结合下述信息与常识判断。
- 音轨要按原始顺序输出，保留语言合理性；字幕轨通常全部无损保留，必要时可指定一条用 start 烧录(burn)。
- 只输出 JSON，不要任何解释、不要 markdown 代码块。

JSON 格式（数字均为该标题内的绝对流 index）：
{
  "titleId": "handbrake:6",
  "confidence": "high|medium|low",
  "reason": "简短中文理由",
  "video": 6,
  "audio": [7, 9],
  "subtitles": [8, 10],
  "burn": 8
}`;

/** 把光盘真实结构压缩成紧凑 JSON，作为 LLM 的输入（喂的是真实数据，不是任一工具的表述）。 */
export function buildDvdStructurePayload(analysis: DiscAnalysisResult): string {
  const titles = (analysis.titles ?? []).map((title) => ({
    id: title.titleId,
    name: title.displayName,
    seconds: title.durationSeconds,
    chapters: title.chapterCount,
    vts: title.toolMappings?.dvdVtsNumber,
    handbrake: title.toolMappings?.handbrakeTitleNumber,
    video: (title.videoTracks ?? []).map((s) => ({
      i: s.index,
      codec: s.codecName,
      res: `${s.width}x${s.height}`,
      fps: s.frameRate,
      lang: s.language,
      def: s.default,
      forced: s.forced,
    })),
    audio: (title.audioTracks ?? []).map((s) => ({
      i: s.index,
      codec: s.codecName,
      ch: s.channels ?? s.channelLayout,
      lang: s.language,
      def: s.default,
    })),
    subtitle: (title.subtitleTracks ?? []).map((s) => ({
      i: s.index,
      codec: s.codecName,
      lang: s.language,
      forced: s.forced,
      def: s.default,
    })),
  }));
  return JSON.stringify({
    mediaType: analysis.mediaType,
    sourcePath: analysis.sourcePath,
    titles,
  });
}

export type RemuxPlan = {
  titleId: string;
  confidence?: "high" | "medium" | "low";
  reason?: string;
  video?: number;
  audio?: number[];
  subtitles?: number[];
  burn?: number | null;
};

export type NormalizedRemuxPlan = {
  titleId: string;
  durationSeconds: number | null;
  videoIndex: number | null;
  audioIndices: number[];
  subtitleIndices: number[];
  burnSubtitleIndex: number | null;
  reason: string;
  confidence: "high" | "medium" | "low";
};

function outputMode(endpoint: AiEndpoint): string {
  return endpoint.model.startsWith("gpt") ||
    endpoint.model.startsWith("deepseek")
    ? "json"
    : "text";
}

/** 调用 LLM 解析复杂光盘的 remux 方案。无 Key/失败时返回 null（由调用方回退确定性路径）。 */
export async function resolveRemuxPlanWithLlm(input: {
  structure: string;
  config: DvdLlmConfig;
  language?: string;
}): Promise<RemuxPlan | null> {
  const endpoint = resolveAiEndpoint(input.config);
  const apiKey = resolveApiKey(input.config);
  if (!apiKey) return null;

  const user = [
    `界面语言：${input.language ?? "zh-CN"}`,
    `要求：无损 remux（视频流复制 + 按序保留音频 + 无损保留字幕轨，可按需烧录一条）。`,
    `payload：\n${input.structure}`,
  ].join("\n");

  const body: Record<string, unknown> = {
    model: endpoint.model,
    temperature: 0.1,
    max_tokens: 900,
    messages: [
      { role: "system", content: SYSTEM },
      { role: "user", content: user },
    ],
  };
  if (outputMode(endpoint) === "json") {
    body.response_format = { type: "json_object" };
  }

  const response = await fetch(
    `${endpoint.baseUrl.replace(/\/$/, "")}/chat/completions`,
    {
      method: "POST",
      signal: AbortSignal.timeout(30_000),
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    },
  );
  const payload = (await response.json().catch(() => ({}))) as {
    choices?: Array<{ message?: { content?: unknown } }>;
    error?: { message?: string };
  };
  if (!response.ok)
    throw new Error(
      `LLM 返回 HTTP ${response.status}${payload.error?.message ? `：${payload.error.message}` : ""}`,
    );

  const content =
    typeof payload.choices?.[0]?.message?.content === "string"
      ? payload.choices[0].message.content
      : "";
  if (!content) return null;

  const jsonStr = content.replace(/```(?:json)?/gi, "").trim();
  const start = jsonStr.indexOf("{");
  const end = jsonStr.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    const parsed = JSON.parse(
      jsonStr.slice(start, end + 1),
    ) as Partial<RemuxPlan>;
    if (typeof parsed.titleId !== "string" || !parsed.titleId.trim())
      return null;
    return {
      titleId: parsed.titleId.trim(),
      confidence: parsed.confidence ?? "medium",
      reason: typeof parsed.reason === "string" ? parsed.reason : "",
      video: typeof parsed.video === "number" ? parsed.video : undefined,
      audio: Array.isArray(parsed.audio)
        ? parsed.audio.filter((x): x is number => typeof x === "number")
        : undefined,
      subtitles: Array.isArray(parsed.subtitles)
        ? parsed.subtitles.filter((x): x is number => typeof x === "number")
        : undefined,
      burn:
        typeof parsed.burn === "number"
          ? parsed.burn
          : parsed.burn == null
            ? null
            : undefined,
    };
  } catch {
    return null;
  }
}

/**
 * 用真实流集合校验/裁剪 LLM 方案：只保留真实存在的流索引；无效引用丢弃。
 * 若选中的标题不存在、视频流无效 → 判不可用（由调用方回退确定性）。
 */
export function validateRemuxPlan(
  plan: RemuxPlan,
  analysis: DiscAnalysisResult,
): { ok: boolean; plan: NormalizedRemuxPlan | null; reason?: string } {
  const title = (analysis.titles ?? []).find((t) => t.titleId === plan.titleId);
  if (!title)
    return {
      ok: false,
      plan: null,
      reason: `选中的标题不存在：${plan.titleId}`,
    };
  if (
    analysis.mediaType === "dvd" &&
    title.availabilityStatus === "unavailable"
  ) {
    return {
      ok: false,
      plan: null,
      reason: `选中的标题无法读取实际视频数据：${plan.titleId}`,
    };
  }

  const video = (title.videoTracks ?? []).find((s) => s.index === plan.video);
  if (!video)
    return {
      ok: false,
      plan: null,
      reason: `视频流 ${plan.video} 在标题 ${plan.titleId} 中不存在`,
    };

  const audioMap = new Map((title.audioTracks ?? []).map((s) => [s.index, s]));
  const chosenAudio = (plan.audio ?? []).filter((i) => audioMap.has(i));
  // 音轨全部无效则回退为保留全部音轨（无损 remux 本就复制全部）。
  const audioIndices =
    chosenAudio.length > 0
      ? chosenAudio
      : (title.audioTracks ?? []).map((s) => s.index);
  const audioSet = new Set(audioIndices);

  const subtitleMap = new Map(
    (title.subtitleTracks ?? []).map((s) => [s.index, s]),
  );
  const chosenSubs = (plan.subtitles ?? []).filter((i) => subtitleMap.has(i));
  const subtitleIndices =
    chosenSubs.length > 0
      ? chosenSubs
      : (title.subtitleTracks ?? []).map((s) => s.index);

  const burn =
    plan.burn != null && subtitleMap.has(plan.burn) ? plan.burn : null;
  // 烧录字幕建议为音轨子集合理性检查：烧录轨必须保留。
  const burnValid = burn !== null ? subtitleIndices.includes(burn) : true;

  return {
    ok: true,
    plan: {
      titleId: title.titleId,
      durationSeconds: title.durationSeconds,
      videoIndex: video.index,
      audioIndices: [...audioSet],
      subtitleIndices,
      burnSubtitleIndex: burnValid ? burn : null,
      reason: plan.reason ?? "",
      confidence: plan.confidence ?? "medium",
    },
  };
}
