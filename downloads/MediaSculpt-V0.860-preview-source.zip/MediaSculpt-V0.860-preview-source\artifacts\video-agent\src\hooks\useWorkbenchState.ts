import { useCallback, useEffect, useState } from "react";
import { toHostPath } from "../lib/utils";

export type WorkbenchTab = "workflow" | "compress" | "none" | "remux";
export type ProcessingMode = "compress" | "none" | "remux";
export type SubtitleMode =
  | "auto"
  | "ocr"
  | "extract"
  | "whisper"
  | "transcribe_translate"
  | "skip"
  | "bilingual";

export const WORKBENCH_TABS: WorkbenchTab[] = [
  "workflow",
  "compress",
  "none",
  "remux",
];

export interface WorkbenchPathConfig {
  watchDirectory?: string;
  outputDirectory?: string;
  hostDownloadsPath?: string | null;
  hostOutputPath?: string | null;
}

export function getInitialWorkbenchTab(location: string): WorkbenchTab {
  const search = location.includes("?") ? location.split("?")[1] : "";
  const requested = new URLSearchParams(search).get("tab");
  return requested === "compress" ||
    requested === "none" ||
    requested === "remux"
    ? requested
    : "workflow";
}

export function resolveWorkbenchDirectory(
  config: WorkbenchPathConfig | null | undefined,
): string {
  if (!config?.watchDirectory) return "/media/downloads";
  return toHostPath(config.watchDirectory, config) || config.watchDirectory;
}

export function selectWorkbenchTab(
  tab: WorkbenchTab,
  subtitleMode: SubtitleMode,
): { tab: WorkbenchTab; subtitleMode: SubtitleMode } {
  if (tab === "remux") return { tab, subtitleMode: "skip" };
  if (tab === "none" && subtitleMode === "skip")
    return { tab, subtitleMode: "auto" };
  return { tab, subtitleMode };
}

export function useWorkbenchState(input: {
  location: string;
  config?: WorkbenchPathConfig | null;
}) {
  const [tab, setTab] = useState<WorkbenchTab>(() =>
    getInitialWorkbenchTab(input.location),
  );
  const [subtitleMode, setSubtitleMode] = useState<SubtitleMode>("skip");
  const [directory, setDirectory] = useState("/media/downloads");
  const [browseCreated, setBrowseCreated] = useState(0);

  const configuredWatchDirectory = input.config?.watchDirectory;
  useEffect(() => {
    if (configuredWatchDirectory) {
      setDirectory(resolveWorkbenchDirectory(input.config));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [configuredWatchDirectory]);

  const selectTab = useCallback(
    (next: WorkbenchTab) => {
      const selection = selectWorkbenchTab(next, subtitleMode);
      setTab(selection.tab);
      setSubtitleMode(selection.subtitleMode);
    },
    [subtitleMode],
  );

  return {
    tab,
    setTab,
    subtitleMode,
    setSubtitleMode,
    directory,
    setDirectory,
    browseCreated,
    setBrowseCreated,
    watchDir: input.config ? resolveWorkbenchDirectory(input.config) : "",
    selectTab,
  };
}
