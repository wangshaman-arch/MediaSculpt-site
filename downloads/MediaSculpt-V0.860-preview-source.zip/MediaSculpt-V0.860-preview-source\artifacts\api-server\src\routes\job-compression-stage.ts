import fsSync from "fs";
import path from "path";
import fs from "fs/promises";
import { db, jobsTable, configTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { buildCompressionArgsForJob } from "../media/compression-pipeline";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { mapExternalToolProgress } from "../lib/job-workflow";
import { appendJobToolOutput } from "../lib/job-runtime-log";
import { resolveToolPath } from "../lib/tool-runtime";
import { ffmpegPath } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput } from "../infrastructure/process-runner";
import type { TaskSnapshotV1 } from "../lib/task-snapshot";
import type { ResolvedJob } from "./job-media-input-context";
import type { WorkflowPipelineStep } from "./jobs-pipeline";
import type { UnifiedDiscTitle } from "../lib/disc-analysis";
import { addLog } from "../lib/job-logging";
import { discAnalysisRegistry } from "../lib/disc-analysis-registry";
import { settlePreviewTaskSafely } from "../lib/preview-runtime";
import { cancelledJobs } from "./jobs-tracking";
import { detectInterlacedFromStreams, probeStreams } from "./jobs-probe";
import {
  fixAssPlayResForOutput,
  stageSubtitleSidecars,
} from "./jobs-subtitle-sidecars";
import { SUBTITLE_FILE_EXT_RE } from "./jobs-subtitle-files";
import { validateCompressionOutput } from "./job-encoding";

export type CompressionStageInput = {
  jobId: number;
  job: ResolvedJob;
  config: typeof configTable.$inferSelect;
  taskSnapshot: TaskSnapshotV1 | null;
  pipelineSteps: WorkflowPipelineStep[];
  pipelineHasCompress: boolean;
  pipelineHasSubtitle: boolean;
  pipelineRemuxOutputPath: string | null;
  handbrakeInputPath: string;
  outputFile: string;
  compressionBaseName: string;
  subtitleStageBaseName: string;
  subtitleDirJob: string;
  sourceSubtitleFile: string | null;
  subtitlePath: string | null;
  translatedSubtitlePath: string | null;
  graphicSubtitlePaths: string[];
  selectedAnalysisTitle: UnifiedDiscTitle | undefined;
  temporaryRemuxPath: string | null;
};

export async function runCompressionStage(
  input: CompressionStageInput,
): Promise<{ shouldReturn: boolean }> {
  const {
    jobId,
    job,
    config,
    taskSnapshot,
    pipelineSteps,
    pipelineHasCompress,
    pipelineHasSubtitle,
    pipelineRemuxOutputPath,
    outputFile,
    compressionBaseName,
    subtitleStageBaseName,
    subtitleDirJob,
    sourceSubtitleFile,
    subtitlePath,
    translatedSubtitlePath,
    graphicSubtitlePaths,
    selectedAnalysisTitle,
    temporaryRemuxPath,
  } = input;
  let handbrakeInputPath = input.handbrakeInputPath;

  if (pipelineRemuxOutputPath) {
    handbrakeInputPath = pipelineRemuxOutputPath;
    await addLog(
      jobId,
      "info",
      `流水线：压缩阶段基于 Remux 输出 — ${pipelineRemuxOutputPath}`,
    );
  }

  // 流水线未选择压缩步骤时（如 仅 Remux+字幕），在 Remux/字幕完成后结束任务。
  const shouldRunCompression =
    pipelineSteps.length === 0
      ? job.processingMode === "compress"
      : pipelineHasCompress;
  if (cancelledJobs.has(jobId)) {
    if (pipelineRemuxOutputPath)
      await fs.rm(pipelineRemuxOutputPath, { force: true }).catch(() => {});
    return { shouldReturn: true };
  }
  if (!shouldRunCompression) {
    await db
      .update(jobsTable)
      .set({
        status: "done",
        progress: 100,
        ...(pipelineRemuxOutputPath
          ? { outputPath: pipelineRemuxOutputPath }
          : {}),
        subtitlePath: sourceSubtitleFile ?? subtitlePath,
        translatedSubtitlePath,
        completedAt: new Date(),
      })
      .where(eq(jobsTable.id, jobId));
    await addLog(
      jobId,
      "info",
      `流水线任务完成（无压缩步骤）${pipelineRemuxOutputPath ? ` — 输出：${pipelineRemuxOutputPath}` : ""}`,
    );
    await settlePreviewTaskSafely(jobId, {
      taskKind: pipelineRemuxOutputPath ? "remux" : "subtitle",
      outputValid: Boolean(
        pipelineRemuxOutputPath ||
        sourceSubtitleFile ||
        subtitlePath ||
        translatedSubtitlePath,
      ),
      isPreviewOnly: false,
      cancelled: false,
    });
    return { shouldReturn: true };
  }

  const isDiscCompressionSource =
    job.processingMode === "compress" &&
    (job.mediaType === "dvd" ||
      job.mediaType === "bluray" ||
      job.mediaType === "iso");
  if (isDiscCompressionSource) {
    await addLog(
      jobId,
      "info",
      "光盘压缩模式 — HandBrake 直接分析 DVD/蓝光/ISO；FFmpeg 用于 Remux 无损封装",
    );
  }

  // 执行以任务快照的压缩参数为准（用户在智能助手/工作流里确认的参数），
  // 快照未指定的项（调优/配置/级别等）才回退到全局设置。
  const compressionConfig = {
    ...config,
    ...(taskSnapshot?.compression
      ? {
          encoder: taskSnapshot.compression.encoder ?? config.encoder,
          crf: taskSnapshot.compression.crf ?? config.crf,
          encoderPreset:
            taskSnapshot.compression.preset ?? config.encoderPreset,
          encoderTune:
            taskSnapshot.compression.encoderTune ?? config.encoderTune,
          encoderProfile:
            taskSnapshot.compression.encoderProfile ?? config.encoderProfile,
          encoderLevel:
            taskSnapshot.compression.encoderLevel ?? config.encoderLevel,
          outputResolution:
            taskSnapshot.compression.resolution ?? config.outputResolution,
          outputFormat:
            taskSnapshot.compression.outputFormat ?? config.outputFormat,
          audioCopy: taskSnapshot.compression.audioCopy ?? config.audioCopy,
          frameRate: taskSnapshot.compression.frameRate ?? config.frameRate,
          deinterlace:
            taskSnapshot.compression.deinterlace ?? config.deinterlace,
        }
      : {}),
  };

  const encSummary = [
    `编码器：${compressionConfig.encoder}`,
    `CRF：${compressionConfig.crf}`,
    `预设：${compressionConfig.encoderPreset || "medium"}`,
    compressionConfig.encoderTune && compressionConfig.encoderTune !== "none"
      ? `调优：${compressionConfig.encoderTune}`
      : null,
    compressionConfig.encoderProfile &&
    compressionConfig.encoderProfile !== "auto"
      ? `配置：${compressionConfig.encoderProfile}`
      : null,
    compressionConfig.encoderLevel && compressionConfig.encoderLevel !== "auto"
      ? `级别：${compressionConfig.encoderLevel}`
      : null,
    compressionConfig.outputResolution &&
    compressionConfig.outputResolution !== "source"
      ? `分辨率：${compressionConfig.outputResolution}`
      : "分辨率：保持原始",
    compressionConfig.frameRate !== "same"
      ? `帧率：${compressionConfig.frameRate}fps`
      : "帧率：保持原始",
  ]
    .filter(Boolean)
    .join("，");
  await addLog(jobId, "info", `正在压缩 — ${encSummary}`);

  const parsedHandBrakeSelectionPlan = parseHandBrakeSelectionPlan(
    job.selectionPlan,
  );
  const frozenHandBrakeTitleNumber =
    taskSnapshot?.toolSelections.handbrakeTitleNumber ??
    parsedHandBrakeSelectionPlan?.handbrake?.titleNumber ??
    null;
  if (
    job.mediaType === "dvd" &&
    !temporaryRemuxPath &&
    !pipelineRemuxOutputPath &&
    (typeof frozenHandBrakeTitleNumber !== "number" ||
      frozenHandBrakeTitleNumber <= 0)
  ) {
    throw new Error(
      "DVD 压缩缺少不可变任务快照中的 HandBrake 标题编号，拒绝回退到默认标题",
    );
  }
  const frozenSelectionPlan =
    parsedHandBrakeSelectionPlan &&
    job.mediaType === "dvd" &&
    !temporaryRemuxPath &&
    !pipelineRemuxOutputPath
      ? {
          ...parsedHandBrakeSelectionPlan,
          handbrake: {
            ...(parsedHandBrakeSelectionPlan.handbrake ?? {}),
            titleNumber: frozenHandBrakeTitleNumber,
          },
        }
      : parsedHandBrakeSelectionPlan;
  const handBrakeSelectionPlan =
    temporaryRemuxPath && taskSnapshot
      ? {
          version: 1 as const,
          video: parsedHandBrakeSelectionPlan?.video ?? [],
          audio: parsedHandBrakeSelectionPlan?.audio ?? [],
          subtitle: parsedHandBrakeSelectionPlan?.subtitle ?? [],
          chapters: parsedHandBrakeSelectionPlan?.chapters ?? [],
          handbrake: {
            audioTrackNumbers: taskSnapshot.streamSelection.audioTrackIds.map(
              (_, index) => index + 1,
            ),
            subtitleTrackNumbers:
              taskSnapshot.streamSelection.subtitleTrackIds.map(
                (_, index) => index + 1,
              ),
            chapterNumbers:
              parsedHandBrakeSelectionPlan?.handbrake?.chapterNumbers ?? [],
          },
        }
      : frozenSelectionPlan;
  // Deinterlace filter (yadif) — fixes horizontal line artifacts from
  // interlaced sources. Auto-detects interlaced video from the selected
  // title's media file; the manual setting can force it on as well.
  let deinterlace = compressionConfig.deinterlace === true;
  try {
    const deintAnalysis = taskSnapshot?.analysisId
      ? discAnalysisRegistry.find(taskSnapshot.analysisId)
      : undefined;
    const deintTitle = deintAnalysis?.titles.find(
      (candidate) => candidate.titleId === taskSnapshot?.selectedTitleId,
    );
    const probeTarget = deintTitle?.previewSourcePath ?? null;
    if (probeTarget) {
      const deintProbe = await probeStreams(probeTarget);
      if (detectInterlacedFromStreams(deintProbe.streams)) deinterlace = true;
    } else if (deintTitle?.videoTracks?.[0]?.frameRate) {
      const video = deintTitle.videoTracks[0];
      if (
        detectInterlacedFromStreams([
          {
            codecType: "video",
            frameRate: video.frameRate,
            height: video.height ?? null,
          },
        ])
      )
        deinterlace = true;
    }
  } catch {
    // Probe failed — keep the current decision.
  }
  if (deinterlace) {
    await addLog(
      jobId,
      "info",
      compressionConfig.deinterlace === true
        ? "已启用去隔行 (yadif)"
        : "检测到隔行源，已自动启用去隔行 (yadif)",
    );
  }

  const useCompressionManifest = Boolean(
    taskSnapshot &&
    taskSnapshot.outputMode === "compress" &&
    taskSnapshot.compressionSourceStrategy === "direct-disc" &&
    selectedAnalysisTitle &&
    !temporaryRemuxPath &&
    !pipelineRemuxOutputPath &&
    (job.mediaType === "dvd" ||
      job.mediaType === "bluray" ||
      job.mediaType === "iso"),
  );
  const compressionArguments = buildCompressionArgsForJob({
    snapshot: taskSnapshot,
    title: selectedAnalysisTitle ?? null,
    inputPath: handbrakeInputPath,
    outputPath: outputFile,
    config: compressionConfig,
    selectionPlan: handBrakeSelectionPlan,
    deinterlace,
    useManifest: useCompressionManifest,
  });
  const hbArgs = compressionArguments.args;
  const handBrakeSelectionArgs = compressionArguments.selectionArgs;
  if (compressionArguments.usedManifest) {
    await addLog(
      jobId,
      "info",
      "压缩参数来自已验证媒体清单：标题、音轨、字幕和章节选择已冻结",
    );
  } else {
    await addLog(
      jobId,
      "info",
      "压缩参数使用兼容旧任务路径：当前来源未满足已验证媒体清单条件",
    );
  }
  if (handBrakeSelectionArgs.length > 0) {
    await addLog(
      jobId,
      "info",
      `HandBrake 选择参数：${handBrakeSelectionArgs.join(" ")}`,
    );
  } else {
    await addLog(
      jobId,
      "info",
      "HandBrake 未收到精确流轨选择，使用默认全部音轨/全部字幕",
    );
  }

  if (
    job.mediaType === "dvd" &&
    !temporaryRemuxPath &&
    !pipelineRemuxOutputPath
  ) {
    if (!handBrakeSelectionArgs.includes("--title")) {
      throw new Error("DVD 压缩选择参数未包含所选 HandBrake 标题编号");
    }
    await addLog(
      jobId,
      "info",
      `HandBrake DVD 标题：Title ${frozenHandBrakeTitleNumber}（来自 selectedTitleId=${taskSnapshot?.selectedTitleId ?? "legacy-selection-plan"}）`,
    );
  }

  // Add external SRT if subtitle extraction/transcription was done in a prior job.
  // Guard against a transcription that reported success without writing a file
  // (e.g. Whisper on a clip with no audio) — HandBrake exits 3 on a missing SRT.
  if (subtitlePath && fsSync.existsSync(subtitlePath)) {
    hbArgs.push("--srt-file", ffmpegPath(subtitlePath), "--srt-default");
  } else if (subtitlePath) {
    await addLog(
      jobId,
      "warn",
      `字幕文件不存在，跳过 --srt-file：${subtitlePath}`,
    );
  }

  const hbCli =
    config.handbrakeCliPath ||
    (await resolveToolPath("handbrake")) ||
    "HandBrakeCLI";
  await addLog(jobId, "info", `HandBrakeCLI 参数: ${hbArgs.join(" ")}`);

  const handBrakeStartedAt = Date.now();
  await new Promise<void>((resolve, reject) => {
    const hb = jobProcessController.spawnForJob(
      jobId,
      hbCli,
      hbArgs,
      config.processHighPriority ?? false,
    );
    let lastProgress = 0;
    let lastDbWrite = 0;
    // A full encode is long; keep only the output tail for diagnostics.
    const hbStdout = new BoundedOutput(1024 * 1024);
    const hbStderr = new BoundedOutput(1024 * 1024);

    // HandBrake outputs progress to stdout (or stderr depending on version).
    // We normalise \r → \n so every "Encoding: task …" line is parsed reliably.
    let hbBuffer = "";
    const handleHbChunk = async (chunk: Buffer) => {
      // Replace carriage returns with newlines so partial lines become full lines
      hbBuffer += chunk.toString().replace(/\r/g, "\n");
      const lines = hbBuffer.split("\n");
      hbBuffer = lines.pop() ?? "";
      for (const line of lines) {
        const match = line.match(
          /Encoding: task \d+ of \d+, ([0-9.]+) %(?:[^(]*\(([0-9.]+) fps, avg ([0-9.]+) fps, ETA (\d+)h(\d+)m(\d+)s\))?/,
        );
        if (match) {
          const pct = parseFloat(match[1]);
          const mapped = mapExternalToolProgress({
            toolPercent: pct,
            start: 0,
            end: 95,
          });
          const currentFps = match[2] ? parseFloat(match[2]) : null;
          const avgFps = match[3] ? parseFloat(match[3]) : null;
          const etaSeconds = match[4]
            ? parseInt(match[4]) * 3600 +
              parseInt(match[5]) * 60 +
              parseInt(match[6])
            : null;
          const now = Date.now();
          if (mapped - lastProgress > 0.5 || now - lastDbWrite > 2000) {
            lastProgress = mapped;
            lastDbWrite = now;
            await db
              .update(jobsTable)
              .set({ progress: mapped, currentFps, avgFps, etaSeconds })
              .where(eq(jobsTable.id, jobId));
          }
        }
      }
    };

    const safeHandleHbChunk = (chunk: Buffer) => {
      void handleHbChunk(chunk).catch(async (error) => {
        await addLog(
          jobId,
          "warn",
          `HandBrake 进度解析失败：${error instanceof Error ? error.message : String(error)}`,
        ).catch(() => {});
      });
    };

    hb.stdout?.on("data", (chunk: Buffer) => {
      hbStdout.append(chunk);
      safeHandleHbChunk(chunk);
    });
    hb.stderr?.on("data", (chunk: Buffer) => {
      hbStderr.append(chunk);
      safeHandleHbChunk(chunk);
    });
    hb.on("close", (code) => {
      void appendJobToolOutput(jobId, {
        tool: "HandBrakeCLI",
        executable: hbCli,
        args: hbArgs,
        exitCode: code,
        durationMs: Date.now() - handBrakeStartedAt,
        stdout: hbStdout.toString(),
        stderr: hbStderr.toString(),
      }).catch(() => {});
      void addLog(
        jobId,
        code === 0 ? "info" : "error",
        `HandBrakeCLI 退出码：${code ?? "unknown"}；输出路径：${outputFile}`,
      ).catch(() => {});
      if (code === 0) {
        if (cancelledJobs.has(jobId)) {
          // 取消后 HandBrake 若仍正常退出，不写完成状态并删除刚生成的输出。
          void fs
            .rm(outputFile, { force: true })
            .then(() => reject(new Error("任务已取消")))
            .catch(() => reject(new Error("任务已取消")));
        } else {
          resolve();
        }
      } else reject(new Error(`HandBrakeCLI exit ${code}`));
    });
    hb.on("error", (e) =>
      reject(new Error(`HandBrakeCLI 未找到：${e.message}`)),
    );
  });

  await addLog(
    jobId,
    "info",
    `HandBrake 压缩完成；耗时 ${Date.now() - handBrakeStartedAt} ms；工具=${hbCli}`,
  );

  const compressionValidation = await validateCompressionOutput({
    jobId,
    outputFile,
    expectedDurationSeconds: job.durationSeconds,
    expectedStreamCounts:
      taskSnapshot?.outputMode === "compress"
        ? {
            video: taskSnapshot.streamSelection.videoTrackIds.length,
            audio: taskSnapshot.streamSelection.audioTrackIds.length,
            subtitle: taskSnapshot.streamSelection.subtitleTrackIds.length,
          }
        : undefined,
    expectedChapterCount:
      taskSnapshot?.outputMode === "compress"
        ? taskSnapshot.chapterSelection.chapterIds.length
        : undefined,
    requiredAudioCount:
      taskSnapshot?.outputMode === "compress" &&
      taskSnapshot.streamSelection.audioTrackIds.length > 0
        ? 1
        : 0,
  });
  const fileSizeAfter = compressionValidation.fileSize;
  await addLog(
    jobId,
    "info",
    `HandBrake 输出验证通过：文件大小=${fileSizeAfter} 字节；时长=${compressionValidation.durationSeconds ?? "未知"} 秒；后置校验未发现致命错误`,
  );

  await db
    .update(jobsTable)
    .set({
      status: "done",
      progress: 100,
      currentFps: null,
      avgFps: null,
      etaSeconds: null,
      outputPath: outputFile,
      fileSizeAfter,
      durationSeconds: compressionValidation.durationSeconds ?? undefined,
      completedAt: new Date(),
    })
    .where(eq(jobsTable.id, jobId));

  await addLog(jobId, "info", `任务完成 — 输出：${outputFile}`);
  await settlePreviewTaskSafely(jobId, {
    taskKind: "compress",
    outputValid: true,
    isPreviewOnly: false,
    cancelled: false,
  });
  await fixAssPlayResForOutput(
    outputFile,
    translatedSubtitlePath,
    (level, message) => addLog(jobId, level, message),
  );
  await stageSubtitleSidecars(
    jobId,
    outputFile,
    subtitlePath,
    translatedSubtitlePath,
    (level, message) => addLog(jobId, level, message),
    graphicSubtitlePaths,
  );

  // 流水线：压缩完成后，为压缩版生成同名 srt（字幕跟随 Remux 名时自动适配压缩版文件名）
  if (
    subtitleStageBaseName &&
    subtitleStageBaseName !== compressionBaseName &&
    pipelineHasSubtitle
  ) {
    try {
      const srtEntries = await fs
        .readdir(subtitleDirJob)
        .catch(() => [] as string[]);
      for (const name of srtEntries) {
        if (
          !SUBTITLE_FILE_EXT_RE.test(name) ||
          !name.startsWith(`${subtitleStageBaseName}.`)
        )
          continue;
        const target = path.join(
          subtitleDirJob,
          `${compressionBaseName}.${name.slice(subtitleStageBaseName.length + 1)}`,
        );
        if (
          path.resolve(target) === path.resolve(path.join(subtitleDirJob, name))
        )
          continue;
        await fs.copyFile(path.join(subtitleDirJob, name), target);
        await addLog(jobId, "info", `已为压缩版生成同名字幕：${target}`);
      }
    } catch (error) {
      await addLog(
        jobId,
        "warn",
        `压缩版字幕适配失败：${error instanceof Error ? error.message : String(error)}`,
      );
    }
  }
  return { shouldReturn: false };
}
