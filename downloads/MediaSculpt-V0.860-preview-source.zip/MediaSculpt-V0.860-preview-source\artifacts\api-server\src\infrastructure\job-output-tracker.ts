import fs from "node:fs/promises";
import fsSync from "node:fs";

type OutputSnapshot = { existed: boolean; size: number; temp: boolean };

// Tracks only files touched by the current run. Successful earlier pipeline
// stages can be removed from this map once their post-output validation passes.
const jobOutputFiles = new Map<number, Map<string, OutputSnapshot>>();

export function trackJobOutputFile(
  jobId: number,
  file: string,
  opts?: { temp?: boolean },
): void {
  if (!file) return;
  let files = jobOutputFiles.get(jobId);
  if (!files) {
    files = new Map();
    jobOutputFiles.set(jobId, files);
  }
  if (files.has(file)) return;
  let existed = false;
  let size = 0;
  try {
    const stat = fsSync.statSync(file);
    existed = stat.isFile();
    size = stat.size;
  } catch {
    existed = false;
  }
  files.set(file, { existed, size, temp: opts?.temp ?? false });
}

/** Mark a validated stage as durable when a later pipeline stage may fail. */
export function markJobOutputFileCompleted(jobId: number, file: string): void {
  const files = jobOutputFiles.get(jobId);
  if (!files) return;
  files.delete(file);
  if (files.size === 0) jobOutputFiles.delete(jobId);
}

export function clearJobOutputFiles(jobId: number): void {
  jobOutputFiles.delete(jobId);
}

/** Remove only new, changed, or explicitly temporary outputs from this run. */
export async function removeIncompleteJobOutputs(
  jobId: number,
  log?: (message: string) => Promise<void> | void,
): Promise<void> {
  const files = jobOutputFiles.get(jobId);
  if (!files || files.size === 0) return;
  for (const [file, snapshot] of files) {
    try {
      let currentSize = -1;
      try {
        const stat = await fs.stat(file);
        currentSize = stat.size;
      } catch {
        // File already disappeared; there is nothing left to clean.
      }
      if (currentSize < 0) continue;
      const reason = snapshot.temp
        ? "临时文件"
        : !snapshot.existed
          ? "本次新建"
          : "被本次运行覆盖";
      const incomplete =
        snapshot.temp || !snapshot.existed || currentSize !== snapshot.size;
      if (incomplete) {
        await fs.rm(file, { force: true });
        await log?.(`已删除未完成输出：${file}（${reason}）`);
      }
    } catch {
      // Best effort: failure to remove a diagnostic artifact must not mask the job error.
    }
  }
  jobOutputFiles.delete(jobId);
}
