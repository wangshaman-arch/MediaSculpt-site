import { describe, expect, it } from "vitest";
import {
  readLastBrowsePath,
  readNetworkPathHistory,
  rememberBrowsePath,
  rememberNetworkPath,
} from "./source-browser-storage";

function createStorage(initial: Record<string, string> = {}) {
  const values = new Map(Object.entries(initial));
  return {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => values.set(key, value),
  };
}

describe("source browser storage", () => {
  it("deduplicates network paths and keeps the newest eight", () => {
    const storage = createStorage({
      VX_AGENT_NETWORK_PATHS: JSON.stringify(["C:/old"]),
    });
    const paths = rememberNetworkPath(storage, "C:/new");
    expect(paths[0]).toBe("C:/new");
    expect(rememberNetworkPath(storage, "C:/new")).toEqual(paths);
  });

  it("falls back to legacy network storage when the new value is invalid", () => {
    expect(
      readNetworkPathHistory(
        createStorage({
          VX_AGENT_NETWORK_PATHS: "bad",
          VX_AGENT_LAST_NETWORK_PATH: "\\\\NAS\\Movies",
        }),
      ),
    ).toEqual(["\\\\NAS\\Movies"]);
  });

  it("reuses only the selected folder or one of its descendants", () => {
    const storage = createStorage({
      VX_AGENT_LAST_BROWSE_PATH: "C:/media/Movie/VIDEO_TS",
    });
    expect(readLastBrowsePath(storage, "C:/media/Movie")).toBe(
      "C:/media/Movie/VIDEO_TS",
    );
    expect(readLastBrowsePath(storage, "D:/other")).toBe("D:/other");
    rememberBrowsePath(storage, "D:/other/BDMV");
    expect(readLastBrowsePath(storage, "D:/other")).toBe("D:/other/BDMV");
  });
});
