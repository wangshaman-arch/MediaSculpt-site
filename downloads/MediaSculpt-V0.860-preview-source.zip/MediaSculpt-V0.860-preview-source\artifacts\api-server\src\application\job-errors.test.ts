import { describe, expect, it } from "vitest";
import {
  canStartJobStatus,
  isActiveJobStatus,
  JobCommandError,
} from "./job-errors";

describe("job command errors and states", () => {
  it("keeps processing states separate from retryable states", () => {
    expect(isActiveJobStatus("remuxing")).toBe(true);
    expect(isActiveJobStatus("compressing")).toBe(true);
    expect(canStartJobStatus("pending")).toBe(true);
    expect(canStartJobStatus("error")).toBe(true);
    expect(canStartJobStatus("done")).toBe(false);
  });

  it("preserves a stable machine-readable error code", () => {
    const error = new JobCommandError("JOB_INVALID_STATE", "任务状态不可执行");
    expect(error).toMatchObject({
      code: "JOB_INVALID_STATE",
      message: "任务状态不可执行",
    });
    expect(error.name).toBe("JobCommandError");
  });
});
