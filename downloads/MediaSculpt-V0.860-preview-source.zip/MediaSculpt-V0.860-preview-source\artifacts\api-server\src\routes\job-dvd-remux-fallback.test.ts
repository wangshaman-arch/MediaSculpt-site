import { describe, expect, it } from "vitest";
import { buildDvdVobFallbackArgs } from "./job-dvd-remux-fallback";

describe("DVD VOB Remux fallback command", () => {
  it("keeps selected video/audio/bitmap subtitle maps and converts DVD PCM losslessly", () => {
    const args = buildDvdVobFallbackArgs({
      concatInputArgs: ["-i", "concat:VTS_01_1.VOB|VTS_01_2.VOB"],
      typeMaps: ["-map", "0:v:0", "-map", "0:a:0", "-map", "0:s:0"],
      outputPath: "D:/Output/movie.mkv",
      selectedAudioStreams: [2],
      selectedAudioCodecs: [
        { inputIndex: 2, codecName: "pcm_dvd", bitsPerRawSample: 24 },
      ],
      selectedSubtitleStreams: [5],
      subtitleMetadata: [{ inputIndex: 5, language: "eng" }],
      chapterMetadataPath: null,
    });

    expect(args).toContain("-map");
    expect(args).toContain("0:v:0");
    expect(args).toContain("0:a:0");
    expect(args).toContain("0:s:0");
    expect(args).toContain("language=eng");
    expect(args).toContain("title=英语字幕");
    expect(args).toContain("-c:a:0");
    expect(args).toContain("pcm_s24le");
    expect(args.at(-1)).toBe("D:/Output/movie.mkv");
  });

  it("maps selected chapter metadata as the output chapter source", () => {
    const args = buildDvdVobFallbackArgs({
      concatInputArgs: ["-i", "concat:VTS_01_1.VOB"],
      typeMaps: null,
      outputPath: "D:/Output/movie.mkv",
      selectedAudioStreams: [],
      selectedAudioCodecs: [],
      selectedSubtitleStreams: [],
      chapterMetadataPath: "C:\\Temp\\chapters.ffmeta",
    });

    expect(args).toContain("-map_chapters");
    expect(args).toContain("1");
    expect(args).toContain("C:/Temp/chapters.ffmeta");
  });
});
