import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { afterEach, describe, expect, it } from "vitest";
import {
  appendRuntimeToolLog,
  appendRuntimeToolOutput,
  runtimeToolLogPath,
} from "./runtime-tool-log";

const originalLogPath = process.env.VX_AGENT_RUNTIME_TOOLS_LOG_PATH;
const originalDiagnosticsLogPath = process.env.VX_AGENT_DIAGNOSTICS_LOG;
const originalServiceLogDir = process.env.VX_AGENT_SERVICE_LOG_DIR;

afterEach(() => {
  if (originalLogPath === undefined)
    delete process.env.VX_AGENT_RUNTIME_TOOLS_LOG_PATH;
  else process.env.VX_AGENT_RUNTIME_TOOLS_LOG_PATH = originalLogPath;
  if (originalDiagnosticsLogPath === undefined)
    delete process.env.VX_AGENT_DIAGNOSTICS_LOG;
  else process.env.VX_AGENT_DIAGNOSTICS_LOG = originalDiagnosticsLogPath;
  if (originalServiceLogDir === undefined)
    delete process.env.VX_AGENT_SERVICE_LOG_DIR;
  else process.env.VX_AGENT_SERVICE_LOG_DIR = originalServiceLogDir;
});

describe("runtime tool log", () => {
  it("defaults runtime tool diagnostics into a service log that avoids locking the upload diagnostics file", () => {
    delete process.env.VX_AGENT_RUNTIME_TOOLS_LOG_PATH;
    delete process.env.VX_AGENT_DIAGNOSTICS_LOG;

    expect(path.basename(runtimeToolLogPath())).toBe("tool-events.tmp.log");
  });

  it("uses the service log directory when the service-specific path is not set", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-tool-log-"));
    delete process.env.VX_AGENT_RUNTIME_TOOLS_LOG_PATH;
    process.env.VX_AGENT_SERVICE_LOG_DIR = dir;

    expect(runtimeToolLogPath()).toBe(path.join(dir, "tool-events.tmp.log"));
  });

  it("writes tool diagnostics to the configured diagnostics log file", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-tool-log-"));
    const file = path.join(dir, "tool-events.tmp.log");
    const diagnosticsFile = path.join(dir, "vx-agent-diagnostics.log");
    process.env.VX_AGENT_RUNTIME_TOOLS_LOG_PATH = file;
    process.env.VX_AGENT_DIAGNOSTICS_LOG = diagnosticsFile;

    await appendRuntimeToolLog("ffmpeg: install failed: sample");

    expect(runtimeToolLogPath()).toBe(file);
    await expect(fs.readFile(file, "utf8")).resolves.toContain(
      "ffmpeg: install failed: sample",
    );
    await expect(fs.readFile(diagnosticsFile, "utf8")).resolves.toContain(
      "===== RUNTIME TOOL =====",
    );
  });

  it("preserves complete scan and verification stdout/stderr", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-tool-output-"));
    process.env.VX_AGENT_RUNTIME_TOOLS_LOG_PATH = path.join(
      dir,
      "tool-events.tmp.log",
    );
    process.env.VX_AGENT_DIAGNOSTICS_LOG = path.join(
      dir,
      "vx-agent-diagnostics.log",
    );

    await appendRuntimeToolOutput({
      tool: "HandBrakeCLI",
      executable: "C:\\Tools\\HandBrakeCLI.exe",
      args: ["--scan", "C:\\DVD Folder\\VIDEO_TS"],
      exitCode: 0,
      durationMs: 99,
      stdout: "Title 2, 00:03:00",
      stderr: "warning: sample",
    });

    const content = await fs.readFile(
      process.env.VX_AGENT_DIAGNOSTICS_LOG,
      "utf8",
    );
    expect(content).toContain("===== TOOL OUTPUT HANDBRAKECLI =====");
    expect(content).toContain("Title 2, 00:03:00");
    expect(content).toContain("warning: sample");
  });
});
