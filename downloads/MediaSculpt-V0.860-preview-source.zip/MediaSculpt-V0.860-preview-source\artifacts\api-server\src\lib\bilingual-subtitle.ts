export type BilingualLayout = "zh-top" | "foreign-top";

export type BilingualAssStyle = {
  layout: BilingualLayout;
  outlineWidth: number;
  shadowWidth: number;
  outlineColor: string;
  fontSizeTop: number;
  fontSizeBottom: number;
};

export const DEFAULT_BILINGUAL_STYLE: BilingualAssStyle = {
  layout: "zh-top",
  outlineWidth: 0.2,
  shadowWidth: 0,
  outlineColor: "&H00404040",
  fontSizeTop: 16,
  fontSizeBottom: 9.6,
};

export type SubtitleBlock = {
  startMs: number;
  endMs: number;
  text: string;
};

/** Guard against treating a Chinese OCR sidecar as its own foreign-language reference. */
export function bothSubtitleSidesMostlyHan(
  chinese: SubtitleBlock[],
  foreign: SubtitleBlock[],
): boolean {
  const hanRatio = (blocks: SubtitleBlock[]) => {
    const text = blocks.map((block) => block.text).join("");
    const letters = [...text].filter((char) => /[\p{L}\p{N}]/u.test(char));
    return letters.length
      ? letters.filter((char) => /[\u3400-\u9fff]/u.test(char)).length /
          letters.length
      : 0;
  };
  return hanRatio(chinese) > 0.35 && hanRatio(foreign) > 0.35;
}

function assTime(ms: number): string {
  // 防御非法/缺失时间：绝不输出 NaN 时间戳（会导致播放器无法解析）。
  const total = Number.isFinite(ms) ? Math.max(0, ms) : 0;
  const h = Math.floor(total / 3_600_000);
  const m = Math.floor((total % 3_600_000) / 60_000);
  const s = Math.floor((total % 60_000) / 1000);
  const cs = Math.floor((total % 1000) / 10);
  return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}.${String(cs).padStart(2, "0")}`;
}

function assEscape(text: string): string {
  // 每种语言只显示一行：源文本内部的多行合并为空格；
  // 中英文之间的分隔由 renderBilingualAss 用单个 \N 负责。
  // 去掉 SRT/ASS 常见的 <i>/<b>/<font> 等标记，避免把字面量标签打进 ASS。
  const hasCjk = /[\u3400-\u9fff]/.test(text);
  return (
    text
      .replace(/<[^>]+>/g, "")
      .replace(/[{}]/g, "")
      // 中文合并不加空格（作者常把一句话拆成两行，空格会变成“半岛 和地中海”）；
      // 英文/拉丁文字跨行合并必须保留空格分隔单词。
      .replace(/\s*\r?\n\s*/g, hasCjk ? "" : " ")
  );
}

/**
 * 按起始时间对齐：为每条中文块找到起始时间最接近的外文块（窗口 ±5 秒）。
 * 找不到就只输出中文一行。
 */
export function alignBilingualPairs(
  chinese: SubtitleBlock[],
  foreign: SubtitleBlock[],
  windowMs = 5000,
): Array<{ chinese: SubtitleBlock; foreign: SubtitleBlock | null }> {
  return chinese.map((block) => {
    let best: SubtitleBlock | null = null;
    let bestDistance = Number.POSITIVE_INFINITY;
    for (const candidate of foreign) {
      const distance = Math.abs(candidate.startMs - block.startMs);
      if (distance < bestDistance) {
        bestDistance = distance;
        best = candidate;
      }
    }
    return {
      chinese: block,
      foreign: best && bestDistance <= windowMs ? best : null,
    };
  });
}

/**
 * 渲染双语 ASS：上行为全字号（16），下行为一半字号（8），
 * 默认中文在上、外文在下；foreign-top 则反过来。
 */
export function renderBilingualAss(
  chinese: SubtitleBlock[],
  foreign: SubtitleBlock[],
  style: BilingualAssStyle = DEFAULT_BILINGUAL_STYLE,
  playRes?: { playResX?: number; playResY?: number },
): string {
  const pairs = alignBilingualPairs(chinese, foreign);
  const fontSizeTop = Math.round(style.fontSizeTop * 100) / 100;
  const fontSizeBottom = Math.round(style.fontSizeBottom * 100) / 100;
  // 播放器按 PlayRes 与视频显示尺寸的比例缩放 ASS。把 PlayResY 固定为 288、
  // PlayResX 按视频 DAR 计算后，字体在任意宽高比的视频上占相同高度比例、
  // 且不会因宽高比不同而变形（锁定字体的高宽比）。
  const prX =
    playRes?.playResX && playRes.playResX > 0 ? Number(playRes.playResX) : 384;
  const prY =
    playRes?.playResY && playRes.playResY > 0 ? Number(playRes.playResY) : 288;
  const dar = prY > 0 ? prX / prY : 16 / 9;
  const playResY = 288;
  const playResX = Math.round(playResY * dar);
  const header = `[Script Info]
ScriptType: v4.00+
PlayResX: ${playResX}
PlayResY: ${playResY}
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Bilingual,Microsoft YaHei,${fontSizeTop},&H00FFFFFF,&H000000FF,${style.outlineColor},&H00000000,0,0,0,0,100,100,0,0,1,${style.outlineWidth},${style.shadowWidth},2,10,10,12,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`;
  const events = pairs.map(({ chinese: zh, foreign: en }) => {
    const top = style.layout === "zh-top" ? zh.text : (en?.text ?? zh.text);
    const bottom = style.layout === "zh-top" ? (en?.text ?? "") : zh.text;
    const topLine = assEscape(top);
    const bottomLine = bottom
      ? `{\\fs${fontSizeBottom}}${assEscape(bottom)}`
      : "";
    // \q2 = 不自动换行，保证每种语言始终只有一行（过长时横向延伸而非折行）。
    const text = `{\\q2}${topLine}${bottomLine ? `\\N${bottomLine}` : ""}`;
    return `Dialogue: 0,${assTime(zh.startMs)},${assTime(zh.endMs)},Bilingual,,0,0,0,,${text}`;
  });
  return `${header}${events.join("\n")}\n`;
}
