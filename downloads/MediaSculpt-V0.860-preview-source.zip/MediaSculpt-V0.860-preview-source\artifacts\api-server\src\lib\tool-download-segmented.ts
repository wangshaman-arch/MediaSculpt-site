// Extracted from tool-downloader.ts: parallel HTTP Range segmented download.
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { getToolPackage, ghMirrorChain } from "./tool-manifest";
import {
  candidatePaths,
  executableName,
  resolveToolPath,
  type ToolId,
} from "./tool-runtime";

const execFileAsync = promisify(execFile);

/** 单个分片的 Range 下载（支持断点续传：append 时从已写字节继续）。 */
async function downloadSegmentRange(options: {
  url: string;
  start: number;
  end: number;
  file: string;
  append: boolean;
  onBytes: (count: number) => void;
  log: (message: string) => Promise<void>;
  signal: AbortSignal;
}): Promise<void> {
  const connectController = new AbortController();
  const connectTimer = setTimeout(() => connectController.abort(), 60_000);
  let response: Response;
  try {
    response = await fetch(options.url, {
      signal: AbortSignal.any([connectController.signal, options.signal]),
      headers: { Range: `bytes=${options.start}-${options.end}` },
    });
  } finally {
    clearTimeout(connectTimer);
  }
  if (response.status !== 206 || !response.body) {
    throw new Error(`分片请求失败：HTTP ${response.status}`);
  }
  const file = await fs.open(options.file, options.append ? "a" : "w");
  const reader = response.body.getReader();
  let stallTimer: NodeJS.Timeout | null = null;
  let stallReject: ((error: Error) => void) | null = null;
  const armStallTimer = () => {
    if (stallTimer) clearTimeout(stallTimer);
    stallTimer = setTimeout(() => {
      stallReject?.(new Error("分片 30 秒无进展，重试"));
    }, 30_000);
  };
  try {
    armStallTimer();
    for (;;) {
      const readPromise = reader.read();
      const { done, value } = await Promise.race([
        readPromise,
        new Promise<never>((_, reject) => {
          stallReject = reject;
        }),
      ]);
      stallReject = null;
      if (done) break;
      if (value.byteLength > 0) {
        await file.write(value);
        options.onBytes(value.byteLength);
        armStallTimer();
      }
    }
  } finally {
    if (stallTimer) clearTimeout(stallTimer);
    await reader.cancel().catch(() => {});
    await file.close();
  }
}

/** 多线程分段下载（原理同迅雷）：按大小分片、并行 Range 下载、失败分片重试、最后按序合并。 */
export async function downloadSegmentedParallel(options: {
  id: string;
  url: string;
  totalBytes: number;
  temp: string;
  onProgress: (receivedBytes: number, totalBytes: number) => void;
  log: (message: string) => Promise<void>;
}): Promise<void> {
  const { id, url, totalBytes, temp, onProgress, log } = options;
  // 分片控制在每个连接 25MB 左右（绕开部分网络对大连接的单连接截断），4–8 片。
  const SEGMENT_BYTES = 25 * 1024 * 1024;
  const count = Math.max(4, Math.min(8, Math.ceil(totalBytes / SEGMENT_BYTES)));
  const segments = Array.from({ length: count }, (_, index) => {
    const start = Math.floor((totalBytes * index) / count);
    const end = Math.floor((totalBytes * (index + 1)) / count) - 1;
    return { index, start, end, file: `${temp}.part-${index}` };
  });
  // 跨源续传：上一次失败的源可能已经写好了部分分片。只有当 part-0 头部
  // 是真实可执行/压缩包魔数时才复用（防止把假页面写进分片再续传）；
  // 否则清空全部旧分片重新下载。
  const part0Head = Buffer.alloc(2);
  const canReuseParts = await (async () => {
    try {
      const handle = await fs.open(segments[0].file, "r");
      try {
        await handle.read(part0Head, 0, 2, 0);
      } finally {
        await handle.close();
      }
      return (
        (part0Head[0] === 0x4d && part0Head[1] === 0x5a) || // MZ (exe)
        (part0Head[0] === 0x50 && part0Head[1] === 0x4b) || // PK (zip/whl)
        (part0Head[0] === 0x37 && part0Head[1] === 0x7a)
      ); // 7z
    } catch {
      return false;
    }
  })();
  if (!canReuseParts) {
    for (const segment of segments) {
      await fs.rm(segment.file, { force: true }).catch(() => {});
    }
  }
  let receivedBytes = 0;
  const report = () => onProgress(receivedBytes, totalBytes);
  const controllers = segments.map(() => new AbortController());
  // 分片任务：单分片最多 6 次尝试（含断点续传），任意分片最终失败则中止其他分片。
  const results = await Promise.allSettled(
    segments.map(async (segment, index) => {
      const controller = controllers[index];
      for (let attempt = 0; attempt < 6; attempt += 1) {
        if (controller.signal.aborted)
          throw new Error("分片被中止（其他分片失败）");
        try {
          const written = await fs
            .stat(segment.file)
            .then((stat) => stat.size)
            .catch(() => 0);
          await downloadSegmentRange({
            url,
            start: segment.start + written,
            end: segment.end,
            file: segment.file,
            append: written > 0,
            onBytes: (count) => {
              receivedBytes += count;
              report();
            },
            log,
            signal: controller.signal,
          });
          return;
        } catch (error) {
          if (controller.signal.aborted) throw error;
          if (attempt >= 5) throw error;
          await log(
            `${id}: 分片 ${segment.index + 1}/${count} 第 ${attempt + 1} 次失败（${error instanceof Error ? error.message : String(error)}），从已下载字节续传`,
          );
          await new Promise((resolve) =>
            setTimeout(resolve, 1000 * (attempt + 1)),
          );
        }
      }
    }),
  );
  const failed = results.find((result) => result.status === "rejected");
  if (failed) {
    // 真正取消仍在运行的分片，避免“幽灵连接”继续写盘浪费带宽。
    for (const controller of controllers) controller.abort();
    await Promise.allSettled(results);
    throw (failed as PromiseRejectedResult).reason;
  }
  // 按序合并分片到正式临时文件
  const out = await fs.open(temp, "w");
  try {
    const buf = Buffer.alloc(1024 * 1024);
    for (const segment of segments) {
      const part = await fs.open(segment.file, "r");
      try {
        for (;;) {
          const { bytesRead } = await part.read(buf, 0, buf.length);
          if (bytesRead <= 0) break;
          await out.write(buf.subarray(0, bytesRead));
        }
      } finally {
        await part.close();
      }
      await fs.rm(segment.file, { force: true }).catch(() => {});
    }
  } finally {
    await out.close();
  }
  await log(`${id}: 多线程分段下载完成（${totalBytes} 字节，${count} 片）`);
}
