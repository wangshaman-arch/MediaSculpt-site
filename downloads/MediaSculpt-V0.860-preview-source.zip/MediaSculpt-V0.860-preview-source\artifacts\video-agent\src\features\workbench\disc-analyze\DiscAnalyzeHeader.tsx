import { Loader2, Sparkles, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { ProcessingMode } from "@/hooks/useWorkbenchState";
import { useI18n } from "@/i18n";
import { cn } from "@/lib/utils";
import type { ScanCopy } from "@/pages/Scan";
import { discFolderName } from "@/pages/scan-model";
import { formatDiscBytes } from "../disc-display-model";

export type DiscAnalyzeHeaderProps = {
  uiText: ScanCopy;
  discPath: string;
  hasData: boolean;
  discType: "dvd" | "bluray";
  trackCount: number;
  sourceSizeBytes?: number | null;
  analysisOnly: boolean;
  processingMode: ProcessingMode;
  showModePicker: boolean;
  modeChosen: boolean;
  modeSelectionAttention: boolean;
  selectedTitleCount: number;
  verifyingCount: number;
  smartParsing: boolean;
  smartParseHasLlm: boolean;
  onChooseProcessingMode: (mode: ProcessingMode) => void;
  onRunSmartParse: () => void;
  onClose: () => void;
  onConfirmAnalysis: () => void;
};

export function DiscAnalyzeHeader({
  uiText,
  discPath,
  hasData,
  discType,
  trackCount,
  sourceSizeBytes,
  analysisOnly,
  processingMode,
  showModePicker,
  modeChosen,
  modeSelectionAttention,
  selectedTitleCount,
  verifyingCount,
  smartParsing,
  smartParseHasLlm,
  onChooseProcessingMode,
  onRunSmartParse,
  onClose,
  onConfirmAnalysis,
}: DiscAnalyzeHeaderProps) {
  const { t } = useI18n();
  const discLabel =
    discType === "bluray" ? t("scan.discBluray") : t("scan.discDvd");
  const processingLabel = uiText.modes[processingMode].label;

  return (
    <div className="flex items-center justify-between gap-3 p-4 border-b shrink-0">
      <div className="min-w-0 flex-1">
        <h3 className="flex min-w-0 items-center gap-2 font-semibold text-base">
          <span className="truncate">{uiText.sourcePreview}</span>
          <span className="shrink-0 rounded bg-primary/10 px-1.5 py-0.5 text-[11px] font-normal text-primary">
            {discFolderName(discPath)}
          </span>
        </h3>
        {hasData && (
          <p className="mt-0.5 truncate text-xs text-muted-foreground">
            {discLabel} · {t("scan.trackCount", { count: trackCount })}
            {sourceSizeBytes
              ? ` · ${t("scan.sourceSize")}: ${formatDiscBytes(sourceSizeBytes)}`
              : ""}
            {!analysisOnly && (
              <>
                {" "}
                · {t("scan.processingLabelPrefix")}
                {processingLabel}
              </>
            )}
          </p>
        )}
        <p
          className="mt-0.5 truncate font-mono text-[11px] text-muted-foreground"
          title={discPath}
        >
          {discPath}
        </p>
      </div>
      <div className="flex min-w-0 shrink-0 items-center gap-1.5">
        {showModePicker && (
          <div
            className="flex items-center gap-1"
            aria-label={uiText.processingMode}
          >
            {(["remux", "compress", "none"] as const).map((mode) => (
              <button
                key={mode}
                type="button"
                onClick={() => onChooseProcessingMode(mode)}
                className={cn(
                  "h-7 max-w-[9rem] truncate rounded-md border px-2 text-[11px] transition-colors",
                  processingMode === mode && modeChosen
                    ? "border-primary bg-primary/10 text-primary"
                    : cn(
                        "border-border text-muted-foreground hover:border-primary/50 hover:bg-secondary/40 hover:text-foreground",
                        modeSelectionAttention &&
                          "animate-pulse border-blue-500/80 text-blue-400",
                      ),
                )}
                title={uiText.modes[mode].label}
              >
                {uiText.modes[mode].label}
              </button>
            ))}
          </div>
        )}
        {analysisOnly && (
          <div className="flex shrink-0 items-center gap-1">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={onClose}
              className={cn(
                "h-7 min-h-0 w-32 px-2 text-[11px]",
                analysisOnly &&
                  selectedTitleCount === 0 &&
                  "animate-pulse ring-2 ring-primary/50",
              )}
            >
              {uiText.cancel}
            </Button>
            <Button
              type="button"
              size="sm"
              onClick={onConfirmAnalysis}
              disabled={selectedTitleCount === 0 || verifyingCount > 0}
              className={cn(
                "h-7 min-h-0 w-32 px-2 text-[11px]",
                analysisOnly &&
                  selectedTitleCount === 0 &&
                  "animate-pulse ring-2 ring-primary/50",
              )}
            >
              {t("scan.confirmSelection")}
            </Button>
          </div>
        )}
        {smartParsing ? (
          <span
            className="inline-flex h-7 w-32 shrink-0 items-center justify-center gap-1.5 text-xs text-amber-400"
            title={t("scan.smartParsing")}
          >
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
            {t("scan.smartParsing")}
          </span>
        ) : (
          <button
            type="button"
            onClick={onRunSmartParse}
            disabled={!hasData || discType !== "dvd" || trackCount === 0}
            className={cn(
              "inline-flex h-7 w-32 shrink-0 items-center justify-center gap-1.5 rounded-md border px-2 text-[11px] transition-colors disabled:cursor-not-allowed disabled:border-border/40 disabled:text-muted-foreground/40",
              smartParseHasLlm
                ? "border-amber-400/50 text-amber-400 hover:bg-amber-400/10"
                : "border-primary/40 text-primary hover:bg-primary/5",
            )}
            title={t(
              smartParseHasLlm
                ? "scan.smartParseHint"
                : "scan.smartParseLocalHint",
            )}
          >
            <Sparkles className="h-3.5 w-3.5" />
            {t(smartParseHasLlm ? "scan.smartParse" : "scan.smartParseLocal")}
          </button>
        )}
      </div>
      <button
        onClick={onClose}
        className="shrink-0 p-1 rounded hover:bg-secondary/60 transition-colors"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
