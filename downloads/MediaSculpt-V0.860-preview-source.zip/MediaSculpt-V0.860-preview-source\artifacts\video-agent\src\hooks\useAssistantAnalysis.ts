import { useCallback, useEffect, useRef, useState } from "react";
import { useI18n } from "@/i18n";
import { resolveAnalysisOverview } from "@/lib/assistant-analysis";
import {
  getRetryPromptState,
  preserveAnalysisAfterFailure,
} from "@/lib/assistant-analysis-state";
import type { AssistantMetadataSnapshot } from "@/lib/assistant-metadata";

export type AssistantCorrection = {
  titleEn?: string;
  titleZh?: string;
  year?: number;
  /** IMDb 号：概要预览识别到资料库条目时自动反向填充到输入框。 */
  imdbId?: string | null;
  /** A provider match or a typed id is verified; the model's claim is not. */
  imdbIdSource?: "verified" | "assistant";
  doubanId?: string | null;
  doubanRating?: number | null;
};

function reconcileAnalysisReply(reply: string, imdbId?: string | null): string {
  if (!imdbId || !/^tt\d{7,8}$/i.test(imdbId.trim())) return reply;
  const cleaned = reply
    .split(/\r?\n/)
    .filter((line) => !/^\s*IMDBID\s*=/i.test(line))
    .filter(
      (line) =>
        !/^\s*IMDb\s*(?:编号|ID)?\s*[:：=]\s*(?:tt\d{7,8}|未|无|未知|N\/?A)/i.test(
          line,
        ),
    )
    .join("\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  return `${cleaned}${cleaned ? "\n" : ""}IMDb 编号：${imdbId.trim()}`;
}

/**
 * 共享的“分析”逻辑：提示词默认收起、分析请求、LLM 校对回写、简介展示。
 * 工作流页与任务详情页共用，提示词的渲染位置由调用方决定（助手条右侧列 / 详情栏顶部）。
 */
export function useAssistantAnalysis({
  contextType,
  contextRef,
  onCorrection,
  onAnalysisResult,
  onAnalysisMetadata,
}: {
  contextType: "workflow" | "job";
  contextRef: React.MutableRefObject<Record<string, unknown>>;
  onCorrection: (correction: AssistantCorrection) => void;
  onAnalysisResult?: (reply: string) => void;
  onAnalysisMetadata?: (metadata: AssistantMetadataSnapshot | null) => void;
}) {
  const { t, lang } = useI18n();
  const [prompt, setPrompt] = useState("");
  const [promptOpen, setPromptOpen] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [analysisOpen, setAnalysisOpen] = useState(false);
  const [analysisPosterUrl, setAnalysisPosterUrl] = useState<string | null>(
    null,
  );
  const [analysisMetadata, setAnalysisMetadata] =
    useState<AssistantMetadataSnapshot | null>(null);
  const [promptFocusRequest, setPromptFocusRequest] = useState(0);
  const [promptAttention, setPromptAttention] = useState(false);
  const controllerRef = useRef<AbortController | null>(null);

  const requestPromptFocus = useCallback(() => {
    const next = getRetryPromptState();
    setPromptOpen(next.promptOpen);
    setPromptFocusRequest((current) => current + 1);
  }, []);

  useEffect(() => {
    if (promptFocusRequest === 0) return;
    setPromptAttention(true);
    const timer = window.setTimeout(() => setPromptAttention(false), 2200);
    return () => window.clearTimeout(timer);
  }, [promptFocusRequest]);

  const analyze = useCallback(
    async (fields: {
      titleEn: string;
      titleZh: string;
      year: number | null;
      imdbId?: string;
      processing: string[];
      prompt: string;
    }) => {
      const messages = [
        ...(fields.titleEn.trim()
          ? [
              {
                role: "user",
                content: `${t("assistant.titleEnField")}: ${fields.titleEn.trim()}`,
              },
            ]
          : []),
        ...(fields.titleZh.trim()
          ? [
              {
                role: "user",
                content: `${t("assistant.titleZhField")}: ${fields.titleZh.trim()}`,
              },
            ]
          : []),
        ...(fields.year != null && fields.year >= 1920
          ? [
              {
                role: "user",
                content: `${t("assistant.yearField")}: ${fields.year}`,
              },
            ]
          : []),
        ...(fields.imdbId?.trim()
          ? [
              {
                role: "user",
                content: `${t("assistant.imdbField")}: ${fields.imdbId.trim()}`,
              },
            ]
          : []),
        ...(fields.processing.length
          ? [
              {
                role: "user",
                content: `${t("assistant.processingField")}: ${fields.processing.join(" → ")}`,
              },
            ]
          : []),
        ...(fields.prompt.trim()
          ? [{ role: "user", content: fields.prompt.trim() }]
          : []),
      ];
      controllerRef.current?.abort();
      const controller = new AbortController();
      controllerRef.current = controller;
      let aborted = false;
      setAnalyzing(true);
      try {
        const response = await fetch("/api/assistant/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contextType,
            context: contextRef.current,
            messages,
            language: lang,
            analysis: true,
            imdbId: (fields.imdbId ?? "").trim() || undefined,
          }),
          signal: controller.signal,
        });
        const body = (await response.json().catch(() => ({}))) as {
          reply?: string;
          corrected?: AssistantCorrection;
          posterUrl?: string | null;
          metadata?: AssistantMetadataSnapshot | null;
          error?: string;
        };
        if (!response.ok)
          throw new Error(body.error ?? `HTTP ${response.status}`);
        const reply = body.reply ?? "";
        setAnalysisMetadata(body.metadata ?? null);
        onAnalysisMetadata?.(body.metadata ?? null);
        const posterMatch = /POSTER_URL\s*=\s*(\S+)/i.exec(reply);
        const posterUrl =
          typeof body.posterUrl === "string" && body.posterUrl
            ? body.posterUrl
            : (posterMatch?.[1] ?? null);
        if (posterUrl) {
          setAnalysisPosterUrl(posterUrl);
          // 海报由服务端在分析链路内直接保存到源目录（多源 + 信息卡兜底），
          // 前端不再重复 POST；目录海报在下方 useEffect 中轮询读取。
        }
        const cleanReply =
          posterUrl && posterMatch
            ? reply.replace(posterMatch[0], "").trim()
            : reply;
        const reconciledReply = reconcileAnalysisReply(
          cleanReply,
          body.corrected?.imdbId,
        );
        setAnalysisError(null);
        setAnalysisResult(reconciledReply || t("assistant.noAnalysis"));
        setPromptOpen(false);
        setAnalysisOpen(true);
        if (body.corrected) onCorrection(body.corrected);
        const proseReply = resolveAnalysisOverview(
          reconciledReply,
          body.metadata?.overview,
        );
        if (proseReply) onAnalysisResult?.(proseReply);
        return body.corrected ?? null;
      } catch (e: unknown) {
        if (e instanceof Error && e.name === "AbortError") {
          aborted = true;
          return null;
        }
        const error = `${t("assistant.analysisFailed")}：${e instanceof Error ? e.message : String(e)}`;
        const preserved = preserveAnalysisAfterFailure(analysisResult, error);
        setAnalysisError(preserved.error);
        setAnalysisResult(preserved.result);
        setAnalysisOpen(true);
        return null;
      } finally {
        if (controllerRef.current === controller) controllerRef.current = null;
        if (!aborted) setAnalyzing(false);
      }
    },
    [
      analysisResult,
      contextType,
      contextRef,
      lang,
      t,
      onCorrection,
      onAnalysisResult,
      onAnalysisMetadata,
    ],
  );

  return {
    prompt,
    setPrompt,
    promptOpen,
    setPromptOpen,
    analyzing,
    analyze,
    analysisResult,
    setAnalysisResult,
    analysisError,
    analysisOpen,
    setAnalysisOpen,
    analysisPosterUrl,
    setAnalysisPosterUrl,
    analysisMetadata,
    setAnalysisMetadata,
    promptFocusRequest,
    promptAttention,
    requestPromptFocus,
  };
}
