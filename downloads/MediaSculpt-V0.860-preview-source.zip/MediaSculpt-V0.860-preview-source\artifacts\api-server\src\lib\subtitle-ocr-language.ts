// Extracted from subtitle-ocr.ts: script/language detection and Tesseract tessdata management.
import { deflateSync, inflateSync } from "node:zlib";
import { createHash } from "node:crypto";
import path from "node:path";
import { access, mkdir } from "node:fs/promises";
import {
  resolveAiEndpoint,
  resolveApiKey,
  type AiProviderConfig,
} from "./ai-provider";
import { managedToolDirectory, resolveToolPath } from "./tool-runtime";
import { findDvdTitles, resolveDvdVideoTsDir } from "./disc";
import { isGraphicSubtitleCodec } from "./subtitle-utils";

// ── Language detection (fast, dependency-free) ────────────────────────────────
export const HAN = /[\u4e00-\u9fff]/;
export const KANA = /[\u3040-\u30ff]/;
export const HANGUL = /[\uac00-\ud7af]/;
export const CYRILLIC = /[\u0400-\u04ff]/;
export const GREEK = /[\u0370-\u03ff]/;
export const THAI = /[\u0e00-\u0e7f]/;
export const ARABIC = /[\u0600-\u06ff]/;
export const HEBREW = /[\u0590-\u05ff]/;
export const DEVANAGARI = /[\u0900-\u097f]/;
export const LATIN = /[a-zA-Z]/;

export function detectScriptLanguage(text: string): string {
  const sample = text.slice(0, 4000);
  const count = (re: RegExp) => (sample.match(re) || []).length;
  const han = count(HAN);
  const kana = count(KANA);
  const hangul = count(HANGUL);
  const cyrillic = count(CYRILLIC);
  const greek = count(GREEK);
  const thai = count(THAI);
  const arabic = count(ARABIC);
  const hebrew = count(HEBREW);
  const devanagari = count(DEVANAGARI);
  const latin = count(LATIN);
  if (kana > 0) return "ja";
  if (hangul > 0) return "ko";
  if (han > 0) return "zh";
  if (cyrillic > 0) return "ru";
  if (greek > 0) return "el";
  if (thai > 0) return "th";
  if (arabic > 0) return "ar";
  if (hebrew > 0) return "he";
  if (devanagari > 0) return "hi";
  if (latin > 0) return "en";
  return "unknown";
}

// Tesseract language codes used by the OCR preset picker. The keys are the
// canonical preset values stored on jobs; values are the tesseract data names.
export const OCR_LANGUAGE_CODES = [
  "auto",
  "eng",
  "chi_sim",
  "chi_tra",
  "jpn",
  "kor",
  "rus",
  "deu",
  "fra",
  "spa",
  "por",
  "ita",
  "nld",
  "pol",
  "tur",
  "ara",
  "heb",
  "tha",
  "vie",
  "ind",
  "msa",
  "ukr",
  "hun",
  "ces",
  "ell",
  "swe",
  "nor",
  "dan",
  "fin",
  "ron",
  "bul",
  "slv",
  "hrv",
  "srp",
  "slk",
  "lit",
  "lva",
  "est",
  "cat",
  "glg",
  "eus",
  "fas",
  "hin",
  "ben",
  "tam",
  "tel",
  "kan",
  "mal",
  "mar",
  "guj",
  "pan",
  "urd",
] as const;

export type OcrLanguageCode = (typeof OCR_LANGUAGE_CODES)[number];

// ISO 639-1 (or common ffprobe/HandBrake) tags → tesseract code.
export const ISO_TO_TESSERACT: Record<string, string> = {
  zh: "chi_sim",
  zho: "chi_sim",
  chi: "chi_sim",
  cmn: "chi_sim",
  yue: "chi_tra",
  ja: "jpn",
  jpn: "jpn",
  ko: "kor",
  kor: "kor",
  ru: "rus",
  rus: "rus",
  en: "eng",
  eng: "eng",
  de: "deu",
  deu: "deu",
  fr: "fra",
  fra: "fra",
  es: "spa",
  spa: "spa",
  pt: "por",
  por: "por",
  it: "ita",
  ita: "ita",
  nl: "nld",
  nld: "nld",
  pl: "pol",
  pol: "pol",
  tr: "tur",
  tur: "tur",
  ar: "ara",
  ara: "ara",
  he: "heb",
  heb: "heb",
  iw: "heb",
  th: "tha",
  tha: "tha",
  vi: "vie",
  vie: "vie",
  id: "ind",
  ind: "ind",
  ms: "msa",
  msa: "msa",
  uk: "ukr",
  ukr: "ukr",
  hu: "hun",
  hun: "hun",
  cs: "ces",
  ces: "ces",
  el: "ell",
  ell: "ell",
  sv: "swe",
  swe: "swe",
  no: "nor",
  nor: "nor",
  da: "dan",
  dan: "dan",
  fi: "fin",
  fin: "fin",
  ro: "ron",
  ron: "ron",
  bg: "bul",
  bul: "bul",
  sl: "slv",
  slv: "slv",
  hr: "hrv",
  hrv: "hrv",
  sr: "srp",
  srp: "srp",
  sk: "slk",
  slk: "slk",
  lt: "lit",
  lit: "lit",
  lv: "lva",
  lva: "lva",
  et: "est",
  est: "est",
  ca: "cat",
  cat: "cat",
  gl: "glg",
  glg: "glg",
  eu: "eus",
  eus: "eus",
  fa: "fas",
  fas: "fas",
  hi: "hin",
  hin: "hin",
  bn: "ben",
  ben: "ben",
  ta: "tam",
  tam: "tam",
  te: "tel",
  tel: "tel",
  kn: "kan",
  kan: "kan",
  ml: "mal",
  mal: "mal",
  mr: "mar",
  mar: "mar",
  gu: "guj",
  guj: "guj",
  pa: "pan",
  pan: "pan",
  ur: "urd",
  urd: "urd",
};

/** Map an OCR preset (or "auto") plus a stream language tag to a tesseract code. */
export function mapTesseractLanguage(
  language: string,
  streamLanguage?: string | null,
): string {
  const explicit = language.trim().toLowerCase();
  if (explicit !== "auto") {
    return ISO_TO_TESSERACT[explicit] ?? explicit;
  }
  const tag = (streamLanguage || "").trim().toLowerCase();
  return ISO_TO_TESSERACT[tag] ?? "eng";
}

/** Whether a stream language tag matches a requested OCR language preset. */
export function languageMatchesRequest(
  tag: string | null | undefined,
  requested: string,
): boolean {
  const norm = (tag || "").trim().toLowerCase();
  if (!norm) return false;
  const req = requested.trim().toLowerCase();
  if (norm === req) return true;
  const tess = ISO_TO_TESSERACT[norm];
  return tess ? tess === req : norm.startsWith(req.slice(0, 3));
}

/**
 * Locate the tessdata directory that belongs to a Tesseract executable.
 * UB-Mannheim/Homebrew/apt installs keep tessdata next to the binary (or one
 * level up when the binary lives in a bin/ subdirectory).
 */
export async function findTessdataDirectoryForTesseract(
  tesseractPath: string,
): Promise<string | null> {
  const candidates = [
    path.join(path.dirname(tesseractPath), "tessdata"),
    path.join(path.dirname(tesseractPath), "..", "tessdata"),
  ];
  for (const candidate of candidates) {
    try {
      const stat = await (await import("node:fs/promises")).stat(candidate);
      if (stat.isDirectory()) return candidate;
    } catch {
      // Try the next candidate.
    }
  }
  return null;
}

/** Verify that the traineddata for the requested OCR language is available. */
export async function ensureTesseractLanguageData(
  tesseractPath: string,
  language: string,
  managedTessdataDirectory = path.join(
    managedToolDirectory(),
    "tesseract",
    "tessdata",
  ),
): Promise<string> {
  const tessdata = await findTessdataDirectoryForTesseract(tesseractPath);
  if (
    tessdata &&
    (await fileExists(path.join(tessdata, `${language}.traineddata`)))
  )
    return tessdata;

  // System Tesseract commonly lives under Program Files, where a standard
  // user cannot install language packs. Keep downloaded models in the
  // per-user MediaSculpt tools directory and pass it explicitly to Tesseract.
  const traineddata = path.join(
    managedTessdataDirectory,
    `${language}.traineddata`,
  );
  if (await fileExists(traineddata)) return managedTessdataDirectory;
  await mkdir(path.dirname(traineddata), { recursive: true });
  const downloaded = await downloadTessdata(traineddata, language).catch(
    () => false,
  );
  if (!downloaded) {
    throw new Error(
      `缺少 Tesseract 语言数据：${language}.traineddata；已尝试自动下载到用户数据目录 ${managedTessdataDirectory}，但所有下载源均失败。` +
        `请检查网络，或在「设置 → 工具」中安装该语言数据，或切换 OCR 引擎。`,
    );
  }
  return managedTessdataDirectory;
}

async function fileExists(filePath: string): Promise<boolean> {
  try {
    await access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function downloadTessdata(
  targetPath: string,
  language: string,
): Promise<boolean> {
  const { rename, rm, writeFile } = await import("node:fs/promises");
  const temporaryPath = `${targetPath}.${process.pid}.${Date.now()}.download`;
  const repositories = ["tessdata_fast", "tessdata_best"];
  const mirrors = (repository: string) => [
    `https://cdn.jsdelivr.net/gh/tesseract-ocr/${repository}@main/${language}.traineddata`,
    `https://gitee.com/mirrors/${repository}/raw/master/${language}.traineddata`,
    `https://ghproxy.net/https://raw.githubusercontent.com/tesseract-ocr/${repository}/main/${language}.traineddata`,
    `https://gh-proxy.com/https://raw.githubusercontent.com/tesseract-ocr/${repository}/main/${language}.traineddata`,
    `https://raw.githubusercontent.com/tesseract-ocr/${repository}/main/${language}.traineddata`,
  ];
  for (const repository of repositories) {
    for (const url of mirrors(repository)) {
      try {
        const response = await fetch(url, {
          signal: AbortSignal.timeout(90_000),
        });
        if (!response.ok) continue;
        const buffer = Buffer.from(await response.arrayBuffer());
        if (buffer.length < 100_000) continue;
        await writeFile(temporaryPath, buffer);
        await rename(temporaryPath, targetPath);
        return true;
      } catch {
        await rm(temporaryPath, { force: true }).catch(() => {});
      }
    }
  }
  return false;
}
