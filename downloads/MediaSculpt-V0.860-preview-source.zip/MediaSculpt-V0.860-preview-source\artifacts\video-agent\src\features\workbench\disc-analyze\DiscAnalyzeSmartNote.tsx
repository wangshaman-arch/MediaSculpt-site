import { X } from "lucide-react";

export type DiscAnalyzeSmartNoteProps = {
  note: string;
  onDismiss: () => void;
};

export function DiscAnalyzeSmartNote({
  note,
  onDismiss,
}: DiscAnalyzeSmartNoteProps) {
  return (
    <div className="flex items-center justify-between gap-3 border-b bg-amber-400/5 px-4 py-1.5 text-xs text-amber-500/90">
      <span className="min-w-0 truncate">{note}</span>
      <button
        type="button"
        onClick={onDismiss}
        className="shrink-0 text-muted-foreground hover:text-foreground"
      >
        <X className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}
