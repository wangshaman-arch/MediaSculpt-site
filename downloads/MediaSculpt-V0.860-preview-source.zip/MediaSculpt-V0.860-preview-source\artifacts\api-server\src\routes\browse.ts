import { Router } from "express";
import fs from "fs/promises";
import path from "path";
import os from "os";

const router = Router();

const IS_WINDOWS = os.platform() === "win32";

const DRIVES_ROOT = "__drives__";

const VIDEO_EXTENSIONS = new Set([
  ".mkv",
  ".mp4",
  ".avi",
  ".mov",
  ".wmv",
  ".flv",
  ".m4v",
  ".ts",
  ".m2ts",
  ".iso",
  ".vob",
  ".rmvb",
  ".webm",
]);

async function listWindowsDrives(): Promise<
  { name: string; path: string; type: "dir" }[]
> {
  const drives: { name: string; path: string; type: "dir" }[] = [];
  // Probe all drive letters in parallel with a 500 ms timeout per letter so that
  // offline network-mapped drives (e.g. Z:\ on a disconnected share) don't stall
  // the entire response for 10+ seconds.
  const timeout = (ms: number) =>
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error("timeout")), ms),
    );
  const probes = Array.from({ length: 26 }, (_, i) =>
    String.fromCharCode(65 + i),
  ).map(async (letter) => {
    const drivePath = `${letter}:\\`;
    try {
      await Promise.race([fs.access(drivePath), timeout(500)]);
      drives.push({ name: `${letter}:`, path: drivePath, type: "dir" });
    } catch {
      // not accessible or timed out
    }
  });
  await Promise.all(probes);
  drives.sort((a, b) => a.name.localeCompare(b.name));
  return drives;
}

async function isBlurayDisc(dir: string): Promise<boolean> {
  try {
    const stat = await fs.stat(path.join(dir, "BDMV", "index.bdmv"));
    return stat.isFile();
  } catch {
    return false;
  }
}

async function isDvdDisc(dir: string): Promise<boolean> {
  try {
    const stat = await fs.stat(path.join(dir, "VIDEO_TS", "VIDEO_TS.IFO"));
    return stat.isFile();
  } catch {
    return false;
  }
}

router.get("/browse", async (req, res) => {
  const rawPath =
    (req.query["path"] as string | undefined) ??
    (IS_WINDOWS ? DRIVES_ROOT : "/");

  if (rawPath === DRIVES_ROOT) {
    if (IS_WINDOWS) {
      const drives = await listWindowsDrives();
      return res.json({
        path: DRIVES_ROOT,
        parent: null,
        discType: null,
        entries: drives,
      });
    }
    return res.redirect(`/api/browse?path=${encodeURIComponent("/")}`);
  }

  const targetPath = path.resolve(rawPath);

  // Directory missing → return empty result (200) instead of 500.
  // On Windows, go straight to the drive-list root so the user can navigate to the
  // correct location rather than getting stuck in a non-existent subtree.
  try {
    await fs.stat(targetPath);
  } catch {
    const parentFallback = IS_WINDOWS
      ? DRIVES_ROOT
      : targetPath === "/"
        ? null
        : path.dirname(targetPath);
    return res.json({
      path: targetPath,
      parent: parentFallback,
      discType: null,
      entries: [],
      warning: "目录不存在或无法访问",
    });
  }

  try {
    const entries = await fs.readdir(targetPath, { withFileTypes: true });

    // 逐条目容错：单个子目录/文件 stat 失败（系统保护目录拒绝访问、链接失效等）
    // 只跳过该项，不能拖垮整个目录列表（否则 C:\、D:\ 根目录会整体 500）。
    const dirs: Array<{
      name: string;
      path: string;
      type: "dir";
      modifiedAt: string;
    }> = [];
    const files: Array<{
      name: string;
      path: string;
      type: "file";
      sizeBytes: number;
      modifiedAt: string;
    }> = [];
    let skipped = 0;
    for (const entry of entries) {
      const entryPath = path.join(targetPath, entry.name);
      try {
        if (entry.isDirectory() && !entry.name.startsWith(".")) {
          const stat = await fs.stat(entryPath);
          dirs.push({
            name: entry.name,
            path: entryPath,
            type: "dir",
            modifiedAt: stat.mtime.toISOString(),
          });
        } else if (
          entry.isFile() &&
          VIDEO_EXTENSIONS.has(path.extname(entry.name).toLowerCase())
        ) {
          const stat = await fs.stat(entryPath);
          files.push({
            name: entry.name,
            path: entryPath,
            type: "file",
            sizeBytes: stat.size,
            modifiedAt: stat.mtime.toISOString(),
          });
        }
      } catch {
        skipped += 1;
      }
    }
    dirs.sort((a, b) => a.name.localeCompare(b.name));
    files.sort((a, b) => a.name.localeCompare(b.name));

    let parent: string | null;
    if (IS_WINDOWS) {
      const parsed = path.parse(targetPath);
      parent =
        targetPath === parsed.root ? DRIVES_ROOT : path.dirname(targetPath);
    } else {
      parent = targetPath === "/" ? null : path.dirname(targetPath);
    }

    // Detect if the current directory is a Blu-ray or DVD root
    let discType: "bluray" | "dvd" | null = null;
    if (await isBlurayDisc(targetPath)) discType = "bluray";
    else if (await isDvdDisc(targetPath)) discType = "dvd";

    // Detect disc type for each subdirectory
    const dirsWithDisc = await Promise.all(
      dirs.map(async (d) => {
        let entryDiscType: "bluray" | "dvd" | null = null;
        if (await isBlurayDisc(d.path)) entryDiscType = "bluray";
        else if (await isDvdDisc(d.path)) entryDiscType = "dvd";
        return { ...d, discType: entryDiscType };
      }),
    );

    return res.json({
      path: targetPath,
      parent,
      discType,
      entries: [...dirsWithDisc, ...files],
      ...(skipped > 0 ? { warning: `已跳过 ${skipped} 个无法访问的项` } : {}),
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return res.status(500).json({ error: `Cannot read directory: ${msg}` });
  }
});

export default router;
