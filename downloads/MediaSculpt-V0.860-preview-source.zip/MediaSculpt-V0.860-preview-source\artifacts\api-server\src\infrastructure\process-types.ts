import type { ChildProcess } from "node:child_process";

export interface ProcessRequest {
  executable: string;
  args: string[];
  cwd?: string;
  env?: NodeJS.ProcessEnv;
  jobId?: number;
  stage?: string;
  signal?: AbortSignal;
  /** Maximum bytes retained per output stream; streams are still drained after the limit. */
  maxOutputBytes?: number;
  /** Optional data written to stdin before it is closed. */
  stdin?: string | Buffer;
  /** Abort and reject a process that exceeds this duration. */
  timeoutMs?: number;
}

export interface ProcessResult {
  code: number | null;
  signal?: NodeJS.Signals | null;
  stdout: string;
  stderr: string;
  durationMs: number;
}

export interface ManagedProcess {
  child: ChildProcess;
  completed: Promise<ProcessResult>;
  kill(signal?: NodeJS.Signals): boolean;
}

export interface ProcessRunner {
  run(request: ProcessRequest): Promise<ProcessResult>;
  spawn(request: ProcessRequest): ManagedProcess;
}
