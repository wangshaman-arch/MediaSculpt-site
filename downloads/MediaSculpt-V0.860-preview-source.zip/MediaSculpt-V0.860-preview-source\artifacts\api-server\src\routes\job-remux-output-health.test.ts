import { describe, expect, it } from "vitest";
import { isPlayableRemuxProbe } from "./job-remux-output-health";

describe("Remux output health", () => {
  it("accepts a probe with a video stream and positive duration", () => {
    expect(
      isPlayableRemuxProbe({ duration: 12, streams: [{ codecType: "video" }] }),
    ).toBe(true);
  });

  it("rejects empty, audio-only, and zero-duration outputs", () => {
    expect(isPlayableRemuxProbe({ duration: 12, streams: [] })).toBe(false);
    expect(
      isPlayableRemuxProbe({ duration: 12, streams: [{ codecType: "audio" }] }),
    ).toBe(false);
    expect(
      isPlayableRemuxProbe({ duration: 0, streams: [{ codecType: "video" }] }),
    ).toBe(false);
    expect(isPlayableRemuxProbe(null)).toBe(false);
  });
});
