// Extracted from routes/jobs.ts: audio track selection and probing.
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import {
  lookupAll,
  metadataIdentityMatches,
  normalizeTitleEn,
} from "../lib/metadata";
import {
  servePreviewSegment,
  cleanupPreviewSegments,
} from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import {
  buildFfconcatFileContent as buildManifest,
  buildFfconcatChapterContent,
  buildFfconcatTimedContent,
  type FfconcatTimedSegment,
} from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import {
  appendJobRuntimeLog,
  appendJobToolOutput,
} from "../lib/job-runtime-log";
import {
  appendRuntimeToolLog,
  appendRuntimeToolOutput,
} from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { dvdInputArg } from "./jobs-dvd";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import {
  buildCompressionOutputName,
  buildRemuxOutputName,
  cleanSegment,
  encoderBitDepth,
  selectBestAudioTrack,
} from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import {
  renderBilingualAss,
  DEFAULT_BILINGUAL_STYLE,
  type BilingualAssStyle,
  type SubtitleBlock,
} from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import {
  ensureLocalPoster,
  MEDIA_INFO_DIR,
  POSTER_META_FILE,
  posterIdentityMatches,
} from "../lib/poster";
import {
  ensureFasterWhisperModel,
  ensureWhisperCliScript,
} from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import {
  hasValidSubtitleCues,
  isGraphicSubtitleCodec,
  shouldFallbackToWhisper,
} from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import {
  buildDvdRemuxArgs,
  runDvdRemux,
  verifyDvdTitle,
} from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import {
  buildDvdStructurePayload,
  resolveRemuxPlanWithLlm,
  validateRemuxPlan,
} from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import {
  assertPreviewTaskAllowed,
  recordPreviewAiCall,
  settlePreviewTask,
} from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import {
  parseCustomTuning,
  resolveLogicPlaceholders,
} from "../lib/custom-tuning";
import {
  decryptSecret,
  encryptSecret,
  isEncryptedSecret,
} from "../lib/secrets";
import {
  ffmpegPath,
  resolveOutputDir,
  resolveRuntimePath,
  type RuntimePathConfig,
} from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import {
  assertCompleteMediaTitle,
  createDvdMediaTitle,
} from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import {
  buildPreviewTranscodeArgs,
  isPreviewVideoCandidate,
  previewService,
} from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";

type AudioTrackInfo = {
  typeIndex: number;
  language: string | null;
  channels: number | null;
  codec: string | null;
  bitRate: number | null;
};

/**
 * Score an audio track for Whisper transcription: English first, then any
 * non-Russian language (Russian dubs on pirate discs are often poor-quality
 * first tracks), then quality signals (channels, codec, bitrate).
 */
function scoreAudioTrack(track: AudioTrackInfo): number {
  const lang = (track.language ?? "").toLowerCase();
  let score = 0;
  if (lang === "eng") score += 50;
  else if (lang && lang !== "rus" && lang !== "und") score += 30;
  const channels = track.channels ?? 0;
  if (channels >= 6) score += 20;
  else if (channels >= 2) score += 8;
  if (/dts|truehd|eac3|ac3/.test(track.codec ?? "")) score += 10;
  if (track.bitRate && track.bitRate >= 256_000) score += 5;
  return score;
}

export function pickBestAudioTrack(
  streams: Array<{
    index?: number;
    codec_type?: string;
    codec_name?: string;
    channels?: number;
    sample_rate?: string | number;
    bit_rate?: string | number;
    tags?: { language?: string };
  }>,
): AudioTrackInfo | null {
  const audio = streams
    .filter((stream) => stream.codec_type === "audio")
    .map((stream, typeIndex) => ({
      typeIndex,
      language: stream.tags?.language ?? null,
      channels: Number(stream.channels) > 0 ? Number(stream.channels) : null,
      codec: stream.codec_name ?? null,
      bitRate: Number(stream.bit_rate) > 0 ? Number(stream.bit_rate) : null,
    }));
  if (audio.length === 0) return null;
  return audio.reduce((best, current) =>
    scoreAudioTrack(current) > scoreAudioTrack(best) ? current : best,
  );
}

export async function probeAudioTracks(
  filePath: string,
  isDisc: boolean,
): Promise<
  Array<{
    index?: number;
    codec_type?: string;
    codec_name?: string;
    channels?: number;
    sample_rate?: string | number;
    bit_rate?: string | number;
    tags?: { language?: string };
  }>
> {
  const ffprobe = (await resolveToolPath("ffprobe")) ?? "ffprobe";
  return new Promise((resolve) => {
    const args = isDisc
      ? [
          "-v",
          "quiet",
          "-print_format",
          "json",
          "-f",
          "dvdvideo",
          "-show_streams",
          dvdInputArg(filePath),
        ]
      : [
          "-v",
          "quiet",
          "-print_format",
          "json",
          "-show_streams",
          ffmpegPath(filePath),
        ];
    const proc = jobProcessController.spawn(ffprobe, args, 30_000);
    let out = "";
    proc.stdout?.on("data", (d: Buffer) => (out += d));
    proc.on("close", () => {
      try {
        const parsed = JSON.parse(out) as {
          streams?: Array<{
            index?: number;
            codec_type?: string;
            codec_name?: string;
            channels?: number;
            sample_rate?: string | number;
            bit_rate?: string | number;
            tags?: { language?: string };
          }>;
        };
        resolve(parsed.streams ?? []);
      } catch {
        resolve([]);
      }
    });
    proc.on("error", () => resolve([]));
  });
}
