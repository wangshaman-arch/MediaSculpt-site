import type { DiscAnalysisResult, UnifiedDiscTitle } from "./disc-analysis";

/**
 * 判定一张光碟在解析上是否"复杂/特殊"，需要把真实结构推给 LLM 来给出更合理的
 * remux 逻辑。只覆盖"结构含糊/多义"，不含"损坏/文件缺失"——那类应在确定性阶段
 * 报错，而非推给 LLM（LLM 不能凭空造出缺失的数据）。
 */

export type DiscComplexitySignal =
  | "no-main-title"
  | "ambiguous-main"
  | "multi-audio-language"
  | "forced-subtitles"
  | "conflicting-tool-scan";

export type DiscComplexityVerdict = {
  complex: boolean;
  reasons: string[];
  signals: DiscComplexitySignal[];
};

/** 仅统计有意义的标题（≥ 5 分钟且含视频轨）。 */
function meaningfulTitles(titles: UnifiedDiscTitle[]): UnifiedDiscTitle[] {
  return titles.filter(
    (title) =>
      (title.videoTracks?.length ?? 0) > 0 &&
      (title.durationSeconds ?? 0) >= 300,
  );
}

function formatSeconds(seconds: number | null): string {
  if (!seconds) return "--";
  const m = Math.floor(seconds / 60);
  return `${m} 分钟`;
}

export function assessDiscComplexity(
  analysis: DiscAnalysisResult,
): DiscComplexityVerdict {
  const reasons: string[] = [];
  const signals: DiscComplexitySignal[] = [];
  const titles = meaningfulTitles(analysis.titles ?? []);

  if (titles.length === 0) {
    reasons.push("没有解析到任何有意义的（≥5 分钟）主影片标题");
    signals.push("no-main-title");
    return { complex: true, reasons, signals };
  }

  // 主影片不唯一：前两名时长接近且都较长；某张碟可能包含多个正片。
  const sorted = [...titles].sort(
    (a, b) => (b.durationSeconds ?? 0) - (a.durationSeconds ?? 0),
  );
  const longest = sorted[0].durationSeconds ?? 0;
  const second = sorted[1]?.durationSeconds ?? 0;
  if (sorted.length >= 2 && longest >= 40 * 60 && second > longest * 0.8) {
    reasons.push(
      `主影片不唯一：${sorted[0].displayName}（${formatSeconds(sorted[0].durationSeconds)}）与 ` +
        `${sorted[1].displayName}（${formatSeconds(sorted[1].durationSeconds)}）时长接近，需判定正片`,
    );
    signals.push("ambiguous-main");
  }
  // 标题多本身是常见形态（剧集/合集），确定性解析已能处理，不算"复杂"，
  // 仅作备注；真正需要 LLM 的是下方的真正多义信号。
  if (titles.length >= 8) {
    reasons.push(
      `标题数量较多（${titles.length} 个），疑似剧集/多集合集（确定性解析可处理，仅备注）`,
    );
  }

  // 主候选含多音轨语言：常见于多语版/导演评论版，音频选择需要斟酌。
  const main = sorted[0];
  const audioLangs = new Set(
    (main.audioTracks ?? []).map((a) => a.language).filter(Boolean),
  );
  if (audioLangs.size >= 2) {
    reasons.push(
      `主标题包含多种音轨语言（${[...audioLangs].join("、")}），需确认保留顺序`,
    );
    signals.push("multi-audio-language");
  }

  // 强制字幕轨：需要决定是否烧录/保留。
  const subtitleTracks = main.subtitleTracks ?? [];
  if (subtitleTracks.some((s) => s.forced)) {
    reasons.push("主标题含强制字幕轨，需决定保留/烧录处理");
    signals.push("forced-subtitles");
  }

  // 手工映射状态（handbrake↔dvdvideo 未对齐/工具扫描存在分歧）。
  const mappingConflicted = (analysis.titles ?? []).some(
    (t) => t.mappingStatus === "unmapped" || t.verificationStatus === "failed",
  );
  if (mappingConflicted) {
    reasons.push("存在标题映射未对齐/验证失败，工具扫描结果存在分歧");
    signals.push("conflicting-tool-scan");
  }

  return { complex: signals.length > 0, reasons, signals };
}
