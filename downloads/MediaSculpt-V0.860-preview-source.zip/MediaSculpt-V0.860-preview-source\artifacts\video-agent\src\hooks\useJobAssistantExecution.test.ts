import { describe, expect, it } from "vitest";
import type { Job } from "@workspace/api-client-react";
import {
  buildCompressionPatch,
  buildJobMetadataPatch,
  buildPipelinePatch,
  type AssistantIdentity,
} from "./useJobAssistantExecution";
import { DEFAULT_COMPRESSION_PRESETS } from "../lib/compression-presets";

const baseJob = {
  id: 1,
  filePath: "/movies/a.mkv",
  status: "pending",
  createdAt: "2024-01-01T00:00:00.000Z",
  movieTitle: "旧标题",
  movieTitleEn: "Old Title",
  movieYear: 2001,
  movieImdbId: "tt0000001",
} as unknown as Job;

const identity: AssistantIdentity = {
  titleEn: "New Title",
  titleZh: "新标题",
  year: 2020,
  imdbId: "tt1234567",
};

describe("useJobAssistantExecution helpers", () => {
  it("only patches metadata fields that actually changed", () => {
    expect(buildJobMetadataPatch(baseJob, identity)).toEqual({
      movieTitle: "新标题",
      movieTitleEn: "New Title",
      movieYear: 2020,
      movieImdbId: "tt1234567",
    });

    const unchanged: AssistantIdentity = {
      titleEn: "Old Title",
      titleZh: "旧标题",
      year: 2001,
      imdbId: "tt0000001",
    };
    expect(buildJobMetadataPatch(baseJob, unchanged)).toEqual({});
    expect(buildJobMetadataPatch(baseJob, null)).toEqual({});
  });

  it("builds pipeline patch and drops chapterPreview from the main task", () => {
    const { patch, previewPlusOthers } = buildPipelinePatch({
      processing: ["chapterPreview", "compress"],
      baselineProcessing: ["compress"],
      subtitle: "auto",
      baselineSubtitle: "auto",
      chapterSamplePosition: "end",
    });
    expect(previewPlusOthers).toBe(true);
    expect(patch).toEqual({
      pipelineSteps: ["compress"],
      chapterSamplePosition: "end",
    });
  });

  it("does not emit pipeline fields when nothing changed", () => {
    const { patch, previewPlusOthers } = buildPipelinePatch({
      processing: ["compress"],
      baselineProcessing: ["compress"],
      subtitle: "skip",
      baselineSubtitle: "skip",
      chapterSamplePosition: "middle",
    });
    expect(previewPlusOthers).toBe(false);
    expect(patch).toEqual({});
  });

  it("emits a subtitleMode change independently of steps", () => {
    const { patch } = buildPipelinePatch({
      processing: ["compress"],
      baselineProcessing: ["compress"],
      subtitle: "whisper",
      baselineSubtitle: "auto",
      chapterSamplePosition: "middle",
    });
    expect(patch).toEqual({ subtitleMode: "whisper" });
  });

  it("builds compression settings from a built-in preset", () => {
    const patch = buildCompressionPatch({
      selectedPresetLabel: "balanced",
      compressionPresets: DEFAULT_COMPRESSION_PRESETS,
      config: undefined,
    });
    expect(patch.presetId).toBe("balanced");
    expect(patch.compressionSettings).toMatchObject({ encoder: "x265_10bit" });
  });

  it("falls back to global config for the custom preset", () => {
    const patch = buildCompressionPatch({
      selectedPresetLabel: "custom",
      compressionPresets: DEFAULT_COMPRESSION_PRESETS,
      config: { encoder: "x264", crf: 20 } as never,
    });
    expect(patch).toEqual({
      presetId: "custom",
      compressionSettings: expect.objectContaining({
        encoder: "x264",
        crf: 20,
      }),
    });
  });
});
