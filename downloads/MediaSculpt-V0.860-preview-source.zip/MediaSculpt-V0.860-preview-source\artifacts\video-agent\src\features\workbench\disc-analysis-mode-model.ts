import type {
  ProcessingMode,
  SubtitleMode,
} from "../../hooks/useWorkbenchState";

export type DiscAnalysisDialogBehavior = {
  showModePicker: boolean;
  includeVideoStreams: boolean;
  verifyDvdTitles: boolean;
  filterTitlesByProcessingMode: boolean;
  allowJobCreation: boolean;
};

/**
 * The smart-workflow disc preview is an analysis surface, not a job creator.
 * Keep this separate from ProcessingMode: `none` is a real subtitle-only mode
 * and must not be reused to represent an undecided workflow state.
 */
export function discAnalysisDialogBehavior(input: {
  analysisOnly?: boolean;
  processingMode: ProcessingMode;
  subtitleMode: SubtitleMode;
}): DiscAnalysisDialogBehavior {
  if (input.analysisOnly) {
    return {
      showModePicker: false,
      includeVideoStreams: true,
      verifyDvdTitles: true,
      filterTitlesByProcessingMode: false,
      allowJobCreation: false,
    };
  }

  const showModePicker =
    input.processingMode === "none" && input.subtitleMode === "skip";
  const videoProcessing =
    input.processingMode === "remux" || input.processingMode === "compress";

  return {
    showModePicker,
    includeVideoStreams: input.processingMode !== "none",
    verifyDvdTitles: videoProcessing,
    filterTitlesByProcessingMode: true,
    allowJobCreation: true,
  };
}
