import { describe, expect, it } from "vitest";
import { toSimplifiedChinese } from "./chinese-utils";

describe("toSimplifiedChinese", () => {
  it("converts traditional Chinese to simplified deterministically", () => {
    expect(toSimplifiedChinese("我們認識因為 裡面 台灣 香港 乾杯")).toBe(
      "我们认识因为 里面 台湾 香港 干杯",
    );
  });

  it("leaves already-simplified text unchanged", () => {
    expect(toSimplifiedChinese("我们认识因为 里面 台湾 干杯")).toBe(
      "我们认识因为 里面 台湾 干杯",
    );
  });

  it("keeps non-Chinese content intact", () => {
    expect(toSimplifiedChinese("Hello 世界 123")).toBe("Hello 世界 123");
  });
});
