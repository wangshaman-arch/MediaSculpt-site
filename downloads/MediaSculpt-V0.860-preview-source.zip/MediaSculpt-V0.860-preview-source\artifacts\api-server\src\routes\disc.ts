import { Router } from "express";
import fs from "fs/promises";
import path from "path";
import { db, jobsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
} from "../lib/disc-analysis";
import {
  parseBlurayMpls,
  resolveDvdTitleForSource,
  resolveDvdVideoTsDir,
} from "../lib/disc";
import { assessDiscComplexity } from "../lib/disc-complexity";
import {
  buildDvdStructurePayload,
  resolveRemuxPlanWithLlm,
  validateRemuxPlan,
} from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { verifyDvdTitle } from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { resolveToolPath } from "../lib/tool-runtime";
import {
  appendRuntimeToolLog,
  appendRuntimeToolOutput,
} from "../lib/runtime-tool-log";
import { ffmpegPath, resolveRuntimePath } from "../lib/runtime-paths";
import { processRunner } from "../infrastructure/process-runner";
import {
  discAnalysisCache,
  discAnalysisRegistry,
  DVD_VERIFICATION_CACHE_TTL_MS,
  dvdTitleVerificationCache,
  dvdTitleVerificationInFlight,
} from "../lib/disc-analysis-registry";
import { dvdVideoInputPath, ffprobeCmd, ensureDvdCssSupport } from "./jobs-dvd";
import {
  ensureAnalysisIsoReady,
  mountBlurayIso,
  registerIsoMount,
  unmountBlurayIso,
} from "./jobs-iso";
import { getConfig } from "./jobs-config";
import { isBlurayDisc, isDvdDisc } from "../lib/disc";

const router = Router();
router.post("/disc/analyze/smart", async (req, res) => {
  const analysisId =
    typeof req.body?.analysisId === "string" ? req.body.analysisId.trim() : "";
  const force = req.body?.force === true;
  if (!analysisId)
    return res.status(400).json({ error: "analysisId 不能为空" });
  const analysis = discAnalysisRegistry.find(analysisId);
  if (!analysis)
    return res.status(404).json({ error: "分析不存在，请重新分析后重试" });
  if (analysis.mediaType !== "dvd") {
    return res.json({
      invoked: false,
      complex: false,
      applied: false,
      reason: "智能标题校验目前只适用于 DVD 光盘",
      reasons: [],
    });
  }

  const verdict = assessDiscComplexity(analysis);
  if (!force && !verdict.complex) {
    return res.json({
      invoked: false,
      complex: false,
      applied: false,
      reasons: verdict.reasons,
    });
  }

  const config = await getConfig();
  const ffprobeExecutable =
    (await resolveToolPath("ffprobe").catch(() => null)) ?? "ffprobe";
  const ffmpegExecutable =
    (await resolveToolPath("ffmpeg").catch(() => null)) ?? "ffmpeg";
  await ensureDvdCssSupport(ffmpegExecutable);
  await appendRuntimeToolLog(
    `智能解析（${force ? "用户强制" : "结构复杂"}）：开始校验 ${analysis.titles.length} 个候选标题；${verdict.reasons.slice(0, 3).join("；") || "用户强制智能解析"}`,
  ).catch(() => {});
  let manifest;
  try {
    manifest = await buildDvdSmartManifest({
      analysis,
      ffprobeExecutable,
      ffmpegExecutable,
    });
  } catch (error) {
    const reason = `DVD 智能校验失败：${error instanceof Error ? error.message : String(error)}`;
    await appendRuntimeToolLog(reason).catch(() => {});
    return res.json({
      invoked: true,
      complex: verdict.complex,
      applied: false,
      reason,
      reasons: verdict.reasons,
    });
  }

  // AI is advisory only. It receives the same real analysis, but can only be
  // attached when its title and stream references are already selected by the
  // deterministic validator.
  if (manifest.selectedTitleIds.length > 0) {
    try {
      const raw = await resolveRemuxPlanWithLlm({
        structure: buildDvdStructurePayload(analysis),
        config,
      });
      if (raw) {
        const validated = validateRemuxPlan(raw, analysis);
        const aiCandidate =
          validated.ok && validated.plan
            ? manifest.candidates.find(
                (candidate) =>
                  candidate.titleId === validated.plan?.titleId &&
                  candidate.status === "selected",
              )
            : null;
        if (validated.ok && validated.plan && aiCandidate) {
          manifest.ai = {
            titleId: validated.plan.titleId,
            videoIndex: validated.plan.videoIndex,
            audioIndices: validated.plan.audioIndices,
            subtitleIndices: validated.plan.subtitleIndices,
            reason: validated.plan.reason,
            confidence: validated.plan.confidence,
          };
          await appendRuntimeToolLog(
            `AI 仅作辅助排序：标题=${validated.plan.titleId}，确定性选择=${manifest.selectedTitleIds.join(", ")}`,
          ).catch(() => {});
        }
      }
    } catch (error) {
      await appendRuntimeToolLog(
        `AI 辅助解析不可用，保留确定性 manifest：${error instanceof Error ? error.message : String(error)}`,
      ).catch(() => {});
    }
  }
  const primaryTitle = analysis.titles.find(
    (title) => title.titleId === manifest.selectedTitleIds[0],
  );
  const primaryVideo = primaryTitle?.videoTracks?.[0]?.index ?? null;
  const primaryAudio =
    primaryTitle?.audioTracks?.map((stream) => stream.index) ?? [];
  const primarySubtitles =
    primaryTitle?.subtitleTracks?.map((stream) => stream.index) ?? [];
  await appendRuntimeToolLog(
    `智能校验完成：选择=${manifest.selectedTitleIds.join(", ") || "无"}（${manifest.confidence}），物理容量=${manifest.capacity.countedPhysicalBytes}/${manifest.capacity.physicalBytes ?? "未知"}`,
  ).catch(() => {});
  return res.json({
    invoked: true,
    complex: verdict.complex,
    applied: manifest.selectedTitleIds.length > 0,
    titleId: manifest.selectedTitleIds[0] ?? null,
    videoIndex: primaryVideo,
    audioIndices: primaryAudio,
    subtitleIndices: primarySubtitles,
    reason: manifest.reasons.join("；"),
    ...manifest,
    confidence: manifest.confidence,
    reasons: [...verdict.reasons, ...manifest.reasons],
  });
});

// GET /disc/analyze?path= — analyze a BD/DVD directory and return all tracks with stream info
async function estimateDvdTitleSizes(
  videoTsDir: string,
  titles: Array<{
    durationSeconds?: number | null;
    estimatedSize?: number | null;
    toolMappings?: { physicalVtsNumber?: number | null };
  }>,
): Promise<Array<number | null>> {
  const entries = await fs.readdir(videoTsDir).catch(() => [] as string[]);
  const vtsSizes = new Map<number, number>();
  for (const name of entries) {
    const match = /^VTS_(\d+)_\d+\.VOB$/i.exec(name);
    if (!match) continue;
    const stat = await fs.stat(path.join(videoTsDir, name)).catch(() => null);
    const vtsNumber = Number(match[1]);
    if (stat && Number.isInteger(vtsNumber) && vtsNumber > 0) {
      vtsSizes.set(vtsNumber, (vtsSizes.get(vtsNumber) ?? 0) + stat.size);
    }
  }
  return mapDvdTitleSizes(
    titles.map((title) => ({
      ...title,
      exactSizeBytes: title.estimatedSize,
    })),
    vtsSizes,
  );
}

router.get("/disc/analyze", async (req, res) => {
  const rawPath = String(req.query.path ?? "");
  if (!rawPath) return res.status(400).json({ error: "path 参数不能为空" });

  const cfg = await getConfig();
  const runtimePath = resolveRuntimePath(rawPath, cfg);
  const targetPath = path.resolve(runtimePath);

  let discType: "bluray" | "dvd";
  const isIsoPath = /\.iso$/i.test(targetPath);
  const isoDrive = isIsoPath ? await mountBlurayIso(targetPath) : null;
  const cleanupIso = async () => {
    if (isoDrive) await unmountBlurayIso(targetPath).catch(() => {});
  };
  if (isIsoPath) {
    if (!isoDrive)
      return res.status(400).json({
        error:
          "无法挂载 ISO 镜像（文件可能被占用、路径无效或系统不支持 Mount-DiskImage），请稍后重试",
      });
    if (await isBlurayDisc(isoDrive)) discType = "bluray";
    else if (await isDvdDisc(isoDrive)) discType = "dvd";
    else {
      await cleanupIso();
      return res
        .status(400)
        .json({ error: "ISO 内容不是有效的蓝光或 DVD 目录" });
    }
  } else {
    if (await isBlurayDisc(targetPath)) discType = "bluray";
    else if (await isDvdDisc(targetPath)) discType = "dvd";
    else
      return res.status(400).json({ error: "该目录不是有效的蓝光或 DVD 目录" });
  }

  const force = req.query.force === "1" || req.query.force === "true";
  const discRootForAnalysis = isIsoPath ? isoDrive! : targetPath;
  const analysisSourcePath =
    discType === "dvd"
      ? ((await resolveDvdVideoTsDir(discRootForAnalysis)) ??
        discRootForAnalysis)
      : normalizeDiscSourcePath(discRootForAnalysis);
  const sourceFingerprint = await buildDiscSourceFingerprint(
    analysisSourcePath,
    discType,
  );
  const cacheKey = buildDiscAnalysisCacheKey({
    sourcePath: isIsoPath ? targetPath : analysisSourcePath,
    sourceFingerprint,
    mediaType: discType,
  });
  const cachedAnalysis = await discAnalysisCache.getOrAnalyze(
    { cacheKey, force },
    async () =>
      analyzeDiscSource({
        sourcePath: analysisSourcePath,
        mediaType: discType,
        sourceFingerprint,
        handbrakeCliPath: cfg.handbrakeCliPath,
      }),
  );
  const unified = cachedAnalysis.value;
  discAnalysisRegistry.remember(unified);
  if (isIsoPath && isoDrive) {
    // Keep the ISO mounted so verify-title / title-preview / job creation can
    // still access the drive letter stored in the analysis. The previous ISO
    // (if any) is unmounted here to avoid accumulating virtual drives.
    unified.isoPath = targetPath;
    await registerIsoMount(targetPath, isoDrive);
  }
  if (!cachedAnalysis.cached && !cachedAnalysis.shared) {
    for (const diagnostic of unified.diagnostics) {
      await appendRuntimeToolOutput({
        tool: diagnostic.tool,
        executable: diagnostic.executable ?? "unavailable",
        args: diagnostic.args,
        exitCode: diagnostic.exitCode,
        durationMs: diagnostic.durationMs,
        stdout: diagnostic.stdout,
        stderr: diagnostic.stderr,
      }).catch(() => {});
    }
  }
  await appendRuntimeToolLog(
    `光盘分析 ${unified.analysisId} source=${analysisSourcePath} cache=${cachedAnalysis.cached ? "hit" : cachedAnalysis.shared ? "shared" : "miss"} tools=${unified.diagnostics.map((item) => `${item.tool}:${item.executable ?? "unavailable"}:${item.durationMs}ms:exit=${item.exitCode ?? "n/a"}`).join(",")} memory=${Math.round(process.memoryUsage().rss / 1024 / 1024)}MB diagnostics=${unified.diagnosticLogPath ?? "unavailable"}`,
  ).catch(() => {});
  if (unified.titles.length > 0) {
    const dvdTitleSizes =
      discType === "dvd"
        ? await estimateDvdTitleSizes(analysisSourcePath, unified.titles)
        : unified.titles.map(() => null);
    return res.json({
      discType,
      analysisId: unified.analysisId,
      sourceFingerprint: unified.sourceFingerprint,
      sourceSizeBytes: unified.sourceSizeBytes ?? null,
      cache: {
        hit: cachedAnalysis.cached,
        shared: cachedAnalysis.shared,
        force,
      },
      diagnosticLogPath: unified.diagnosticLogPath,
      diagnostics: summarizeDiscDiagnostics(unified.diagnostics),
      warnings: unified.warnings,
      exportCandidates: unified.exportCandidates,
      tracks: unified.titles.map((title, titleIndex) => {
        const estimatedTitleSize = dvdTitleSizes[titleIndex];
        const sizeBytes = estimatedTitleSize ?? 0;
        const streamSizes = fillStreamSizeEstimates(
          title.streams.map((stream) => ({
            ...stream,
            codecName: stream.codecName ?? "unknown",
          })),
          title.durationSeconds,
          sizeBytes,
        );
        // A DVD title number is a logical playback chain. Without an exact
        // physical VTS mapping, bitrate-based stream sizes are not additive
        // disk usage and must not be presented as precise bytes.
        const displayStreams =
          sizeBytes > 0
            ? streamSizes
            : streamSizes.map((stream) => {
                const copy = { ...stream };
                delete copy.estimatedSizeBytes;
                return copy;
              });
        return {
          path: title.sourcePath,
          sourcePath: title.sourcePath,
          titleKind: title.titleKind ?? null,
          previewSourcePath: title.previewSourcePath ?? null,
          titleId: title.titleId,
          titleUid: title.titleUid ?? null,
          titleIndex: title.titleIndex,
          name: title.displayName,
          titleNumber: title.toolMappings.handbrakeTitleNumber,
          handbrakeTitleNumber: title.toolMappings.handbrakeTitleNumber,
          makemkvTitleIndex: title.toolMappings.makemkvTitleIndex,
          playlistId: title.toolMappings.playlistId,
          mappingStatus: title.mappingStatus,
          verificationStatus:
            title.verificationStatus ??
            (discType === "dvd" ? "pending" : "verified"),
          verificationFailureReason: title.verificationFailureReason ?? null,
          availabilityStatus: title.availabilityStatus ?? "confirmed",
          availabilityFailureReason: title.availabilityFailureReason ?? null,
          dvdVtsNumber: title.toolMappings.dvdVtsNumber,
          physicalVtsNumber: title.toolMappings.physicalVtsNumber ?? null,
          sizeBytes,
          physicalRanges: title.physicalRanges ?? [],
          durationSeconds: title.durationSeconds,
          chapterCount: title.chapterCount,
          videoTracks: title.videoTracks,
          audioTracks: title.audioTracks,
          subtitleTracks: title.subtitleTracks,
          streams: displayStreams,
          chapters: title.chapters,
          analyzer: "unified",
        };
      }),
    });
  }

  if (discType === "dvd") {
    await cleanupIso();
    return res.status(422).json({
      error:
        "HandBrakeCLI 未能解析 DVD 标题；已停止分析，未调用 ffprobe 兜底。",
      discType,
      analysisId: unified.analysisId,
      sourceFingerprint: unified.sourceFingerprint,
      cache: {
        hit: cachedAnalysis.cached,
        shared: cachedAnalysis.shared,
        force,
      },
      diagnosticLogPath: unified.diagnosticLogPath,
      diagnostics: summarizeDiscDiagnostics(unified.diagnostics),
      warnings: unified.warnings,
      exportCandidates: [],
      tracks: [],
    });
  }

  async function probeStreams(filePath: string) {
    try {
      const ffprobeP = await ffprobeCmd();
      const out = await new Promise<string>((resolve, reject) => {
        const p = processRunner.spawn({
          executable: ffprobeP,
          args: buildFfprobeAnalysisArgs(ffmpegPath(filePath)),
          stage: "metadata-probe-streams",
          timeoutMs: 60_000,
        }).child;
        let data = "";
        p.stdout?.on("data", (d: Buffer) => (data += d));
        p.on("close", (code: number | null) =>
          code === 0
            ? resolve(data)
            : reject(new Error(`ffprobe exit ${code}`)),
        );
        p.on("error", reject);
      });
      const parsed = JSON.parse(out);
      const streams: unknown[] = parsed.streams ?? [];
      const durationSeconds: number | null = parsed.format?.duration
        ? parseFloat(parsed.format.duration)
        : null;
      const chapters = (parsed.chapters ?? []).map(
        (chapter: Record<string, unknown>, index: number) => ({
          id: index,
          startSeconds: Number(chapter.start_time ?? 0),
          endSeconds: Number(chapter.end_time ?? 0),
          title: ((chapter.tags ?? {}) as Record<string, string>).title ?? null,
        }),
      );
      return {
        streams: streams.map((s) => {
          const st = s as Record<string, unknown>;
          const tags = (st.tags ?? {}) as Record<string, string>;
          return {
            index: Number(st.index ?? 0),
            codecType: String(st.codec_type ?? ""),
            codecName: String(st.codec_name ?? ""),
            language: tags.language ?? null,
            title: tags.title ?? null,
            width: st.width ? Number(st.width) : null,
            height: st.height ? Number(st.height) : null,
            channels: st.channels ? Number(st.channels) : null,
            default:
              Number(
                (st.disposition as Record<string, unknown>)?.default ?? 0,
              ) === 1,
            forced:
              Number(
                (st.disposition as Record<string, unknown>)?.forced ?? 0,
              ) === 1,
          };
        }),
        durationSeconds,
        chapters,
      };
    } catch {
      return { streams: [], durationSeconds: null, chapters: [] };
    }
  }

  try {
    const streamDir = path.join(discRootForAnalysis, "BDMV", "STREAM");
    const playlistDir = path.join(discRootForAnalysis, "BDMV", "PLAYLIST");
    const playlistEntries = await fs
      .readdir(playlistDir)
      .catch(() => [] as string[]);
    const playlists = await Promise.all(
      playlistEntries
        .filter((f) => f.toLowerCase().endsWith(".mpls"))
        .sort()
        .map(async (f) => {
          const playlistPath = path.join(playlistDir, f);
          const stat = await fs.stat(playlistPath);
          const segments = await parseBlurayMpls(
            playlistPath,
            discRootForAnalysis,
          );
          return {
            id: path.basename(f, path.extname(f)),
            path: playlistPath,
            sizeBytes: stat.size,
            segments,
          };
        }),
    );
    const entries = await fs.readdir(streamDir);
    const m2tsFiles = entries
      .filter((f) => f.toLowerCase().endsWith(".m2ts"))
      .sort();
    const tracks = await Promise.all(
      m2tsFiles.map(async (f) => {
        const filePath = path.join(streamDir, f);
        const stat = await fs.stat(filePath);
        const { streams, durationSeconds, chapters } =
          await probeStreams(filePath);
        return {
          path: filePath,
          name: f,
          sizeBytes: stat.size,
          durationSeconds,
          streams,
          chapters,
        };
      }),
    );
    tracks.sort((a, b) => b.sizeBytes - a.sizeBytes);
    return res.json({ discType: "bluray", playlists, tracks });
  } catch (e) {
    await cleanupIso();
    const msg = e instanceof Error ? e.message : String(e);
    return res.status(500).json({ error: `分析失败：${msg}` });
  }
});

// POST /disc/verify-title — one ffprobe dvdvideo call for the exact HandBrake title selected by the user.
router.post("/disc/verify-title", async (req, res) => {
  const analysisId =
    typeof req.body?.analysisId === "string" ? req.body.analysisId : "";
  const titleId = typeof req.body?.titleId === "string" ? req.body.titleId : "";
  const force = req.body?.force === true;
  if (!analysisId || !titleId)
    return res.status(400).json({ error: "analysisId 和 titleId 不能为空" });

  const analysis = discAnalysisRegistry.find(analysisId);
  if (!analysis || analysis.mediaType !== "dvd")
    return res.status(404).json({ error: "DVD 分析结果已失效，请重新分析" });
  const title = analysis.titles.find(
    (candidate) => candidate.titleId === titleId,
  );
  if (!title) return res.status(404).json({ error: "所选 DVD 标题不存在" });
  if (title.availabilityStatus === "unavailable") {
    return res.status(422).json({
      analysisId,
      titleId,
      verified: false,
      failureReason:
        title.availabilityFailureReason ?? "该 DVD 标题无法读取实际视频数据",
      warnings: [
        "标题元数据存在，但逐标题读取失败；已阻止导出和压缩，避免生成空文件或错标题。",
      ],
      diagnosticLogPath: analysis.diagnosticLogPath,
    });
  }
  await ensureAnalysisIsoReady(analysis);
  const titleNumber = title.toolMappings.handbrakeTitleNumber;
  if (!titleNumber || titleNumber <= 0)
    return res
      .status(400)
      .json({ error: "所选标题没有有效的 HandBrake 标题编号" });

  const ffprobeExecutable = await resolveToolPath("ffprobe");
  if (!ffprobeExecutable)
    return res
      .status(400)
      .json({ error: "未找到项目实际使用的 ffprobe，无法验证所选标题" });
  await ensureDvdCssSupport(ffprobeExecutable);
  // Exact cache identity: analysisId + titleId + sourceFingerprint.
  const verificationKey = `${analysisId}:${titleId}:${analysis.sourceFingerprint}`;
  if (force) dvdTitleVerificationCache.delete(verificationKey);
  const cachedEntry = !force
    ? dvdTitleVerificationCache.get(verificationKey)
    : undefined;
  const cacheHit = Boolean(
    cachedEntry &&
    Date.now() - cachedEntry.cachedAt <= DVD_VERIFICATION_CACHE_TTL_MS,
  );
  if (cachedEntry && !cacheHit)
    dvdTitleVerificationCache.delete(verificationKey);
  let active = dvdTitleVerificationInFlight.get(verificationKey);
  if (cacheHit && cachedEntry) {
    active = Promise.resolve(cachedEntry.verification);
    await appendRuntimeToolLog(
      `标题验证缓存命中 analysis=${analysisId} title=${titleNumber} key=${verificationKey}`,
    ).catch(() => {});
  } else if (!active || force) {
    active = verifyDvdTitle({
      sourcePath: dvdVideoInputPath(analysis.sourcePath),
      titleNumber,
      handbrakeDurationSeconds: title.durationSeconds,
      handbrakeChapterCount: title.chapterCount,
      handbrakeStreams: title.streams,
      ffprobeExecutable,
    });
    dvdTitleVerificationInFlight.set(verificationKey, active);
    active
      .then((verification) => {
        dvdTitleVerificationCache.set(verificationKey, {
          verification,
          cachedAt: Date.now(),
        });
      })
      .catch(() => {});
  }
  try {
    const verification = await active;
    const now = new Date();
    analysis.diagnostics.push({
      tool: "ffprobe",
      executable: verification.diagnostic.executable,
      args: verification.diagnostic.args,
      startedAt: new Date(
        now.getTime() - verification.diagnostic.durationMs,
      ).toISOString(),
      finishedAt: now.toISOString(),
      durationMs: verification.diagnostic.durationMs,
      exitCode: verification.diagnostic.exitCode,
      stdout: verification.diagnostic.stdout,
      stderr: verification.diagnostic.stderr,
      failureReason:
        verification.failureReason ?? verification.diagnostic.failureReason,
    });
    title.verificationStatus = verification.verified ? "verified" : "failed";
    title.verificationFailureReason = verification.failureReason;
    if (verification.verified) {
      const verifiedStreams = verification.streams.map((stream, index) => ({
        ...stream,
        ...(title.titleUid && stream.codecType !== "unknown"
          ? {
              trackUid: buildDvdStreamUid({
                titleUid: title.titleUid,
                type: stream.codecType,
                ordinal: verification.streams
                  .slice(0, index)
                  .filter(
                    (candidate) => candidate.codecType === stream.codecType,
                  ).length,
                codecName: stream.codecName,
                language: stream.language,
                channels: stream.channels,
              }),
            }
          : {}),
      }));
      title.toolMappings.dvdVtsNumber = titleNumber;
      title.durationSeconds =
        verification.durationSeconds ?? title.durationSeconds;
      title.chapters = verification.chapters;
      title.chapterCount = verification.chapters.length;
      title.streams = verifiedStreams;
      title.videoTracks = verifiedStreams.filter(
        (stream) => stream.codecType === "video",
      );
      title.audioTracks = verifiedStreams.filter(
        (stream) => stream.codecType === "audio",
      );
      title.subtitleTracks = verifiedStreams.filter(
        (stream) => stream.codecType === "subtitle",
      );
    }
    title.verificationWarnings = verification.warnings;
    analysis.diagnosticLogPath = await persistDiscAnalysisDiagnostics(
      analysis.analysisId,
      analysis.diagnostics,
    ).catch(() => analysis.diagnosticLogPath);
    discAnalysisRegistry.remember(analysis);
    if (!cacheHit) {
      await appendRuntimeToolOutput({
        tool: "ffprobe",
        executable: verification.diagnostic.executable ?? ffprobeExecutable,
        args: verification.diagnostic.args,
        exitCode: verification.diagnostic.exitCode,
        durationMs: verification.diagnostic.durationMs,
        stdout: verification.diagnostic.stdout,
        stderr: verification.diagnostic.stderr,
      }).catch(() => {});
    }
    await appendRuntimeToolLog(
      `DVD 标题验证 analysis=${analysisId} title=${titleNumber} verified=${verification.verified} cache=${cacheHit ? "hit" : "miss"} durationMs=${verification.diagnostic.durationMs} ffprobe=${ffprobeExecutable} memory=${Math.round(process.memoryUsage().rss / 1024 / 1024)}MB log=${analysis.diagnosticLogPath ?? "unavailable"}`,
    ).catch(() => {});
    if (!verification.verified) {
      // CSS-protected discs cannot be verified through dvdvideo, but the VOB
      // structure is still resolvable. Mark the title verified-for-remux so a
      // Remux task can be created; the runtime falls back to VOB concat.
      // A VOB concat fallback is safe only when the physical VTS number is
      // exactly the verified logical title number. Never use the largest VTS
      // as a substitute for a different logical title.
      const vobFallback = await resolveDvdTitleForSource(
        analysis.sourcePath,
        0,
        titleNumber,
      ).catch(() => null);
      if (
        vobFallback?.vobFiles.length &&
        typeof vobFallback.titleNumber === "number" &&
        vobFallback.titleNumber > 0
      ) {
        title.toolMappings.dvdVtsNumber = vobFallback.titleNumber;
        title.toolMappings.physicalVtsNumber = vobFallback.titleNumber;
        title.verificationStatus = "verified";
        title.verificationFailureReason = null;
        title.verificationWarnings = [
          ...(title.verificationWarnings ?? []),
          "CSS 加密光盘：dvdvideo 验证失败，已按 VOB 结构解析标题；Remux 将使用 VOB 拼接（图形字幕无法保留）",
        ];
        await appendRuntimeToolLog(
          `DVD 标题验证回退：CSS 盘按 VOB 结构解析 title=${vobFallback.titleNumber} vobs=${vobFallback.vobFiles.length}`,
        ).catch(() => {});
      }
    }
    if (title.verificationStatus !== "verified")
      return res.status(422).json({
        analysisId,
        titleId,
        cached: cacheHit,
        verified: false,
        titleNumber,
        failureReason: verification.failureReason,
        warnings: verification.warnings,
        durationDifferenceSeconds: verification.durationDifferenceSeconds,
        durationDifferencePercent: verification.durationDifferencePercent,
        diagnosticLogPath: analysis.diagnosticLogPath,
      });
    return res.json({
      analysisId,
      titleId,
      cached: cacheHit,
      verified: true,
      titleNumber,
      durationSeconds: title.durationSeconds,
      chapters: title.chapters,
      streams: title.streams,
      videoTracks: title.videoTracks,
      audioTracks: title.audioTracks,
      subtitleTracks: title.subtitleTracks,
      warnings: title.verificationWarnings ?? verification.warnings,
      durationDifferenceSeconds: verification.durationDifferenceSeconds,
      durationDifferencePercent: verification.durationDifferencePercent,
      failureReason: null,
      diagnosticLogPath: analysis.diagnosticLogPath,
    });
  } finally {
    if (dvdTitleVerificationInFlight.get(verificationKey) === active)
      dvdTitleVerificationInFlight.delete(verificationKey);
  }
});

export const discRouter = router;
