import { Profiler } from "react";
import type { ProcessingMode } from "@/hooks/useWorkbenchState";
import { useI18n } from "@/i18n";
import type { ScanCopy } from "@/pages/Scan";
import { onDiscPreviewRender } from "@/pages/Scan";
import type { assessDiscRemuxCapacity } from "../disc-job-mode-model";
import {
  formatDiscBytes,
  type DiscTrackWithMakeMkv,
} from "../disc-display-model";
import { DiscTitleRow } from "../DiscTitleRow";

export type DiscTrackSelectorProps = {
  uiText: ScanCopy;
  tracks: DiscTrackWithMakeMkv[];
  selectedTrackIndices: Set<number>;
  activeTrackIdx: number;
  verifyingTracks: Set<number>;
  discType: "dvd" | "bluray";
  processingMode: ProcessingMode;
  selectableTitleCount: number;
  remuxCapacity: ReturnType<typeof assessDiscRemuxCapacity> | null;
  onSelect: (idx: number) => void;
  onToggleSelected: (idx: number, selected: boolean) => void;
  onSetAllTitles: (selected: boolean) => void;
  isSelectionDisabled: (idx: number) => boolean;
  isTrackVisible: (track: DiscTrackWithMakeMkv) => boolean;
};

export function DiscTrackSelector({
  uiText,
  tracks,
  selectedTrackIndices,
  activeTrackIdx,
  verifyingTracks,
  discType,
  processingMode,
  selectableTitleCount,
  remuxCapacity,
  onSelect,
  onToggleSelected,
  onSetAllTitles,
  isSelectionDisabled,
  isTrackVisible,
}: DiscTrackSelectorProps) {
  const { t } = useI18n();

  return (
    <div className="min-h-[12rem] min-w-0 flex-none overflow-y-auto pr-1">
      <div className="sticky top-0 z-10 mb-2 flex flex-wrap items-center justify-between gap-2 bg-background/95 py-1">
        <p className="text-xs font-medium text-muted-foreground">
          {uiText.selectTitles}
        </p>
        <div className="flex shrink-0 gap-1">
          <button
            type="button"
            className="rounded border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-secondary/50 disabled:cursor-not-allowed disabled:opacity-40"
            onClick={(event) => {
              event.stopPropagation();
              onSetAllTitles(true);
            }}
            disabled={verifyingTracks.size > 0 || selectableTitleCount === 0}
          >
            {uiText.selectAllTitles}
          </button>
          <button
            type="button"
            className="rounded border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-secondary/50 disabled:cursor-not-allowed disabled:opacity-40"
            onClick={(event) => {
              event.stopPropagation();
              onSetAllTitles(false);
            }}
            disabled={selectedTrackIndices.size === 0}
          >
            {uiText.clearAllTitles}
          </button>
        </div>
      </div>
      {remuxCapacity?.blocked && (
        <p className="mb-2 rounded border border-destructive/30 bg-destructive/5 px-2 py-1.5 text-xs text-destructive">
          {t("scan.capacitySelectionBlocked")}
        </p>
      )}
      {remuxCapacity && !remuxCapacity.blocked && (
        <p className="mb-2 rounded border border-border/60 bg-muted/30 px-2 py-1.5 text-xs text-muted-foreground">
          {t("scan.capacitySelectionSummary", {
            selected: formatDiscBytes(remuxCapacity.estimatedBytes),
            source: remuxCapacity.sourceBytes
              ? formatDiscBytes(remuxCapacity.sourceBytes)
              : "—",
          })}
          {remuxCapacity.hasOverlap && (
            <span className="ml-1 text-amber-700 dark:text-amber-400">
              {t("scan.capacityOverlapWarning", {
                titles: formatDiscBytes(remuxCapacity.summedTitleBytes),
                overlap: formatDiscBytes(remuxCapacity.overlapBytes),
              })}
            </span>
          )}
        </p>
      )}
      <div className="space-y-1.5 pr-1">
        <Profiler
          id="DiscTitleList"
          onRender={(id, phase, actualDuration) =>
            onDiscPreviewRender(id, phase, actualDuration)
          }
        >
          {tracks.map((track, idx) => {
            if (!isTrackVisible(track)) return null;
            const isSelected = selectedTrackIndices.has(idx);
            const isActive = idx === activeTrackIdx;
            return (
              <div
                key={`${track.path}-${idx}-${track.name}`}
                className="rounded-lg"
              >
                <DiscTitleRow
                  index={idx}
                  track={track}
                  isSelected={isSelected}
                  isActive={isActive}
                  isVerifying={
                    discType === "dvd" &&
                    processingMode === "remux" &&
                    verifyingTracks.has(idx)
                  }
                  discType={discType}
                  onSelect={onSelect}
                  onToggleSelected={onToggleSelected}
                  selectionDisabled={isSelectionDisabled(idx)}
                />
              </div>
            );
          })}
        </Profiler>
      </div>
    </div>
  );
}
