export type BlockedJobCode =
  | "no-video"
  | "no-subtitle-track"
  | "no-audio-track";

/**
 * 解析后端写入的“不可执行”标记：errorMessage 以 `VX_BLOCKED:<code>` 开头。
 * 返回结构化代码供界面显示本地化原因（区别于普通运行失败）。
 */
export function parseBlockedJobCode(
  errorMessage: string | null | undefined,
): BlockedJobCode | null {
  if (!errorMessage) return null;
  const match = /^VX_BLOCKED:([a-z-]+)/.exec(errorMessage);
  if (!match) return null;
  const code = match[1];
  return code === "no-video" ||
    code === "no-subtitle-track" ||
    code === "no-audio-track"
    ? code
    : null;
}

export function blockedReasonKey(code: BlockedJobCode): string {
  return `jobDetail.blocked.${code}`;
}
