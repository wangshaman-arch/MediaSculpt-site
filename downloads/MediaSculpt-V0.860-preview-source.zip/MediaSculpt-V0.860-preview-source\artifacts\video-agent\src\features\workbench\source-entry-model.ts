export function defaultSourceBrowserExpanded(processingMode?: string): boolean {
  return processingMode === "workflow";
}

export function shouldShowSourceBrowser(
  expanded: boolean,
  directory: string,
): boolean {
  return expanded || directory.trim().length > 0;
}
