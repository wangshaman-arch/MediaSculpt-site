export function buildRemuxMapArgs(selectedStreams: string | null): string[] {
  if (!selectedStreams) return ["-map", "0"];
  let indices: unknown;
  try {
    indices = JSON.parse(selectedStreams);
  } catch {
    return ["-map", "0"];
  }
  if (!Array.isArray(indices)) return ["-map", "0"];
  if (indices.length === 0) throw new Error("至少选择一个视频、音频或字幕流");
  return indices.flatMap((index) => ["-map", `0:${index}`]);
}

export function buildRemuxCopyArgs(options: {
  usesConcatInput: boolean;
  selectedChapters?: string | null;
}): string[] {
  const args = [
    "-dn",
    "-ignore_unknown",
    "-c",
    "copy",
    "-avoid_negative_ts",
    "make_zero",
  ];
  if (options.selectedChapters === "[]") args.push("-map_chapters", "-1");
  return args;
}
