import { Badge } from "@/components/ui/badge";
import { useI18n } from "@/i18n";

const STATUS_CONFIG: Record<string, { labelKey: string; className: string }> = {
  pending: {
    labelKey: "jobs.pending",
    className: "bg-muted text-muted-foreground border-transparent",
  },
  scanning: {
    labelKey: "jobs.scanning",
    className: "bg-blue-500/10 text-blue-500 border-blue-500/20 animate-pulse",
  },
  transcribing: {
    labelKey: "jobs.transcribing",
    className:
      "bg-purple-500/10 text-purple-500 border-purple-500/20 animate-pulse",
  },
  compressing: {
    labelKey: "jobs.compressing",
    className:
      "bg-orange-500/10 text-orange-500 border-orange-500/20 animate-pulse",
  },
  paused: {
    labelKey: "jobs.paused",
    className: "bg-blue-500/10 text-blue-500 border-blue-500/20",
  },
  done: {
    labelKey: "jobs.done",
    className: "bg-green-500/10 text-green-500 border-green-500/20",
  },
  error: {
    labelKey: "jobs.error",
    className: "bg-destructive/10 text-destructive border-destructive/20",
  },
};

export function JobStatusBadge({
  status,
  processingMode,
  subtitleMode,
  plain = false,
}: {
  status: string;
  processingMode?: string | null;
  subtitleMode?: string | null;
  plain?: boolean;
}) {
  const { t } = useI18n();
  const cfg =
    status === "compressing" && processingMode === "remux"
      ? { ...STATUS_CONFIG.compressing, labelKey: "jobs.remuxing" }
      : status === "transcribing" && subtitleMode === "ocr"
        ? { ...STATUS_CONFIG.transcribing, labelKey: "jobs.ocrRunning" }
        : (STATUS_CONFIG[status] ?? { labelKey: status, className: "" });
  if (plain) {
    const tone =
      status === "error"
        ? "text-destructive"
        : status === "done"
          ? "text-emerald-500"
          : status === "pending"
            ? "text-muted-foreground"
            : status === "paused"
              ? "text-blue-500"
              : "text-primary";
    return (
      <span
        className={`font-mono text-[10px] font-medium tracking-wider ${tone}`}
      >
        {t(cfg.labelKey)}
      </span>
    );
  }
  return (
    <Badge
      variant="outline"
      className={`font-mono text-[10px] tracking-wider ${cfg.className}`}
    >
      {t(cfg.labelKey)}
    </Badge>
  );
}
