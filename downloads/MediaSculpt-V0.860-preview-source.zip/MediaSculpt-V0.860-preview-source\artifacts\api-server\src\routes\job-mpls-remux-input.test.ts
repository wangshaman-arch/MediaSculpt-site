import { describe, expect, it } from "vitest";
import {
  filterAvailableMplsSegments,
  sumMplsSegmentSizes,
} from "./job-mpls-remux-input";

const segments = [
  { clipId: "00001", streamPath: "A.m2ts", inTime45k: 0, outTime45k: 90_000 },
  { clipId: "00002", streamPath: "B.m2ts", inTime45k: 0, outTime45k: 90_000 },
  {
    clipId: "00001",
    streamPath: "A.m2ts",
    inTime45k: 90_000,
    outTime45k: 180_000,
  },
];

describe("MPLS remux input", () => {
  it("keeps available playlist segments in playback order", () => {
    expect(filterAvailableMplsSegments(segments, new Set(["A.m2ts"]))).toEqual([
      segments[0],
      segments[2],
    ]);
  });

  it("counts each physical m2ts file once for the size expectation", () => {
    expect(
      sumMplsSegmentSizes(
        segments,
        new Map([
          ["A.m2ts", 100],
          ["B.m2ts", 200],
        ]),
      ),
    ).toBe(300);
  });

  it("returns zero when no referenced stream can be measured", () => {
    expect(sumMplsSegmentSizes(segments, new Map())).toBe(0);
  });
});
