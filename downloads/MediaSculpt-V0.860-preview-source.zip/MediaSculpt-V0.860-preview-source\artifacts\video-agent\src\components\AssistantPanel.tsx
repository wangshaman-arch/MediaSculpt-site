import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Button } from "@/components/ui/button";
import { Loader2, Search } from "lucide-react";
import { useI18n } from "@/i18n";
import { cn } from "@/lib/utils";
import {
  cleanAnalysisBody,
  hasVerifiedMetadataValue,
} from "@/lib/assistant-analysis";
import {
  getAnalysisAction,
  hasExistingAnalysis,
} from "@/lib/assistant-analysis-state";
import {
  buildAssistantDisplayMetadata,
  buildMetadataRows,
  isPosterCandidateUsable,
  parseAssistantMetadataFields,
  type AssistantMetadataSnapshot,
} from "@/lib/assistant-metadata";
import type { AssistantCorrection } from "@/hooks/useAssistantAnalysis";
import { AssistantChip } from "./assistant/AssistantChip";
import { AssistantIdentityEditor } from "./assistant/AssistantIdentityEditor";
import { AssistantModesColumn } from "./assistant/AssistantModesColumn";
import { AssistantToolbarActions } from "./assistant/AssistantToolbarActions";
import { AssistantAnalysisCard } from "./assistant/AssistantAnalysisCard";
import { AssistantPosterDialogs } from "./assistant/AssistantPosterDialogs";
import {
  DEFAULT_PREFERENCES,
  DEFAULT_STEP_ORDER,
  folderChineseTitleForSource,
  formatDuration,
  sourceDisplayName,
  splitSourceName,
  yearFromSource,
} from "./assistant/assistant-panel-model";

export type AiGenerateOptions = {
  generateReadme: boolean;
  generatePoster: boolean;
  generateReview: boolean;
};

export type ProcessingStep =
  | "compress"
  | "remux"
  | "subtitle"
  | "chapterPreview";
export type SubtitleChoice =
  | "auto"
  | "extract"
  | "whisper"
  | "transcribe_translate"
  | "skip"
  | "ocr"
  | "bilingual";

export type AssistantPreferences = {
  /** 外语名（英文片名，IMDB 等数据库对齐，单词用 . 连接） */
  titleEn: string;
  /** 中文名（豆瓣等简中平台对齐） */
  titleZh: string;
  year: number | null;
  /** IMDb 号（tt 开头）：用于提高影片识别唯一性（区分同名异年版本），与传统匹配逻辑联动 */
  imdbId: string;
  /** 有序处理流水线：默认 ① Remux → ② 字幕 → ③ 压缩；可拖动调整，每次打开恢复默认顺序 */
  processing: ProcessingStep[];
  subtitle: SubtitleChoice | null;
};

export type AssistantMetadata = {
  movieTitle?: string | null;
  movieTitleEn?: string | null;
  movieYear?: number | null;
  movieImdbId?: string | null;
  movieRating?: number | null;
  movieDirector?: string | null;
  movieGenres?: string | null;
  metadataSnapshot?: AssistantMetadataSnapshot | null;
};

export type PresetOption = { id: string; label: string };

export function AssistantPanel({
  contextType,
  context,
  jobId,
  generateOptions,
  preferences,
  allowRemux = true,
  aiAvailable = false,
  posterUrl,
  sourceName,
  presets = [],
  selectedPresetId = null,
  allowChapterPreview = true,
  expandMode = "inline",
  identityPortalTarget = null,
  analysisButtonPortalTarget = null,
  analysisPlacement = "inline",
  analysisPortalTarget = null,
  promptPlacement = "toolbar",
  prompt = "",
  promptOpen = false,
  promptFocusRequest,
  promptAttention = false,
  onPromptToggle,
  onPromptFocus,
  onPromptChange,
  onAnalyze,
  analyzing = false,
  analysisResult,
  analysisError,
  analysisPosterUrl,
  metadata,
  analysisOpen = false,
  onAnalysisOpenChange,
  correction,
  onPreferencesChange,
  onGenerateOptionsChange,
  onConfirm,
  onPresetSelect,
  onOpenQualityPanel,
  batchMode = false,
  batchCount = 0,
  onBatchConfirm,
  onFeatureClick,
  confirmed = false,
  processingLocked = false,
}: {
  contextType: "workflow" | "job";
  context: Record<string, unknown>;
  jobId?: number;
  generateOptions?: AiGenerateOptions;
  preferences?: Partial<AssistantPreferences>;
  allowRemux?: boolean;
  /** 是否已配置 AI API Key：无 Key 时调用 LLM 的部分置灰不可选 */
  aiAvailable?: boolean;
  posterUrl?: string | null;
  /** 源文件/文件夹名：变化时外语名/中文名/年代自动跟随 */
  sourceName?: string | null;
  presets?: PresetOption[];
  selectedPresetId?: string | null;
  expandMode?: "inline" | "external";
  /** 仅将基本信息分析卡片挂到视频区域的覆盖层。 */
  analysisPlacement?: "inline" | "sidebar" | "video-overlay";
  analysisPortalTarget?: HTMLElement | null;
  promptPlacement?: "toolbar" | "external";
  prompt?: string;
  promptOpen?: boolean;
  promptFocusRequest?: number;
  promptAttention?: boolean;
  onPromptToggle?: (open: boolean) => void;
  onPromptFocus?: () => void;
  onPromptChange?: (value: string) => void;
  onAnalyze?: (fields: {
    titleEn: string;
    titleZh: string;
    year: number | null;
    imdbId: string;
    processing: ProcessingStep[];
    prompt: string;
  }) => void;
  analyzing?: boolean;
  analysisResult?: string | null;
  analysisError?: string | null;
  analysisPosterUrl?: string | null;
  /** 与概要正文对应的已保存、可核验元数据快照。 */
  metadata?: AssistantMetadata;
  analysisOpen?: boolean;
  onAnalysisOpenChange?: (open: boolean) => void;
  correction?: AssistantCorrection | null;
  onPreferencesChange?: (preferences: AssistantPreferences) => void;
  onGenerateOptionsChange?: (options: AiGenerateOptions) => void;
  onConfirm?: () => void;
  onPresetSelect?: (presetId: string) => void;
  onOpenQualityPanel?: () => void;
  /** 批量模式：非批量任务时“批量确认”按钮置灰不可点击。 */
  batchMode?: boolean;
  batchCount?: number;
  /** 功能确认后高亮锁定（批量页点击功能确认后为 true，未确认保持透明无底色） */
  confirmed?: boolean;
  onBatchConfirm?: () => void;
  /** 处理方式已在光盘分析阶段确认，智能助手只展示结果，不允许再次改选。 */
  processingLocked?: boolean;
  /** 批量/详情页联动：点击处理方式/字幕/画质时通知父级展开对应下级选项。 */
  onFeatureClick?: (
    feature: "remux" | "subtitle" | "preset" | "chapterPreview" | null,
  ) => void;
  /** 章节预览为独立预览模式：默认可用；工作流页等不支持该动作的页面可禁用。 */
  allowChapterPreview?: boolean;
  /** 将详情页的助手控制区压入右侧栏，但不改变任何功能与状态逻辑。 */
  /** 详情页将影片身份编辑器与预览标题合并显示。 */
  identityPortalTarget?: HTMLElement | null;
  /** 将“概要预览”按钮 portal 到外部槽位（如页面头部），放在“提示词”左侧。 */
  analysisButtonPortalTarget?: HTMLElement | null;
}) {
  const { t, lang } = useI18n();
  const contextSourcePath =
    (typeof context.sourcePath === "string" && context.sourcePath.trim()) ||
    (typeof context.filePath === "string" && context.filePath.trim()) ||
    "";
  const contextSourceName = contextSourcePath
    ? sourceDisplayName(contextSourcePath)
    : (sourceName ?? "").trim();
  const contextSourceYear = contextSourcePath
    ? yearFromSource(contextSourcePath)
    : null;
  const folderZh = contextSourcePath
    ? folderChineseTitleForSource(contextSourcePath)
    : "";
  const fileSplit = splitSourceName(contextSourceName);
  const initialSplit = folderZh
    ? { ...fileSplit, titleZh: folderZh }
    : fileSplit;

  const [prefs, setPrefs] = useState<AssistantPreferences>(() => {
    const merged = { ...DEFAULT_PREFERENCES, ...(preferences ?? {}) };
    return {
      ...merged,
      titleEn: initialSplit.titleEn || merged.titleEn,
      titleZh: initialSplit.titleZh || merged.titleZh,
      year:
        contextSourceYear ??
        initialSplit.year ??
        (merged.year != null && merged.year >= 1920 ? merged.year : null),
    };
  });
  const [gen, setGen] = useState<AiGenerateOptions>(
    generateOptions ?? {
      generateReadme: false,
      generatePoster: false,
      generateReview: false,
    },
  );
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  // 智能生成功能尚未完善、未接入云端 LLM 时不可用，因此默认收起整行。
  const [generateOpen, setGenerateOpen] = useState(false);
  const [inlinePanel, setInlinePanel] = useState<"quality" | null>(null);
  const [posterOpen, setPosterOpen] = useState(false);
  const [readingOpen, setReadingOpen] = useState(false);
  /** An id the assistant suggested but no provider confirmed. */
  const [unverifiedImdbId, setUnverifiedImdbId] = useState<string | null>(null);
  const [dirPosterUrl, setDirPosterUrl] = useState<string | null>(null);
  const promptInputRef = useRef<HTMLInputElement>(null);
  const promptTextareaRef = useRef<HTMLTextAreaElement>(null);
  const promptFocusSeenRef = useRef(promptFocusRequest ?? 0);
  const analyzingSeenRef = useRef(false);
  const [promptFocusPending, setPromptFocusPending] = useState(false);
  const [retryRequested, setRetryRequested] = useState(false);
  const currentYear = new Date().getFullYear();
  const workflowIdentity = context.identity as { title?: string } | undefined;
  // A just-completed analysis is newer than any poster left in the source
  // directory. Showing the directory file first can surface a stale poster
  // from a previous, incorrectly matched title.
  // Prefer the locally saved poster after provenance validation; the remote
  // URL is only a transient fallback while the local file is being refreshed.
  // A merely suggested id fills the input for the user to accept, but it must not
  // become verified identity: only a provider match or a hand-typed id may pin a
  // poster.
  const inputImdbId = prefs.imdbId.trim();
  const verifiedImdbId =
    metadata?.metadataSnapshot?.imdb?.id?.trim() ||
    metadata?.movieImdbId?.trim() ||
    (inputImdbId && inputImdbId !== unverifiedImdbId ? inputImdbId : "");
  const posterTitleEn =
    metadata?.metadataSnapshot?.titleEn?.trim() ||
    metadata?.movieTitleEn?.trim() ||
    prefs.titleEn.trim();
  const posterYear =
    metadata?.metadataSnapshot?.year ?? metadata?.movieYear ?? prefs.year;
  // Local posters are gated by the saved sidecar provenance and remote ones by
  // the identity they carry. The server-returned poster stays a candidate even
  // once the id is known: dropping it there is what lost every poster.
  const effectivePoster =
    [dirPosterUrl, analysisPosterUrl, posterUrl].find((candidate) =>
      isPosterCandidateUsable(
        candidate,
        verifiedImdbId,
        posterTitleEn,
        posterYear,
      ),
    ) ?? null;
  const contextSourceType =
    typeof context.sourceType === "string" ? context.sourceType : "";
  const contextFirstItem = Array.isArray(context.items)
    ? (context.items[0] as
        | {
            durationSeconds?: number | null;
            audioTracks?: number;
            subtitleTracks?: number;
          }
        | undefined)
    : undefined;
  const contextDuration = Number(contextFirstItem?.durationSeconds ?? 0);
  const displayTitle =
    [prefs.titleEn.trim(), prefs.year ?? "", prefs.titleZh.trim()]
      .filter(Boolean)
      .join(".") ||
    contextSourceName ||
    t("assistant.posterPreview");
  const analysisBody = cleanAnalysisBody(analysisResult);
  const persistedOverview = metadata?.metadataSnapshot?.overview?.trim() ?? "";
  const hasExistingResult = hasExistingAnalysis({
    analysisResult,
    persistedOverview,
  });
  const analysisAction = getAnalysisAction({
    hasResult: hasExistingResult,
    analyzing: Boolean(analyzing),
    retryRequested,
  });
  const metadataTitle = [
    metadata?.movieTitleEn?.trim(),
    metadata?.movieYear ?? "",
    metadata?.movieTitle?.trim(),
  ]
    .filter(Boolean)
    .join(".");
  const infoTitle = (metadataTitle || displayTitle)
    .replace(/\.{2,}/g, ".")
    .replace(/\./g, " ")
    .replace(/\s+/g, " ")
    .trim();
  const unverifiedLabel = t("assistant.metadataUnverified");
  const parsedFields = parseAssistantMetadataFields(analysisResult);
  const displayMetadata = buildAssistantDisplayMetadata(
    metadata?.metadataSnapshot,
    {
      ...parsedFields,
      // Identity scraped out of the assistant prose is the least reliable
      // source; it only fills what the correction, the verified snapshot,
      // and the persisted record all leave empty.
      title: correction?.titleZh || undefined,
      titleEn: correction?.titleEn || undefined,
      year: correction?.year ?? undefined,
      imdbId: correction?.imdbId || undefined,
    },
    {
      title: metadata?.movieTitle || parsedFields.title,
      titleEn: metadata?.movieTitleEn || parsedFields.titleEn,
      year: metadata?.movieYear ?? parsedFields.year,
      imdbId: metadata?.movieImdbId || parsedFields.imdbId,
      imdbRating: metadata?.movieRating,
      director: metadata?.movieDirector,
      genres: metadata?.movieGenres,
    },
  );
  const structuredRows = buildMetadataRows(displayMetadata);
  const metadataRows: Array<readonly [string, string | number]> =
    structuredRows.length > 0
      ? structuredRows.map((row) => [row.label, row.value] as const)
      : (
          [
            [t("assistant.titleField"), infoTitle],
            [t("assistant.yearField"), metadata?.movieYear ?? prefs.year ?? ""],
            [t("assistant.imdbField"), metadata?.movieImdbId || ""],
            [
              t("assistant.ratingField"),
              metadata?.movieRating != null ? String(metadata.movieRating) : "",
            ],
            [t("assistant.directorField"), metadata?.movieDirector || ""],
            [t("assistant.genreField"), metadata?.movieGenres || ""],
          ] as Array<readonly [string, string | number]>
        ).filter(([, value]) =>
          hasVerifiedMetadataValue(value, unverifiedLabel),
        );
  // Technical facts belong to the same table as the metadata; as a loose line
  // they collided with the 绫诲瀷 (genre) row and read as a stray fragment.
  const techRows: Array<[string, string]> = [];
  if (contextSourceType)
    techRows.push([
      t("assistant.sourceTypeLabel"),
      contextSourceType.toUpperCase(),
    ]);
  if (contextDuration > 0)
    techRows.push([
      t("assistant.durationLabel"),
      formatDuration(contextDuration),
    ]);
  if (typeof contextFirstItem?.audioTracks === "number")
    techRows.push([
      t("assistant.audioTracksLabel"),
      String(contextFirstItem.audioTracks),
    ]);
  if (typeof contextFirstItem?.subtitleTracks === "number")
    techRows.push([
      t("assistant.subtitleTracksLabel"),
      String(contextFirstItem.subtitleTracks),
    ]);
  const factsRows = [...metadataRows, ...techRows];

  const updatePrefs = (patch: Partial<AssistantPreferences>) => {
    const next = { ...prefs, ...patch };
    setPrefs(next);
    onPreferencesChange?.(next);
  };

  // 源目录已有海报（poster.jpg/folder.jpg）→ 自动显示；分析保存后稍后刷新为本地文件
  useEffect(() => {
    if (!contextSourcePath) {
      setDirPosterUrl(null);
      return;
    }
    let cancelled = false;
    const check = () => {
      const posterQuery = new URLSearchParams({
        path: contextSourcePath,
        t: String(Date.now()),
      });
      const identityImdb =
        metadata?.metadataSnapshot?.imdb?.id?.trim() ||
        metadata?.movieImdbId?.trim() ||
        prefs.imdbId.trim();
      if (identityImdb) setDirPosterUrl(null);
      if (identityImdb) posterQuery.set("imdbId", identityImdb);
      if (metadata?.movieTitle?.trim() || prefs.titleZh.trim())
        posterQuery.set(
          "title",
          metadata?.movieTitle?.trim() || prefs.titleZh.trim(),
        );
      if (posterTitleEn) posterQuery.set("titleEn", posterTitleEn);
      if (posterYear) posterQuery.set("year", String(posterYear));
      fetch(`/api/media/poster?${posterQuery.toString()}`)
        .then((response) => {
          if (!cancelled) setDirPosterUrl(response.ok ? response.url : null);
        })
        .catch(() => {
          if (!cancelled) setDirPosterUrl(null);
        });
    };
    check();
    if (analysisPosterUrl) {
      const timer = window.setTimeout(check, 1600);
      return () => {
        cancelled = true;
        window.clearTimeout(timer);
      };
    }
    return () => {
      cancelled = true;
    };
  }, [
    contextSourcePath,
    analysisPosterUrl,
    metadata?.metadataSnapshot,
    metadata?.movieImdbId,
    metadata?.movieTitle,
    metadata?.movieTitleEn,
    metadata?.movieYear,
    posterTitleEn,
    posterYear,
    prefs.imdbId,
    prefs.titleEn,
    prefs.titleZh,
    prefs.year,
  ]);

  // 源路径一变化（或挂载时），外语名/中文名/年代立即强制跟随源文件夹/文件名
  useEffect(() => {
    if (!contextSourceName) return;
    const split = folderZh
      ? { ...splitSourceName(contextSourceName), titleZh: folderZh }
      : splitSourceName(contextSourceName);
    setPrefs((current) => ({
      ...current,
      titleEn: split.titleEn || current.titleEn,
      titleZh: split.titleZh || current.titleZh,
      year: contextSourceYear ?? split.year ?? current.year,
    }));
    onPreferencesChange?.({
      ...prefs,
      titleEn: split.titleEn || prefs.titleEn,
      titleZh: split.titleZh || prefs.titleZh,
      year: contextSourceYear ?? split.year ?? prefs.year,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [contextSourcePath]);

  // 分析校对结果回写：外语名 / 中文名 / 年代 / IMDb 号（概要预览识别到资料库条目时自动反向填充）
  useEffect(() => {
    if (!correction) return;
    // Remember that the value came from the model rather than a provider, so the
    // field can mark it unverified and the poster gate can ignore it.
    setUnverifiedImdbId(
      correction.imdbIdSource === "assistant"
        ? correction.imdbId?.trim() || null
        : null,
    );
    setPrefs((current) => {
      const next = {
        ...current,
        titleEn: correction.titleEn ?? current.titleEn,
        titleZh: correction.titleZh ?? current.titleZh,
        year: correction.year ?? current.year,
        imdbId: correction.imdbId?.trim()
          ? correction.imdbId.trim()
          : current.imdbId,
      };
      onPreferencesChange?.(next);
      return next;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [correction]);

  const preferencesKey = JSON.stringify(preferences ?? null);
  useEffect(() => {
    if (preferences)
      setPrefs((current) => ({
        ...current,
        ...preferences,
        // 外语名/中文名以源同步为准；年份在有源年份时也不被覆盖
        titleEn: current.titleEn || (preferences.titleEn ?? ""),
        titleZh: current.titleZh || (preferences.titleZh ?? ""),
        year:
          contextSourceYear ??
          (preferences.year && preferences.year >= 1920
            ? preferences.year
            : current.year),
      }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [preferencesKey]);

  const toggleGen = (key: keyof AiGenerateOptions) => {
    if (key === "generateReview" && !aiAvailable) return;
    const next = { ...gen, [key]: !gen[key] };
    setGen(next);
    onGenerateOptionsChange?.(next);
    if (jobId) {
      void fetch(`/api/jobs/${jobId}/ai-options`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(next),
      }).catch(() => {});
    }
  };

  // A review is cloud-LLM-only. If its key disappears while the panel remains
  // open, clear the stale selection as well as disabling the control so the
  // next task cannot silently request an operation that cannot run.
  useEffect(() => {
    if (aiAvailable || !gen.generateReview) return;
    const next = { ...gen, generateReview: false };
    setGen(next);
    onGenerateOptionsChange?.(next);
    if (jobId) {
      void fetch(`/api/jobs/${jobId}/ai-options`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(next),
      }).catch(() => {});
    }
  }, [aiAvailable, gen.generateReview, jobId, onGenerateOptionsChange]);

  const toggleProcessing = (step: ProcessingStep) => {
    if (processingLocked) return;
    const wasSelected = prefs.processing.includes(step);
    const feature: "remux" | "subtitle" | "preset" | "chapterPreview" | null =
      wasSelected
        ? null
        : step === "compress"
          ? "preset"
          : step === "chapterPreview"
            ? "chapterPreview"
            : step === "subtitle"
              ? "subtitle"
              : "remux";
    onFeatureClick?.(feature);
    // 四项彼此独立，均可同时选择：章节预览会作为独立预览任务与其余步骤并存，
    // 由确认逻辑（任务详情拆分为独立预览任务 / 批量页逐个建任务）保证不互相覆盖。
    const others = prefs.processing.filter((item) => item !== step);
    let nextSteps: ProcessingStep[];
    if (wasSelected) {
      nextSteps = others;
    } else {
      nextSteps = [...others, step];
    }
    // 去重 + 按固定顺序展示（重复点击不会把同一项加入两次）。
    nextSteps = Array.from(new Set(nextSteps)).sort(
      (a, b) => DEFAULT_STEP_ORDER.indexOf(a) - DEFAULT_STEP_ORDER.indexOf(b),
    );
    updatePrefs({
      processing: nextSteps,
    });
  };

  const moveProcessing = (from: number, to: number) => {
    if (processingLocked || from === to || from < 0 || to < 0) return;
    const next = [...prefs.processing];
    const [moved] = next.splice(from, 1);
    next.splice(to, 0, moved);
    updatePrefs({ processing: next });
    setDragIndex(null);
  };

  const openPanel = () => {
    onFeatureClick?.("preset");
    if (expandMode === "external") {
      onOpenQualityPanel?.();
      return;
    }
    setInlinePanel((current) => (current === "quality" ? null : "quality"));
  };

  const stepLabel = (step: ProcessingStep) =>
    t(
      step === "compress"
        ? "assistant.optionCompress"
        : step === "chapterPreview"
          ? "assistant.optionChapterPreview"
          : step === "remux"
            ? "assistant.optionRemux"
            : "assistant.optionSubtitleOnly",
    );

  const triggerAnalyze = () => {
    onAnalyze?.({
      titleEn: prefs.titleEn,
      titleZh: prefs.titleZh,
      year: prefs.year,
      imdbId: prefs.imdbId,
      processing: prefs.processing,
      prompt,
    });
  };

  useEffect(() => {
    if (
      promptFocusRequest == null ||
      promptFocusRequest === promptFocusSeenRef.current
    )
      return;
    promptFocusSeenRef.current = promptFocusRequest;
    setPromptFocusPending(true);
  }, [promptFocusRequest]);

  useEffect(() => {
    if (!promptOpen || !promptFocusPending) return;
    const frame = window.requestAnimationFrame(() => {
      promptInputRef.current?.focus();
      promptTextareaRef.current?.focus();
      setPromptFocusPending(false);
    });
    return () => window.cancelAnimationFrame(frame);
  }, [promptFocusPending, promptOpen]);

  useEffect(() => {
    const justFinished = analyzingSeenRef.current && !analyzing;
    if (justFinished && !analysisError) setRetryRequested(false);
    analyzingSeenRef.current = Boolean(analyzing);
  }, [analysisError, analyzing]);

  const handleAnalysisClick = () => {
    if (analysisAction === "show-existing") {
      onAnalysisOpenChange?.(true);
      return;
    }
    if (analysisAction === "analyze") triggerAnalyze();
  };

  const handleRetryAnalysis = () => {
    setRetryRequested(true);
    onAnalysisOpenChange?.(true);
    onPromptToggle?.(true);
    onPromptFocus?.();
  };

  const identityEditor = (
    <AssistantIdentityEditor
      t={t}
      prefs={prefs}
      updatePrefs={updatePrefs}
      onImdbInput={(value) => {
        setUnverifiedImdbId(null);
        updatePrefs({ imdbId: value });
      }}
      unverifiedImdbId={unverifiedImdbId}
      inputImdbId={inputImdbId}
      contextType={contextType}
      workflowIdentity={workflowIdentity}
      contextSourceName={contextSourceName}
      currentYear={currentYear}
      effectivePoster={effectivePoster}
      onPosterOpen={() => setPosterOpen(true)}
    />
  );

  const analysisButton = (
    <Button
      type="button"
      size="sm"
      variant="outline"
      onClick={handleAnalysisClick}
      disabled={analyzing || (analysisAction === "analyze" && !aiAvailable)}
      title={
        aiAvailable || analysisAction === "show-existing"
          ? undefined
          : t("assistant.aiNeedsKey")
      }
      className={cn(
        "h-8 w-full min-w-0 justify-center gap-1 border-amber-400/50 px-1.5 text-xs text-foreground hover:border-amber-400/70 hover:bg-amber-400/10",
        !aiAvailable &&
          analysisAction === "analyze" &&
          "disabled:border-border/40 disabled:text-muted-foreground/40 disabled:opacity-100",
      )}
      data-testid="assistant-analyze"
    >
      {analyzing ? (
        <Loader2 className="h-3.5 w-3.5 animate-spin" />
      ) : (
        <Search className="h-3.5 w-3.5" />
      )}
      <span className="ml-1 min-w-0 truncate">
        {retryRequested
          ? t("assistant.retryAnalysis")
          : hasExistingResult
            ? t("assistant.showLastAnalysis")
            : t("assistant.analyze")}
      </span>
    </Button>
  );

  const analysisCard = (
    <AssistantAnalysisCard
      t={t}
      analysisOpen={analysisOpen}
      analysisPlacement={analysisPlacement}
      hasExistingResult={hasExistingResult}
      aiAvailable={aiAvailable}
      analyzing={Boolean(analyzing)}
      analysisError={analysisError}
      analysisBody={analysisBody}
      persistedOverview={persistedOverview}
      factsRows={factsRows}
      onRetryAnalysis={handleRetryAnalysis}
      onReadingOpen={() => setReadingOpen(true)}
      onClose={() => onAnalysisOpenChange?.(false)}
    />
  );

  return (
    <>
      {identityPortalTarget &&
        createPortal(identityEditor, identityPortalTarget)}
      {analysisButtonPortalTarget &&
        createPortal(analysisButton, analysisButtonPortalTarget)}
      <div
        className={cn(
          "min-w-0 max-w-full rounded-lg border border-blue-500/25 bg-blue-500/5 p-2.5",
          "border-0 bg-transparent p-0",
        )}
        data-testid="assistant-panel"
      >
        <div
          className={cn(
            "flex min-w-0 max-w-full flex-wrap items-stretch gap-x-3 gap-y-2",
            "flex-col items-stretch gap-y-2",
          )}
          data-testid="assistant-toolbar"
        >
          {/* ① 左侧：海报 + 外语名/年代/中文名 + 来源；flex-1 撑满剩余宽度，右侧②③贴合内容宽度 */}
          {!identityPortalTarget && identityEditor}

          {/* ② 右侧（上下关系）：智能生成（琥珀）在上，任务处理在下，中间横线区分；ml-auto 使其贴合右侧与③相邻 */}
          <AssistantModesColumn
            t={t}
            aiAvailable={aiAvailable}
            gen={gen}
            generateOpen={generateOpen}
            setGenerateOpen={setGenerateOpen}
            toggleGen={toggleGen}
            prefs={prefs}
            dragIndex={dragIndex}
            setDragIndex={setDragIndex}
            allowRemux={allowRemux}
            allowChapterPreview={allowChapterPreview}
            processingLocked={processingLocked}
            toggleProcessing={toggleProcessing}
            moveProcessing={moveProcessing}
            stepLabel={stepLabel}
          />

          {/* ③ 最右侧：提示词 + 分析 + 确认 + 批量确认，两行两列布置，避免溢出；紧随② 贴合右侧 */}
          <AssistantToolbarActions
            t={t}
            promptPlacement={promptPlacement}
            promptOpen={promptOpen}
            aiAvailable={aiAvailable}
            prompt={prompt}
            promptAttention={promptAttention}
            onPromptChange={onPromptChange}
            onPromptToggle={onPromptToggle}
            analysisButtonPortalTarget={analysisButtonPortalTarget}
            analysisButton={analysisButton}
            confirmed={confirmed}
            onConfirm={onConfirm}
            batchMode={batchMode}
            batchCount={batchCount}
            onBatchConfirm={onBatchConfirm}
            promptInputRef={promptInputRef}
            promptTextareaRef={promptTextareaRef}
          />
        </div>

        {/* 工作流页内联面板：画质 */}
        {expandMode === "inline" && inlinePanel === "quality" && (
          <div
            className="mt-2 flex flex-wrap items-center gap-1 rounded-lg border border-primary/20 bg-primary/5 px-2.5 py-2"
            data-testid="assistant-inline-quality"
          >
            <span className="w-12 shrink-0 text-[10px] text-muted-foreground">
              {t("assistant.qualityField")}
            </span>
            {presets.map((preset) => (
              <AssistantChip
                key={preset.id}
                active={selectedPresetId === preset.id}
                label={preset.label}
                onClick={() => onPresetSelect?.(preset.id)}
              />
            ))}
          </div>
        )}

        {analysisPlacement === "video-overlay"
          ? analysisPortalTarget && analysisCard
            ? createPortal(analysisCard, analysisPortalTarget)
            : null
          : analysisCard}

        <AssistantPosterDialogs
          t={t}
          posterOpen={posterOpen}
          onPosterOpenChange={setPosterOpen}
          effectivePoster={effectivePoster}
          readingOpen={readingOpen}
          onReadingOpenChange={setReadingOpen}
          factsRows={factsRows}
          analysisBody={analysisBody}
          persistedOverview={persistedOverview}
        />
      </div>
    </>
  );
}
