import { describe, expect, it } from "vitest";
import {
  canUsePhysicalDvdVobFallback,
  expectedRemuxSizeBytes,
  mayAdoptMainTrackProbeDuration,
} from "./disc-expectations";

describe("DVD logical/physical title guard", () => {
  it("allows VOB fallback only for an explicitly matching VTS number", () => {
    expect(
      canUsePhysicalDvdVobFallback({
        requestedLogicalTitleNumber: 2,
        physicalVtsNumber: 2,
      }),
    ).toBe(true);
    expect(
      canUsePhysicalDvdVobFallback({
        requestedLogicalTitleNumber: 4,
        physicalVtsNumber: 2,
      }),
    ).toBe(false);
    expect(
      canUsePhysicalDvdVobFallback({
        requestedLogicalTitleNumber: 4,
        physicalVtsNumber: null,
      }),
    ).toBe(false);
  });

  it("allows a confirmed logical-to-physical mapping to use its VOB group", () => {
    expect(
      canUsePhysicalDvdVobFallback({
        requestedLogicalTitleNumber: 18,
        physicalVtsNumber: 13,
        mappingConfirmed: true,
      }),
    ).toBe(true);
  });
});
describe("disc remux size expectations", () => {
  it("never measures a snapshot-selected title against the largest VTS", () => {
    // MC.14.22 regression: the job selected dvdvideo title 2 (20.9 s / ~5.3 MB)
    // while the largest VTS (the 2009 MB main feature) was used as the baseline,
    // so a correct remux was rejected. With a snapshot and no per-title size the
    // size check must be skipped instead.
    expect(
      expectedRemuxSizeBytes({
        hasTaskSnapshot: true,
        selectedTitleSizeBytes: null,
        selectedAnalysisEstimatedSize: null,
        resolvedMainTitleSizeBytes: 2_106_898_432,
      }),
    ).toBeNull();
  });

  it("prefers the selected title's own size when the snapshot provides one", () => {
    expect(
      expectedRemuxSizeBytes({
        hasTaskSnapshot: true,
        selectedTitleSizeBytes: 5_500_000,
        selectedAnalysisEstimatedSize: 6_000_000,
        resolvedMainTitleSizeBytes: 2_106_898_432,
      }),
    ).toBe(5_500_000);
  });

  it("falls back to the analysed title's size estimate before giving up", () => {
    expect(
      expectedRemuxSizeBytes({
        hasTaskSnapshot: true,
        selectedTitleSizeBytes: null,
        selectedAnalysisEstimatedSize: 5_800_000,
        resolvedMainTitleSizeBytes: 2_106_898_432,
      }),
    ).toBe(5_800_000);
  });

  it("keeps using the resolved title's size for legacy jobs without a snapshot", () => {
    expect(
      expectedRemuxSizeBytes({
        hasTaskSnapshot: false,
        resolvedMainTitleSizeBytes: 2_106_898_432,
      }),
    ).toBe(2_106_898_432);
  });

  it("ignores non-positive sizes", () => {
    expect(
      expectedRemuxSizeBytes({
        hasTaskSnapshot: true,
        selectedTitleSizeBytes: 0,
      }),
    ).toBeNull();
    expect(
      expectedRemuxSizeBytes({
        hasTaskSnapshot: false,
        resolvedMainTitleSizeBytes: -1,
      }),
    ).toBeNull();
  });
});

describe("disc job duration baseline", () => {
  it("forbids the main-track probe for snapshot-backed disc jobs", () => {
    for (const mediaType of ["dvd", "bluray", "iso"]) {
      expect(
        mayAdoptMainTrackProbeDuration({ mediaType, hasTaskSnapshot: true }),
      ).toBe(false);
    }
  });

  it("keeps the legacy probe fallback for disc jobs without a snapshot", () => {
    for (const mediaType of ["dvd", "bluray", "iso"]) {
      expect(
        mayAdoptMainTrackProbeDuration({ mediaType, hasTaskSnapshot: false }),
      ).toBe(true);
    }
  });

  it("always allows the probe for non-disc media", () => {
    expect(
      mayAdoptMainTrackProbeDuration({
        mediaType: "video",
        hasTaskSnapshot: true,
      }),
    ).toBe(true);
    expect(
      mayAdoptMainTrackProbeDuration({
        mediaType: null,
        hasTaskSnapshot: true,
      }),
    ).toBe(true);
  });
});
