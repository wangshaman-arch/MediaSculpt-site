import { execFile, type ChildProcess } from "node:child_process";

export type ProcessTerminator = (
  child: ChildProcess,
  signal?: NodeJS.Signals,
) => void;

/**
 * Stop a process and, on Windows, its complete descendant tree.
 * `ChildProcess.kill()` only targets the immediate process on Windows; media
 * tools commonly start helper processes, so cancellation must use taskkill's
 * tree mode there. We still kill the direct child immediately: taskkill is
 * asynchronous and a failed/delayed taskkill must not leave the encoder
 * consuming CPU while the HTTP cancellation request has already returned.
 */
export function terminateProcessTree(
  child: ChildProcess,
  signal: NodeJS.Signals = "SIGKILL",
  platform: NodeJS.Platform = process.platform,
): void {
  if (platform === "win32" && typeof child.pid === "number" && child.pid > 0) {
    // 先 taskkill /T 杀整棵树（它强杀根进程及其全部后代）。若先 child.kill 杀掉父进程，
    // 其后代会被孤立，taskkill /T 可能再也找不到它们，导致孤儿进程继续占用 CPU/文件。
    execFile(
      "taskkill",
      ["/F", "/T", "/PID", String(child.pid)],
      { windowsHide: true },
      (error) => {
        if (error) {
          try {
            child.kill(signal);
          } catch {
            /* process already exited */
          }
        }
      },
    );
    return;
  }
  try {
    child.kill(signal);
  } catch {
    /* process already exited */
  }
}
