import { mkdtemp, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { describe, expect, it, vi } from "vitest";
import type { ProcessRunner } from "../infrastructure/process-types";
import {
  PreviewService,
  buildPreviewTranscodeArgs,
  isPreviewVideoCandidate,
} from "./preview-service";

function runner(stdout: string, code = 0): ProcessRunner {
  return {
    run: vi.fn(async () => ({ code, stdout, stderr: "", durationMs: 1 })),
    spawn: vi.fn(() => {
      throw new Error("spawn is not used by PreviewService tests");
    }),
  };
}

describe("PreviewService", () => {
  it("accepts video sources but rejects subtitle sidecars", () => {
    expect(isPreviewVideoCandidate("movie.mkv")).toBe(true);
    expect(isPreviewVideoCandidate("movie.srt")).toBe(false);
    expect(isPreviewVideoCandidate("VIDEO_TS")).toBe(true);
  });

  it("builds browser-compatible transcode arguments", () => {
    const args = buildPreviewTranscodeArgs(true, 2);
    expect(args).toContain("-c:v");
    expect(args).toContain("libx264");
    expect(args).toContain("-f");
    expect(args).toContain("mp4");
    expect(args.join(" ")).toContain("[0:s:2]");
    expect(args.join(" ")).toContain(
      "frag_keyframe+empty_moov+default_base_moof",
    );
    expect(args.join(" ")).toContain(
      "yadif=mode=send_frame:parity=auto:deint=interlaced",
    );
  });

  it("probes duration and file size through the injected process runner", async () => {
    const tempDir = await mkdtemp(
      path.join(os.tmpdir(), "mediasculpt-preview-test-"),
    );
    const mediaPath = path.join(tempDir, "movie.mkv");
    await writeFile(mediaPath, Buffer.alloc(2048));
    try {
      const process = runner(
        JSON.stringify({ format: { duration: "12.5" }, streams: [] }),
      );
      const service = new PreviewService(process, async () => "ffprobe");
      await expect(service.probeMetadata(mediaPath)).resolves.toEqual({
        durationSeconds: 12.5,
        sizeBytes: 2048,
        fileName: "movie.mkv",
      });
      expect(process.run).toHaveBeenCalledWith(
        expect.objectContaining({ executable: "ffprobe" }),
      );
    } finally {
      await rm(tempDir, { recursive: true, force: true });
    }
  });

  it("filters subtitle stream indices and caches the probe briefly", async () => {
    const process = runner(
      JSON.stringify({
        streams: [
          { index: 0, codec_type: "video" },
          { index: 3, codec_type: "subtitle" },
          { index: 5, codec_type: "audio" },
          { index: 8, codec_type: "subtitle" },
        ],
      }),
    );
    const service = new PreviewService(process, async () => "ffprobe");

    await expect(
      service.subtitleContainerIndices("movie.mkv"),
    ).resolves.toEqual([3, 8]);
    await expect(
      service.subtitleContainerIndices("movie.mkv"),
    ).resolves.toEqual([3, 8]);
    expect(process.run).toHaveBeenCalledTimes(1);
  });
});
