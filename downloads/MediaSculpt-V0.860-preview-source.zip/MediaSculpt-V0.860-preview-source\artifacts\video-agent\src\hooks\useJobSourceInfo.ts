import { useEffect, useRef, useState } from "react";
import { type PreviewPlayerHandle } from "../components/PreviewPlayer";
import {
  isImageSubtitleCodec,
  parseSubtitleCues,
  type EmbeddedSubtitleTrack,
  type MediaStreamInfo,
  type SourceInfo,
} from "../pages/job-detail-model";

export type ExternalSubtitleFile = {
  name: string;
  path: string;
  kind: "original" | "translated" | "other";
};

export type SubtitlePreviewKind =
  | "off"
  | "subtitle"
  | "translated"
  | `embedded:${number}`
  | `file:${string}`;

export type SubtitleCue = { start: number; end: number; text: string };

/** 任务结束后优先展示已翻译字幕，其次原文字幕，再次第一个外挂字幕。 */
export function resolveDefaultSubtitlePreviewKind(
  files: ExternalSubtitleFile[],
  current: SubtitlePreviewKind,
): SubtitlePreviewKind {
  if (current !== "off") return current;
  const preferred =
    files.find((file) => file.kind === "translated") ??
    files.find((file) => file.kind === "original") ??
    files[0];
  return preferred ? `file:${preferred.name}` : current;
}

/** 把当前字幕展示选择映射到后端 VTT / 预览接口地址；off 时不请求。 */
export function subtitleCueUrl(
  jobId: number,
  kind: SubtitlePreviewKind,
): string | null {
  if (kind === "off") return null;
  if (kind.startsWith("embedded:")) {
    return `/api/jobs/${jobId}/subtitle-vtt?stream=${encodeURIComponent(
      kind.split(":")[1] ?? "",
    )}`;
  }
  if (kind.startsWith("file:")) {
    return `/api/jobs/${jobId}/subtitle-preview?file=${encodeURIComponent(
      kind.slice("file:".length),
    )}`;
  }
  return `/api/jobs/${jobId}/subtitle-preview?kind=${
    kind === "translated" ? "translated" : "subtitle"
  }`;
}

/**
 * 任务源信息与字幕预览：拉取 streams / subtitles，维护字幕展示选择、外挂字幕文件、
 * 内嵌字幕轨，并按当前选择加载字幕 cue 文本。播放器重建由 selectEmbeddedTrack /
 * clearBurnedSubtitleIfNeeded 通过 playerRef 完成。
 */
export function useJobSourceInfo(
  jobId: number,
  job: { id: number } | undefined,
) {
  const [subtitlePreviewKind, setSubtitlePreviewKind] =
    useState<SubtitlePreviewKind>("off");
  const [showAllTracks, setShowAllTracks] = useState(false);
  const [embeddedSubtitleTracks, setEmbeddedSubtitleTracks] = useState<
    EmbeddedSubtitleTrack[]
  >([]);
  const [externalSubtitleFiles, setExternalSubtitleFiles] = useState<
    ExternalSubtitleFile[]
  >([]);
  const [sourceInfo, setSourceInfo] = useState<SourceInfo | null>(null);
  const [subtitleCues, setSubtitleCues] = useState<SubtitleCue[]>([]);
  const playerRef = useRef<PreviewPlayerHandle>(null);

  useEffect(() => {
    if (!job) return;
    let cancelled = false;
    fetch(`/api/jobs/${jobId}/streams`)
      .then((response) => (response.ok ? response.json() : null))
      .then((data) => {
        if (cancelled) return;
        const tracks: EmbeddedSubtitleTrack[] = Array.isArray(data?.streams)
          ? data.streams
              .filter(
                (stream: { codecType?: string }) =>
                  stream.codecType === "subtitle",
              )
              .map(
                (stream: {
                  index: number;
                  codecName?: string;
                  language?: string | null;
                  title?: string | null;
                }) => ({
                  index: stream.index,
                  codecName: stream.codecName ?? "subtitle",
                  language: stream.language,
                  title: stream.title,
                }),
              )
          : [];
        setEmbeddedSubtitleTracks(tracks);
        setSourceInfo({
          streams: Array.isArray(data?.streams) ? data.streams : [],
          chapters: Array.isArray(data?.chapters) ? data.chapters : [],
          duration: typeof data?.duration === "number" ? data.duration : null,
          formatName:
            typeof data?.formatName === "string" ? data.formatName : null,
          bitRate: typeof data?.bitRate === "string" ? data.bitRate : null,
        });
      })
      .catch(() => {
        if (!cancelled) {
          setEmbeddedSubtitleTracks([]);
          setSourceInfo(null);
        }
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [jobId, job?.id]);

  useEffect(() => {
    if (!job) return;
    let cancelled = false;
    fetch(`/api/jobs/${jobId}/subtitles`)
      .then((response) => (response.ok ? response.json() : null))
      .then((body: { files?: ExternalSubtitleFile[] } | null) => {
        if (cancelled) return;
        const files = Array.isArray(body?.files) ? body.files : [];
        setExternalSubtitleFiles(files);
        setSubtitlePreviewKind((current) =>
          resolveDefaultSubtitlePreviewKind(files, current),
        );
      })
      .catch(() => {
        if (!cancelled) setExternalSubtitleFiles([]);
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [jobId, job?.id]);

  useEffect(() => {
    let cancelled = false;
    if (subtitlePreviewKind === "off") {
      setSubtitleCues([]);
      return;
    }
    if (subtitlePreviewKind.startsWith("embedded:")) {
      const trackIndex = Number(subtitlePreviewKind.split(":")[1] ?? "-1");
      const track = embeddedSubtitleTracks.find(
        (item) => item.index === trackIndex,
      );
      if (track && isImageSubtitleCodec(track.codecName)) {
        // Image-based tracks are burned into the preview stream, not overlaid as text.
        setSubtitleCues([]);
        return;
      }
    }
    const url = subtitleCueUrl(jobId, subtitlePreviewKind);
    if (!url) return;
    fetch(url)
      .then((response) => (response.ok ? response.text() : ""))
      .then((text) => {
        if (!cancelled) setSubtitleCues(parseSubtitleCues(text));
      })
      .catch(() => {
        if (!cancelled) setSubtitleCues([]);
      });
    return () => {
      cancelled = true;
    };
  }, [subtitlePreviewKind, embeddedSubtitleTracks, jobId]);

  const selectEmbeddedTrack = (track: EmbeddedSubtitleTrack) => {
    const burnIndex = isImageSubtitleCodec(track.codecName)
      ? track.index
      : null;
    setSubtitlePreviewKind(`embedded:${track.index}`);
    const player = playerRef.current;
    if (player) player.rebuild(player.getCurrentTime(), burnIndex);
  };

  const clearBurnedSubtitleIfNeeded = () => {
    const player = playerRef.current;
    if (player) player.rebuild(player.getCurrentTime(), null);
  };

  const previewVideoStream: MediaStreamInfo | undefined =
    sourceInfo?.streams.find((stream) => stream.codecType === "video");

  return {
    sourceInfo,
    embeddedSubtitleTracks,
    externalSubtitleFiles,
    subtitlePreviewKind,
    setSubtitlePreviewKind,
    showAllTracks,
    setShowAllTracks,
    subtitleCues,
    playerRef,
    selectEmbeddedTrack,
    clearBurnedSubtitleIfNeeded,
    previewVideoStream,
  };
}
