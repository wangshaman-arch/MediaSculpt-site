import { describe, expect, it } from "vitest";
import { discPreviewPagination } from "./disc-preview-model";

describe("disc preview model", () => {
  it("pages previews two at a time and clamps the requested page", () => {
    const pagination = discPreviewPagination(["a", "b", "c", "d", "e"], 0);
    expect(pagination.pageCount).toBe(3);
    expect(pagination.visible).toEqual(["a", "b"]);
    expect(pagination.canPrev).toBe(false);
    expect(pagination.canNext).toBe(true);

    expect(discPreviewPagination(["a", "b", "c", "d", "e"], 99)).toMatchObject({
      page: 2,
      visible: ["e"],
      canNext: false,
    });
  });

  it("always keeps at least one page for an empty preview list", () => {
    expect(discPreviewPagination([], 0)).toMatchObject({
      page: 0,
      pageCount: 1,
      visible: [],
      canPrev: false,
      canNext: false,
    });
  });
});
