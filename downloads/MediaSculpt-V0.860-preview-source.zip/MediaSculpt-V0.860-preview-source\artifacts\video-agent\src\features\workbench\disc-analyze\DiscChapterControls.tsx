import { Checkbox } from "@/components/ui/checkbox";
import { useI18n } from "@/i18n";
import type { ScanCopy } from "@/pages/Scan";
import {
  formatDiscChapterDuration,
  formatDiscDuration,
  type DiscTrackWithMakeMkv,
} from "../disc-display-model";

export type DiscChapterControlsProps = {
  uiText: ScanCopy;
  selectedTrack: DiscTrackWithMakeMkv;
  verifying: boolean;
  selectedChapterIds: Set<number>;
  onToggleChapter: (id: number) => void;
  onSetAllChapters: (selected: boolean) => void;
};

export function DiscChapterControls({
  uiText,
  selectedTrack,
  verifying,
  selectedChapterIds,
  onToggleChapter,
  onSetAllChapters,
}: DiscChapterControlsProps) {
  const { t } = useI18n();

  return (
    <div data-testid="title-level-chapter-controls">
      <div className="mb-2 flex items-center justify-between gap-2">
        <p className="text-xs font-medium text-muted-foreground">
          {uiText.chapterInfo}
        </p>
        <div className="flex shrink-0 gap-1">
          <button
            type="button"
            className="rounded border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-secondary/50"
            onClick={() => onSetAllChapters(true)}
            disabled={verifying}
          >
            {uiText.selectAll}
          </button>
          <button
            type="button"
            className="rounded border px-2 py-0.5 text-[11px] text-muted-foreground hover:bg-secondary/50"
            onClick={() => onSetAllChapters(false)}
            disabled={verifying}
          >
            {uiText.clearSelection}
          </button>
        </div>
      </div>
      <div className="space-y-1 rounded-lg border divide-y">
        {selectedTrack.chapters?.map((chapter) => (
          <label
            key={chapter.id}
            onPointerDown={(event) => event.stopPropagation()}
            onClick={(event) => event.stopPropagation()}
            className="flex cursor-pointer items-center gap-3 px-3 py-2 text-sm hover:bg-secondary/30"
          >
            <Checkbox
              checked={selectedChapterIds.has(chapter.id)}
              disabled={verifying}
              onCheckedChange={() => onToggleChapter(chapter.id)}
            />
            <span className="font-mono text-xs">#{chapter.id + 1}</span>
            <span className="flex-1 truncate">
              {chapter.title || t("scan.unnamedChapter")}
            </span>
            <span className="font-mono text-xs text-muted-foreground">
              {formatDiscDuration(chapter.startSeconds)} -{" "}
              {formatDiscDuration(chapter.endSeconds)}
            </span>
            <span className="text-xs text-muted-foreground">
              {t("scan.durationValue", {
                value:
                  formatDiscChapterDuration(
                    chapter.startSeconds,
                    chapter.endSeconds,
                  ) || t("scan.unknown"),
              })}
            </span>
          </label>
        ))}
      </div>
    </div>
  );
}
