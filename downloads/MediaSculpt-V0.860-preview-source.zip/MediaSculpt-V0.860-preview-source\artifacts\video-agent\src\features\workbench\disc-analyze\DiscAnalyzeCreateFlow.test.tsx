// @vitest-environment jsdom
import type { ReactNode } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  cleanup,
  render,
  screen,
  waitFor,
  within,
} from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import type {
  AnalyzeDiscQueryResult,
  DiscStream,
} from "@workspace/api-client-react";
import { I18nProvider, useScanCopy } from "@/i18n";
import { zhCN } from "@/i18n/zh-CN";
import type { DiscTrackWithMakeMkv } from "../disc-display-model";
import { DiscAnalyzeDialog } from "../DiscAnalyzeDialog";

const mocks = vi.hoisted(() => ({
  createJob: vi.fn(),
  toast: vi.fn(),
  state: {} as { analysis: AnalyzeDiscQueryResult | undefined },
}));

// Keep every other generated export (and the rest of the app's import graph)
// real; only intercept the disc-analyze hooks so no network/query client runs.
vi.mock("@workspace/api-client-react", async (importOriginal) => {
  const actual =
    await importOriginal<typeof import("@workspace/api-client-react")>();
  return {
    ...actual,
    getGetConfigQueryKey: () => ["config"] as const,
    getListJobsQueryKey: (params?: unknown) => ["jobs", params] as const,
    useGetConfig: () => ({ data: undefined }),
    useAnalyzeDisc: () => ({
      data: mocks.state.analysis,
      isLoading: false,
      isError: false,
    }),
    useListJobs: () => ({ data: [] }),
    useCreateJob: () => ({ mutateAsync: mocks.createJob, isPending: false }),
  };
});

vi.mock("@/hooks/use-toast", () => ({
  useToast: () => ({ toast: mocks.toast, dismiss: vi.fn() }),
  toast: mocks.toast,
}));

const DISC_PATH = "D:/discs/MOVIE";
const ANALYSIS_ID = "analysis-1";
const FINGERPRINT = "fingerprint-1";
// Smaller than a title so the capacity-safe default selection is empty,
// forcing the test to select a title explicitly.
const SOURCE_BYTES = 1_000_000_000;

function stream(
  index: number,
  codecType: DiscStream["codecType"],
  codecName: string,
): DiscStream {
  return { index, codecType, codecName };
}

const VALID_AUDIO_INDEX = 1;
const VALID_SUBTITLE_INDEX = 2;

const validTrack: DiscTrackWithMakeMkv = {
  path: `${DISC_PATH}/Title 1.m2ts`,
  name: "Title 1",
  titleId: "title-1",
  sizeBytes: 2_000_000_000,
  durationSeconds: 3600,
  verificationStatus: "verified",
  streams: [
    stream(0, "video", "h264"),
    stream(VALID_AUDIO_INDEX, "audio", "ac3"),
    stream(VALID_SUBTITLE_INDEX, "subtitle", "subrip"),
  ],
  chapters: [
    { id: 0, startSeconds: 0, endSeconds: 60 },
    { id: 1, startSeconds: 60, endSeconds: 120 },
  ],
};

const unavailableTrack: DiscTrackWithMakeMkv = {
  path: `${DISC_PATH}/Title 2.m2ts`,
  name: "Title 2",
  titleId: "title-2",
  sizeBytes: 2_000_000_000,
  durationSeconds: 3600,
  availabilityStatus: "unavailable",
  availabilityFailureReason: "title source is gone",
  streams: [stream(0, "video", "h264"), stream(1, "audio", "ac3")],
};

function analysisWith(tracks: DiscTrackWithMakeMkv[]): AnalyzeDiscQueryResult {
  return {
    discType: "dvd",
    analysisId: ANALYSIS_ID,
    sourceFingerprint: FINGERPRINT,
    sourceSizeBytes: SOURCE_BYTES,
    tracks,
  };
}

function createCountName(count: number): string {
  return zhCN.scan.createTaskCount.replace("{count}", String(count));
}

function Harness({
  onClose,
  onJobCreated,
  children,
}: {
  onClose: () => void;
  onJobCreated: (count: number, firstId?: number) => void;
  children?: ReactNode;
}) {
  const uiText = useScanCopy();
  return (
    <>
      <DiscAnalyzeDialog
        discPath={DISC_PATH}
        processingMode="none"
        subtitleMode="extract"
        uiText={uiText}
        onClose={onClose}
        onJobCreated={onJobCreated}
      />
      {children}
    </>
  );
}

function renderDialog(
  analysis: AnalyzeDiscQueryResult,
  handlers: {
    onClose?: () => void;
    onJobCreated?: (count: number, firstId?: number) => void;
  } = {},
) {
  mocks.state.analysis = analysis;
  const onClose = handlers.onClose ?? vi.fn();
  const onJobCreated = handlers.onJobCreated ?? vi.fn();
  return {
    onClose,
    onJobCreated,
    ...render(
      <I18nProvider lang="zh-CN">
        <Harness onClose={onClose} onJobCreated={onJobCreated} />
      </I18nProvider>,
    ),
  };
}

function titleRow(name: string) {
  return screen.getByRole("button", { name: new RegExp(name) });
}

async function selectTitle(
  user: ReturnType<typeof userEvent.setup>,
  name: string,
) {
  await user.click(within(titleRow(name)).getByRole("checkbox"));
}

beforeEach(() => {
  mocks.createJob.mockReset();
  mocks.toast.mockReset();
  mocks.state.analysis = undefined;
  vi.stubGlobal(
    "fetch",
    vi.fn((input: RequestInfo | URL) => {
      const url = typeof input === "string" ? input : input.toString();
      if (url.includes("/api/disc/title-preview")) {
        // Preview images are irrelevant here; never resolve so no state churn.
        return new Promise(() => {});
      }
      return Promise.resolve({
        ok: true,
        status: 200,
        json: async () => ({}),
        text: async () => "{}",
      });
    }),
  );
});

afterEach(() => {
  vi.unstubAllGlobals();
  cleanup();
});

describe("disc analyze real create flow", () => {
  it("selecting a title updates the real selection and enables creation", async () => {
    const user = userEvent.setup();
    renderDialog(analysisWith([validTrack]));

    expect(
      screen.getByRole("button", {
        name: zhCN.scan.chooseTitleBeforeCreate,
      }),
    ).toBeDisabled();

    await selectTitle(user, "Title 1");

    expect(
      screen.getByRole("button", { name: createCountName(1) }),
    ).toBeEnabled();
  });

  it("cannot create when the title is unavailable and never posts a request", async () => {
    const user = userEvent.setup();
    renderDialog(analysisWith([unavailableTrack]));

    const create = screen.getByRole("button", {
      name: zhCN.scan.chooseTitleBeforeCreate,
    });
    expect(create).toBeDisabled();

    const checkbox = within(titleRow("Title 2")).getByRole("checkbox");
    expect(checkbox).toBeDisabled();

    await user.click(checkbox);
    await user.click(create);

    expect(mocks.createJob).not.toHaveBeenCalled();
  });

  it("surfaces an error and does not report success when creation fails", async () => {
    const user = userEvent.setup();
    mocks.createJob.mockRejectedValueOnce(new Error("backend exploded"));
    const { onClose, onJobCreated } = renderDialog(analysisWith([validTrack]));

    await selectTitle(user, "Title 1");
    await user.click(screen.getByRole("button", { name: createCountName(1) }));

    await waitFor(() => expect(mocks.createJob).toHaveBeenCalledTimes(1));
    await waitFor(() =>
      expect(mocks.toast).toHaveBeenCalledWith(
        expect.objectContaining({
          variant: "destructive",
          description: "backend exploded",
        }),
      ),
    );
    expect(onJobCreated).not.toHaveBeenCalled();
    expect(onClose).not.toHaveBeenCalled();
  });

  it("posts the chosen title/track/streams and reports success", async () => {
    const user = userEvent.setup();
    mocks.createJob.mockResolvedValueOnce({ id: 42 });
    const { onClose, onJobCreated } = renderDialog(analysisWith([validTrack]));

    await selectTitle(user, "Title 1");
    await user.click(screen.getByRole("button", { name: createCountName(1) }));

    await waitFor(() => expect(onJobCreated).toHaveBeenCalledWith(1, 42));
    expect(mocks.createJob).toHaveBeenCalledTimes(1);

    const call = mocks.createJob.mock.calls[0][0] as {
      data: Record<string, unknown>;
    };
    expect(call.data).toMatchObject({
      filePath: DISC_PATH,
      mainTrackPath: validTrack.path,
      selectedTitleId: "title-1",
      analysisId: ANALYSIS_ID,
      sourceFingerprint: FINGERPRINT,
      mediaType: "dvd",
      subtitleMode: "extract",
      processingMode: "none",
      outputMode: "subtitle",
      selectedStreams: JSON.stringify([
        VALID_AUDIO_INDEX,
        VALID_SUBTITLE_INDEX,
      ]),
      selectedChapters: JSON.stringify([0, 1]),
    });

    const plan = JSON.parse(String(call.data.selectionPlan));
    expect(plan.analysis.titleId).toBe("title-1");
    expect(plan.audio).toEqual([VALID_AUDIO_INDEX]);
    expect(plan.subtitle).toEqual([VALID_SUBTITLE_INDEX]);
    expect(plan.chapters).toEqual([0, 1]);
    expect(onClose).toHaveBeenCalledTimes(1);
  });
});
