import type {
  ChargeTaskInput,
  ChargeTaskResult,
} from "./preview-entitlement-repository";

type PreviewTaskRepository = {
  chargeTaskOnce: (input: ChargeTaskInput) => Promise<ChargeTaskResult>;
};

export type PreviewJobSettlementInput = {
  jobId: number;
  taskKind: string;
  outputValid: boolean;
  isPreviewOnly: boolean;
  cancelled: boolean;
};

export function createPreviewJobSettlement(repository: PreviewTaskRepository) {
  return async function settlePreviewJob(
    input: PreviewJobSettlementInput,
  ): Promise<ChargeTaskResult> {
    if (!input.outputValid || input.isPreviewOnly || input.cancelled) {
      return { charged: false, successfulTaskCount: 0 };
    }
    return repository.chargeTaskOnce({
      jobId: input.jobId,
      taskKind: input.taskKind,
      chargedAt: new Date(),
    });
  };
}
