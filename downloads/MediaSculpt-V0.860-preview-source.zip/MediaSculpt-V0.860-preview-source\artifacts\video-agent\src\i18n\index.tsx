import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  type ReactNode,
} from "react";
import { zhCN } from "./zh-CN";
import { enUS } from "./en-US";

export type AppLanguage = "zh-CN" | "en-US";

type LocalePack = typeof zhCN;

const PACKS: Record<AppLanguage, LocalePack> = {
  "zh-CN": zhCN,
  "en-US": enUS,
};

export function getNestedValue(pack: LocalePack, path: string): unknown {
  let current: unknown = pack;
  for (const part of path.split(".")) {
    if (current && typeof current === "object" && part in current) {
      current = (current as Record<string, unknown>)[part];
    } else {
      return undefined;
    }
  }
  return current;
}

type I18nContextValue = {
  lang: AppLanguage;
  t: (path: string, params?: Record<string, string | number>) => string;
};

const I18nContext = createContext<I18nContextValue>({
  lang: "zh-CN",
  t: (path) => String(getNestedValue(zhCN, path) ?? path),
});

export function I18nProvider({
  lang,
  children,
}: {
  lang: AppLanguage;
  children: ReactNode;
}) {
  const t = useCallback(
    (path: string, params?: Record<string, string | number>) => {
      const pack = PACKS[lang];
      let value = getNestedValue(pack, path);
      if (typeof value !== "string") {
        value = getNestedValue(zhCN, path);
        if (typeof value !== "string") return path;
        if (process.env.NODE_ENV !== "production" && lang !== "zh-CN") {
          console.warn(`[i18n] missing translation for "${path}" in ${lang}`);
        }
      }
      if (!params) return value;
      return value.replace(/\{(\w+)\}/g, (match, key: string) => {
        const replacement = params[key];
        return replacement === undefined ? match : String(replacement);
      });
    },
    [lang],
  );

  const value = useMemo(() => ({ lang, t }), [lang, t]);
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nContextValue {
  return useContext(I18nContext);
}

/** Scan workbench copy in the shape expected by the workbench UI, sourced from the locale packs. */
export function useScanCopy() {
  const { t } = useI18n();
  return {
    title: t("scan.title"),
    description: t("scan.description"),
    processingMode: t("scan.processingMode"),
    processingModeDescription: t("scan.processingModeDescription"),
    modes: {
      compress: {
        label: t("scan.modeCompress"),
        desc: t("scan.modeCompressDesc"),
      },
      remux: { label: t("scan.modeRemux"), desc: t("scan.modeRemuxDesc") },
      none: { label: t("scan.modeNone"), desc: t("scan.modeNoneDesc") },
    },
    subtitleModes: {
      auto: { label: t("scan.subtitleAuto"), desc: t("scan.subtitleAutoDesc") },
      ocr: { label: t("scan.subtitleOcr"), desc: t("scan.subtitleOcrDesc") },
      extract: {
        label: t("scan.subtitleExtract"),
        desc: t("scan.subtitleExtractDesc"),
      },
      whisper: {
        label: t("scan.subtitleWhisper"),
        desc: t("scan.subtitleWhisperDesc"),
      },
      transcribe_translate: {
        label: t("scan.subtitleTranscribe"),
        desc: t("scan.subtitleTranscribeDesc"),
      },
      skip: { label: t("scan.subtitleSkip"), desc: t("scan.subtitleSkipDesc") },
      audio: {
        label: t("scan.subtitleAudio"),
        desc: t("scan.subtitleAudioDesc"),
      },
      bilingual: {
        label: t("scan.subtitleBilingual"),
        desc: t("scan.subtitleBilingualDesc"),
      },
    },
    sourcePreview: t("scan.sourcePreview"),
    unifiedPreview: t("scan.sourcePreview"),
    unifiedPreviewDesc: t("scan.processingModeDescription"),
    analyzingDisc: t("scan.analyzingDisc"),
    discAnalysisFailed: t("scan.discAnalysisFailed"),
    discAnalysisHint: t("scan.discAnalysisHint"),
    selectTitles: t("scan.selectTitles"),
    selectAllTitles: t("scan.selectAllTitles"),
    clearAllTitles: t("scan.clearAllTitles"),
    currentTrack: t("scan.currentTrack"),
    selectStreams: t("scan.selectStreams"),
    selectAllStreams: t("scan.selectAllStreams"),
    clearAllStreams: t("scan.clearAllStreams"),
    chapterInfo: t("scan.chapterInfo"),
    noChapters: t("scan.noChapters"),
    noChaptersHint: t("scan.noChaptersHint"),
    noStreams: t("scan.noStreams"),
    cancel: t("common.cancel"),
    create: t("scan.create"),
    creating: t("scan.creating"),
    createdDiscJob: t("scan.createRemuxJob"),
    createdRemuxJob: t("scan.createRemuxJob"),
    createRemuxJob: t("scan.createRemuxJob"),
    createCompressionJob: t("scan.createCompressionJob"),
    createSubtitleJob: t("scan.createSubtitleJob"),
    discAnalysis: t("scan.discAnalysis"),
    discDirectory: t("scan.discDirectory"),
    discBannerPrefix: t("scan.discBannerPrefix"),
    networkPathPlaceholder: t("scan.networkPathPlaceholder"),
    openNetworkLocation: t("scan.openNetworkLocation"),
    chooseNetworkLocation: t("scan.chooseNetworkLocation"),
    directoryPickerPlaceholder: t("scan.directoryPickerPlaceholder"),
    recentLocations: t("scan.recentLocations"),
    pathExamples: t("scan.pathExamples"),
    selectAll: t("scan.selectAll"),
    clearSelection: t("scan.clearSelection"),
    addSelected: t("scan.addSelected"),
    previewSelected: t("nav.settingsPreview"),
    batchTasks: t("scan.batchTasks"),
    sortByName: t("scan.sortByName"),
    sortByModified: t("scan.sortByModified"),
    addedTasks: t("scan.addedTasks"),
    browseFiles: t("scan.browseFiles"),
    browseFilesDesc: t("scan.browseFilesDesc"),
    browseSelect: t("scan.browseSelect"),
    currentMode: t("scan.currentMode"),
    enterBrowse: t("scan.enterBrowse"),
    browseCollapsed: t("scan.browseCollapsed"),
    batchScan: t("scan.batchScan"),
    scanTab: t("scan.batchScan"),
    batchScanDesc: t("scan.batchScanDesc"),
    directoryPath: t("scan.directoryPath"),
    directoryPathHint: t("scan.directoryPathHint"),
    recursiveScan: t("scan.recursiveScan"),
    recursiveScanDesc: t("scan.recursiveScanDesc"),
    subtitleMode: t("scan.subtitleMode"),
    scanning: t("scan.scanning"),
    startScan: t("scan.startScan"),
    scanResult: t("scan.scanResult"),
    scanDone: t("scan.scanDone"),
    scanFailed: t("scan.scanFailed"),
    unknownError: t("common.unknownError"),
    found: t("scan.found"),
    created: t("scan.created"),
    skipped: t("scan.skipped"),
    viewJobs: t("scan.viewJobs"),
    loadingConfig: t("scan.loadingConfig"),
    compressionDirectDesc: t("scan.compressionDirectDesc"),
    sourceDirectory: t("scan.sourceDirectory"),
    sourceDirectoryDesc: t("scan.sourceDirectoryDesc"),
    browseSource: t("scan.browseSource"),
    collapseBrowse: t("scan.collapseBrowse"),
    expandBrowse: t("scan.expandBrowse"),
    expandList: t("scan.expandList"),
    collapseList: t("scan.collapseList"),
    chooseDirPlaceholder: t("scan.chooseDirPlaceholder"),
    backToParent: t("scan.backToParent"),
    networkLocation: t("scan.networkLocation"),
    selectedCount: t("scan.selectedCount"),
    sizeUnknown: t("scan.sizeUnknown"),
    processableMedia: t("scan.processableMedia"),
    dragHint: t("scan.dragHint"),
    emptyDirectory: t("scan.emptyDirectory"),
    goToParentHint: t("scan.goToParentHint"),
    analyze: t("scan.analyze"),
    fileSizeLabel: t("scan.fileSizeLabel"),
    discDirInstructionTitle: t("scan.discDirInstructionTitle"),
    discDirInstructionBody: t("scan.discDirInstructionBody"),
    discDirPathLabel: t("scan.discDirPathLabel"),
    driveRootHint: t("scan.driveRootHint"),
    outputDirHint: t("scan.outputDirHint"),
    stepInputPath: t("scan.stepInputPath"),
    stepInputPathDesc: t("scan.stepInputPathDesc"),
    stepClickAnalyze: t("scan.stepClickAnalyze"),
    stepClickAnalyzeDesc: t("scan.stepClickAnalyzeDesc"),
    stepSelectCreate: t("scan.stepSelectCreate"),
    stepSelectCreateDesc: t("scan.stepSelectCreateDesc"),
    helpAria: t("scan.helpAria"),
    workbenchHintText: t("scan.workbenchHintText"),
    currentPrefix: t("scan.currentPrefix"),
    jobsAdded: t("scan.jobsAdded"),
    viewQueue: t("scan.viewQueue"),
  };
}
