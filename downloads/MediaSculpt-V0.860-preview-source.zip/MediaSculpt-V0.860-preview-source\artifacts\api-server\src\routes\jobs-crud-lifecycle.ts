import { Router } from "express";
import { db, jobsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  CancelJobParams,
  DeleteJobParams,
  RetryJobParams,
  StartJobParams,
} from "@workspace/api-zod";
import { loadTaskSnapshot, serializeTaskSnapshot } from "../lib/task-snapshot";
import { hasExecutableWorkflowSelection } from "../lib/job-workflow";
import { cleanupPreviewSegments } from "../lib/preview-segments";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import { assertPreviewTaskAllowed } from "../lib/preview-runtime";
import { isActiveJobStatus } from "../application/job-errors";
import { addLog } from "../lib/job-logging";
import { getConfig } from "./jobs-config";
import { jobService, startJobWhenQueueIdle } from "./job-runtime";
import { SOURCE_DIRECTORY_VALUE } from "./jobs-output-paths";

const router = Router();
// DELETE /jobs/:id
router.delete("/jobs/:id", async (req, res) => {
  const parsed = DeleteJobParams.safeParse(req.params);
  if (!parsed.success) return res.status(400).json({ error: "无效的任务 ID" });

  const rows = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, parsed.data.id))
    .limit(1);
  if (rows[0] && isActiveJobStatus(rows[0].status)) {
    return res
      .status(409)
      .json({ error: "运行中的任务不能直接删除，请先暂停或取消" });
  }
  await db.delete(jobsTable).where(eq(jobsTable.id, parsed.data.id));
  if (rows[0]?.filePath)
    void cleanupPreviewSegments(rows[0].filePath).catch(() => {});
  return res.status(204).send();
});

// POST /jobs/:id/start
router.post("/jobs/:id/start", async (req, res) => {
  const parsed = StartJobParams.safeParse(req.params);
  if (!parsed.success) return res.status(400).json({ error: "无效的任务 ID" });

  const result = await jobService.start(parsed.data.id);
  if (result.kind === "not-found")
    return res.status(404).json({ error: "任务未找到" });
  if (result.kind === "invalid-state")
    return res
      .status(400)
      .json({ error: `任务状态为 ${result.job.status}，无法启动` });
  if (result.kind === "needs-confirmation")
    return res
      .status(400)
      .json({ error: "请先在智能助手中选择处理项目并确认" });
  if (result.kind === "preview-blocked")
    return res.status(409).json({
      errorCode: result.code,
      error: result.message,
      preview: result.preview,
    });
  return res.json(result.job);
});

// POST /jobs/:id/retry
router.post("/jobs/:id/retry", async (req, res) => {
  const parsed = RetryJobParams.safeParse(req.params);
  if (!parsed.success) return res.status(400).json({ error: "无效的任务 ID" });

  const rows = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, parsed.data.id))
    .limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });

  try {
    await assertPreviewTaskAllowed();
  } catch (error) {
    if (isPreviewLimitError(error))
      return res.status(409).json({
        errorCode: error.errorCode,
        error: error.message,
        preview: error.preview,
      });
    throw error;
  }

  // 重试时，Remux 任务的输出目录与字幕目录跟随当前配置（默认“与源文件同目录”），
  // 避免旧任务快照里的旧目录把输出写到别处。
  const retryConfig = await getConfig();
  const retrySnapshot = loadTaskSnapshot(rows[0]);
  if (
    retrySnapshot &&
    !hasExecutableWorkflowSelection({
      processingMode: rows[0].processingMode,
      subtitleMode: rows[0].subtitleMode,
      outputMode: retrySnapshot.outputMode,
    })
  ) {
    const message =
      "该旧任务没有可执行步骤：原任务保存为‘跳过字幕 + 不处理视频’。请打开任务详情，在智能助手中选择 Remux 或压缩后再确认，不能直接重试。";
    await addLog(parsed.data.id, "error", message);
    return res
      .status(409)
      .json({ errorCode: "TASK_NO_EXECUTABLE_STEP", error: message });
  }
  if (retrySnapshot && retrySnapshot.outputMode === "remux") {
    const remuxTargetDir =
      retryConfig.remuxOutputDirectory ?? retryConfig.outputDirectory;
    const subtitleTargetDir = retryConfig.subtitleDirectory ?? "";
    if (
      retrySnapshot.output.directory !== remuxTargetDir ||
      (retrySnapshot.output.subtitleDirectory ?? "") !== subtitleTargetDir
    ) {
      const refreshed = {
        ...retrySnapshot,
        output: {
          ...retrySnapshot.output,
          directory: remuxTargetDir,
          subtitleDirectory: subtitleTargetDir,
        },
      };
      await db
        .update(jobsTable)
        .set({ taskSnapshot: serializeTaskSnapshot(refreshed) })
        .where(eq(jobsTable.id, parsed.data.id));
      await addLog(
        parsed.data.id,
        "info",
        `重试已同步输出目录到当前配置：${remuxTargetDir === SOURCE_DIRECTORY_VALUE ? "源文件同目录" : remuxTargetDir}`,
      );
    }
  }

  await db
    .update(jobsTable)
    .set({
      status: "pending",
      errorMessage: null,
      progress: null,
      startedAt: null,
      completedAt: null,
    })
    .where(eq(jobsTable.id, parsed.data.id));

  await startJobWhenQueueIdle(parsed.data.id);
  const [updated] = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, parsed.data.id))
    .limit(1);
  return res.json(updated);
});

// 暂停单个任务：终止运行中的子进程并标记为“已暂停”（不阻塞队列调度），
// 之后可用重试/恢复重新执行。
router.post("/jobs/:id/pause", async (req, res) => {
  const parsed = CancelJobParams.safeParse(req.params);
  if (!parsed.success) return res.status(400).json({ error: "无效的任务 ID" });
  const result = await jobService.pause(parsed.data.id);
  if (result.kind === "not-found")
    return res.status(404).json({ error: "任务未找到" });
  if (result.kind === "stop-failed")
    return res.status(409).json({
      error: "未能确认外部处理进程已退出，任务仍在运行，请稍后重试停止",
    });
  return res.json(result.job);
});

// POST /jobs/:id/cancel
router.post("/jobs/:id/cancel", async (req, res) => {
  const parsed = CancelJobParams.safeParse(req.params);
  if (!parsed.success) return res.status(400).json({ error: "无效的任务 ID" });

  const result = await jobService.cancel(parsed.data.id);
  if (result.kind === "not-found")
    return res.status(404).json({ error: "任务未找到" });
  if (result.kind === "stop-failed")
    return res.status(409).json({
      error: "未能确认外部处理进程已退出，任务仍在运行，请稍后重试停止",
    });
  return res.json(result.job);
});

export const jobsCrudLifecycleRouter = router;
