import { afterEach, describe, expect, it } from "vitest";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { validateRemuxOutput } from "./remux-validation";

const files: string[] = [];
afterEach(async () => {
  await Promise.all(
    files.splice(0).map((file) => fs.unlink(file).catch(() => {})),
  );
});

describe("remux output validation", () => {
  it("accepts a valid output and calculates drift", async () => {
    const file = path.join(os.tmpdir(), `vx-remux-${Date.now()}.mkv`);
    files.push(file);
    await fs.writeFile(file, Buffer.alloc(10));
    const result = await validateRemuxOutput(file, 100, async () => ({
      duration: 90,
    }));
    expect(result.fileSize).toBe(10);
    expect(result.drift).toBeCloseTo(0.1);
  });

  it("rejects an empty output", async () => {
    const file = path.join(os.tmpdir(), `vx-remux-empty-${Date.now()}.mkv`);
    files.push(file);
    await fs.writeFile(file, Buffer.alloc(0));
    await expect(
      validateRemuxOutput(file, 10, async () => ({ duration: 10 })),
    ).rejects.toThrow("输出文件为空");
  });

  it("rejects a remux output that is much smaller AND whose duration deviates from the selected title", async () => {
    const file = path.join(os.tmpdir(), `vx-remux-small-${Date.now()}.mkv`);
    files.push(file);
    await fs.writeFile(file, Buffer.alloc(40));

    await expect(
      validateRemuxOutput(file, 10, async () => ({ duration: 3 }), {
        expectedSizeBytes: 100,
        minimumSizeRatio: 0.65,
      }),
    ).rejects.toThrow("Remux 输出文件明显小于所选源");
  });

  it("accepts a smaller-but-correct output (short/extras title) when the duration matches the selected title", async () => {
    const file = path.join(os.tmpdir(), `vx-remux-short-${Date.now()}.mkv`);
    files.push(file);
    await fs.writeFile(file, Buffer.alloc(40));

    const result = await validateRemuxOutput(
      file,
      10,
      async () => ({ duration: 10 }),
      {
        expectedSizeBytes: 100,
        minimumSizeRatio: 0.65,
      },
    );
    expect(result.fileSize).toBe(40);
    expect(result.drift).toBeCloseTo(0);
  });

  it("rejects an output that exceeds the selected physical VOB payload", async () => {
    const file = path.join(os.tmpdir(), `vx-remux-over-size-${Date.now()}.mkv`);
    files.push(file);
    await fs.writeFile(file, Buffer.alloc(1_101));

    await expect(
      validateRemuxOutput(file, 10, async () => ({ duration: 10 }), {
        expectedSizeBytes: 1_000,
        maximumSizeRatio: 1.05,
        maximumSizeOverheadBytes: 0,
      }),
    ).rejects.toThrow("超过所选 VOB 物理载荷");
  });

  it("allows a small Matroska overhead above the VOB payload", async () => {
    const file = path.join(os.tmpdir(), `vx-remux-overhead-${Date.now()}.mkv`);
    files.push(file);
    await fs.writeFile(file, Buffer.alloc(1_020));

    const result = await validateRemuxOutput(
      file,
      10,
      async () => ({ duration: 10 }),
      {
        expectedSizeBytes: 1_000,
        maximumSizeRatio: 1.05,
        maximumSizeOverheadBytes: 0,
      },
    );
    expect(result.fileSize).toBe(1_020);
  });

  it("rejects a remux whose duration is outside the selected title tolerance", async () => {
    const file = path.join(
      os.tmpdir(),
      `vx-remux-duration-drift-${Date.now()}.mkv`,
    );
    files.push(file);
    await fs.writeFile(file, Buffer.alloc(1_000));

    await expect(
      validateRemuxOutput(file, 100, async () => ({ duration: 96 }), {
        maximumDurationDrift: 0.02,
      }),
    ).rejects.toThrow("输出时长偏离所选标题");
  });

  it("rejects a readable output when selected streams or chapters are missing", async () => {
    const file = path.join(os.tmpdir(), `vx-remux-streams-${Date.now()}.mkv`);
    files.push(file);
    await fs.writeFile(file, Buffer.alloc(40));
    await expect(
      validateRemuxOutput(
        file,
        10,
        async () => ({
          duration: 10,
          streams: [{ codecType: "video" }, { codecType: "audio" }],
          chapters: [],
        }),
        {
          expectedStreamCounts: { video: 1, audio: 2, subtitle: 1 },
          expectedChapterCount: 1,
        },
      ),
    ).rejects.toThrow("输出流轨验证未通过");
  });

  it("rejects output with timestamps that move backwards", async () => {
    const file = path.join(
      os.tmpdir(),
      `vx-remux-timestamps-${Date.now()}.mkv`,
    );
    files.push(file);
    await fs.writeFile(file, Buffer.alloc(40));
    await expect(
      validateRemuxOutput(file, 10, async () => ({
        duration: 10,
        timestamps: [0, 1.25, 1.1, 2],
      })),
    ).rejects.toThrow("时间戳不单调");
  });
});
