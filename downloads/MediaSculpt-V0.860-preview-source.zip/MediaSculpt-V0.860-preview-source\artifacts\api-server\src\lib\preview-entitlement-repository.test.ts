import { DatabaseSync } from "node:sqlite";
import { describe, expect, it } from "vitest";
import { initializeSqliteDatabase } from "../../../../lib/db/src/sqlite-init";
import { createPreviewEntitlementRepository } from "./preview-entitlement-repository";

function createTestClient(): DatabaseSync {
  const client = new DatabaseSync(":memory:");
  initializeSqliteDatabase(client);
  return client;
}

describe("preview entitlement repository", () => {
  it("creates one entitlement row and preserves it across reads", async () => {
    const repository = createPreviewEntitlementRepository({
      client: createTestClient(),
      edition: "preview",
    });
    const first = await repository.getOrCreate(
      new Date("2026-09-14T00:00:00.000Z"),
    );
    const second = await repository.getOrCreate(
      new Date("2026-09-15T00:00:00.000Z"),
    );

    expect(first.installationId).toBeTruthy();
    expect(second.installationId).toBe(first.installationId);
    expect(second.successfulTaskCount).toBe(0);
    expect(second.aiCallCount).toBe(0);
    expect(second.lastSeenAt.toISOString()).toBe("2026-09-15T00:00:00.000Z");
  });

  it("charges the same job only once and keeps AI calls separate", async () => {
    const repository = createPreviewEntitlementRepository({
      client: createTestClient(),
      edition: "preview",
    });
    await repository.getOrCreate(new Date("2026-09-14T00:00:00.000Z"));

    await expect(
      repository.chargeTaskOnce({
        jobId: 7,
        taskKind: "compress",
        chargedAt: new Date("2026-09-14T01:00:00.000Z"),
      }),
    ).resolves.toEqual({
      charged: true,
      successfulTaskCount: 1,
    });
    await expect(
      repository.chargeTaskOnce({
        jobId: 7,
        taskKind: "compress",
        chargedAt: new Date("2026-09-14T02:00:00.000Z"),
      }),
    ).resolves.toEqual({
      charged: false,
      successfulTaskCount: 1,
    });
    await expect(
      repository.recordAiCall(new Date("2026-09-14T03:00:00.000Z")),
    ).resolves.toBe(1);
    await expect(
      repository.getStatus(new Date("2026-09-14T04:00:00.000Z")),
    ).resolves.toMatchObject({
      successfulTaskCount: 1,
      remainingTasks: 19,
      aiCallCount: 1,
    });
  });

  it("does not impose a task limit in development mode", async () => {
    const repository = createPreviewEntitlementRepository({
      client: createTestClient(),
      edition: "development",
    });
    await repository.getOrCreate(new Date("2026-09-14T00:00:00.000Z"));

    for (let jobId = 1; jobId <= 25; jobId += 1) {
      await expect(
        repository.chargeTaskOnce({
          jobId,
          taskKind: "compress",
          chargedAt: new Date("2026-09-14T01:00:00.000Z"),
        }),
      ).resolves.toMatchObject({ charged: true });
    }
    await expect(
      repository.getStatus(new Date("2030-01-01T00:00:00.000Z")),
    ).resolves.toMatchObject({
      edition: "development",
      taskLimit: null,
      remainingTasks: null,
      successfulTaskCount: 25,
      blockedReason: null,
    });
  });

  it("re-applies the packaged edition after the same database was used for development", async () => {
    const now = new Date("2026-09-14T00:00:00.000Z");
    const client = createTestClient();
    const development = createPreviewEntitlementRepository({
      client,
      edition: "development",
      installationIdFactory: () => "dev",
    });
    await development.getOrCreate(now);

    const preview = createPreviewEntitlementRepository({
      client,
      edition: "preview",
      installationIdFactory: () => "preview",
    });
    await expect(preview.getStatus(now)).resolves.toMatchObject({
      edition: "preview",
      taskLimit: 20,
      isActive: true,
    });
  });
});
