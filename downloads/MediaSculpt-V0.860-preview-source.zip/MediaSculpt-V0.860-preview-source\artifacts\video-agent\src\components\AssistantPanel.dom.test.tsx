// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { cleanup, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { I18nProvider } from "@/i18n";
import { zhCN } from "@/i18n/zh-CN";
import { AssistantPanel } from "./AssistantPanel";

beforeEach(() => {
  vi.stubGlobal(
    "fetch",
    vi.fn(() =>
      Promise.resolve({ ok: false, status: 404, json: async () => ({}) }),
    ),
  );
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

type PanelProps = Parameters<typeof AssistantPanel>[0];

function renderPanel(overrides: Partial<PanelProps> = {}) {
  return render(
    <I18nProvider lang="zh-CN">
      <AssistantPanel
        contextType="job"
        context={{}}
        aiAvailable
        {...overrides}
      />
    </I18nProvider>,
  );
}

describe("AssistantPanel layout", () => {
  it("renders the identity, smart-generate and task-processing regions in order with amber AI styling", () => {
    renderPanel();

    const toolbar = screen.getByTestId("assistant-toolbar");
    expect(screen.getByTestId("assistant-panel")).toBeInTheDocument();
    expect(screen.getByTestId("assistant-identity-editor")).toBeInTheDocument();

    const generateToggle = within(toolbar).getByTestId(
      "assistant-generate-toggle",
    );
    const processingLabel = within(toolbar).getByText(
      zhCN.assistant.processingField,
    );

    // Smart-generate sits above task-processing inside the right-hand column.
    expect(
      generateToggle.compareDocumentPosition(processingLabel) &
        Node.DOCUMENT_POSITION_FOLLOWING,
    ).toBeTruthy();
    expect(generateToggle).toHaveClass("text-amber-400/70");
    expect(screen.getByTestId("assistant-analyze")).toHaveClass(
      "border-amber-400/50",
    );
  });

  it("expands the smart-generate row to expose the three generation chips", async () => {
    const user = userEvent.setup();
    renderPanel({ aiAvailable: true });

    expect(
      screen.queryByTestId("assistant-generate-bar"),
    ).not.toBeInTheDocument();

    await user.click(screen.getByTestId("assistant-generate-toggle"));

    const bar = screen.getByTestId("assistant-generate-bar");
    expect(
      within(bar).getByText(zhCN.assistant.generateReadme),
    ).toBeInTheDocument();
    expect(
      within(bar).getByText(zhCN.assistant.generatePoster),
    ).toBeInTheDocument();
    const review = within(bar)
      .getByText(zhCN.assistant.generateReview)
      .closest("button");
    expect(review).toBeEnabled();
  });

  it("lists every task-processing step and keeps the confirm actions gated", () => {
    renderPanel();

    expect(
      screen.getByText(zhCN.assistant.processingField),
    ).toBeInTheDocument();
    const stepLabels = [
      zhCN.assistant.optionRemux,
      zhCN.assistant.optionSubtitleOnly,
      zhCN.assistant.optionCompress,
      zhCN.assistant.optionChapterPreview,
    ];
    for (const label of stepLabels) {
      expect(screen.getByText(label)).toBeInTheDocument();
    }

    expect(screen.getByTestId("assistant-confirm")).toBeDisabled();
    expect(screen.getByTestId("assistant-batch-confirm")).toBeDisabled();
  });

  it("enables the confirm control only once a confirm handler is provided", () => {
    const { rerender } = renderPanel();
    expect(screen.getByTestId("assistant-confirm")).toBeDisabled();

    const onConfirm = vi.fn();
    rerender(
      <I18nProvider lang="zh-CN">
        <AssistantPanel
          contextType="job"
          context={{}}
          aiAvailable
          onConfirm={onConfirm}
        />
      </I18nProvider>,
    );

    expect(screen.getByTestId("assistant-confirm")).toBeEnabled();
  });
});
