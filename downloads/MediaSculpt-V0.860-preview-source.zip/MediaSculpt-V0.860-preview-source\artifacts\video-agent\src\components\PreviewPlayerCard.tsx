import { forwardRef, type CSSProperties, type ReactNode } from "react";
import { Card, CardContent } from "@/components/ui/card";
import {
  PreviewPlayer,
  type PreviewPlayerHandle,
} from "@/components/PreviewPlayer";
import { cn } from "@/lib/utils";
import { previewLayoutMode } from "@/lib/preview-model";

export type PreviewPlayerCardProps = {
  src: string;
  metaUrl: string;
  rawUrl?: string;
  /** 转码预览基址（字幕烧录 / 非原生可播格式）；缺省回退到 src */
  transcodeUrl?: string;
  /** src 是原生可播流（mp4/webm 等）：seek 直接定位，不重建转码 */
  nativeSeek?: boolean;
  /** 分段预览模式（后端按 5s 片段转码 + Range 随机访问）；光盘直播流传 false。 */
  segmentMode?: boolean;
  /** 智能助手横栏展开：视频容器同样受窗口高度约束，防止溢出 */
  assistantOpen?: boolean;
  /** 未播放且侧栏收起时用于保持画面比例的原始宽高比 */
  aspectRatio?: string;
  /** 播放中：视频占满可用空间 */
  playing: boolean;
  /** 侧栏/详情展开：视频切换到中等高度并自适应填充 */
  expanded: boolean;
  /** 未播放且无侧栏时也占满可用空间（详情/助手全部收起时不留黑边） */
  fill?: boolean;
  onPlayingChange?: (playing: boolean) => void;
  /** 自定义字幕选择控件（替代播放器内置字幕按钮） */
  extraControls?: ReactNode;
  /** 叠加层（如字幕文本覆盖），渲染在视频之上 */
  overlay?: ReactNode;
  /** 字幕提示（文本字幕 cue）：由播放器按播放位置实时渲染 */
  subtitleCues?: Array<{ start: number; end: number; text: string }>;
  /** 卡片底部附加内容（如流轨信息条） */
  footer?: ReactNode;
  style?: CSSProperties;
  className?: string;
};

/**
 * 视频与字幕预览窗口：任务详情页与批量创建任务页共用同一套显示/适配逻辑，
 * 保证播放中占满空间、侧栏展开时自适应、默认不出现双滚动条。
 */
export const PreviewPlayerCard = forwardRef<
  PreviewPlayerHandle,
  PreviewPlayerCardProps
>(function PreviewPlayerCard(
  {
    src,
    metaUrl,
    rawUrl,
    transcodeUrl,
    nativeSeek,
    segmentMode,
    assistantOpen,
    aspectRatio,
    playing,
    expanded,
    fill,
    onPlayingChange,
    extraControls,
    overlay,
    subtitleCues,
    footer,
    style,
    className,
  },
  ref,
) {
  const layoutMode = previewLayoutMode({
    playing,
    expanded,
    assistantOpen: assistantOpen === true,
    fill: fill === true,
  });
  const fillSpace = layoutMode !== "ratio";
  return (
    <Card
      className={cn("overflow-hidden", fillSpace && "md:h-full", className)}
    >
      <CardContent
        className={cn(
          "space-y-2 p-3",
          fillSpace && "md:flex md:h-full md:min-h-0 md:flex-col",
        )}
      >
        <PreviewPlayer
          ref={ref}
          className={cn(
            "w-full min-h-0",
            layoutMode === "ratio"
              ? "h-[min(58vh,calc(100vh-19rem))] md:max-h-full"
              : "h-full max-h-full md:flex-1",
          )}
          style={{
            ...(layoutMode === "ratio" && aspectRatio ? { aspectRatio } : {}),
            ...style,
          }}
          src={src}
          metaUrl={metaUrl}
          rawUrl={rawUrl}
          transcodeUrl={transcodeUrl}
          nativeSeek={nativeSeek}
          segmentMode={segmentMode}
          extraControls={extraControls}
          overlay={overlay}
          subtitleCues={subtitleCues}
          onPlayingChange={onPlayingChange}
        />
      </CardContent>
      {footer}
    </Card>
  );
});
