import { describe, expect, it } from "vitest";
import {
  buildSelectedChapterMetadata,
  resolveRemuxChapterIds,
} from "./remux-chapters";

const chapters = [
  { id: 0, startSeconds: 0, endSeconds: 12.5, title: "开场" },
  { id: 1, startSeconds: 12.5, endSeconds: 40, title: "正文" },
  { id: 2, startSeconds: 40, endSeconds: 60, title: "结尾" },
];

describe("selected chapter metadata", () => {
  it("writes only selected chapters with millisecond timestamps", () => {
    const result = buildSelectedChapterMetadata(chapters, [1]);
    expect(result).toContain("START=12500");
    expect(result).toContain("title=正文");
    expect(result).not.toContain("开场");
  });

  it("numbers fallback chapter titles by source order, not one-based IDs", () => {
    const oneBased = [
      { id: 1, startSeconds: 0, endSeconds: 10, title: null },
      { id: 2, startSeconds: 10, endSeconds: 20, title: null },
    ];
    const result = buildSelectedChapterMetadata(oneBased, [1, 2]);
    expect(result).toContain("title=Chapter 1");
    expect(result).toContain("title=Chapter 2");
    expect(result).not.toContain("title=Chapter 3");
  });

  it("resolves all, range, and selected modes without silently inventing chapters", () => {
    expect(resolveRemuxChapterIds(chapters, { mode: "all" })).toEqual([
      0, 1, 2,
    ]);
    expect(
      resolveRemuxChapterIds(chapters, { mode: "range", start: 1, end: 2 }),
    ).toEqual([1, 2]);
    expect(
      resolveRemuxChapterIds(chapters, {
        mode: "selected",
        chapterIds: ["chapter:2", "chapter:0"],
      }),
    ).toEqual([2, 0]);
  });

  it("rejects malformed or missing selected chapter ids", () => {
    expect(() =>
      resolveRemuxChapterIds(chapters, { mode: "selected", chapterIds: ["2"] }),
    ).toThrow("无效");
    expect(() =>
      resolveRemuxChapterIds(chapters, {
        mode: "selected",
        chapterIds: ["chapter:9"],
      }),
    ).toThrow("不存在");
  });
});
