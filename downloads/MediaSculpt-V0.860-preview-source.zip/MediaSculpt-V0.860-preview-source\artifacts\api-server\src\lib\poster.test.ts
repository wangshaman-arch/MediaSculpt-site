import { describe, expect, it, vi } from "vitest";
import {
  bindPosterIdentityToUrl,
  expandPosterHostVariants,
  findPosterCandidatesByOnline,
  findPosterUrlsByOnline,
  orderPosterCandidates,
  posterCacheKey,
  posterIdentityMatches,
  posterSearchIdentityMatches,
  prioritizePosterCandidates,
} from "./poster";

describe("posterSearchIdentityMatches", () => {
  it("accepts only an exact title/year search result", () => {
    expect(
      posterSearchIdentityMatches({
        actualTitle: "The Making of King Arthur",
        actualYear: 2010,
        expectedTitleEn: "The Making of King Arthur",
        expectedYear: 2010,
      }),
    ).toBe(true);
    expect(
      posterSearchIdentityMatches({
        actualTitle: "King Arthur",
        actualYear: 2004,
        expectedTitleEn: "The Making of King Arthur",
        expectedYear: 2010,
      }),
    ).toBe(false);
  });

  it("rejects a title-only image source when no identity fields are available", () => {
    expect(
      posterSearchIdentityMatches({
        actualTitle: "King Arthur",
        actualYear: 2004,
      }),
    ).toBe(false);
  });

  // Measured against adversarial pairs: the gate must never attach a poster for
  // a different work. These all rejected before and must keep rejecting.
  it("still rejects every wrong-work candidate", () => {
    const reject = (q: string, y: number, c: string, cy: number) =>
      posterSearchIdentityMatches({
        actualTitle: c,
        actualYear: cy,
        expectedTitleEn: q,
        expectedTitle: q,
        expectedYear: y,
      });
    expect(
      reject(
        "A Beautiful Mind",
        2001,
        "A Beautiful Mind: Deleted Scenes",
        2002,
      ),
    ).toBe(false);
    expect(
      reject("A Better Tomorrow", 1986, "A Better Tomorrow II", 1987),
    ).toBe(false);
    expect(reject("Hamlet", 1996, "Hamlet", 2000)).toBe(false);
    expect(reject("Crash", 2004, "Crash", 1996)).toBe(false);
    expect(reject("The Key", 1983, "The Key", 2011)).toBe(false);
    expect(reject("Ocean's 11", 2001, "Ocean's 12", 2004)).toBe(false);
  });

  // Regression: accents and spelled-out numerals are presentation differences,
  // not identity differences. Rejecting them silently dropped correct posters.
  it("accepts the same work written with accents or spelled-out numerals", () => {
    const accept = (q: string, y: number, c: string, cy: number) =>
      posterSearchIdentityMatches({
        actualTitle: c,
        actualYear: cy,
        expectedTitleEn: q,
        expectedTitle: q,
        expectedYear: y,
      });
    expect(accept("La Bayadere", 1980, "La Bayadère", 1980)).toBe(true);
    expect(accept("Ocean's 11", 2001, "Oceans Eleven", 2001)).toBe(true);
    expect(accept("A zori zdes tikhie", 1972, "A zori zdes tikhie", 1972)).toBe(
      true,
    );
    expect(accept("Amelie", 2001, "Amélie", 2001)).toBe(true);
  });
});

describe("posterIdentityMatches", () => {
  it("rejects a poster without matching provenance", () => {
    expect(
      posterIdentityMatches(
        {
          imdbId: "tt36988628",
          titleEn: "In the Opinion of the Censor",
          year: 2025,
        },
        {
          imdbId: "tt0000001",
          titleEn: "In the Opinion of the Censor",
          year: 2025,
        },
      ),
    ).toBe(false);
    expect(
      posterIdentityMatches(
        {
          imdbId: "tt36988628",
          titleEn: "In the Opinion of the Censor",
          year: 2025,
        },
        {
          imdbId: "tt36988628",
          titleEn: "In the Opinion of the Censor",
          year: 2025,
        },
      ),
    ).toBe(true);
    expect(
      posterIdentityMatches(
        { titleEn: "A Different Film", year: 2025 },
        { titleEn: "In the Opinion of the Censor", year: 2025 },
      ),
    ).toBe(false);
  });
});

describe("bindPosterIdentityToUrl", () => {
  it("adds identity parameters without breaking a remote image URL", () => {
    expect(
      bindPosterIdentityToUrl("https://m.media-amazon.com/images/poster.jpg", {
        imdbId: "tt1234567",
        titleEn: "Example Film",
        year: 2020,
      }),
    ).toBe(
      "https://m.media-amazon.com/images/poster.jpg?imdbId=tt1234567&titleEn=Example+Film&year=2020",
    );
  });
});

describe("posterCacheKey", () => {
  it("isolates cached posters by verified IMDb identity", () => {
    expect(
      posterCacheKey(
        "Simply Anne Sophie",
        "Simply Anne Sophie",
        2007,
        "tt1234567",
      ),
    ).toBe("id:tt1234567");
    expect(
      posterCacheKey(
        "Simply Anne Sophie",
        "Simply Anne Sophie",
        2007,
        "tt7654321",
      ),
    ).not.toBe(
      posterCacheKey(
        "Simply Anne Sophie",
        "Simply Anne Sophie",
        2007,
        "tt1234567",
      ),
    );
  });
});

describe("orderPosterCandidates", () => {
  it("keeps IMDb/Amazon image URLs as a lower-priority fallback", () => {
    expect(
      orderPosterCandidates([
        "https://m.media-amazon.com/images/M/poster.jpg",
        "https://img9.doubanio.com/view/photo/poster.jpg",
        "https://m.media-amazon.com/images/M/poster.jpg",
      ]),
    ).toEqual([
      "https://img9.doubanio.com/view/photo/poster.jpg",
      "https://m.media-amazon.com/images/M/poster.jpg",
    ]);
  });
});

describe("prioritizePosterCandidates", () => {
  it("keeps the identity-confirmed poster ahead of search fallbacks", () => {
    expect(
      prioritizePosterCandidates(
        [
          "https://img9.doubanio.com/wrong.jpg",
          "https://m.media-amazon.com/images/M/confirmed.jpg",
        ],
        ["https://m.media-amazon.com/images/M/confirmed.jpg"],
      ),
    ).toEqual([
      "https://m.media-amazon.com/images/M/confirmed.jpg",
      "https://img9.doubanio.com/wrong.jpg",
    ]);
  });
});

describe("findPosterUrlsByOnline", () => {
  it("keeps title/year fallback searches when a local IMDb id is present", async () => {
    const originalFetch = globalThis.fetch;
    const calls: string[] = [];
    vi.stubGlobal("fetch", (input: string | URL) => {
      const url = String(input);
      calls.push(url);
      if (url.includes("movie.douban.com/j/subject_suggest")) {
        return Promise.resolve(
          new Response(
            JSON.stringify([
              {
                img: "https://img9.doubanio.com/view/photo/poster.jpg",
                title: "The Making of King Arthur",
                year: "2010",
              },
            ]),
            { status: 200, headers: { "content-type": "application/json" } },
          ),
        );
      }
      return Promise.resolve(
        new Response(JSON.stringify({ results: [] }), { status: 200 }),
      );
    });
    try {
      const urls = await findPosterUrlsByOnline({
        titleEn: "The Making of King Arthur",
        year: 2010,
        imdbId: "tt1234567",
      });
      expect(urls).toContain("https://img9.doubanio.com/view/photo/poster.jpg");
      expect(calls.some((url) => url.includes("subject_suggest"))).toBe(true);
    } finally {
      vi.stubGlobal("fetch", originalFetch);
    }
  });

  it("uses the configured proxy-aware fetch path for keyed providers", async () => {
    const originalFetch = globalThis.fetch;
    const calls: string[] = [];
    vi.stubGlobal("fetch", (input: string | URL) => {
      calls.push(String(input));
      return Promise.resolve(
        new Response(JSON.stringify({ results: [], Response: "False" }), {
          status: 200,
        }),
      );
    });
    try {
      await findPosterUrlsByOnline({
        titleEn: "Example Film",
        year: 2020,
        tmdbApiKey: "tmdb-test",
        omdbApiKey: "omdb-test",
        proxyUrl: null,
      });
      expect(calls.some((url) => url.includes("api.themoviedb.org"))).toBe(
        true,
      );
      expect(calls.some((url) => url.includes("omdbapi.com"))).toBe(true);
    } finally {
      vi.stubGlobal("fetch", originalFetch);
    }
  });

  it("uses an IMDb id to retrieve a directly mapped TMDb poster", async () => {
    const originalFetch = globalThis.fetch;
    vi.stubGlobal("fetch", (input: string | URL) => {
      const url = String(input);
      if (url.includes("/find/tt1234567")) {
        return Promise.resolve(
          new Response(
            JSON.stringify({ movie_results: [{ poster_path: "/mapped.jpg" }] }),
            { status: 200 },
          ),
        );
      }
      return Promise.resolve(new Response(JSON.stringify([]), { status: 200 }));
    });
    try {
      const candidates = await findPosterCandidatesByOnline({
        titleEn: "Example Film",
        imdbId: "tt1234567",
        tmdbApiKey: "tmdb-test",
      });
      expect(candidates).toContainEqual({
        url: "https://image.tmdb.org/t/p/original/mapped.jpg",
        source: "tmdb",
        confidence: "high",
        matchedBy: "imdb",
      });
    } finally {
      vi.stubGlobal("fetch", originalFetch);
    }
  });

  it("uses the identity-bound IMDb suggestion poster without requiring an API key", async () => {
    const originalFetch = globalThis.fetch;
    vi.stubGlobal("fetch", (input: string | URL) => {
      const url = String(input);
      if (url.includes("v3.sg.media-imdb.com/suggestion")) {
        return Promise.resolve(
          new Response(
            JSON.stringify({
              d: [
                {
                  id: "tt1234567",
                  l: "Example Film",
                  y: 2020,
                  i: {
                    imageUrl: "https://m.media-amazon.com/images/example.jpg",
                  },
                },
              ],
            }),
            { status: 200, headers: { "content-type": "application/json" } },
          ),
        );
      }
      return Promise.resolve(new Response(JSON.stringify([]), { status: 200 }));
    });
    try {
      const candidates = await findPosterCandidatesByOnline({
        titleEn: "Example Film",
        year: 2020,
        imdbId: "tt1234567",
      });
      expect(candidates).toContainEqual({
        url: "https://m.media-amazon.com/images/example.jpg",
        source: "imdb",
        confidence: "high",
        matchedBy: "imdb",
      });
    } finally {
      vi.stubGlobal("fetch", originalFetch);
    }
  });
});

describe("posterIdentityMatches with a sidecar written before the id resolved", () => {
  it("corroborates by title instead of hiding a matching poster", () => {
    expect(
      posterIdentityMatches(
        { titleEn: "Blow-Up", year: 1966 },
        { imdbId: "tt0060176", titleEn: "Blow-Up", year: 1966 },
      ),
    ).toBe(true);
    expect(
      posterIdentityMatches(
        { imdbId: null, titleEn: "Blow-Up", year: 1966 },
        { imdbId: "tt0060176", titleEn: "Blow-Up", year: 1966 },
      ),
    ).toBe(true);
  });

  it("still refuses a contradicting or uncorroborated poster", () => {
    expect(
      posterIdentityMatches(
        { titleEn: "A Different Film", year: 1966 },
        { imdbId: "tt0060176", titleEn: "Blow-Up", year: 1966 },
      ),
    ).toBe(false);
    expect(
      posterIdentityMatches(
        { imdbId: "tt9999999", titleEn: "Blow-Up", year: 1966 },
        { imdbId: "tt0060176", titleEn: "Blow-Up", year: 1966 },
      ),
    ).toBe(false);
  });
});

describe("expandPosterHostVariants", () => {
  const url =
    "https://m.media-amazon.com/images/M/ABC@._V1_.jpg?imdbId=tt0113720&titleEn=All.Things.Fair&year=1995";

  it("offers the equivalent Amazon hosts for the same asset", () => {
    const variants = expandPosterHostVariants(url);
    expect(variants[0]).toBe(url);
    expect(variants).toContain(
      "https://images-na.ssl-images-amazon.com/images/M/ABC@._V1_.jpg?imdbId=tt0113720&titleEn=All.Things.Fair&year=1995",
    );
    expect(
      variants.some((variant) =>
        variant.startsWith("https://ia.media-imdb.com/images/M/"),
      ),
    ).toBe(true);
    expect(variants.length).toBe(4);
  });

  it("keeps the identity parameters on every variant so the poster stays bound", () => {
    for (const variant of expandPosterHostVariants(url)) {
      expect(variant).toContain("imdbId=tt0113720");
      expect(variant).toContain("year=1995");
    }
  });

  it("leaves non-Amazon hosts untouched", () => {
    const douban =
      "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p548426395.jpg";
    expect(expandPosterHostVariants(douban)).toEqual([douban]);
    expect(expandPosterHostVariants("not a url")).toEqual(["not a url"]);
  });
});
