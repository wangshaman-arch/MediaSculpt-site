import { describe, expect, it } from "vitest";
import type {
  DiscAnalysisStream,
  UnifiedDiscTitle,
} from "../lib/disc-analysis";
import type { TaskSnapshotV1 } from "../lib/task-snapshot";
import type { HandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { buildCompressionArgsForJob } from "./compression-pipeline";

const config = {
  encoder: "x264_10bit",
  crf: 19,
  outputFormat: "mkv",
  audioCopy: true,
  encoderPreset: "slow",
  encoderTune: "grain",
  encoderProfile: "high10",
  encoderLevel: "3.1",
  frameRate: "same",
  outputResolution: "source",
};

const streams: DiscAnalysisStream[] = [
  {
    index: 0,
    codecType: "video",
    codecName: "mpeg2video",
    language: null,
    title: null,
    handbrakeTrackNumber: null,
  },
  {
    index: 1,
    codecType: "audio",
    codecName: "ac3",
    language: "en",
    title: "English",
    handbrakeTrackNumber: 2,
  },
  {
    index: 2,
    codecType: "subtitle",
    codecName: "dvd_subtitle",
    language: "en",
    title: "English",
    handbrakeTrackNumber: 3,
  },
];

const title: UnifiedDiscTitle = {
  titleId: "handbrake:7",
  titleIndex: 0,
  sourcePath: "D:\\DVD",
  displayName: "Movie",
  durationSeconds: 5_400,
  chapterCount: 2,
  chapters: [
    { id: 1, startSeconds: 0, endSeconds: 2_700, title: "Part 1" },
    { id: 2, startSeconds: 2_700, endSeconds: 5_400, title: "Part 2" },
  ],
  videoTracks: [streams[0]],
  audioTracks: [streams[1]],
  subtitleTracks: [streams[2]],
  estimatedSize: null,
  streams,
  toolMappings: {
    handbrakeTitleNumber: 7,
    makemkvTitleIndex: null,
    playlistId: null,
    dvdVtsNumber: 7,
  },
  mappingStatus: "not-required",
  verificationStatus: "verified",
};

const snapshot: TaskSnapshotV1 = {
  snapshotVersion: 1,
  analysisId: "disc-1",
  sourcePath: "D:\\DVD",
  sourceFingerprint: "dvd-1",
  sourceType: "dvd",
  selectedTitleId: "handbrake:7",
  outputMode: "compress",
  compressionSourceStrategy: "direct-disc",
  toolSelections: {
    handbrakeTitleNumber: 7,
    makemkvTitleIndex: null,
    playlistId: null,
    dvdVtsNumber: 7,
    remuxExportCandidateIndex: null,
  },
  streamSelection: {
    videoTrackIds: ["stream:0"],
    audioTrackIds: ["stream:1"],
    subtitleTrackIds: ["stream:2"],
  },
  chapterSelection: { mode: "all", start: null, end: null, chapterIds: [] },
  remux: { container: "mkv" },
  compression: {
    encoder: "x264_10bit",
    crf: 19,
    resolution: "source",
    preset: "slow",
    audioCopy: true,
    frameRate: "same",
    outputFormat: "mkv",
    deinterlace: false,
  },
  whisper: { inputSource: "original-title", language: "zh", model: "medium" },
  output: {
    directory: "D:\\Output",
    fileName: "Movie.mkv",
    format: "mkv",
    subtitleDirectory: null,
  },
  toolVersions: {
    handbrake: null,
    makemkv: null,
    ffmpeg: null,
    whisper: null,
    configVersion: "config-1",
  },
  createdAt: "2026-09-16T00:00:00.000Z",
};

describe("compression execution adapter", () => {
  it("uses the verified manifest title and tracks for a direct disc compression", () => {
    const result = buildCompressionArgsForJob({
      snapshot,
      title,
      inputPath: "D:\\DVD",
      outputPath: "D:\\Output\\Movie.mkv",
      config,
      selectionPlan: null,
      deinterlace: false,
      useManifest: true,
    });

    expect(result.usedManifest).toBe(true);
    expect(result.selectionArgs).toEqual(
      expect.arrayContaining([
        "--title",
        "7",
        "--audio",
        "2",
        "--subtitle",
        "3",
        "--chapters",
        "1-2",
      ]),
    );
  });

  it("keeps the legacy selection path when the verified title is unavailable", () => {
    const legacyPlan: HandBrakeSelectionPlan = {
      version: 1,
      video: [0],
      audio: [],
      subtitle: [],
      chapters: [],
      handbrake: { titleNumber: 1 },
    };
    const result = buildCompressionArgsForJob({
      snapshot,
      title: null,
      inputPath: "D:\\DVD",
      outputPath: "D:\\Output\\Movie.mkv",
      config,
      selectionPlan: legacyPlan,
      deinterlace: false,
      useManifest: false,
    });

    expect(result.usedManifest).toBe(false);
    expect(result.args).toEqual(expect.arrayContaining(["--title", "1"]));
  });
});
