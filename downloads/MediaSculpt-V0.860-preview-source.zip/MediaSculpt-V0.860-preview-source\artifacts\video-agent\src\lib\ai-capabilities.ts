export type AiCapabilityConfig = {
  aiProvider?: string | null;
  libreTranslateUrl?: string | null;
  openaiApiKey?: string | null;
  deepseekApiKey?: string | null;
  siliconflowApiKey?: string | null;
  zhipuApiKey?: string | null;
  moonshotApiKey?: string | null;
  qwenApiKey?: string | null;
  groqApiKey?: string | null;
  geminiApiKey?: string | null;
  /** Backend-computed: a usable AI key exists (Settings-configured or env-injected). */
  aiAvailable?: boolean;
};

const API_KEY_BY_PROVIDER = {
  openai: "openaiApiKey",
  custom: "openaiApiKey",
  deepseek: "deepseekApiKey",
  siliconflow: "siliconflowApiKey",
  zhipu: "zhipuApiKey",
  moonshot: "moonshotApiKey",
  qwen: "qwenApiKey",
  groq: "groqApiKey",
  gemini: "geminiApiKey",
} as const satisfies Record<string, keyof AiCapabilityConfig>;

/** True only when the currently selected cloud LLM provider has its own key. */
export function hasSelectedCloudLlmKey(
  config: AiCapabilityConfig | null | undefined,
): boolean {
  if (!config) return false;
  const provider = config.aiProvider?.trim() || "deepseek";
  if (provider === "libretranslate") return false;
  // The backend also accepts an env-injected fallback key; trust its
  // availability flag so cloud features stay enabled even when no key was
  // saved through Settings.
  if (config.aiAvailable) return true;
  const keyField =
    API_KEY_BY_PROVIDER[provider as keyof typeof API_KEY_BY_PROVIDER] ??
    "openaiApiKey";
  return Boolean(config[keyField]?.trim());
}

/** Subtitle translation can still run without a cloud key through LibreTranslate. */
export function hasSubtitleTranslationProvider(
  config: AiCapabilityConfig | null | undefined,
): boolean {
  if (!config) return false;
  return (
    config.aiProvider?.trim() === "libretranslate" ||
    hasSelectedCloudLlmKey(config)
  );
}
