export type DiscPreviewPage = {
  page: number;
  pageCount: number;
  visible: string[];
  canPrev: boolean;
  canNext: boolean;
};

/**
 * Previews are paged two-per-view. The dialog clamps the requested page so a
 * shrinking list can never point past the end.
 */
export function discPreviewPagination(
  previews: string[],
  requestedPage: number,
): DiscPreviewPage {
  const pageCount = Math.max(1, Math.ceil(previews.length / 2));
  const page = Math.min(requestedPage, pageCount - 1);
  return {
    page,
    pageCount,
    visible: previews.slice(page * 2, page * 2 + 2),
    canPrev: page > 0,
    canNext: page < pageCount - 1,
  };
}
