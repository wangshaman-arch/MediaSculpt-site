import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import {
  AssistantFactsTable,
  type AssistantFactRow,
} from "./AssistantFactsTable";

type Translate = (
  path: string,
  params?: Record<string, string | number>,
) => string;

export function AssistantPosterDialogs({
  t,
  posterOpen,
  onPosterOpenChange,
  effectivePoster,
  readingOpen,
  onReadingOpenChange,
  factsRows,
  analysisBody,
  persistedOverview,
}: {
  t: Translate;
  posterOpen: boolean;
  onPosterOpenChange: (open: boolean) => void;
  effectivePoster: string | null;
  readingOpen: boolean;
  onReadingOpenChange: (open: boolean) => void;
  factsRows: ReadonlyArray<AssistantFactRow>;
  analysisBody: string;
  persistedOverview: string;
}) {
  return (
    <>
      <Dialog open={posterOpen} onOpenChange={onPosterOpenChange}>
        <DialogContent className="max-w-[min(92vw,42rem)] border-primary/30 bg-background/95 p-4">
          <DialogTitle className="sr-only">
            {t("assistant.posterPreview")}
          </DialogTitle>
          {effectivePoster && (
            <img
              src={effectivePoster}
              alt={t("assistant.posterPreview")}
              className="mx-auto max-h-[82vh] w-auto rounded object-contain"
            />
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={readingOpen} onOpenChange={onReadingOpenChange}>
        <DialogContent className="flex h-[85vh] w-[min(1100px,92vw)] max-w-none flex-col gap-3 border-amber-400/25 bg-background/95 p-4">
          <DialogTitle className="sr-only">
            {t("assistant.readingTitle")}
          </DialogTitle>
          <div className="flex min-h-0 flex-1 gap-4">
            <div className="hidden w-72 shrink-0 flex-col gap-3 overflow-y-auto overscroll-contain pr-1 text-sm sm:flex">
              <AssistantFactsTable rows={factsRows} />
            </div>
            <div
              className="min-h-0 min-w-0 flex-1 overflow-y-auto overscroll-contain pr-2 text-sm leading-7 text-muted-foreground"
              data-testid="assistant-reading-overview"
            >
              <div className="max-w-[72ch] whitespace-pre-wrap">
                {analysisBody || persistedOverview}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
