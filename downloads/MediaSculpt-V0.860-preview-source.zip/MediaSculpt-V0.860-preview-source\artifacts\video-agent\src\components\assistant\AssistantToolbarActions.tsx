import type { ReactNode, RefObject } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Check, ChevronDown, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

type Translate = (
  path: string,
  params?: Record<string, string | number>,
) => string;

export function AssistantToolbarActions({
  t,
  promptPlacement,
  promptOpen,
  aiAvailable,
  prompt,
  promptAttention,
  onPromptChange,
  onPromptToggle,
  analysisButtonPortalTarget,
  analysisButton,
  confirmed,
  onConfirm,
  batchMode,
  batchCount,
  onBatchConfirm,
  promptInputRef,
  promptTextareaRef,
}: {
  t: Translate;
  promptPlacement: "toolbar" | "external";
  promptOpen: boolean;
  aiAvailable: boolean;
  prompt: string;
  promptAttention: boolean;
  onPromptChange?: (value: string) => void;
  onPromptToggle?: (open: boolean) => void;
  analysisButtonPortalTarget: HTMLElement | null;
  analysisButton: ReactNode;
  confirmed: boolean;
  onConfirm?: () => void;
  batchMode: boolean;
  batchCount: number;
  onBatchConfirm?: () => void;
  promptInputRef: RefObject<HTMLInputElement | null>;
  promptTextareaRef: RefObject<HTMLTextAreaElement | null>;
}) {
  return (
    <>
      <div
        className={cn(
          "grid min-w-[12rem] shrink-0 grid-cols-2 items-center justify-end gap-1",
          "w-full min-w-0 grid-cols-2",
        )}
      >
        {promptPlacement === "toolbar" &&
          (promptOpen ? (
            <div className="col-span-2 flex items-center gap-1">
              <Input
                autoFocus
                ref={promptInputRef}
                disabled={!aiAvailable}
                value={prompt}
                onChange={(e) => onPromptChange?.(e.currentTarget.value)}
                placeholder={t("assistant.placeholder")}
                className={cn(
                  "h-7 min-w-0 flex-1 text-xs disabled:opacity-50",
                  promptAttention &&
                    "border-amber-400 ring-2 ring-amber-400/40",
                )}
              />
              <Button
                type="button"
                size="icon"
                variant="ghost"
                className="h-7 w-7 shrink-0"
                onClick={() => onPromptToggle?.(false)}
                aria-label={t("assistant.collapsePrompt")}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <Button
              type="button"
              size="sm"
              variant="outline"
              disabled={!aiAvailable}
              className="h-7 shrink-0 border-amber-400/40 px-2 text-[11px] text-amber-400 hover:bg-amber-400/10 disabled:border-border/40 disabled:text-muted-foreground/40"
              onClick={() => onPromptToggle?.(true)}
              title={aiAvailable ? undefined : t("assistant.aiNeedsKey")}
            >
              <ChevronDown className="mr-1 h-3.5 w-3.5" />
              {t("assistant.promptLabel")}
            </Button>
          ))}
        {!analysisButtonPortalTarget && analysisButton}
        <Button
          type="button"
          size="sm"
          variant={confirmed ? "default" : "outline"}
          onClick={onConfirm}
          disabled={!onConfirm}
          className={cn(
            "h-7 w-full min-w-0 justify-center px-1.5 text-[11px]",
            !confirmed && "text-primary hover:bg-primary/10",
          )}
          data-testid="assistant-confirm"
        >
          <Check className="mr-1 h-3.5 w-3.5" />
          {t(batchMode ? "assistant.functionConfirm" : "assistant.confirm")}
        </Button>
        <Button
          type="button"
          size="sm"
          variant="outline"
          onClick={onBatchConfirm}
          disabled={!batchMode || batchCount === 0 || !onBatchConfirm}
          title={
            batchMode
              ? t("assistant.batchConfirm", { count: batchCount })
              : t("assistant.batchConfirmDisabledHint")
          }
          className={cn(
            "h-7 w-full min-w-0 justify-center px-1.5 text-[11px]",
            batchMode && batchCount > 0 && onBatchConfirm
              ? "border-amber-400/40 text-amber-400 hover:bg-amber-400/10"
              : "border-border/40 text-muted-foreground/50",
          )}
          data-testid="assistant-batch-confirm"
        >
          <Check className="mr-1 h-3.5 w-3.5" />
          {t("assistant.taskQueue")}
        </Button>
      </div>
      {promptPlacement === "external" && promptOpen && (
        <div className="mt-2" data-testid="job-prompt-section">
          <textarea
            ref={promptTextareaRef}
            autoFocus
            disabled={!aiAvailable}
            value={prompt}
            onChange={(event) => onPromptChange?.(event.currentTarget.value)}
            placeholder={t("assistant.placeholder")}
            rows={3}
            className={cn(
              "w-full rounded-md border bg-background px-2 py-1.5 text-xs outline-none focus:border-primary/60 disabled:cursor-not-allowed disabled:opacity-50",
              promptAttention && "border-amber-400 ring-2 ring-amber-400/40",
            )}
          />
        </div>
      )}
    </>
  );
}
