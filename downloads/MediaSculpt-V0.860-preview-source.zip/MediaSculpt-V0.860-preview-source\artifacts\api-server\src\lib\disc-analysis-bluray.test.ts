import { describe, expect, it } from "vitest";
import { buildBlurayTitleDisplayName } from "./disc-analysis-bluray";
import type { UnifiedDiscTitle } from "./disc-analysis";
import * as blurayAnalysis from "./disc-analysis-bluray";

function title(overrides: Partial<UnifiedDiscTitle>): UnifiedDiscTitle {
  return {
    titleId: "mpls:00009",
    titleIndex: 0,
    sourcePath: "D:\\Disc\\BDMV\\PLAYLIST\\00009.mpls",
    titleKind: "m2ts",
    displayName: "Playlist 00009",
    durationSeconds: 5159.72,
    chapterCount: 8,
    chapters: [],
    estimatedSize: 42_000_000_000,
    streams: [],
    videoTracks: [],
    audioTracks: [],
    subtitleTracks: [],
    toolMappings: {
      handbrakeTitleNumber: null,
      makemkvTitleIndex: null,
      dvdVtsNumber: null,
      playlistId: "00009",
    },
    mappingStatus: "not-required",
    ...overrides,
  };
}

describe("Blu-ray title display names", () => {
  it("shows the playlist identifier for parsed MPLS titles", () => {
    expect(
      buildBlurayTitleDisplayName({
        kind: "playlist",
        index: 0,
        playlistId: "01002",
      }),
    ).toBe("Playlist 01002");
  });

  it("keeps HandBrake title and its mapped playlist visible", () => {
    expect(
      buildBlurayTitleDisplayName({
        kind: "handbrake",
        index: 0,
        handbrakeTitleNumber: 10,
        playlistId: "01002",
      }),
    ).toBe("HandBrake Title 10 · Playlist 01002");
  });

  it("shows the physical M2TS identifier for fallback titles", () => {
    expect(
      buildBlurayTitleDisplayName({
        kind: "stream",
        index: 0,
        streamFileName: "00001.m2ts",
      }),
    ).toBe("M2TS 00001");
  });

  it("merges playlist and HandBrake scans into one executable final title", () => {
    const merge = (
      blurayAnalysis as typeof blurayAnalysis & {
        mergeBluRayToolTitles?: (
          playlists: UnifiedDiscTitle[],
          handbrake: UnifiedDiscTitle[],
        ) => UnifiedDiscTitle[];
      }
    ).mergeBluRayToolTitles;
    expect(typeof merge).toBe("function");

    const previewSegments = [
      {
        sourcePath: "D:\\Disc\\BDMV\\STREAM\\00009.m2ts",
        startSeconds: 0,
        endSeconds: 3600,
      },
    ];
    const playlist = title({ previewSegments });
    const handbrake = title({
      titleId: "handbrake:3",
      titleIndex: 1,
      sourcePath: "D:\\Disc",
      titleKind: "handbrake",
      displayName: "HandBrake Title 3 · Playlist 00009",
      chapterCount: 7,
      estimatedSize: null,
      toolMappings: {
        handbrakeTitleNumber: 3,
        makemkvTitleIndex: null,
        dvdVtsNumber: null,
        playlistId: "00009",
      },
    });

    const result = merge?.([playlist], [handbrake]) ?? [];
    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({
      titleId: "mpls:00009",
      displayName: "Playlist 00009",
      titleKind: "handbrake",
      toolMappings: {
        playlistId: "00009",
        handbrakeTitleNumber: 3,
      },
      previewSegments,
    });
  });
});
