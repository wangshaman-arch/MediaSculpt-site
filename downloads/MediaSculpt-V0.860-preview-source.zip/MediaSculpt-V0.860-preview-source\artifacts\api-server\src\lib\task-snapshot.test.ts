import { afterEach, describe, expect, it } from "vitest";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { eq } from "drizzle-orm";
import { openSqliteDatabase } from "../../../../lib/db/src/sqlite";
import { sqliteSchema } from "../../../../lib/db/src/sqlite-schema";
import {
  TaskSnapshotError,
  createTaskSnapshotV1,
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  parseTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  type TaskSnapshotV1,
} from "./task-snapshot";
import type { DiscAnalysisResult } from "./disc-analysis";

function analysisFixture(): DiscAnalysisResult {
  return {
    analysisId: "disc-a1",
    sourcePath: "D:\\影视 库\\示例 DVD",
    sourceFingerprint: "source-fingerprint-a1",
    mediaType: "dvd",
    createdAt: "2026-08-02T00:00:00.000Z",
    diagnosticLogPath: null,
    diagnostics: [],
    warnings: [],
    exportCandidates: [
      {
        makemkvTitleIndex: 3,
        name: "Main title",
        sourcePath: "D:\\影视 库\\示例 DVD",
        estimatedSize: 4_000_000_000,
        durationSeconds: 7200,
        mappedTitleId: "handbrake:7",
        mappingStatus: "not-required",
      },
    ],
    titles: [
      {
        titleId: "handbrake:7",
        titleIndex: 0,
        sourcePath: "D:\\影视 库\\示例 DVD",
        displayName: "Title 7",
        durationSeconds: 7200,
        chapterCount: 2,
        chapters: [
          { id: 0, startSeconds: 0, endSeconds: 3600, title: "第一章" },
          { id: 1, startSeconds: 3600, endSeconds: 7200, title: "第二章" },
        ],
        estimatedSize: 4_000_000_000,
        streams: [
          {
            index: 0,
            codecType: "video",
            codecName: "mpeg2video",
            language: null,
            title: null,
            handbrakeTrackNumber: 1,
          },
          {
            index: 1,
            codecType: "audio",
            codecName: "ac3",
            language: "zh",
            title: "普通话",
            handbrakeTrackNumber: 2,
          },
          {
            index: 2,
            codecType: "subtitle",
            codecName: "dvd_subtitle",
            language: "en",
            title: "English",
            handbrakeTrackNumber: 3,
          },
        ],
        videoTracks: [
          {
            index: 0,
            codecType: "video",
            codecName: "mpeg2video",
            language: null,
            title: null,
            handbrakeTrackNumber: 1,
          },
        ],
        audioTracks: [
          {
            index: 1,
            codecType: "audio",
            codecName: "ac3",
            language: "zh",
            title: "普通话",
            handbrakeTrackNumber: 2,
          },
        ],
        subtitleTracks: [
          {
            index: 2,
            codecType: "subtitle",
            codecName: "dvd_subtitle",
            language: "en",
            title: "English",
            handbrakeTrackNumber: 3,
          },
        ],
        toolMappings: {
          handbrakeTitleNumber: 7,
          makemkvTitleIndex: 3,
          dvdVtsNumber: 1,
        },
        mappingStatus: "not-required",
        verificationStatus: "verified",
      },
    ],
  };
}

function settingsFixture() {
  return {
    encoder: "x265_10bit",
    crf: 19,
    outputResolution: "1080p",
    encoderPreset: "slow",
    encoderTune: "grain",
    encoderProfile: "high10",
    encoderLevel: "3.1",
    audioCopy: true,
    outputDirectory: "D:\\输出 目录",
    remuxOutputDirectory: "__source__",
    subtitleDirectory: "__source__",
    whisperModel: "medium",
    subtitleLanguage: "zh",
    outputFormat: "mkv",
  };
}

function snapshotInput(overrides: Record<string, unknown> = {}) {
  return {
    analysis: analysisFixture(),
    analysisId: "disc-a1",
    selectedTitleId: "handbrake:7",
    outputMode: "compress" as const,
    streamSelection: {
      videoTrackIds: ["stream:0"],
      audioTrackIds: ["stream:1"],
      subtitleTrackIds: ["stream:2"],
    },
    chapterSelection: { mode: "range" as const, start: 1, end: 2 },
    settings: settingsFixture(),
    remux: { container: "mkv" as const },
    whisper: { inputSource: "original-title" as const, language: "zh" },
    output: {
      directory: "D:\\输出 目录",
      fileName: "示例 DVD.DVD.x265.1080p.mkv",
    },
    toolVersions: {
      handbrake: "1.9.2",
      makemkv: "1.17.8",
      ffmpeg: "7.1",
      whisper: "20250625",
    },
    createdAt: "2026-08-02T00:00:00.000Z",
    ...overrides,
  };
}

describe("versioned immutable task snapshot", () => {
  let tempDirectory: string | undefined;
  let close: (() => void) | undefined;

  afterEach(() => {
    close?.();
    close = undefined;
    if (tempDirectory)
      fs.rmSync(tempDirectory, { recursive: true, force: true });
    tempDirectory = undefined;
  });

  it("creates a complete V1 snapshot from analysisId plus selectedTitleId without retaining mutable settings", () => {
    const settings = settingsFixture();
    const analysis = analysisFixture();
    const snapshot = createTaskSnapshotV1(
      snapshotInput({ settings, analysis }),
    );

    settings.encoder = "x264_8bit";
    settings.crf = 28;
    settings.outputDirectory = "E:\\changed";
    analysis.titles[0]!.toolMappings.handbrakeTitleNumber = 99;

    expect(snapshot).toMatchObject({
      snapshotVersion: 1,
      analysisId: "disc-a1",
      sourcePath: "D:\\影视 库\\示例 DVD",
      sourceFingerprint: "source-fingerprint-a1",
      sourceType: "dvd",
      selectedTitleId: "handbrake:7",
      outputMode: "compress",
      toolSelections: {
        handbrakeTitleNumber: 7,
        makemkvTitleIndex: 3,
        dvdVtsNumber: 1,
      },
      streamSelection: {
        videoTrackIds: ["stream:0"],
        audioTrackIds: ["stream:1"],
        subtitleTrackIds: ["stream:2"],
      },
      chapterSelection: { mode: "range", start: 1, end: 2 },
      compression: {
        encoder: "x265_10bit",
        crf: 19,
        resolution: "1080p",
        preset: "slow",
        encoderTune: "grain",
        encoderProfile: "high10",
        encoderLevel: "3.1",
        audioCopy: true,
      },
      output: {
        directory: "D:\\输出 目录",
        fileName: "示例 DVD.DVD.x265.1080p.mkv",
        format: "mkv",
      },
      createdAt: "2026-08-02T00:00:00.000Z",
      toolVersions: {
        handbrake: "1.9.2",
        makemkv: "1.17.8",
        ffmpeg: "7.1",
        whisper: "20250625",
      },
    });
    expect(snapshot.compression.encoder).toBe("x265_10bit");
    expect(snapshot.toolSelections.handbrakeTitleNumber).toBe(7);
  });

  it("accepts a confirmed smart-workflow output name without changing legacy naming", () => {
    const registry = new DiscAnalysisRegistry();
    registry.remember(analysisFixture());
    const prepared = prepareTaskSnapshotForJobCreation({
      registry,
      request: {
        analysisId: "disc-a1",
        sourcePath: "D:\\影视 库\\示例 DVD",
        sourceFingerprint: "source-fingerprint-a1",
        selectedTitleId: "handbrake:7",
        outputMode: "compress",
        selectedStreamIndexes: [0, 1, 2],
        selectedChapterIds: [0, 1],
        outputFileName: "我的确认名称.mkv",
      },
      settings: settingsFixture(),
    });
    expect(prepared.snapshot.output.fileName).toBe("我的确认名称.mkv");
  });

  it("rejects a missing analysis or title instead of silently choosing a default title", () => {
    expect(() =>
      createTaskSnapshotV1(snapshotInput({ analysisId: "expired-analysis" })),
    ).toThrow(new TaskSnapshotError("TASK_SNAPSHOT_ANALYSIS_NOT_FOUND"));
    expect(() =>
      createTaskSnapshotV1(snapshotInput({ selectedTitleId: "handbrake:404" })),
    ).toThrow(new TaskSnapshotError("TASK_SNAPSHOT_TITLE_NOT_FOUND"));
  });

  it("rejects an unavailable DVD title for every output mode", () => {
    const unavailable = analysisFixture();
    unavailable.titles[0]!.availabilityStatus = "unavailable";
    unavailable.titles[0]!.availabilityFailureReason =
      "VTS payload read failed";

    expect(() =>
      createTaskSnapshotV1(
        snapshotInput({ analysis: unavailable, outputMode: "compress" }),
      ),
    ).toThrow(new TaskSnapshotError("TASK_SNAPSHOT_TITLE_UNAVAILABLE"));
    expect(() =>
      createTaskSnapshotV1(
        snapshotInput({ analysis: unavailable, outputMode: "remux" }),
      ),
    ).toThrow(new TaskSnapshotError("TASK_SNAPSHOT_TITLE_UNAVAILABLE"));
  });

  it("uses the verified dvdvideo title for DVD Remux without requiring MakeMKV or title-order fallbacks", () => {
    const noMakeMkv = analysisFixture();
    noMakeMkv.titles[0]!.toolMappings.makemkvTitleIndex = null;
    noMakeMkv.exportCandidates = [];
    noMakeMkv.titles[0]!.verificationStatus = "verified";
    const dvdRemux = createTaskSnapshotV1(
      snapshotInput({ analysis: noMakeMkv, outputMode: "remux" }),
    );
    expect(dvdRemux.toolSelections).toMatchObject({
      handbrakeTitleNumber: 7,
      makemkvTitleIndex: null,
      dvdVtsNumber: 1,
    });

    const unverifiedDvd = analysisFixture();
    unverifiedDvd.titles[0]!.toolMappings.makemkvTitleIndex = null;
    unverifiedDvd.titles[0]!.toolMappings.dvdVtsNumber = null;
    unverifiedDvd.titles[0]!.verificationStatus = "pending";
    expect(() =>
      createTaskSnapshotV1(
        snapshotInput({ analysis: unverifiedDvd, outputMode: "remux" }),
      ),
    ).toThrow(new TaskSnapshotError("TASK_SNAPSHOT_REMUX_TITLE_REQUIRED"));

    const noHandBrake = analysisFixture();
    noHandBrake.titles[0]!.toolMappings.handbrakeTitleNumber = null;
    expect(() =>
      createTaskSnapshotV1(
        snapshotInput({ analysis: noHandBrake, outputMode: "compress" }),
      ),
    ).toThrow(new TaskSnapshotError("TASK_SNAPSHOT_HANDBRAKE_TITLE_REQUIRED"));

    const unpaired = analysisFixture();
    unpaired.titles[0]!.toolMappings.makemkvTitleIndex = null;
    unpaired.titles[0]!.toolMappings.dvdVtsNumber = null;
    expect(() =>
      createTaskSnapshotV1(
        snapshotInput({ analysis: unpaired, outputMode: "both" }),
      ),
    ).toThrow(new TaskSnapshotError("TASK_SNAPSHOT_REMUX_TITLE_REQUIRED"));

    expect(() =>
      createTaskSnapshotV1(
        snapshotInput({
          analysis: unpaired,
          outputMode: "both",
          remuxExportCandidateIndex: 3,
        }),
      ),
    ).toThrow(new TaskSnapshotError("TASK_SNAPSHOT_REMUX_TITLE_REQUIRED"));
  });

  it("restores the real DVD video stream when a stale Remux selection contains audio only", () => {
    const snapshot = createTaskSnapshotV1(
      snapshotInput({
        outputMode: "remux",
        streamSelection: {
          videoTrackIds: [],
          audioTrackIds: ["stream:1"],
          subtitleTrackIds: [],
        },
      }),
    );
    expect(snapshot.streamSelection.videoTrackIds).toEqual(["stream:0"]);
    expect(snapshot.streamSelection.audioTrackIds).toEqual(["stream:1"]);
  });

  it("persists the physical VTS mapping separately from the logical DVD title number", () => {
    const dvd = analysisFixture();
    dvd.titles[0]!.toolMappings.physicalVtsNumber = 13;
    const snapshot = createTaskSnapshotV1(
      snapshotInput({ analysis: dvd, outputMode: "remux" }),
    );
    expect(snapshot.toolSelections).toMatchObject({
      dvdVtsNumber: 1,
      physicalVtsNumber: 13,
    });
    expect(
      parseTaskSnapshot(serializeTaskSnapshot(snapshot)).toolSelections
        .physicalVtsNumber,
    ).toBe(13);
  });

  it("allows Remux snapshots for playlist-less Blu-ray m2ts fallback titles", () => {
    const bluray = analysisFixture();
    bluray.mediaType = "bluray";
    bluray.sourcePath = "D:\\影视 库\\示例蓝光";
    bluray.exportCandidates = [];
    bluray.titles = [
      {
        titleId: "m2ts:00000",
        titleIndex: 0,
        sourcePath: "D:\\影视 库\\示例蓝光\\BDMV\\STREAM\\00000.m2ts",
        displayName: "Title 1",
        durationSeconds: 6172,
        chapterCount: 0,
        chapters: [],
        estimatedSize: 10_000_000_000,
        streams: [
          {
            index: 0,
            codecType: "video",
            codecName: "h264",
            language: null,
            title: null,
          },
          {
            index: 1,
            codecType: "audio",
            codecName: "truehd",
            language: "zh",
            title: "TrueHD",
          },
        ],
        videoTracks: [
          {
            index: 0,
            codecType: "video",
            codecName: "h264",
            language: null,
            title: null,
          },
        ],
        audioTracks: [
          {
            index: 1,
            codecType: "audio",
            codecName: "truehd",
            language: "zh",
            title: "TrueHD",
          },
        ],
        subtitleTracks: [],
        toolMappings: {
          handbrakeTitleNumber: null,
          makemkvTitleIndex: null,
          dvdVtsNumber: null,
          playlistId: null,
        },
        mappingStatus: "not-required",
      },
    ];
    const registry = new DiscAnalysisRegistry();
    registry.remember(bluray);
    const prepared = prepareTaskSnapshotForJobCreation({
      registry,
      request: {
        analysisId: bluray.analysisId,
        sourcePath: bluray.sourcePath,
        sourceFingerprint: bluray.sourceFingerprint,
        selectedTitleId: "m2ts:00000",
        outputMode: "remux",
        selectedStreamIndexes: [0, 1],
        selectedChapterIds: [],
      },
      settings: settingsFixture(),
    });
    expect(prepared.snapshot.toolSelections.playlistId).toBeNull();
    expect(prepared.snapshot.selectedTitleId).toBe("m2ts:00000");
    expect(prepared.snapshot.outputMode).toBe("remux");
    expect(prepared.snapshot.output.fileName).toContain("BluRay.Remux");
  });

  it("freezes the configured Remux output directory independently from compression output", () => {
    const sourceRegistry = new DiscAnalysisRegistry();
    sourceRegistry.remember(analysisFixture());
    const sourceDefault = prepareTaskSnapshotForJobCreation({
      registry: sourceRegistry,
      request: {
        analysisId: "disc-a1",
        sourcePath: analysisFixture().sourcePath,
        sourceFingerprint: analysisFixture().sourceFingerprint,
        selectedTitleId: "handbrake:7",
        outputMode: "remux",
        selectedStreamIndexes: [0, 1, 2],
        selectedChapterIds: [0, 1],
      },
      settings: settingsFixture(),
    });
    expect(sourceDefault.snapshot.output.directory).toBe("__source__");

    const registry = new DiscAnalysisRegistry();
    registry.remember(analysisFixture());
    const custom = prepareTaskSnapshotForJobCreation({
      registry,
      request: {
        analysisId: "disc-a1",
        sourcePath: analysisFixture().sourcePath,
        sourceFingerprint: analysisFixture().sourceFingerprint,
        selectedTitleId: "handbrake:7",
        outputMode: "remux",
        selectedStreamIndexes: [0],
        selectedChapterIds: [0],
      },
      settings: {
        ...settingsFixture(),
        remuxOutputDirectory: "D:\\Remux 输出",
      },
    });
    expect(custom.snapshot.output.directory).toBe("D:\\Remux 输出");
    expect(custom.snapshot.compression).toMatchObject({
      encoder: "x265_10bit",
      crf: 19,
    });
  });

  it("does not apply the Remux directory to compression or subtitle snapshots", () => {
    const settings = {
      ...settingsFixture(),
      remuxOutputDirectory: "D:\\Remux 输出",
    };
    const compression = createStandaloneTaskSnapshotV1({
      sourcePath: "D:\\影片\\movie.mkv",
      sourceType: "video",
      outputMode: "compress",
      settings,
    });
    const subtitle = createStandaloneTaskSnapshotV1({
      sourcePath: "D:\\影片\\movie.mkv",
      sourceType: "video",
      outputMode: "subtitle",
      settings,
    });
    expect(compression.output.directory).toBe("D:\\输出 目录");
    expect(subtitle.output.directory).toBe("D:\\输出 目录");
    expect(subtitle.output.fileName).toBe("movie.mkv.MediaSculpt.srt");
  });

  it("freezes a temporary-remux compression strategy when DVD verification reports structural differences", () => {
    const analysis = analysisFixture();
    analysis.titles[0]!.verificationWarnings = [
      "音轨数量差异：HandBrake 2，FFprobe 1",
    ];
    const registry = new DiscAnalysisRegistry();
    registry.remember(analysis);
    const prepared = prepareTaskSnapshotForJobCreation({
      registry,
      request: {
        analysisId: "disc-a1",
        sourcePath: analysis.sourcePath,
        sourceFingerprint: analysis.sourceFingerprint,
        selectedTitleId: "handbrake:7",
        outputMode: "compress",
        selectedStreamIndexes: [0, 1, 2],
        selectedChapterIds: [0, 1],
      },
      settings: settingsFixture(),
    });
    expect(prepared.snapshot.compressionSourceStrategy).toBe("temporary-remux");
  });

  it("keeps all DVD streams and chapters when the selection is omitted", () => {
    const registry = new DiscAnalysisRegistry();
    registry.remember(analysisFixture());
    const prepared = prepareTaskSnapshotForJobCreation({
      registry,
      request: {
        analysisId: "disc-a1",
        sourcePath: analysisFixture().sourcePath,
        sourceFingerprint: analysisFixture().sourceFingerprint,
        selectedTitleId: "handbrake:7",
        outputMode: "remux",
      },
      settings: settingsFixture(),
    });
    expect(prepared.snapshot.streamSelection).toEqual({
      videoTrackIds: ["stream:0"],
      audioTrackIds: ["stream:1"],
      subtitleTrackIds: ["stream:2"],
    });
    expect(prepared.snapshot.chapterSelection.chapterIds).toEqual([
      "chapter:0",
      "chapter:1",
    ]);
  });

  it("preserves every remaining subtitle track when selected language variants are excluded", () => {
    const analysis = analysisFixture();
    const title = analysis.titles[0]!;
    for (let index = 3; index <= 11; index += 1) {
      title.streams.push({
        index,
        codecType: "subtitle",
        codecName: "dvd_subtitle",
        language: index >= 10 ? "jpn" : "eng",
        title: index >= 10 ? "Japanese" : "Foreign subtitle",
      });
    }
    title.subtitleTracks = title.streams.filter(
      (stream) => stream.codecType === "subtitle",
    );
    const registry = new DiscAnalysisRegistry();
    registry.remember(analysis);
    const prepared = prepareTaskSnapshotForJobCreation({
      registry,
      request: {
        analysisId: analysis.analysisId,
        sourcePath: analysis.sourcePath,
        sourceFingerprint: analysis.sourceFingerprint,
        selectedTitleId: "handbrake:7",
        outputMode: "remux",
        // Simulate unchecking the two Japanese variants at indices 10 and 11.
        selectedStreamIndexes: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
      },
      settings: settingsFixture(),
    });

    expect(prepared.snapshot.streamSelection.subtitleTrackIds).toEqual(
      [2, 3, 4, 5, 6, 7, 8, 9].map((index) => `stream:${index}`),
    );
  });

  it("gives different DVD HandBrake titles different frozen compression output names", () => {
    const analysis = analysisFixture();
    const shortTitle = {
      ...analysis.titles[0]!,
      titleId: "handbrake:2",
      displayName: "Title 2",
      durationSeconds: 420,
      chapterCount: 1,
      chapters: [{ id: 0, startSeconds: 0, endSeconds: 420, title: "花絮" }],
      estimatedSize: null,
      toolMappings: {
        handbrakeTitleNumber: 2,
        makemkvTitleIndex: null,
        dvdVtsNumber: 2,
      },
    };
    analysis.titles = [analysis.titles[0]!, shortTitle];
    const registry = new DiscAnalysisRegistry();
    registry.remember(analysis);

    const feature = prepareTaskSnapshotForJobCreation({
      registry,
      request: {
        analysisId: analysis.analysisId,
        sourcePath: analysis.sourcePath,
        sourceFingerprint: analysis.sourceFingerprint,
        selectedTitleId: "handbrake:7",
        outputMode: "compress",
        selectedStreamIndexes: [0, 1, 2],
      },
      settings: settingsFixture(),
    });
    const short = prepareTaskSnapshotForJobCreation({
      registry,
      request: {
        analysisId: analysis.analysisId,
        sourcePath: analysis.sourcePath,
        sourceFingerprint: analysis.sourceFingerprint,
        selectedTitleId: "handbrake:2",
        outputMode: "compress",
        selectedStreamIndexes: [0, 1, 2],
      },
      settings: settingsFixture(),
    });

    expect(feature.snapshot.output.fileName).toContain("Title07");
    expect(short.snapshot.output.fileName).toContain("Title02");
    expect(feature.snapshot.output.fileName).not.toBe(
      short.snapshot.output.fileName,
    );
  });

  it("preserves snapshot semantics through SQLite write, process-memory loss, and reload", async () => {
    const snapshot = createTaskSnapshotV1(snapshotInput());
    tempDirectory = fs.mkdtempSync(path.join(os.tmpdir(), "vx-task-snapshot-"));
    const databasePath = path.join(tempDirectory, "vx-agent.db");
    const first = openSqliteDatabase(databasePath);
    await first.db.insert(sqliteSchema.jobsTable).values({
      filePath: snapshot.sourcePath,
      mediaType: snapshot.sourceType,
      processingMode: "compress",
      taskSnapshot: serializeTaskSnapshot(snapshot),
      taskSnapshotVersion: snapshot.snapshotVersion,
      legacyTask: false,
    });
    first.client.close();

    const reopened = openSqliteDatabase(databasePath);
    close = () => reopened.client.close();
    const [job] = await reopened.db.select().from(sqliteSchema.jobsTable);
    const loaded = loadTaskSnapshot(job);

    expect(loaded).toEqual(snapshot);
    expect(loaded?.toolSelections.handbrakeTitleNumber).toBeTypeOf("number");
    expect(loaded?.streamSelection.subtitleTrackIds).toEqual(["stream:2"]);
    expect(loaded?.output.directory).toBe("D:\\输出 目录");
  });

  it("marks pre-snapshot jobs as legacy and never infers a replacement title", () => {
    expect(
      loadTaskSnapshot({
        taskSnapshot: null,
        taskSnapshotVersion: null,
        legacyTask: true,
      }),
    ).toBeNull();
    expect(() => parseTaskSnapshot('{"snapshotVersion":2}')).toThrow(
      new TaskSnapshotError("TASK_SNAPSHOT_UNSUPPORTED_VERSION"),
    );
  });

  it("rejects structurally incomplete or wrongly typed snapshot JSON at the execution boundary", () => {
    const snapshot = createTaskSnapshotV1(snapshotInput());
    const malformed = {
      ...snapshot,
      compression: { ...snapshot.compression, crf: "19" },
      output: { directory: snapshot.output.directory },
    };
    expect(() => parseTaskSnapshot(JSON.stringify(malformed))).toThrow(
      new TaskSnapshotError("TASK_SNAPSHOT_INVALID"),
    );
  });

  it("prepares POST /jobs data from the registered analysis id and freezes settings A before settings B exists", () => {
    const registry = new DiscAnalysisRegistry();
    registry.remember(analysisFixture());
    const settingsA = settingsFixture();
    const prepared = prepareTaskSnapshotForJobCreation({
      registry,
      request: {
        analysisId: "disc-a1",
        sourcePath: "D:\\影视 库\\示例 DVD",
        sourceFingerprint: "source-fingerprint-a1",
        selectedTitleId: "handbrake:7",
        outputMode: "compress",
        selectedStreamIndexes: [0, 1, 2],
        selectedChapterIds: [0, 1],
      },
      settings: settingsA,
      createdAt: "2026-08-02T00:00:00.000Z",
    });

    const settingsB = {
      ...settingsA,
      encoder: "av1",
      crf: 32,
      outputResolution: "720p",
      encoderPreset: "fast",
      audioCopy: false,
      outputDirectory: "E:\\其他输出",
    };
    registry.clear();

    expect(prepared.snapshot.compression).toMatchObject({
      encoder: "x265_10bit",
      crf: 19,
      resolution: "1080p",
      preset: "slow",
      audioCopy: true,
    });
    expect(prepared.snapshot.output.directory).toBe("D:\\输出 目录");
    expect(prepared.snapshot.streamSelection).toEqual({
      videoTrackIds: ["stream:0"],
      audioTrackIds: ["stream:1"],
      subtitleTrackIds: ["stream:2"],
    });
    expect(prepared.snapshot.chapterSelection).toEqual({
      mode: "selected",
      start: null,
      end: null,
      chapterIds: ["chapter:0", "chapter:1"],
    });
    expect(settingsB.encoder).toBe("av1");
    expect(() =>
      prepareTaskSnapshotForJobCreation({
        registry,
        request: { ...prepared.request, analysisId: "disc-a1" },
        settings: settingsB,
      }),
    ).toThrow(new TaskSnapshotError("TASK_SNAPSHOT_ANALYSIS_NOT_FOUND"));
  });

  it("expires registered analysis ids with the analysis cache instead of recreating a selection from a path", () => {
    let now = 0;
    const registry = new DiscAnalysisRegistry(100, () => now);
    registry.remember(analysisFixture());
    expect(registry.find("disc-a1")?.analysisId).toBe("disc-a1");
    now = 101;
    expect(registry.find("disc-a1")).toBeNull();
  });

  it("creates a deterministic snapshot for a directly selected normal media file without inventing a disc title", () => {
    const snapshot = createStandaloneTaskSnapshotV1({
      sourcePath: "C:\\媒体\\示例 影片.mkv",
      sourceType: "video",
      outputMode: "compress",
      selectedStreamIndexes: [0, 2],
      selectedChapterIds: [],
      settings: settingsFixture(),
      createdAt: "2026-08-02T00:00:00.000Z",
    });

    expect(snapshot).toMatchObject({
      snapshotVersion: 1,
      sourceType: "video",
      selectedTitleId: "media:source",
      toolSelections: {
        handbrakeTitleNumber: null,
        makemkvTitleIndex: null,
        dvdVtsNumber: null,
      },
      streamSelection: {
        videoTrackIds: ["stream:0", "stream:2"],
        audioTrackIds: [],
        subtitleTrackIds: [],
      },
    });
  });
});
