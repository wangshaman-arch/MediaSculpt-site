import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import zlib from "node:zlib";
import { describe, expect, it, vi } from "vitest";
import {
  AACS_DLL_MIN_BYTES,
  KEYDB_MIN_BYTES,
  LIBAACS_FILE_NAME,
  LIBBDPLUS_FILE_NAME,
  KEYDB_FILE_NAME,
  aacsLibraryTargetPath,
  ensureAacsDecryption,
  extractAacsLibrariesFromZip,
  isAacsDecryptionError,
  isAacsLibraryInstalled,
  isKeydbContent,
  isKeydbInstalled,
  isPeDllHead,
  keydbTargetPaths,
  type AacsDownloadFn,
} from "./libaacs";

/** Build a minimal stored/deflated zip so the parser is exercised for real. */
function buildZip(
  entries: Array<{ name: string; data: Buffer; deflate?: boolean }>,
): Buffer {
  const chunks: Buffer[] = [];
  const central: Buffer[] = [];
  let offset = 0;
  for (const entry of entries) {
    const nameBuf = Buffer.from(entry.name, "utf8");
    const raw = entry.deflate ? zlib.deflateRawSync(entry.data) : entry.data;
    const method = entry.deflate ? 8 : 0;
    const local = Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0, 6);
    local.writeUInt16LE(method, 8);
    local.writeUInt32LE(0, 14); // crc (not validated by the reader)
    local.writeUInt32LE(raw.length, 18);
    local.writeUInt32LE(entry.data.length, 22);
    local.writeUInt16LE(nameBuf.length, 26);
    local.writeUInt16LE(0, 28);
    chunks.push(local, nameBuf, raw);

    const cd = Buffer.alloc(46);
    cd.writeUInt32LE(0x02014b50, 0);
    cd.writeUInt16LE(20, 4);
    cd.writeUInt16LE(20, 6);
    cd.writeUInt16LE(0, 8);
    cd.writeUInt16LE(method, 10);
    cd.writeUInt32LE(0, 16);
    cd.writeUInt32LE(raw.length, 20);
    cd.writeUInt32LE(entry.data.length, 24);
    cd.writeUInt16LE(nameBuf.length, 28);
    cd.writeUInt32LE(offset, 42);
    central.push(cd, nameBuf);
    offset += local.length + nameBuf.length + raw.length;
  }
  const centralBuf = Buffer.concat(central);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(entries.length, 8);
  eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(centralBuf.length, 12);
  eocd.writeUInt32LE(offset, 16);
  return Buffer.concat([...chunks, centralBuf, eocd]);
}

function peDll(size: number): Buffer {
  const buffer = Buffer.alloc(size);
  buffer[0] = 0x4d;
  buffer[1] = 0x5a;
  return buffer;
}

function keydbText(records: number): Buffer {
  const lines = ["; MediaSculpt test KEYDB", "; device key entries follow"];
  for (let index = 0; index < records; index += 1) {
    lines.push(
      `${"0".repeat(32)}|${"1".repeat(32)}|${index}|MediaSculpt|test|2020-01-01`,
    );
  }
  return Buffer.from(lines.join("\n"), "utf8");
}

async function tempDir(): Promise<string> {
  return fs.mkdtemp(path.join(os.tmpdir(), "vx-aacs-"));
}

describe("Blu-ray AACS/BD+ decryption support", () => {
  it("extracts both engines from a deflated release archive", () => {
    const dll = peDll(AACS_DLL_MIN_BYTES + 1024);
    const zip = buildZip([
      { name: "winx64/libaacs.dll", data: dll, deflate: true },
      {
        name: "winx86/libaacs.dll",
        data: peDll(AACS_DLL_MIN_BYTES),
        deflate: true,
      },
      { name: "winx64/libbdplus.dll", data: dll, deflate: true },
      { name: "LICENSE", data: Buffer.from("licence text"), deflate: true },
    ]);
    const extracted = extractAacsLibrariesFromZip(new Uint8Array(zip));
    expect(extracted).not.toBeNull();
    expect(
      isPeDllHead(extracted!.aacs.slice(0, 16), extracted!.aacs.length),
    ).toBe(true);
    expect(
      isPeDllHead(extracted!.bdplus.slice(0, 16), extracted!.bdplus.length),
    ).toBe(true);
  });

  it("handles stored entries as well as deflated ones", () => {
    const dll = peDll(AACS_DLL_MIN_BYTES + 100);
    const zip = buildZip([
      { name: "winx64/libaacs.dll", data: dll, deflate: false },
      { name: "winx64/libbdplus.dll", data: dll, deflate: false },
    ]);
    const extracted = extractAacsLibrariesFromZip(new Uint8Array(zip));
    expect(extracted?.aacs.length).toBe(dll.length);
  });

  it("refuses a half-populated archive instead of installing one engine", () => {
    const zip = buildZip([
      {
        name: "winx64/libaacs.dll",
        data: peDll(AACS_DLL_MIN_BYTES),
        deflate: true,
      },
    ]);
    expect(extractAacsLibrariesFromZip(new Uint8Array(zip))).toBeNull();
  });

  it("rejects tiny payloads and HTML served in place of a DLL", () => {
    expect(isPeDllHead(new Uint8Array([0x4d, 0x5a]), 512)).toBe(false);
    expect(isPeDllHead(new Uint8Array([0x4d, 0x5a]), AACS_DLL_MIN_BYTES)).toBe(
      true,
    );
    expect(isPeDllHead(new Uint8Array([0x3c, 0x21]), 100_000)).toBe(false);
  });

  it("accepts a real key database and rejects an HTML error page", () => {
    const good = keydbText(200);
    expect(isKeydbContent(good.slice(0, 4096), good.length)).toBe(true);
    const html = Buffer.concat([
      Buffer.from("<!DOCTYPE html><html><body>not found"),
      Buffer.alloc(KEYDB_MIN_BYTES),
    ]);
    expect(isKeydbContent(html.slice(0, 4096), html.length)).toBe(false);
    expect(isKeydbContent(good.slice(0, 4096), 100)).toBe(false);
  });

  it("places engines beside the tool and KEYDB in the libaacs search path", async () => {
    expect(
      aacsLibraryTargetPath(
        "C:\\tools\\ffmpeg.exe",
        LIBAACS_FILE_NAME,
        "win32",
      ),
    ).toBe("C:\\tools\\libaacs.dll");
    expect(
      aacsLibraryTargetPath(
        "C:\\tools\\ffmpeg.exe",
        LIBBDPLUS_FILE_NAME,
        "linux",
      ),
    ).toBeNull();
    const targets = keydbTargetPaths(
      "C:\\tools\\ffmpeg.exe",
      "win32",
      "C:\\Users\\tester",
      "C:\\Users\\tester\\AppData\\Roaming",
    );
    expect(targets[0]).toBe(
      path.join("C:\\Users\\tester\\AppData\\Roaming", "aacs", KEYDB_FILE_NAME),
    );
    expect(targets[1]).toBe(path.join("C:\\tools", KEYDB_FILE_NAME));
    expect(keydbTargetPaths("C:\\tools\\ffmpeg.exe", "darwin")).toEqual([]);
  });

  it("installs both engines and the key database from the configured sources", async () => {
    const root = await tempDir();
    const executable = path.join(root, "ffmpeg.exe");
    await fs.writeFile(executable, "stub");
    const appData = path.join(root, "Roaming");
    const dll = peDll(AACS_DLL_MIN_BYTES + 2048);
    const archive = buildZip([
      { name: "winx64/libaacs.dll", data: dll, deflate: true },
      { name: "winx64/libbdplus.dll", data: dll, deflate: true },
    ]);
    const keydb = keydbText(300);
    const download: AacsDownloadFn = vi.fn(async (url) =>
      url.endsWith(".zip")
        ? { ok: true, status: 200, data: new Uint8Array(archive) }
        : { ok: true, status: 200, data: new Uint8Array(keydb) },
    );
    const logs: string[] = [];
    const result = await ensureAacsDecryption(executable, {
      platform: "win32",
      appData,
      libraryUrl: "https://example.com/libaacs_libbdplus.zip",
      keydbMirrors: ["https://example.com/KEYDB.cfg"],
      download,
      onLog: async (message) => {
        logs.push(message);
      },
    });

    expect(result).toEqual({ libraries: "installed", keydb: "installed" });
    expect(await isAacsLibraryInstalled(executable, "win32")).toBe(true);
    expect(await isKeydbInstalled(executable, "win32", root, appData)).toBe(
      true,
    );
    expect(logs.some((line) => line.includes(LIBAACS_FILE_NAME))).toBe(true);
    await fs.rm(root, { recursive: true, force: true });
  });

  it("keeps installed engines when every key database mirror fails", async () => {
    const root = await tempDir();
    const executable = path.join(root, "ffmpeg.exe");
    await fs.writeFile(executable, "stub");
    const dll = peDll(AACS_DLL_MIN_BYTES + 2048);
    const archive = buildZip([
      { name: "winx64/libaacs.dll", data: dll, deflate: true },
      { name: "winx64/libbdplus.dll", data: dll, deflate: true },
    ]);
    const download: AacsDownloadFn = vi.fn(async (url) =>
      url.endsWith(".zip")
        ? { ok: true, status: 200, data: new Uint8Array(archive) }
        : { ok: false, status: 404, data: new Uint8Array() },
    );
    const result = await ensureAacsDecryption(executable, {
      platform: "win32",
      appData: path.join(root, "Roaming"),
      libraryUrl: "https://example.com/libaacs_libbdplus.zip",
      keydbMirrors: ["https://example.com/KEYDB.cfg"],
      download,
    });
    expect(result.libraries).toBe("installed");
    expect(result.keydb).toBe("failed");
    expect(await isAacsLibraryInstalled(executable, "win32")).toBe(true);
    await fs.rm(root, { recursive: true, force: true });
  });

  it("is a no-op on non-Windows platforms", async () => {
    const download: AacsDownloadFn = vi.fn(async () => ({
      ok: true,
      status: 200,
      data: new Uint8Array(),
    }));
    expect(
      await ensureAacsDecryption("/usr/bin/ffmpeg", {
        platform: "darwin",
        download,
      }),
    ).toEqual({
      libraries: "unsupported",
      keydb: "unsupported",
    });
    expect(download).not.toHaveBeenCalled();
  });

  it("recognises AACS/BD+ decryption failures in tool stderr", () => {
    expect(isAacsDecryptionError("aacs: unit key not found")).toBe(true);
    expect(
      isAacsDecryptionError("libaacs: failed to open AACS/Unit_Key_RO.inf"),
    ).toBe(true);
    expect(
      isAacsDecryptionError("BD+ virtual machine verification failed"),
    ).toBe(true);
    expect(
      isAacsDecryptionError(
        "libdvdread: Could not open E:\\VIDEO_TS with libdvdcss.",
      ),
    ).toBe(false);
    expect(isAacsDecryptionError("")).toBe(false);
  });
});
