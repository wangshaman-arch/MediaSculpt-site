import type { DiscStream, DiscTrack } from "@workspace/api-client-react";

/**
 * A title is focused with a complete export selection. Users can narrow it
 * explicitly afterwards; the default must match what the old dialog built.
 */
export function defaultStreamSelection(
  track: DiscTrack | undefined,
  includeVideoStreams: boolean,
): Set<number> {
  return new Set(
    track?.streams
      .filter(
        (stream) =>
          includeVideoStreams ||
          stream.codecType === "audio" ||
          stream.codecType === "subtitle",
      )
      .map((stream) => stream.index) ?? [],
  );
}

export function defaultChapterSelection(
  track: DiscTrack | undefined,
): Set<number> {
  return new Set(track?.chapters?.map((chapter) => chapter.id) ?? []);
}

export function selectableStreamsForTrack(
  track: DiscTrack | undefined,
  includeVideoStreams: boolean,
): DiscStream[] {
  if (!track) return [];
  return track.streams.filter(
    (stream) =>
      includeVideoStreams ||
      stream.codecType === "audio" ||
      stream.codecType === "subtitle",
  );
}

export function countSelectedTrackStreams(
  track: DiscTrack | undefined,
  selectedIndexes: Set<number>,
  codecType: DiscStream["codecType"],
): number {
  return (
    track?.streams.filter(
      (stream) =>
        stream.codecType === codecType && selectedIndexes.has(stream.index),
    ).length ?? 0
  );
}
