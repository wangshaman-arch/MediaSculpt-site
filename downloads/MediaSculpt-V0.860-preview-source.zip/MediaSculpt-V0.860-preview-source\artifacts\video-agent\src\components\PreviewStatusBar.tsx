import {
  useGetPreviewStatus,
  getGetPreviewStatusQueryKey,
} from "@workspace/api-client-react";
import {
  AlertTriangle,
  CalendarClock,
  CheckCircle2,
  Infinity,
  Sparkles,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useI18n } from "@/i18n";

function formatDate(value: string | null, locale: string): string {
  if (!value) return "";
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? ""
    : new Intl.DateTimeFormat(locale, {
        year: "numeric",
        month: "short",
        day: "numeric",
      }).format(date);
}

export function PreviewStatusBar({
  showDetails = false,
}: {
  showDetails?: boolean;
}) {
  const { t, lang } = useI18n();
  const { data, isLoading, isError } = useGetPreviewStatus({
    query: {
      queryKey: getGetPreviewStatusQueryKey(),
      refetchInterval: 30_000,
      refetchOnWindowFocus: true,
    },
  });

  if (isLoading || isError || !data) {
    return (
      <div
        data-testid="preview-status-bar"
        className="flex min-h-9 items-center gap-2 rounded-lg border bg-card/70 px-3 py-2 text-xs text-muted-foreground"
      >
        <Sparkles className="h-3.5 w-3.5" />
        <span>
          {isError
            ? t("previewStatus.unavailable")
            : t("previewStatus.loading")}
        </span>
      </div>
    );
  }

  const blocked = !data.isActive;
  const taskText =
    data.remainingTasks === null
      ? t("previewStatus.unlimited")
      : t("previewStatus.tasksRemaining", { count: data.remainingTasks });
  const reason =
    data.blockedReason === "expired"
      ? t("previewStatus.expired")
      : data.blockedReason === "quota_exhausted"
        ? t("previewStatus.quotaExhausted")
        : data.blockedReason === "clock_invalid"
          ? t("previewStatus.clockInvalid")
          : "";

  return (
    <div
      data-testid="preview-status-bar"
      className="flex min-h-9 flex-wrap items-center gap-x-3 gap-y-1 rounded-lg border bg-card/70 px-3 py-2 text-xs"
    >
      <Badge variant={blocked ? "destructive" : "outline"} className="gap-1">
        {blocked ? (
          <AlertTriangle className="h-3 w-3" />
        ) : (
          <CheckCircle2 className="h-3 w-3" />
        )}
        {data.edition === "development"
          ? t("previewStatus.development")
          : t("previewStatus.preview")}
      </Badge>
      <span
        className={
          blocked ? "font-medium text-destructive" : "text-muted-foreground"
        }
      >
        {blocked ? reason : taskText}
      </span>
      {data.edition === "preview" && data.expiresAt && (
        <span className="inline-flex items-center gap-1 text-muted-foreground">
          <CalendarClock className="h-3.5 w-3.5" />
          {t("previewStatus.expires", {
            date: formatDate(data.expiresAt, lang),
          })}
          {data.daysRemaining !== null &&
            ` · ${t("previewStatus.expiresIn", { days: data.daysRemaining })}`}
        </span>
      )}
      {showDetails && data.edition === "preview" && data.firstStartedAt && (
        <span className="inline-flex items-center gap-1 text-muted-foreground">
          <CalendarClock className="h-3.5 w-3.5" />
          {t("previewStatus.started", {
            date: formatDate(data.firstStartedAt, lang),
          })}
        </span>
      )}
      <span className="inline-flex items-center gap-1 text-muted-foreground">
        <Sparkles className="h-3.5 w-3.5" />
        {t("previewStatus.aiCalls", { count: data.aiCallCount })}
      </span>
      {data.edition === "development" && (
        <span className="inline-flex items-center gap-1 text-muted-foreground">
          <Infinity className="h-3.5 w-3.5" />
          {t("previewStatus.developmentNote")}
        </span>
      )}
    </div>
  );
}
