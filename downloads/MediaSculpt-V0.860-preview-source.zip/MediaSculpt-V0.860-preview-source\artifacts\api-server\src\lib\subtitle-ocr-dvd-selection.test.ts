import { describe, expect, it } from "vitest";
import {
  chooseDvdSubtitleReferenceTrack,
  chooseDvdSubtitleTrack,
  dvdSubtitleLanguageLabel,
} from "./subtitle-ocr-dvd";

describe("DVD subtitle track selection", () => {
  it("prefers English when its estimated count is close to the longest track", () => {
    const selected = chooseDvdSubtitleTrack([
      { subTypeIndex: 0, count: 1200, language: "fra", coverage: 1 },
      { subTypeIndex: 1, count: 1160, language: "eng", coverage: 1 },
      { subTypeIndex: 2, count: 300, language: "spa", coverage: 1 },
    ]);
    expect(selected.subTypeIndex).toBe(1);
  });

  it("uses the longest complete track when English is substantially shorter", () => {
    const selected = chooseDvdSubtitleTrack([
      { subTypeIndex: 0, count: 1500, language: "fra", coverage: 1 },
      { subTypeIndex: 1, count: 900, language: "eng", coverage: 1 },
    ]);
    expect(selected.subTypeIndex).toBe(0);
  });

  it("does not choose a short forced track over a complete track", () => {
    const selected = chooseDvdSubtitleTrack([
      { subTypeIndex: 0, count: 100, language: "eng", coverage: 0.25 },
      { subTypeIndex: 1, count: 800, language: "fra", coverage: 1 },
    ]);
    expect(selected.subTypeIndex).toBe(1);
  });

  it("prefers a Chinese graphic track for a Chinese-target workflow", () => {
    const selected = chooseDvdSubtitleTrack(
      [
        { subTypeIndex: 0, count: 340, language: "deu", coverage: 1 },
        { subTypeIndex: 1, count: 340, language: "fra", coverage: 1 },
        { subTypeIndex: 2, count: 340, language: "spa", coverage: 1 },
        { subTypeIndex: 3, count: 310, language: "chi", coverage: 1 },
      ],
      "chi_sim",
    );
    expect(selected.subTypeIndex).toBe(3);
  });

  it("keeps a Chinese source track even when a foreign track reports higher coverage", () => {
    const selected = chooseDvdSubtitleTrack(
      [
        { subTypeIndex: 0, count: 278, language: "deu", coverage: 1 },
        { subTypeIndex: 1, count: 278, language: "fra", coverage: 1 },
        { subTypeIndex: 2, count: 278, language: "spa", coverage: 1 },
        { subTypeIndex: 3, count: 278, language: "chi", coverage: 0.62 },
      ],
      "chi_sim",
    );
    expect(selected.subTypeIndex).toBe(3);
  });

  it("prefers a Chinese graphic track in auto mode when one is available", () => {
    const selected = chooseDvdSubtitleTrack(
      [
        { subTypeIndex: 0, count: 278, language: "deu", coverage: 1 },
        { subTypeIndex: 1, count: 278, language: "fra", coverage: 1 },
        { subTypeIndex: 2, count: 278, language: "spa", coverage: 1 },
        { subTypeIndex: 3, count: 278, language: "chi", coverage: 1 },
      ],
      "auto",
    );
    expect(selected.subTypeIndex).toBe(3);
  });

  it("renders stable human-readable language labels", () => {
    expect(dvdSubtitleLanguageLabel("spa")).toBe("西班牙语（SPA）");
    expect(dvdSubtitleLanguageLabel("eng")).toBe("英语（ENG）");
    expect(dvdSubtitleLanguageLabel(null)).toBe("未标记");
  });
});

describe("DVD subtitle reference selection", () => {
  const chinese = {
    subTypeIndex: 0,
    count: 310,
    language: "chi",
    coverage: 0.8,
  };

  it("prefers an English reference track when one exists", () => {
    const selected = chooseDvdSubtitleReferenceTrack(
      [
        chinese,
        { subTypeIndex: 1, count: 90, language: "fra", coverage: 0.4 },
        { subTypeIndex: 2, count: 800, language: "eng", coverage: 1 },
      ],
      chinese,
    );
    expect(selected?.subTypeIndex).toBe(2);
  });

  it("falls back to the closest-count foreign track when English is absent", () => {
    const selected = chooseDvdSubtitleReferenceTrack(
      [
        chinese,
        { subTypeIndex: 1, count: 280, language: "fra", coverage: 0.75 },
        { subTypeIndex: 2, count: 700, language: "deu", coverage: 1 },
        { subTypeIndex: 3, count: 306, language: "chi", coverage: 0.8 },
      ],
      chinese,
    );
    expect(selected?.subTypeIndex).toBe(1);
  });

  it("does not use a foreign track whose cue count is far from the Chinese track", () => {
    expect(
      chooseDvdSubtitleReferenceTrack(
        [
          chinese,
          { subTypeIndex: 1, count: 90, language: "fra", coverage: 0.4 },
        ],
        chinese,
      ),
    ).toBeNull();
  });
});
