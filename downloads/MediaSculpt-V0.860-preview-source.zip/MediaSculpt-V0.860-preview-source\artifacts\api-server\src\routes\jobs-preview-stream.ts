import type { ChildProcess } from "child_process";
import type { Response } from "express";
import { resolveToolPath } from "../lib/tool-runtime";
import { ffmpegPath } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { buildPreviewTranscodeArgs } from "../media/preview-service";
// 通用预览转码：同一时刻只保留一个进程（快速 seek / 切换项时终止旧的）。
let genericPreviewFfmpeg: ChildProcess | null = null;
export function streamFfmpegPreview(
  res: Response,
  executable: string,
  args: string[],
): void {
  res.setHeader("Content-Type", "video/mp4");
  res.setHeader("Cache-Control", "no-store");
  if (genericPreviewFfmpeg && !genericPreviewFfmpeg.killed) {
    try {
      genericPreviewFfmpeg.kill("SIGKILL");
    } catch {
      /* ignore */
    }
  }
  const ffmpeg = jobProcessController.spawn(executable, args);
  genericPreviewFfmpeg = ffmpeg;
  let stderr = "";
  let wroteBytes = false;
  ffmpeg.stderr?.on("data", (chunk) => {
    stderr += String(chunk);
  });
  // 手动写响应：ffmpeg 输出为空时绝不能以 200 空响应结束（浏览器会报错误码 4）。
  ffmpeg.stdout?.on("data", (chunk: Buffer) => {
    wroteBytes = true;
    if (res.destroyed || res.writableEnded) return;
    if (!res.write(chunk)) ffmpeg.stdout?.pause();
  });
  res.on("drain", () => ffmpeg.stdout?.resume());
  ffmpeg.stdout?.on("end", () => {
    /* close 时统一收尾 */
  });
  ffmpeg.on("error", (error) => {
    if (!res.headersSent)
      res.status(500).json({ error: `预览转码启动失败：${error.message}` });
    else res.destroy(error);
  });
  ffmpeg.on("close", (code) => {
    if (genericPreviewFfmpeg === ffmpeg) genericPreviewFfmpeg = null;
    if (!wroteBytes) {
      if (!res.headersSent) {
        res.status(500).json({
          error: `预览转码失败：${stderr.slice(-600) || `ffmpeg exit ${code ?? "unknown"}`}`,
        });
        return;
      }
      res.destroy();
      return;
    }
    if (!res.writableEnded) res.end();
  });
  res.on("close", () => {
    if (!ffmpeg.killed) ffmpeg.kill("SIGTERM");
  });
}

/** 连续预览转码：整条响应保持同一个 MP4 流，不按 5 秒片段切换源。 */
export async function streamContinuousPreview(
  res: Response,
  filePath: string,
  subTypeIndex: number | null,
  seekSeconds: number,
): Promise<void> {
  const ffmpegExecutable =
    (await resolveToolPath("ffmpeg").catch(() => null)) ?? "ffmpeg";
  const inputArgs = [
    "-hide_banner",
    "-loglevel",
    "error",
    "-fflags",
    "+genpts",
    ...(seekSeconds > 0 ? ["-ss", String(seekSeconds)] : []),
    "-i",
    ffmpegPath(filePath),
  ];
  const transcodeArgs = buildPreviewTranscodeArgs(
    subTypeIndex !== null,
    subTypeIndex,
  );
  streamFfmpegPreview(res, ffmpegExecutable, [...inputArgs, ...transcodeArgs]);
}
