import { describe, expect, it } from "vitest";
import { mapDvdTitleSizes } from "./dvd-size-estimate";

describe("mapDvdTitleSizes", () => {
  it("does not invent a title size when the HandBrake title has no physical VTS mapping", () => {
    const result = mapDvdTitleSizes(
      [
        { titleNumber: 1, toolMappings: { physicalVtsNumber: null } },
        { titleNumber: 2, toolMappings: { physicalVtsNumber: null } },
        { titleNumber: 3, toolMappings: { physicalVtsNumber: null } },
      ],
      new Map([
        [1, 2_000],
        [2, 1_900],
        [3, 1_800],
      ]),
    );

    expect(result).toEqual([null, null, null]);
  });

  it("uses exact IFO/PGC/Cell sizes for shared physical VTS titles", () => {
    const result = mapDvdTitleSizes(
      [
        {
          titleNumber: 1,
          durationSeconds: 100,
          exactSizeBytes: 500,
          toolMappings: { physicalVtsNumber: 2 },
        },
        {
          titleNumber: 2,
          durationSeconds: 300,
          exactSizeBytes: 1_500,
          toolMappings: { physicalVtsNumber: 2 },
        },
        {
          titleNumber: 3,
          durationSeconds: 60,
          toolMappings: { physicalVtsNumber: 1 },
        },
      ],
      new Map([
        [1, 1_800],
        [2, 2_000],
      ]),
    );

    expect(result).toEqual([500, 1_500, null]);
  });

  it("refuses a shared VTS estimate when a logical duration is unknown", () => {
    const result = mapDvdTitleSizes(
      [
        {
          titleNumber: 1,
          durationSeconds: 100,
          toolMappings: { physicalVtsNumber: 2 },
        },
        {
          titleNumber: 2,
          durationSeconds: null,
          toolMappings: { physicalVtsNumber: 2 },
        },
      ],
      new Map([[2, 2_000]]),
    );

    expect(result).toEqual([null, null]);
  });
});
