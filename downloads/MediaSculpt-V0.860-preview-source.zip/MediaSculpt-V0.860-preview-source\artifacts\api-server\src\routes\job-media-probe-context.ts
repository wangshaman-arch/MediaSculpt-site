import { db, jobsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { mayAdoptMainTrackProbeDuration } from "../lib/disc-expectations";
import { selectBestAudioTrack } from "../lib/output-naming";
import { probeMediaStreams } from "./jobs-probe";
import type { ResolvedJob } from "./job-media-input-context";

type ProbeStream = {
  codecType?: string | null;
  codecName?: string | null;
  height?: number | null;
  channels?: number | null;
  bitRate?: number | string | null;
  tags?: { language?: string | null } | null;
};

export type MediaProbeSummary = {
  hasEmbeddedSubs: boolean;
  primaryAudioCodec: string | null;
  sourceHasAudio: boolean;
  probeVideoHeight: number | null;
  probeHasVideo: boolean;
};

type MediaProbeResult = {
  streams: unknown[];
  duration?: number | null;
};

export function summarizeMediaProbeStreams(
  streams: unknown[],
): MediaProbeSummary {
  const probeStreams = streams as ProbeStream[];
  const audioStreams = probeStreams.filter(
    (stream) => stream.codecType === "audio",
  );
  const bestAudioTrack = selectBestAudioTrack(
    audioStreams.map((stream) => ({
      codec: stream.codecName ?? null,
      channels: stream.channels ?? null,
      bitrate: Number(stream.bitRate) > 0 ? Number(stream.bitRate) : null,
      language: stream.tags?.language ?? null,
    })),
  );
  const videoStream = probeStreams.find(
    (stream) => stream.codecType === "video",
  );

  return {
    hasEmbeddedSubs: probeStreams.some(
      (stream) => stream.codecType === "subtitle",
    ),
    primaryAudioCodec: bestAudioTrack?.codec ?? null,
    sourceHasAudio: audioStreams.length > 0,
    probeVideoHeight:
      typeof videoStream?.height === "number" ? videoStream.height : null,
    probeHasVideo: Boolean(videoStream),
  };
}

export function resolveProbedDuration(input: {
  mediaType: string | null;
  hasTaskSnapshot: boolean;
  probeDuration: number | null | undefined;
  selectedTitleDurationSeconds: number | null;
}): number | null {
  if (
    !mayAdoptMainTrackProbeDuration({
      mediaType: input.mediaType,
      hasTaskSnapshot: input.hasTaskSnapshot,
    })
  ) {
    return input.selectedTitleDurationSeconds;
  }
  if (typeof input.probeDuration === "number" && input.probeDuration > 0)
    return input.probeDuration;
  return input.selectedTitleDurationSeconds;
}

export async function probeJobMedia(input: {
  jobId: number;
  job: ResolvedJob;
  mediaInputPath: string;
  taskSnapshotPresent: boolean;
  selectedDvdTitleNumber?: number | null;
  selectedTitleDurationSeconds: number | null;
  probeDvdTitleByNumber?: (
    sourcePath: string,
    titleNumber: number,
  ) => Promise<MediaProbeResult>;
}): Promise<MediaProbeSummary & { durationSeconds: number | null }> {
  let probe: MediaProbeResult;
  if (
    input.job.mediaType === "dvd" &&
    input.selectedDvdTitleNumber &&
    input.probeDvdTitleByNumber
  ) {
    try {
      probe = await input.probeDvdTitleByNumber(
        input.mediaInputPath,
        input.selectedDvdTitleNumber,
      );
    } catch {
      // Preserve the best-effort legacy probe as a diagnostic fallback. The
      // subtitle stage will independently probe the frozen title before it
      // decides that no subtitle track exists.
      probe = await probeMediaStreams(
        input.mediaInputPath,
        input.job.mediaType,
      );
    }
  } else {
    probe = await probeMediaStreams(input.mediaInputPath, input.job.mediaType);
  }
  const summary = summarizeMediaProbeStreams(
    Array.isArray(probe.streams) ? probe.streams : [],
  );
  const durationSeconds = resolveProbedDuration({
    mediaType: input.job.mediaType,
    hasTaskSnapshot: input.taskSnapshotPresent,
    probeDuration: probe.duration,
    selectedTitleDurationSeconds: input.selectedTitleDurationSeconds,
  });
  if (durationSeconds !== null) {
    input.job.durationSeconds = durationSeconds;
    await db
      .update(jobsTable)
      .set({ durationSeconds })
      .where(eq(jobsTable.id, input.jobId));
  }
  return { ...summary, durationSeconds };
}
