type Translate = (
  key: string,
  params?: Record<string, string | number>,
) => string;

const ENCODER_LABEL_KEYS: Record<string, string> = {
  x264_10bit: "settings.encoderX264",
  x264: "settings.encoderX264Plain",
  x265_10bit: "settings.encoderX265",
  x265: "settings.encoderX265Plain",
  av1: "settings.encoderAv1",
  vp9: "settings.encoderVp9",
};

const RESOLUTION_LABEL_KEYS: Record<string, string> = {
  source: "settings.resSourceShort",
  "2160p": "settings.res2160pShort",
  "1080p": "settings.res1080pShort",
  "720p": "settings.res720pShort",
  "576p": "settings.res576pShort",
  "480p": "settings.res480pShort",
};

export function compressionPresetSummary(
  values: { encoder: string; crf: number; outputResolution?: string },
  t?: Translate,
): string {
  const encoder = t
    ? t(ENCODER_LABEL_KEYS[values.encoder] ?? "settings.encoderUnknown")
    : values.encoder;
  const crf = t
    ? t("settings.crfShort", { value: values.crf })
    : `CRF ${values.crf}`;
  const resolution = values.outputResolution ?? "source";
  return `${encoder} · ${crf} · ${t ? t(RESOLUTION_LABEL_KEYS[resolution] ?? "settings.resolutionUnknown") : resolution}`;
}

export function customPresetSummary(
  values: { encoder: string; crf: string | number; outputResolution?: string },
  t?: Translate,
): string {
  const crf =
    values.crf === "" || values.crf === null || values.crf === undefined
      ? "--"
      : values.crf;
  if (!t)
    return `${values.encoder || "source"} · CRF ${crf} · ${values.outputResolution || "source"}`;
  const encoder = t(
    ENCODER_LABEL_KEYS[values.encoder] ?? "settings.encoderUnknown",
  );
  const resolution = t(
    RESOLUTION_LABEL_KEYS[values.outputResolution || "source"] ??
      "settings.resolutionUnknown",
  );
  return `${encoder} · ${t("settings.crfShort", { value: crf })} · ${resolution}`;
}
