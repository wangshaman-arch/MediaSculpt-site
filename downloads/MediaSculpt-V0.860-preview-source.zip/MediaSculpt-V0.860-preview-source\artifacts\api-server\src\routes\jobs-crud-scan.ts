import { Router } from "express";
import path from "path";
import fs from "fs/promises";
import { db, jobsTable } from "@workspace/db";
import { ScanDirectoryBody } from "@workspace/api-zod";
import {
  normalizeRequestedProcessingMode,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { buildSourceManifest } from "../lib/source-manifest";
import { resolveRuntimePath } from "../lib/runtime-paths";
import { getConfig } from "./jobs-config";
import { isBlurayDisc, isDvdDisc, resolveMainTrack } from "../lib/disc";
import { VIDEO_EXTENSIONS } from "../lib/media-extensions";

const router = Router();
router.post("/jobs/scan", async (req, res) => {
  const parsed = ScanDirectoryBody.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "请求体无效" });
  }

  const {
    directory,
    recursive,
    subtitleMode = "auto",
    processingMode = "compress",
  } = parsed.data;
  const config = await getConfig();
  const runtimeDirectory = resolveRuntimePath(directory, config);

  interface DiscoveredItem {
    filePath: string;
    mediaType: "video" | "bluray" | "dvd" | "iso";
    mainTrackPath?: string;
    processingMode: WorkflowProcessingMode;
    subtitleMode:
      | "auto"
      | "extract"
      | "whisper"
      | "transcribe_translate"
      | "skip"
      | "ocr"
      | "bilingual";
  }

  async function scanDir(dir: string): Promise<DiscoveredItem[]> {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    const items: DiscoveredItem[] = [];

    // Check if this directory is a disc root first
    if (await isBlurayDisc(dir)) {
      const mainTrackPath = await resolveMainTrack(dir, "bluray");
      const itemProcessingMode = normalizeRequestedProcessingMode({
        mediaType: "bluray",
        processingMode,
      });
      items.push({
        filePath: dir,
        mediaType: "bluray",
        mainTrackPath,
        processingMode: itemProcessingMode,
        subtitleMode: itemProcessingMode === "remux" ? "skip" : subtitleMode,
      });
      return items; // don't recurse into disc folders
    }
    if (await isDvdDisc(dir)) {
      const mainTrackPath = await resolveMainTrack(dir, "dvd");
      const itemProcessingMode = normalizeRequestedProcessingMode({
        mediaType: "dvd",
        processingMode,
      });
      items.push({
        filePath: dir,
        mediaType: "dvd",
        mainTrackPath,
        processingMode: itemProcessingMode,
        subtitleMode: itemProcessingMode === "remux" ? "skip" : subtitleMode,
      });
      return items;
    }

    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (recursive) items.push(...(await scanDir(fullPath)));
      } else if (entry.isFile()) {
        const ext = path.extname(entry.name).toLowerCase();
        if (!VIDEO_EXTENSIONS.includes(ext)) continue;
        if (ext === ".iso") {
          const itemProcessingMode = normalizeRequestedProcessingMode({
            mediaType: "iso",
            processingMode,
          });
          items.push({
            filePath: fullPath,
            mediaType: "iso",
            processingMode: itemProcessingMode,
            subtitleMode:
              itemProcessingMode === "remux" ? "skip" : subtitleMode,
          });
        } else if (ext === ".m2ts" || ext === ".ts") {
          // Standalone BD transport stream
          const itemProcessingMode = normalizeRequestedProcessingMode({
            mediaType: "bluray",
            processingMode,
          });
          items.push({
            filePath: fullPath,
            mediaType: "bluray",
            processingMode: itemProcessingMode,
            subtitleMode:
              itemProcessingMode === "remux" ? "skip" : subtitleMode,
          });
        } else if (ext === ".vob") {
          const itemProcessingMode = normalizeRequestedProcessingMode({
            mediaType: "dvd",
            processingMode,
          });
          items.push({
            filePath: fullPath,
            mediaType: "dvd",
            processingMode: itemProcessingMode,
            subtitleMode:
              itemProcessingMode === "remux" ? "skip" : subtitleMode,
          });
        } else {
          items.push({
            filePath: fullPath,
            mediaType: "video",
            processingMode,
            subtitleMode: processingMode === "remux" ? "skip" : subtitleMode,
          });
        }
      }
    }
    return items;
  }

  let items: DiscoveredItem[] = [];
  try {
    items = await scanDir(runtimeDirectory);
  } catch (e) {
    return res.status(400).json({ error: `无法扫描目录：${String(e)}` });
  }

  const existing = await db.select({ fp: jobsTable.filePath }).from(jobsTable);
  const existingSet = new Set(
    existing.map((r: (typeof existing)[number]) => r.fp),
  );

  let created = 0;
  let skipped = 0;
  const createdFiles: string[] = [];

  for (const item of items) {
    if (existingSet.has(item.filePath)) {
      skipped++;
    } else {
      await db.insert(jobsTable).values({
        filePath: item.filePath,
        subtitleMode: item.subtitleMode,
        mediaType: item.mediaType,
        mainTrackPath: item.mainTrackPath ?? null,
        processingMode: item.processingMode,
        legacyTask: true,
        sourceManifest: JSON.stringify(
          buildSourceManifest({
            filePath: item.filePath,
            mediaType: item.mediaType,
            mainTrackPath: item.mainTrackPath ?? null,
          }),
        ),
      });
      created++;
      createdFiles.push(item.filePath);
    }
  }

  return res.json({
    found: items.length,
    created,
    skipped,
    files: createdFiles,
  });
});

export const jobsCrudScanRouter = router;
