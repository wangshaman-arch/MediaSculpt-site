import { Router } from "express";
import path from "path";
import { db, jobsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  loadTaskSnapshot,
  serializeTaskSnapshot,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  buildCompressionOutputName,
  buildRemuxOutputName,
  encoderBitDepth,
} from "../lib/output-naming";
import { dvdOutputBaseName } from "../lib/dvd-source-identity";
import { addLog } from "../lib/job-logging";
import { getConfig } from "./jobs-config";
import {
  defaultTaskSnapshotOutputMode,
  normalizePipelineSteps,
  parsePipelineNames,
  parsePipelineSteps,
} from "./jobs-pipeline";
import { snapshotTitleIndex } from "./jobs-ffmpeg-run";

const router = Router();
// PATCH /jobs/:id/execution - apply assistant-confirmed execution options.
// Pending/queued/error jobs are updated in place (and reset to pending when
// they previously errored); completed jobs are cloned into a new pending job
// so the newly confirmed options actually run.
router.patch("/jobs/:id/execution", async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0)
    return res.status(400).json({ error: "invalid job id" });

  const rows = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, id))
    .limit(1);
  if (!rows.length) return res.status(404).json({ error: "job not found" });
  const job = rows[0];
  if (
    ["scanning", "transcribing", "compressing", "remuxing"].includes(job.status)
  ) {
    return res.status(409).json({ error: "job is running" });
  }

  const raw = (req.body ?? {}) as Record<string, unknown>;
  const requestedPipelineSteps = Array.isArray(raw.pipelineSteps)
    ? raw.pipelineSteps.filter(
        (step): step is string => typeof step === "string",
      )
    : undefined;
  const requestedSubtitleMode =
    typeof raw.subtitleMode === "string" ? raw.subtitleMode : undefined;
  const requestedPresetId = Object.prototype.hasOwnProperty.call(
    raw,
    "presetId",
  )
    ? typeof raw.presetId === "string" && raw.presetId.trim()
      ? raw.presetId.trim()
      : null
    : undefined;
  const requestedCompressionSettings = (() => {
    const value = raw.compressionSettings;
    if (!value || typeof value !== "object" || Array.isArray(value))
      return null;
    const source = value as Record<string, unknown>;
    const result: Record<string, string | number> = {};
    for (const key of [
      "encoder",
      "encoderPreset",
      "encoderTune",
      "encoderProfile",
      "encoderLevel",
      "frameRate",
      "outputResolution",
    ]) {
      if (typeof source[key] === "string" && source[key].trim())
        result[key] = source[key].trim();
    }
    if (typeof source.crf === "number" && Number.isFinite(source.crf))
      result.crf = source.crf;
    return Object.keys(result).length > 0 ? result : null;
  })();
  const requestedChapterSamplePosition =
    raw.chapterSamplePosition === "middle" ||
    raw.chapterSamplePosition === "start" ||
    raw.chapterSamplePosition === "end"
      ? raw.chapterSamplePosition
      : undefined;
  const movieTitle =
    typeof raw.movieTitle === "string" && raw.movieTitle.trim()
      ? raw.movieTitle.trim()
      : undefined;
  const movieTitleEn =
    typeof raw.movieTitleEn === "string" && raw.movieTitleEn.trim()
      ? raw.movieTitleEn.trim()
      : undefined;
  const movieYear = Object.prototype.hasOwnProperty.call(raw, "movieYear")
    ? typeof raw.movieYear === "number" && Number.isFinite(raw.movieYear)
      ? raw.movieYear
      : raw.movieYear === null
        ? null
        : undefined
    : undefined;
  const movieImdbId = Object.prototype.hasOwnProperty.call(raw, "movieImdbId")
    ? typeof raw.movieImdbId === "string" &&
      /^tt\d{7,8}$/i.test(raw.movieImdbId.trim())
      ? raw.movieImdbId.trim()
      : raw.movieImdbId === null
        ? null
        : undefined
    : undefined;

  const allowedSubtitleModes = [
    "auto",
    "extract",
    "whisper",
    "transcribe_translate",
    "skip",
    "ocr",
    "bilingual",
  ];
  if (
    requestedSubtitleMode !== undefined &&
    !allowedSubtitleModes.includes(requestedSubtitleMode)
  ) {
    return res.status(400).json({ error: "invalid subtitleMode" });
  }

  const config = await getConfig();
  const currentSteps = parsePipelineSteps(job);
  const currentNames = parsePipelineNames(job);
  const steps =
    requestedPipelineSteps !== undefined
      ? normalizePipelineSteps(requestedPipelineSteps, job.mediaType ?? "video")
      : currentSteps;
  const stepsChanged =
    requestedPipelineSteps !== undefined &&
    JSON.stringify(steps) !== JSON.stringify(currentSteps);

  let selectionPlan: Record<string, unknown> | null = null;
  try {
    selectionPlan = job.selectionPlan
      ? (JSON.parse(job.selectionPlan) as Record<string, unknown>)
      : null;
  } catch {
    selectionPlan = null;
  }
  const currentPresetId =
    selectionPlan && typeof selectionPlan.presetId === "string"
      ? selectionPlan.presetId
      : null;
  const presetChanged =
    requestedPresetId !== undefined &&
    (requestedPresetId ?? null) !== currentPresetId;

  const finalSubtitleMode =
    steps.length > 0 && !steps.includes("subtitle")
      ? "skip"
      : requestedSubtitleMode !== undefined
        ? requestedSubtitleMode
        : (job.subtitleMode ?? "auto");
  const subtitleChanged =
    requestedSubtitleMode !== undefined &&
    finalSubtitleMode !== (job.subtitleMode ?? "auto");

  // 用户明确提交空流水线（如关闭压缩/Remux/字幕）时，处理模式应为 none：
  // 只做元数据/AI 生成，不执行任何视频处理。
  const processingMode =
    steps.length > 0
      ? steps.includes("chapterPreview")
        ? "chapterPreview"
        : steps.includes("compress")
          ? "compress"
          : steps.includes("remux")
            ? "remux"
            : "none"
      : requestedPipelineSteps !== undefined
        ? "none"
        : (job.processingMode ?? "compress");
  const processingChanged =
    processingMode !== (job.processingMode ?? "compress");

  const metadataChanged =
    movieTitle !== undefined ||
    movieTitleEn !== undefined ||
    movieYear !== undefined ||
    movieImdbId !== undefined;
  const compressionSettingsChanged = requestedCompressionSettings !== null;
  const executionChanged =
    stepsChanged ||
    subtitleChanged ||
    presetChanged ||
    processingChanged ||
    compressionSettingsChanged;
  if (!executionChanged && !metadataChanged) {
    return res.status(200).json({ id, recreated: false, unchanged: true, job });
  }

  let snapshot: TaskSnapshotV1 | null = null;
  try {
    snapshot = loadTaskSnapshot(job);
  } catch {
    snapshot = null;
  }

  const outputMode =
    steps.length > 0
      ? defaultTaskSnapshotOutputMode({
          processingMode,
          subtitleMode: finalSubtitleMode,
        })
      : null;
  const mediaType = job.mediaType ?? "video";
  const rawBaseName = path.basename(job.filePath ?? "");
  const baseName =
    mediaType === "dvd"
      ? dvdOutputBaseName({
          sourcePath: job.filePath ?? "",
          mediaType: "dvd",
          titleNumber:
            snapshot?.toolSelections.handbrakeTitleNumber ??
            snapshot?.toolSelections.dvdVtsNumber,
          titleCount: 1,
        })
      : /^(VIDEO_TS|BDMV)$/i.test(rawBaseName)
        ? path.basename(path.dirname(job.filePath ?? ""))
        : path.basename(job.filePath ?? "", path.extname(job.filePath ?? ""));
  const titleIndex = snapshotTitleIndex(snapshot);
  const outputBase =
    mediaType === "dvd"
      ? baseName
      : `${baseName}${titleIndex >= 0 ? `.Title${String(titleIndex + 1).padStart(2, "0")}` : ""}`;
  const buildCompressName = () =>
    buildCompressionOutputName({
      baseName: outputBase,
      mediaType,
      outputFormat: config.outputFormat ?? "mkv",
      encoder: config.encoder,
      crf: config.crf,
      primaryAudioCodec: null,
      bitDepth: encoderBitDepth(config.encoder),
      template: config.outputNameTemplate,
    });
  const names = {
    remux: steps.includes("remux")
      ? (currentNames.remux ??
        buildRemuxOutputName(
          outputBase,
          mediaType,
          config.outputFormat ?? "mkv",
          config.outputNameTemplate,
        ))
      : null,
    compress: steps.includes("compress")
      ? (currentNames.compress ?? buildCompressName())
      : null,
  };

  let nextSnapshot: TaskSnapshotV1 | null = snapshot;
  if (snapshot && executionChanged) {
    const nextMode = outputMode ?? snapshot.outputMode;
    const modeChanged = nextMode !== snapshot.outputMode;
    const nextFileName = modeChanged
      ? outputMode === "remux"
        ? buildRemuxOutputName(
            outputBase,
            mediaType,
            config.outputFormat ?? "mkv",
            config.outputNameTemplate,
          )
        : outputMode === "compress"
          ? buildCompressName()
          : `${outputBase}.MediaSculpt.srt`
      : snapshot.output.fileName;
    // Remux 输出目录始终跟随当前配置（默认“与源文件同目录”），避免克隆/确认
    // 旧任务时沿用旧快照里冻结的目录。字幕目录同步跟随。
    const nextOutputDirectory =
      nextMode === "remux"
        ? (config.remuxOutputDirectory ?? config.outputDirectory)
        : snapshot.output.directory;
    const nextSubtitleDirectory =
      nextMode === "remux"
        ? (config.subtitleDirectory ?? "")
        : snapshot.output.subtitleDirectory;
    nextSnapshot = {
      ...snapshot,
      outputMode: nextMode,
      compression: compressionSettingsChanged
        ? { ...snapshot.compression, ...requestedCompressionSettings }
        : snapshot.compression,
      output: {
        ...snapshot.output,
        fileName: nextFileName,
        directory: nextOutputDirectory,
        subtitleDirectory: nextSubtitleDirectory,
      },
    };
  }

  const nextSelectionPlan =
    selectionPlan &&
    (requestedPresetId !== undefined ||
      requestedChapterSamplePosition !== undefined ||
      (requestedPipelineSteps !== undefined && steps.length > 0))
      ? JSON.stringify({
          ...selectionPlan,
          ...(requestedPipelineSteps !== undefined && steps.length > 0
            ? { needsUserSelection: false }
            : {}),
          ...(requestedPresetId !== undefined
            ? { presetId: requestedPresetId ?? null }
            : {}),
          ...(requestedChapterSamplePosition !== undefined
            ? { chapterSamplePosition: requestedChapterSamplePosition }
            : {}),
        })
      : (job.selectionPlan ?? undefined);
  const nextPipelineJson =
    steps.length > 0 ? JSON.stringify({ steps, names }) : null;

  const rowUpdates: Partial<typeof jobsTable.$inferInsert> = {
    pipelineSteps:
      requestedPipelineSteps !== undefined ? nextPipelineJson : undefined,
    processingMode: processingChanged ? processingMode : undefined,
    subtitleMode: subtitleChanged ? finalSubtitleMode : undefined,
    ocrEngine:
      subtitleChanged && finalSubtitleMode === "ocr"
        ? (job.ocrEngine ?? "auto")
        : undefined,
    ocrLanguage:
      subtitleChanged && finalSubtitleMode === "ocr"
        ? (job.ocrLanguage ?? "auto")
        : undefined,
    selectionPlan:
      requestedPresetId !== undefined ||
      requestedChapterSamplePosition !== undefined
        ? nextSelectionPlan
        : undefined,
    movieTitle: movieTitle !== undefined ? movieTitle : undefined,
    movieTitleEn: movieTitleEn !== undefined ? movieTitleEn : undefined,
    movieYear: movieYear !== undefined ? movieYear : undefined,
    movieImdbId: movieImdbId !== undefined ? movieImdbId : undefined,
    taskSnapshot: nextSnapshot
      ? serializeTaskSnapshot(nextSnapshot)
      : undefined,
    taskSnapshotVersion: nextSnapshot?.snapshotVersion ?? undefined,
  };

  if (job.status === "done") {
    if (!executionChanged) {
      // 已完成任务的执行计划是历史事实，确认时只能改元数据（片名/年代），
      // 绝不允许原地改写 processingMode/pipeline/subtitle/taskSnapshot，
      // 否则记录会与真实输出不一致（例如“压缩”任务实际输出了 Remux）。
      const metadataOnly: Partial<typeof jobsTable.$inferInsert> = {};
      if (movieTitle !== undefined) metadataOnly.movieTitle = movieTitle;
      if (movieTitleEn !== undefined) metadataOnly.movieTitleEn = movieTitleEn;
      if (movieYear !== undefined) metadataOnly.movieYear = movieYear;
      if (movieImdbId !== undefined) metadataOnly.movieImdbId = movieImdbId;
      if (Object.keys(metadataOnly).length === 0) {
        return res
          .status(200)
          .json({ id, recreated: false, unchanged: true, job });
      }
      await db.update(jobsTable).set(metadataOnly).where(eq(jobsTable.id, id));
      const [updated] = await db
        .select()
        .from(jobsTable)
        .where(eq(jobsTable.id, id))
        .limit(1);
      return res.json({ id, recreated: false, job: updated });
    }
    const [cloned] = await db
      .insert(jobsTable)
      .values({
        filePath: job.filePath,
        status: "pending",
        subtitleMode: subtitleChanged
          ? finalSubtitleMode
          : (job.subtitleMode ?? "auto"),
        ocrEngine:
          finalSubtitleMode === "ocr" ? (job.ocrEngine ?? "auto") : null,
        ocrLanguage:
          finalSubtitleMode === "ocr" ? (job.ocrLanguage ?? "auto") : null,
        generateReadme: job.generateReadme ?? false,
        generatePoster: job.generatePoster ?? false,
        generateReview: job.generateReview ?? false,
        processingMode,
        mediaType: job.mediaType ?? "video",
        mainTrackPath: job.mainTrackPath,
        movieTitle: movieTitle !== undefined ? movieTitle : job.movieTitle,
        movieTitleEn:
          movieTitleEn !== undefined ? movieTitleEn : job.movieTitleEn,
        movieYear: movieYear !== undefined ? movieYear : job.movieYear,
        movieImdbId: movieImdbId !== undefined ? movieImdbId : job.movieImdbId,
        movieOverview: job.movieOverview,
        moviePoster: job.moviePoster,
        selectedStreams: job.selectedStreams,
        selectedChapters: job.selectedChapters,
        sourceManifest: job.sourceManifest,
        selectionPlan:
          requestedPresetId !== undefined
            ? nextSelectionPlan
            : job.selectionPlan,
        taskSnapshot: nextSnapshot
          ? serializeTaskSnapshot(nextSnapshot)
          : job.taskSnapshot,
        taskSnapshotVersion:
          nextSnapshot?.snapshotVersion ?? job.taskSnapshotVersion,
        legacyTask: job.legacyTask ?? false,
        pipelineSteps: nextPipelineJson,
        durationSeconds: job.durationSeconds,
        hasEmbeddedSubtitles: job.hasEmbeddedSubtitles,
        fileSizeBefore: job.fileSizeBefore,
      })
      .returning();
    await addLog(
      cloned.id,
      "info",
      `rebuilt job #${id} with confirmed options: mode=${processingMode} pipeline=${steps.join("->") || "none"}`,
    );
    return res
      .status(201)
      .json({ id: cloned.id, recreated: true, job: cloned });
  }

  if (job.status === "error") {
    rowUpdates.status = "pending";
    rowUpdates.errorMessage = null;
    rowUpdates.progress = null;
    rowUpdates.startedAt = null;
    rowUpdates.completedAt = null;
  }
  await db.update(jobsTable).set(rowUpdates).where(eq(jobsTable.id, id));
  const [updated] = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, id))
    .limit(1);
  await addLog(
    id,
    "info",
    `applied confirmed options: mode=${processingMode} pipeline=${steps.join("->") || "none"}`,
  );
  return res.json({ id, recreated: false, job: updated });
});

export const jobsCrudExecutionRouter = router;
