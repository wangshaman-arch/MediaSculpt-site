import { describe, expect, it } from "vitest";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import {
  activateManagedToolDirectory,
  executableName,
  managedToolDirectory,
  resolveToolPath,
  seedBundledTools,
} from "./tool-runtime";

describe("native tool runtime", () => {
  it("uses platform-specific executable names", () => {
    expect(executableName("ffmpeg", "win32")).toBe("ffmpeg.exe");
    expect(executableName("ffmpeg", "darwin")).toBe("ffmpeg");
    expect(executableName("handbrake", "win32")).toBe("HandBrakeCLI.exe");
    expect(executableName("libretranslate", "win32")).toBe(
      "libretranslate.exe",
    );
    expect(executableName("whisper", "win32")).toBe("python.exe");
    expect(executableName("tesseract", "win32")).toBe("tesseract.exe");
  });

  it("reports Tesseract in tool statuses and discovers system installs on Windows", async () => {
    const runtime = await fs.readFile(
      path.join(import.meta.dirname, "tool-runtime.ts"),
      "utf8",
    );
    expect(runtime).toContain('["tesseract", false]');
    expect(runtime).toContain("systemTesseractPath");
    expect(runtime).toContain("Program Files\\\\Tesseract-OCR");
  });

  it("keeps tools in a managed per-platform directory", () => {
    expect(managedToolDirectory("win32", "C:\\Users\\tester")).toContain(
      "MediaSculpt",
    );
    expect(managedToolDirectory("darwin", "/Users/tester")).toBe(
      path.join(
        "/Users/tester",
        "Library",
        "Application Support",
        "MediaSculpt",
        "tools",
      ),
    );
    expect(managedToolDirectory("linux", "/home/tester")).toBe(
      path.join("/home/tester", ".local", "share", "MediaSculpt", "tools"),
    );
  });

  it("adds the managed directory to PATH for child processes", () => {
    const original = process.env.PATH;
    process.env.PATH = "/usr/bin";
    activateManagedToolDirectory();
    expect(process.env.PATH?.split(path.delimiter)[0]).toBe(
      managedToolDirectory(),
    );
    process.env.PATH = original;
  });

  it("detects tools that are already available on PATH", async () => {
    const originalPath = process.env.PATH;
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-tool-path-"));
    const executable = path.join(dir, executableName("ffmpeg"));
    try {
      await fs.writeFile(executable, "#!/bin/sh\nexit 0\n", "utf8");
      await fs.chmod(executable, 0o755);
      process.env.PATH = dir;

      await expect(resolveToolPath("ffmpeg")).resolves.toBe(executable);
    } finally {
      process.env.PATH = originalPath;
    }
  });

  it("finds managed tools inside extracted versioned folders", async () => {
    const originalToolsDir = process.env.VX_AGENT_TOOLS_DIR;
    const root = await fs.mkdtemp(path.join(os.tmpdir(), "vx-managed-tools-"));
    try {
      process.env.VX_AGENT_TOOLS_DIR = root;
      const nested = path.join(
        root,
        "ffmpeg",
        "ffmpeg-8.1.2-essentials_build",
        "bin",
      );
      await fs.mkdir(nested, { recursive: true });
      const executable = path.join(nested, "ffprobe");
      await fs.writeFile(executable, "#!/bin/sh\nexit 0\n", "utf8");
      await fs.chmod(executable, 0o755);
      await expect(resolveToolPath("ffprobe", "darwin")).resolves.toBe(
        executable,
      );
    } finally {
      if (originalToolsDir === undefined) delete process.env.VX_AGENT_TOOLS_DIR;
      else process.env.VX_AGENT_TOOLS_DIR = originalToolsDir;
    }
  });

  it("seeds bundled tools before resolving them from the managed directory", async () => {
    const originalToolsDir = process.env.MEDIASCULPT_TOOLS_DIR;
    const originalResourceDir = process.env.MEDIASCULPT_RESOURCE_DIR;
    const root = await fs.mkdtemp(
      path.join(os.tmpdir(), "mediasculpt-seed-tools-"),
    );
    const bundled = path.join(root, "resources", "tools", "ffmpeg", "bin");
    const managed = path.join(root, "managed");
    try {
      await fs.mkdir(bundled, { recursive: true });
      await fs.writeFile(
        path.join(bundled, "ffmpeg"),
        "#!/bin/sh\nexit 0\n",
        "utf8",
      );
      process.env.MEDIASCULPT_RESOURCE_DIR = path.join(root, "resources");
      process.env.MEDIASCULPT_TOOLS_DIR = managed;

      await seedBundledTools();

      await expect(resolveToolPath("ffmpeg", "darwin")).resolves.toBe(
        path.join(managed, "ffmpeg", "bin", "ffmpeg"),
      );
    } finally {
      if (originalToolsDir === undefined)
        delete process.env.MEDIASCULPT_TOOLS_DIR;
      else process.env.MEDIASCULPT_TOOLS_DIR = originalToolsDir;
      if (originalResourceDir === undefined)
        delete process.env.MEDIASCULPT_RESOURCE_DIR;
      else process.env.MEDIASCULPT_RESOURCE_DIR = originalResourceDir;
      await fs.rm(root, { recursive: true, force: true });
    }
  });
});
