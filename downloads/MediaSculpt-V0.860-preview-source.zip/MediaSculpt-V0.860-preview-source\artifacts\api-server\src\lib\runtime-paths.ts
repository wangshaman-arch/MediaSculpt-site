import path from "path";

export type RuntimePathConfig = {
  watchDirectory?: string | null;
  outputDirectory?: string | null;
  hostDownloadsPath?: string | null;
  hostOutputPath?: string | null;
};

export function stripTrailingSeparators(p: string): string {
  if (/^[A-Za-z]:[\\/]?$/.test(p)) return p.slice(0, 2);
  const stripped = p.replace(/[\\/]+$/, "");
  return stripped || p;
}

export function isWindowsAbsolutePath(p: string): boolean {
  return /^[A-Za-z]:[\\/]/.test(p) || /^\\\\/.test(p);
}

export function isLinuxAbsolutePath(p: string): boolean {
  return /^\/[^/]/.test(p);
}

function joinMappedPath(
  prefix: string,
  rel: string,
  separator: "/" | "\\",
): string {
  if (!rel) return prefix;
  const base = stripTrailingSeparators(prefix);
  return `${base}${separator}${rel.replace(/[\\/]+/g, separator)}`;
}

function mapByPrefix(
  value: string,
  fromPrefix: string | null | undefined,
  toPrefix: string | null | undefined,
  separator: "/" | "\\",
): string | null {
  if (!fromPrefix || !toPrefix) return null;

  const valueNorm = value.replace(/\\/g, "/");
  const fromNorm = stripTrailingSeparators(fromPrefix).replace(/\\/g, "/");
  const valueCmp = stripTrailingSeparators(valueNorm).toLowerCase();
  const fromCmp = fromNorm.toLowerCase();

  if (valueCmp === fromCmp) return toPrefix;
  if (!valueCmp.startsWith(`${fromCmp}/`)) return null;

  const rel = valueNorm.slice(fromNorm.length).replace(/^\/+/, "");
  return joinMappedPath(toPrefix, rel, separator);
}

export function mapContainerToHostPath(
  value: string,
  cfg: RuntimePathConfig,
): string {
  const downloadsTarget =
    cfg.hostDownloadsPath ??
    (cfg.watchDirectory && isWindowsAbsolutePath(cfg.watchDirectory)
      ? cfg.watchDirectory
      : null);
  const outputTarget =
    cfg.hostOutputPath ??
    (cfg.outputDirectory && isWindowsAbsolutePath(cfg.outputDirectory)
      ? cfg.outputDirectory
      : null);
  const mappings: Array<
    [string | null | undefined, string | null | undefined]
  > = [];

  if (cfg.watchDirectory && isLinuxAbsolutePath(cfg.watchDirectory)) {
    mappings.push([cfg.watchDirectory, downloadsTarget]);
  }
  if (cfg.outputDirectory && isLinuxAbsolutePath(cfg.outputDirectory)) {
    mappings.push([cfg.outputDirectory, outputTarget]);
  }
  mappings.push(["/media/downloads", downloadsTarget]);
  mappings.push(["/media/output", outputTarget]);

  for (const [from, to] of mappings) {
    const mapped = mapByPrefix(value, from, to, "\\");
    if (mapped) return mapped;
  }
  return value;
}

export function mapHostToContainerPath(
  value: string,
  cfg: RuntimePathConfig,
): string {
  const watchTarget =
    cfg.watchDirectory && isLinuxAbsolutePath(cfg.watchDirectory)
      ? cfg.watchDirectory
      : "/media/downloads";
  const outputTarget =
    cfg.outputDirectory && isLinuxAbsolutePath(cfg.outputDirectory)
      ? cfg.outputDirectory
      : "/media/output";

  const mappings: Array<
    [string | null | undefined, string | null | undefined]
  > = [
    [cfg.hostDownloadsPath, watchTarget],
    [cfg.hostOutputPath, outputTarget],
  ];

  for (const [from, to] of mappings) {
    const mapped = mapByPrefix(value, from, to, "/");
    if (mapped) return mapped;
  }
  return value;
}

export function resolveRuntimePath(
  value: string,
  cfg: RuntimePathConfig,
  platform = process.platform,
): string {
  if (platform === "win32") {
    return mapContainerToHostPath(value, cfg);
  }
  if (isWindowsAbsolutePath(value)) {
    return mapHostToContainerPath(value, cfg);
  }
  return value;
}

export function resolveOutputDir(
  rawPath: string,
  cfg?: RuntimePathConfig,
  platform = process.platform,
): string {
  const runtimePath = cfg
    ? resolveRuntimePath(rawPath, cfg, platform)
    : rawPath;
  if (
    platform === "win32" &&
    /^[/\\]/.test(runtimePath) &&
    !/^[A-Za-z]:/.test(runtimePath)
  ) {
    return path.join(process.cwd(), "..", "..", "output");
  }
  return runtimePath;
}

export function ffmpegPath(p: string, platform = process.platform): string {
  return platform === "win32" ? p.replace(/\\/g, "/") : p;
}

export function escapeFfconcatPath(
  p: string,
  platform = process.platform,
): string {
  const normalized = ffmpegPath(p, platform);
  return `'${normalized.replace(/'/g, "'\\''")}'`;
}

export function buildFfconcatFileContent(
  files: string[],
  platform = process.platform,
): string {
  return [
    "ffconcat version 1.0",
    ...files.map((file) => `file ${escapeFfconcatPath(file, platform)}`),
    "",
  ].join("\n");
}
