import type { ChildProcess } from "node:child_process";
import { jobProcessController } from "../infrastructure/job-process-controller";
import {
  BoundedOutput,
  DEFAULT_MAX_OUTPUT_BYTES,
} from "../infrastructure/process-runner";

export interface JobProcessSpawner {
  spawnForJob(jobId: number, executable: string, args: string[]): ChildProcess;
}

export class JobToolExecutor {
  constructor(
    private readonly processes: JobProcessSpawner = jobProcessController,
  ) {}

  /**
   * Run a job tool and collect its output. Long media commands (FFmpeg, Whisper,
   * OCR) can emit far more than the process heap can hold, so stdout/stderr are
   * bounded to the tail instead of accumulating without limit.
   */
  run(
    jobId: number,
    executable: string,
    args: string[],
    options?: { maxOutputBytes?: number },
  ): Promise<{ stdout: string; stderr: string }> {
    const maxBytes =
      Number.isFinite(options?.maxOutputBytes) &&
      (options?.maxOutputBytes ?? 0) > 0
        ? Math.floor(options!.maxOutputBytes as number)
        : DEFAULT_MAX_OUTPUT_BYTES;
    return new Promise((resolve, reject) => {
      const child = this.processes.spawnForJob(jobId, executable, args);
      const stdout = new BoundedOutput(maxBytes);
      const stderr = new BoundedOutput(maxBytes);
      let settled = false;
      const fail = (error: Error) => {
        if (settled) return;
        settled = true;
        reject(error);
      };
      child.stdout?.on("data", (data) => stdout.append(data));
      child.stderr?.on("data", (data) => stderr.append(data));
      child.once("error", (error) => fail(error));
      child.once("close", (code) => {
        if (settled) return;
        settled = true;
        if (code === 0) {
          resolve({ stdout: stdout.toString(), stderr: stderr.toString() });
          return;
        }
        reject(
          new Error(
            stderr.toString().trim().split(/\r?\n/).slice(-4).join(" ") ||
              `命令退出码 ${code}`,
          ),
        );
      });
    });
  }
}

export const jobToolExecutor = new JobToolExecutor();
