@echo off
rem MediaSculpt-Release: 2026.09.25.860
setlocal EnableExtensions
cd /d "%~dp0"

set "LOG=%~dp0mediasculpt-diagnostics.log"
>> "%LOG%" echo.
>> "%LOG%" echo ===== ROOT LAUNCHER =====
>> "%LOG%" echo MediaSculpt startup diagnostics
>> "%LOG%" echo Release: 2026.09.25.860
>> "%LOG%" echo Project directory: %~dp0
>> "%LOG%" echo [%date% %time%] launcher started

if not exist "%~dp0windows-setup\hidden-launcher.vbs" (
  >> "%LOG%" echo [ERROR] Missing windows-setup\hidden-launcher.vbs
  exit /b 1
)

where wscript.exe >> "%LOG%" 2>&1
if errorlevel 1 (
  >> "%LOG%" echo [ERROR] Windows Script Host was not found.
  exit /b 1
)

start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0scripts\start-dev.ps1"
>> "%LOG%" echo [%date% %time%] native launcher requested
exit /b 0
