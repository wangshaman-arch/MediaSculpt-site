import fs from "node:fs/promises";
import path from "node:path";

/**
 * AACS-encrypted Blu-ray detection.
 *
 * MediaSculpt ships `libdvdcss-2.dll` for CSS-protected DVDs (HandBrake also
 * carries its own implementation), but it deliberately does NOT ship `libaacs`
 * or a `KEYDB.cfg` key database. libaacs contains no keys of its own, so
 * without that database an AACS-protected disc simply cannot be opened by any
 * tool in this application.
 *
 * Structure is a more reliable signal than tool output:
 *
 *   - `AACS/`     — the AACS directory, present on every AACS-protected disc,
 *                   with `Unit_Key_RO.inf` as the interchange key file.
 *   - `BDSVM/`    — BD+ virtual machine payload, present on BD+ titles.
 *
 * Verified against unencrypted retail Blu-ray rips: they carry `CERTIFICATE/`
 * but no `AACS/` and no `BDSVM/`, so this check does not misfire on them.
 */
export const AACS_DIRECTORY = "AACS";
export const BDSVM_DIRECTORY = "BDSVM";
export const AACS_UNIT_KEY_FILE = "Unit_Key_RO.inf";

/**
 * The stable warning code the analysis layer attaches when a disc looks
 * AACS-protected. Keeping it a code (not a sentence) lets the UI resolve the
 * user-visible text through the language packs, so the message is bilingual.
 */
export const BLURAY_ENCRYPTED_WARNING_CODE = "bluray-aacs-encrypted";

export type BlurayEncryptionDetection = {
  encrypted: boolean;
  /** Which marker produced the verdict, for diagnostics. */
  evidence: string | null;
};

const NOT_ENCRYPTED: BlurayEncryptionDetection = {
  encrypted: false,
  evidence: null,
};

async function pathExists(target: string): Promise<boolean> {
  try {
    await fs.stat(target);
    return true;
  } catch {
    return false;
  }
}

/**
 * Inspect a Blu-ray source (disc root or a `BDMV` directory) for AACS/BD+
 * markers. Never throws: an unreadable path is reported as "unknown", which we
 * treat as not encrypted so a transient IO error cannot masquerade as copy
 * protection.
 */
export async function detectBlurayEncryption(
  sourcePath: string,
): Promise<BlurayEncryptionDetection> {
  if (!sourcePath) return NOT_ENCRYPTED;
  // Accept either the disc root (which contains BDMV/) or the BDMV folder.
  const discRoot = /[\\/]BDMV[\\/]?$/i.test(sourcePath)
    ? path.dirname(sourcePath.replace(/[\\/]+$/, ""))
    : sourcePath;

  const aacsDir = path.join(discRoot, AACS_DIRECTORY);
  if (await pathExists(aacsDir)) {
    const unitKey = await pathExists(path.join(aacsDir, AACS_UNIT_KEY_FILE));
    return {
      encrypted: true,
      evidence: unitKey
        ? `${AACS_DIRECTORY}/${AACS_UNIT_KEY_FILE}`
        : `${AACS_DIRECTORY}/`,
    };
  }

  const bdsvmDir = path.join(discRoot, BDSVM_DIRECTORY);
  if (await pathExists(bdsvmDir)) {
    return { encrypted: true, evidence: `${BDSVM_DIRECTORY}/` };
  }

  return NOT_ENCRYPTED;
}
