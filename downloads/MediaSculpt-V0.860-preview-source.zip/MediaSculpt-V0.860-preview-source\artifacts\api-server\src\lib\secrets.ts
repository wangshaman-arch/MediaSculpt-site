import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { processRunner } from "../infrastructure/process-runner";

const DPAPI_PREFIX = "dpapi:";
const AES_PREFIX = "aes:";
const isWindows = process.platform === "win32";

/**
 * 非 Windows 平台的本地密钥：存于用户目录下的 0600 文件，用于 AES-256-GCM。
 * （Windows 仍用当前用户 DPAPI；这里只是替代"非 Windows 直接存明文"。）
 */
function localKeyPath(): string {
  const base =
    process.env.MEDIASCULPT_DATA_DIR ||
    process.env.VX_AGENT_DATA_DIR ||
    path.join(os.homedir(), ".mediasculpt");
  return path.join(base, "secret.key");
}

function localKey(): Buffer {
  const keyPath = localKeyPath();
  try {
    const existing = fs.readFileSync(keyPath);
    if (existing.length >= 32) return existing.subarray(0, 32);
  } catch {
    /* create below */
  }
  const key = crypto.randomBytes(32);
  fs.mkdirSync(path.dirname(keyPath), { recursive: true });
  fs.writeFileSync(keyPath, key, { mode: 0o600 });
  return key;
}

function runPowerShell(script: string, input: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const child = processRunner.spawn({
      executable: "powershell",
      args: [
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy",
        "Bypass",
        "-Command",
        script,
      ],
      stdin: input,
      maxOutputBytes: 64 * 1024,
      timeoutMs: 60_000,
      stage: "secret-protection",
    }).child;
    let out = "";
    let err = "";
    child.stdout?.on("data", (d: Buffer) => {
      out += d.toString();
    });
    child.stderr?.on("data", (d: Buffer) => {
      err += d.toString();
    });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) resolve(out.trim());
      else reject(new Error(err.trim() || `powershell exit ${code}`));
    });
  });
}

/** 加密秘密：Windows 用当前用户 DPAPI；其它平台用 AES-256-GCM（本地密钥文件）。 */
export async function encryptSecret(plain: string): Promise<string> {
  if (!plain) return "";
  if (!isWindows) {
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv("aes-256-gcm", localKey(), iv);
    const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
    const tag = cipher.getAuthTag();
    return `${AES_PREFIX}${iv.toString("base64")}:${enc.toString("base64")}:${tag.toString("base64")}`;
  }
  const script =
    "Add-Type -AssemblyName System.Security; " +
    "$b=[Text.Encoding]::UTF8.GetBytes(([Console]::In.ReadToEnd())); " +
    "[Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Protect($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser))";
  const b64 = await runPowerShell(script, plain);
  return `${DPAPI_PREFIX}${b64}`;
}

/** 解密秘密：dpapi:/aes: 前缀分别解密；无前缀视为旧明文原样返回（迁移前兼容）。 */
export async function decryptSecret(
  stored: string | null | undefined,
): Promise<string> {
  if (!stored) return "";
  if (stored.startsWith(DPAPI_PREFIX)) {
    // DPAPI 是 Windows 专属：在其它平台无法解密，明确报错而不是把 base64 当明文返回。
    if (!isWindows)
      throw new Error("该密钥由 Windows DPAPI 加密，无法在当前平台解密");
    const script =
      "Add-Type -AssemblyName System.Security; " +
      "$b=[Convert]::FromBase64String(([Console]::In.ReadToEnd())); " +
      "[Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser))";
    return runPowerShell(script, stored.slice(DPAPI_PREFIX.length));
  }
  if (stored.startsWith(AES_PREFIX)) {
    const [ivB64, dataB64, tagB64] = stored.slice(AES_PREFIX.length).split(":");
    const decipher = crypto.createDecipheriv(
      "aes-256-gcm",
      localKey(),
      Buffer.from(ivB64 ?? "", "base64"),
    );
    decipher.setAuthTag(Buffer.from(tagB64 ?? "", "base64"));
    return Buffer.concat([
      decipher.update(Buffer.from(dataB64 ?? "", "base64")),
      decipher.final(),
    ]).toString("utf8");
  }
  return stored;
}

export function isEncryptedSecret(stored: string | null | undefined): boolean {
  return Boolean(
    stored &&
    (stored.startsWith(DPAPI_PREFIX) || stored.startsWith(AES_PREFIX)),
  );
}
