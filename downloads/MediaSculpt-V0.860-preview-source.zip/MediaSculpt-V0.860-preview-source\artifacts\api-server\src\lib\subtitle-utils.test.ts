import { describe, expect, it } from "vitest";
import {
  assertUsableTranslatedTexts,
  chooseEmbeddedSubtitleAction,
  explicitTranslationFailureMessage,
  isGraphicSubtitleCodec,
  pickBestTextSubtitle,
  shouldExtractEmbeddedText,
  shouldFallbackToWhisper,
  shouldInspectExternalSubtitles,
  shouldOcrGraphicSubtitles,
  shouldPreserveEmbeddedChinese,
  shouldTranslateSubtitleText,
  subtitleModePolicy,
  subtitleOnlyOutputDisposition,
  type SubtitleTrack,
} from "./subtitle-utils";

describe("subtitle mode policy", () => {
  it("defines distinct, executable behavior for all six user-facing modes and skip", () => {
    const expectedPolicies = {
      auto: {
        inspectExternal: true,
        extractEmbeddedText: "if-detected",
        ocrGraphic: true,
        whisper: "when-no-subtitle",
        translateText: "when-available",
        preserveEmbeddedChinese: true,
      },
      ocr: {
        inspectExternal: false,
        extractEmbeddedText: "never",
        ocrGraphic: true,
        whisper: "never",
        translateText: "never",
        preserveEmbeddedChinese: false,
      },
      extract: {
        inspectExternal: true,
        extractEmbeddedText: "always-probe",
        ocrGraphic: false,
        whisper: "never",
        translateText: "never",
        preserveEmbeddedChinese: false,
      },
      whisper: {
        inspectExternal: false,
        extractEmbeddedText: "never",
        ocrGraphic: false,
        whisper: "always",
        translateText: "never",
        preserveEmbeddedChinese: false,
      },
      transcribe_translate: {
        inspectExternal: true,
        extractEmbeddedText: "always-probe",
        ocrGraphic: true,
        whisper: "when-no-subtitle",
        translateText: "when-available",
        preserveEmbeddedChinese: false,
      },
      bilingual: {
        inspectExternal: true,
        extractEmbeddedText: "always-probe",
        ocrGraphic: true,
        whisper: "when-no-subtitle",
        translateText: "when-available",
        preserveEmbeddedChinese: false,
      },
      skip: {
        inspectExternal: false,
        extractEmbeddedText: "never",
        ocrGraphic: false,
        whisper: "never",
        translateText: "never",
        preserveEmbeddedChinese: false,
      },
    } as const;
    for (const [mode, policy] of Object.entries(expectedPolicies)) {
      expect(subtitleModePolicy(mode)).toEqual(policy);
    }
    expect(shouldInspectExternalSubtitles("skip")).toBe(false);
    expect(
      shouldExtractEmbeddedText({
        mode: "transcribe_translate",
        hasEmbeddedSubs: false,
        isDvd: false,
      }),
    ).toBe(true);
    expect(
      shouldExtractEmbeddedText({
        mode: "auto",
        hasEmbeddedSubs: false,
        isDvd: false,
      }),
    ).toBe(false);
    expect(
      shouldExtractEmbeddedText({
        mode: "auto",
        hasEmbeddedSubs: false,
        isDvd: true,
      }),
    ).toBe(true);
    expect(shouldOcrGraphicSubtitles("transcribe_translate")).toBe(true);
    expect(shouldOcrGraphicSubtitles("extract")).toBe(false);
    expect(shouldPreserveEmbeddedChinese("auto")).toBe(true);
    expect(shouldPreserveEmbeddedChinese("transcribe_translate")).toBe(false);
    expect(
      shouldTranslateSubtitleText({ mode: "extract", hasSubtitle: true }),
    ).toBe(false);
    expect(
      shouldTranslateSubtitleText({
        mode: "transcribe_translate",
        hasSubtitle: true,
      }),
    ).toBe(true);
  });
});

describe("subtitle track classification", () => {
  it("does not treat a mixed PGS + SubRip file as speech-only", () => {
    const tracks: SubtitleTrack[] = [
      {
        streamIndex: 4,
        typeIndex: 0,
        codec: "hdmv_pgs_subtitle",
        language: "zh",
      },
      {
        streamIndex: 5,
        typeIndex: 1,
        codec: "subrip",
        language: "en",
        packetCount: 420,
      },
    ];
    expect(isGraphicSubtitleCodec(tracks[0].codec)).toBe(true);
    expect(isGraphicSubtitleCodec(tracks[1].codec)).toBe(false);
    expect(pickBestTextSubtitle(tracks)?.streamIndex).toBe(5);
  });

  it("returns no text track when all embedded subtitles are graphic", () => {
    expect(
      pickBestTextSubtitle([
        {
          streamIndex: 4,
          typeIndex: 0,
          codec: "hdmv_pgs_subtitle",
          language: "zh",
        },
        { streamIndex: 5, typeIndex: 1, codec: "dvd_subtitle", language: "en" },
      ]),
    ).toBeNull();
  });

  it("classifies DVB subtitles as graphic subtitles", () => {
    expect(isGraphicSubtitleCodec("dvb_subtitle")).toBe(true);
  });

  it("classifies HandBrake's bitmap label and PGS carrier as graphic", () => {
    expect(isGraphicSubtitleCodec("bitmap")).toBe(true);
    expect(isGraphicSubtitleCodec("sup")).toBe(true);
  });
});

describe("subtitle fallback policy", () => {
  it("does not switch a failed graphic-subtitle OCR attempt to Whisper", () => {
    expect(
      shouldFallbackToWhisper({
        mode: "auto",
        hasEmbeddedSubs: true,
        hasGraphicSubs: true,
        hasSubtitleOutput: false,
        embeddedChineseSkipped: false,
      }),
    ).toBe(false);
  });

  it("still allows Whisper when automatic mode has no subtitle track", () => {
    expect(
      shouldFallbackToWhisper({
        mode: "auto",
        hasEmbeddedSubs: false,
        hasGraphicSubs: false,
        hasSubtitleOutput: false,
        embeddedChineseSkipped: false,
      }),
    ).toBe(true);
  });

  it("uses Whisper for translation mode when the source has no subtitles", () => {
    expect(
      shouldFallbackToWhisper({
        mode: "transcribe_translate",
        hasEmbeddedSubs: false,
        hasGraphicSubs: false,
        hasSubtitleOutput: false,
        embeddedChineseSkipped: false,
      }),
    ).toBe(true);
  });

  it("does not replace a graphic subtitle source with Whisper in translation mode", () => {
    expect(
      shouldFallbackToWhisper({
        mode: "transcribe_translate",
        hasEmbeddedSubs: true,
        hasGraphicSubs: true,
        hasSubtitleOutput: false,
        embeddedChineseSkipped: false,
      }),
    ).toBe(false);
  });
});

describe("embedded subtitle action", () => {
  it("routes an all-graphic automatic subtitle set to OCR", () => {
    expect(
      chooseEmbeddedSubtitleAction({
        mode: "auto",
        textSubtitleCount: 0,
        graphicSubtitleCount: 2,
      }),
    ).toBe("ocr");
  });

  it("routes an explicit OCR request to OCR", () => {
    expect(
      chooseEmbeddedSubtitleAction({
        mode: "ocr",
        textSubtitleCount: 0,
        graphicSubtitleCount: 1,
      }),
    ).toBe("ocr");
  });

  it("routes graphic subtitles in translation mode through OCR", () => {
    expect(
      chooseEmbeddedSubtitleAction({
        mode: "transcribe_translate",
        textSubtitleCount: 0,
        graphicSubtitleCount: 1,
      }),
    ).toBe("ocr");
  });

  it("never replaces an existing Chinese track with OCR", () => {
    expect(
      chooseEmbeddedSubtitleAction({
        mode: "auto",
        textSubtitleCount: 0,
        graphicSubtitleCount: 1,
        embeddedChineseSkipped: true,
      }),
    ).toBe("skip");
  });
});

describe("subtitle-only completion", () => {
  it("completes silently when the source has no audio track", () => {
    expect(
      subtitleOnlyOutputDisposition({
        hasSubtitleOutput: false,
        sourceHasAudio: false,
        whisperProducedEmpty: false,
        graphicSubtitlePreserved: false,
        requestedMode: "whisper",
      }),
    ).toBe("success");
  });

  it("completes when Whisper found no speech", () => {
    expect(
      subtitleOnlyOutputDisposition({
        hasSubtitleOutput: false,
        sourceHasAudio: true,
        whisperProducedEmpty: true,
        graphicSubtitlePreserved: false,
        requestedMode: "whisper",
      }),
    ).toBe("success");
  });

  it("completes when graphic subtitles remain embedded after OCR failure", () => {
    expect(
      subtitleOnlyOutputDisposition({
        hasSubtitleOutput: false,
        sourceHasAudio: true,
        whisperProducedEmpty: false,
        graphicSubtitlePreserved: true,
        requestedMode: "auto",
      }),
    ).toBe("success");
  });

  it("fails a requested bilingual job when OCR only preserved embedded graphics", () => {
    expect(
      subtitleOnlyOutputDisposition({
        hasSubtitleOutput: false,
        hasBilingualOutput: false,
        sourceHasAudio: true,
        whisperProducedEmpty: false,
        graphicSubtitlePreserved: true,
        requestedMode: "bilingual",
      }),
    ).toBe("error");
  });

  it("accepts a bilingual job only when its merged subtitle artifact exists", () => {
    expect(
      subtitleOnlyOutputDisposition({
        hasSubtitleOutput: false,
        hasBilingualOutput: true,
        sourceHasAudio: true,
        whisperProducedEmpty: false,
        graphicSubtitlePreserved: true,
        requestedMode: "bilingual",
      }),
    ).toBe("success");
  });

  it("still fails when a usable subtitle source was expected but nothing survived", () => {
    expect(
      subtitleOnlyOutputDisposition({
        hasSubtitleOutput: false,
        sourceHasAudio: true,
        whisperProducedEmpty: false,
        graphicSubtitlePreserved: false,
        requestedMode: "extract",
      }),
    ).toBe("error");
  });
});

describe("explicit subtitle translation completion", () => {
  it("fails when the requested translation throws", () => {
    expect(
      explicitTranslationFailureMessage({
        mode: "transcribe_translate",
        translatedOutput: false,
        error: "无法连接 AI 服务",
      }),
    ).toBe("无法连接 AI 服务");
  });

  it("fails when translation mode produces no translated file", () => {
    expect(
      explicitTranslationFailureMessage({
        mode: "transcribe_translate",
        translatedOutput: false,
      }),
    ).toBe("未生成翻译字幕文件");
  });

  it("does not turn optional modes into hard failures", () => {
    expect(
      explicitTranslationFailureMessage({
        mode: "auto",
        translatedOutput: false,
        error: "网络不可用",
      }),
    ).toBeNull();
  });
});

describe("subtitle translation response validation", () => {
  it("rejects local test placeholder text instead of accepting it as translation", () => {
    expect(() =>
      assertUsableTranslatedTexts(["六月 1941 年。", "本机测试中文 2"]),
    ).toThrow("测试占位");
  });
});
