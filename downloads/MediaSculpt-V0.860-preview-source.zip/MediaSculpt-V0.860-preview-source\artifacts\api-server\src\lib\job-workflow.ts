import path from "path";

export type WorkflowMediaType =
  | "video"
  | "dvd"
  | "bluray"
  | "iso"
  | string
  | null
  | undefined;
export type WorkflowProcessingMode =
  | "compress"
  | "remux"
  | "none"
  | "chapterPreview";
export type WorkflowJobStatus = string | null | undefined;

const RUNNING_STATUSES = new Set([
  "scanning",
  "transcribing",
  "compressing",
  "remuxing",
]);

export function isDiscMediaType(mediaType: WorkflowMediaType): boolean {
  return mediaType === "dvd" || mediaType === "bluray" || mediaType === "iso";
}

function pathApiFor(sourcePath: string): typeof path {
  return /^[a-zA-Z]:[\\/]/.test(sourcePath) || sourcePath.includes("\\")
    ? path.win32
    : path;
}

function trimTrailingSeparators(sourcePath: string): string {
  const api = pathApiFor(sourcePath);
  const parsed = api.parse(sourcePath);
  if (sourcePath === parsed.root) return sourcePath;
  return sourcePath.replace(/[\\/]+$/, "");
}

export function defaultRemuxOutputDirectory(
  sourcePath: string,
  mediaType: WorkflowMediaType,
): string {
  const api = pathApiFor(sourcePath);
  const cleanPath = trimTrailingSeparators(sourcePath);
  const base = api.basename(cleanPath);

  if (
    (mediaType === "dvd" && /^VIDEO_TS$/i.test(base)) ||
    (mediaType === "bluray" && /^BDMV$/i.test(base))
  ) {
    return api.dirname(cleanPath);
  }

  const parent = api.basename(api.dirname(cleanPath));
  if (mediaType === "dvd" && /^VIDEO_TS$/i.test(parent)) {
    return api.dirname(api.dirname(cleanPath));
  }
  if (mediaType === "bluray" && /^PLAYLIST$/i.test(parent)) {
    const playlistDir = api.dirname(cleanPath);
    const bdmvDir = api.dirname(playlistDir);
    return api.dirname(bdmvDir);
  }
  if (mediaType === "bluray" && /^BDMV$/i.test(parent)) {
    return api.dirname(api.dirname(cleanPath));
  }
  const parentParent = api.basename(api.dirname(api.dirname(cleanPath)));
  if (mediaType === "bluray" && /^BDMV$/i.test(parentParent)) {
    return api.dirname(api.dirname(api.dirname(cleanPath)));
  }

  const ext = api.extname(cleanPath);
  // DVD/Blu-ray sources are directories (or files inside the VIDEO_TS/BDMV
  // structure). A disc folder name may itself end in a dot-like suffix (e.g.
  // "...LPCM.2.0"), so treating it as a single video file would wrongly walk
  // one level up to the drive root. Only video/ISO sources use the extension.
  if (ext && mediaType !== "dvd" && mediaType !== "bluray")
    return api.dirname(cleanPath);

  if (mediaType === "dvd" || mediaType === "bluray") return cleanPath;

  return cleanPath;
}

export function buildSequentialJobPlan(input: {
  mediaType: WorkflowMediaType;
  processingMode: WorkflowProcessingMode;
}): Array<{ processingMode: WorkflowProcessingMode }> {
  return [{ processingMode: input.processingMode }];
}

export function mapExternalToolProgress(input: {
  toolPercent: number;
  start?: number;
  end?: number;
}): number {
  const start = input.start ?? 0;
  const end = input.end ?? 95;
  const clampedToolPercent = Math.max(0, Math.min(100, input.toolPercent));
  return start + (end - start) * (clampedToolPercent / 100);
}

export function shouldStartJobNow(statuses: WorkflowJobStatus[]): boolean {
  return !statuses.some((status) => status && RUNNING_STATUSES.has(status));
}

export function normalizeRequestedProcessingMode(input: {
  mediaType: WorkflowMediaType;
  processingMode: WorkflowProcessingMode | null | undefined;
}): WorkflowProcessingMode {
  const requested = input.processingMode ?? "compress";
  if (requested === "compress" && isDiscMediaType(input.mediaType))
    return "compress";
  return requested;
}

/**
 * Guard the queue boundary against a task that would only scan metadata and
 * then finish without producing media or subtitle output. This is especially
 * important for old smart-workflow drafts whose row mode was `none` while
 * their subtitle policy was already `skip`.
 */
export function hasExecutableWorkflowSelection(input: {
  processingMode?: string | null;
  subtitleMode?: string | null;
  outputMode?: string | null;
  pipelineSteps?: readonly string[] | null;
}): boolean {
  const steps = input.pipelineSteps ?? [];
  if (
    steps.some(
      (step) =>
        step === "remux" ||
        step === "compress" ||
        step === "subtitle" ||
        step === "chapterPreview",
    )
  )
    return true;
  if (
    input.processingMode === "remux" ||
    input.processingMode === "compress" ||
    input.processingMode === "chapterPreview"
  )
    return true;
  if (
    input.outputMode === "remux" ||
    input.outputMode === "compress" ||
    input.outputMode === "both" ||
    input.outputMode === "audio"
  )
    return true;
  return (
    input.subtitleMode !== "skip" &&
    (input.subtitleMode === "auto" ||
      input.subtitleMode === "extract" ||
      input.subtitleMode === "ocr" ||
      input.subtitleMode === "whisper" ||
      input.subtitleMode === "transcribe_translate" ||
      input.subtitleMode === "bilingual")
  );
}

/**
 * DVD Remux-only jobs must use the verified title/VTS executor. A Remux step
 * inside a longer pipeline stays on the orchestrator so later stages can
 * consume its output.
 */
export function shouldUseVerifiedDvdRemux(input: {
  mediaType?: string | null;
  processingMode?: string | null;
  pipelineHasRemux: boolean;
  pipelineHasCompress: boolean;
  pipelineContinuesAfterRemux: boolean;
}): boolean {
  if (input.mediaType !== "dvd" || input.processingMode !== "remux")
    return false;
  if (!input.pipelineHasRemux) return true;
  return !input.pipelineHasCompress && !input.pipelineContinuesAfterRemux;
}

/** A smart-workflow task can be created as a review draft with no executable choice yet. */
export function requiresWorkflowSelection(
  selectionPlan: string | null | undefined,
): boolean {
  try {
    const parsed = JSON.parse(selectionPlan ?? "null") as {
      workflow?: unknown;
      needsUserSelection?: unknown;
    } | null;
    return (
      parsed?.workflow === "smart-workflow-v1" &&
      parsed.needsUserSelection === true
    );
  } catch {
    return false;
  }
}
