import type { ReactNode } from "react";
import {
  Captions,
  Languages,
  Mic,
  ScanText,
  Settings2,
  Subtitles,
  Wand2,
  X,
} from "lucide-react";
import { Card, CardContent } from "../../components/ui/card";
import { cn } from "../../lib/utils";
import type { SubtitleMode } from "../../hooks/useWorkbenchState";
import { subtitleModeAccent } from "./subtitle-mode-model";

const SUBTITLE_MODE_OPTIONS: SubtitleMode[] = [
  "auto",
  "ocr",
  "extract",
  "whisper",
  "transcribe_translate",
  "bilingual",
];

export interface SubtitleModeSelectorProps {
  title: string;
  activeMode: SubtitleMode;
  labels: Record<string, string>;
  descriptions: Record<string, string>;
  onSelect: (mode: SubtitleMode) => void;
  missingFor: (mode: string) => string[];
  promptMissing: (mode: string) => boolean;
  toolLabel: (id: string) => string;
  missingToolText: (tools: string) => string;
  installToolsText: string;
  bilingualEditTitle: string;
  bilingualSettingsOpen: boolean;
  onOpenBilingualSettings: () => void;
  onOpenToolSettings: () => void;
}

function modeIcon(mode: SubtitleMode): ReactNode {
  if (mode === "auto")
    return <Wand2 className="h-5 w-5 shrink-0 text-violet-400" />;
  if (mode === "ocr")
    return <ScanText className="h-5 w-5 shrink-0 text-rose-400" />;
  if (mode === "extract")
    return <Subtitles className="h-5 w-5 shrink-0 text-blue-400" />;
  if (mode === "whisper")
    return <Mic className="h-5 w-5 shrink-0 text-amber-400" />;
  if (mode === "transcribe_translate")
    return <Languages className="h-5 w-5 shrink-0 text-emerald-400" />;
  return <Captions className="h-5 w-5 shrink-0 text-blue-400" />;
}

function modeClassName(mode: SubtitleMode, active: boolean): string {
  const accent = subtitleModeAccent(mode, active);
  if (accent === "amber-active")
    return "border-amber-400 bg-amber-400/10 text-amber-400";
  if (accent === "primary-active")
    return "border-primary bg-primary/10 text-primary";
  if (accent === "amber-tool")
    return "border-amber-400/40 hover:border-amber-400/70 hover:bg-amber-400/5";
  return "border-border hover:border-primary/50 hover:bg-secondary/40";
}

export function SubtitleModeSelector({
  title,
  activeMode,
  labels,
  descriptions,
  onSelect,
  missingFor,
  promptMissing,
  toolLabel,
  missingToolText,
  installToolsText,
  bilingualEditTitle,
  bilingualSettingsOpen,
  onOpenBilingualSettings,
  onOpenToolSettings,
}: SubtitleModeSelectorProps) {
  return (
    <Card>
      <CardContent className="px-3 pb-2 pt-2">
        <p className="text-xs font-medium text-muted-foreground mb-2">
          {title}
        </p>
        <div className="grid grid-cols-3 gap-2 lg:grid-cols-6">
          {SUBTITLE_MODE_OPTIONS.map((mode) => {
            const active = activeMode === mode;
            const missing = missingFor(mode);
            const label = labels[mode] ?? mode;
            const description = descriptions[mode] ?? "";
            if (mode === "bilingual") {
              return (
                <div
                  key={mode}
                  className={cn(
                    "flex overflow-hidden rounded-lg border transition",
                    active
                      ? "border-amber-400 bg-amber-400/10"
                      : "border-border hover:border-primary/50 hover:bg-secondary/40",
                  )}
                >
                  <button
                    type="button"
                    data-testid="subtitle-mode-bilingual"
                    title={description}
                    onClick={() => {
                      if (missing.length === 0 || promptMissing(mode))
                        onSelect(mode);
                    }}
                    className="min-w-0 flex-1 p-2 text-left"
                  >
                    <div
                      className={cn(
                        "flex items-center gap-2 text-sm font-medium",
                        active && "text-amber-400",
                      )}
                    >
                      {modeIcon(mode)}
                      {label}
                    </div>
                  </button>
                  <button
                    type="button"
                    onClick={onOpenBilingualSettings}
                    title={bilingualEditTitle}
                    className={cn(
                      "shrink-0 border-l px-2.5 transition-colors",
                      bilingualSettingsOpen
                        ? "bg-primary/10 text-primary"
                        : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground",
                    )}
                  >
                    {bilingualSettingsOpen ? (
                      <X className="h-4 w-4" />
                    ) : (
                      <Settings2 className="h-4 w-4" />
                    )}
                  </button>
                </div>
              );
            }
            return (
              <button
                key={mode}
                type="button"
                data-testid={mode === "ocr" ? "subtitle-mode-ocr" : undefined}
                title={description}
                onClick={() => {
                  if (missing.length > 0 && !promptMissing(mode)) return;
                  onSelect(mode);
                }}
                className={cn(
                  "px-2 py-2 rounded-lg border transition-all text-left",
                  modeClassName(mode, active),
                )}
              >
                <div className="flex items-center gap-2 text-sm font-medium">
                  {modeIcon(mode)}
                  {label}
                </div>
                {missing.length > 0 &&
                  (mode === "ocr" ||
                    mode === "whisper" ||
                    mode === "transcribe_translate") && (
                    <div className="mt-1 flex items-center gap-1 text-[10px] text-amber-500">
                      <span>
                        {missingToolText(missing.map(toolLabel).join("/"))}
                      </span>
                      <button
                        type="button"
                        className="underline underline-offset-1 hover:text-amber-400"
                        onClick={(event) => {
                          event.stopPropagation();
                          onOpenToolSettings();
                        }}
                      >
                        {installToolsText}
                      </button>
                    </div>
                  )}
              </button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
