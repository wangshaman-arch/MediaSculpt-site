import { Router } from "express";
import fs from "node:fs/promises";
import path from "node:path";
import {
  ensureRuntimeDirectories,
  getToolStatuses,
  managedToolDirectory,
  resolveToolPath,
  type ToolId,
} from "../lib/tool-runtime";
import {
  downloadTool,
  installTesseractLanguageData,
  probeDownloadSources,
  rankDownloadSources,
} from "../lib/tool-downloader";
import { toolPackages } from "../lib/tool-manifest";
import {
  ensureFasterWhisperModel,
  installWhisperModel,
  setupLibreTranslateEnvironment,
  setupRapidOcrEnvironment,
  setupWhisperEnvironment,
} from "../lib/whisper-runtime";
import {
  appendRuntimeToolLog,
  diagnosticsLogPath,
  formatError,
} from "../lib/runtime-tool-log";
import { resolveAiEndpoint, testAiConnection } from "../lib/ai-provider";
import { getConfig } from "./jobs-config";

const router = Router();

type InstallTask = {
  progress: number;
  status: "running" | "done" | "error";
  message: string;
  startedAt: number;
};

/** 内存中的安装任务进度表：安装为后台执行，前端轮询 install-status 获取百分比。 */
const installTasks = new Map<string, InstallTask>();
/** 同一工具同时只允许一个安装任务，防止第二个安装把第一个的部分下载清掉。 */
const runningInstalls = new Set<string>();
/** 安装完成后任务状态保留一段时间供前端轮询；定期清理旧任务，防止内存增长。 */
setInterval(() => {
  const now = Date.now();
  for (const [key, task] of installTasks) {
    if (now - task.startedAt > 10 * 60 * 1000) installTasks.delete(key);
  }
}, 60_000).unref();

function createInstallTask(id: string): { taskId: string; task: InstallTask } {
  const taskId = `${id}-${Date.now()}`;
  const task: InstallTask = {
    progress: 0,
    status: "running",
    message: "准备安装…",
    startedAt: Date.now(),
  };
  installTasks.set(taskId, task);
  return { taskId, task };
}

/** 从安装日志解析阶段进度（Python 下载约占 45%，venv/pip 依次递增）。 */
function applyInstallLog(task: InstallTask, message: string): void {
  if (task.status !== "running") return;
  const percentMatch = /^download progress: (\d+)%/.exec(message);
  if (percentMatch) {
    task.progress = Math.max(task.progress, 5 + Number(percentMatch[1]) * 0.4);
    task.message = `下载运行环境… ${percentMatch[1]}%`;
    return;
  }
  if (/^download: /.test(message)) {
    task.progress = Math.max(task.progress, 5);
    task.message = "下载运行环境…";
    return;
  }
  if (/^downloaded: /.test(message)) {
    task.progress = Math.max(task.progress, 50);
    task.message = "运行环境就绪，正在准备虚拟环境…";
    return;
  }
  if (message.includes("pip index:")) {
    task.progress = Math.max(task.progress, 60);
    task.message = "正在通过 pip 安装依赖…";
    return;
  }
  if (message.includes("pip packages already")) {
    task.progress = Math.max(task.progress, 65);
    task.message = "依赖已存在，复用本地环境…";
    return;
  }
  if (message.includes("setup environment")) {
    task.progress = Math.max(task.progress, 2);
    task.message = "准备环境…";
    return;
  }
  const whisperModelPercentMatch =
    /whisper model download progress: (\d+)%/.exec(message);
  if (whisperModelPercentMatch) {
    // 环境占 0–50，模型下载占 50–100。
    task.progress = Math.max(
      task.progress,
      50 + Number(whisperModelPercentMatch[1]) * 0.5,
    );
    task.message = `下载 Whisper 模型… ${whisperModelPercentMatch[1]}%`;
    return;
  }
  const tesseractLangMatch = /^tesseract: language data (\d+)\/(\d+):/.exec(
    message,
  );
  if (tesseractLangMatch) {
    const done = Number(tesseractLangMatch[1]);
    const total = Number(tesseractLangMatch[2]);
    // 主安装（exe + 静默安装）占 91–93%，语言数据占 94–99%。
    task.progress = Math.max(
      task.progress,
      94 + Math.round((done / total) * 5),
    );
    task.message = `正在下载 Tesseract 语言数据 ${done}/${total}…`;
    return;
  }
  if (/^tesseract: extracting installer/.test(message)) {
    task.progress = Math.max(task.progress, 93);
    task.message = "正在解压 Tesseract 安装包…";
    return;
  }
  if (/^tesseract: downloading 7-Zip/.test(message)) {
    task.progress = Math.max(task.progress, 91);
    task.message = "正在准备 7-Zip 解包工具…";
    return;
  }
  if (/^tesseract: running silent installer/.test(message)) {
    task.progress = Math.max(task.progress, 92);
    task.message = "正在静默安装 Tesseract…";
    return;
  }
  if (/^tesseract: deployed/.test(message)) {
    task.progress = Math.max(task.progress, 98);
    task.message = "Tesseract 已就绪，正在检查语言数据…";
    return;
  }
}

async function runInstallTask(
  id: ToolId,
  url: string | undefined,
  sha256: string | undefined,
  task: InstallTask,
): Promise<void> {
  const onLog = async (message: string) => {
    await logRuntimeTool(message);
    applyInstallLog(task, message);
  };
  const onProgress = (event: { percent: number | null }) => {
    const percent = Math.max(0, Math.min(100, Math.round(event.percent ?? 0)));
    // 下载阶段占 0–90%，剩余进度留给静默安装与语言数据阶段。
    task.progress = Math.max(task.progress, Math.round(percent * 0.9));
    // 用任务累计进度显示，避免换源后从 0 重新计数造成“下载停止/倒退”的错觉。
    task.message = `下载 ${id}… ${Math.round(task.progress)}%`;
  };
  // Callers may pass an explicit sha256; otherwise fall back to the pinned
  // checksum declared by the tool manifest (e.g. HandBrake / Tesseract).
  const effectiveSha256 =
    sha256 ?? toolPackages().find((pkg) => pkg.id === id)?.checksum;
  try {
    if (id === "libretranslate") {
      const installedPath = await setupLibreTranslateEnvironment(
        undefined,
        onLog,
      );
      await onLog(`${id}: install completed at ${installedPath}`);
    } else if (id === "rapidocr") {
      const installedPath = await setupRapidOcrEnvironment(undefined, onLog);
      await onLog(`${id}: install completed at ${installedPath}`);
    } else if (id === "whisper") {
      const installedPath = await setupWhisperEnvironment(undefined, onLog);
      await onLog(`${id}: install completed at ${installedPath}`);
    } else {
      const candidateUrls =
        url && /^https:\/\//i.test(url)
          ? [url]
          : (toolPackages().find((pkg) => pkg.id === id)?.sources ?? []).filter(
              (source) => /^https:\/\//i.test(source),
            );
      // 只尝试真正的二进制文件下载地址（.exe/.zip/.7z 等）；发布页/说明页链接
      // 保留在界面里供查看，但不当作下载源——否则页面被下载“成功”后会走
      // “不是可执行安装程序”之类的误导性错误。
      const binaryCandidateUrls = candidateUrls.filter((source) => {
        try {
          return /\.(exe|zip|7z|msi|whl|dmg|pkg)$/i.test(
            new URL(source).pathname,
          );
        } catch {
          return false;
        }
      });
      const finalCandidateUrls =
        binaryCandidateUrls.length > 0 ? binaryCandidateUrls : candidateUrls;
      // 并行探测所有源，按“可用 + 速度快”排序后再下载：国内镜像时好时坏，
      // 固定顺序会先在失效源上浪费 60–90 秒（例如 ghfast.top 超时）。
      let orderedCandidateUrls = finalCandidateUrls;
      if (orderedCandidateUrls.length > 1) {
        await onLog(
          `${id}: probing ${orderedCandidateUrls.length} download sources…`,
        );
        const probes = await probeDownloadSources(orderedCandidateUrls, {
          onLog,
        });
        orderedCandidateUrls = rankDownloadSources(
          orderedCandidateUrls,
          probes,
        );
        const usable = probes.filter((probe) => probe.ok).length;
        await onLog(
          `${id}: source probe done (${usable}/${probes.length} usable); trying fastest source first`,
        );
      }
      let lastError: unknown = new Error("没有可用的下载地址");
      // 只在整次安装开始时清一次旧安装；换源时不再反复删除安装目录，
      // 否则前一个源的部分下载会被删掉重来，看起来就是“下载停止”。
      const pkg = toolPackages().find((p) => p.id === id);
      if (pkg) {
        // 逐项清理安装目录：保留 *.download 续传文件（即使上一次安装失败、
        // 用户重新点击也能继续），且绝不整目录删除——正在下载的 .download
        // 文件被占用时，整目录递归删除会卡住。
        try {
          const entries = await fs.readdir(pkg.installDirectory);
          for (const entry of entries) {
            if (entry.endsWith(".download")) continue;
            await fs
              .rm(path.join(pkg.installDirectory, entry), {
                recursive: true,
                force: true,
              })
              .catch(() => {});
          }
        } catch {
          // 目录可能尚不存在，忽略。
        }
        await onLog(`${id}: cleared existing install before reinstall`);
      }
      let installedOk = false;
      for (const target of orderedCandidateUrls) {
        try {
          const installedPath = await downloadTool(id, target, {
            force: false,
            sha256: effectiveSha256,
            onProgress,
            onLog,
          });
          await onLog(`${id}: install completed at ${installedPath}`);
          installedOk = true;
          break;
        } catch (error) {
          lastError = error;
          await onLog(`${id}: source ${target} failed: ${formatError(error)}`);
        }
      }
      // 之前用“task 未完成且进度<100”判断失败，会把“已安装复用本地工具”或
      // 正常下载完成（进度封顶 95%）误判成失败。改为显式成功标志。
      if (!installedOk) throw lastError;
    }
    task.status = "done";
    task.progress = 100;
    task.message = "安装完成";
  } catch (error) {
    task.status = "error";
    task.message = formatError(error);
    await logRuntimeTool(`${id}: install failed: ${formatError(error)}`);
  }
}

async function readReleaseId(): Promise<string> {
  const candidates = [
    path.resolve(process.cwd(), "..", "..", "windows-setup", "release-id.txt"),
    path.resolve(process.cwd(), "windows-setup", "release-id.txt"),
  ];
  for (const candidate of candidates) {
    try {
      return (await fs.readFile(candidate, "utf8")).trim();
    } catch {
      // Try next location.
    }
  }
  return (
    process.env.MEDIASCULPT_RELEASE_ID ||
    process.env.VX_AGENT_RELEASE_ID ||
    "unknown"
  );
}

async function logRuntimeTool(message: string): Promise<void> {
  await appendRuntimeToolLog(message).catch(() => {});
}

function redactAiLog(value: unknown): string {
  return String(value ?? "")
    .replace(
      /(api[_-]?key|authorization|token|secret)\s*[:=]\s*[^,\s}]+/gi,
      "$1=[redacted]",
    )
    .slice(0, 1200);
}

router.get("/runtime/version", async (_req, res) => {
  const releaseId = await readReleaseId();
  res.json({
    releaseId,
    softwareVersion:
      process.env.MEDIASCULPT_VERSION ||
      process.env.VX_AGENT_VERSION ||
      "V 0.856",
    branch:
      process.env.MEDIASCULPT_GITHUB_BRANCH ||
      process.env.VX_AGENT_GITHUB_BRANCH ||
      "native-main-fix",
    commit:
      process.env.MEDIASCULPT_GITHUB_COMMIT ||
      process.env.VX_AGENT_GITHUB_COMMIT ||
      process.env.GITHUB_SHA ||
      "unknown",
  });
});

router.post("/runtime/ai/test", async (req, res) => {
  const config = await getConfig();
  const provider =
    typeof req.body?.provider === "string"
      ? req.body.provider
      : config.aiProvider;
  // 安全：绝不能把"已保存的密钥"发到"请求体指定的任意地址"（会外泄密钥并造成 SSRF）。
  // 只有当请求同时自带 apiKey（调用方自测自己的密钥）时，才允许使用请求体里的地址；
  // 否则一律强制使用已保存的 config 地址，并做基本 URL 协议校验。
  const requestApiKey =
    typeof req.body?.apiKey === "string" && req.body.apiKey.trim()
      ? req.body.apiKey.trim()
      : undefined;
  const callerEndpointAllowed = Boolean(requestApiKey);
  const safeHttpUrl = (
    value: unknown,
    fallback: string | null | undefined,
  ): string | null | undefined => {
    if (!callerEndpointAllowed || typeof value !== "string" || !value.trim())
      return fallback;
    try {
      const parsed = new URL(value.trim());
      return parsed.protocol === "http:" || parsed.protocol === "https:"
        ? value.trim()
        : fallback;
    } catch {
      return fallback;
    }
  };
  const requestConfig = {
    ...config,
    provider,
    apiKey: requestApiKey,
    model:
      typeof req.body?.model === "string" ? req.body.model : config.aiModel,
    baseUrl: safeHttpUrl(req.body?.baseUrl, config.aiBaseUrl),
    libreTranslateUrl: safeHttpUrl(
      req.body?.libreTranslateUrl,
      config.libreTranslateUrl,
    ),
  };
  const endpoint = resolveAiEndpoint(requestConfig);
  await logRuntimeTool(
    `AI 连接测试开始：provider=${endpoint.label} model=${endpoint.model} baseUrl=${endpoint.baseUrl}`,
  );
  const result = await testAiConnection(requestConfig);
  await logRuntimeTool(
    `AI 连接测试结果：provider=${result.provider} model=${result.model} connected=${result.connected} status=${result.statusCode ?? "n/a"} durationMs=${result.durationMs} message=${redactAiLog(result.message)}`,
  );
  return res
    .status(result.connected ? 200 : 502)
    .json({ ...result, logPath: diagnosticsLogPath() });
});

// POST /runtime/metadata/test — verify a TMDb or OMDb API key with a minimal
// request, mirroring the AI connection test. Keys are never written to logs.
router.post("/runtime/metadata/test", async (req, res) => {
  const config = await getConfig();
  const provider = req.body?.provider === "omdb" ? "omdb" : "tmdb";
  const apiKey =
    typeof req.body?.apiKey === "string" && req.body.apiKey.trim()
      ? req.body.apiKey.trim()
      : provider === "omdb"
        ? config.omdbApiKey
        : config.tmdbApiKey;
  if (!apiKey) {
    return res
      .status(400)
      .json({ error: `未配置 ${provider.toUpperCase()} API Key` });
  }
  const startedAt = Date.now();
  try {
    if (provider === "tmdb") {
      const response = await fetch(
        `https://api.themoviedb.org/3/configuration?api_key=${encodeURIComponent(apiKey)}`,
        { signal: AbortSignal.timeout(15_000) },
      );
      const durationMs = Date.now() - startedAt;
      const body = (await response.json().catch(() => ({}))) as {
        status_message?: string;
      };
      const connected = response.ok;
      const message = connected
        ? "TMDb 连接成功"
        : (body.status_message ?? `TMDb 返回 HTTP ${response.status}`);
      await logRuntimeTool(
        `TMDb 连接测试结果：connected=${connected} status=${response.status} durationMs=${durationMs} message=${redactAiLog(message)}`,
      );
      return res.status(connected ? 200 : 502).json({
        provider,
        connected,
        statusCode: response.status,
        durationMs,
        message,
        logPath: diagnosticsLogPath(),
      });
    }
    const response = await fetch(
      `https://www.omdbapi.com/?apikey=${encodeURIComponent(apiKey)}&s=test`,
      { signal: AbortSignal.timeout(15_000) },
    );
    const durationMs = Date.now() - startedAt;
    const body = (await response.json().catch(() => ({}))) as {
      Response?: string;
      Error?: string;
    };
    const connected = body.Response === "True";
    const message = connected
      ? "OMDb 连接成功"
      : (body.Error ?? `OMDb 返回 HTTP ${response.status}`);
    await logRuntimeTool(
      `OMDb 连接测试结果：connected=${connected} status=${response.status} durationMs=${durationMs} message=${redactAiLog(message)}`,
    );
    return res.status(connected ? 200 : 502).json({
      provider,
      connected,
      statusCode: response.status,
      durationMs,
      message,
      logPath: diagnosticsLogPath(),
    });
  } catch (error) {
    const durationMs = Date.now() - startedAt;
    const message = error instanceof Error ? error.message : String(error);
    await logRuntimeTool(
      `${provider.toUpperCase()} 连接测试失败：durationMs=${durationMs} message=${redactAiLog(message)}`,
    ).catch(() => {});
    return res.status(502).json({
      provider,
      connected: false,
      statusCode: null,
      durationMs,
      message,
      logPath: diagnosticsLogPath(),
    });
  }
});

router.get("/runtime/tools", async (_req, res) => {
  try {
    await logRuntimeTool("refresh: checking runtime tool statuses");
    await ensureRuntimeDirectories();
    const statuses = await getToolStatuses();
    const packages = toolPackages(
      process.platform as "win32" | "darwin" | "linux",
    );
    await logRuntimeTool(
      `refresh: ${statuses.map((status) => `${status.id}=${status.available ? "available" : "missing"}`).join(", ")}`,
    );
    res.json({
      platform: process.platform,
      toolDirectory: managedToolDirectory(),
      logPath: diagnosticsLogPath(),
      tools: statuses.map((status) => ({
        ...status,
        sources: packages.find((pkg) => pkg.id === status.id)?.sources ?? [],
      })),
    });
  } catch (error) {
    await logRuntimeTool(`refresh failed: ${formatError(error)}`);
    res
      .status(500)
      .json({ error: String(error), logPath: diagnosticsLogPath() });
  }
});

router.post("/runtime/tools/:id/install", async (req, res) => {
  const rawId = String(req.params.id);
  const toolIds: readonly ToolId[] = [
    "ffmpeg",
    "ffprobe",
    "handbrake",
    "whisper",
    "libretranslate",
    "tesseract",
    "rapidocr",
  ];
  if (!toolIds.includes(rawId as ToolId))
    return res.status(400).json({ error: "不支持的工具" });
  const id = rawId as ToolId;
  const { url, sha256 } = req.body as { url?: string; sha256?: string };
  try {
    await logRuntimeTool(
      `${id}: install requested${url ? ` from ${url}` : ""}`,
    );
    // 下载类工具在无 URL 且无内置源时直接失败（避免后台任务空转）。
    if (!url && !/^https:\/\//i.test(url ?? "") && id !== "tesseract") {
      const sources = (
        toolPackages().find((pkg) => pkg.id === id)?.sources ?? []
      ).filter((source) => /^https:\/\//i.test(source));
      if (
        sources.length === 0 &&
        !["libretranslate", "rapidocr", "whisper"].includes(id)
      ) {
        return res.status(400).json({
          error: "该工具没有可自动选择的下载源，请提供 HTTPS 下载地址",
        });
      }
    }
    const { taskId, task } = createInstallTask(id);
    const alreadyRunning =
      runningInstalls.has(id) ||
      [...installTasks.entries()].some(
        ([existingTaskId, entry]) =>
          entry.status === "running" &&
          existingTaskId !== taskId &&
          existingTaskId.startsWith(`${id}-`),
      );
    if (alreadyRunning) {
      await logRuntimeTool(
        `${id}: install already in progress; rejecting duplicate`,
      );
      return res
        .status(409)
        .json({ error: "该工具已有安装任务正在进行，请等待完成后再试" });
    }
    runningInstalls.add(id);
    void runInstallTask(id, url, sha256, task).finally(() => {
      runningInstalls.delete(id);
    });
    return res
      .status(202)
      .json({ id, taskId, progress: 0, logPath: diagnosticsLogPath() });
  } catch (error) {
    await logRuntimeTool(`${id}: install failed: ${formatError(error)}`);
    return res
      .status(502)
      .json({ error: String(error), logPath: diagnosticsLogPath() });
  }
});

// GET /runtime/tools/:id/install-status?taskId= — 轮询后台安装进度。
router.get("/runtime/tools/:id/install-status", async (req, res) => {
  const taskId = String(req.query.taskId ?? "");
  const task = installTasks.get(taskId);
  if (!task) return res.status(404).json({ error: "安装任务不存在或已过期" });
  return res.json({ taskId, ...task, logPath: diagnosticsLogPath() });
});

// GET /runtime/tools/installs/active — 返回所有正在运行的安装任务，
// 前端据此把“由后台/其他来源启动”的安装也接到界面显示真实进度。
router.get("/runtime/tools/installs/active", async (_req, res) => {
  const tasks = [...installTasks.entries()]
    .filter(([, task]) => task.status === "running")
    .map(([taskId, task]) => ({
      taskId,
      id: taskId.split("-")[0],
      progress: task.progress,
      status: task.status,
      message: task.message,
    }));
  return res.json({ tasks });
});

router.post("/runtime/whisper/setup", async (_req, res) => {
  try {
    await logRuntimeTool("whisper: setup requested");
    return res.json({
      environment: await setupWhisperEnvironment(undefined, logRuntimeTool),
      logPath: diagnosticsLogPath(),
    });
  } catch (error) {
    await logRuntimeTool(`whisper: setup failed: ${formatError(error)}`);
    return res
      .status(502)
      .json({ error: String(error), logPath: diagnosticsLogPath() });
  }
});

// POST /runtime/whisper/setup-model — 环境 + 指定模型一站式后台安装（带真实进度）。
router.post("/runtime/whisper/setup-model", async (req, res) => {
  const model = String(req.body?.model ?? "medium").trim();
  if (!/^[a-z0-9.-]+$/i.test(model))
    return res.status(400).json({ error: "无效的 Whisper 模型名称" });
  if (runningInstalls.has("whisper")) {
    return res
      .status(409)
      .json({ error: "Whisper 已有安装任务正在进行，请等待完成后再试" });
  }
  const { taskId, task } = createInstallTask("whisper");
  runningInstalls.add("whisper");
  const onLog = async (message: string) => {
    await logRuntimeTool(message);
    applyInstallLog(task, message);
  };
  void (async () => {
    try {
      await setupWhisperEnvironment(undefined, onLog);
      await ensureFasterWhisperModel(model, onLog);
      task.status = "done";
      task.progress = 100;
      task.message = `Whisper ${model} 安装完成`;
      await logRuntimeTool(`whisper: setup+model ${model} completed`);
    } catch (error) {
      task.status = "error";
      task.message = formatError(error);
      await logRuntimeTool(
        `whisper: setup+model ${model} failed: ${formatError(error)}`,
      );
    } finally {
      runningInstalls.delete("whisper");
    }
  })();
  return res.status(202).json({
    id: "whisper",
    taskId,
    progress: 0,
    logPath: diagnosticsLogPath(),
  });
});

router.post("/runtime/whisper/models/:model/install", async (req, res) => {
  try {
    await logRuntimeTool(
      `whisper: model install requested ${req.params.model}`,
    );
    return res.json({
      model: req.params.model,
      path: await installWhisperModel(
        String(req.params.model),
        undefined,
        logRuntimeTool,
      ),
      logPath: diagnosticsLogPath(),
    });
  } catch (error) {
    await logRuntimeTool(
      `whisper: model install failed: ${formatError(error)}`,
    );
    return res
      .status(502)
      .json({ error: String(error), logPath: diagnosticsLogPath() });
  }
});

router.post("/runtime/tools/tesseract/language/:lang", async (req, res) => {
  const lang = String(req.params.lang ?? "").trim();
  if (!/^[a-z_]+$/.test(lang))
    return res.status(400).json({ error: "无效的 Tesseract 语言代码" });
  try {
    const tesseractPath = await resolveToolPath("tesseract");
    if (!tesseractPath)
      return res
        .status(400)
        .json({ error: "请先在工具管理中安装 Tesseract OCR，再安装语言数据" });
    await logRuntimeTool(`tesseract: language data install requested: ${lang}`);
    const installed = await installTesseractLanguageData(
      tesseractPath,
      [lang],
      logRuntimeTool,
    );
    await logRuntimeTool(
      `tesseract: language ${lang} installed at ${installed.join(", ")}`,
    );
    return res.json({
      lang,
      path: installed[0] ?? null,
      logPath: diagnosticsLogPath(),
    });
  } catch (error) {
    await logRuntimeTool(
      `tesseract: language ${lang} install failed: ${formatError(error)}`,
    );
    return res
      .status(502)
      .json({ error: String(error), logPath: diagnosticsLogPath() });
  }
});

export default router;
