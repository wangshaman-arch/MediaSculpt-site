import { describe, expect, it } from "vitest";
import { defaultPresetLabelForMediaType, matchPresetId } from "./useJobPresets";
import {
  DEFAULT_COMPRESSION_PRESETS,
  type ArchivePreset,
} from "../lib/compression-presets";

describe("useJobPresets helpers", () => {
  it("maps media types onto default preset labels", () => {
    expect(defaultPresetLabelForMediaType("dvd")).toBe("dvd-convert");
    expect(defaultPresetLabelForMediaType("bluray")).toBe("bluray-collection");
    expect(defaultPresetLabelForMediaType("iso")).toBe("bluray-collection");
    expect(defaultPresetLabelForMediaType("video")).toBe("balanced");
    expect(defaultPresetLabelForMediaType(null)).toBe("balanced");
  });

  it("matches the built-in preset for a config, defaulting slow/source", () => {
    const balanced = DEFAULT_COMPRESSION_PRESETS.find(
      (preset) => preset.id === "balanced",
    ) as ArchivePreset;
    expect(
      matchPresetId(DEFAULT_COMPRESSION_PRESETS, {
        encoder: balanced.values.encoder,
        crf: balanced.values.crf,
        encoderPreset: balanced.values.encoderPreset,
        outputResolution: balanced.values.outputResolution,
      }),
    ).toBe("balanced");
    // dvd-convert uses slow/source; undefined falls back to the same defaults.
    const dvd = DEFAULT_COMPRESSION_PRESETS.find(
      (preset) => preset.id === "dvd-convert",
    ) as ArchivePreset;
    expect(
      matchPresetId(DEFAULT_COMPRESSION_PRESETS, {
        encoder: dvd.values.encoder,
        crf: dvd.values.crf,
        encoderPreset: undefined,
        outputResolution: undefined,
      }),
    ).toBe("dvd-convert");
  });

  it("returns empty string when no preset matches", () => {
    expect(
      matchPresetId(DEFAULT_COMPRESSION_PRESETS, {
        encoder: "nope",
        crf: 99,
        encoderPreset: "slow",
        outputResolution: "source",
      }),
    ).toBe("");
  });
});
