import { describe, expect, it } from "vitest";
import {
  createMediaPipelineManifest,
  type MediaPipelineInput,
} from "./media-pipeline-contract";
import {
  buildDvdRemuxRequest,
  buildDvdRemuxRequestFromManifest,
} from "./remux-service";
import { IncompleteMediaTitleError, type MediaTitle } from "./media-source";

function title(overrides: Partial<MediaTitle> = {}): MediaTitle {
  return {
    stableId: "dvd:1:VTS_01_0.IFO",
    ordinal: 1,
    sourceFile: "D:\\DVD\\VIDEO_TS\\VTS_01_0.IFO",
    sourceSizeBytes: 100,
    missingInputs: [],
    durationSeconds: null,
    videoStreams: [],
    audioStreams: [],
    subtitleStreams: [],
    chapters: [],
    orderedInputs: ["D:\\DVD\\VIDEO_TS\\VTS_01_1.VOB"],
    ...overrides,
  };
}

describe("DVD Remux service", () => {
  function manifest(): ReturnType<typeof createMediaPipelineManifest> {
    const input: MediaPipelineInput = {
      source: {
        kind: "dvd",
        path: "D:\\DVD",
        fingerprint: "dvd-v1",
        physicalBytes: 7_000_000_000,
      },
      title: {
        id: "handbrake:1",
        titleNumber: 7,
        durationSeconds: 5_400,
        streams: [
          { id: "video:0", index: 0, type: "video", codec: "mpeg2video" },
          {
            id: "audio:1",
            index: 1,
            type: "audio",
            codec: "ac3",
            language: "en",
          },
          {
            id: "subtitle:2",
            index: 2,
            type: "subtitle",
            codec: "dvd_subtitle",
            language: "en",
          },
        ],
        chapters: [],
      },
      selection: {
        streamIds: ["video:0", "audio:1", "subtitle:2"],
        chapterIds: [],
      },
      output: { mode: "remux", directory: "D:\\Output", fileName: "Movie.mkv" },
    };
    return createMediaPipelineManifest(input);
  }

  it("converts one verified manifest into the exact DVD Remux request", () => {
    expect(
      buildDvdRemuxRequestFromManifest({
        manifest: manifest(),
        executable: "ffmpeg.exe",
      }),
    ).toMatchObject({
      sourcePath: "D:\\DVD",
      titleNumber: 7,
      selectedVideoStreams: [0],
      selectedAudioStreams: [1],
      selectedSubtitleStreams: [2],
      outputPath: "D:\\Output\\Movie.mkv",
    });
  });

  it("does not use a compression or subtitle manifest for DVD Remux", () => {
    const inputManifest = manifest();
    expect(() =>
      buildDvdRemuxRequestFromManifest({
        manifest: createMediaPipelineManifest({
          source: inputManifest.source,
          title: inputManifest.title,
          selection: { streamIds: ["video:0"], chapterIds: [] },
          output: { ...inputManifest.output, mode: "compress" },
        }),
        executable: "ffmpeg.exe",
      }),
    ).toThrow("输出模式必须是 remux");
  });

  it("requires the immutable source title before preparing FFmpeg input", () => {
    expect(
      buildDvdRemuxRequest({
        sourceTitle: title(),
        executable: "ffmpeg.exe",
        sourcePath: "D:\\DVD\\VIDEO_TS",
        titleNumber: 7,
        selectedVideoStreams: [0],
        selectedAudioStreams: [2],
        selectedSubtitleStreams: [],
        outputPath: "D:\\out\\movie.mkv",
      }),
    ).toMatchObject({ sourcePath: "D:\\DVD\\VIDEO_TS", titleNumber: 7 });
  });

  it("blocks a source title with missing VOB segments before spawning FFmpeg", () => {
    expect(() =>
      buildDvdRemuxRequest({
        sourceTitle: title({ missingInputs: ["VTS_01_2.VOB"] }),
        executable: "ffmpeg.exe",
        sourcePath: "D:\\DVD\\VIDEO_TS",
        titleNumber: 7,
        selectedVideoStreams: [0],
        selectedAudioStreams: [],
        selectedSubtitleStreams: [],
        outputPath: "D:\\out\\movie.mkv",
      }),
    ).toThrowError(IncompleteMediaTitleError);
  });
});
