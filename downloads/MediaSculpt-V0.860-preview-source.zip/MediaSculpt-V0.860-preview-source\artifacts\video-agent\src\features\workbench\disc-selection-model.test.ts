import { describe, expect, it } from "vitest";
import type { DiscStream, DiscTrack } from "@workspace/api-client-react";
import {
  countSelectedTrackStreams,
  defaultChapterSelection,
  defaultStreamSelection,
  selectableStreamsForTrack,
} from "./disc-selection-model";

const stream = (overrides: Partial<DiscStream>): DiscStream => ({
  index: 0,
  codecType: "audio",
  codecName: "aac",
  ...overrides,
});

const track = (streams: DiscStream[], chapters: number[] = []): DiscTrack => ({
  path: "D:/disc",
  name: "Title",
  sizeBytes: 100,
  streams,
  chapters: chapters.map((id) => ({
    id,
    startSeconds: id,
    endSeconds: id + 10,
  })),
});

describe("disc selection model", () => {
  it("includes only audio/subtitle streams when video is excluded", () => {
    const value = track([
      stream({ index: 0, codecType: "video", codecName: "h264" }),
      stream({ index: 1, codecType: "audio", codecName: "aac" }),
      stream({ index: 2, codecType: "subtitle", codecName: "sub" }),
    ]);
    expect([...defaultStreamSelection(value, false)].sort()).toEqual([1, 2]);
    expect([...defaultStreamSelection(value, true)].sort()).toEqual([0, 1, 2]);
    expect(selectableStreamsForTrack(value, false).map((s) => s.index)).toEqual(
      [1, 2],
    );
  });

  it("returns empty defaults for an undefined track", () => {
    expect(defaultStreamSelection(undefined, true).size).toBe(0);
    expect(defaultChapterSelection(undefined).size).toBe(0);
    expect(selectableStreamsForTrack(undefined, true)).toEqual([]);
  });

  it("defaults chapters to every parsed chapter id", () => {
    expect([...defaultChapterSelection(track([], [1, 2, 3]))]).toEqual([
      1, 2, 3,
    ]);
  });

  it("counts only selected streams of the requested codec type", () => {
    const value = track([
      stream({ index: 0, codecType: "video", codecName: "h264" }),
      stream({ index: 1, codecType: "audio", codecName: "aac" }),
      stream({ index: 2, codecType: "audio", codecName: "ac3" }),
    ]);
    expect(countSelectedTrackStreams(value, new Set([1]), "audio")).toBe(1);
    expect(countSelectedTrackStreams(value, new Set([1, 2]), "audio")).toBe(2);
    expect(countSelectedTrackStreams(undefined, new Set([1]), "audio")).toBe(0);
  });
});
