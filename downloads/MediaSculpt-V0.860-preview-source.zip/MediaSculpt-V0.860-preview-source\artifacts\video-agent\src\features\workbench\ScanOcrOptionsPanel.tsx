import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { ChevronsUpDown } from "lucide-react";
import { OCR_LANGUAGE_CODES, ocrLanguageLabel } from "@/lib/ocr-languages";

type Translate = (key: string) => string;

/**
 * Searchable OCR language picker. A plain Select with 50+ entries overflows
 * the viewport and cannot scroll, so this uses a Command combobox with a
 * viewport-safe max height and keyboard search.
 */
function OcrLanguagePicker({
  value,
  onChange,
  t,
}: {
  value: string;
  onChange: (value: string) => void;
  t: Translate;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return OCR_LANGUAGE_CODES;
    return OCR_LANGUAGE_CODES.filter((code) => {
      const label = t(`ocr.languageNames.${code}`).toLowerCase();
      return code.includes(q) || label.includes(q);
    });
  }, [query, t]);
  const select = (next: string) => {
    onChange(next);
    setOpen(false);
    setQuery("");
  };
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="h-9 w-full justify-between font-normal"
          data-testid="ocr-language-select"
        >
          {ocrLanguageLabel(value, t)}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" sideOffset={4} className="w-[280px] p-0">
        <Command>
          <CommandInput
            placeholder={t("ocr.languageSearchPlaceholder")}
            value={query}
            onValueChange={setQuery}
          />
          <CommandList className="max-h-[min(50vh,360px)] overflow-y-auto">
            <CommandEmpty>{t("ocr.languageSearchEmpty")}</CommandEmpty>
            <CommandItem value="auto" onSelect={() => select("auto")}>
              {t("ocr.languageAuto")}
            </CommandItem>
            {filtered.map((code) => (
              <CommandItem
                key={code}
                value={code}
                onSelect={() => select(code)}
              >
                {t(`ocr.languageNames.${code}`)}
              </CommandItem>
            ))}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

export function ScanOcrOptionsPanel({
  t,
  ocrEngine,
  ocrLanguage,
  onOcrEngineChange,
  onOcrLanguageChange,
}: {
  t: Translate;
  ocrEngine: string;
  ocrLanguage: string;
  onOcrEngineChange: (value: string) => void;
  onOcrLanguageChange: (value: string) => void;
}) {
  return (
    <div
      className="mt-3 rounded-lg border border-primary/25 bg-primary/5 p-3 space-y-3"
      data-testid="ocr-options-panel"
    >
      <p className="text-xs text-muted-foreground leading-relaxed">
        {t("scan.ocrModeHint")}
      </p>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div className="space-y-1.5">
          <label className="text-xs font-medium">{t("ocr.engine")}</label>
          <Select
            value={ocrEngine}
            onValueChange={onOcrEngineChange}
            data-testid="ocr-engine-select"
          >
            <SelectTrigger className="h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="auto">{t("ocr.engineAuto")}</SelectItem>
              <SelectItem value="llm">{t("ocr.engineLlm")}</SelectItem>
              <SelectItem value="tesseract">
                {t("ocr.engineTesseract")}
              </SelectItem>
              <SelectItem value="rapidocr">
                {t("ocr.engineRapidOcr")}
              </SelectItem>
              <SelectItem value="subtitleedit" disabled>
                {t("ocr.engineSubtitleEdit")}（{t("ocr.comingSoon")}）
              </SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <label className="text-xs font-medium">{t("ocr.language")}</label>
          <OcrLanguagePicker
            value={ocrLanguage}
            onChange={onOcrLanguageChange}
            t={t}
          />
        </div>
      </div>
    </div>
  );
}
