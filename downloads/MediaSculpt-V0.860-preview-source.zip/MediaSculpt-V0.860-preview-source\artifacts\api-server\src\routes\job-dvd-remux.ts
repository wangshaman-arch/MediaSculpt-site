// Extracted from routes/jobs.ts: verified DVD remux job execution.
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import {
  lookupAll,
  metadataIdentityMatches,
  normalizeTitleEn,
} from "../lib/metadata";
import {
  servePreviewSegment,
  cleanupPreviewSegments,
} from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import {
  buildSelectedChapterMetadata,
  resolveRemuxChapterIds,
} from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import {
  buildFfconcatFileContent as buildManifest,
  buildFfconcatChapterContent,
  buildFfconcatTimedContent,
  type FfconcatTimedSegment,
} from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import {
  appendJobRuntimeLog,
  appendJobToolOutput,
} from "../lib/job-runtime-log";
import {
  appendRuntimeToolLog,
  appendRuntimeToolOutput,
} from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import {
  buildCompressionOutputName,
  buildRemuxOutputName,
  cleanSegment,
  encoderBitDepth,
  selectBestAudioTrack,
} from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import {
  renderBilingualAss,
  DEFAULT_BILINGUAL_STYLE,
  type BilingualAssStyle,
  type SubtitleBlock,
} from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import {
  ensureLocalPoster,
  MEDIA_INFO_DIR,
  POSTER_META_FILE,
  posterIdentityMatches,
} from "../lib/poster";
import {
  ensureFasterWhisperModel,
  ensureWhisperCliScript,
} from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import {
  hasValidSubtitleCues,
  isGraphicSubtitleCodec,
  shouldFallbackToWhisper,
} from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import {
  buildDvdRemuxArgs,
  runDvdRemux,
  verifyDvdTitle,
} from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import {
  buildDvdStructurePayload,
  resolveRemuxPlanWithLlm,
  validateRemuxPlan,
} from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import {
  assertPreviewTaskAllowed,
  recordPreviewAiCall,
  settlePreviewTask,
} from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import {
  parseCustomTuning,
  resolveLogicPlaceholders,
} from "../lib/custom-tuning";
import {
  decryptSecret,
  encryptSecret,
  isEncryptedSecret,
} from "../lib/secrets";
import {
  ffmpegPath,
  resolveOutputDir,
  resolveRuntimePath,
  type RuntimePathConfig,
} from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { trackJobOutputFile } from "./jobs-tracking";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import {
  assertCompleteMediaTitle,
  createDvdMediaTitle,
} from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import {
  buildPreviewTranscodeArgs,
  isPreviewVideoCandidate,
  previewService,
} from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";
import { addLog } from "../lib/job-logging";
import { discAnalysisRegistry } from "../lib/disc-analysis-registry";
import { settlePreviewTaskSafely } from "../lib/preview-runtime";
import {
  snapshotStreamIndexes,
  selectedDvdAudioCodecs,
  probeDvdAudioCodecs,
} from "./jobs-dvd-audio";
import {
  dvdVideoInputPath,
  dvdConcatInputArgs,
  buildDvdTypeMaps,
  ffmpegSupportsDvdTitleNavigation,
  writeDvdConcatListFile,
  assertDvdTitleComplete,
  ensureDvdCssSupport,
} from "./jobs-dvd";
import {
  SOURCE_DIRECTORY_VALUE,
  validateWritableDirectory,
  describeFfmpegExecutable,
} from "./jobs-output-paths";
import { verifyOutputEndPlayable } from "./jobs-ffmpeg-run";
import { probeStreams } from "./jobs-probe";
import { isPlayableRemuxProbe } from "./job-remux-output-health";
import { buildDvdVobFallbackArgs } from "./job-dvd-remux-fallback";
import { canUsePhysicalDvdVobFallback } from "../lib/disc-expectations";
import {
  doesNotSupportFfmpegProgressOption,
  formatFfmpegTimestamp,
  parseFfmpegProgressSeconds,
} from "../lib/ffmpeg-progress";

export async function processVerifiedDvdRemuxJob(
  jobId: number,
  job: typeof jobsTable.$inferSelect,
  config: typeof configTable.$inferSelect,
): Promise<void> {
  const snapshot = loadTaskSnapshot(job);
  if (
    !snapshot ||
    snapshot.sourceType !== "dvd" ||
    snapshot.outputMode !== "remux"
  ) {
    throw new Error("DVD Remux 缺少不可变任务快照");
  }
  const titleNumber = snapshot.toolSelections.dvdVtsNumber;
  if (!titleNumber || titleNumber <= 0)
    throw new Error("DVD Remux 的所选标题未通过 FFprobe 验证");
  let videoStreams = snapshotStreamIndexes(
    snapshot.streamSelection.videoTrackIds,
  );
  const audioStreams = snapshotStreamIndexes(
    snapshot.streamSelection.audioTrackIds,
  );
  let subtitleStreams = snapshotStreamIndexes(
    snapshot.streamSelection.subtitleTrackIds,
  );
  let selectedAudioCodecs = selectedDvdAudioCodecs(
    snapshot,
    audioStreams,
    job.selectionPlan,
  );

  const sourcePath = resolveRuntimePath(snapshot.sourcePath, config);
  const dvdInputPath = dvdVideoInputPath(sourcePath);
  // HandBrake/FFprobe's title number is a logical dvdvideo title number. The
  // analysis may have matched it to a different physical VTS file group, so
  // use that evidence for VOB lookup while retaining `titleNumber` for the
  // dvdvideo navigation command.
  let remuxAnalysis = discAnalysisRegistry.find(snapshot.analysisId);
  // The registry is intentionally in-memory. A retry after an app restart must
  // rebuild the same analysis instead of silently falling back to logical title
  // number == physical VTS number.
  if (!remuxAnalysis) {
    const refreshed = await analyzeDiscSource({
      sourcePath,
      mediaType: "dvd",
      sourceFingerprint: snapshot.sourceFingerprint,
      handbrakeCliPath: config.handbrakeCliPath,
    }).catch(() => null);
    if (refreshed?.analysisId === snapshot.analysisId) {
      remuxAnalysis = refreshed;
      discAnalysisRegistry.remember(refreshed);
      await addLog(
        jobId,
        "info",
        `重试前重新建立 DVD 分析快照：analysis=${snapshot.analysisId}`,
      );
    }
  }
  const remuxAnalysisTitle =
    remuxAnalysis?.titles.find(
      (candidate) => candidate.titleId === snapshot.selectedTitleId,
    ) ?? null;
  const availableSubtitleCount = remuxAnalysisTitle?.subtitleTracks.length ?? 0;
  await addLog(
    jobId,
    availableSubtitleCount > 0 && subtitleStreams.length === 0
      ? "warn"
      : "info",
    `DVD Remux 流轨选择：视频 ${videoStreams.length} 条，音频 ${audioStreams.length} 条，字幕 ${subtitleStreams.length}/${availableSubtitleCount} 条${availableSubtitleCount > 0 && subtitleStreams.length === 0 ? "；本任务将不包含原盘字幕" : ""}`,
  );
  // Repair snapshots created by older UI versions that accidentally persisted
  // only an audio stream after switching from subtitle mode to Remux. The
  // authoritative analyzed title supplies the real video stream for retry;
  // this keeps the immutable task usable without guessing a different title.
  if (videoStreams.length === 0 && remuxAnalysisTitle) {
    videoStreams = (remuxAnalysisTitle.videoTracks ?? [])
      .map((stream) => stream.index)
      .filter(
        (index): index is number => Number.isInteger(index) && index >= 0,
      );
    if (videoStreams.length > 0) {
      await addLog(
        jobId,
        "warn",
        "旧任务快照缺少视频流，已从同一已验证 DVD 标题恢复视频流后重试",
      );
    }
  }
  if (videoStreams.length === 0)
    throw new Error("DVD Remux 至少需要一个已验证的视频流");
  const physicalVtsNumber =
    remuxAnalysisTitle?.toolMappings.physicalVtsNumber ??
    snapshot.toolSelections.physicalVtsNumber ??
    null;
  const sourceLookupTitleNumber =
    typeof physicalVtsNumber === "number" && physicalVtsNumber > 0
      ? physicalVtsNumber
      : titleNumber;
  const sourceTitleInfo = await resolveDvdTitleForSource(
    sourcePath,
    0,
    sourceLookupTitleNumber,
  ).catch(() => null);
  assertDvdTitleComplete(sourceTitleInfo);
  if (!sourceTitleInfo) throw new Error(`未找到 DVD 标题结构：${sourcePath}`);
  if (physicalVtsNumber && sourceTitleInfo.titleNumber === physicalVtsNumber) {
    await addLog(
      jobId,
      "info",
      `DVD title 映射：逻辑 Title ${titleNumber} → 物理 VTS_${String(physicalVtsNumber).padStart(2, "0")}，导航与 VOB 文件组分开使用`,
    );
  }
  const sourceTitle = createDvdMediaTitle(sourceTitleInfo);
  if (selectedAudioCodecs.length === 0 && audioStreams.length > 0) {
    const ffprobe = await resolveToolPath("ffprobe");
    if (ffprobe) {
      selectedAudioCodecs = await probeDvdAudioCodecs(
        ffprobe,
        dvdInputPath,
        titleNumber,
        audioStreams,
      );
      if (
        selectedAudioCodecs.some(
          (stream) => stream.codecName?.toLowerCase() === "pcm_dvd",
        )
      ) {
        await addLog(
          jobId,
          "info",
          "DVD 音轨为 PCM（pcm_dvd），封装 MKV 时无损转换为 pcm_s16le",
        );
      }
    }
  }
  const outputDirectory =
    snapshot.output.directory === SOURCE_DIRECTORY_VALUE
      ? defaultRemuxOutputDirectory(sourcePath, snapshot.sourceType)
      : resolveRuntimePath(snapshot.output.directory, config);
  const outputFileName = snapshot.output.fileName.toLowerCase().endsWith(".mkv")
    ? snapshot.output.fileName
    : `${path.basename(snapshot.output.fileName, path.extname(snapshot.output.fileName))}.mkv`;
  const outputPath = path.join(outputDirectory, outputFileName);
  await validateWritableDirectory(outputDirectory);

  const ffmpegExecutable = await resolveToolPath("ffmpeg");
  if (!ffmpegExecutable) throw new Error("未找到项目实际使用的 FFmpeg");
  const cssSupport = await ensureDvdCssSupport(ffmpegExecutable);
  if (cssSupport === "ok") {
    await addLog(
      jobId,
      "info",
      "libdvdcss 就绪：CSS 加密 DVD 可直接通过 FFmpeg 读取",
    );
  } else if (cssSupport === "failed") {
    await addLog(
      jobId,
      "warn",
      "libdvdcss 自动安装失败：若为 CSS 加密 DVD，Remux 可能失败（普通 DVD 不受影响）",
    );
  }
  const legacyArgs = buildDvdRemuxArgs({
    sourcePath: dvdInputPath,
    titleNumber,
    selectedVideoStreams: videoStreams,
    selectedAudioStreams: audioStreams,
    selectedAudioCodecs,
    selectedSubtitleStreams: subtitleStreams,
    selectedSubtitleMetadata: subtitleStreams.map((inputIndex) => {
      const stream = remuxAnalysisTitle?.streams.find(
        (candidate) => candidate.index === inputIndex,
      );
      return {
        inputIndex,
        language: stream?.language ?? null,
        title: stream?.title ?? null,
      };
    }),
    outputPath,
  });
  // The unified manifest + planner is the single source of truth for the DVD
  // Remux command. It must reproduce the legacy command byte for byte; if it
  // ever diverges we fall back to the legacy command so the output cannot
  // silently change.
  const remuxChapters = remuxAnalysisTitle?.chapters ?? [];
  const selectedChapterIds = remuxAnalysisTitle
    ? resolveRemuxChapterIds(remuxChapters, snapshot.chapterSelection)
    : [];
  let chapterMetadataPath: string | null = null;
  // Make the chapter table explicit even for "all". The dvdvideo demuxer can
  // expose chapters, but the VOB concat fallback cannot; writing the verified
  // table here keeps both routes equivalent and makes chapter validation real.
  if (remuxAnalysisTitle && remuxChapters.length > 0) {
    const metadata = buildSelectedChapterMetadata(
      remuxChapters,
      selectedChapterIds,
    );
    if (!metadata) {
      throw new Error(
        "DVD Remux 的章节选择为空；请至少选择一个章节，或改为保留全部章节",
      );
    }
    chapterMetadataPath = path.join(
      os.tmpdir(),
      `vx-dvd-chapters-${jobId}-${Date.now()}.ffmeta`,
    );
    trackJobOutputFile(jobId, chapterMetadataPath, { temp: true });
    await fs.writeFile(chapterMetadataPath, metadata, "utf8");
    await addLog(
      jobId,
      "info",
      `已生成 ${selectedChapterIds.length} 个${snapshot.chapterSelection.mode === "all" ? "保留" : "选定"}章节的元数据`,
    );
  }
  // The output directory may be the symbolic __source__ value in the snapshot;
  // use the resolved directory so the planner and validation refer to one path.
  const plannerSnapshot = {
    ...snapshot,
    // The retry repair above may recover the real video stream from the
    // verified analysis title. Keep the planner and VOB fallback on that same
    // effective selection instead of feeding them the stale audio-only
    // snapshot that caused the original failure.
    streamSelection: {
      ...snapshot.streamSelection,
      videoTrackIds: videoStreams.map((index) => `stream:${index}`),
    },
    output: { ...snapshot.output, directory: outputDirectory },
  };
  const remuxManifest = buildMediaPipelineManifestFromSnapshot({
    snapshot: plannerSnapshot,
    title: remuxAnalysisTitle,
    selectionPlan: job.selectionPlan,
    sourcePath: dvdInputPath,
  });
  let plannedArgs: string[] | null = null;
  try {
    plannedArgs = buildRemuxCommandPlan({
      manifest: remuxManifest,
      executable: ffmpegExecutable,
      inputMode: "dvd-navigation",
      chapterMetadataPath: chapterMetadataPath ?? undefined,
    }).args as string[];
  } catch (error) {
    await addLog(
      jobId,
      "warn",
      `Remux planner 构建失败，回退旧命令：${error instanceof Error ? error.message : String(error)}`,
    );
  }
  const plannerMatches =
    plannedArgs !== null &&
    JSON.stringify(plannedArgs) === JSON.stringify(legacyArgs);
  if (chapterMetadataPath && plannedArgs === null) {
    throw new Error("DVD Remux 章节元数据规划失败，已停止以避免输出错误章节");
  }
  const args = chapterMetadataPath
    ? (plannedArgs as string[])
    : plannerMatches
      ? (plannedArgs as string[])
      : legacyArgs;
  if (!chapterMetadataPath && !plannerMatches) {
    await addLog(
      jobId,
      "warn",
      "Remux planner 与旧命令不一致，已回退旧命令（请检查）",
    );
  }
  await addLog(
    jobId,
    "info",
    `DVD Remux 唯一路线：FFmpeg dvdvideo，Title ${titleNumber}`,
  );
  await addLog(jobId, "info", `实际 FFmpeg 路径：${ffmpegExecutable}`);
  await addLog(
    jobId,
    "info",
    `FFmpeg 能力诊断：${await describeFfmpegExecutable(ffmpegExecutable)}`,
  );
  await addLog(jobId, "info", `Remux 实际输出目录：${outputDirectory}`);
  await addLog(
    jobId,
    "info",
    `实际 FFmpeg 版本：${process.env.MEDIASCULPT_FFMPEG_VERSION ?? process.env.VX_AGENT_FFMPEG_VERSION ?? "未记录；请查看 tools/ffmpeg-capabilities.log"}`,
  );
  await addLog(jobId, "info", `FFmpeg 参数数组：${JSON.stringify(args)}`);
  for (const codec of selectedAudioCodecs) {
    if (codec.codecName?.toLowerCase() === "pcm_dvd") {
      await addLog(
        jobId,
        "info",
        `检测到 pcm_dvd 音轨 ${codec.inputIndex}：为兼容 MKV 将按无损 PCM 方式封装（不重新编码视频）`,
      );
    }
  }
  await appendRuntimeToolLog(
    `DVD Remux job=${jobId} ffmpeg=${ffmpegExecutable} title=${titleNumber} args=${JSON.stringify(args)}`,
  ).catch(() => {});

  const expectedDuration =
    remuxAnalysisTitle?.durationSeconds ?? job.durationSeconds ?? null;
  const expectedChapterCount = chapterMetadataPath
    ? selectedChapterIds.length
    : undefined;

  await db
    .update(jobsTable)
    .set({
      status: "remuxing",
      progress: expectedDuration && expectedDuration > 0 ? 0 : null,
    })
    .where(eq(jobsTable.id, jobId));
  let result: Awaited<ReturnType<typeof executeDvdRemux>>;
  let lastProgressWrite = 0;
  let lastProgress = 0;
  let lastProgressLogAt = 0;
  let pendingProgressWrite: Promise<void> = Promise.resolve();
  const startedAt = Date.now();
  const reportRemuxTimestamp = (seconds: number | null) => {
    if (!expectedDuration || expectedDuration <= 0 || seconds === null) return;
    const now = Date.now();
    if (now - lastProgressWrite < 900) return;
    lastProgressWrite = now;
    // Reserve the final 8% for output probing, validation and tail decoding.
    lastProgress = Math.max(
      lastProgress,
      Math.min(92, (seconds / expectedDuration) * 92),
    );
    const etaSeconds =
      seconds > 0
        ? Math.max(
            0,
            Math.round(
              (expectedDuration - seconds) *
                ((now - startedAt) / 1000 / seconds),
            ),
          )
        : null;
    const progress = lastProgress;
    if (now - lastProgressLogAt >= 10_000) {
      lastProgressLogAt = now;
      void addLog(
        jobId,
        "info",
        `DVD Remux 进度：${formatFfmpegTimestamp(seconds)} / ${formatFfmpegTimestamp(expectedDuration)}（${progress.toFixed(1)}%）`,
      ).catch(() => {});
    }
    pendingProgressWrite = pendingProgressWrite
      .then(async () => {
        await db
          .update(jobsTable)
          .set({ progress, etaSeconds })
          .where(eq(jobsTable.id, jobId));
      })
      .catch(() => {});
  };
  const executeWithArgs = (attemptArgs: string[]) =>
    executeDvdRemux({
      sourceTitle,
      executable: ffmpegExecutable,
      sourcePath: dvdInputPath,
      titleNumber,
      selectedVideoStreams: videoStreams,
      selectedAudioStreams: audioStreams,
      selectedAudioCodecs,
      selectedSubtitleStreams: subtitleStreams,
      outputPath,
      args: attemptArgs,
      run: async (request) => {
        const runFfmpegAttempt = (executionArgs: string[]) =>
          new Promise<{
            tool: typeof request.tool;
            executable: string;
            args: string[];
            exitCode: number | null;
            stdout: string;
            stderr: string;
            durationMs: number;
            failureReason: string | null;
          }>((resolve) => {
            const startedAt = Date.now();
            const child = jobProcessController.spawnForJob(
              jobId,
              request.executable,
              executionArgs,
              config.processHighPriority ?? false,
            );
            // A full-title Remux can run for a long time; keep only the output tail so
            // diagnostics cannot exhaust memory.
            const stdout = new BoundedOutput(1024 * 1024);
            const stderr = new BoundedOutput(1024 * 1024);
            let stdoutPending = "";
            child.stdout?.on("data", (chunk) => {
              const text = String(chunk);
              stdout.append(text);
              const lines = `${stdoutPending}${text}`.split(/\r?\n/);
              stdoutPending = lines.pop() ?? "";
              const seconds = parseFfmpegProgressSeconds(lines.join("\n"));
              reportRemuxTimestamp(seconds);
            });
            child.stderr?.on("data", (chunk) => {
              stderr.append(chunk);
            });
            child.on("error", (error) => {
              const diagnostic = {
                tool: request.tool,
                executable: request.executable,
                args: executionArgs,
                exitCode: null,
                stdout: stdout.toString(),
                stderr: stderr.toString(),
                durationMs: Date.now() - startedAt,
                failureReason: error.message,
              };
              void pendingProgressWrite.then(() => resolve(diagnostic));
            });
            child.on("close", (code) => {
              const diagnostic = {
                tool: request.tool,
                executable: request.executable,
                args: executionArgs,
                exitCode: code,
                stdout: stdout.toString(),
                stderr: stderr.toString(),
                durationMs: Date.now() - startedAt,
                failureReason:
                  code === 0
                    ? null
                    : stderr.toString().trim().slice(-2000) ||
                      `ffmpeg 退出码 ${code}`,
              };
              void pendingProgressWrite.then(() => resolve(diagnostic));
            });
          });
        // Use FFmpeg's machine-readable progress protocol. Parsing human-oriented
        // stderr stats is locale/version dependent and was the reason the queue
        // stayed at 0% until the Remux finished.
        const progressArgs = [
          "-progress",
          "pipe:1",
          "-nostats",
          ...request.args,
        ];
        await addLog(jobId, "info", "DVD Remux 已启用 FFmpeg 结构化进度输出");
        const progressResult = await runFfmpegAttempt(progressArgs);
        if (
          !doesNotSupportFfmpegProgressOption(
            progressResult.exitCode,
            progressResult.stderr,
          )
        )
          return progressResult;

        await addLog(
          jobId,
          "warn",
          "当前 FFmpeg 不支持 -progress，已移除进度参数并用原 Remux 参数重试；封装可继续，但此版本无法显示百分比进度",
        );
        // An unsupported global option is rejected before media processing, but
        // remove any partial target defensively before retrying the exact legacy
        // command so no stale/truncated container can be mistaken for success.
        await fs.rm(outputPath, { force: true }).catch(() => {});
        return runFfmpegAttempt(request.args);
      },
      validateOutput: async (validatedPath) => {
        const outputProbe = await probeStreams(validatedPath);
        if (!isPlayableRemuxProbe(outputProbe)) {
          throw new Error("DVD 导航输出没有有效视频内容，自动回退 VOB concat");
        }
        await validateRemuxOutput(
          validatedPath,
          expectedDuration,
          async () => ({
            duration: outputProbe.duration,
            streams: outputProbe.streams.map((stream) => ({
              codecType: stream.codecType,
              language: stream.language,
            })),
            chapters: outputProbe.chapters,
          }),
          {
            // The selected logical title is authoritative.  sourceTitleInfo is a
            // physical VTS fallback and may represent a different programme on
            // multi-title DVDs, so never use its bytes as the Remux baseline.
            expectedSizeBytes:
              remuxAnalysisTitle?.estimatedSize &&
              remuxAnalysisTitle.estimatedSize > 0
                ? remuxAnalysisTitle.estimatedSize
                : null,
            minimumSizeRatio: 0.65,
            maximumSizeRatio: 1.05,
            maximumSizeOverheadBytes: 16 * 1024 * 1024,
            maximumDurationDrift: 0.02,
            expectedStreamCounts: {
              video: videoStreams.length,
              audio: audioStreams.length,
              subtitle: subtitleStreams.length,
            },
            expectedChapterCount,
          },
        );
        const endPlayable = await verifyOutputEndPlayable(
          jobId,
          validatedPath,
          outputProbe.duration ?? expectedDuration,
        );
        if (!endPlayable.ok) {
          throw new Error(
            `DVD Remux 输出末尾解码失败，自动回退 VOB concat：${endPlayable.error}`,
          );
        }
        await addLog(
          jobId,
          "info",
          `DVD Remux 输出校验通过：流轨 ${outputProbe.streams.length} 条，章节 ${outputProbe.chapters.length} 个，时长 ${outputProbe.duration?.toFixed(1) ?? "未知"} 秒`,
        );
      },
    });
  try {
    result = await executeWithArgs(args);
  } catch (navigationError) {
    if (!ffmpegSupportsDvdTitleNavigation(navigationError))
      throw navigationError;
    if (
      !canUsePhysicalDvdVobFallback({
        requestedLogicalTitleNumber: titleNumber,
        physicalVtsNumber: sourceTitleInfo.titleNumber,
        mappingConfirmed:
          typeof physicalVtsNumber === "number" &&
          sourceTitleInfo.titleNumber === physicalVtsNumber,
      })
    ) {
      throw new Error(
        "DVD 导航读取失败，且没有与所选逻辑标题一一对应的 VTS 文件组；已停止回退，避免输出错误标题",
      );
    }
    await addLog(
      jobId,
      "warn",
      `DVD 导航 Remux 失败，自动回退 VOB concat：${navigationError instanceof Error ? navigationError.message : String(navigationError)}`,
    );
    const fallbackListFile = await writeDvdConcatListFile(
      sourceTitleInfo,
      `verified-fallback-vob-${jobId}`,
    );
    trackJobOutputFile(jobId, fallbackListFile, { temp: true });
    try {
      const fallbackArgs = buildDvdVobFallbackArgs({
        concatInputArgs: dvdConcatInputArgs(fallbackListFile),
        typeMaps: buildDvdTypeMaps(plannerSnapshot, remuxAnalysisTitle),
        outputPath,
        selectedAudioStreams: audioStreams,
        selectedAudioCodecs,
        selectedSubtitleStreams: subtitleStreams,
        subtitleMetadata: subtitleStreams.map((inputIndex) => {
          const stream = remuxAnalysisTitle?.streams.find(
            (candidate) => candidate.index === inputIndex,
          );
          return {
            inputIndex,
            language: stream?.language ?? null,
            title: stream?.title ?? null,
          };
        }),
        chapterMetadataPath,
      });
      await addLog(
        jobId,
        "info",
        `DVD Remux 回退 VOB concat 参数：${JSON.stringify(fallbackArgs)}`,
      );
      result = await executeWithArgs(fallbackArgs);
    } finally {
      await fs.unlink(fallbackListFile).catch(() => {});
    }
  } finally {
    if (chapterMetadataPath)
      await fs.unlink(chapterMetadataPath).catch(() => {});
  }
  await db
    .update(jobsTable)
    .set({ progress: 99, etaSeconds: null })
    .where(eq(jobsTable.id, jobId));
  await addLog(
    jobId,
    "info",
    `FFmpeg 退出码：${result.diagnostic.exitCode}；耗时 ${result.diagnostic.durationMs} ms`,
  );
  if (result.diagnostic.stderr.trim())
    await addLog(
      jobId,
      "info",
      `ffmpeg stderr:\n${result.diagnostic.stderr.trim().slice(-4000)}`,
    );
  await db
    .update(jobsTable)
    .set({
      status: "done",
      progress: 100,
      outputPath,
      fileSizeAfter: result.fileSize,
      completedAt: new Date(),
      errorMessage: null,
    })
    .where(eq(jobsTable.id, jobId));
  await addLog(
    jobId,
    "info",
    `DVD Remux 完成 — 实际文件大小 ${result.fileSize} 字节；输出：${outputPath}`,
  );
  await settlePreviewTaskSafely(jobId, {
    taskKind: "remux",
    outputValid: true,
    isPreviewOnly: false,
    cancelled: false,
  });
}
