import { describe, expect, it } from "vitest";
import {
  bitDepthTag,
  buildCompressionOutputName,
  buildRemuxOutputName,
  normalizeAudioCodec,
  normalizeEncoderName,
  resolutionTag,
  selectBestAudioTrack,
  sourceLabel,
} from "./output-naming";

describe("output naming", () => {
  it("adds source and Remux suffix for disc remux outputs", () => {
    expect(buildRemuxOutputName("Movie", "dvd", "mkv")).toBe(
      "Movie.DVD.Remux.mkv",
    );
    expect(buildRemuxOutputName("Movie", "bluray", "mkv")).toBe(
      "Movie.BluRay.Remux.mkv",
    );
    expect(buildRemuxOutputName("Movie", "iso", "mkv")).toBe(
      "Movie.ISO.Remux.mkv",
    );
    expect(buildRemuxOutputName("Movie", "video", "mkv")).toBe(
      "Movie.Video.Remux.mkv",
    );
  });

  it("normalizes source, encoder, and audio labels for compression outputs", () => {
    expect(sourceLabel("dvd")).toBe("DVD");
    expect(sourceLabel("bluray")).toBe("BluRay");
    expect(normalizeEncoderName("x264_10bit")).toBe("H264-10bit");
    expect(normalizeEncoderName("x265_10bit")).toBe("H265-10bit");
    expect(normalizeAudioCodec("dca")).toBe("DTS");
    expect(normalizeAudioCodec("ac3")).toBe("AC3");
  });

  it("adds source, encoder, RF, and primary audio codec for compression outputs", () => {
    expect(
      buildCompressionOutputName({
        baseName: "Movie",
        mediaType: "dvd",
        outputFormat: "mkv",
        encoder: "x264_10bit",
        crf: 18,
        primaryAudioCodec: "ac3",
      }),
    ).toBe("Movie.DVDrip.H264.10bit.AC3.mkv");
    expect(
      buildCompressionOutputName({
        baseName: "Movie",
        mediaType: "bluray",
        outputFormat: "mkv",
        encoder: "x265_10bit",
        crf: 20,
        primaryAudioCodec: "dca",
        height: 1080,
      }),
    ).toBe("Movie.1080p.BluRay.10bit.DTS.mkv");
    expect(
      buildCompressionOutputName({
        baseName: "Movie",
        mediaType: "video",
        outputFormat: "mkv",
        encoder: "x264_10bit",
        primaryAudioCodec: "ac3",
        height: 720,
      }),
    ).toBe("Movie.720p.H264.10bit.AC3.mkv");
  });

  it("removes Chinese characters from output file names", () => {
    expect(
      buildRemuxOutputName("All.Things.Fair.1995.教室别恋", "dvd", "mkv"),
    ).toBe("All.Things.Fair.1995.DVD.Remux.mkv");
    expect(
      buildRemuxOutputName(
        "Helene.Grimaud.Mozart.Schumann.Silvestrov.2023.海伦·格里莫独奏音乐会",
        "bluray",
        "mkv",
      ),
    ).toBe("Helene.Grimaud.Mozart.Schumann.Silvestrov.2023.BluRay.Remux.mkv");
    expect(
      buildCompressionOutputName({
        baseName: "流浪地球.2019",
        mediaType: "bluray",
        outputFormat: "mkv",
        encoder: "x265_10bit",
        crf: 18,
        primaryAudioCodec: null,
      }),
    ).toBe("2019.BluRay.10bit.Audio.mkv");
    expect(buildRemuxOutputName("纯中文名", "bluray", "mkv")).toBe(
      "Untitled.BluRay.Remux.mkv",
    );
  });

  it("emits resolution/bit-depth tags and picks the best audio label", () => {
    expect(resolutionTag(1080)).toBe("1080p");
    expect(resolutionTag(480)).toBe("");
    expect(bitDepthTag(10)).toBe("10bit");
    expect(bitDepthTag(8)).toBe("");
    const best = selectBestAudioTrack([
      { codec: "aac", channels: 2, bitrate: 192_000 },
      { codec: "dts_hd_ma", channels: 8, bitrate: 4_000_000 },
      { codec: "ac3", channels: 6, bitrate: 448_000 },
    ]);
    expect(best?.codec).toBe("dts_hd_ma");
  });
});
