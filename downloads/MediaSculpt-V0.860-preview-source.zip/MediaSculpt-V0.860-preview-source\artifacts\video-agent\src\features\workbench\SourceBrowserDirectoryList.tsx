import { ChevronRight, Disc, Film, Folder } from "lucide-react";
import type { BrowseResultEntriesItem } from "@workspace/api-client-react";
import { Button } from "../../components/ui/button";
import { Checkbox } from "../../components/ui/checkbox";
import { cn } from "../../lib/utils";
import { formatDiscBytes } from "./disc-display-model";
import { isIsoFileName } from "./source-browser-model";

type DirectoryEntry = BrowseResultEntriesItem & {
  discType?: "bluray" | "dvd" | null;
};

export interface SourceBrowserDirectoryListProps {
  dirs: DirectoryEntry[];
  files: DirectoryEntry[];
  isLoading: boolean;
  isError: boolean;
  dirWarning: string | null;
  hasParent: boolean;
  selected: Set<string>;
  text: {
    loadingConfig: string;
    discAnalysisHint: string;
    emptyDirectory: string;
    goToParentHint: string;
    batchTasks: string;
    analyze: string;
  };
  translate: (key: string, params?: Record<string, string | number>) => string;
  fileTitle: (entry: DirectoryEntry) => string;
  onToggle: (path: string) => void;
  onNavigate: (path: string) => void;
  onAnalyze: (path: string) => void;
}

export function SourceBrowserDirectoryList({
  dirs,
  files,
  isLoading,
  isError,
  dirWarning,
  hasParent,
  selected,
  text,
  translate,
  fileTitle,
  onToggle,
  onNavigate,
  onAnalyze,
}: SourceBrowserDirectoryListProps) {
  return (
    <div className="rounded-lg border divide-y">
      {isLoading && (
        <div className="text-center text-muted-foreground text-sm py-10">
          {text.loadingConfig}
        </div>
      )}
      {isError && (
        <div className="text-center text-destructive text-sm py-10">
          {text.discAnalysisHint}
        </div>
      )}
      {!isLoading && !isError && dirs.length === 0 && files.length === 0 && (
        <div className="text-center text-muted-foreground text-sm py-10 space-y-1">
          <p>{dirWarning ?? text.emptyDirectory}</p>
          {dirWarning && hasParent && (
            <p className="text-xs">{text.goToParentHint}</p>
          )}
        </div>
      )}

      {dirs.map((entry) => {
        const isDisc = entry.discType;
        return (
          <div
            key={entry.path}
            className="w-full flex items-center gap-3 px-4 py-3 hover:bg-secondary/40 transition-colors text-left"
          >
            {isDisc ? (
              <Checkbox
                checked={selected.has(entry.path)}
                onCheckedChange={() => onToggle(entry.path)}
                className="shrink-0"
                title={text.batchTasks}
              />
            ) : (
              <span className="w-4 shrink-0" />
            )}
            {isDisc ? (
              <Disc
                className={cn(
                  "h-4 w-4 shrink-0",
                  isDisc === "bluray" ? "text-blue-400" : "text-purple-400",
                )}
              />
            ) : (
              <Folder className="h-4 w-4 text-blue-400 shrink-0" />
            )}
            <button
              type="button"
              onClick={() => onNavigate(entry.path)}
              className="min-w-0 flex-1 truncate text-left text-sm hover:text-primary"
            >
              {entry.name}
            </button>
            {isDisc && (
              <span
                className={cn(
                  "text-[10px] px-1.5 py-0.5 rounded font-medium shrink-0",
                  isDisc === "bluray"
                    ? "bg-blue-500/10 text-blue-400"
                    : "bg-purple-500/10 text-purple-400",
                )}
              >
                {isDisc === "bluray" ? "BD" : "DVD"}
              </span>
            )}
            {isDisc && (
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={() => onAnalyze(entry.path)}
              >
                <Disc className="mr-1.5 h-3.5 w-3.5" />
                {text.analyze}
              </Button>
            )}
            <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
          </div>
        );
      })}

      {files.map((entry) => {
        const checked = selected.has(entry.path);
        if (isIsoFileName(entry.name)) {
          return (
            <div
              key={entry.path}
              title={fileTitle(entry)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 transition-colors text-left",
                checked
                  ? "bg-primary/8 hover:bg-primary/12"
                  : "hover:bg-secondary/40",
              )}
            >
              <Checkbox
                checked={checked}
                onCheckedChange={() => onToggle(entry.path)}
                className="shrink-0"
              />
              <Disc className="h-4 w-4 shrink-0 text-blue-400" />
              <span className="min-w-0 flex-1 truncate text-sm">
                {entry.name}
              </span>
              {entry.sizeBytes != null && (
                <span className="text-xs text-muted-foreground font-mono">
                  {translate("scan.fileSizeLabel", {
                    size: formatDiscBytes(entry.sizeBytes),
                  })}
                </span>
              )}
              <span className="shrink-0 rounded bg-blue-500/10 px-1.5 py-0.5 text-[10px] font-medium text-blue-400">
                ISO
              </span>
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={() => onAnalyze(entry.path)}
              >
                <Disc className="mr-1.5 h-3.5 w-3.5" />
                {text.analyze}
              </Button>
            </div>
          );
        }
        return (
          <label
            key={entry.path}
            title={fileTitle(entry)}
            className={cn(
              "flex items-center gap-3 px-4 py-3 cursor-pointer transition-colors",
              checked
                ? "bg-primary/8 hover:bg-primary/12"
                : "hover:bg-secondary/40",
            )}
          >
            <Checkbox
              checked={checked}
              onCheckedChange={() => onToggle(entry.path)}
              className="shrink-0"
            />
            <Film className="h-4 w-4 text-orange-400 shrink-0" />
            <span className="flex-1 truncate text-sm">{entry.name}</span>
            {entry.sizeBytes != null && (
              <span className="text-xs text-muted-foreground font-mono">
                {translate("scan.fileSizeLabel", {
                  size: formatDiscBytes(entry.sizeBytes),
                })}
              </span>
            )}
          </label>
        );
      })}
    </div>
  );
}
