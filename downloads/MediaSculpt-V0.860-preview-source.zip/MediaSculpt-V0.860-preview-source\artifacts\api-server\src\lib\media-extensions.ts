// Media/subtitle file extensions shared by directory scanning and subtitle
// discovery. Extracted from routes/jobs.ts.
export const VIDEO_EXTENSIONS = [
  ".mkv",
  ".mp4",
  ".avi",
  ".mov",
  ".wmv",
  ".flv",
  ".m4v",
  ".ts",
  ".m2ts",
  ".iso",
  ".vob",
];
export const SUBTITLE_EXTENSIONS = [".srt", ".ass", ".ssa", ".sub", ".vtt"];
