import { describe, expect, it } from "vitest";
import { toSqliteValue } from "../../../../lib/db/src/migrate-postgres-to-sqlite";

describe("PostgreSQL to SQLite value conversion", () => {
  it("converts dates and booleans to node:sqlite bind values", () => {
    const date = new Date("2026-07-14T00:00:00.000Z");

    expect(toSqliteValue(date)).toBe(date.getTime());
    expect(toSqliteValue(true)).toBe(1);
    expect(toSqliteValue(false)).toBe(0);
    expect(toSqliteValue(undefined)).toBeNull();
  });
});
