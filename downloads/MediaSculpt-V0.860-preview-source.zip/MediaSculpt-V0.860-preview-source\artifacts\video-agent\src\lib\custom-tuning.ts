import { TUNING_CUSTOM_PRESETS_KEY } from "./brand-storage";

export type TuningLogicParamKind = "number" | "select" | "text";

export type TuningLogicParam = {
  key: string;
  label?: string;
  labelKey?: string;
  value: number | string;
  kind: TuningLogicParamKind;
  unit?: string;
  min?: number;
  max?: number;
  step?: number;
  options?: string[];
  hintKey?: string;
  hint?: string;
  default: number | string;
  custom: boolean;
};

export type CustomTuningLogic = {
  parameters: TuningLogicParam[];
};

export type CustomTuningPrompts = {
  analysis: string;
  identity: string;
  translate: string;
  readme: string;
  review: string;
};

export type CustomTuning = {
  prompts: CustomTuningPrompts;
  logic: CustomTuningLogic;
};

/** 内置逻辑参数的默认定义（界面显示用 i18n labelKey；未改名不存 label）。 */
export const DEFAULT_LOGIC_PARAMETERS: TuningLogicParam[] = [
  {
    key: "documentaryGbPer50min",
    labelKey: "settings.tuningLogic.documentaryGbPer50min",
    value: 2,
    kind: "number",
    unit: "GB",
    min: 0.5,
    max: 5,
    step: 0.1,
    hintKey: "settings.tuningLogic.documentaryGbPer50minHint",
    default: 2,
    custom: false,
  },
  {
    key: "movieGb",
    labelKey: "settings.tuningLogic.movieGb",
    value: 8,
    kind: "number",
    unit: "GB",
    min: 2,
    max: 20,
    step: 0.5,
    hintKey: "settings.tuningLogic.movieGbHint",
    default: 8,
    custom: false,
  },
  {
    key: "h265Ratio",
    labelKey: "settings.tuningLogic.h265Ratio",
    value: 0.7,
    kind: "number",
    min: 0.5,
    max: 1,
    step: 0.05,
    hintKey: "settings.tuningLogic.h265RatioHint",
    default: 0.7,
    custom: false,
  },
  {
    key: "minClipMinutes",
    labelKey: "settings.tuningLogic.minClipMinutes",
    value: 5,
    kind: "number",
    unit: "min",
    min: 1,
    max: 15,
    step: 1,
    hintKey: "settings.tuningLogic.minClipMinutesHint",
    default: 5,
    custom: false,
  },
  {
    key: "dvdDefaultMode",
    labelKey: "settings.tuningLogic.dvdDefaultMode",
    value: "remux",
    kind: "select",
    options: ["remux", "compress"],
    hintKey: "settings.tuningLogic.dvdDefaultModeHint",
    default: "remux",
    custom: false,
  },
  {
    key: "dvdCompressPreset",
    labelKey: "settings.tuningLogic.dvdCompressPreset",
    value: "dvd-convert",
    kind: "select",
    hintKey: "settings.tuningLogic.dvdCompressPresetHint",
    default: "dvd-convert",
    custom: false,
  },
];

export const DEFAULT_CUSTOM_TUNING: CustomTuning = {
  prompts: {
    analysis:
      "你是影刻资料检索助手。根据提供的源文件基本信息与用户提示词，检索并校对该影片/节目的资料。请按以下格式输出：\n" +
      "TITLE_EN=<校对后的纯英文/原文片名，单词用点连接，如 Prisoners.of.Terpsichore；只允许片名本身，禁止包含年份、季集号（S01E03/第一季）、分辨率（720p/1080p/576P）、编码（x264/HEVC）、音轨（AAC/DTS/AC3）、发布标签（BluRay/DVDRip/WEB-DL/Remux）或发布组>\n" +
      "TITLE_EN 必须输出：即使无法确认规范英文名，也按源文件名/目录名清洗掉年份、季集号、分辨率、编码、音轨、发布标签与发布组后输出（如 Kronprinz.Rudolf.2006.2DVD5.Rus.Eng.Kinosvalka&rutracker → Kronprinz.Rudolf），禁止留空、禁止照抄原始文件名。\n" +
      "TITLE_ZH=<校对后的中文片名，以豆瓣等简中平台为准；无法确认时留空>\n" +
      "YEAR=<发行年份，如 1995；无法确认时留空>\n" +
      "POSTER_URL=<可公开访问的海报图片 URL，找不到就不输出这一行>\n" +
      "年份核对规则：来源文件名/目录名或用户提示词中的年份代表该录制/发行版本，作为首选参照；但允许两类偏差——同一片名在外部资料中的年份与来源年份相差 1 年以内（±1 年）视为同一部作品；官方录像/发行年份可能晚于实际演出/录制年份多年（如 1967 年现场录制、2020 年才发行蓝光），来源年份与资料年份相差多年时仍可能是同一场演出，需结合片名、导演/艺术家、演出内容判断。只有片名相同但年份相差多年且确属重拍/新版/不同演出时，才判定为不同作品。\n" +
      "然后空一行，用当前界面语言输出基本信息简介：第一行给出一句话定位（规范英文名 · 规范中文名 · 年份 · 类型 · 国别/地区 · 片长；剧集/纪录片系列注明季数与集数）。随后是评价与资料栏（放在简介之前）：IMDb 编号（ttXXXXXXX，找到才写）、IMDb 评分（评分基准，含票数）、烂番茄/Letterboxd/Metacritic 等国际评分与媒体评价（标注来源）、豆瓣评分（仅参考并标注来源）。然后给出主创栏：导演、主要演员（含舞者/主持人/指挥等，按作品类型调整）必须中英文双语，格式为“中文译名（English Name / 原文名）”。最后是约 300-500 字的内容/剧情简介。评分规则：评分以 IMDb 为准，豆瓣只作参考并标注来源；对同性、女权、动画等题材，当 IMDb 与豆瓣评分差异超过约 1.5 分时，明确标注“两站评分差异较大，请谨慎参考”并说明可能原因。正文使用专业纯文本：禁止 Markdown 符号；禁止“识别依据”“综合判断”“与来源文件的技术特征相符”等过程性文字；不得提及文件格式、分辨率、编码、音轨或发布组（如 720p/x264/MVGroup），不得重复原始文件名。不要输出任何 JSON 动作，不要编造无法确认的事实。",
    identity:
      "根据文件名或片源名称，返回最可能的影片资料候选。不要编造无法确认的技术信息。\n" +
      "title 必须使用豆瓣常用的中文片名（不要自行直译英文片名；无法确认豆瓣中文名时降低 confidence 或返回空数组），titleEn 只保留纯英文/原文片名（单词用点连接），禁止包含年份、季集号、分辨率、编码、音轨、发布标签或发布组。只返回 JSON 数组，每项字段：title、titleEn、year、overview、mediaType（movie 或 tv）、confidence（0 到 1）、matchReason、technicalAssessment、recommendedAction。\n" +
      "year 与来源年份相差 1 年以内视为同一部作品；官方录像/发行年份可能晚于实际演出/录制年份多年，仍可能是同一场演出，不要仅凭年份差异排除。\n" +
      "matchReason 说明为什么与文件名和媒体特征匹配；technicalAssessment 用一句话总结时长、章节、分辨率、音轨/字幕等可核验信息；recommendedAction 只能是保留、压缩、Remux 或人工确认之一。不要把推测写成已确认事实。\n" +
      "最多返回 5 项；没有可靠候选时返回空数组。",
    translate: "",
    readme: "",
    review: "",
  },
  logic: {
    parameters: DEFAULT_LOGIC_PARAMETERS.map((param) => ({ ...param })),
  },
};

/** 智能工作流逻辑预设（场景卡片，鼠标点选即生效；只覆盖内置参数 key） */
export type TuningScenario = {
  id: string;
  labelKey: string;
  descKey: string;
  values: Record<string, number | string>;
};

export const TUNING_SCENARIOS: TuningScenario[] = [
  {
    id: "standard",
    labelKey: "settings.tuningScenarioStandard",
    descKey: "settings.tuningScenarioStandardDesc",
    values: {
      documentaryGbPer50min: 2,
      movieGb: 8,
      h265Ratio: 0.7,
      minClipMinutes: 5,
      dvdDefaultMode: "remux",
      dvdCompressPreset: "dvd-convert",
    },
  },
  {
    id: "light",
    labelKey: "settings.tuningScenarioLight",
    descKey: "settings.tuningScenarioLightDesc",
    values: {
      documentaryGbPer50min: 1.2,
      movieGb: 6,
      h265Ratio: 0.65,
      minClipMinutes: 5,
      dvdDefaultMode: "compress",
      dvdCompressPreset: "dvd-convert",
    },
  },
  {
    id: "quality",
    labelKey: "settings.tuningScenarioQuality",
    descKey: "settings.tuningScenarioQualityDesc",
    values: {
      documentaryGbPer50min: 3,
      movieGb: 10,
      h265Ratio: 0.8,
      minClipMinutes: 5,
      dvdDefaultMode: "remux",
      dvdCompressPreset: "bluray-collection",
    },
  },
  {
    id: "documentary",
    labelKey: "settings.tuningScenarioDocumentary",
    descKey: "settings.tuningScenarioDocumentaryDesc",
    values: {
      documentaryGbPer50min: 3,
      movieGb: 8,
      h265Ratio: 0.7,
      minClipMinutes: 10,
      dvdDefaultMode: "remux",
      dvdCompressPreset: "documentary",
    },
  },
  {
    id: "bluray",
    labelKey: "settings.tuningScenarioBluray",
    descKey: "settings.tuningScenarioBlurayDesc",
    values: {
      documentaryGbPer50min: 2,
      movieGb: 8,
      h265Ratio: 0.7,
      minClipMinutes: 5,
      dvdDefaultMode: "remux",
      dvdCompressPreset: "bluray-collection",
    },
  },
  {
    id: "fast",
    labelKey: "settings.tuningScenarioFast",
    descKey: "settings.tuningScenarioFastDesc",
    values: {
      documentaryGbPer50min: 4,
      movieGb: 15,
      h265Ratio: 0.9,
      minClipMinutes: 5,
      dvdDefaultMode: "remux",
      dvdCompressPreset: "balanced",
    },
  },
];

export { TUNING_CUSTOM_PRESETS_KEY } from "./brand-storage";

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function normalizeParam(raw: unknown): TuningLogicParam | null {
  if (!isPlainObject(raw)) return null;
  const key =
    typeof raw.key === "string" && raw.key.trim() ? raw.key.trim() : "";
  if (!key) return null;
  const builtin = DEFAULT_LOGIC_PARAMETERS.find((param) => param.key === key);
  const kind: TuningLogicParamKind =
    raw.kind === "select" || raw.kind === "text" ? raw.kind : "number";
  const value =
    typeof raw.value === "number" && Number.isFinite(raw.value)
      ? raw.value
      : typeof raw.value === "string"
        ? raw.value
        : (builtin?.value ?? 0);
  const defaultValue =
    typeof raw.default === "number" && Number.isFinite(raw.default)
      ? raw.default
      : typeof raw.default === "string"
        ? raw.default
        : (builtin?.default ?? value);
  return {
    key,
    ...(typeof raw.label === "string" && raw.label.trim()
      ? { label: raw.label.trim() }
      : {}),
    ...(builtin?.labelKey ? { labelKey: builtin.labelKey } : {}),
    value,
    kind,
    ...(typeof raw.unit === "string" && raw.unit.trim()
      ? { unit: raw.unit.trim() }
      : {}),
    ...(builtin?.hintKey ? { hintKey: builtin.hintKey } : {}),
    ...(typeof raw.hint === "string" && raw.hint.trim()
      ? { hint: raw.hint.trim() }
      : {}),
    min:
      typeof raw.min === "number" && Number.isFinite(raw.min)
        ? raw.min
        : builtin?.min,
    max:
      typeof raw.max === "number" && Number.isFinite(raw.max)
        ? raw.max
        : builtin?.max,
    step:
      typeof raw.step === "number" && Number.isFinite(raw.step) && raw.step > 0
        ? raw.step
        : (builtin?.step ?? 1),
    ...(Array.isArray(raw.options)
      ? {
          options: raw.options.filter(
            (option): option is string => typeof option === "string",
          ),
        }
      : builtin?.options
        ? { options: builtin.options }
        : {}),
    default: defaultValue,
    custom: raw.custom === true,
  };
}

export function parseCustomTuning(
  raw: string | null | undefined,
): CustomTuning {
  if (!raw) return DEFAULT_CUSTOM_TUNING;
  try {
    const parsed = JSON.parse(raw) as {
      prompts?: Partial<CustomTuningPrompts>;
      logic?: unknown;
    };
    const source = isPlainObject(parsed.logic) ? parsed.logic : {};
    let logic: CustomTuningLogic;
    if (Array.isArray(source.parameters)) {
      logic = {
        parameters: source.parameters
          .map(normalizeParam)
          .filter((param): param is TuningLogicParam => param !== null),
      };
    } else {
      // 旧格式：固定字段对象 → 迁移为参数表
      logic = {
        parameters: DEFAULT_LOGIC_PARAMETERS.map((definition) => ({
          ...definition,
          value:
            typeof source[definition.key] === "number" ||
            typeof source[definition.key] === "string"
              ? (source[definition.key] as number | string)
              : definition.value,
        })),
      };
    }
    return {
      prompts: { ...DEFAULT_CUSTOM_TUNING.prompts, ...(parsed.prompts ?? {}) },
      logic,
    };
  } catch {
    return DEFAULT_CUSTOM_TUNING;
  }
}

export function serializeCustomTuning(tuning: CustomTuning): string {
  return JSON.stringify(tuning, null, 2);
}

/** 按 key 查找参数。 */
export function logicParam(
  logic: CustomTuningLogic | undefined | null,
  key: string,
): TuningLogicParam | undefined {
  return logic?.parameters?.find((param) => param.key === key);
}

/** 读取参数值；缺失或非法时返回 fallback（内置参数被删除后即走默认值）。 */
export function logicValue<T extends number | string>(
  logic: CustomTuningLogic | undefined | null,
  key: string,
  fallback: T,
): T {
  const param = logicParam(logic, key);
  const value = param?.value;
  if (typeof fallback === "number") {
    return (
      typeof value === "number" && Number.isFinite(value) && value > 0
        ? value
        : fallback
    ) as T;
  }
  return (typeof value === "string" && value.trim() ? value : fallback) as T;
}
