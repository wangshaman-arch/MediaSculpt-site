import { useState, useCallback, useEffect, useRef } from "react";
import type { DiscTrack, DiscStream } from "@workspace/api-client-react";
import type { AnalyzeDiscQueryResult } from "@workspace/api-client-react";
import type { ProcessingMode } from "@/hooks/useWorkbenchState";
import type { DiscTrackWithMakeMkv } from "../disc-display-model";
import { isClearlyInvalidDiscTrack } from "../disc-job-mode-model";

type Translate = (
  path: string,
  params?: Record<string, string | number>,
) => string;
type ToastFn = (input: {
  title?: string;
  description?: string;
  variant?: "default" | "destructive";
}) => void;

/**
 * Owns DVD title verification: the verified/failed track metadata, in-flight
 * verification bookkeeping, and the two asynchronous verification passes.
 * It receives {@link initializeTrackSelection} so verification can enrich a
 * title's stream list without resetting the user's choices.
 */
export function useDiscAnalyzeVerification({
  data,
  processingMode,
  verifyDvdTitles,
  activeTrackIdx,
  initializeTrackSelection,
  t,
  toast,
}: {
  data: AnalyzeDiscQueryResult | undefined;
  processingMode: ProcessingMode;
  verifyDvdTitles: boolean;
  activeTrackIdx: number;
  initializeTrackSelection: (idx: number, track: DiscTrack) => void;
  t: Translate;
  toast: ToastFn;
}) {
  const [verifiedTracks, setVerifiedTracks] = useState<
    Map<number, DiscTrackWithMakeMkv>
  >(new Map());
  const [verifyingTracks, setVerifyingTracks] = useState<Set<number>>(
    new Set(),
  );
  const [verificationRequests, setVerificationRequests] = useState<
    Map<number, number>
  >(new Map());
  const [dvdVerificationComplete, setDvdVerificationComplete] = useState(false);
  const dvdVerificationScopeRef = useRef("");
  const verificationStateScopeRef = useRef("");
  const verifyingTracksRef = useRef<Set<number>>(new Set());
  const activeTrackRef = useRef(activeTrackIdx);
  activeTrackRef.current = activeTrackIdx;

  const effectiveTrack = useCallback(
    (idx: number): DiscTrackWithMakeMkv | undefined =>
      verifiedTracks.get(idx) ??
      (data?.tracks[idx] as DiscTrackWithMakeMkv | undefined),
    [data?.tracks, verifiedTracks],
  );

  // A newly opened analysis (or a mode change) must drop any verified snapshot
  // and in-flight verifications from the previous scope.
  useEffect(() => {
    if (!data?.tracks[0]) return;
    const scope = `${data.analysisId}:${data.sourceFingerprint}:${data.discType}:${processingMode}`;
    if (verificationStateScopeRef.current === scope) return;
    verificationStateScopeRef.current = scope;
    setVerifiedTracks(new Map());
    setVerifyingTracks(new Set());
    setVerificationRequests(new Map());
    setDvdVerificationComplete(false);
    dvdVerificationScopeRef.current = "";
  }, [
    data?.analysisId,
    data?.sourceFingerprint,
    data?.discType,
    processingMode,
  ]);

  const requestReverification = useCallback((idx: number) => {
    setVerifiedTracks((previous) => {
      const next = new Map(previous);
      next.delete(idx);
      return next;
    });
    setVerificationRequests((previous) =>
      new Map(previous).set(idx, (previous.get(idx) ?? 0) + 1),
    );
  }, []);

  // Verify every candidate DVD title once after analysis. The previous active-
  // title-only verification made Remux/compression appear to contain only the
  // main title even when other valid VOB groups were available.
  useEffect(() => {
    if (
      (processingMode !== "remux" && processingMode !== "compress") ||
      data?.discType !== "dvd" ||
      !data.analysisId
    )
      return;
    const analysis = data;
    const scope = `${analysis.analysisId}:${analysis.sourceFingerprint}:${processingMode}`;
    if (dvdVerificationScopeRef.current === scope) return;
    dvdVerificationScopeRef.current = scope;
    const controller = new AbortController();
    let cancelled = false;
    const candidateIndices = analysis.tracks.flatMap((rawTrack, idx) => {
      const track = rawTrack as DiscTrackWithMakeMkv;
      return track.titleId && !isClearlyInvalidDiscTrack(track) ? [idx] : [];
    });

    async function verifyCandidate(idx: number) {
      const track = analysis.tracks[idx] as DiscTrackWithMakeMkv | undefined;
      if (!track?.titleId) return;
      verifyingTracksRef.current.add(idx);
      setVerifyingTracks((previous) => new Set(previous).add(idx));
      try {
        const response = await fetch("/api/disc/verify-title", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({
            analysisId: analysis.analysisId,
            titleId: track.titleId,
            force: false,
          }),
        });
        const body = (await response.json().catch(() => ({}))) as Record<
          string,
          unknown
        >;
        if (!response.ok || body.verified !== true)
          throw new Error(
            String(
              body.failureReason ?? body.error ?? t("scan.titleVerifyFailed"),
            ),
          );
        if (cancelled) return;
        const verifiedTrack: DiscTrackWithMakeMkv = {
          ...track,
          durationSeconds:
            typeof body.durationSeconds === "number"
              ? body.durationSeconds
              : track.durationSeconds,
          streams: Array.isArray(body.streams)
            ? (body.streams as DiscStream[])
            : track.streams,
          chapters: Array.isArray(body.chapters)
            ? (body.chapters as DiscTrack["chapters"])
            : track.chapters,
          dvdVtsNumber:
            typeof body.titleNumber === "number" ? body.titleNumber : null,
          verificationStatus: "verified",
          verificationFailureReason: null,
          verificationWarnings: Array.isArray(body.warnings)
            ? body.warnings.filter(
                (item): item is string => typeof item === "string",
              )
            : [],
        };
        setVerifiedTracks((previous) =>
          new Map(previous).set(idx, verifiedTrack),
        );
        initializeTrackSelection(idx, verifiedTrack);
      } catch (error) {
        if (
          cancelled ||
          (error instanceof DOMException && error.name === "AbortError")
        )
          return;
        const failedTrack: DiscTrackWithMakeMkv = {
          ...track,
          verificationStatus: "failed",
          verificationFailureReason:
            error instanceof Error ? error.message : String(error),
        };
        setVerifiedTracks((previous) =>
          new Map(previous).set(idx, failedTrack),
        );
      } finally {
        verifyingTracksRef.current.delete(idx);
        setVerifyingTracks((previous) => {
          if (!previous.has(idx)) return previous;
          const next = new Set(previous);
          next.delete(idx);
          return next;
        });
      }
    }

    void (async () => {
      for (const idx of candidateIndices) {
        if (cancelled) return;
        await verifyCandidate(idx);
      }
      if (!cancelled) setDvdVerificationComplete(true);
    })();
    return () => {
      cancelled = true;
      controller.abort();
      for (const idx of candidateIndices)
        verifyingTracksRef.current.delete(idx);
    };
  }, [
    data?.analysisId,
    data?.discType,
    data?.sourceFingerprint,
    data?.tracks,
    initializeTrackSelection,
    processingMode,
    t,
    verifyDvdTitles,
  ]);

  useEffect(() => {
    if (
      !verifyDvdTitles ||
      data?.discType !== "dvd" ||
      !data.analysisId ||
      activeTrackIdx < 0 ||
      (verificationRequests.get(activeTrackIdx) ?? 0) <= 0
    )
      return;
    const track = effectiveTrack(activeTrackIdx);
    if (
      !track ||
      track.verificationStatus === "verified" ||
      track.verificationStatus === "failed" ||
      verifyingTracksRef.current.has(activeTrackIdx)
    )
      return;
    const trackIdx = activeTrackIdx;
    const controller = new AbortController();
    let cancelled = false;
    verifyingTracksRef.current.add(trackIdx);
    setVerifyingTracks((previous) => new Set(previous).add(trackIdx));
    void fetch("/api/disc/verify-title", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({
        analysisId: data.analysisId,
        titleId: track.titleId,
        force: (verificationRequests.get(trackIdx) ?? 0) > 0,
      }),
    })
      .then(async (response) => {
        const body = (await response.json().catch(() => ({}))) as Record<
          string,
          unknown
        >;
        if (!response.ok || body.verified !== true)
          throw new Error(
            String(
              body.failureReason ?? body.error ?? t("scan.titleVerifyFailed"),
            ),
          );
        if (cancelled || activeTrackRef.current !== trackIdx) return;
        const verifiedTrack: DiscTrackWithMakeMkv = {
          ...track,
          durationSeconds:
            typeof body.durationSeconds === "number"
              ? body.durationSeconds
              : track.durationSeconds,
          streams: Array.isArray(body.streams)
            ? (body.streams as DiscStream[])
            : track.streams,
          chapters: Array.isArray(body.chapters)
            ? (body.chapters as DiscTrack["chapters"])
            : track.chapters,
          dvdVtsNumber:
            typeof body.titleNumber === "number" ? body.titleNumber : null,
          verificationStatus: "verified",
          verificationFailureReason: null,
          verificationWarnings: Array.isArray(body.warnings)
            ? body.warnings.filter(
                (item): item is string => typeof item === "string",
              )
            : [],
        };
        setVerifiedTracks((previous) =>
          new Map(previous).set(trackIdx, verifiedTrack),
        );
        // Verification may enrich streams/chapters, but must never reset a user's choices.
        initializeTrackSelection(trackIdx, verifiedTrack);
      })
      .catch((error) => {
        if (
          cancelled ||
          (error instanceof DOMException && error.name === "AbortError")
        )
          return;
        const failedTrack: DiscTrackWithMakeMkv = {
          ...track,
          verificationStatus: "failed",
          verificationFailureReason:
            error instanceof Error ? error.message : String(error),
        };
        setVerifiedTracks((previous) =>
          new Map(previous).set(trackIdx, failedTrack),
        );
        toast({
          title: t("scan.titleVerifyFailed"),
          description: failedTrack.verificationFailureReason ?? undefined,
          variant: "destructive",
        });
      })
      .finally(() => {
        verifyingTracksRef.current.delete(trackIdx);
        if (cancelled) return;
        setVerifyingTracks((previous) => {
          const next = new Set(previous);
          next.delete(trackIdx);
          return next;
        });
      });
    return () => {
      cancelled = true;
      controller.abort();
      verifyingTracksRef.current.delete(trackIdx);
      setVerifyingTracks((previous) => {
        if (!previous.has(trackIdx)) return previous;
        const next = new Set(previous);
        next.delete(trackIdx);
        return next;
      });
    };
  }, [
    activeTrackIdx,
    data?.analysisId,
    data?.discType,
    effectiveTrack,
    initializeTrackSelection,
    processingMode,
    toast,
    verificationRequests,
    verifyDvdTitles,
  ]);

  return {
    verifiedTracks,
    setVerifiedTracks,
    verifyingTracks,
    setVerifyingTracks,
    verificationRequests,
    setVerificationRequests,
    dvdVerificationComplete,
    setDvdVerificationComplete,
    verifyingTracksRef,
    requestReverification,
    effectiveTrack,
  };
}

export type DiscAnalyzeVerificationState = ReturnType<
  typeof useDiscAnalyzeVerification
>;
