import { describe, expect, it, vi } from "vitest";
import { JobRunner } from "./job-runner";

describe("JobRunner", () => {
  it("starts a job only when no other job is running", async () => {
    const start = vi.fn(async () => {});
    const runner = new JobRunner({
      getRunningStatuses: async () => [],
      validateBeforeStart: async () => true,
      start,
    });

    await expect(runner.startWhenIdle(7)).resolves.toBe(true);
    expect(start).toHaveBeenCalledWith(7);
  });

  it("queues a job without starting it while another job is running", async () => {
    const start = vi.fn(async () => {});
    const logQueued = vi.fn(async () => {});
    const runner = new JobRunner({
      getRunningStatuses: async () => ["compressing"],
      validateBeforeStart: async () => true,
      start,
      logQueued,
    });

    await expect(runner.startWhenIdle(8)).resolves.toBe(false);
    expect(start).not.toHaveBeenCalled();
    expect(logQueued).toHaveBeenCalledWith(8);
  });

  it("does not start a job when snapshot validation fails", async () => {
    const start = vi.fn(async () => {});
    const runner = new JobRunner({
      getRunningStatuses: async () => [],
      validateBeforeStart: async () => false,
      start,
    });

    await expect(runner.startWhenIdle(9)).resolves.toBe(false);
    expect(start).not.toHaveBeenCalled();
  });

  it("does not launch the same job twice while its start callback is pending", async () => {
    let release!: () => void;
    const start = vi.fn(
      () =>
        new Promise<void>((resolve) => {
          release = resolve;
        }),
    );
    const runner = new JobRunner({
      getRunningStatuses: async () => [],
      validateBeforeStart: async () => true,
      start,
    });

    const first = runner.startWhenIdle(10);
    await expect(runner.startWhenIdle(10)).resolves.toBe(false);
    expect(start).toHaveBeenCalledTimes(1);
    release();
    await expect(first).resolves.toBe(true);
  });

  it("honors queue pause before selecting the next pending job", async () => {
    const findNextPending = vi.fn(async () => 11);
    const start = vi.fn(async () => {});
    const runner = new JobRunner({
      getRunningStatuses: async () => [],
      validateBeforeStart: async () => true,
      findNextPending,
      start,
    });

    await expect(runner.startNextPending(true)).resolves.toBe(false);
    expect(findNextPending).not.toHaveBeenCalled();
    expect(start).not.toHaveBeenCalled();
  });
});
