import { Router } from "express";
import { appendRuntimeToolLog } from "../lib/runtime-tool-log";
import { isQueuePaused, setQueuePaused } from "./jobs-tracking";
import { startNextPendingJob } from "./job-runtime";

const router = Router();
// 队列暂停状态查询。必须注册在 GET /jobs/:id 之前，否则 “queue-status” 会被当成任务 ID 返回 400。
router.get("/jobs/queue-status", async (_req, res) => {
  return res.json({ paused: isQueuePaused() });
});

// 队列调度暂停：当前任务继续跑完，但不再自动开始下一个 pending 任务。
router.post("/jobs/queue/pause", async (_req, res) => {
  setQueuePaused(true);
  await appendRuntimeToolLog("队列已暂停：不再自动开始新任务").catch(() => {});
  return res.json({ paused: true });
});

// 队列调度恢复：恢复自动调度，并立即尝试启动下一个待处理任务。
router.post("/jobs/queue/resume", async (_req, res) => {
  setQueuePaused(false);
  await appendRuntimeToolLog("队列已恢复自动调度").catch(() => {});
  void startNextPendingJob().catch(() => {});
  return res.json({ paused: false });
});

export const jobsCrudQueueRouter = router;
