import { describe, expect, it } from "vitest";
import {
  createMediaPipelineManifest,
  type MediaPipelineInput,
} from "./media-pipeline-contract";
import {
  decideSubtitlePipeline,
  type SubtitlePipelineMode,
} from "./subtitle-pipeline";

function manifest(
  streams: MediaPipelineInput["title"]["streams"],
  mode: "remux" | "compress" | "subtitle" = "subtitle",
) {
  return createMediaPipelineManifest({
    source: {
      kind: "file",
      path: "D:\\Movie.mkv",
      fingerprint: "movie-v1",
      physicalBytes: 1_000,
    },
    title: {
      id: "file:movie",
      titleNumber: null,
      durationSeconds: 5_400,
      streams,
      chapters: [],
    },
    selection: {
      streamIds: streams.map((stream) => stream.id),
      chapterIds: [],
    },
    output: { mode, directory: "D:\\Output", fileName: "Movie.mkv" },
  });
}

const audio = {
  id: "audio:1",
  index: 1,
  type: "audio" as const,
  codec: "ac3",
  language: "en",
};

describe("subtitle pipeline routing", () => {
  it("translates an existing foreign text subtitle without OCR or Whisper", () => {
    const result = decideSubtitlePipeline({
      manifest: manifest([
        { id: "video:0", index: 0, type: "video", codec: "h264" },
        audio,
        {
          id: "subtitle:2",
          index: 2,
          type: "subtitle",
          codec: "subrip",
          language: "en",
        },
      ]),
      mode: "auto",
    });
    expect(result).toMatchObject({
      strategy: "translate-text",
      runOcr: false,
      runWhisper: false,
      translate: true,
    });
  });

  it("routes a graphic subtitle to OCR and never Whisper", () => {
    const result = decideSubtitlePipeline({
      manifest: manifest([
        { id: "video:0", index: 0, type: "video", codec: "h264" },
        audio,
        {
          id: "subtitle:2",
          index: 2,
          type: "subtitle",
          codec: "hdmv_pgs_subtitle",
          language: "en",
        },
      ]),
      mode: "auto",
    });
    expect(result).toMatchObject({
      strategy: "ocr-graphic",
      sourceSubtitleId: "subtitle:2",
      runOcr: true,
      runWhisper: false,
      translate: true,
      preserveOriginal: true,
    });
  });

  it("treats HandBrake's bitmap label as a graphic subtitle routed to OCR", () => {
    const result = decideSubtitlePipeline({
      manifest: manifest([
        { id: "video:0", index: 0, type: "video", codec: "h264" },
        audio,
        {
          id: "subtitle:2",
          index: 2,
          type: "subtitle",
          codec: "bitmap",
          language: "en",
        },
      ]),
      mode: "auto",
    });
    expect(result).toMatchObject({
      strategy: "ocr-graphic",
      runOcr: true,
      runWhisper: false,
    });
  });

  it("keeps the OCR route after an OCR failure instead of switching to speech recognition", () => {
    const result = decideSubtitlePipeline({
      manifest: manifest([
        { id: "video:0", index: 0, type: "video", codec: "h264" },
        audio,
        {
          id: "subtitle:2",
          index: 2,
          type: "subtitle",
          codec: "dvd_subtitle",
          language: "en",
        },
      ]),
      mode: "auto",
      ocrFailed: true,
    });
    expect(result.strategy).toBe("ocr-graphic");
    expect(result.runWhisper).toBe(false);
    expect(result.warning).toContain("OCR");
  });

  it("uses Whisper only when automatic mode has no subtitle", () => {
    const result = decideSubtitlePipeline({
      manifest: manifest([
        { id: "video:0", index: 0, type: "video", codec: "h264" },
        audio,
      ]),
      mode: "auto",
    });
    expect(result).toMatchObject({
      strategy: "whisper-audio",
      sourceAudioId: "audio:1",
      runOcr: false,
      runWhisper: true,
    });
  });

  it("honors explicit Whisper and skip modes", () => {
    const input = manifest([
      { id: "video:0", index: 0, type: "video", codec: "h264" },
      audio,
      {
        id: "subtitle:2",
        index: 2,
        type: "subtitle",
        codec: "hdmv_pgs_subtitle",
        language: "en",
      },
    ]);
    expect(
      decideSubtitlePipeline({
        manifest: input,
        mode: "whisper" as SubtitlePipelineMode,
      }),
    ).toMatchObject({
      strategy: "whisper-audio",
      runWhisper: true,
      runOcr: false,
    });
    expect(
      decideSubtitlePipeline({ manifest: input, mode: "skip" }),
    ).toMatchObject({
      strategy: "none",
      runWhisper: false,
      runOcr: false,
      translate: false,
    });
  });
});
