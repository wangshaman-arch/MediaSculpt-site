import { describe, expect, it } from "vitest";
import {
  AI_FILLABLE_FIELDS,
  applyAiEnrichment,
  buildAiEnrichmentPrompt,
  missingEnrichableFields,
  normalizeSuggestion,
} from "./metadata-ai";
import type { MetadataResult } from "./metadata";

function base(overrides: Partial<MetadataResult> = {}): MetadataResult {
  return {
    title: "美丽心灵",
    titleEn: "A Beautiful Mind",
    year: 2001,
    imdbId: "tt0268978",
    mediaType: "movie",
    source: "imdb",
    ...overrides,
  };
}

describe("AI metadata enrichment", () => {
  // The default must be off: an LLM can invent facts, so nothing is applied
  // unless the user explicitly enabled enrichment.
  it("changes nothing while disabled", () => {
    const outcome = applyAiEnrichment({
      result: base(),
      suggestion: { director: "Ron Howard", cast: "Russell Crowe" },
      enabled: false,
    });
    expect(outcome.used).toBe(false);
    expect(outcome.skippedReason).toBe("disabled");
    expect(outcome.result.director).toBeUndefined();
    expect(outcome.filled).toEqual([]);
  });

  it("fills only the fields that are empty", () => {
    const outcome = applyAiEnrichment({
      result: base({ director: "Ron Howard", genres: "剧情" }),
      suggestion: {
        director: "错误导演",
        cast: "Russell Crowe、Jennifer Connelly",
        genres: "错误类型",
        overview: "A biographical drama…",
      },
      enabled: true,
    });
    expect(outcome.used).toBe(true);
    expect(outcome.filled.sort()).toEqual(["cast", "overview"]);
    // Populated values are never replaced.
    expect(outcome.result.director).toBe("Ron Howard");
    expect(outcome.result.genres).toBe("剧情");
    expect(outcome.result.cast).toBe("Russell Crowe、Jennifer Connelly");
  });

  // Identity is the one thing an LLM must never be allowed to relabel.
  it("never lets AI touch identity fields", () => {
    const outcome = applyAiEnrichment({
      result: base(),
      suggestion: {
        title: "错误的片名",
        titleEn: "Wrong Title",
        year: 1999,
        imdbId: "tt0000000",
        director: "Ron Howard",
      } as never,
      enabled: true,
    });
    expect(outcome.result.title).toBe("美丽心灵");
    expect(outcome.result.titleEn).toBe("A Beautiful Mind");
    expect(outcome.result.year).toBe(2001);
    expect(outcome.result.imdbId).toBe("tt0268978");
    expect(outcome.filled).toEqual(["director"]);
    expect(AI_FILLABLE_FIELDS).not.toContain("title" as never);
    expect(AI_FILLABLE_FIELDS).not.toContain("imdbId" as never);
  });

  // Every AI-sourced value must be attributable, so it is never mistaken for a
  // verified one.
  it("records the ai source for every field it fills", () => {
    const outcome = applyAiEnrichment({
      result: base(),
      suggestion: { director: "Ron Howard", cast: "Russell Crowe" },
      enabled: true,
      sources: { imdbId: "imdb" },
    });
    expect(outcome.sources).toMatchObject({
      imdbId: "imdb",
      director: "ai",
      cast: "ai",
    });
  });

  it("skips the call entirely when nothing is missing", () => {
    const complete = base({
      director: "d",
      cast: "c",
      genres: "g",
      overview: "o",
      runtimeMinutes: 135,
    });
    expect(missingEnrichableFields(complete)).toEqual([]);
    const outcome = applyAiEnrichment({
      result: complete,
      suggestion: { director: "x" },
      enabled: true,
    });
    expect(outcome.used).toBe(false);
    expect(outcome.skippedReason).toBe("nothing-missing");
  });

  it("treats an empty or useless response as no enrichment", () => {
    expect(
      applyAiEnrichment({ result: base(), suggestion: null, enabled: true })
        .skippedReason,
    ).toBe("empty-response");
    expect(
      applyAiEnrichment({ result: base(), suggestion: {}, enabled: true })
        .skippedReason,
    ).toBe("empty-response");
    const outcome = applyAiEnrichment({
      result: base(),
      suggestion: {
        director: "未知",
        cast: "N/A",
        overview: "unknown",
        runtimeMinutes: 0,
      },
      enabled: true,
    });
    expect(outcome.used).toBe(false);
    expect(outcome.result.director).toBeUndefined();
  });

  it("normalises a raw reply and drops unparsable values", () => {
    expect(
      normalizeSuggestion({
        director: "  Ron Howard  ",
        cast: "Russell Crowe, Jennifer Connelly",
        genres: "",
        overview: "n/a",
        runtimeMinutes: "135.6",
        title: "ignored",
      }),
    ).toEqual({
      director: "Ron Howard",
      cast: "Russell Crowe, Jennifer Connelly",
      runtimeMinutes: 136,
    });
    expect(normalizeSuggestion(null)).toEqual({});
    expect(normalizeSuggestion("plain text")).toEqual({});
  });

  // A Chinese-language prompt routinely comes back with a Chinese placeholder;
  // writing 未知 into the field would read as data instead of as absence.
  it("rejects Chinese placeholders as well as English ones", () => {
    expect(
      normalizeSuggestion({
        director: "未知",
        cast: "不详",
        genres: "暂无",
        overview: "无法确定",
        runtimeMinutes: 0,
      }),
    ).toEqual({});
    expect(normalizeSuggestion({ director: "　未知　" })).toEqual({});
    expect(normalizeSuggestion({ director: "Ron Howard" })).toEqual({
      director: "Ron Howard",
    });
  });

  it("reports which fields are missing on a sparse record", () => {
    const missing = missingEnrichableFields(base({ director: "Ron Howard" }));
    expect(missing).not.toContain("director");
    expect(missing).toContain("cast");
    expect(missing).toContain("overview");
    expect(missingEnrichableFields(null)).toEqual([]);
  });

  it("states the identity rule to the model and names only the missing fields", () => {
    const prompt = buildAiEnrichmentPrompt({
      title: "美丽心灵",
      titleEn: "A Beautiful Mind",
      year: 2001,
      imdbId: "tt0268978",
      missing: ["cast", "overview"],
    });
    expect(prompt).toContain("不要修改片名、年份、IMDb 号");
    expect(prompt).toContain("cast、overview");
    expect(prompt).not.toContain("director、");
  });
});
