import { useState, useCallback, useEffect, useRef } from "react";
import type { DiscTrack } from "@workspace/api-client-react";
import type { AnalyzeDiscQueryResult } from "@workspace/api-client-react";
import type { ProcessingMode } from "@/hooks/useWorkbenchState";
import type { DiscTrackWithMakeMkv } from "../disc-display-model";
import {
  defaultChapterSelection as modelDefaultChapterSelection,
  defaultStreamSelection as modelDefaultStreamSelection,
} from "../disc-selection-model";
import {
  isClearlyInvalidDiscTrack,
  mergeNewlyDiscoveredDiscStreams,
  selectCapacitySafeDiscTitles,
} from "../disc-job-mode-model";

/**
 * Owns the raw disc selection state (active title, selected titles, stream and
 * chapter selections) and the per-title stream discovery bookkeeping. These
 * primitives do not depend on verified title metadata, so they can be created
 * before the verification hook and handed to it.
 */
export function useDiscAnalyzeSelection({
  data,
  includeVideoStreams,
  filterTitlesByProcessingMode,
  processingMode,
  verifyDvdTitles,
  setPreviewPage,
}: {
  data: AnalyzeDiscQueryResult | undefined;
  includeVideoStreams: boolean;
  filterTitlesByProcessingMode: boolean;
  processingMode: ProcessingMode;
  verifyDvdTitles: boolean;
  setPreviewPage: (page: number) => void;
}) {
  const [activeTrackIdx, setActiveTrackIdx] = useState(-1);
  const [selectedTrackIndices, setSelectedTrackIndices] = useState<Set<number>>(
    new Set(),
  );
  const [streamSelections, setStreamSelections] = useState<
    Map<number, Set<number>>
  >(new Map());
  const [chapterSelections, setChapterSelections] = useState<
    Map<number, Set<number>>
  >(new Map());
  const [selectionInitialized, setSelectionInitialized] = useState<Set<number>>(
    new Set(),
  );
  const streamSelectionKnownIndexesRef = useRef<Map<number, Set<number>>>(
    new Map(),
  );
  const selectionScopeRef = useRef("");

  // Focusing a title prepares a complete export selection. Users can narrow it
  // explicitly in the selection summary without changing the title selection.
  const defaultStreamSelection = useCallback(
    (track?: DiscTrack) =>
      modelDefaultStreamSelection(track, includeVideoStreams),
    [includeVideoStreams, processingMode],
  );

  const defaultChapterSelection = useCallback(
    (track?: DiscTrack) => modelDefaultChapterSelection(track),
    [],
  );

  const initializeTrackSelection = useCallback(
    (idx: number, track: DiscTrack) => {
      const previouslyKnownIndexes =
        streamSelectionKnownIndexesRef.current.get(idx) ??
        new Set(
          (data?.tracks[idx]?.streams ?? []).map((stream) => stream.index),
        );
      const newlyDiscoveredSelectableIndexes = track.streams
        .filter(
          (stream) =>
            (includeVideoStreams || stream.codecType !== "video") &&
            !previouslyKnownIndexes.has(stream.index),
        )
        .map((stream) => stream.index);
      streamSelectionKnownIndexesRef.current.set(
        idx,
        new Set(track.streams.map((stream) => stream.index)),
      );
      setStreamSelections((current) => {
        const next = new Map(current);
        const existing = current.get(idx) ?? defaultStreamSelection(track);
        next.set(
          idx,
          mergeNewlyDiscoveredDiscStreams({
            selectedIndexes: existing,
            previouslyKnownIndexes,
            verifiedIndexes: newlyDiscoveredSelectableIndexes,
          }),
        );
        return next;
      });
      setChapterSelections((current) => {
        if (current.has(idx)) return current;
        return new Map(current).set(idx, defaultChapterSelection(track));
      });
      setSelectionInitialized((current) => {
        if (current.has(idx)) return current;
        const next = new Set(current);
        next.add(idx);
        return next;
      });
    },
    [
      data?.tracks,
      defaultChapterSelection,
      defaultStreamSelection,
      includeVideoStreams,
    ],
  );

  useEffect(() => {
    if (!data?.tracks[0]) return;
    setPreviewPage(0);
    const scope = `${data.analysisId}:${data.sourceFingerprint}:${data.discType}:${processingMode}`;
    if (selectionScopeRef.current === scope) return;
    selectionScopeRef.current = scope;
    streamSelectionKnownIndexesRef.current = new Map();
    if (verifyDvdTitles && data.discType === "dvd") {
      const firstValidIndex = data.tracks.findIndex(
        (track) => !isClearlyInvalidDiscTrack(track as DiscTrackWithMakeMkv),
      );
      setActiveTrackIdx(firstValidIndex >= 0 ? firstValidIndex : 0);
      setSelectedTrackIndices(new Set());
      setStreamSelections(new Map());
      setChapterSelections(new Map());
      setSelectionInitialized(new Set());
      return;
    }
    // Compress mode prefers HandBrake titles (merged full-performance grouping)
    // when available; Remux/subtitle modes use the per-m2ts fallback titles.
    const hasHandbrakeTitles = data.tracks.some(
      (track) => (track as DiscTrackWithMakeMkv).titleKind === "handbrake",
    );
    const visibleEntries = data.tracks
      .map((track, idx) => ({ track: track as DiscTrackWithMakeMkv, idx }))
      .filter(({ track }) => {
        if (!filterTitlesByProcessingMode) return true;
        const kind = track.titleKind;
        if (kind === "handbrake")
          return (
            processingMode === "compress" ||
            (processingMode === "remux" && typeof track.playlistId === "string")
          );
        if (kind === "m2ts")
          return processingMode !== "compress" || !hasHandbrakeTitles;
        return true;
      });
    // Focus the longest visible track for preview, but do not select it or any
    // stream/chapter automatically. Execution requires explicit user choices.
    const validVisibleEntries = visibleEntries.filter(
      ({ track }) => !isClearlyInvalidDiscTrack(track),
    );
    const initialEntry = validVisibleEntries.reduce<
      (typeof visibleEntries)[number] | null
    >(
      (best, entry) =>
        best == null ||
        (entry.track.durationSeconds ?? 0) > (best.track.durationSeconds ?? 0)
          ? entry
          : best,
      null,
    );
    const initialIdx = initialEntry ? initialEntry.idx : 0;
    const defaultIndices = selectCapacitySafeDiscTitles(
      data.tracks as Array<DiscTrackWithMakeMkv>,
      validVisibleEntries.map(({ idx }) => idx),
      data.sourceSizeBytes,
    );
    const defaultStreams = new Map<number, Set<number>>();
    const defaultChapters = new Map<number, Set<number>>();
    for (const idx of defaultIndices) {
      const track = data.tracks[idx];
      if (!track) continue;
      defaultStreams.set(idx, defaultStreamSelection(track));
      defaultChapters.set(idx, defaultChapterSelection(track));
    }
    setActiveTrackIdx(initialIdx);
    setSelectedTrackIndices(new Set(defaultIndices));
    setStreamSelections(defaultStreams);
    setChapterSelections(defaultChapters);
    setSelectionInitialized(new Set(defaultIndices));
  }, [
    data?.analysisId,
    data?.sourceFingerprint,
    data?.discType,
    data?.sourceSizeBytes,
    data?.tracks,
    defaultChapterSelection,
    defaultStreamSelection,
    filterTitlesByProcessingMode,
    processingMode,
    verifyDvdTitles,
    setPreviewPage,
  ]);

  return {
    activeTrackIdx,
    setActiveTrackIdx,
    selectedTrackIndices,
    setSelectedTrackIndices,
    streamSelections,
    setStreamSelections,
    chapterSelections,
    setChapterSelections,
    selectionInitialized,
    setSelectionInitialized,
    streamSelectionKnownIndexesRef,
    defaultStreamSelection,
    defaultChapterSelection,
    initializeTrackSelection,
  };
}

export type DiscAnalyzeSelectionState = ReturnType<
  typeof useDiscAnalyzeSelection
>;
