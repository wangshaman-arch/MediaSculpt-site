import type { MediaAnalysis, NormalizedSelection } from "./media-analysis";
import { normalizeSelection } from "./media-analysis";

export type MediaSelectionPlan = NormalizedSelection & {
  version: 1;
};

export function buildSelectionPlan(
  analysis: MediaAnalysis,
  selectedStreams?: number[],
  selectedChapters?: number[],
): MediaSelectionPlan {
  return {
    version: 1,
    ...normalizeSelection(analysis, selectedStreams, selectedChapters),
  };
}

export function parseSelectionPlan(
  raw: string | null | undefined,
): MediaSelectionPlan | null {
  if (!raw) return null;
  try {
    const value = JSON.parse(raw) as Partial<MediaSelectionPlan>;
    if (
      value.version !== 1 ||
      !Array.isArray(value.video) ||
      !Array.isArray(value.audio) ||
      !Array.isArray(value.subtitle) ||
      !Array.isArray(value.chapters)
    )
      return null;
    return {
      version: 1,
      video: value.video,
      audio: value.audio,
      subtitle: value.subtitle,
      chapters: value.chapters,
    };
  } catch {
    return null;
  }
}
