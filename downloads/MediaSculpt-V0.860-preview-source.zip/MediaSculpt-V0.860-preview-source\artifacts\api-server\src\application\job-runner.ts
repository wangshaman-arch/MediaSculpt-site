const RUNNING_STATUSES = new Set([
  "scanning",
  "transcribing",
  "compressing",
  "remuxing",
]);

export interface JobRunnerDependencies {
  getRunningStatuses: () => Promise<readonly string[]>;
  validateBeforeStart: (jobId: number) => Promise<boolean>;
  start: (jobId: number) => Promise<void>;
  findNextPending?: () => Promise<number | null>;
  logQueued?: (jobId: number) => Promise<void>;
  logNextPending?: (jobId: number) => Promise<void>;
}

/**
 * Serializes queue decisions so two HTTP requests cannot observe the same idle
 * queue and launch two jobs before either database update becomes visible.
 */
export class JobRunner {
  private queueLock: Promise<void> = Promise.resolve();
  private requestedStarts = new Set<number>();

  constructor(private readonly dependencies: JobRunnerDependencies) {}

  async startWhenIdle(jobId: number): Promise<boolean> {
    if (this.requestedStarts.has(jobId)) return false;
    this.requestedStarts.add(jobId);
    return this.withQueueLock(async () => {
      try {
        return await this.startWhenIdleUnlocked(jobId);
      } finally {
        this.requestedStarts.delete(jobId);
      }
    });
  }

  async startNextPending(paused = false): Promise<boolean> {
    if (paused || !this.dependencies.findNextPending) return false;

    return this.withQueueLock(async () => {
      if (this.hasRunningJob(await this.dependencies.getRunningStatuses()))
        return false;
      const nextJobId = await this.dependencies.findNextPending!();
      if (nextJobId == null) return false;
      if (this.requestedStarts.has(nextJobId)) return false;
      this.requestedStarts.add(nextJobId);
      try {
        await this.dependencies.logNextPending?.(nextJobId);
        return await this.startWhenIdleUnlocked(nextJobId);
      } finally {
        this.requestedStarts.delete(nextJobId);
      }
    });
  }

  private async startWhenIdleUnlocked(jobId: number): Promise<boolean> {
    if (this.hasRunningJob(await this.dependencies.getRunningStatuses())) {
      await this.dependencies.logQueued?.(jobId);
      return false;
    }
    if (!(await this.dependencies.validateBeforeStart(jobId))) return false;
    await this.dependencies.start(jobId);
    return true;
  }

  private hasRunningJob(statuses: readonly string[]): boolean {
    return statuses.some((status) => RUNNING_STATUSES.has(status));
  }

  private async withQueueLock<T>(work: () => Promise<T>): Promise<T> {
    const previous = this.queueLock;
    let release!: () => void;
    this.queueLock = new Promise<void>((resolve) => {
      release = resolve;
    });
    try {
      await previous;
      return await work();
    } finally {
      release();
    }
  }
}
