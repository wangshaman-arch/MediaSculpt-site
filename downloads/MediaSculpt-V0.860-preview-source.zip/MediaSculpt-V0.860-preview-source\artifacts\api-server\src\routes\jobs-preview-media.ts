import { Router } from "express";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import {
  ensureLocalPoster,
  MEDIA_INFO_DIR,
  POSTER_META_FILE,
  posterIdentityMatches,
} from "../lib/poster";
import { resolveRuntimePath } from "../lib/runtime-paths";
import { servePreviewSegment } from "../lib/preview-segments";
import { previewService } from "../media/preview-service";
import { getConfig } from "./jobs-config";
import { resolveMainTrack } from "../lib/disc";
import { streamContinuousPreview } from "./jobs-preview-stream";

const router = Router();
router.get("/media/preview.mp4", async (req, res) => {
  const rawPath =
    typeof req.query.path === "string" ? req.query.path.trim() : "";
  if (!rawPath) return res.status(400).json({ error: "path 参数不能为空" });
  const config = await getConfig();
  const sourcePath = resolveRuntimePath(rawPath, config);
  let filePath = sourcePath;
  try {
    const stat = await fs.stat(filePath);
    if (stat.isDirectory())
      filePath = await resolveMainTrack(filePath, "bluray").catch(
        () => filePath,
      );
    const fileStat = await fs.stat(filePath);
    if (!fileStat.isFile())
      return res.status(404).json({ error: "没有可预览的视频文件" });
  } catch {
    return res.status(404).json({ error: "视频文件不存在或无法读取" });
  }
  const seekRaw = typeof req.query.seek === "string" ? req.query.seek : "";
  const seekSeconds = Number(seekRaw);
  const hasSeek =
    seekRaw !== "" && Number.isFinite(seekSeconds) && seekSeconds > 0;
  const subRaw = typeof req.query.sub === "string" ? req.query.sub : "";
  const subIndex = Number(subRaw);
  const hasSub = subRaw !== "" && Number.isInteger(subIndex) && subIndex >= 0;
  let subTypeIndex: number | null = null;
  if (hasSub) {
    const containerIndices =
      await previewService.subtitleContainerIndices(filePath);
    const found = containerIndices.indexOf(subIndex);
    subTypeIndex = found >= 0 ? found : null;
  }
  // 默认使用连续流；旧的分段模式仅在显式 segment=1 时启用。
  if (req.query.segment === "1") {
    return servePreviewSegment(
      res,
      filePath,
      subTypeIndex,
      hasSeek ? seekSeconds : 0,
    );
  }
  return streamContinuousPreview(
    res,
    filePath,
    subTypeIndex,
    hasSeek ? seekSeconds : 0,
  );
});

async function resolveMediaPreviewFilePath(
  rawPath: string,
): Promise<string | null> {
  if (!rawPath) return null;
  const config = await getConfig();
  const sourcePath = resolveRuntimePath(rawPath, config);
  let filePath = sourcePath;
  try {
    const stat = await fs.stat(filePath);
    if (stat.isDirectory())
      filePath = await resolveMainTrack(filePath, "bluray").catch(
        () => filePath,
      );
    const fileStat = await fs.stat(filePath);
    return fileStat.isFile() ? filePath : null;
  } catch {
    return null;
  }
}

/** 源路径可能存在的海报目录：MediaInfo 子目录优先（新位置），再回退到目录根（旧位置）。 */
function posterDirectoriesForSource(sourcePath: string): string[] {
  const baseDirs: string[] = [];
  try {
    const stat = fsSync.statSync(sourcePath);
    if (stat.isFile()) {
      baseDirs.push(path.dirname(sourcePath));
    } else if (stat.isDirectory()) {
      baseDirs.push(sourcePath);
      const base = path.basename(sourcePath);
      if (/^(VIDEO_TS|BDMV|DVD|AUDIO_TS)$/i.test(base))
        baseDirs.push(path.dirname(sourcePath));
    }
  } catch {
    if (path.extname(sourcePath)) baseDirs.push(path.dirname(sourcePath));
    else baseDirs.push(sourcePath);
  }
  const uniqueBase = baseDirs.filter(
    (dir, index) => baseDirs.indexOf(dir) === index,
  );
  const infoDirs = uniqueBase.map((dir) => path.join(dir, MEDIA_INFO_DIR));
  return [...infoDirs, ...uniqueBase];
}

// GET /media/poster — 读取源目录里已保存的海报（poster.jpg / folder.jpg）。
router.get("/media/poster", async (req, res) => {
  const rawPath =
    typeof req.query.path === "string" ? req.query.path.trim() : "";
  if (!rawPath) return res.status(400).json({ error: "path 参数不能为空" });
  const expectedImdbId =
    typeof req.query.imdbId === "string" ? req.query.imdbId.trim() : "";
  const expectedTitle =
    typeof req.query.title === "string" ? req.query.title.trim() : "";
  const expectedTitleEn =
    typeof req.query.titleEn === "string" ? req.query.titleEn.trim() : "";
  const expectedYear =
    typeof req.query.year === "string" && /^\d{4}$/.test(req.query.year)
      ? Number(req.query.year)
      : undefined;
  const config = await getConfig();
  const sourcePath = resolveRuntimePath(rawPath, config);
  for (const dir of posterDirectoriesForSource(sourcePath)) {
    for (const name of ["poster.jpg", "folder.jpg"]) {
      const file = path.join(dir, name);
      try {
        const stat = await fs.stat(file);
        if (stat.isFile()) {
          // Once the task has a canonical IMDb id, never display a legacy
          // poster unless its sidecar provenance points to the same identity.
          // This prevents a failed refresh from surfacing a poster from a
          // previous, similarly named title.
          if (
            expectedImdbId ||
            expectedTitle ||
            expectedTitleEn ||
            expectedYear
          ) {
            const metaRaw = await fs
              .readFile(path.join(dir, POSTER_META_FILE), "utf8")
              .catch(() => null);
            // 旧版本保存的海报没有 sidecar：不要因此隐藏它。只有在 sidecar 存在
            // 且身份明确冲突时才跳过，避免把有效海报误判为无效而 404。
            if (metaRaw) {
              const meta = JSON.parse(metaRaw) as {
                imdbId?: string | null;
                title?: string | null;
                titleEn?: string | null;
                year?: number | string | null;
              };
              if (
                !posterIdentityMatches(meta, {
                  imdbId: expectedImdbId,
                  title: expectedTitle,
                  titleEn: expectedTitleEn,
                  year: expectedYear,
                })
              )
                continue;
            }
          }
          res.setHeader(
            "Content-Type",
            name.toLowerCase().endsWith(".png") ? "image/png" : "image/jpeg",
          );
          res.setHeader("Cache-Control", "no-store");
          return fsSync.createReadStream(file).pipe(res);
        }
      } catch {
        /* try next candidate */
      }
    }
  }
  return res.status(404).json({ error: "目录中没有海报" });
});

// POST /media/poster — 把找到的真实海报保存到源目录（poster.jpg + folder.jpg）。
router.post("/media/poster", async (req, res) => {
  const rawPath =
    typeof req.body?.path === "string" ? req.body.path.trim() : "";
  const url = typeof req.body?.url === "string" ? req.body.url.trim() : "";
  if (!rawPath || !url || !/^https?:\/\//i.test(url)) {
    return res.status(400).json({ error: "path 与 url 不能为空" });
  }
  const config = await getConfig();
  const sourcePath = resolveRuntimePath(rawPath, config);
  const dir = posterDirectoriesForSource(sourcePath)[0];
  if (!dir) return res.status(404).json({ error: "无法确定海报保存目录" });
  const posterPath = await ensureLocalPoster({
    title: typeof req.body?.title === "string" ? req.body.title : null,
    titleEn: typeof req.body?.titleEn === "string" ? req.body.titleEn : null,
    imdbId: typeof req.body?.imdbId === "string" ? req.body.imdbId : null,
    posterUrl: url,
    posterMirrorUrl: config.posterMirrorUrl,
    posterProxyUrl: config.posterProxyUrl,
    year: typeof req.body?.year === "number" ? req.body.year : null,
    targetDirectory: dir,
  });
  if (!posterPath) return res.status(500).json({ error: "海报保存失败" });
  return res.json({ posterPath });
});

// 按路径的原始文件流（Range 支持）：浏览器可直接播放的容器（mp4/webm/mov 等）用
// 它替代转码流，时长/进度/seek 原生准确、零转码不卡顿。
router.get("/media/preview", async (req, res) => {
  const rawPath =
    typeof req.query.path === "string" ? req.query.path.trim() : "";
  const filePath = await resolveMediaPreviewFilePath(rawPath);
  if (!filePath) return res.status(404).json({ error: "没有可预览的视频文件" });
  try {
    const stat = await fs.stat(filePath);
    const range = req.headers.range;
    const extension = path.extname(filePath).toLowerCase();
    const contentType =
      extension === ".webm"
        ? "video/webm"
        : extension === ".mkv"
          ? "video/x-matroska"
          : extension === ".ts" || extension === ".m2ts"
            ? "video/mp2t"
            : extension === ".mov"
              ? "video/quicktime"
              : "video/mp4";
    if (!range) {
      res.setHeader("Content-Length", stat.size);
      res.setHeader("Content-Type", contentType);
      return fsSync.createReadStream(filePath).pipe(res);
    }
    const match = range.match(/bytes=(\d*)-(\d*)/);
    if (!match) return res.status(416).end();
    const start = match[1] ? Number(match[1]) : 0;
    const end = match[2]
      ? Math.min(Number(match[2]), stat.size - 1)
      : Math.min(start + 1024 * 1024 - 1, stat.size - 1);
    if (start >= stat.size || end < start) return res.status(416).end();
    res.status(206).set({
      "Content-Range": `bytes ${start}-${end}/${stat.size}`,
      "Accept-Ranges": "bytes",
      "Content-Length": String(end - start + 1),
      "Content-Type": contentType,
    });
    return fsSync.createReadStream(filePath, { start, end }).pipe(res);
  } catch {
    return res.status(404).json({ error: "视频文件不存在或无法读取" });
  }
});

// 按路径的预览元信息（时长），供播放器校准进度条/时长显示。
router.get("/media/preview/meta", async (req, res) => {
  const rawPath =
    typeof req.query.path === "string" ? req.query.path.trim() : "";
  const filePath = await resolveMediaPreviewFilePath(rawPath);
  if (!filePath) return res.status(404).json({ error: "没有可预览的视频文件" });
  const metadata = await previewService.probeMetadata(filePath);
  return res.json(metadata);
});
export const mediaPreviewRouter = router;
