import { describe, expect, it } from "vitest";
import {
  assColorToHex,
  defaultBilingualDraft,
  hexToAssColor,
} from "./scan-bilingual-model";

describe("scan bilingual style model", () => {
  it("converts ASS BGR colors to web hex", () => {
    expect(assColorToHex("&H00404040")).toBe("#404040");
    expect(assColorToHex("&H00FF0000")).toBe("#0000FF");
  });

  it("falls back to the default outline color for invalid input", () => {
    expect(assColorToHex(null)).toBe("#404040");
    expect(assColorToHex("nonsense")).toBe("#404040");
  });

  it("round-trips a hex color through the ASS representation", () => {
    expect(hexToAssColor("#404040")).toBe("&H00404040");
    expect(hexToAssColor(assColorToHex("&H00123456"))).toBe("&H00123456");
  });

  it("provides a default draft", () => {
    expect(defaultBilingualDraft()).toMatchObject({
      layout: "zh-top",
      outlineColor: "#404040",
    });
  });
});
