import { describe, expect, it } from "vitest";
import {
  createMediaPipelineManifest,
  type MediaPipelineInput,
} from "./media-pipeline-contract";

function input(
  overrides: Partial<MediaPipelineInput> = {},
): MediaPipelineInput {
  return {
    source: {
      kind: "dvd",
      path: "D:\\DVD",
      fingerprint: "dvd-fingerprint-v1",
      physicalBytes: 7_000_000_000,
    },
    title: {
      id: "handbrake:1",
      titleNumber: 1,
      durationSeconds: 5_400,
      streams: [
        { id: "video:0", index: 0, type: "video", codec: "mpeg2video" },
        {
          id: "audio:1",
          index: 1,
          type: "audio",
          codec: "ac3",
          language: "en",
        },
        {
          id: "subtitle:2",
          index: 2,
          type: "subtitle",
          codec: "dvd_subtitle",
          language: "en",
        },
      ],
      chapters: [
        { id: 1, startSeconds: 0, endSeconds: 2_700, title: "Part 1" },
        { id: 2, startSeconds: 2_700, endSeconds: 5_400, title: "Part 2" },
      ],
    },
    selection: {
      streamIds: ["video:0", "audio:1", "subtitle:2"],
      chapterIds: [1, 2],
    },
    output: {
      mode: "remux",
      directory: "D:\\Output",
      fileName: "Movie.mkv",
    },
    ...overrides,
  };
}

describe("media pipeline contract", () => {
  it("keeps physical source capacity separate from the output size estimate", () => {
    const manifest = createMediaPipelineManifest(input());

    expect(manifest.source.physicalBytes).toBe(7_000_000_000);
    expect(manifest.output.estimatedBytes).toBeNull();
    expect(manifest.source.physicalBytes).not.toBe(
      manifest.output.estimatedBytes,
    );
  });

  it("freezes a complete video/audio/subtitle/chapter selection", () => {
    const manifest = createMediaPipelineManifest(input());

    expect(manifest.selection.videoStreamIds).toEqual(["video:0"]);
    expect(manifest.selection.audioStreamIds).toEqual(["audio:1"]);
    expect(manifest.selection.subtitleStreamIds).toEqual(["subtitle:2"]);
    expect(manifest.selection.chapterIds).toEqual([1, 2]);
    expect(Object.isFrozen(manifest)).toBe(true);
    expect(Object.isFrozen(manifest.selection)).toBe(true);
  });

  it("rejects a selection that has no video stream", () => {
    expect(() =>
      createMediaPipelineManifest(
        input({
          selection: { streamIds: ["audio:1"], chapterIds: [1, 2] },
        }),
      ),
    ).toThrow("至少选择一个视频流");
  });

  it("rejects stream and chapter references that are not in the verified title", () => {
    expect(() =>
      createMediaPipelineManifest(
        input({
          selection: { streamIds: ["video:0", "audio:99"], chapterIds: [1, 2] },
        }),
      ),
    ).toThrow("不存在的流轨");

    expect(() =>
      createMediaPipelineManifest(
        input({
          selection: { streamIds: ["video:0"], chapterIds: [3] },
        }),
      ),
    ).toThrow("不存在的章节");
  });
});
