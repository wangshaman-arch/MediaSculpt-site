import { describe, expect, it } from "vitest";
import { readProjectFile } from "./windows-contract-helpers";

describe("V0.840 preview package contract", () => {
  it("requires proprietary release documents in the source package", () => {
    const packageScript = readProjectFile("windows-setup/package-base.ps1");
    const tauriConfig = readProjectFile(
      "desktop-tauri/src-tauri/tauri.conf.json",
    );

    expect(packageScript).toContain(
      '"LICENSE", "EULA.md", "THIRD-PARTY-NOTICES.md"',
    );
    expect(tauriConfig).toContain('"licenseFile": "../../EULA.md"');
    expect(tauriConfig).toContain(
      '"../../THIRD-PARTY-NOTICES.md": "THIRD-PARTY-NOTICES.md"',
    );
  });

  it("requires the base installer to contain the core media toolchain", () => {
    const sidecarScript = readProjectFile("scripts/prepare-tauri-sidecar.ps1");

    expect(sidecarScript).toContain(
      "Base bundle requires both FFmpeg and FFprobe",
    );
    expect(sidecarScript).toContain("Base bundle requires HandBrakeCLI.exe");
    expect(sidecarScript).toContain(
      'Join-Path $env:LOCALAPPDATA "VX-Agent\\Tools"',
    );
    expect(sidecarScript).toContain(
      "OCR, Whisper and translation tools install on demand",
    );
  });

  it("passes Tauri build arguments without an extra pnpm separator", () => {
    const buildScript = readProjectFile("scripts/build-tauri-base.ps1");

    expect(buildScript).toContain("run tauri @tauriArguments");
    expect(buildScript).not.toContain("run tauri -- @tauriArguments");
    expect(buildScript).toContain("mediasculpt-tauri-skip-build-$PID.json");
    expect(buildScript).toContain(
      "Remove-Item -LiteralPath $skipBuildConfigPath",
    );
    expect(buildScript).toContain(
      "SkipFrontendBuild requires a staged API sidecar",
    );
    expect(buildScript).toContain(
      "SkipFrontendBuild requires a staged frontend",
    );
  });

  it("does not add a removed disc-tool payload or installer entry", () => {
    const packageScript = readProjectFile("windows-setup/package-base.ps1");
    const tauriConfig = readProjectFile(
      "desktop-tauri/src-tauri/tauri.conf.json",
    );

    expect(packageScript).not.toMatch(/MakeMKV|makemkv/i);
    expect(tauriConfig).not.toMatch(/MakeMKV|makemkv/i);
  });

  it("keeps UNC paths in native Windows form for DVD verification", () => {
    const verifier = readProjectFile("scripts/verify-dvd-remux.ps1");

    expect(verifier).toContain(".ProviderPath");
    expect(verifier).not.toContain("(Resolve-Path -LiteralPath $Source).Path");
  });
});
