// Shared process-local state for disc analysis hand-offs between the
// /disc/analyze route and POST /jobs. Extracted from routes/jobs.ts so the
// route entry no longer has to act as the import hub for this state.
import { DiscAnalysisCache, type DiscAnalysisResult } from "./disc-analysis";
import { DiscAnalysisRegistry } from "./task-snapshot";
import { verifyDvdTitle } from "./dvd-remux";

export const discAnalysisCache = new DiscAnalysisCache<DiscAnalysisResult>();
export const discAnalysisRegistry = new DiscAnalysisRegistry();
export type DvdVerificationResult = Awaited<ReturnType<typeof verifyDvdTitle>>;
export const dvdTitleVerificationInFlight = new Map<
  string,
  Promise<DvdVerificationResult>
>();
export const dvdTitleVerificationCache = new Map<
  string,
  { verification: DvdVerificationResult; cachedAt: number }
>();
export const DVD_VERIFICATION_CACHE_TTL_MS = 10 * 60_000;

// Kept as a narrow internal seam for the /disc/analyze → POST /jobs hand-off.
// It does not scan, reorder, or infer titles; callers can only register a completed analysis.
export function registerDiscAnalysisForTaskCreation(
  analysis: DiscAnalysisResult,
): void {
  discAnalysisRegistry.remember(analysis);
}
