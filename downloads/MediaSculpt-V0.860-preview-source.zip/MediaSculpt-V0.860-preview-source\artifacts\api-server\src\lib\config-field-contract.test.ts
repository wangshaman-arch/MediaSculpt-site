import { describe, expect, it } from "vitest";
import { readProjectFile } from "./windows-contract-helpers";

/**
 * Settings fields must survive the round trip to the database.
 *
 * `PUT /api/config` applies an explicit `allowedFields` whitelist, and a field
 * that is missing from it is dropped silently: the toggle renders, the form
 * holds the new value, and the setting has no effect whatsoever. That is exactly
 * what happened when `aiMetadataEnrichment` was added — the switch existed but
 * the API ignored it.
 *
 * This contract ties the form schema to the whitelist so the next field added
 * cannot repeat the mistake.
 */
function formSchemaFields(): string[] {
  const source = readProjectFile(
    "artifacts/video-agent/src/pages/settings-model.ts",
  );
  return [...source.matchAll(/^\s{2}([a-zA-Z][a-zA-Z0-9]*):\s*z\./gm)]
    .map((match) => match[1])
    .sort();
}

function allowedConfigFields(): string[] {
  const source = readProjectFile("artifacts/api-server/src/routes/admin.ts");
  const block = /const allowedFields = \[([\s\S]*?)\]\s*as const;/.exec(source);
  if (!block) return [];
  return [...block[1].matchAll(/"([a-zA-Z][a-zA-Z0-9]*)"/g)]
    .map((match) => match[1])
    .sort();
}

describe("config field contract", () => {
  it("parses both field lists", () => {
    expect(formSchemaFields().length).toBeGreaterThan(30);
    expect(allowedConfigFields().length).toBeGreaterThan(30);
  });

  it("accepts every settings field the form can submit", () => {
    const allowed = new Set(allowedConfigFields());
    const rejected = formSchemaFields().filter((field) => !allowed.has(field));
    expect(rejected).toEqual([]);
  });

  // The specific field that exposed the gap; keep it named so a regression is
  // obvious rather than merely implied by the list comparison.
  it("keeps the AI enrichment toggle writable", () => {
    expect(allowedConfigFields()).toContain("aiMetadataEnrichment");
    expect(formSchemaFields()).toContain("aiMetadataEnrichment");
  });
});
