import fsSync from "fs";
import os from "os";
import path from "path";
import fs from "fs/promises";
import { db, jobsTable, configTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import {
  parseBlurayChapters,
  parseBlurayMpls,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoTsDir,
  type DvdTitle,
} from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import { mapExternalToolProgress } from "../lib/job-workflow";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import {
  buildFfconcatFileContent,
  buildFfconcatChapterContent,
  buildFfconcatTimedContent,
} from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import { buildRemuxOutputName } from "../lib/output-naming";
import { dvdOutputBaseName } from "../lib/dvd-source-identity";
import { resolveToolPath } from "../lib/tool-runtime";
import { ffmpegPath } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput } from "../infrastructure/process-runner";
import { loadTaskSnapshot } from "../lib/task-snapshot";
import { finalizeRemuxStage } from "./job-remux-finalization";
import { tryRemuxBluRayM2ts } from "./job-remux-bluray-m2ts";
import { resolveBlurayPlaylistInput } from "./job-bluray-playlist-input";
import { probeAndTrimBluraySegments } from "./job-bluray-segment-context";
import {
  chooseBlurayHandBrakeChapterTitle,
  clampBlurayChapters,
  readPersistedBlurayChapters,
} from "./job-bluray-chapter-context";
import { prepareDvdRemuxInput } from "./job-dvd-remux-input";
import { prepareMplsRemuxInput } from "./job-mpls-remux-input";
import {
  parseSelectedChapterIds,
  readPersistedSelectedChapters,
  selectChaptersById,
} from "./job-remux-chapter-selection";
import { isPlayableRemuxProbe } from "./job-remux-output-health";
import type { ResolvedJob } from "./job-media-input-context";
import type { PipelineNames } from "./jobs-pipeline";
import type { UnifiedDiscTitle } from "../lib/disc-analysis";
import { addLog } from "../lib/job-logging";
import { discAnalysisRegistry } from "../lib/disc-analysis-registry";
import {
  buildDvdTypeMaps,
  dvdConcatInputArgs,
  dvdInputArg,
  dvdTitleNavigationInputArgs,
  dvdVideoInputPath,
  ffmpegSupportsDvdTitleNavigation,
  isVobConcatList,
  writeDvdConcatListFile,
} from "./jobs-dvd";
import { mountBlurayIso, unmountBlurayIso } from "./jobs-iso";
import { cancelledJobs, trackJobOutputFile } from "./jobs-tracking";
import { probeDvdAudioCodecs } from "./jobs-dvd-audio";
import { probeMediaStreams, probeStreams } from "./jobs-probe";
import {
  runFfmpegCapture,
  snapshotTitleIndex,
  verifyOutputEndPlayable,
} from "./jobs-ffmpeg-run";
import { buildLosslessRemuxArgs } from "./job-encoding";

export type RemuxStageInput = {
  jobId: number;
  job: ResolvedJob;
  config: typeof configTable.$inferSelect;
  mediaInputPath: string;
  outputDir: string;
  baseName: string;
  pipelineNames: PipelineNames;
  pipelineHasRemux: boolean;
  pipelineContinuesAfterRemux: boolean;
  subtitlePath: string | null;
  translatedSubtitlePath: string | null;
  graphicSubtitlePaths: string[];
  dvdTitle: DvdTitle | null;
  selectedTitleSizeBytes: number | null;
  selectedAnalysisTitle: UnifiedDiscTitle | undefined;
};

export async function runRemuxStage(
  input: RemuxStageInput,
): Promise<{ pipelineRemuxOutputPath: string | null; shouldReturn: boolean }> {
  const {
    jobId,
    job,
    config,
    mediaInputPath,
    outputDir,
    baseName,
    pipelineNames,
    pipelineHasRemux,
    pipelineContinuesAfterRemux,
    subtitlePath,
    translatedSubtitlePath,
    graphicSubtitlePaths,
    dvdTitle,
    selectedTitleSizeBytes,
    selectedAnalysisTitle,
  } = input;

  let pipelineRemuxOutputPath: string | null = null;
  if (job.processingMode === "remux" || pipelineHasRemux) {
    const remuxFfmpeg =
      (await resolveToolPath("ffmpeg").catch(() => null)) ?? "ffmpeg";
    let sourcePath = mediaInputPath;
    const isIfoInput = /\.ifo$/i.test(sourcePath);
    const isMplsInput = /\.mpls$/i.test(sourcePath);
    const discLabel =
      job.mediaType === "bluray"
        ? "蓝光"
        : job.mediaType === "dvd"
          ? "DVD"
          : "ISO";
    await addLog(
      jobId,
      "info",
      `无损封装模式 — ${discLabel} 源文件: ${path.basename(sourcePath)}${isIfoInput ? " (DVD IFO 完整标题)" : ""}`,
    );
    let isoRemuxDrive: string | null = null;
    if (job.mediaType === "iso") {
      const mounted = await mountBlurayIso(sourcePath);
      if (!mounted)
        throw new Error(
          "无法挂载 ISO 镜像，请检查文件是否被占用或系统挂载支持",
        );
      isoRemuxDrive = mounted;
      const mountedVideoTs = await resolveDvdVideoTsDir(mounted);
      if (mountedVideoTs) {
        // DVD-content ISO: route into the DVD dvdvideo navigation path below
        // (libdvdread needs the mounted drive, not the raw ISO file).
        await addLog(
          jobId,
          "info",
          `ISO 内容为 DVD，已挂载到 ${mounted}，按 DVD 标题导航封装`,
        );
        job.mediaType = "dvd";
        sourcePath = mountedVideoTs;
      }
    }

    // Fix output name for disc folders: if filePath is a VIDEO_TS/BDMV subfolder,
    // use the parent directory name so output is "MovieName.mkv" not "VIDEO_TS.mkv".
    const taskSnapshot = loadTaskSnapshot(job);
    const remuxBaseName =
      job.mediaType === "dvd"
        ? dvdOutputBaseName({ sourcePath: job.filePath, mediaType: "dvd" })
        : /^(VIDEO_TS|BDMV)$/i.test(baseName)
          ? path.basename(path.dirname(job.filePath))
          : baseName;
    const titleIndex = snapshotTitleIndex(taskSnapshot);
    const remuxTitleSuffix =
      job.mediaType === "dvd"
        ? ""
        : titleIndex >= 0
          ? `.Title${String(titleIndex + 1).padStart(2, "0")}`
          : "";
    const remuxFileName =
      taskSnapshot?.outputMode === "remux"
        ? taskSnapshot.output.fileName
        : (pipelineNames.remux ??
          buildRemuxOutputName(
            `${remuxBaseName}${remuxTitleSuffix}`,
            job.mediaType,
            config.outputFormat,
            config.outputNameTemplate,
          ));
    const remuxOutputFile = path.join(outputDir, remuxFileName);
    trackJobOutputFile(jobId, remuxOutputFile);
    // Stream indexes the user selected (from the immutable snapshot); null
    // means "no explicit selection", in which case all tracks are kept.
    const remuxSelectedStreams = (() => {
      if (!taskSnapshot) return null;
      const ids = [
        ...taskSnapshot.streamSelection.videoTrackIds,
        ...taskSnapshot.streamSelection.audioTrackIds,
        ...taskSnapshot.streamSelection.subtitleTrackIds,
      ];
      const indexes = ids
        .map((id) => Number(String(id).replace(/^stream:/, "")))
        .filter((index) => Number.isInteger(index) && index >= 0);
      return indexes.length > 0 ? indexes : null;
    })();

    const isDiscRemux =
      job.mediaType === "bluray" || job.mediaType === "iso" || isMplsInput;
    if (isDiscRemux) {
      const discSourcePath = job.filePath;
      // Blu-ray titles from the m2ts fallback (playlist-less discs) are remuxed
      // directly from their BDMV/STREAM file without playlist concat.
      const m2tsRemux = await tryRemuxBluRayM2ts({
        jobId,
        discSourcePath,
        selectedTitleId: taskSnapshot?.selectedTitleId,
        remuxSelectedStreams,
        remuxOutputFile,
        expectedDurationSeconds: job.durationSeconds,
        pipelineContinuesAfterRemux,
        subtitlePath,
        translatedSubtitlePath,
        graphicSubtitlePaths,
        log: (level, message) => addLog(jobId, level, message),
      });
      pipelineRemuxOutputPath = m2tsRemux.pipelineRemuxOutputPath;
      if (m2tsRemux.handled && !pipelineContinuesAfterRemux)
        return { pipelineRemuxOutputPath, shouldReturn: true };
      await addLog(
        jobId,
        "info",
        `FFmpeg 播放列表 Remux：源 ${discSourcePath}`,
      );
      const blurayPlaylistInput = await resolveBlurayPlaylistInput({
        mediaType: job.mediaType,
        sourcePath,
        discSourcePath,
        taskSnapshot,
        expectedTitleSeconds:
          job.durationSeconds && job.durationSeconds > 0
            ? job.durationSeconds
            : null,
        log: (level, message) => addLog(jobId, level, message),
      });
      const { discRoot, mplsPath } = blurayPlaylistInput;
      const parsedSegments = await parseBlurayMpls(mplsPath, discRoot);
      if (parsedSegments.length === 0)
        throw new Error("播放列表未解析到有效片段");
      const segmentContext = await probeAndTrimBluraySegments({
        segments: parsedSegments,
        probeDuration: async (streamPath) => {
          const probe = await probeStreams(streamPath);
          return probe.duration ?? null;
        },
        log: (message) => addLog(jobId, "info", message),
      });
      const { segments, playlistDuration, keptDurationSeconds } =
        segmentContext;

      // Resolve chapters BEFORE the single ffmpeg pass so the chapter
      // metadata is written by the same invocation that creates the output
      // file — no intermediate "no-chapter" file, no double output.
      let chapters: Array<{
        id: number;
        startSeconds: number;
        endSeconds: number;
        title: string | null;
      }> = readPersistedBlurayChapters(job.selectionPlan);
      if (chapters.length === 0) {
        try {
          const chapterSnapshot = loadTaskSnapshot(job);
          const chapterAnalysis = chapterSnapshot?.analysisId
            ? discAnalysisRegistry.find(chapterSnapshot.analysisId)
            : undefined;
          const chapterTitle = chapterAnalysis?.titles.find(
            (candidate) =>
              candidate.titleId === chapterSnapshot?.selectedTitleId,
          );
          if (chapterTitle?.chapters && chapterTitle.chapters.length > 0) {
            chapters = chapterTitle.chapters.map((chapter) => ({
              id: chapter.id,
              startSeconds: chapter.startSeconds,
              endSeconds: chapter.endSeconds,
              title: chapter.title ?? null,
            }));
          }
        } catch {
          chapters = [];
        }
      }
      if (chapters.length === 0) {
        // Legacy jobs created before chapter persistence have no saved
        // chapter times. Recover them with a quick HandBrake scan so a
        // re-run still gets the real layout instead of broken marks.
        try {
          const hbExecutable = await resolveToolPath("handbrake");
          if (hbExecutable) {
            const hbScan = await scanHandBrakeTitles(discRoot, hbExecutable);
            let chapterSnapshotForScan: { selectedTitleId?: string } | null =
              null;
            try {
              chapterSnapshotForScan = loadTaskSnapshot(job);
            } catch {
              chapterSnapshotForScan = null;
            }
            const match = chooseBlurayHandBrakeChapterTitle(
              hbScan,
              chapterSnapshotForScan?.selectedTitleId ?? null,
              job.durationSeconds,
            );
            if (match && match.chapters.length > 0) {
              chapters = match.chapters.map((chapter) => ({
                id: chapter.id,
                startSeconds: chapter.startSeconds,
                endSeconds: chapter.endSeconds,
                title: chapter.title ?? null,
              }));
            }
          }
        } catch {
          chapters = [];
        }
      }
      if (chapters.length === 0)
        chapters = await parseBlurayChapters(mplsPath, discRoot);
      const effectiveDuration =
        keptDurationSeconds > 0
          ? keptDurationSeconds
          : (playlistDuration ??
            job.durationSeconds ??
            Number.MAX_SAFE_INTEGER);
      const validChapters = clampBlurayChapters(chapters, effectiveDuration);
      let metaPath: string | null = null;
      if (validChapters.length > 1) {
        metaPath = path.join(
          os.tmpdir(),
          `vx-bd-${Date.now()}-${Math.random().toString(36).slice(2)}.ffmeta`,
        );
        trackJobOutputFile(jobId, metaPath, { temp: true });
        const metaLines = [";FFMETADATA1", "TIMEBASE=1/90000"];
        for (const chapter of validChapters) {
          metaLines.push(`[CHAPTER]`);
          metaLines.push(`TIMEBASE=1/90000`);
          metaLines.push(`START=${Math.round(chapter.startSeconds * 90000)}`);
          metaLines.push(`END=${Math.round(chapter.endSeconds * 90000)}`);
          metaLines.push("title=Chapter " + (chapter.id + 1));
        }
        await fs.writeFile(metaPath, metaLines.join("\r\n"), "utf8");
      } else if (chapters.length > 1) {
        await addLog(
          jobId,
          "warn",
          `章节时间信息不完整（${chapters.length} 个章节标记无效），已跳过章节封装；无损封装结果不受影响`,
        );
      }

      await db
        .update(jobsTable)
        .set({ progress: 10 })
        .where(eq(jobsTable.id, jobId));
      const remuxBuild = await buildLosslessRemuxArgs(
        segments[0].streamPath,
        undefined,
        remuxSelectedStreams,
      );
      if (remuxBuild.transcodedPcmBluray) {
        await addLog(
          jobId,
          "info",
          "检测到蓝光 LPCM（pcm_bluray）音轨，已无损转换为 MKV 兼容的 PCM（pcm_s24le）",
        );
      }
      const concatList = path.join(
        os.tmpdir(),
        `vx-bd-${Date.now()}-${Math.random().toString(36).slice(2)}.ffconcat`,
      );
      trackJobOutputFile(jobId, concatList, { temp: true });
      await fs.writeFile(
        concatList,
        buildFfconcatFileContent(segments.map((segment) => segment.streamPath)),
        "utf8",
      );
      const legacyBdArgs = [
        "-f",
        "concat",
        "-safe",
        "0",
        "-i",
        ffmpegPath(concatList),
        ...(metaPath ? ["-i", metaPath, "-map_chapters", "1"] : []),
        ...remuxBuild.args,
        "-fflags",
        "+genpts",
        "-y",
        remuxOutputFile,
      ];
      // The unified planner must reproduce the legacy command byte for byte;
      // otherwise fall back to it so the output cannot silently change.
      let plannedBdArgs: string[] | null = null;
      try {
        const bdAnalysisTitle =
          discAnalysisRegistry
            .find(taskSnapshot?.analysisId ?? "")
            ?.titles.find(
              (candidate) =>
                candidate.titleId === taskSnapshot?.selectedTitleId,
            ) ?? null;
        const bdManifest = buildMediaPipelineManifestFromSnapshot({
          snapshot: taskSnapshot as NonNullable<typeof taskSnapshot>,
          title: bdAnalysisTitle,
          selectionPlan: job.selectionPlan,
          sourcePath: segments[0].streamPath,
        });
        plannedBdArgs = buildRemuxCommandPlan({
          manifest: bdManifest,
          executable: remuxFfmpeg,
          inputMode: "concat",
          concatListPath: concatList,
          chapterMetadataPath: metaPath ?? undefined,
        }).args as string[];
      } catch (error) {
        await addLog(
          jobId,
          "warn",
          `蓝光 Remux planner 构建失败，回退旧命令：${error instanceof Error ? error.message : String(error)}`,
        );
      }
      const bdPlannerMatches =
        plannedBdArgs !== null &&
        JSON.stringify(plannedBdArgs) === JSON.stringify(legacyBdArgs);
      if (!bdPlannerMatches) {
        await addLog(
          jobId,
          "warn",
          "蓝光 Remux planner 与旧命令不一致，已回退旧命令（请检查）",
        );
      }
      try {
        await runFfmpegCapture(
          jobId,
          bdPlannerMatches ? (plannedBdArgs as string[]) : legacyBdArgs,
          keptDurationSeconds > 0
            ? keptDurationSeconds
            : (playlistDuration ?? job.durationSeconds),
        );
      } finally {
        await fs.unlink(concatList).catch(() => {});
        if (metaPath) await fs.unlink(metaPath).catch(() => {});
      }
      await db
        .update(jobsTable)
        .set({ progress: 60 })
        .where(eq(jobsTable.id, jobId));
      if (cancelledJobs.has(jobId)) {
        await fs.rm(remuxOutputFile, { force: true }).catch(() => {});
        throw new Error("任务已取消");
      }

      let fileSizeAfter: number;
      let outputDuration: number | null;
      try {
        const validation = await validateRemuxOutput(
          remuxOutputFile,
          effectiveDuration,
          probeStreams,
          {
            expectedSizeBytes: null,
            minimumSizeRatio: 0.6,
          },
        );
        fileSizeAfter = validation.fileSize;
        outputDuration = validation.duration;
        if (validation.drift !== null && validation.drift > 0.05) {
          await addLog(
            jobId,
            "warn",
            `Remux 输出时长与播放列表差异 ${(validation.drift * 100).toFixed(1)}%`,
          );
        }
      } catch (probeError) {
        await addLog(
          jobId,
          "error",
          `FFmpeg Remux 输出校验失败：${String(probeError)}`,
        );
        throw probeError;
      }
      const endPlayable = await verifyOutputEndPlayable(
        jobId,
        remuxOutputFile,
        outputDuration ?? effectiveDuration,
      );
      if (!endPlayable.ok) {
        throw new Error(`输出后段解码失败，文件可能损坏：${endPlayable.error}`);
      }
      pipelineRemuxOutputPath = (
        await finalizeRemuxStage({
          jobId,
          remuxOutputFile,
          fileSizeAfter,
          outputDuration,
          pipelineContinuesAfterRemux,
          subtitlePath,
          translatedSubtitlePath,
          log: (level, message) => addLog(jobId, level, message),
        })
      ).pipelineRemuxOutputPath;
      if (!pipelineContinuesAfterRemux)
        return { pipelineRemuxOutputPath, shouldReturn: true };
    }

    // DVD IFO is not a plain video file. Prefer ffmpeg's dvdvideo demuxer so
    // title navigation, IFO timing, and chapter/cell boundaries are read from
    // the disc structure. Raw VOB concat is only a sparse-extract fallback.
    let inputPath = sourcePath;
    let concatListFile: string | null = null;
    let chapterMetadataFile: string | null = null;
    let dvdNavigationTitle: DvdTitle | null = null;
    let remuxExpectedSizeBytes: number | null = dvdTitle?.sizeBytes ?? null;
    const dvdRemuxInput = await prepareDvdRemuxInput({
      jobId,
      sourcePath,
      isIfoInput,
      isMplsInput,
      mediaType: job.mediaType,
      taskSnapshot,
      dvdTitle,
      selectedTitleSizeBytes,
      selectedAnalysisEstimatedSize:
        selectedAnalysisTitle?.estimatedSize ?? null,
      resolveDvdTitleForSource,
      resolveDvdTitleForIfo,
      writeDvdConcatListFile,
      trackTempFile: (filePath) =>
        trackJobOutputFile(jobId, filePath, { temp: true }),
      log: (level, message) => addLog(jobId, level, message),
    });
    concatListFile = dvdRemuxInput.concatListFile;
    dvdNavigationTitle = dvdRemuxInput.dvdNavigationTitle;
    remuxExpectedSizeBytes = dvdRemuxInput.remuxExpectedSizeBytes;
    if (isMplsInput) {
      const mplsRemuxInput = await prepareMplsRemuxInput({
        jobId,
        sourcePath,
        discRoot: path.dirname(path.dirname(path.dirname(sourcePath))),
        trackTempFile: (filePath) =>
          trackJobOutputFile(jobId, filePath, { temp: true }),
        log: (level, message) => addLog(jobId, level, message),
      });
      remuxExpectedSizeBytes = mplsRemuxInput.remuxExpectedSizeBytes;
      concatListFile = mplsRemuxInput.concatListFile;
    }

    // Rebuild the chapter metadata from the user's selected chapter IDs.
    // This keeps stream-copy lossless while preventing unselected chapter
    // markers from leaking into the output container.
    if (job.selectedChapters) {
      try {
        const selected = parseSelectedChapterIds(job.selectedChapters);
        if (Array.isArray(selected) && selected.length > 0)
          remuxExpectedSizeBytes = null;
        let probed: {
          chapters?: Array<{
            id: number;
            startSeconds: number;
            endSeconds: number;
            title?: string | null;
          }>;
        } | null = null;
        try {
          probed = await probeMediaStreams(sourcePath, job.mediaType);
        } catch {
          probed = null;
        }
        let chapters = selectChaptersById(probed?.chapters ?? [], selected);
        if (chapters.length === 0) {
          // The source probe failed (e.g. CSS-protected DVD directory or a
          // disc root). Recover the selected title's chapters from the
          // persisted selection plan or the analysis so the remux still
          // gets a proper chapter layout.
          chapters = readPersistedSelectedChapters(job.selectionPlan, selected);
        }
        if (chapters.length === 0) {
          try {
            const snap = loadTaskSnapshot(job);
            const title = snap?.analysisId
              ? discAnalysisRegistry
                  .find(snap.analysisId)
                  ?.titles.find(
                    (candidate) => candidate.titleId === snap?.selectedTitleId,
                  )
              : undefined;
            if (title?.chapters?.length) {
              chapters = selectChaptersById(title.chapters, selected).map(
                (chapter) => ({
                  id: chapter.id,
                  startSeconds: chapter.startSeconds,
                  endSeconds: chapter.endSeconds,
                  title: chapter.title ?? null,
                }),
              );
            }
          } catch {
            chapters = [];
          }
        }
        if (chapters.length > 0) {
          chapterMetadataFile = path.join(
            os.tmpdir(),
            `vx-chapters-${jobId}-${Date.now()}.ffmeta`,
          );
          trackJobOutputFile(jobId, chapterMetadataFile, { temp: true });
          const metadata = buildSelectedChapterMetadata(chapters, selected);
          if (!metadata) throw new Error("未找到选定章节");
          await fs.writeFile(chapterMetadataFile, metadata, "utf8");
          await addLog(
            jobId,
            "info",
            `已生成 ${chapters.length} 个选定章节的元数据`,
          );
          if (isMplsInput && concatListFile) {
            const playlistSegments = await parseBlurayMpls(
              sourcePath,
              path.dirname(path.dirname(path.dirname(sourcePath))),
            );
            const selectedSegments = mapBlurayChaptersToSegments(
              playlistSegments,
              chapters,
            ).filter((segment) => fsSync.existsSync(segment.file));
            if (selectedSegments.length > 0) {
              await fs.writeFile(
                concatListFile,
                buildFfconcatTimedContent(selectedSegments),
                "utf8",
              );
              await addLog(
                jobId,
                "info",
                `蓝光章节已映射到 ${selectedSegments.length} 个 m2ts 时间片段`,
              );
            }
          }
          if (
            job.mediaType !== "dvd" &&
            !isIfoInput &&
            !isMplsInput &&
            !concatListFile
          ) {
            concatListFile = path.join(
              os.tmpdir(),
              `vx-chapter-${jobId}-${Date.now()}.ffconcat`,
            );
            trackJobOutputFile(jobId, concatListFile, { temp: true });
            await fs.writeFile(
              concatListFile,
              buildFfconcatChapterContent(sourcePath, chapters),
              "utf8",
            );
            await addLog(
              jobId,
              "info",
              `普通视频将只封装 ${chapters.length} 个选定章节片段`,
            );
          }
        }
      } catch {
        await addLog(jobId, "warn", "章节选择解析失败，将保留原始章节元数据");
      }
    }

    let selectedChapterCount = 0;
    if (job.selectedChapters) {
      try {
        selectedChapterCount = parseSelectedChapterIds(
          job.selectedChapters,
        ).length;
      } catch {
        selectedChapterCount = 0;
      }
    }

    const appendRemuxSelectionArgs = async (
      ffmpegArgs: string[],
      usesConcatInput: boolean,
      vobProtocol = false,
    ) => {
      if (chapterMetadataFile) ffmpegArgs.push("-i", chapterMetadataFile);

      if (vobProtocol) {
        // concat-protocol input exposes dvd_nav data at stream 0, video at 1
        // and audio after it, so map by type/order instead of raw indexes.
        if (job.selectedStreams) {
          try {
            ffmpegArgs.push("-map", "0:v");
            // Map the audio tracks actually selected in the task snapshot
            // (the raw stream list also contains video/subtitle indexes).
            const audioIndexes = (
              taskSnapshot?.streamSelection.audioTrackIds ?? []
            )
              .map((id) => {
                const match = /^stream:(\d+)$/.exec(id);
                return match ? Number(match[1]) : null;
              })
              .filter((index): index is number => index !== null && index > 0)
              .sort((a, b) => a - b);
            for (const index of audioIndexes)
              ffmpegArgs.push("-map", `0:a:${index - 1}`);
            await addLog(
              jobId,
              "info",
              "DVD VOB 拼接：按类型映射视频与所选音轨",
            );
          } catch {
            ffmpegArgs.push("-map", "0:v", "-map", "0:a");
          }
        } else {
          ffmpegArgs.push("-map", "0:v", "-map", "0:a");
        }
      } else if (isIfoInput) {
        // DVD vobsub (dvd_subtitle) subtitles are bitmap-based and cannot be
        // reliably stream-copied into MKV without special handling — skip them.
        if (job.selectedStreams) {
          ffmpegArgs.push(...buildRemuxMapArgs(job.selectedStreams));
          await addLog(jobId, "info", "DVD 模式：按已选择的流轨封装");
        } else {
          ffmpegArgs.push("-map", "0:v?", "-map", "0:a?");
          await addLog(jobId, "info", "DVD 模式：封装视频和音频流（跳过字幕）");
        }
      } else if (dvdNavigationTitle && job.mediaType === "dvd") {
        // dvdvideo input: use type-based maps so re-probed duplicate stream
        // lists on some discs cannot corrupt the MKV container.
        const analysisTitle = taskSnapshot?.analysisId
          ? discAnalysisRegistry
              .find(taskSnapshot.analysisId)
              ?.titles.find(
                (candidate) =>
                  candidate.titleId === taskSnapshot?.selectedTitleId,
              )
          : undefined;
        const typedMaps = buildDvdTypeMaps(taskSnapshot, analysisTitle);
        if (typedMaps) {
          ffmpegArgs.push(...typedMaps);
          await addLog(
            jobId,
            "info",
            "DVD 模式：按类型映射所选流轨（避免 dvdvideo 流轨重复导致 MKV 损坏）",
          );
        } else {
          ffmpegArgs.push(...buildRemuxMapArgs(job.selectedStreams ?? null));
        }
      } else {
        const mapArgs = buildRemuxMapArgs(job.selectedStreams ?? null);
        ffmpegArgs.push(...mapArgs);
      }

      // Regenerate the container timeline from zero while stream-copying payloads.
      // Preserving raw input timestamps (-copyts) caused broken durations after
      // DVD/BD concat and selected-chapter remuxes on Windows.
      ffmpegArgs.push(
        ...buildRemuxCopyArgs({
          usesConcatInput,
          selectedChapters: job.selectedChapters,
        }),
      );
      // Matroska has no pcm_dvd codec tag; convert LPCM DVD audio losslessly
      // to little-endian PCM (same samples, MKV-safe). Without conversion the
      // mux header fails with "No wav codec tag found for codec pcm_dvd".
      if (dvdNavigationTitle && job.mediaType === "dvd") {
        const audioInputIndexes = (
          taskSnapshot?.streamSelection.audioTrackIds ?? []
        )
          .map((id) => {
            const match = /^stream:(\d+)$/.exec(id);
            return match ? Number(match[1]) : null;
          })
          .filter((index): index is number => index !== null && index >= 0)
          .sort((a, b) => a - b);
        if (audioInputIndexes.length > 0) {
          const ffprobe = await resolveToolPath("ffprobe").catch(() => null);
          if (ffprobe) {
            const codecs = await probeDvdAudioCodecs(
              ffprobe,
              dvdInputArg(dvdVideoInputPath(sourcePath)),
              dvdNavigationTitle.titleNumber,
              audioInputIndexes,
            );
            let audioOutIndex = 0;
            for (const codec of codecs) {
              if (codec.codecName?.toLowerCase() === "pcm_dvd") {
                ffmpegArgs.push(`-c:a:${audioOutIndex}`, "pcm_s16le");
                await addLog(
                  jobId,
                  "info",
                  `检测到 pcm_dvd 音轨 ${codec.inputIndex}：为兼容 MKV 将按无损 PCM 方式封装（不重新编码视频）`,
                );
              }
              audioOutIndex += 1;
            }
          }
        }
      }
      if (chapterMetadataFile)
        ffmpegArgs.push("-map_metadata", "1", "-map_chapters", "1");
      if (selectedChapterCount > 0) {
        if (/\.mpls$/i.test(sourcePath) || /\.ifo$/i.test(sourcePath)) {
          await addLog(
            jobId,
            "info",
            `当前光盘 Remux 已保存 ${selectedChapterCount} 个选定章节；蓝光/DVD 章节范围将随后续片段时间映射处理。`,
          );
        } else {
          await addLog(
            jobId,
            "info",
            `当前 Remux 将处理 ${selectedChapterCount} 个选定章节片段。`,
          );
        }
      }
      ffmpegArgs.push(ffmpegPath(remuxOutputFile));
    };

    const buildRemuxFfmpegArgs = async (
      mode: "dvd-navigation" | "concat" | "file",
      listFile?: string,
    ) => {
      const ffmpegArgs: string[] = ["-y"];
      if (mode === "dvd-navigation") {
        if (!dvdNavigationTitle)
          throw new Error(`DVD 标题未找到可导航输入：${sourcePath}`);
        ffmpegArgs.push(
          "-analyzeduration",
          "100M",
          "-probesize",
          "100M",
          ...dvdTitleNavigationInputArgs(dvdNavigationTitle),
        );
        await appendRemuxSelectionArgs(ffmpegArgs, false);
      } else if (mode === "concat") {
        if (!listFile)
          throw new Error(
            `DVD 标题未找到可封装的 VOB concat 输入：${sourcePath}`,
          );
        const vobProtocol = isVobConcatList(listFile);
        ffmpegArgs.push(
          "-fflags",
          "+genpts",
          "-analyzeduration",
          "100M",
          "-probesize",
          "100M",
          ...dvdConcatInputArgs(listFile),
        );
        await appendRemuxSelectionArgs(ffmpegArgs, true, vobProtocol);
      } else {
        if (isIfoInput)
          throw new Error(`DVD 标题未找到可封装的 IFO/VOB 输入：${sourcePath}`);
        ffmpegArgs.push("-i", ffmpegPath(inputPath));
        await appendRemuxSelectionArgs(ffmpegArgs, false);
      }
      return ffmpegArgs;
    };

    const runFfmpegRemux = async (ffmpegArgs: string[]) => {
      await new Promise<void>((resolve, reject) => {
        const ff = jobProcessController.spawnForJob(
          jobId,
          remuxFfmpeg,
          ffmpegArgs,
          config.processHighPriority ?? false,
        );
        const stderrOut = new BoundedOutput(256 * 1024);
        ff.stderr?.on("data", async (chunk) => {
          const text: string = chunk.toString();
          stderrOut.append(text);
          // Parse progress from "time=HH:MM:SS.xx" in ffmpeg output
          const timeMatch = text.match(/time=(\d+):(\d+):([0-9.]+)/);
          if (timeMatch && job.durationSeconds && job.durationSeconds > 0) {
            const secs =
              parseInt(timeMatch[1]) * 3600 +
              parseInt(timeMatch[2]) * 60 +
              parseFloat(timeMatch[3]);
            const pct = mapExternalToolProgress({
              toolPercent: Math.min(secs / job.durationSeconds, 1) * 100,
              start: 0,
              end: 95,
            });
            await db
              .update(jobsTable)
              .set({ progress: pct })
              .where(eq(jobsTable.id, jobId));
          }
        });
        ff.on("close", async (code) => {
          if (code === 0) {
            resolve();
          } else {
            // Log the last meaningful lines of stderr to help diagnose failures
            const errLines = stderrOut
              .toString()
              .split("\n")
              .map((l) => l.trim())
              .filter((l) => l.length > 0)
              .slice(-20)
              .join("\n");
            if (errLines)
              await addLog(jobId, "error", `ffmpeg stderr:\n${errLines}`);
            reject(
              new Error(
                errLines
                  ? `ffmpeg exit ${code}: ${errLines}`
                  : `ffmpeg exit ${code}`,
              ),
            );
          }
        });
        ff.on("error", (e) => reject(new Error(`ffmpeg 未找到：${e.message}`)));
      });
    };

    try {
      if (dvdNavigationTitle) {
        const ffmpegArgs = await buildRemuxFfmpegArgs("dvd-navigation");
        await addLog(jobId, "info", `ffmpeg 参数: ${ffmpegArgs.join(" ")}`);
        try {
          await runFfmpegRemux(ffmpegArgs);
          const navigationProbe = await probeStreams(remuxOutputFile).catch(
            () => null,
          );
          if (!isPlayableRemuxProbe(navigationProbe)) {
            await fs.rm(remuxOutputFile, { force: true }).catch(() => {});
            throw new Error("DVD 导航未产生有效视频输出，自动回退 VOB concat");
          }
        } catch (error) {
          if (!ffmpegSupportsDvdTitleNavigation(error)) {
            throw new Error(
              `本机 FFmpeg 不支持 DVD title 导航；请安装带 dvdvideo/libdvdread/libdvdnav 支持的 FFmpeg 后再执行 DVD Remux。原始错误：${error instanceof Error ? error.message : String(error)}`,
            );
          }
          await addLog(
            jobId,
            "warn",
            `DVD 导航模式失败，退回 VOB concat：${error instanceof Error ? error.message : String(error)}`,
          );
          const fallbackConcatListFile = await writeDvdConcatListFile(
            dvdNavigationTitle,
            `fallback-vob-${jobId}`,
          );
          try {
            const fallbackArgs = await buildRemuxFfmpegArgs(
              "concat",
              fallbackConcatListFile,
            );
            await addLog(
              jobId,
              "info",
              `ffmpeg 参数(退回 VOB concat): ${fallbackArgs.join(" ")}`,
            );
            await runFfmpegRemux(fallbackArgs);
          } finally {
            await fs.unlink(fallbackConcatListFile).catch(() => {});
          }
        }
      } else if (concatListFile) {
        const ffmpegArgs = await buildRemuxFfmpegArgs("concat", concatListFile);
        await addLog(jobId, "info", `ffmpeg 参数: ${ffmpegArgs.join(" ")}`);
        await runFfmpegRemux(ffmpegArgs);
      } else {
        const ffmpegArgs = await buildRemuxFfmpegArgs("file");
        await addLog(jobId, "info", `ffmpeg 参数: ${ffmpegArgs.join(" ")}`);
        await runFfmpegRemux(ffmpegArgs);
      }
    } finally {
      // Always clean up the temporary concat list file
      if (concatListFile) await fs.unlink(concatListFile).catch(() => {});
      if (chapterMetadataFile)
        await fs.unlink(chapterMetadataFile).catch(() => {});
      if (isoRemuxDrive) await unmountBlurayIso(mediaInputPath).catch(() => {});
    }

    await addLog(jobId, "info", "无损封装完成");
    if (
      job.mediaType === "dvd" &&
      taskSnapshot?.streamSelection.subtitleTrackIds.length
    ) {
      await addLog(
        jobId,
        "warn",
        "DVD 字幕（vobsub）为图形字幕，无法无损复制进 MKV，本次 Remux 已跳过字幕轨",
      );
    }

    let fileSizeAfter: number;
    let outputDuration: number | null;
    try {
      const validation = await validateRemuxOutput(
        remuxOutputFile,
        job.durationSeconds,
        probeStreams,
        {
          expectedSizeBytes: remuxExpectedSizeBytes,
          minimumSizeRatio: 0.65,
          maximumSizeRatio: job.mediaType === "dvd" ? 1.05 : undefined,
          maximumSizeOverheadBytes:
            job.mediaType === "dvd" ? 16 * 1024 * 1024 : undefined,
          maximumDurationDrift: job.mediaType === "dvd" ? 0.02 : undefined,
          expectedStreamCounts: taskSnapshot
            ? {
                video: taskSnapshot.streamSelection.videoTrackIds.length,
                audio: taskSnapshot.streamSelection.audioTrackIds.length,
                // DVD vobsub (dvd_subtitle) tracks cannot be stream-copied into
                // MKV; the remux intentionally skips them, so do not require them.
                subtitle:
                  job.mediaType === "dvd"
                    ? 0
                    : taskSnapshot.streamSelection.subtitleTrackIds.length,
              }
            : undefined,
          // Only require the selected chapters when the chapter metadata was
          // actually written (DVD navigation can fail on CSS discs and the
          // analysis fallback may not always provide a chapter layout).
          expectedChapterCount: chapterMetadataFile
            ? taskSnapshot?.chapterSelection.chapterIds.length
            : undefined,
        },
      );
      fileSizeAfter = validation.fileSize;
      outputDuration = validation.duration;
      if (validation.drift !== null && validation.drift > 0.05)
        await addLog(
          jobId,
          "warn",
          `Remux 输出时长与源文件差异 ${(validation.drift * 100).toFixed(1)}%（源 ${job.durationSeconds?.toFixed(1)} 秒，输出 ${outputDuration?.toFixed(1)} 秒）`,
        );
    } catch (probeError) {
      await addLog(jobId, "error", `Remux 输出校验失败：${String(probeError)}`);
      throw probeError;
    }
    const endPlayable = await verifyOutputEndPlayable(
      jobId,
      remuxOutputFile,
      outputDuration ?? job.durationSeconds,
    );
    if (!endPlayable.ok) {
      throw new Error(`输出后段解码失败，文件可能损坏：${endPlayable.error}`);
    }
    pipelineRemuxOutputPath = (
      await finalizeRemuxStage({
        jobId,
        remuxOutputFile,
        fileSizeAfter,
        outputDuration,
        pipelineContinuesAfterRemux,
        subtitlePath,
        translatedSubtitlePath,
        graphicSubtitlePaths,
        log: (level, message) => addLog(jobId, level, message),
      })
    ).pipelineRemuxOutputPath;
    if (!pipelineContinuesAfterRemux)
      return { pipelineRemuxOutputPath, shouldReturn: true };
  }
  return { pipelineRemuxOutputPath, shouldReturn: false };
}
