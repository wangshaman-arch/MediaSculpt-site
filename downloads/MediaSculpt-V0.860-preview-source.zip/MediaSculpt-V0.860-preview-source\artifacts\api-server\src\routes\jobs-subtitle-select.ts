// Extracted from routes/jobs.ts: external subtitle selection and detection.
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import {
  lookupAll,
  metadataIdentityMatches,
  normalizeTitleEn,
} from "../lib/metadata";
import {
  servePreviewSegment,
  cleanupPreviewSegments,
} from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import {
  buildFfconcatFileContent as buildManifest,
  buildFfconcatChapterContent,
  buildFfconcatTimedContent,
  type FfconcatTimedSegment,
} from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import {
  appendJobRuntimeLog,
  appendJobToolOutput,
} from "../lib/job-runtime-log";
import {
  appendRuntimeToolLog,
  appendRuntimeToolOutput,
} from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import {
  buildCompressionOutputName,
  buildRemuxOutputName,
  cleanSegment,
  encoderBitDepth,
  selectBestAudioTrack,
} from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import {
  renderBilingualAss,
  DEFAULT_BILINGUAL_STYLE,
  type BilingualAssStyle,
  type SubtitleBlock,
} from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import {
  ensureLocalPoster,
  MEDIA_INFO_DIR,
  POSTER_META_FILE,
  posterIdentityMatches,
} from "../lib/poster";
import {
  ensureFasterWhisperModel,
  ensureWhisperCliScript,
} from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import {
  hasValidSubtitleCues,
  isGraphicSubtitleCodec,
  shouldFallbackToWhisper,
} from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import {
  buildDvdRemuxArgs,
  runDvdRemux,
  verifyDvdTitle,
} from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import {
  buildDvdStructurePayload,
  resolveRemuxPlanWithLlm,
  validateRemuxPlan,
} from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import {
  assertPreviewTaskAllowed,
  recordPreviewAiCall,
  settlePreviewTask,
} from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import {
  parseCustomTuning,
  resolveLogicPlaceholders,
} from "../lib/custom-tuning";
import {
  decryptSecret,
  encryptSecret,
  isEncryptedSecret,
} from "../lib/secrets";
import {
  ffmpegPath,
  resolveOutputDir,
  resolveRuntimePath,
  type RuntimePathConfig,
} from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import {
  assertCompleteMediaTitle,
  createDvdMediaTitle,
} from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import {
  buildPreviewTranscodeArgs,
  isPreviewVideoCandidate,
  previewService,
} from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";

// Moved here from routes/jobs.ts: the subtitle file shape owned by detection.
export type DetectedSubtitleFile = {
  path: string;
  language: "zh" | "en" | "bilingual" | "other";
};

/**
 * Select the external subtitle that should seed the subtitle pipeline.
 * Normal/translation modes intentionally keep the historical behaviour of
 * selecting an English or other-language source; bilingual mode is the one
 * exception: when Chinese is the only available same-name subtitle, reuse it
 * instead of triggering Whisper and translating Chinese into Chinese.
 */
export function selectExternalSubtitleForJob(
  detected: DetectedSubtitleFile[],
  isBilingual: boolean,
): DetectedSubtitleFile | null {
  // A dual-language sidecar is already the requested output. Prefer it for
  // bilingual jobs so the same file is never used as both source and target.
  const bilingualSub = detected.find((item) => item.language === "bilingual");
  if (isBilingual && bilingualSub) return bilingualSub;
  const englishSub = detected.find((item) => item.language === "en");
  const fallbackSub =
    detected.find((item) => item.language === "other") ?? englishSub;
  return (
    englishSub ??
    fallbackSub ??
    (isBilingual ? detected.find((item) => item.language === "zh") : null) ??
    null
  );
}

/**
 * A Chinese subtitle often contains an occasional Latin proper name, acronym,
 * or quoted foreign word.  That is not evidence that the file is bilingual.
 * Only count independent foreign subtitle lines (normally the second line of
 * a two-line cue), and require repeated evidence before classifying a file as
 * a dual-language source.
 */
function hasIndependentBilingualEvidence(sample: string): boolean {
  const blocks = sample
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .split(/\n\s*\n+/);
  let bilingualCueCount = 0;
  let foreignOnlyLineCount = 0;

  for (const block of blocks) {
    const lines = block
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean);
    const textLines = lines.filter(
      (line) => !/^\d+$/.test(line) && !line.includes("-->"),
    );
    if (textLines.length < 2) continue;
    const chineseLines = textLines.filter((line) =>
      /[\u3400-\u9fff]/.test(line),
    );
    const foreignOnlyLines = textLines.filter(
      (line) => !/[\u3400-\u9fff]/.test(line) && /[A-Za-z]{2,}/.test(line),
    );
    if (chineseLines.length > 0 && foreignOnlyLines.length > 0)
      bilingualCueCount += 1;
    foreignOnlyLineCount += foreignOnlyLines.length;
  }

  return bilingualCueCount >= 2 || foreignOnlyLineCount >= 3;
}

function extractAssDialogueText(sample: string): string {
  return sample
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .split("\n")
    .filter((line) => /^Dialogue:\s*\d+/i.test(line))
    .map((line) =>
      line
        .split(",")
        .slice(9)
        .join(",")
        .replace(/\{[^}]*\}/g, ""),
    )
    .join("\n\n");
}

function hasBilingualAssCues(sample: string): boolean {
  const dialogueText = extractAssDialogueText(sample);
  if (!dialogueText) return false;
  const cues = dialogueText.split(/\n\s*\n+/).filter((cue) => {
    const lines = cue
      .split(/\\N/i)
      .map((line) => line.trim())
      .filter(Boolean);
    const hasChineseLine = lines.some((line) => /[\u3400-\u9fff]/.test(line));
    const hasForeignLine = lines.some(
      (line) => !/[\u3400-\u9fff]/.test(line) && /[A-Za-z]{2,}/.test(line),
    );
    return lines.length >= 2 && hasChineseLine && hasForeignLine;
  });
  return cues.length >= 2;
}

/**
 * Find existing subtitle files in a directory by content and size, ignoring
 * file extensions. Videos/audio and binary files are excluded by the size
 * window and by parsing the content as SRT/ASS/text.
 */
export async function detectExistingSubtitleFiles(
  directory: string,
  mediaBaseName?: string,
): Promise<DetectedSubtitleFile[]> {
  const entries = await fs.readdir(directory).catch(() => []);
  const results: DetectedSubtitleFile[] = [];
  for (const entry of entries) {
    const full = path.join(directory, entry);
    try {
      const stat = await fs.stat(full);
      if (!stat.isFile() || stat.size < 300 || stat.size > 20 * 1024 * 1024)
        continue;
    } catch {
      continue;
    }
    // 按文件名配对：只有与媒体文件同名（或同名 + 语言/说明后缀，如 Movie.zh.srt）
    // 的字幕才属于该媒体文件。同目录其他视频的字幕不能算作本文件“已含中文/已翻译”。
    if (mediaBaseName) {
      const lowerBase = mediaBaseName.toLowerCase();
      const entryBase = path.basename(entry, path.extname(entry)).toLowerCase();
      if (entryBase !== lowerBase && !entryBase.startsWith(`${lowerBase}.`))
        continue;
    }
    let sample = "";
    try {
      const handle = await fs.open(full, "r");
      const buffer = Buffer.alloc(8192);
      const { bytesRead } = await handle.read(buffer, 0, buffer.length, 0);
      await handle.close();
      sample = buffer.subarray(0, bytesRead).toString("utf8");
    } catch {
      continue;
    }
    if (!sample.trim()) continue;
    const ext = path.extname(entry).toLowerCase();
    const srtMarkers = (
      sample.match(
        /\d{1,2}:\d{2}:\d{2}[,.]\d{1,3}\s*-->\s*\d{1,2}:\d{2}:\d{2}[,.]\d{1,3}/g,
      ) || []
    ).length;
    const assMarkers = (sample.match(/^Dialogue:\s*\d+/gm) || []).length;
    if (srtMarkers + assMarkers < 2) {
      const lines = sample
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter(Boolean);
      const printable = lines.filter((line) =>
        /^[\p{L}\p{N}\p{P}\p{S}\s]+$/u.test(line),
      ).length;
      if (lines.length < 3 || printable / Math.max(lines.length, 1) < 0.7)
        continue;
    }
    const assDialogueText = /\.(?:ass|ssa)$/i.test(ext)
      ? extractAssDialogueText(sample)
      : "";
    const languageSample = assDialogueText || sample;
    const hasHan = /[\u3400-\u9fff]/.test(languageSample);
    const hasKana = /[\u3040-\u30ff]/.test(languageSample);
    const hasLatin = /[a-zA-Z]/.test(languageSample);
    const isBilingual = /\.(?:ass|ssa)$/i.test(ext)
      ? hasBilingualAssCues(sample)
      : hasHan && hasLatin && hasIndependentBilingualEvidence(sample);
    const language = isBilingual
      ? "bilingual"
      : hasHan && !hasKana
        ? "zh"
        : hasLatin
          ? "en"
          : "other";
    results.push({ path: full, language });
  }
  return results;
}

import { pickBestAudioTrack, probeAudioTracks } from "./jobs-audio";
export { pickBestAudioTrack, probeAudioTracks } from "./jobs-audio";

import { translateBatchLibre, translateBatch } from "./jobs-translation";
export { translateBatchLibre, translateBatch } from "./jobs-translation";

import {
  buildWhisperCorrectionPrompt,
  buildTranslationPrompt,
  findPosterUrlByLlm,
} from "./jobs-prompts";
export {
  buildWhisperCorrectionPrompt,
  buildTranslationPrompt,
  findPosterUrlByLlm,
} from "./jobs-prompts";

// ─── Main subtitle pipeline ───────────────────────────────────────────────────
import {
  fullSubtitlePacketThreshold,
  sampleEmbeddedSubtitleText,
  textLooksChinese,
  probeSubtitlePacketCount,
  languageTagIsChinese,
} from "./jobs-subtitle-probe";
export {
  fullSubtitlePacketThreshold,
  sampleEmbeddedSubtitleText,
  textLooksChinese,
  probeSubtitlePacketCount,
  languageTagIsChinese,
} from "./jobs-subtitle-probe";
import type { PipelineStep } from "./jobs-subtitle-probe";
export type { PipelineStep } from "./jobs-subtitle-probe";
