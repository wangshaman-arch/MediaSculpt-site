import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { describe, expect, it } from "vitest";
import {
  analyzeDvdSource,
  assertCompleteMediaTitle,
  createDvdMediaSource,
  orderedDvdInputs,
} from "./dvd-source";

describe("DVD media source", () => {
  it("preserves the IFO-derived VOB order in an immutable title", () => {
    const source = createDvdMediaSource({
      sourcePath: "H:\\Movie DVD",
      titles: [
        {
          titleNumber: 1,
          discRoot: "H:\\Movie DVD",
          videoTsDir: "H:\\Movie DVD\\VIDEO_TS",
          ifoPath: "H:\\Movie DVD\\VIDEO_TS\\VTS_01_0.IFO",
          vobFiles: [
            "H:\\Movie DVD\\VIDEO_TS\\VTS_01_1.VOB",
            "H:\\Movie DVD\\VIDEO_TS\\VTS_01_2.VOB",
            "H:\\Movie DVD\\VIDEO_TS\\VTS_01_10.VOB",
          ],
          missingVobFiles: [],
          sizeBytes: 123,
        },
      ],
    });

    expect(source.kind).toBe("dvd");
    expect(source.titles[0]?.orderedInputs).toEqual([
      "H:\\Movie DVD\\VIDEO_TS\\VTS_01_1.VOB",
      "H:\\Movie DVD\\VIDEO_TS\\VTS_01_2.VOB",
      "H:\\Movie DVD\\VIDEO_TS\\VTS_01_10.VOB",
    ]);
    expect(Object.isFrozen(source)).toBe(true);
    expect(Object.isFrozen(source.titles)).toBe(true);
    expect(Object.isFrozen(source.titles[0]?.orderedInputs)).toBe(true);
    expect(source.titles[0]?.missingInputs).toEqual([]);
  });

  it("returns the same immutable input sequence to every processing stage", () => {
    const source = createDvdMediaSource({
      sourcePath: "H:\\Movie DVD",
      titles: [
        {
          titleNumber: 1,
          discRoot: "H:\\Movie DVD",
          videoTsDir: "H:\\Movie DVD\\VIDEO_TS",
          ifoPath: "H:\\Movie DVD\\VIDEO_TS\\VTS_01_0.IFO",
          vobFiles: ["H:\\Movie DVD\\VIDEO_TS\\VTS_01_1.VOB"],
          missingVobFiles: [],
          sizeBytes: 123,
        },
      ],
    });

    const first = orderedDvdInputs(source.titles[0]!);
    const second = orderedDvdInputs(source.titles[0]!);
    expect(first).toBe(second);
    expect(first).toEqual(["H:\\Movie DVD\\VIDEO_TS\\VTS_01_1.VOB"]);
  });

  it("analyzes an IFO-backed DVD and rejects missing numeric VOB segments", async () => {
    const root = await fs.mkdtemp(path.join(os.tmpdir(), "mediasculpt-dvd-"));
    const videoTs = path.join(root, "VIDEO_TS");
    await fs.mkdir(videoTs);
    await fs.writeFile(path.join(videoTs, "VIDEO_TS.IFO"), "ifo");
    await fs.writeFile(path.join(videoTs, "VTS_01_0.IFO"), "ifo");
    await fs.writeFile(path.join(videoTs, "VTS_01_1.VOB"), "one");
    await fs.writeFile(path.join(videoTs, "VTS_01_3.VOB"), "three");

    try {
      const source = await analyzeDvdSource({ sourcePath: root });
      const title = source.titles[0]!;
      expect(title.orderedInputs.map((file) => path.basename(file))).toEqual([
        "VTS_01_1.VOB",
        "VTS_01_3.VOB",
      ]);
      expect(title.missingInputs).toEqual(["VTS_01_2.VOB"]);
      expect(() => assertCompleteMediaTitle(title)).toThrowError(
        /VTS_01_2\.VOB/,
      );
    } finally {
      await fs.rm(root, { recursive: true, force: true });
    }
  });
});
