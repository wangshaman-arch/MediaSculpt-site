import { afterEach, describe, expect, it } from "vitest";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import type { RemuxCommandPlan } from "./remux-pipeline";
import { executeRemuxPlan, type RemuxProcessExecutor } from "./remux-executor";

const files: string[] = [];
afterEach(async () => {
  await Promise.all(
    files.splice(0).map((file) => fs.rm(file, { force: true })),
  );
});

function plan(outputPath: string): RemuxCommandPlan {
  return Object.freeze({
    executable: "ffmpeg.exe",
    args: Object.freeze(["-y", "-i", "input.mkv", outputPath]),
    outputPath,
    temporaryInputs: Object.freeze([]),
    expected: Object.freeze({
      video: 1,
      audio: 0,
      subtitle: 0,
      chapters: 0,
      durationSeconds: null,
    }),
  });
}

function runner(callback: RemuxProcessExecutor["run"]): RemuxProcessExecutor {
  return { run: callback };
}

describe("Remux executor", () => {
  it("keeps a valid output after the process completes", async () => {
    const output = path.join(
      os.tmpdir(),
      `vx-remux-executor-${Date.now()}.mkv`,
    );
    files.push(output);
    const result = await executeRemuxPlan({
      jobId: 1,
      plan: plan(output),
      processes: runner(async ({ outputPath }) => {
        await fs.writeFile(outputPath, Buffer.alloc(32));
        return { stdout: "", stderr: "" };
      }),
    });

    expect(result.fileSize).toBe(32);
    expect(await fs.stat(output)).toMatchObject({ size: 32 });
  });

  it("removes a partial output when the external process fails", async () => {
    const output = path.join(
      os.tmpdir(),
      `vx-remux-executor-fail-${Date.now()}.mkv`,
    );
    files.push(output);
    await expect(
      executeRemuxPlan({
        jobId: 2,
        plan: plan(output),
        processes: runner(async ({ outputPath }) => {
          await fs.writeFile(outputPath, Buffer.alloc(32));
          throw new Error("ffmpeg exit 1");
        }),
      }),
    ).rejects.toThrow("ffmpeg exit 1");
    await expect(fs.stat(output)).rejects.toMatchObject({ code: "ENOENT" });
  });

  it("does not treat a successful command without an output file as success", async () => {
    const output = path.join(
      os.tmpdir(),
      `vx-remux-executor-empty-${Date.now()}.mkv`,
    );
    files.push(output);
    await expect(
      executeRemuxPlan({
        jobId: 3,
        plan: plan(output),
        processes: runner(async () => ({ stdout: "", stderr: "" })),
      }),
    ).rejects.toThrow("未生成有效输出");
  });
});
