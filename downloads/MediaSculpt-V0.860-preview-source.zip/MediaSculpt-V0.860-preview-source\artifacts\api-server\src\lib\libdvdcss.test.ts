import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { describe, expect, it, vi } from "vitest";
import {
  ensureLibdvdcss,
  isLibdvdcssMissingError,
  isLibdvdcssInstalled,
  isPeDllHead,
  libdvdcssTargetPath,
  type LibdvdcssDownloadFn,
} from "./libdvdcss";

const CSS_ERROR = "libdvdread: Could not open E:\\VIDEO_TS with libdvdcss.";

describe("libdvdcss auto-provisioning", () => {
  it("recognizes the classic libdvdcss missing error and ignores unrelated probe errors", () => {
    expect(isLibdvdcssMissingError(CSS_ERROR)).toBe(true);
    expect(
      isLibdvdcssMissingError("libdvdcss failed to load from C:\\tools"),
    ).toBe(true);
    expect(isLibdvdcssMissingError("dvdvideo: unknown demuxer")).toBe(false);
    expect(
      isLibdvdcssMissingError("Invalid data found when processing input"),
    ).toBe(false);
    expect(isLibdvdcssMissingError("")).toBe(false);
  });

  it("places the DLL next to the ffmpeg executable on win32 only", () => {
    const target = libdvdcssTargetPath(
      "C:\\VX-Agent\\ffmpeg\\bin\\ffmpeg.exe",
      "win32",
    );
    expect(target).toMatch(/libdvdcss-2\.dll$/);
    expect(libdvdcssTargetPath("/usr/bin/ffmpeg", "linux")).toBeNull();
    expect(libdvdcssTargetPath("/usr/local/bin/ffmpeg", "darwin")).toBeNull();
  });

  it("validates the PE magic before accepting a payload", () => {
    expect(isPeDllHead(new Uint8Array([0x4d, 0x5a, 0x90, 0x00]), 4096)).toBe(
      true,
    );
    expect(isPeDllHead(new Uint8Array([0x50, 0x4b, 0x03, 0x04]), 4096)).toBe(
      false,
    );
    expect(isPeDllHead(new Uint8Array([0x3c, 0x21, 0x64, 0x6f]), 4096)).toBe(
      false,
    );
    expect(isPeDllHead(new Uint8Array([0x4d, 0x5a]), 512)).toBe(false);
  });

  it("installs the DLL from a working mirror and skips bad payloads", async () => {
    const root = await fs.mkdtemp(path.join(os.tmpdir(), "vx-libdvdcss-"));
    const executable = path.join(root, "ffmpeg.exe");
    await fs.writeFile(executable, "ffmpeg stub");
    const mzPayload = new Uint8Array(4096);
    mzPayload[0] = 0x4d;
    mzPayload[1] = 0x5a;
    const download: LibdvdcssDownloadFn = vi.fn(async (url) => ({
      ok: true,
      status: 200,
      data: url.includes("bad")
        ? new Uint8Array([0x3c, 0x68, 0x74, 0x6d, 0x6c])
        : mzPayload,
    }));
    const logs: string[] = [];
    const status = await ensureLibdvdcss(executable, {
      platform: "win32",
      mirrors: ["https://example.com/bad.dll", "https://example.com/good.dll"],
      timeoutMs: 1000,
      download,
      onLog: async (message) => {
        logs.push(message);
      },
    });
    expect(status).toBe("installed");
    expect(await isLibdvdcssInstalled(executable, "win32")).toBe(true);
    expect(logs.some((line) => line.includes("not a PE DLL"))).toBe(true);
    expect(
      await fs
        .access(path.join(root, "libdvdcss-2.dll"))
        .then(() => true)
        .catch(() => false),
    ).toBe(true);
  });

  it("returns already when the DLL exists and failed when every mirror fails", async () => {
    const root = await fs.mkdtemp(path.join(os.tmpdir(), "vx-libdvdcss-"));
    const executable = path.join(root, "ffmpeg.exe");
    await fs.writeFile(executable, "ffmpeg stub");
    const mzPayload = new Uint8Array(4096);
    mzPayload[0] = 0x4d;
    mzPayload[1] = 0x5a;
    await fs.writeFile(
      path.join(root, "libdvdcss-2.dll"),
      Buffer.from(mzPayload),
    );
    expect(
      await ensureLibdvdcss(executable, {
        platform: "win32",
        mirrors: ["https://example.com/x.dll"],
        timeoutMs: 1000,
      }),
    ).toBe("already");

    const failingDownload: LibdvdcssDownloadFn = vi.fn(async () => ({
      ok: false,
      status: 404,
      data: new Uint8Array(),
    }));
    expect(
      await ensureLibdvdcss(executable, {
        platform: "win32",
        force: true,
        mirrors: ["https://example.com/missing.dll"],
        timeoutMs: 1000,
        download: failingDownload,
      }),
    ).toBe("failed");
  });

  it("reports unsupported on non-Windows platforms without touching the disk", async () => {
    const download: LibdvdcssDownloadFn = vi.fn(async () => ({
      ok: true,
      status: 200,
      data: new Uint8Array(4096),
    }));
    expect(
      await ensureLibdvdcss("/usr/local/bin/ffmpeg", {
        platform: "darwin",
        download,
      }),
    ).toBe("unsupported");
    expect(await isLibdvdcssInstalled("/usr/bin/ffmpeg", "linux")).toBe(false);
    expect(download).not.toHaveBeenCalled();
  });
});
