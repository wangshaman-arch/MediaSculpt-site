import { jobsTable, configTable } from "@workspace/db";
import {
  DEFAULT_BILINGUAL_STYLE,
  type BilingualAssStyle,
} from "../lib/bilingual-subtitle";
import {
  parsePipelineNames,
  parsePipelineSteps,
  type PipelineNames,
  type WorkflowPipelineStep,
} from "./jobs-pipeline";

type ExecutionJobInput = Pick<
  typeof jobsTable.$inferSelect,
  "pipelineSteps" | "subtitleMode" | "selectionPlan"
>;

type BilingualConfigInput = Pick<
  typeof configTable.$inferSelect,
  | "bilingualLayout"
  | "bilingualOutlineWidth"
  | "bilingualShadowWidth"
  | "bilingualOutlineColor"
  | "bilingualFontSizeTop"
  | "bilingualFontSizeBottom"
>;

export type JobExecutionContext = {
  pipelineSteps: WorkflowPipelineStep[];
  pipelineNames: PipelineNames;
  pipelineRemuxIndex: number;
  pipelineSubtitleIndex: number;
  pipelineCompressIndex: number;
  pipelineHasRemux: boolean;
  pipelineHasSubtitle: boolean;
  pipelineHasCompress: boolean;
  pipelineContinuesAfterRemux: boolean;
  isBilingual: boolean;
  subtitleMode: string;
  selectionPlanOptions: Record<string, unknown>;
  bilingualStyle: BilingualAssStyle;
};

function parseSelectionPlanOptions(
  value: string | null,
): Record<string, unknown> {
  if (!value) return {};
  try {
    const parsed: unknown = JSON.parse(value);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed)
      ? (parsed as Record<string, unknown>)
      : {};
  } catch {
    return {};
  }
}

export function buildJobExecutionContext(input: {
  job: ExecutionJobInput;
  config: Partial<BilingualConfigInput>;
}): JobExecutionContext {
  const pipelineSteps = parsePipelineSteps(input.job);
  const pipelineNames = parsePipelineNames(input.job);
  const pipelineRemuxIndex = pipelineSteps.indexOf("remux");
  const pipelineSubtitleIndex = pipelineSteps.indexOf("subtitle");
  const pipelineCompressIndex = pipelineSteps.indexOf("compress");
  const pipelineHasRemux = pipelineRemuxIndex >= 0;
  const pipelineHasSubtitle = pipelineSubtitleIndex >= 0;
  const pipelineHasCompress = pipelineCompressIndex >= 0;
  const isBilingual = input.job.subtitleMode === "bilingual";
  const selectionPlanOptions = parseSelectionPlanOptions(
    input.job.selectionPlan,
  );
  const bilingualStyle: BilingualAssStyle = {
    layout:
      selectionPlanOptions.bilingualLayout === "foreign-top"
        ? "foreign-top"
        : input.config.bilingualLayout === "foreign-top"
          ? "foreign-top"
          : "zh-top",
    outlineWidth:
      typeof input.config.bilingualOutlineWidth === "number"
        ? input.config.bilingualOutlineWidth
        : DEFAULT_BILINGUAL_STYLE.outlineWidth,
    shadowWidth:
      typeof input.config.bilingualShadowWidth === "number"
        ? input.config.bilingualShadowWidth
        : DEFAULT_BILINGUAL_STYLE.shadowWidth,
    outlineColor:
      typeof input.config.bilingualOutlineColor === "string" &&
      input.config.bilingualOutlineColor.trim()
        ? input.config.bilingualOutlineColor
        : DEFAULT_BILINGUAL_STYLE.outlineColor,
    fontSizeTop:
      typeof input.config.bilingualFontSizeTop === "number"
        ? input.config.bilingualFontSizeTop
        : DEFAULT_BILINGUAL_STYLE.fontSizeTop,
    fontSizeBottom:
      typeof input.config.bilingualFontSizeBottom === "number"
        ? input.config.bilingualFontSizeBottom
        : DEFAULT_BILINGUAL_STYLE.fontSizeBottom,
  };

  return {
    pipelineSteps,
    pipelineNames,
    pipelineRemuxIndex,
    pipelineSubtitleIndex,
    pipelineCompressIndex,
    pipelineHasRemux,
    pipelineHasSubtitle,
    pipelineHasCompress,
    pipelineContinuesAfterRemux: pipelineHasRemux && pipelineSteps.length > 1,
    isBilingual,
    subtitleMode: isBilingual ? "auto" : input.job.subtitleMode,
    selectionPlanOptions,
    bilingualStyle,
  };
}
