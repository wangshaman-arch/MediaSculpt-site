import { describe, expect, it } from "vitest";
import { migrateMediaSculptPresetStorage } from "./brand-storage";

function storageWith(values: Record<string, string>) {
  const data = new Map(Object.entries(values));
  return {
    getItem: (key: string) => data.get(key) ?? null,
    setItem: (key: string, value: string) => data.set(key, value),
  };
}

describe("MediaSculpt preset storage migration", () => {
  it("copies legacy presets only when the MediaSculpt key is absent", () => {
    const storage = storageWith({
      "vx-agent-archive-presets-v1": "legacy-archive",
      "vx-agent-custom-presets": "legacy-custom",
      "vx-agent-ocr-engine": "tesseract",
      "vx-agent-tuning-custom-presets": "legacy-tuning",
      "mediasculpt-custom-presets": "current-custom",
    });

    migrateMediaSculptPresetStorage(storage);

    expect(storage.getItem("mediasculpt-archive-presets-v1")).toBe(
      "legacy-archive",
    );
    expect(storage.getItem("mediasculpt-custom-presets")).toBe(
      "current-custom",
    );
    expect(storage.getItem("mediasculpt-ocr-engine")).toBe("tesseract");
    expect(storage.getItem("mediasculpt-tuning-custom-presets")).toBe(
      "legacy-tuning",
    );
    expect(storage.getItem("vx-agent-custom-presets")).toBe("legacy-custom");
  });
});
