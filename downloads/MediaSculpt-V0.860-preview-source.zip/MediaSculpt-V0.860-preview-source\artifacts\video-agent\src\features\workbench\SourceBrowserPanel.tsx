// Extracted from pages/Scan.tsx: the file browser panel.
import {
  Profiler,
  useState,
  useCallback,
  useEffect,
  useMemo,
  useRef,
} from "react";
import {
  useCreateJob,
  useBrowseDirectory,
  useGetConfig,
  getGetConfigQueryKey,
  useUpdateConfig,
  useAnalyzeDisc,
  useListJobs,
  getListJobsQueryKey,
} from "@workspace/api-client-react";
import type { DiscTrack, DiscStream } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import { ToastAction } from "@/components/ui/toast";
import {
  Loader2,
  Play,
  ArrowLeft,
  SquareCheck,
  Square,
  Disc,
  X,
  Video,
  Music,
  Subtitles,
  HelpCircle,
  ChevronDown,
  ChevronsUpDown,
  Save,
  ScanText,
  Sparkles,
  Layers,
  List,
  Wand2,
  Mic,
  Languages,
  Captions,
  Settings2,
  RotateCcw,
} from "lucide-react";
import { useLocation } from "wouter";
import {
  useToolAvailability,
  toolsRequiredForSubtitle,
} from "@/lib/use-tool-availability";
import { cn, formatDate } from "@/lib/utils";
import {
  ARCHIVE_PRESETS,
  ARCHIVE_PRESET_LS_KEY,
  compressionConfigValues,
  CUSTOM_COMPRESSION_PRESET_ID,
  PRESET_CHANGED_EVENT,
  loadCompressionPresets,
  presetConfigValues,
  type ArchivePreset,
  type CompressionPresetValues,
} from "@/lib/compression-presets";
import { useI18n, useScanCopy } from "@/i18n";
import {
  useWorkbenchState,
  type ProcessingMode,
  type SubtitleMode,
  type WorkbenchTab,
} from "@/hooks/useWorkbenchState";
import { WorkbenchModeTabs } from "./WorkbenchModeTabs";
import { SubtitleModeSelector } from "./SubtitleModeSelector";
import { CompressionPresetPanel } from "./CompressionPresetPanel";
import { DiscTitleRow } from "./DiscTitleRow";
import { WorkbenchSourceEntry } from "./WorkbenchSourceEntry";
import {
  browserStorage,
  readLastBrowsePath,
  readNetworkPathHistory,
  rememberBrowsePath,
  rememberNetworkPath,
} from "./source-browser-storage";
import {
  lastPathSegment,
  normalizeBatchStreams,
  sortBrowserEntries,
} from "./source-browser-model";
import { SourceBrowserNetworkPanel } from "./SourceBrowserNetworkPanel";
import { SourceBrowserDirectoryList } from "./SourceBrowserDirectoryList";
import {
  formatDiscBytes as fmtBytes,
  formatDiscChapterDuration as fmtChapterDuration,
  formatDiscDuration as fmtDuration,
  handBrakeTrackNumbers,
  streamLanguageDisplay as languageLabel,
  streamDisplayLabel as streamLabel,
  streamTechnicalBadges,
  trackLanguageDisplay as trackLanguageSummary,
  type DiscStreamWithHandBrake,
  type DiscTrackWithMakeMkv,
} from "./disc-display-model";
import Workflow from "@/pages/Workflow";
import type { BatchItem } from "@/pages/BatchConfirmPage";
import {
  OCR_ENGINE_KEY,
  OCR_LANGUAGE_KEY,
  OCR_LANGUAGE_CODES,
  ocrLanguageLabel,
} from "@/lib/ocr-languages";
import {
  discFolderName,
  isDirectM2tsTitle,
  stableDiscTitleKey,
} from "../../pages/scan-model";
import { DiscAnalyzeDialog } from "./DiscAnalyzeDialog";

import { fileHoverTitle, type ScanCopy } from "../../pages/Scan";

// ── File browser ──────────────────────────────────────────────────────────────
// NOTE: The parent MUST pass key={watchDir} and wait for config before rendering
// this component. That ensures we always start at the correct directory without
// any async init logic inside the component itself.
export function SourceBrowserPanel({
  onJobsCreated,
  onAnalysisConfirmed,
  subtitleMode,
  ocrEngine,
  ocrLanguage,
  bilingualLayout = "zh-top",
  processingMode,
  defaultPath,
  uiText,
  isRemuxMode = false,
  embedded = false,
  defaultOpen,
  onSelectMode,
  analysisOnly = false,
}: {
  onJobsCreated: (count: number, firstId?: number) => void;
  onAnalysisConfirmed?: (items: BatchItem[]) => void;
  subtitleMode: SubtitleMode;
  ocrEngine?: string;
  ocrLanguage?: string;
  bilingualLayout?: "zh-top" | "foreign-top";
  defaultPath: string; // required — parent must wait for config
  processingMode: ProcessingMode;
  uiText: ScanCopy;
  isRemuxMode?: boolean;
  embedded?: boolean;
  /** 首次挂载时展开浏览区；仍保留用户可操作的展开/收起按钮。 */
  defaultOpen?: boolean;
  onSelectMode?: (mode: ProcessingMode, subtitleMode?: SubtitleMode) => void;
  /** Smart Workflow analyzes disc structure here; processing is chosen later. */
  analysisOnly?: boolean;
}) {
  // Start at defaultPath immediately — no async init needed because the parent
  // only renders us after config has loaded (key={watchDir} ensures remount on change).
  const { t, lang } = useI18n();
  const [currentPath, setCurrentPath] = useState(() =>
    readLastBrowsePath(browserStorage(), defaultPath),
  );
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [creating, setCreating] = useState(false);
  const [analyzeDiscPath, setAnalyzeDiscPath] = useState<string | null>(null);
  const [networkPathHistory, setNetworkPathHistory] = useState<string[]>(() =>
    readNetworkPathHistory(browserStorage()),
  );
  const [networkPath, setNetworkPath] = useState(
    () => readNetworkPathHistory(browserStorage())[0] ?? "",
  );
  const [recentLocationsOpen, setRecentLocationsOpen] = useState(false);
  const [networkDetailsOpen, setNetworkDetailsOpen] = useState(false);
  const [browseDetailsOpen, setBrowseDetailsOpen] = useState(
    defaultOpen ?? embedded,
  );
  // Default: newest first (by modified time) — matches how users scan a fresh
  // batch of downloads/folders in the source directory.
  const [sortBy, setSortBy] = useState<"name" | "modified">("modified");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const scanRequestIdRef = useRef(0);
  const networkPathInputRef = useRef<HTMLInputElement>(null);

  const { data, isLoading, isError } = useBrowseDirectory({
    path: currentPath,
  });
  const createJob = useCreateJob();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const dirs = data?.entries?.filter((e) => e.type === "dir") ?? [];
  const files = data?.entries?.filter((e) => e.type === "file") ?? [];
  const sortedDirs = sortBrowserEntries(dirs, sortBy, sortDir);
  const sortedFiles = sortBrowserEntries(files, sortBy, sortDir);
  const currentDiscType = data?.discType ?? null;
  // Server may return a `warning` string for non-existent directories
  const dirWarning =
    (data as { warning?: string } | undefined)?.warning ?? null;

  useEffect(() => {
    scanRequestIdRef.current += 1;
  }, [currentPath]);

  // Auto-open disc dialog only in remux mode
  useEffect(() => {
    if (isRemuxMode && currentDiscType && currentPath && !analyzeDiscPath) {
      setAnalyzeDiscPath(currentPath);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isRemuxMode, currentPath, currentDiscType]);

  function navigate(path: string) {
    setCurrentPath(path);
    rememberBrowsePath(browserStorage(), path);
    setSelected(new Set());
    setAnalyzeDiscPath(null);
  }

  function openNetworkPath(pathValue = networkPath) {
    const next = pathValue.trim();
    if (!next) return;
    setNetworkPathHistory(rememberNetworkPath(browserStorage(), next));
    setNetworkPath(next);
    navigate(next);
  }

  function toggleFile(filePath: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(filePath) ? next.delete(filePath) : next.add(filePath);
      return next;
    });
  }

  function toggleAll() {
    setSelected(
      selected.size === files.length && files.length > 0
        ? new Set()
        : new Set(files.map((f) => f.path)),
    );
  }

  async function handleAddSelected() {
    if (selected.size === 0) return;
    setCreating(true);
    let ok = 0,
      fail = 0;
    let firstId: number | undefined;
    let lastError: unknown = null;
    // “添加所选”只处理本级视频文件；光盘目录请用“批量任务”走分析流程。
    const filePaths = Array.from(selected).filter((path) =>
      files.some((file) => file.path === path),
    );
    if (filePaths.length === 0) {
      setCreating(false);
      toast({ title: "No video files selected", variant: "destructive" });
      return;
    }
    for (const filePath of filePaths) {
      try {
        const result = await createJob.mutateAsync({
          data: {
            filePath,
            subtitleMode: isRemuxMode ? "skip" : subtitleMode,
            ocrEngine:
              !isRemuxMode && subtitleMode === "ocr"
                ? ((ocrEngine || "auto") as
                    | "auto"
                    | "llm"
                    | "tesseract"
                    | "rapidocr"
                    | "subtitleedit")
                : undefined,
            ocrLanguage:
              !isRemuxMode && subtitleMode === "ocr"
                ? ocrLanguage || "auto"
                : undefined,
            processingMode: isRemuxMode
              ? "remux"
              : subtitleMode === "bilingual"
                ? "none"
                : processingMode,
            ...(subtitleMode === "bilingual"
              ? { outputMode: "subtitle" as const, bilingualLayout }
              : {}),
          },
        });
        if (!firstId && typeof (result as { id?: unknown })?.id === "number")
          firstId = (result as { id: number }).id;
        ok++;
      } catch (error) {
        lastError = error;
        fail++;
      }
    }
    setCreating(false);
    setSelected(new Set());
    if (ok > 0) {
      toast({
        title: `${uiText.addedTasks}: ${ok}`,
        description: fail > 0 ? `${fail} failed` : undefined,
      });
      onJobsCreated(ok, firstId);
    } else {
      toast({
        title: "Failed to add tasks",
        description:
          lastError instanceof Error ? lastError.message : String(lastError),
        variant: "destructive",
      });
    }
  }

  // 批量任务：本级文件直接分析；本级光盘文件夹按光盘分析（每个标题一个批量项），
  // 不递归子目录，忽略普通目录与光盘内的散视频。
  async function handleBatchCreate() {
    if (selected.size === 0) return;
    setCreating(true);
    const items: BatchItem[] = [];
    let ignored = 0;
    for (const entryPath of Array.from(selected)) {
      const entry = [...dirs, ...files].find((e) => e.path === entryPath);
      if (!entry) {
        ignored += 1;
        continue;
      }
      if (entry.type === "dir") {
        const discType = (entry as { discType?: string | null }).discType;
        if (!discType) {
          ignored += 1;
          continue;
        }
        try {
          const response = await fetch(
            `/api/disc/analyze?path=${encodeURIComponent(entryPath)}`,
          );
          if (!response.ok) {
            ignored += 1;
            continue;
          }
          const data = (await response.json()) as Record<string, unknown>;
          const kind: BatchItem["kind"] =
            data.discType === "dvd" ? "dvd" : "bluray";
          const tracks = Array.isArray(data.tracks) ? data.tracks : [];
          for (const track of tracks as Array<Record<string, unknown>>) {
            if (typeof track.titleId !== "string") continue;
            items.push({
              key: `${entryPath}::${track.titleId}`,
              path: entryPath,
              kind,
              label:
                typeof track.name === "string" && track.name
                  ? track.name
                  : lastPathSegment(entryPath),
              titleId: track.titleId,
              analysisId:
                typeof data.analysisId === "string" ? data.analysisId : null,
              sourceFingerprint:
                typeof data.sourceFingerprint === "string"
                  ? data.sourceFingerprint
                  : null,
              handbrakeTitleNumber:
                typeof track.handbrakeTitleNumber === "number"
                  ? track.handbrakeTitleNumber
                  : null,
              playlistId:
                typeof track.playlistId === "string" ? track.playlistId : null,
              mappingStatus:
                typeof track.mappingStatus === "string"
                  ? track.mappingStatus
                  : null,
              verificationStatus:
                typeof track.verificationStatus === "string"
                  ? track.verificationStatus
                  : null,
              dvdVtsNumber:
                typeof track.dvdVtsNumber === "number"
                  ? track.dvdVtsNumber
                  : null,
              durationSeconds:
                typeof track.durationSeconds === "number"
                  ? track.durationSeconds
                  : null,
              chapterCount: Array.isArray(track.chapters)
                ? track.chapters.length
                : undefined,
              streams: normalizeBatchStreams(track.streams),
            });
          }
        } catch {
          ignored += 1;
        }
      } else {
        try {
          const response = await fetch(
            `/api/media/analyze?path=${encodeURIComponent(entryPath)}`,
          );
          if (!response.ok) {
            ignored += 1;
            continue;
          }
          const data = (await response.json()) as Record<string, unknown>;
          items.push({
            key: entryPath,
            path: entryPath,
            kind: "video",
            label: lastPathSegment(entryPath),
            durationSeconds:
              typeof data.durationSeconds === "number"
                ? data.durationSeconds
                : null,
            streams: normalizeBatchStreams(data.streams),
          });
        } catch {
          ignored += 1;
        }
      }
    }
    setCreating(false);
    if (items.length === 0) {
      toast({
        title: "No batchable items",
        description: ignored > 0 ? `${ignored} ignored` : undefined,
        variant: "destructive",
      });
      return;
    }
    sessionStorage.setItem("vx-batch-items", JSON.stringify(items));
    if (ignored > 0)
      toast({
        title: `${uiText.batchTasks}: ${items.length}`,
        description: `${ignored} ignored`,
      });
    setLocation("/batch");
  }

  const allSelected = files.length > 0 && selected.size === files.length;
  const selectedSizeBytes = files
    .filter((entry) => selected.has(entry.path))
    .reduce((total, entry) => total + (entry.sizeBytes ?? 0), 0);
  // 单选视频文件 → “添加所选”通道；单选光盘目录或多选 → “批量任务”通道（光盘需先分析选标题）。
  const singleSelectedPath =
    selected.size === 1 ? Array.from(selected)[0] : null;
  const singleIsVideo =
    singleSelectedPath !== null &&
    files.some((entry) => entry.path === singleSelectedPath);
  // Smart Workflow is a planning flow: even a single video must go through
  // the shared preview/selection page instead of creating a job immediately.
  const previewSelectedVideo = analysisOnly && singleIsVideo;

  if (analyzeDiscPath) {
    return (
      <DiscAnalyzeDialog
        key={analyzeDiscPath}
        discPath={analyzeDiscPath}
        processingMode={processingMode}
        subtitleMode={subtitleMode}
        ocrEngine={ocrEngine}
        ocrLanguage={ocrLanguage}
        bilingualLayout={bilingualLayout}
        uiText={uiText}
        analysisOnly={analysisOnly}
        onClose={() => setAnalyzeDiscPath(null)}
        onJobCreated={(count, firstId) => {
          setAnalyzeDiscPath(null);
          onJobsCreated(count, firstId);
        }}
        onAnalysisConfirmed={onAnalysisConfirmed}
        onSelectMode={analysisOnly ? undefined : onSelectMode}
      />
    );
  }

  return (
    <div
      className="space-y-3"
      data-testid="source-browser-panel"
      onDragOver={(event) => event.preventDefault()}
      onDrop={(event) => {
        event.preventDefault();
        const droppedPath = event.dataTransfer.getData("text/plain").trim();
        if (droppedPath) navigate(droppedPath);
      }}
    >
      {/* Path bar */}
      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          disabled={!data?.parent}
          onClick={() => data?.parent && navigate(data.parent)}
        >
          <ArrowLeft className="h-4 w-4 mr-1" /> {uiText.backToParent}
        </Button>
        <div
          className="font-mono text-sm bg-secondary/30 border rounded px-3 py-1.5 flex-1 min-w-0 truncate text-muted-foreground"
          title={currentPath}
        >
          {currentPath}
        </div>
      </div>

      {!embedded && (
        <Button
          type="button"
          variant="secondary"
          size="sm"
          className="w-full justify-between bg-secondary/40"
          onClick={() => setBrowseDetailsOpen((open) => !open)}
          aria-expanded={browseDetailsOpen}
        >
          <span>
            {browseDetailsOpen ? uiText.collapseBrowse : uiText.expandBrowse}
          </span>
          <ChevronDown
            className={cn(
              "h-4 w-4 transition-transform",
              browseDetailsOpen && "rotate-180",
            )}
          />
        </Button>
      )}

      {(embedded || browseDetailsOpen) && (
        <div className="space-y-3">
          <SourceBrowserNetworkPanel
            networkPath={networkPath}
            networkPathHistory={networkPathHistory}
            recentLocationsOpen={recentLocationsOpen}
            networkDetailsOpen={networkDetailsOpen}
            networkPathInputRef={networkPathInputRef}
            text={uiText}
            onToggleNetworkDetails={() =>
              setNetworkDetailsOpen((open) => !open)
            }
            onNetworkPathChange={setNetworkPath}
            onOpenNetworkPath={openNetworkPath}
            onChooseNetworkLocation={() => {
              networkPathInputRef.current?.focus();
              networkPathInputRef.current?.select();
            }}
            onDirectoryPathChange={(path) => {
              setNetworkPath(path);
              setNetworkPathHistory(
                rememberNetworkPath(browserStorage(), path),
              );
              openNetworkPath(path);
            }}
            onToggleRecentLocations={() =>
              setRecentLocationsOpen((open) => !open)
            }
          />

          {/* Disc root banner — shown in ALL processing modes. DVD Remux uses the
          verified FFmpeg dvdvideo route; Blu-ray keeps its existing route. */}
          {currentDiscType && (
            <div className="flex items-center gap-3 px-4 py-3 rounded-lg border border-blue-500/30 bg-blue-500/5">
              <Disc className="h-5 w-5 text-blue-400 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium">
                  {currentDiscType === "bluray" ? "🔵 Blu-ray" : "📀 DVD"}{" "}
                  {uiText.discDirectory}
                </p>
                <p className="text-xs text-muted-foreground">
                  {uiText.discBannerPrefix} {uiText.modes[processingMode].label}
                </p>
              </div>
              <Button size="sm" onClick={() => setAnalyzeDiscPath(currentPath)}>
                <Disc className="h-3.5 w-3.5 mr-1.5" />
                {uiText.discAnalysis}
              </Button>
            </div>
          )}

          {/* Select all bar — hidden in OCR mode, which targets a single source */}
          {files.length > 0 && (
            <div className="flex items-center justify-between px-1">
              <button
                onClick={toggleAll}
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                {allSelected ? (
                  <SquareCheck className="h-4 w-4 text-primary" />
                ) : (
                  <Square className="h-4 w-4" />
                )}
                {allSelected
                  ? uiText.clearSelection
                  : `${uiText.selectAll} ${files.length}`}
              </button>
              {selected.size > 0 && (
                <div className="flex items-center gap-3">
                  <span className="text-xs text-muted-foreground">
                    {t("scan.selectedCount", { count: selected.size })} ·{" "}
                    {selectedSizeBytes > 0
                      ? fmtBytes(selectedSizeBytes)
                      : uiText.sizeUnknown}
                  </span>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-8"
                    onClick={() => {
                      if (previewSelectedVideo) void handleBatchCreate();
                      else if (singleIsVideo) void handleAddSelected();
                      else void handleBatchCreate();
                    }}
                    disabled={creating}
                    data-testid="btn-add-or-batch"
                  >
                    {singleIsVideo && !previewSelectedVideo ? (
                      <Play className="h-3.5 w-3.5 mr-1.5" />
                    ) : (
                      <Layers className="h-3.5 w-3.5 mr-1.5" />
                    )}
                    {creating
                      ? uiText.creating
                      : previewSelectedVideo
                        ? uiText.previewSelected
                        : singleIsVideo
                          ? `${uiText.addSelected} (1)`
                          : `${uiText.batchTasks}${selected.size > 1 ? ` (${selected.size})` : ""}`}
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* Directory listing */}
          <div className="mb-2 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
            <span className="font-medium text-foreground">
              {uiText.processableMedia}
            </span>
            <span className="hidden sm:inline">{uiText.dragHint}</span>
            <div className="ml-auto flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => {
                  if (sortBy === "name")
                    setSortDir((current) =>
                      current === "asc" ? "desc" : "asc",
                    );
                  else {
                    setSortBy("name");
                    setSortDir("asc");
                  }
                }}
                className={cn(
                  "rounded border px-1.5 py-0.5 transition-colors",
                  sortBy === "name"
                    ? "border-primary/50 bg-primary/15 text-primary"
                    : "border-border/60 hover:border-primary/40",
                )}
              >
                {uiText.sortByName}
                {sortBy === "name" ? (sortDir === "asc" ? " ↑" : " ↓") : ""}
              </button>
              <button
                type="button"
                onClick={() => {
                  if (sortBy === "modified")
                    setSortDir((current) =>
                      current === "asc" ? "desc" : "asc",
                    );
                  else {
                    setSortBy("modified");
                    setSortDir("desc");
                  }
                }}
                className={cn(
                  "rounded border px-1.5 py-0.5 transition-colors",
                  sortBy === "modified"
                    ? "border-primary/50 bg-primary/15 text-primary"
                    : "border-border/60 hover:border-primary/40",
                )}
              >
                {uiText.sortByModified}
                {sortBy === "modified" ? (sortDir === "asc" ? " ↑" : " ↓") : ""}
              </button>
            </div>
          </div>
          <SourceBrowserDirectoryList
            dirs={sortedDirs}
            files={sortedFiles}
            isLoading={isLoading}
            isError={isError}
            dirWarning={dirWarning}
            hasParent={Boolean(data?.parent)}
            selected={selected}
            text={uiText}
            translate={t}
            fileTitle={(entry) => fileHoverTitle(entry, t, lang)}
            onToggle={toggleFile}
            onNavigate={navigate}
            onAnalyze={setAnalyzeDiscPath}
          />
        </div>
      )}
    </div>
  );
}
