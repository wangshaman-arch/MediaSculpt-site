import fsSync from "fs";
import fs from "fs/promises";
import path from "path";
import { db, jobsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { ffmpegPath } from "../lib/runtime-paths";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildLosslessRemuxArgs } from "./job-encoding";
import { cancelledJobs } from "./jobs-tracking";
import { probeStreams } from "./jobs-probe";
import { runFfmpegCapture } from "./jobs-ffmpeg-run";
import { finalizeRemuxStage } from "./job-remux-finalization";

export function resolveBluRayM2tsTitlePath(
  discSourcePath: string,
  selectedTitleId: string | null | undefined,
): string | null {
  const match = /^m2ts:(\d+)$/.exec(String(selectedTitleId ?? ""));
  return match
    ? path.join(discSourcePath, "BDMV", "STREAM", `${match[1]}.m2ts`)
    : null;
}

export async function tryRemuxBluRayM2ts(input: {
  jobId: number;
  discSourcePath: string;
  selectedTitleId: string | null | undefined;
  remuxSelectedStreams: number[] | null;
  remuxOutputFile: string;
  expectedDurationSeconds: number | null;
  pipelineContinuesAfterRemux: boolean;
  subtitlePath: string | null;
  translatedSubtitlePath: string | null;
  graphicSubtitlePaths?: readonly string[];
  log: (level: "info" | "warn" | "error", message: string) => Promise<unknown>;
}): Promise<{ handled: boolean; pipelineRemuxOutputPath: string | null }> {
  const streamPath = resolveBluRayM2tsTitlePath(
    input.discSourcePath,
    input.selectedTitleId,
  );
  if (!streamPath) return { handled: false, pipelineRemuxOutputPath: null };
  if (!fsSync.existsSync(streamPath))
    throw new Error(`未找到蓝光片段文件：${streamPath}`);

  await input.log("info", `蓝光片段直接 Remux：${streamPath}`);
  const remuxBuild = await buildLosslessRemuxArgs(
    streamPath,
    undefined,
    input.remuxSelectedStreams,
  );
  if (remuxBuild.transcodedPcmBluray) {
    await input.log(
      "info",
      "检测到蓝光 LPCM（pcm_bluray）音轨，已无损转换为 MKV 兼容的 PCM（pcm_s24le）",
    );
  }
  await runFfmpegCapture(input.jobId, [
    "-i",
    ffmpegPath(streamPath),
    ...remuxBuild.args,
    "-fflags",
    "+genpts",
    "-y",
    input.remuxOutputFile,
  ]);
  await db
    .update(jobsTable)
    .set({ progress: 60 })
    .where(eq(jobsTable.id, input.jobId));
  if (cancelledJobs.has(input.jobId)) {
    await fs.rm(input.remuxOutputFile, { force: true }).catch(() => {});
    throw new Error("任务已取消");
  }

  let fileSizeAfter: number;
  let outputDuration: number | null;
  try {
    const validation = await validateRemuxOutput(
      input.remuxOutputFile,
      input.expectedDurationSeconds,
      probeStreams,
      {
        expectedSizeBytes: null,
        minimumSizeRatio: 0.6,
      },
    );
    fileSizeAfter = validation.fileSize;
    outputDuration = validation.duration;
  } catch (probeError) {
    await input.log(
      "error",
      `FFmpeg Remux 输出校验失败：${String(probeError)}`,
    );
    throw probeError;
  }

  const finalization = await finalizeRemuxStage({
    jobId: input.jobId,
    remuxOutputFile: input.remuxOutputFile,
    fileSizeAfter,
    outputDuration,
    pipelineContinuesAfterRemux: input.pipelineContinuesAfterRemux,
    subtitlePath: input.subtitlePath,
    translatedSubtitlePath: input.translatedSubtitlePath,
    graphicSubtitlePaths: input.graphicSubtitlePaths,
    log: input.log,
  });
  return { handled: true, ...finalization };
}
