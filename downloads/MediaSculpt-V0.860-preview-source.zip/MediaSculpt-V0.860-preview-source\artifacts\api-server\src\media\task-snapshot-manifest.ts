import type {
  DiscAnalysisStream,
  UnifiedDiscTitle,
} from "../lib/disc-analysis";
import type {
  TaskSnapshotOutputMode,
  TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  createMediaPipelineManifest,
  type MediaPipelineInput,
  type MediaPipelineManifest,
  type MediaPipelineStream,
  type MediaPipelineStreamType,
} from "./media-pipeline-contract";

export type SnapshotManifestSourceKind = "file" | "dvd" | "bluray" | "iso";

export type BuildManifestFromSnapshotInput = {
  snapshot: TaskSnapshotV1;
  /** Verified title metadata: stream codecs/languages/track numbers and chapters. */
  title?: UnifiedDiscTitle | null;
  /** Persisted selection plan; supplies DVD audio codecs when the title is unavailable. */
  selectionPlan?: string | null;
  /** Physical source bytes (DVD `VIDEO_TS` total); never used as an output size. */
  physicalBytes?: number | null;
  /**
   * Resolved runtime input path to place in `manifest.source.path`. The route
   * resolves it (`resolveDvdVideoInputPath`) because it depends on config and
   * the platform; the planner then passes it through verbatim.
   */
  sourcePath?: string;
};

const SOURCE_KIND: Record<
  TaskSnapshotV1["sourceType"],
  SnapshotManifestSourceKind
> = {
  video: "file",
  dvd: "dvd",
  bluray: "bluray",
  iso: "iso",
};

/**
 * Translate the immutable task snapshot into the shared media pipeline manifest.
 * This is the single place where the snapshot's string ids ("stream:3",
 * "chapter:2") become the manifest's verified stream/chapter references.
 */
export function buildMediaPipelineManifestFromSnapshot(
  input: BuildManifestFromSnapshotInput,
): MediaPipelineManifest {
  const { snapshot } = input;
  const selected = {
    video: [...snapshot.streamSelection.videoTrackIds],
    audio: [...snapshot.streamSelection.audioTrackIds],
    subtitle: [...snapshot.streamSelection.subtitleTrackIds],
  };
  const codecOverrides = audioCodecsFromSelectionPlan(input.selectionPlan);
  const baseStreams = input.title ? streamsFromTitle(input.title) : [];
  const streams = mergeStreams(baseStreams, selected, codecOverrides);
  const { chapters, chapterIds } = chaptersFor(snapshot, input.title);
  const manifestInput: MediaPipelineInput = {
    source: {
      kind: SOURCE_KIND[snapshot.sourceType],
      path: input.sourcePath ?? snapshot.sourcePath,
      fingerprint: snapshot.sourceFingerprint,
      physicalBytes: input.physicalBytes ?? null,
    },
    title: {
      id: snapshot.selectedTitleId,
      titleNumber: titleNumberFor(snapshot),
      durationSeconds: input.title?.durationSeconds ?? null,
      streams,
      chapters,
    },
    selection: {
      streamIds: [...selected.video, ...selected.audio, ...selected.subtitle],
      chapterIds,
    },
    output: {
      mode: outputModeFor(snapshot.outputMode),
      directory: snapshot.output.directory,
      fileName: snapshot.output.fileName,
      estimatedBytes: null,
    },
  };
  return createMediaPipelineManifest(manifestInput);
}

function outputModeFor(
  mode: TaskSnapshotOutputMode,
): MediaPipelineInput["output"]["mode"] {
  switch (mode) {
    case "remux":
      return "remux";
    case "compress":
      return "compress";
    case "subtitle":
    case "whisper":
      return "subtitle";
    case "both":
      throw new Error("both 模式需要按阶段分别构建清单（Remux 与压缩各一份）");
    case "audio":
      throw new Error("audio 模式不属于媒体清单支持的输出模式");
  }
}

/**
 * The manifest carries one title number used by both `ffmpeg -f dvdvideo
 * -title N` (DVD) and `HandBrakeCLI --title N` (DVD + Blu-ray compression).
 * For DVD those are the same value; for Blu-ray only the HandBrake number
 * exists, so falling back to it is what stops compression from encoding the
 * wrong (default title 1) clip.
 */
function titleNumberFor(snapshot: TaskSnapshotV1): number | null {
  if (snapshot.sourceType === "dvd") {
    const dvdVtsNumber = snapshot.toolSelections.dvdVtsNumber;
    return typeof dvdVtsNumber === "number" && dvdVtsNumber > 0
      ? dvdVtsNumber
      : null;
  }
  const handbrakeTitleNumber = snapshot.toolSelections.handbrakeTitleNumber;
  return typeof handbrakeTitleNumber === "number" && handbrakeTitleNumber > 0
    ? handbrakeTitleNumber
    : null;
}

function streamTypeFor(
  codecType: DiscAnalysisStream["codecType"],
): MediaPipelineStreamType | null {
  return codecType === "video" ||
    codecType === "audio" ||
    codecType === "subtitle"
    ? codecType
    : null;
}

function streamsFromTitle(title: UnifiedDiscTitle): MediaPipelineStream[] {
  const streams: MediaPipelineStream[] = [];
  for (const stream of title.streams) {
    const type = streamTypeFor(stream.codecType);
    if (!type) continue;
    streams.push({
      id: `stream:${stream.index}`,
      index: stream.index,
      type,
      codec: stream.codecName ?? null,
      language: stream.language ?? null,
      title: stream.title ?? null,
      handbrakeTrackNumber: stream.handbrakeTrackNumber ?? null,
      bitsPerRawSample: stream.bitsPerRawSample ?? null,
    });
  }
  return streams;
}

function idIndex(id: string): number {
  const match = /^stream:(\d+)$/.exec(id);
  const index = match ? Number(match[1]) : Number.NaN;
  if (!Number.isInteger(index) || index < 0)
    throw new Error(`无效的流轨选择：${id}`);
  return index;
}

function mergeStreams(
  base: MediaPipelineStream[],
  selected: { video: string[]; audio: string[]; subtitle: string[] },
  codecOverrides: Map<number, string | null>,
): MediaPipelineStream[] {
  const byId = new Map(base.map((stream) => [stream.id, stream]));
  const ensure = (ids: string[], type: MediaPipelineStreamType) => {
    for (const id of ids) {
      if (byId.has(id)) continue;
      const index = idIndex(id);
      byId.set(id, {
        id,
        index,
        type,
        codec: type === "audio" ? (codecOverrides.get(index) ?? null) : null,
        language: null,
        title: null,
        handbrakeTrackNumber: null,
      });
    }
  };
  ensure(selected.video, "video");
  ensure(selected.audio, "audio");
  ensure(selected.subtitle, "subtitle");
  return [...byId.values()];
}

function chapterIdFrom(value: string): number | null {
  const match = /^chapter:(\d+)$/.exec(value);
  const id = match ? Number(match[1]) : Number.NaN;
  return Number.isInteger(id) ? id : null;
}

function chaptersFor(
  snapshot: TaskSnapshotV1,
  title?: UnifiedDiscTitle | null,
): { chapters: MediaPipelineInput["title"]["chapters"]; chapterIds: number[] } {
  const chapters = (title?.chapters ?? []).map((chapter) => ({
    id: chapter.id,
    startSeconds: chapter.startSeconds,
    endSeconds: chapter.endSeconds,
    title: chapter.title ?? null,
  }));
  const available = new Set(chapters.map((chapter) => chapter.id));
  const selection = snapshot.chapterSelection;
  if (selection.mode === "all") {
    return {
      chapters,
      chapterIds: title ? chapters.map((chapter) => chapter.id) : [],
    };
  }
  if (selection.mode === "range") {
    const start = selection.start ?? 1;
    const end = selection.end ?? Number.MAX_SAFE_INTEGER;
    const inRange = chapters.filter(
      (chapter) => chapter.id >= start && chapter.id <= end,
    );
    return { chapters, chapterIds: inRange.map((chapter) => chapter.id) };
  }
  const ids = selection.chapterIds
    .map(chapterIdFrom)
    .filter((id): id is number => id !== null);
  if (ids.length !== selection.chapterIds.length)
    throw new Error("章节选择包含无效的章节 ID");
  if (!title && ids.length > 0)
    throw new Error("缺少已验证标题章节，无法解析章节选择");
  if (ids.some((id) => !available.has(id)))
    throw new Error("章节选择引用了不存在的章节");
  return { chapters, chapterIds: ids };
}

function audioCodecsFromSelectionPlan(
  selectionPlan?: string | null,
): Map<number, string | null> {
  const result = new Map<number, string | null>();
  if (!selectionPlan) return result;
  let parsed: { audioStreams?: unknown };
  try {
    parsed = JSON.parse(selectionPlan) as { audioStreams?: unknown };
  } catch {
    return result;
  }
  if (!Array.isArray(parsed?.audioStreams)) return result;
  for (const value of parsed.audioStreams) {
    if (!value || typeof value !== "object") continue;
    const candidate = value as Record<string, unknown>;
    if (
      typeof candidate.inputIndex !== "number" ||
      !Number.isInteger(candidate.inputIndex)
    )
      continue;
    result.set(
      candidate.inputIndex,
      typeof candidate.codecName === "string" ? candidate.codecName : null,
    );
  }
  return result;
}
