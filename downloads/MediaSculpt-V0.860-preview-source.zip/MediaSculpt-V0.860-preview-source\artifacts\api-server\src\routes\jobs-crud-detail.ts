import { Router } from "express";
import { db, jobsTable, jobLogsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { GetJobLogsParams, GetJobParams } from "@workspace/api-zod";
import { normalizeTitleEn } from "../lib/metadata";
import { reconcileMovieOverview } from "./jobs-crud-helpers";

const router = Router();
// GET /jobs/:id
router.get("/jobs/:id", async (req, res) => {
  const parsed = GetJobParams.safeParse(req.params);
  if (!parsed.success) return res.status(400).json({ error: "无效的任务 ID" });

  const rows = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, parsed.data.id))
    .limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });

  return res.json(rows[0]);
});

// GET /jobs/:id/logs
router.get("/jobs/:id/logs", async (req, res) => {
  const parsed = GetJobLogsParams.safeParse(req.params);
  if (!parsed.success) return res.status(400).json({ error: "无效的任务 ID" });

  const logs = await db
    .select()
    .from(jobLogsTable)
    .where(eq(jobLogsTable.jobId, parsed.data.id))
    .orderBy(jobLogsTable.createdAt);

  return res.json(logs);
});

// PUT /jobs/:id/metadata
router.put("/jobs/:id/metadata", async (req, res) => {
  const idParsed = GetJobParams.safeParse(req.params);
  if (!idParsed.success)
    return res.status(400).json({ error: "无效的任务 ID" });

  const jobId = idParsed.data.id;
  const rows = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, jobId))
    .limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });

  const {
    movieTitle,
    movieTitleEn,
    movieYear,
    movieRating,
    movieDirector,
    movieGenres,
    movieOverview,
    moviePoster,
    standardizedName,
    tmdbId,
    movieImdbId,
  } = req.body as Record<string, unknown>;
  const requestedImdbId =
    typeof movieImdbId === "string" && /^tt\d{7,8}$/i.test(movieImdbId.trim())
      ? movieImdbId.trim()
      : null;
  const existingImdbId =
    typeof rows[0].movieImdbId === "string" &&
    /^tt\d{7,8}$/i.test(rows[0].movieImdbId.trim())
      ? rows[0].movieImdbId.trim()
      : null;

  const cleanedTitleEn =
    typeof movieTitleEn === "string"
      ? normalizeTitleEn(movieTitleEn) || movieTitleEn
      : movieTitleEn;

  await db
    .update(jobsTable)
    .set({
      movieTitle: typeof movieTitle === "string" ? movieTitle : undefined,
      movieTitleEn:
        typeof cleanedTitleEn === "string" ? cleanedTitleEn : undefined,
      movieYear: typeof movieYear === "number" ? movieYear : undefined,
      movieImdbId: requestedImdbId ?? undefined,
      movieRating: typeof movieRating === "number" ? movieRating : undefined,
      movieDirector:
        typeof movieDirector === "string" ? movieDirector : undefined,
      movieGenres: typeof movieGenres === "string" ? movieGenres : undefined,
      movieOverview:
        typeof movieOverview === "string"
          ? reconcileMovieOverview(
              movieOverview,
              requestedImdbId ?? existingImdbId,
            )
          : undefined,
      moviePoster: typeof moviePoster === "string" ? moviePoster : undefined,
      standardizedName:
        typeof standardizedName === "string" ? standardizedName : undefined,
      tmdbId: typeof tmdbId === "number" ? tmdbId : undefined,
    })
    .where(eq(jobsTable.id, jobId));

  const [updated] = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, jobId))
    .limit(1);
  return res.json(updated);
});

export const jobsCrudDetailRouter = router;
