import fs from "node:fs/promises";
import path from "node:path";

/**
 * libdvdcss auto-provisioning for CSS-protected DVDs.
 *
 * FFmpeg builds ship libdvdread/libdvdnav but not the decryption library.
 * When libdvdread cannot open a VIDEO_TS folder it prints something like:
 *
 *   libdvdread: Could not open E:\VIDEO_TS with libdvdcss.
 *
 * The decoder DLL is loaded dynamically from the directory that contains
 * ffmpeg.exe / ffprobe.exe, so dropping libdvdcss-2.dll next to the binaries
 * is enough to unlock encrypted discs without reinstalling FFmpeg.
 */
export const LIBDVDCSS_FILE_NAME = "libdvdcss-2.dll";

/**
 * Download mirrors in preference order.
 *
 * The allienx 1.4.3/1.5.0 builds (the ones HandBrake ships) are preferred:
 * they are the only ones that also open folder-based VIDEO_TS rips on
 * Windows, while the old official VideoLAN 1.2.12 build only works against a
 * drive root (physical drive / mounted ISO). jsDelivr and the GitHub proxy
 * mirrors cover Chinese networks; the official VideoLAN mirrors remain as a
 * last-resort fallback.
 */
export const LIBDVDCSS_MIRRORS = [
  "https://cdn.jsdelivr.net/gh/allienx/libdvdcss-dll@main/1.5.0/64-bit/libdvdcss-2.dll",
  "https://cdn.jsdelivr.net/gh/allienx/libdvdcss-dll@main/1.4.3/64-bit/libdvdcss-2.dll",
  "https://ghfast.top/https://github.com/allienx/libdvdcss-dll/raw/main/1.5.0/64-bit/libdvdcss-2.dll",
  "https://gh.llkk.cc/https://github.com/allienx/libdvdcss-dll/raw/main/1.4.3/64-bit/libdvdcss-2.dll",
  "https://mirror.netcologne.de/videolan.org/libdvdcss/1.2.12/win64/libdvdcss-2.dll",
  "https://download.videolan.org/pub/libdvdcss/1.2.12/win64/libdvdcss-2.dll",
  "https://http.mirror.yandex.ru/mirrors/ftp.videolan.org/libdvdcss/1.2.12/win64/libdvdcss-2.dll",
  "https://ftp.snt.utwente.nl/pub/software/videolan/libdvdcss/1.2.12/win64/libdvdcss-2.dll",
  "https://mirror.ac2.se/mirror/videolan.org/libdvdcss/1.2.12/win64/libdvdcss-2.dll",
];

/** Short list used by quick health probes so the settings page stays fast. */
export const LIBDVDCSS_PROBE_MIRRORS = LIBDVDCSS_MIRRORS.slice(0, 3);

export type LibdvdcssStatus =
  | "unsupported"
  | "already"
  | "installed"
  | "failed";

export type LibdvdcssDownloadFn = (
  url: string,
  timeoutMs: number,
) => Promise<{ ok: boolean; status: number; data: Uint8Array }>;

/**
 * Detect the classic libdvdread/libdvdcss failure signature in ffmpeg/ffprobe
 * stderr. Only treat it as actionable when the message really talks about the
 * CSS decryption library being unavailable, so unrelated probe errors are not
 * misdiagnosed.
 */
export function isLibdvdcssMissingError(stderr: string): boolean {
  if (!stderr) return false;
  return (
    /libdvdcss/i.test(stderr) &&
    /open|load|couldn'?t|failed|missing|dvdread/i.test(stderr)
  );
}

/**
 * Absolute path where the DLL must live: the same directory as the tool
 * executable (ffmpeg.exe or ffprobe.exe). Windows-only; other platforms use
 * the system package manager and return null.
 */
export function libdvdcssTargetPath(
  executable: string,
  platform: NodeJS.Platform = process.platform,
): string | null {
  if (platform !== "win32") return null;
  return path.join(path.dirname(path.resolve(executable)), LIBDVDCSS_FILE_NAME);
}

export async function isLibdvdcssInstalled(
  executable: string,
  platform: NodeJS.Platform = process.platform,
): Promise<boolean> {
  const target = libdvdcssTargetPath(executable, platform);
  if (!target) return false;
  try {
    const stat = await fs.stat(target);
    return stat.isFile() && stat.size >= 1024;
  } catch {
    return false;
  }
}

/** PE files start with the MZ magic; reject HTML error pages served as 200. */
export function isPeDllHead(head: Uint8Array, totalSize: number): boolean {
  return (
    totalSize >= 1024 &&
    head.length >= 2 &&
    head[0] === 0x4d &&
    head[1] === 0x5a
  );
}

async function defaultDownload(
  url: string,
  timeoutMs: number,
): Promise<{ ok: boolean; status: number; data: Uint8Array }> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      redirect: "follow",
      signal: controller.signal,
    });
    if (!response.ok || !response.body)
      return { ok: false, status: response.status, data: new Uint8Array() };
    const reader = response.body.getReader();
    const chunks: Uint8Array[] = [];
    let received = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      received += value.byteLength;
    }
    return {
      ok: true,
      status: response.status,
      data: Buffer.concat(chunks.map((chunk) => Buffer.from(chunk))),
    };
  } catch {
    return { ok: false, status: 0, data: new Uint8Array() };
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Make sure libdvdcss-2.dll sits next to the given ffmpeg/ffprobe executable.
 * It is a no-op when the DLL already exists (fast path). When missing, mirrors
 * are tried in order; each downloaded payload must pass the PE magic check
 * before it is atomically renamed into place.
 */
export async function ensureLibdvdcss(
  executable: string,
  options: {
    force?: boolean;
    mirrors?: string[];
    timeoutMs?: number;
    download?: LibdvdcssDownloadFn;
    onLog?: (message: string) => void | Promise<void>;
    /** Target platform; injectable so the download/validation logic is testable on any host. */
    platform?: NodeJS.Platform;
  } = {},
): Promise<LibdvdcssStatus> {
  const platform = options.platform ?? process.platform;
  const target = libdvdcssTargetPath(executable, platform);
  if (!target) return "unsupported";
  const log = async (message: string) => {
    await options.onLog?.(message);
  };
  if (!options.force && (await isLibdvdcssInstalled(executable, platform)))
    return "already";
  const mirrors = options.mirrors ?? LIBDVDCSS_MIRRORS;
  const timeoutMs = options.timeoutMs ?? 30_000;
  const download = options.download ?? defaultDownload;
  for (const url of mirrors) {
    try {
      const result = await download(url, timeoutMs);
      if (!result.ok) {
        await log(`libdvdcss: ${url} -> HTTP ${result.status}, skipping`);
        continue;
      }
      if (!isPeDllHead(result.data.slice(0, 16), result.data.length)) {
        await log(
          `libdvdcss: ${url} -> payload is not a PE DLL (MZ magic missing), skipping`,
        );
        continue;
      }
      await fs.mkdir(path.dirname(target), { recursive: true });
      const temp = `${target}.download`;
      await fs.writeFile(temp, Buffer.from(result.data));
      await fs.rename(temp, target);
      await log(`libdvdcss: installed ${target} from ${url}`);
      return "installed";
    } catch (error) {
      await log(
        `libdvdcss: ${url} -> ${error instanceof Error ? error.message : String(error)}`,
      );
    }
  }
  return "failed";
}
