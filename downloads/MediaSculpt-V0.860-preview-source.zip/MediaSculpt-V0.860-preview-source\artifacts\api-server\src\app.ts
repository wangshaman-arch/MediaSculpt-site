import express, {
  type Express,
  type NextFunction,
  type Request,
  type Response,
} from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import path from "node:path";
import { fileURLToPath } from "node:url";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

// Disable HTTP ETags for all API routes so React Query always gets a 200 with
// full body instead of a 304 (empty body) that breaks .json() after a page reload.
app.set("etag", false);

// ── Loopback-only guard ────────────────────────────────────────────────────────
// 本工具是本地应用，API 绑定 127.0.0.1 且无账号体系。为防止"恶意网页通过
// CSRF / DNS 重绑定访问本机 API"（可读任意本地文件、改配置、下载并执行工具），
// 要求 Host 必须是回环地址；若请求带 Origin，其主机也必须是回环。
const LOOPBACK_HOSTNAMES = new Set(["127.0.0.1", "localhost", "::1", "[::1]"]);

function hostnameOf(value: string | undefined): string | null {
  if (!value) return null;
  try {
    return new URL(
      value.includes("://") ? value : `http://${value}`,
    ).hostname.toLowerCase();
  } catch {
    return null;
  }
}

function loopbackOnly(req: Request, res: Response, next: NextFunction): void {
  const host = hostnameOf(req.headers.host);
  if (host && !LOOPBACK_HOSTNAMES.has(host)) {
    res.status(403).json({ error: "仅允许本机访问" });
    return;
  }
  const originHost = hostnameOf(req.headers.origin);
  if (originHost && !LOOPBACK_HOSTNAMES.has(originHost)) {
    res.status(403).json({ error: "仅允许本机访问" });
    return;
  }
  next();
}

app.use(loopbackOnly);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(
  cors({
    origin: ["http://127.0.0.1:24403", "http://localhost:24403"],
  }),
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

// ── Browser heartbeat ──────────────────────────────────────────────────────────
// The frontend pings this every 15 s. In dev mode, if no ping arrives for 60 s
// (browser closed) the process exits so Windows can release file locks.
export const heartbeat = { lastPingMs: Date.now() };
app.post("/api/ping", (_req, res) => {
  heartbeat.lastPingMs = Date.now();
  res.status(204).end();
});

// Serve frontend static files in production
if (process.env.NODE_ENV === "production") {
  const publicDir = path.resolve(
    path.dirname(fileURLToPath(import.meta.url)),
    "../public",
  );
  app.use(express.static(publicDir));
  app.get("/*splat", (_req, res) => {
    res.sendFile(path.join(publicDir, "index.html"));
  });
}

export default app;
