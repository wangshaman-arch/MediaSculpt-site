// Job log persistence helper shared by the route and pipeline modules.
// Extracted from routes/jobs.ts so the route entry is no longer the import hub.
import { db, jobLogsTable } from "@workspace/db";
import { appendJobRuntimeLog } from "./job-runtime-log";

export async function addLog(
  jobId: number,
  level: "info" | "warn" | "error",
  message: string,
) {
  await db.insert(jobLogsTable).values({ jobId, level, message });
  await appendJobRuntimeLog(jobId, level, message).catch(() => {});
}
