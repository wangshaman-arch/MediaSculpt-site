import { createHash } from "node:crypto";

export type DvdManifestTitleInput = {
  sourceFingerprint: string;
  handbrakeTitleNumber: number;
  /** Optional physical identity from an IFO/PGC/Cell reader. */
  physicalIdentity?: string | null;
};

export type DvdManifestStreamInput = {
  titleUid: string;
  type: "video" | "audio" | "subtitle";
  ordinal: number;
  codecName?: string | null;
  language?: string | null;
  channels?: number | null;
};

function normalize(value: string | null | undefined): string {
  return (value ?? "").trim().toLowerCase().replace(/\s+/g, " ");
}

function digest(value: string): string {
  return createHash("sha256").update(value).digest("hex").slice(0, 20);
}

/**
 * A title UID is scoped to the source fingerprint and the tool's immutable
 * logical title number. Physical identity can be added once an IFO reader is
 * available, but array order is deliberately never part of this key.
 */
export function buildDvdTitleUid(input: DvdManifestTitleInput): string {
  if (
    !Number.isInteger(input.handbrakeTitleNumber) ||
    input.handbrakeTitleNumber <= 0
  ) {
    throw new Error("DVD HandBrake 标题编号无效");
  }
  const physical = normalize(input.physicalIdentity);
  const key = [
    "dvd-title",
    normalize(input.sourceFingerprint),
    physical || `handbrake-title-${input.handbrakeTitleNumber}`,
  ].join("|");
  return `dvd-title:${digest(key)}`;
}

/**
 * Stream UIDs use a type-relative ordinal because two DVD audio tracks can
 * legitimately have identical codec, language, and channel metadata.
 */
export function buildDvdStreamUid(input: DvdManifestStreamInput): string {
  if (!Number.isInteger(input.ordinal) || input.ordinal < 0)
    throw new Error("DVD 流轨序号无效");
  const key = [
    input.titleUid,
    normalize(input.type),
    input.ordinal,
    normalize(input.codecName),
    normalize(input.language),
    input.channels ?? "",
  ].join("|");
  return `dvd-track:${digest(key)}`;
}
