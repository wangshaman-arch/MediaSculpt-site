import { Router } from "express";
import { jobsCrudListRouter } from "./jobs-crud-list";
import { jobsCrudCreateRouter } from "./jobs-crud-create";
import { jobsCrudScanRouter } from "./jobs-crud-scan";
import { jobsCrudQueueRouter } from "./jobs-crud-queue";
import { jobsCrudDetailRouter } from "./jobs-crud-detail";
import { jobsCrudLifecycleRouter } from "./jobs-crud-lifecycle";
import { jobsCrudExecutionRouter } from "./jobs-crud-execution";

export {
  requestedWorkflowOutputFileName,
  resolveLlmRemuxPlanForCreate,
} from "./jobs-crud-helpers";

const router = Router();

router.use(jobsCrudListRouter);
router.use(jobsCrudCreateRouter);
router.use(jobsCrudScanRouter);
router.use(jobsCrudQueueRouter);
router.use(jobsCrudDetailRouter);
router.use(jobsCrudLifecycleRouter);
router.use(jobsCrudExecutionRouter);

export const jobsCrudRouter = router;
