// Extracted from routes/jobs.ts: Blu-ray ISO mount / unmount management.
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import {
  lookupAll,
  metadataIdentityMatches,
  normalizeTitleEn,
} from "../lib/metadata";
import {
  servePreviewSegment,
  cleanupPreviewSegments,
} from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import {
  buildFfconcatFileContent as buildManifest,
  buildFfconcatChapterContent,
  buildFfconcatTimedContent,
  type FfconcatTimedSegment,
} from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import {
  appendJobRuntimeLog,
  appendJobToolOutput,
} from "../lib/job-runtime-log";
import {
  appendRuntimeToolLog,
  appendRuntimeToolOutput,
} from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import {
  buildCompressionOutputName,
  buildRemuxOutputName,
  cleanSegment,
  encoderBitDepth,
  selectBestAudioTrack,
} from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import {
  renderBilingualAss,
  DEFAULT_BILINGUAL_STYLE,
  type BilingualAssStyle,
  type SubtitleBlock,
} from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import {
  ensureLocalPoster,
  MEDIA_INFO_DIR,
  POSTER_META_FILE,
  posterIdentityMatches,
} from "../lib/poster";
import {
  ensureFasterWhisperModel,
  ensureWhisperCliScript,
} from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import {
  hasValidSubtitleCues,
  isGraphicSubtitleCodec,
  shouldFallbackToWhisper,
} from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import {
  buildDvdRemuxArgs,
  runDvdRemux,
  verifyDvdTitle,
} from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import {
  buildDvdStructurePayload,
  resolveRemuxPlanWithLlm,
  validateRemuxPlan,
} from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import {
  assertPreviewTaskAllowed,
  recordPreviewAiCall,
  settlePreviewTask,
} from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import {
  parseCustomTuning,
  resolveLogicPlaceholders,
} from "../lib/custom-tuning";
import {
  decryptSecret,
  encryptSecret,
  isEncryptedSecret,
} from "../lib/secrets";
import {
  ffmpegPath,
  resolveOutputDir,
  resolveRuntimePath,
  type RuntimePathConfig,
} from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import {
  assertCompleteMediaTitle,
  createDvdMediaTitle,
} from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import {
  buildPreviewTranscodeArgs,
  isPreviewVideoCandidate,
  previewService,
} from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";

export async function mountBlurayIso(isoPath: string): Promise<string | null> {
  // 先卸载可能残留的同一镜像挂载，避免旧盘符/占用导致 Mount-DiskImage 失败。
  await unmountBlurayIso(isoPath).catch(() => {});
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const drive = await new Promise<string | null>((resolve) => {
      const script = `\$img = Mount-DiskImage -ImagePath '${isoPath.replace(/'/g, "''")}' -PassThru; if (\$img) { (Get-Volume -DiskImage \$img).DriveLetter }`;
      const child = processRunner.spawn({
        executable: "powershell.exe",
        args: ["-NoProfile", "-Command", script],
        stage: "mount-bluray-iso",
        timeoutMs: 30_000,
      }).child;
      let stdout = "";
      let stderr = "";
      child.stdout?.on("data", (chunk) => {
        stdout += String(chunk);
      });
      child.stderr?.on("data", (chunk) => {
        stderr += String(chunk);
      });
      child.on("close", () => {
        const letter = stdout.replace(/\s/g, "");
        resolve(letter ? letter + ":\\" : null);
      });
      child.on("error", () => resolve(null));
    });
    if (drive) {
      // 等待卷文件系统就绪：刚挂载的瞬间可能还读不到目录。
      for (let ready = 0; ready < 6; ready += 1) {
        const entries = await fs.readdir(drive).catch(() => null);
        if (entries) return drive;
        await new Promise((resolve) => setTimeout(resolve, 300));
      }
      return drive;
    }
    await new Promise((resolve) => setTimeout(resolve, 600));
  }
  return null;
}

export async function unmountBlurayIso(isoPath: string): Promise<boolean> {
  const script = `Dismount-DiskImage -ImagePath '${isoPath.replace(/'/g, "''")}' -ErrorAction SilentlyContinue`;
  return new Promise((resolve) => {
    const child = spawn("powershell.exe", ["-NoProfile", "-Command", script], {
      windowsHide: true,
      // Detached so the dismount survives even if the Node process exits
      // first (shutdown cleanup).
      detached: process.platform === "win32",
      stdio: "ignore",
    });
    child.on("close", () => resolve(true));
    child.on("error", () => resolve(false));
  });
}

/**
 * ISOs analysed through /disc/analyze stay mounted after the request so the
 * follow-up steps (verify-title, title-preview, job creation) can still read
 * the drive letter stored in the analysis. The mount is released when a
 * different ISO is analysed or when the app shuts down.
 */
const isoMounts = new Map<string, { drive: string; mountedAt: number }>();

export async function registerIsoMount(
  isoPath: string,
  drive: string,
): Promise<void> {
  for (const [heldPath] of isoMounts) {
    if (
      path.resolve(heldPath).toLowerCase() !==
      path.resolve(isoPath).toLowerCase()
    ) {
      await unmountBlurayIso(heldPath).catch(() => {});
      isoMounts.delete(heldPath);
    }
  }
  isoMounts.set(isoPath, { drive, mountedAt: Date.now() });
}

export async function unmountAllIsoMounts(): Promise<void> {
  for (const heldPath of isoMounts.keys()) {
    await unmountBlurayIso(heldPath).catch(() => {});
  }
  isoMounts.clear();
}

async function driveLetterExists(drive: string): Promise<boolean> {
  try {
    await fs.access(`${drive}\\`);
    return true;
  } catch {
    return false;
  }
}

/**
 * Make sure the drive letter an ISO-backed analysis points at is still
 * mounted; re-mount from the ISO file when the user unmounted it manually.
 * Returns a sourcePath that is valid for the current drive letter.
 */
export async function ensureAnalysisIsoReady(analysis: {
  isoPath?: string | null;
  sourcePath: string;
}): Promise<string> {
  if (!analysis.isoPath) return analysis.sourcePath;
  const held = isoMounts.get(analysis.isoPath);
  if (held && (await driveLetterExists(held.drive))) return analysis.sourcePath;
  const drive = await mountBlurayIso(analysis.isoPath);
  if (!drive) return analysis.sourcePath;
  isoMounts.set(analysis.isoPath, { drive, mountedAt: Date.now() });
  // The re-mounted drive may have received a different letter; remap the
  // stored sourcePath so downstream tools read the right drive.
  const base = path.basename(analysis.sourcePath);
  const remapped = path.join(`${drive}\\`, base);
  if (remapped !== analysis.sourcePath) {
    (analysis as { sourcePath: string }).sourcePath = remapped;
  }
  return analysis.sourcePath;
}
