import fs from "fs/promises";
import { db, jobsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { markJobOutputFileCompleted } from "../infrastructure/job-output-tracker";
import { cancelledJobs } from "./jobs-tracking";
import {
  fixAssPlayResForOutput,
  stageSubtitleSidecars,
} from "./jobs-subtitle-sidecars";
import { settlePreviewTaskSafely } from "../lib/preview-runtime";

export type RemuxFinalizationMode = "pipeline" | "terminal";

export function remuxFinalizationMode(
  pipelineContinuesAfterRemux: boolean,
): RemuxFinalizationMode {
  return pipelineContinuesAfterRemux ? "pipeline" : "terminal";
}

export async function finalizeRemuxStage(input: {
  jobId: number;
  remuxOutputFile: string;
  fileSizeAfter: number;
  outputDuration: number | null;
  pipelineContinuesAfterRemux: boolean;
  subtitlePath: string | null;
  translatedSubtitlePath: string | null;
  graphicSubtitlePaths?: readonly string[];
  log: (level: "info" | "warn" | "error", message: string) => Promise<unknown>;
}): Promise<{ pipelineRemuxOutputPath: string | null }> {
  if (cancelledJobs.has(input.jobId)) {
    await fs.rm(input.remuxOutputFile, { force: true }).catch(() => {});
    throw new Error("任务已取消");
  }

  if (remuxFinalizationMode(input.pipelineContinuesAfterRemux) === "pipeline") {
    await db
      .update(jobsTable)
      .set({
        outputPath: input.remuxOutputFile,
        fileSizeAfter: input.fileSizeAfter,
        progress: 100,
      })
      .where(eq(jobsTable.id, input.jobId));
    markJobOutputFileCompleted(input.jobId, input.remuxOutputFile);
    await input.log(
      "info",
      `① Remux 阶段完成（流水线继续）— ${input.remuxOutputFile}`,
    );
    return { pipelineRemuxOutputPath: input.remuxOutputFile };
  }

  await fixAssPlayResForOutput(
    input.remuxOutputFile,
    input.translatedSubtitlePath,
    async (level, message) => {
      await input.log(level, message);
    },
  );
  await stageSubtitleSidecars(
    input.jobId,
    input.remuxOutputFile,
    input.subtitlePath,
    input.translatedSubtitlePath,
    async (level, message) => {
      await input.log(level, message);
    },
    input.graphicSubtitlePaths,
  );
  await db
    .update(jobsTable)
    .set({
      status: "done",
      progress: 100,
      outputPath: input.remuxOutputFile,
      fileSizeAfter: input.fileSizeAfter,
      durationSeconds: input.outputDuration ?? undefined,
      completedAt: new Date(),
    })
    .where(eq(jobsTable.id, input.jobId));
  await input.log("info", `任务完成 — 输出：${input.remuxOutputFile}`);
  await settlePreviewTaskSafely(input.jobId, {
    taskKind: "remux",
    outputValid: true,
    isPreviewOnly: false,
    cancelled: false,
  });
  return { pipelineRemuxOutputPath: null };
}
