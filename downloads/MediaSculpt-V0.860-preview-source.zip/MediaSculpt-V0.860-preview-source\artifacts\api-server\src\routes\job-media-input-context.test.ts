import { describe, expect, it } from "vitest";
import { resolveSelectedTitleDurationSeconds } from "./job-media-input-context";

describe("job media input context", () => {
  it("prefers the frozen HandBrake duration over analysis metadata", () => {
    expect(
      resolveSelectedTitleDurationSeconds(
        { handbrake: { durationSeconds: 120 } },
        { durationSeconds: 240 },
      ),
    ).toBe(120);
  });

  it("falls back to the selected analysis title when the snapshot is partial", () => {
    expect(
      resolveSelectedTitleDurationSeconds(
        { handbrake: { durationSeconds: null } },
        { durationSeconds: 240 },
      ),
    ).toBe(240);
  });

  it("returns null instead of borrowing a duration from another title", () => {
    expect(
      resolveSelectedTitleDurationSeconds(
        { handbrake: { durationSeconds: null } },
        { durationSeconds: 0 },
      ),
    ).toBeNull();
  });
});
