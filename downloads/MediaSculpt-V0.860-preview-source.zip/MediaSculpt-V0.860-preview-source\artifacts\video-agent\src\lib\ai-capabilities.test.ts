import { describe, expect, it } from "vitest";
import {
  hasSelectedCloudLlmKey,
  hasSubtitleTranslationProvider,
} from "./ai-capabilities";

describe("selected AI provider capabilities", () => {
  it("requires the key for the currently selected provider", () => {
    expect(
      hasSelectedCloudLlmKey({
        aiProvider: "deepseek",
        deepseekApiKey: "  ",
        openaiApiKey: "configured-for-another-provider",
      }),
    ).toBe(false);
    expect(
      hasSelectedCloudLlmKey({
        aiProvider: "deepseek",
        deepseekApiKey: " deepseek-key ",
        openaiApiKey: "configured-for-another-provider",
      }),
    ).toBe(true);
  });

  it("uses the OpenAI key for custom-compatible providers", () => {
    expect(
      hasSelectedCloudLlmKey({ aiProvider: "custom", openaiApiKey: "key" }),
    ).toBe(true);
    expect(hasSelectedCloudLlmKey({ aiProvider: "custom" })).toBe(false);
  });

  it("does not treat LibreTranslate as a cloud LLM", () => {
    const config = { aiProvider: "libretranslate", openaiApiKey: "key" };
    expect(hasSelectedCloudLlmKey(config)).toBe(false);
    expect(hasSubtitleTranslationProvider(config)).toBe(true);
  });

  it("keeps subtitle translation unavailable when no provider is configured", () => {
    expect(hasSelectedCloudLlmKey(undefined)).toBe(false);
    expect(hasSubtitleTranslationProvider(undefined)).toBe(false);
    expect(hasSubtitleTranslationProvider({ aiProvider: "deepseek" })).toBe(
      false,
    );
  });

  it("honors the backend availability flag for env-injected keys", () => {
    // Backend accepts AI_INTEGRATIONS_OPENAI_API_KEY; the config endpoint
    // reports it as aiAvailable so the UI enables cloud features.
    expect(
      hasSelectedCloudLlmKey({ aiProvider: "deepseek", aiAvailable: true }),
    ).toBe(true);
    expect(
      hasSelectedCloudLlmKey({ aiProvider: "custom", aiAvailable: true }),
    ).toBe(true);
    // LibreTranslate stays a local provider even if a fallback key exists.
    expect(
      hasSelectedCloudLlmKey({
        aiProvider: "libretranslate",
        aiAvailable: true,
      }),
    ).toBe(false);
  });
});
