import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { describe, expect, it, vi } from "vitest";
import { projectRoot } from "./windows-contract-helpers";
import {
  analyzeDvdWithHandBrake,
  buildDvdRemuxArgs,
  buildDvdTitleProbeArgs,
  canStartDvdRemux,
  inspectFfmpegCapabilities,
  runDvdRemux,
  verifyDvdTitle,
  type ExternalToolRunner,
} from "./dvd-remux";

const handBrakeOutput = `JSON Title Set: {
  "TitleList": [{
    "Index": 4,
    "Duration": { "Hours": 0, "Minutes": 20, "Seconds": 0 },
    "Geometry": { "Width": 720, "Height": 576 },
    "ChapterList": [
      { "Duration": { "Hours": 0, "Minutes": 10, "Seconds": 0 } },
      { "Duration": { "Hours": 0, "Minutes": 10, "Seconds": 0 } }
    ],
    "AudioList": [{ "TrackNumber": 1, "CodecName": "AC3", "LanguageCode": "eng" }],
    "SubtitleList": [{ "TrackNumber": 1, "Format": "VOBSUB", "LanguageCode": "zho" }]
  }]
}`;

const ffprobeOutput = JSON.stringify({
  streams: [
    {
      index: 0,
      codec_type: "video",
      codec_name: "mpeg2video",
      width: 720,
      height: 576,
    },
    {
      index: 2,
      codec_type: "audio",
      codec_name: "ac3",
      channels: 6,
      tags: { language: "eng" },
    },
    {
      index: 5,
      codec_type: "subtitle",
      codec_name: "dvd_subtitle",
      tags: { language: "zho" },
    },
  ],
  chapters: [
    { id: 0, start_time: "0", end_time: "600" },
    { id: 1, start_time: "600", end_time: "1200" },
  ],
  format: { duration: "1200" },
});

function runnerReturning(
  stdout: string,
): ExternalToolRunner & ReturnType<typeof vi.fn> {
  return vi.fn(async (request) => ({
    tool: request.tool,
    executable: request.executable,
    args: request.args,
    exitCode: 0,
    stdout,
    stderr: "",
    durationMs: 12,
    failureReason: null,
  })) as ExternalToolRunner & ReturnType<typeof vi.fn>;
}

describe("DVD Remux rescue route", () => {
  it("rescans each title when Title 0 JSON only contains MainFeature", async () => {
    const run = vi.fn(async (request) => {
      const titleArgIndex = request.args.indexOf("--title");
      const titleNumber =
        titleArgIndex >= 0 ? Number(request.args[titleArgIndex + 1]) : 0;
      const title = titleNumber > 0 ? titleNumber : 1;
      return {
        tool: request.tool,
        executable: request.executable,
        args: request.args,
        exitCode: 0,
        stdout:
          titleNumber === 0
            ? [
                "scan: DVD has 3 title(s)",
                "scan: duration is 01:00:00 (3600000 ms)",
                "scan: title 1 has 12 chapters",
                "scan: duration is 00:59:58 (3598000 ms)",
                "scan: title 2 has 12 chapters",
                "scan: duration is 01:00:02 (3602000 ms)",
                "scan: title 3 has 12 chapters",
                handBrakeOutput,
              ].join("\n")
            : handBrakeOutput.replace('"Index": 4', `"Index": ${title}`),
        stderr: "",
        durationMs: 12,
        failureReason: null,
      };
    }) as ExternalToolRunner & ReturnType<typeof vi.fn>;

    const result = await analyzeDvdWithHandBrake({
      sourcePath: "D:\\影片甲\\VIDEO_TS",
      sourceFingerprint: "dvd-v1",
      handbrakeExecutable: "C:\\VX Tools\\HandBrakeCLI.exe",
      run,
    });

    expect(run.mock.calls.map(([request]) => request.args)).toHaveLength(4);
    expect(
      result.titles.map((title) => title.toolMappings.handbrakeTitleNumber),
    ).toEqual([1, 2, 3]);
  });

  it("marks a title unavailable when its exact HandBrake scan cannot read the payload", async () => {
    const run = vi.fn(async (request) => {
      const titleArgIndex = request.args.indexOf("--title");
      const titleNumber =
        titleArgIndex >= 0 ? Number(request.args[titleArgIndex + 1]) : 0;
      return {
        tool: request.tool,
        executable: request.executable,
        args: request.args,
        exitCode: titleNumber === 2 ? 2 : 0,
        stdout:
          titleNumber === 0
            ? [
                "scan: DVD has 2 title(s)",
                "scan: duration is 00:20:00 (1200000 ms)",
                "scan: title 1 has 2 chapters",
                "scan: duration is 00:19:58 (1198000 ms)",
                "scan: title 2 has 2 chapters",
                handBrakeOutput,
              ].join("\n")
            : titleNumber === 1
              ? handBrakeOutput.replace('"Index": 4', '"Index": 1')
              : "No title found.",
        stderr: titleNumber === 2 ? "dvdnav: Read Error" : "",
        durationMs: 12,
        failureReason: titleNumber === 2 ? "HandBrake title scan failed" : null,
      };
    }) as ExternalToolRunner & ReturnType<typeof vi.fn>;

    const result = await analyzeDvdWithHandBrake({
      sourcePath: "D:\\损坏盘\\VIDEO_TS",
      sourceFingerprint: "dvd-v1",
      handbrakeExecutable: "C:\\VX Tools\\HandBrakeCLI.exe",
      run,
    });

    expect(
      result.titles.map((title) => [
        title.toolMappings.handbrakeTitleNumber,
        title.availabilityStatus,
      ]),
    ).toEqual([
      [1, "confirmed"],
      [2, "unavailable"],
    ]);
    expect(result.warnings?.join(" ")).toContain("Title 2");
  });

  it("initial analysis invokes HandBrakeCLI exactly once and invokes neither MakeMKV nor ffprobe", async () => {
    const run = runnerReturning(handBrakeOutput);
    const result = await analyzeDvdWithHandBrake({
      sourcePath: "D:\\影片 甲\\VIDEO_TS",
      sourceFingerprint: "dvd-v1",
      handbrakeExecutable: "C:\\VX Tools\\HandBrakeCLI.exe",
      run,
    });

    expect(run).toHaveBeenCalledTimes(1);
    expect(run.mock.calls[0]?.[0]).toMatchObject({ tool: "handbrake" });
    expect(result.titles[0]).toMatchObject({
      titleId: "handbrake:4",
      toolMappings: {
        handbrakeTitleNumber: 4,
        makemkvTitleIndex: null,
        dvdVtsNumber: null,
      },
    });
  });

  it("selection verification invokes ffprobe exactly once with dvdvideo and the selected non-first title", async () => {
    const run = runnerReturning(ffprobeOutput);
    const result = await verifyDvdTitle({
      sourcePath: "D:\\影片 甲\\VIDEO_TS",
      titleNumber: 4,
      handbrakeDurationSeconds: 1200,
      handbrakeChapterCount: 2,
      ffprobeExecutable: "C:\\VX Tools\\ffprobe.exe",
      run,
    });

    expect(run).toHaveBeenCalledTimes(1);
    expect(run.mock.calls[0]?.[0].args).toEqual(
      buildDvdTitleProbeArgs("D:\\影片 甲\\VIDEO_TS", 4),
    );
    expect(result.verified).toBe(true);
    expect(result.titleNumber).toBe(4);
    expect(result.streams.map((stream) => stream.index)).toEqual([0, 2, 5]);
  });

  it("rejects a title whose duration or chapter count clearly disagrees without substituting another title", async () => {
    const run = runnerReturning(
      JSON.stringify({
        ...JSON.parse(ffprobeOutput),
        format: { duration: "300" },
        chapters: [],
      }),
    );
    const result = await verifyDvdTitle({
      sourcePath: "D:\\DVD\\VIDEO_TS",
      titleNumber: 7,
      handbrakeDurationSeconds: 1200,
      handbrakeChapterCount: 2,
      ffprobeExecutable: "ffprobe.exe",
      run,
    });

    expect(result).toMatchObject({ verified: false, titleNumber: 7 });
    expect(result.failureReason).toContain("所选标题验证失败");
  });

  it("passes moderate duration and chapter/stream differences with explicit warnings", async () => {
    const run = runnerReturning(
      JSON.stringify({
        ...JSON.parse(ffprobeOutput),
        format: { duration: "1260" },
        chapters: [{ id: 0, start_time: "0", end_time: "1260" }],
        streams: [
          JSON.parse(ffprobeOutput).streams[0],
          JSON.parse(ffprobeOutput).streams[1],
        ],
      }),
    );
    const result = await verifyDvdTitle({
      sourcePath: "D:\\DVD-9\\VIDEO_TS",
      titleNumber: 7,
      handbrakeDurationSeconds: 1200,
      handbrakeChapterCount: 2,
      handbrakeStreams: [
        {
          index: 0,
          codecType: "video",
          codecName: "mpeg2video",
          language: null,
          title: null,
        },
        {
          index: 1,
          codecType: "audio",
          codecName: "ac3",
          language: "eng",
          title: null,
          handbrakeTrackNumber: 1,
        },
        {
          index: 3,
          codecType: "audio",
          codecName: "ac3",
          language: "jpn",
          title: null,
          handbrakeTrackNumber: 2,
        },
        {
          index: 2,
          codecType: "subtitle",
          codecName: "vobsub",
          language: "zho",
          title: null,
          handbrakeTrackNumber: 1,
        },
      ],
      ffprobeExecutable: "ffprobe.exe",
      run,
    });
    expect(result.verified).toBe(true);
    expect(result.warnings.join(" ")).toContain("时长差异");
    expect(result.warnings.join(" ")).toContain("章节数量差异");
    expect(result.warnings.join(" ")).toContain("音轨数量差异");
  });

  it("positionally maps identical-looking subtitles so a selected track is never dropped", async () => {
    const probe = JSON.stringify({
      streams: [
        {
          index: 0,
          codec_type: "video",
          codec_name: "mpeg2video",
          width: 720,
          height: 576,
        },
        {
          index: 1,
          codec_type: "audio",
          codec_name: "ac3",
          channels: 2,
          tags: { language: "eng" },
        },
        { index: 3, codec_type: "subtitle", codec_name: "dvd_subtitle" },
        { index: 4, codec_type: "subtitle", codec_name: "dvd_subtitle" },
        { index: 5, codec_type: "subtitle", codec_name: "dvd_subtitle" },
      ],
      chapters: [
        { id: 0, start_time: "0", end_time: "600" },
        { id: 1, start_time: "600", end_time: "1200" },
      ],
      format: { duration: "1200" },
    });
    const run = runnerReturning(probe);
    const result = await verifyDvdTitle({
      sourcePath: "D:\\DVD\\VIDEO_TS",
      titleNumber: 4,
      handbrakeDurationSeconds: 1200,
      handbrakeChapterCount: 2,
      handbrakeStreams: [
        {
          index: 0,
          codecType: "video",
          codecName: "mpeg2video",
          language: null,
          title: null,
        },
        {
          index: 1,
          codecType: "audio",
          codecName: "ac3",
          language: "eng",
          title: null,
          handbrakeTrackNumber: 1,
        },
        {
          index: 2,
          codecType: "subtitle",
          codecName: "bitmap",
          language: null,
          title: null,
          handbrakeTrackNumber: 1,
        },
        {
          index: 3,
          codecType: "subtitle",
          codecName: "bitmap",
          language: null,
          title: null,
          handbrakeTrackNumber: 2,
        },
        {
          index: 4,
          codecType: "subtitle",
          codecName: "bitmap",
          language: null,
          title: null,
          handbrakeTrackNumber: 3,
        },
      ],
      ffprobeExecutable: "ffprobe.exe",
      run,
    });
    expect(result.verified).toBe(true);
    const subtitles = result.streams.filter(
      (stream) => stream.codecType === "subtitle",
    );
    expect(subtitles.map((stream) => stream.handbrakeTrackNumber)).toEqual([
      1, 2, 3,
    ]);
  });

  it("blocks only a large duration mismatch while preserving the selected title", async () => {
    const run = runnerReturning(
      JSON.stringify({
        ...JSON.parse(ffprobeOutput),
        format: { duration: "300" },
      }),
    );
    const result = await verifyDvdTitle({
      sourcePath: "D:\\DVD-9\\VIDEO_TS",
      titleNumber: 9,
      handbrakeDurationSeconds: 1200,
      handbrakeChapterCount: 2,
      ffprobeExecutable: "ffprobe.exe",
      run,
    });
    expect(result.verified).toBe(false);
    expect(result.titleNumber).toBe(9);
    expect(result.failureReason).toContain("差异");
  });

  it("builds an argument array that preserves Chinese/space paths, stream choices, chapters and stream copy", () => {
    const args = buildDvdRemuxArgs({
      sourcePath: "D:\\影片 甲\\VIDEO_TS",
      titleNumber: 4,
      selectedVideoStreams: [0],
      selectedAudioStreams: [2],
      selectedSubtitleStreams: [5],
      outputPath: "D:\\输出 目录\\影片.DVD.Remux.mkv",
    });

    expect(args).toEqual([
      "-y",
      "-hide_banner",
      "-f",
      "dvdvideo",
      "-title",
      "4",
      "-i",
      "D:\\影片 甲\\VIDEO_TS",
      "-f",
      "dvdvideo",
      "-title",
      "4",
      "-i",
      "D:\\影片 甲\\VIDEO_TS",
      // Absolute-index maps honour the exact selected tracks (video 0, audio 2, subtitle 5).
      "-map",
      "0:0",
      "-map",
      "0:2",
      "-map",
      "1:5",
      "-map_chapters",
      "0",
      "-c",
      "copy",
      "-metadata:s:s:0",
      "title=未标注字幕轨 1",
      "D:\\输出 目录\\影片.DVD.Remux.mkv",
    ]);
    expect(args).not.toContain('"D:\\影片 甲\\VIDEO_TS"');
  });

  it("writes a readable Chinese title while preserving the subtitle language tag", () => {
    const args = buildDvdRemuxArgs({
      sourcePath: "D:\\DVD\\VIDEO_TS",
      titleNumber: 1,
      selectedVideoStreams: [0],
      selectedAudioStreams: [],
      selectedSubtitleStreams: [3, 4, 5, 6, 7, 8],
      selectedSubtitleMetadata: [
        { inputIndex: 3, language: "lat" },
        { inputIndex: 4, language: "ger" },
        { inputIndex: 5, language: "eng" },
        { inputIndex: 6, language: "fre" },
        { inputIndex: 7, language: "spa" },
        { inputIndex: 8, language: null },
      ],
      outputPath: "D:\\DVD\\movie.mkv",
    });
    expect(args).toEqual(
      expect.arrayContaining([
        "-f",
        "dvdvideo",
        "-title",
        "1",
        "-i",
        "D:\\DVD\\VIDEO_TS",
        "-map",
        "1:3",
        "-map",
        "1:4",
        "-map",
        "1:5",
        "-map",
        "1:6",
        "-map",
        "1:7",
        "-map",
        "1:8",
        "-metadata:s:s:0",
        "language=lat",
        "-metadata:s:s:0",
        "title=拉丁语字幕",
        "-metadata:s:s:1",
        "language=ger",
        "-metadata:s:s:1",
        "title=德语字幕",
        "-metadata:s:s:2",
        "language=eng",
        "-metadata:s:s:2",
        "title=英语字幕",
        "-metadata:s:s:3",
        "language=fre",
        "-metadata:s:s:3",
        "title=法语字幕",
        "-metadata:s:s:4",
        "language=spa",
        "-metadata:s:s:4",
        "title=西班牙语字幕",
        "-metadata:s:s:5",
        "title=未标注字幕轨 6",
      ]),
    );
  });

  it("does not add subtitle maps when no subtitle is selected", () => {
    const args = buildDvdRemuxArgs({
      sourcePath: "D:\\DVD\\VIDEO_TS",
      titleNumber: 9,
      selectedVideoStreams: [0],
      selectedAudioStreams: [3],
      selectedSubtitleStreams: [],
      outputPath: "D:\\DVD\\movie.mkv",
    });
    expect(args.filter((arg) => arg === "0:5")).toHaveLength(0);
    expect(args.filter((arg) => arg === "-f")).toHaveLength(1);
    expect(args.slice(args.indexOf("-map_chapters"))).toContain("copy");
    expect(args[args.indexOf("-title") + 1]).toBe("9");
  });

  it("converts selected pcm_dvd audio to MKV-compatible little-endian PCM only", () => {
    const args = buildDvdRemuxArgs({
      sourcePath: "D:\\DVD\\VIDEO_TS",
      titleNumber: 2,
      selectedVideoStreams: [0],
      selectedAudioStreams: [1, 2],
      selectedAudioCodecs: [
        { inputIndex: 1, codecName: "pcm_dvd", bitsPerRawSample: 16 },
        { inputIndex: 2, codecName: "ac3", bitsPerRawSample: null },
      ],
      selectedSubtitleStreams: [],
      outputPath: "D:\\DVD\\movie.mkv",
    });

    expect(args).toContain("-c");
    expect(args).toContain("copy");
    expect(args).toContain("-c:a:0");
    expect(args).toContain("pcm_s16le");
    expect(args).not.toContain("-c:a:1");
  });

  it("enables Remux when estimated size and MakeMKV are unavailable", () => {
    expect(
      canStartDvdRemux({
        validSource: true,
        selectedTitleNumber: 2,
        titleVerified: true,
        videoStreamCount: 1,
        outputPathValid: true,
        duplicateRunning: false,
        estimatedSize: null,
        makeMkvAvailable: false,
        selectedSubtitleStreams: [],
      }),
    ).toBe(true);
  });

  it("starts ffmpeg once, never invokes analyzers, and fails when exit 0 produced no valid MKV", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-dvd-remux-"));
    const outputPath = path.join(dir, "missing.mkv");
    const run = runnerReturning("");
    try {
      await expect(
        runDvdRemux({
          executable: "C:\\VX Tools\\ffmpeg.exe",
          sourcePath: "D:\\影片 甲\\VIDEO_TS",
          titleNumber: 4,
          selectedVideoStreams: [0],
          selectedAudioStreams: [2],
          selectedSubtitleStreams: [],
          outputPath,
          run,
        }),
      ).rejects.toThrow(/未生成有效 MKV/);
      expect(run).toHaveBeenCalledTimes(1);
      expect(run.mock.calls[0]?.[0].tool).toBe("ffmpeg");
    } finally {
      await fs.rm(dir, { recursive: true, force: true });
    }
  });

  it("accepts a real output only after the one ffmpeg invocation", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-dvd-remux-"));
    const outputPath = path.join(dir, "movie.mkv");
    const run = vi.fn(async (request) => {
      await fs.writeFile(
        outputPath,
        Buffer.concat([
          Buffer.from([0x1a, 0x45, 0xdf, 0xa3]),
          Buffer.alloc(4092),
        ]),
      );
      return {
        tool: request.tool,
        executable: request.executable,
        args: request.args,
        exitCode: 0,
        stdout: "",
        stderr: "",
        durationMs: 10,
        failureReason: null,
      };
    }) as ExternalToolRunner & ReturnType<typeof vi.fn>;
    try {
      const result = await runDvdRemux({
        executable: "ffmpeg.exe",
        sourcePath: "D:\\DVD\\VIDEO_TS",
        titleNumber: 4,
        selectedVideoStreams: [0],
        selectedAudioStreams: [2],
        selectedSubtitleStreams: [5],
        outputPath,
        run,
      });
      expect(run).toHaveBeenCalledTimes(1);
      expect(result.fileSize).toBe(4096);
    } finally {
      await fs.rm(dir, { recursive: true, force: true });
    }
  });

  it("rejects an exit-0 output that is not a Matroska file", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-dvd-remux-"));
    const outputPath = path.join(dir, "garbage.mkv");
    const run = vi.fn(async (request) => {
      await fs.writeFile(outputPath, Buffer.alloc(4096));
      return {
        tool: request.tool,
        executable: request.executable,
        args: request.args,
        exitCode: 0,
        stdout: "",
        stderr: "",
        durationMs: 10,
        failureReason: null,
      };
    }) as ExternalToolRunner;
    try {
      await expect(
        runDvdRemux({
          executable: "ffmpeg.exe",
          sourcePath: "D:\\DVD\\VIDEO_TS",
          titleNumber: 4,
          selectedVideoStreams: [0],
          selectedAudioStreams: [2],
          selectedSubtitleStreams: [],
          outputPath,
          run,
        }),
      ).rejects.toThrow(/有效 MKV/);
    } finally {
      await fs.rm(dir, { recursive: true, force: true });
    }
  });

  it("removes a valid-looking output when post-remux validation fails", async () => {
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-dvd-remux-"));
    const outputPath = path.join(dir, "invalid-content.mkv");
    const run = vi.fn(async (request) => {
      await fs.writeFile(
        outputPath,
        Buffer.concat([
          Buffer.from([0x1a, 0x45, 0xdf, 0xa3]),
          Buffer.alloc(4092),
        ]),
      );
      return {
        tool: request.tool,
        executable: request.executable,
        args: request.args,
        exitCode: 0,
        stdout: "",
        stderr: "",
        durationMs: 10,
        failureReason: null,
      };
    }) as ExternalToolRunner & ReturnType<typeof vi.fn>;
    try {
      await expect(
        runDvdRemux({
          executable: "ffmpeg.exe",
          sourcePath: "D:\\DVD\\VIDEO_TS",
          titleNumber: 4,
          selectedVideoStreams: [0],
          selectedAudioStreams: [2],
          selectedSubtitleStreams: [],
          outputPath,
          run,
          validateOutput: async () => {
            throw new Error("输出流轨验证未通过");
          },
        }),
      ).rejects.toThrow("输出流轨验证未通过");
      await expect(fs.stat(outputPath)).rejects.toMatchObject({
        code: "ENOENT",
      });
    } finally {
      await fs.rm(dir, { recursive: true, force: true });
    }
  });

  it("retries with prepared fallback args when primary output validation fails", async () => {
    const dir = await fs.mkdtemp(
      path.join(os.tmpdir(), "vx-dvd-remux-fallback-"),
    );
    const outputPath = path.join(dir, "fallback.mkv");
    let validationAttempts = 0;
    const run = vi.fn(async (request) => {
      await fs.writeFile(
        outputPath,
        Buffer.concat([
          Buffer.from([0x1a, 0x45, 0xdf, 0xa3]),
          Buffer.alloc(4092),
        ]),
      );
      return {
        tool: request.tool,
        executable: request.executable,
        args: request.args,
        exitCode: 0,
        stdout: "",
        stderr: "",
        durationMs: 10,
        failureReason: null,
      };
    }) as ExternalToolRunner & ReturnType<typeof vi.fn>;
    try {
      const result = await runDvdRemux({
        executable: "ffmpeg.exe",
        sourcePath: "D:\\DVD\\VIDEO_TS",
        titleNumber: 4,
        selectedVideoStreams: [0],
        selectedAudioStreams: [2],
        selectedSubtitleStreams: [],
        outputPath,
        run,
        args: ["-primary", outputPath],
        fallbackArgs: ["-fallback", outputPath],
        validateOutput: async () => {
          validationAttempts += 1;
          if (validationAttempts === 1) throw new Error("导航输出无效");
        },
      });
      expect(result.fileSize).toBe(4096);
      expect(run).toHaveBeenCalledTimes(2);
      expect(run.mock.calls[0]?.[0].args).toEqual(["-primary", outputPath]);
      expect(run.mock.calls[1]?.[0].args).toEqual(["-fallback", outputPath]);
    } finally {
      await fs.rm(dir, { recursive: true, force: true });
    }
  });

  it("requires dvdvideo plus libdvdnav and libdvdread in the project ffmpeg", async () => {
    const calls: string[][] = [];
    const run = vi.fn(async (request) => {
      calls.push(request.args);
      const joined = request.args.join(" ");
      if (joined.includes("-version"))
        return {
          tool: "ffmpeg" as const,
          executable: request.executable,
          args: request.args,
          exitCode: 0,
          stdout: "ffmpeg version N-123",
          stderr: "",
          durationMs: 1,
          failureReason: null,
        };
      if (joined.includes("-demuxers"))
        return {
          tool: "ffmpeg" as const,
          executable: request.executable,
          args: request.args,
          exitCode: 0,
          stdout: " D  dvdvideo DVD-Video",
          stderr: "",
          durationMs: 1,
          failureReason: null,
        };
      return {
        tool: "ffmpeg" as const,
        executable: request.executable,
        args: request.args,
        exitCode: 0,
        stdout: "--enable-libdvdnav --enable-libdvdread",
        stderr: "",
        durationMs: 1,
        failureReason: null,
      };
    }) as ExternalToolRunner;
    const result = await inspectFfmpegCapabilities(
      "C:\\VX Tools\\ffmpeg.exe",
      run,
    );
    expect(calls).toEqual([
      ["-hide_banner", "-version"],
      ["-hide_banner", "-demuxers"],
      ["-hide_banner", "-buildconf"],
    ]);
    expect(result).toMatchObject({
      dvdvideo: true,
      libdvdnav: true,
      libdvdread: true,
      supported: true,
    });
  });

  it("ships a Windows verifier that checks the managed build, output codecs, chapters, duration, size and MakeMKV absence", async () => {
    const script = await fs.readFile(
      path.join(projectRoot, "scripts/verify-dvd-remux.ps1"),
      "utf8",
    );
    expect(script).toContain('"-hide_banner", "-version"');
    expect(script).toContain('"-hide_banner", "-demuxers"');
    expect(script).toContain('"-hide_banner", "-buildconf"');
    expect(script).toContain("dvdvideo");
    expect(script).toContain("--enable-libdvdnav");
    expect(script).toContain("--enable-libdvdread");
    expect(script).toContain('Get-Process -Name "makemkvcon"');
    expect(script).not.toMatch(/&\s+makemkv/i);
    expect(script).toContain('"-map_chapters", "0", "-c", "copy"');
    expect(script).toContain("outputCodecs");
    expect(script).toContain("durationDrift");
    expect(script).toContain("allowedSmallTailSeconds");
    expect(script).toContain("minimumReasonableBytes");
  });
});
