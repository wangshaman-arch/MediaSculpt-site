# MediaSculpt（影刻）本地视频处理工具

> **Version:** V 0.860 · 版本：V 0.860
MediaSculpt is a Windows-first local desktop workbench for video compression, DVD/Blu-ray Remux, subtitle processing, speech recognition, and optional AI-assisted metadata and translation.

## Current release: V 0.860

- DVD Remux now accounts for physical `VIDEO_TS` capacity and prevents a multi-title selection from exceeding the source estimate.
- DVD navigation and VOB fallback cap output duration to the selected title and reject timestamp padding that runs past the source.
- The disc workbench keeps processing-mode selection explicit; compression, Remux, subtitle, and stream selections do not silently interfere.
- Long smart-analysis messages wrap and scroll inside their notice area instead of overflowing the native window.
- The Windows package is a native Tauri desktop installer. It does not require manually opening a browser.
- DVD stream selection now supports selecting or clearing all streams across the selected titles, while preserving mode-specific stream rules.

## Main capabilities

- Video compression through HandBrakeCLI with user-selected quality and audio settings.
- Lossless DVD/Blu-ray Remux to MKV with explicit title, stream, subtitle, and chapter selection.
- DVD smart analysis with real title reads, timestamp checks, physical capacity accounting, and conservative duplicate handling.
- Subtitle extraction, graphic-subtitle OCR, Whisper speech recognition, bilingual subtitle generation, and optional translation.
- Local tool management for FFmpeg/FFprobe, HandBrakeCLI, Whisper, OCR, and LibreTranslate.
- Local diagnostics for installation, startup, tools, previews, and processing jobs.

Video and media files are processed locally by default. If the user configures an online AI, translation, metadata, poster, or visual-OCR provider, only the data required by that provider is sent directly to it; MediaSculpt does not proxy user API keys.

## Windows V0.860 基础预览安装包

本版本的交付物是 **Windows 受限基础安装包**，不是源代码压缩包。普通用户直接运行生成的 `.exe` 安装器；源码包仅供开发、复现和问题定位使用。基础安装包包含原生桌面窗口、API sidecar、Node.js、FFmpeg/FFprobe 和 HandBrakeCLI，Whisper、OCR 和翻译工具按需安装。

Build the base installer from the repository root:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\build-tauri-base.ps1
```

The output is `release\MediaSculpt_0.860.0_x64-setup-base.exe` with a matching `.sha256` file. This is the Windows base installer for the limited preview edition, not a source archive. Whisper models and optional OCR/translation tools are installed on demand and are not bundled into the base package.

## Install and test

1. Run `MediaSculpt_0.860.0_x64-setup-base.exe`.
2. Launch MediaSculpt from its desktop or Start-menu shortcut.
3. Confirm input and output directories in Settings.
4. For a failed task, use the installed diagnostics entry and attach `mediasculpt-diagnostics.log`.

## Run from source

1. Install Node.js `22.20.0` or newer and pnpm `9` or newer.
2. Run `pnpm install` in the repository root.
3. Run `pnpm run typecheck` and `pnpm run test`.
4. Use `Start MediaSculpt.bat` or `scripts/start-dev.ps1` for the native development window.

## Documentation

- Release history: [`VERSION.md`](VERSION.md)
- Installation: [`INSTALL.md`](INSTALL.md)
- Windows testing: [`docs/windows-testing.md`](docs/windows-testing.md)
- Tools, caches, and uninstall: [`docs/windows-install-cache-uninstall-plan.md`](docs/windows-install-cache-uninstall-plan.md)
- Product rules: [`docs/product-rules.md`](docs/product-rules.md)
- Development quality gates: [`docs/development-quality-gates.md`](docs/development-quality-gates.md)
- Legal, copyright, and privacy: [`docs/legal-and-privacy.md`](docs/legal-and-privacy.md)
- Third-party licenses: [`THIRD-PARTY-NOTICES.md`](THIRD-PARTY-NOTICES.md)

---

# MediaSculpt（影刻）本地视频处理工具

V 0.860 是 Windows 受限基础安装包预览版，不是源代码压缩包。普通用户直接运行 `.exe` 安装器；源码包仅供开发、复现和问题定位。软件在本机完成视频压缩、DVD/蓝光 Remux、字幕处理、语音识别和可选的 AI 辅助工作流，不要求用户手动打开浏览器。

本版本重点修复了 DVD 全选 Remux 的物理容量核算、标题时长尾部溢出、智能解析长文本溢出，以及处理方式选择之间的相互干扰。DVD 输出会按所选标题和真实物理 VTS 容量校验；信息未知或预计达到源容量时，软件会阻止批量 Remux。

基础安装器命令：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\build-tauri-base.ps1
```

输出：`release\MediaSculpt_0.860.0_x64-setup-base.exe` 及对应的 SHA-256 校验文件。基础包包含原生窗口、本地 API、Node.js、FFmpeg/FFprobe 和 HandBrakeCLI；Whisper 模型、OCR 和本地翻译工具按需安装。

版权、第三方组件、隐私和网络边界请以 [`EULA.md`](EULA.md)、[`THIRD-PARTY-NOTICES.md`](THIRD-PARTY-NOTICES.md) 与 [`docs/legal-and-privacy.md`](docs/legal-and-privacy.md) 为准。
