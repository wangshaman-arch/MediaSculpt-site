import { spawn } from "node:child_process";
import { performance } from "node:perf_hooks";
import type {
  ManagedProcess,
  ProcessRequest,
  ProcessResult,
  ProcessRunner,
} from "./process-types";
import { terminateProcessTree } from "./process-termination";

export const DEFAULT_MAX_OUTPUT_BYTES = 1024 * 1024;

export class BoundedOutput {
  private buffer = Buffer.alloc(0);
  private truncated = false;

  constructor(private readonly maxBytes: number) {}

  append(chunk: Buffer | string): void {
    const next = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    if (next.length === 0) return;
    const combined = Buffer.concat([this.buffer, next]);
    if (combined.length > this.maxBytes) {
      this.buffer = combined.subarray(combined.length - this.maxBytes);
      this.truncated = true;
    } else {
      this.buffer = combined;
    }
  }

  toString(): string {
    const value = this.buffer.toString("utf8");
    return this.truncated
      ? `[output truncated; last ${this.maxBytes} bytes retained]\n${value}`
      : value;
  }
}

class ProcessAbortError extends Error {
  constructor() {
    super("The external process was aborted.");
    this.name = "AbortError";
  }
}

class ProcessTimeoutError extends Error {
  constructor(timeoutMs: number) {
    super(`The external process exceeded its ${timeoutMs}ms timeout.`);
    this.name = "TimeoutError";
  }
}

export class NodeProcessRunner implements ProcessRunner {
  run(request: ProcessRequest): Promise<ProcessResult> {
    return this.spawn(request).completed;
  }

  spawn(request: ProcessRequest): ManagedProcess {
    const startedAt = performance.now();
    const child = spawn(request.executable, request.args, {
      cwd: request.cwd,
      env: { ...process.env, ...request.env },
      windowsHide: true,
      stdio: ["pipe", "pipe", "pipe"],
    });

    let settled = false;
    let aborted = false;
    let timedOut = false;
    let timeoutHandle: NodeJS.Timeout | undefined;
    const maxOutputBytes =
      Number.isFinite(request.maxOutputBytes) &&
      (request.maxOutputBytes ?? 0) > 0
        ? Math.floor(request.maxOutputBytes as number)
        : DEFAULT_MAX_OUTPUT_BYTES;
    const stdout = new BoundedOutput(maxOutputBytes);
    const stderr = new BoundedOutput(maxOutputBytes);
    const abortError = new ProcessAbortError();
    let removeAbortListener: (() => void) | undefined;

    const completed = new Promise<ProcessResult>((resolve, reject) => {
      const finish = (callback: () => void) => {
        if (settled) return;
        settled = true;
        if (timeoutHandle) clearTimeout(timeoutHandle);
        removeAbortListener?.();
        callback();
      };

      child.stdout.on("data", (chunk: Buffer | string) => stdout.append(chunk));
      child.stderr.on("data", (chunk: Buffer | string) => stderr.append(chunk));
      child.once("error", (error) => finish(() => reject(error)));
      child.once("close", (code, signal) => {
        finish(() => {
          if (aborted) {
            reject(abortError);
            return;
          }
          if (timedOut) {
            reject(new ProcessTimeoutError(request.timeoutMs as number));
            return;
          }
          resolve({
            code,
            signal,
            stdout: stdout.toString(),
            stderr: stderr.toString(),
            durationMs: Math.max(0, Math.round(performance.now() - startedAt)),
          });
        });
      });

      if (request.signal) {
        const abort = () => {
          if (settled) return;
          aborted = true;
          terminateProcessTree(child);
        };
        request.signal.addEventListener("abort", abort, { once: true });
        removeAbortListener = () =>
          request.signal?.removeEventListener("abort", abort);
        if (request.signal.aborted) abort();
      }

      if (!request.signal?.aborted) {
        if (request.stdin !== undefined) child.stdin?.end(request.stdin);
        else child.stdin?.end();
      }
      const timeoutMs =
        Number.isFinite(request.timeoutMs) && (request.timeoutMs ?? 0) > 0
          ? Math.floor(request.timeoutMs as number)
          : null;
      if (timeoutMs !== null && !request.signal?.aborted) {
        timeoutHandle = setTimeout(() => {
          if (settled) return;
          timedOut = true;
          terminateProcessTree(child);
        }, timeoutMs);
      }
    });

    return {
      child,
      completed,
      kill: (signal) => {
        if (typeof child.pid !== "number" || child.killed) return false;
        terminateProcessTree(child, signal);
        return true;
      },
    };
  }
}

export const processRunner = new NodeProcessRunner();

export type {
  ManagedProcess,
  ProcessRequest,
  ProcessResult,
  ProcessRunner,
} from "./process-types";
