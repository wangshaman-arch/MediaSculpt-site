import { describe, expect, it } from "vitest";
import {
  dvdOutputBaseName,
  dvdSourceBaseName,
  dvdTitleSuffix,
} from "./dvd-source-identity";
import { buildRemuxOutputName } from "./output-naming";

describe("DVD source identity", () => {
  it("keeps Part 3 and year while removing the transport suffix", () => {
    expect(
      dvdSourceBaseName("H:\\11 Days 11 Nights Part 3 (1989) DVD\\VIDEO_TS"),
    ).toBe("11 Days 11 Nights Part 3 1989");
    expect(
      dvdSourceBaseName(
        "H:\\11 Days 11 Nights Part 3 (1989) DVD.Title01\\VIDEO_TS",
      ),
    ).toBe("11 Days 11 Nights Part 3 1989");
    expect(
      dvdSourceBaseName(
        "H:\\11 Days 11 Nights Part 3 (1989) DVD\\VIDEO_TS\\VTS_01_0.IFO",
      ),
    ).toBe("11 Days 11 Nights Part 3 1989");
  });

  it("removes a local-language alias after the release year", () => {
    expect(
      dvdSourceBaseName(
        "\\\\192.168.2.232\\Home2\\Les.choses.de.la.vie.1970.生活琐事\\VIDEO_TS",
      ),
    ).toBe("Les.choses.de.la.vie.1970");
  });

  it("does not expose an internal title number for a single usable title", () => {
    expect(
      dvdTitleSuffix({ mediaType: "dvd", titleNumber: 1, titleCount: 1 }),
    ).toBe("");
    expect(
      dvdOutputBaseName({
        sourcePath: "H:\\11 Days 11 Nights Part 3 (1989) DVD\\VIDEO_TS",
        mediaType: "dvd",
        titleNumber: 1,
        titleCount: 1,
      }),
    ).toBe("11 Days 11 Nights Part 3 1989");
    expect(
      buildRemuxOutputName(
        dvdOutputBaseName({
          sourcePath: "H:\\11 Days 11 Nights Part 3 (1989) DVD\\VIDEO_TS",
          mediaType: "dvd",
          titleNumber: 1,
          titleCount: 1,
        }),
        "dvd",
        "mkv",
      ),
    ).toBe("11.Days.11.Nights.Part.3.1989.DVD.Remux.mkv");
  });

  it("keeps a suffix only when multiple usable titles need disambiguation", () => {
    expect(
      dvdTitleSuffix({ mediaType: "dvd", titleNumber: 7, titleCount: 3 }),
    ).toBe(".Title07");
    expect(
      dvdOutputBaseName({
        sourcePath: "D:\\DVD-9\\VIDEO_TS",
        mediaType: "dvd",
        titleNumber: 7,
        titleCount: 3,
      }),
    ).toBe("DVD-9.Title07");
  });

  it("does not change Blu-ray naming", () => {
    expect(
      dvdOutputBaseName({
        sourcePath: "H:\\Concert\\BDMV",
        mediaType: "bluray",
        titleNumber: 3,
        titleCount: 4,
      }),
    ).toBe("Concert");
  });
});
