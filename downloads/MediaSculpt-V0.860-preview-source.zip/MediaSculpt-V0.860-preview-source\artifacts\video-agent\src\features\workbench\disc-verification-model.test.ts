import { describe, expect, it } from "vitest";
import type { DiscStream } from "@workspace/api-client-react";
import {
  discVerificationMessage,
  isDiscProcessingMappingBlocked,
} from "./disc-verification-model";
import type { DiscTrackWithMakeMkv } from "./disc-display-model";

const translate = (key: string) => key;

const stream = (overrides: Partial<DiscStream>): DiscStream => ({
  index: 0,
  codecType: "video",
  codecName: "h264",
  ...overrides,
});

const track = (
  overrides: Partial<DiscTrackWithMakeMkv> = {},
): DiscTrackWithMakeMkv => ({
  path: "D:/disc",
  name: "Title",
  sizeBytes: 1,
  streams: [stream({})],
  ...overrides,
});

describe("disc verification model", () => {
  it("reports verifying and failure states for DVD titles", () => {
    expect(
      discVerificationMessage(
        {
          track: track(),
          isVerifying: true,
          verifyDvdTitles: true,
          discType: "dvd",
          processingMode: "remux",
        },
        translate,
      ),
    ).toBe("scan.verifyingDiscTitle");
    expect(
      discVerificationMessage(
        {
          track: track({
            verificationStatus: "failed",
            verificationFailureReason: "dvdvideo broken",
          }),
          isVerifying: false,
          verifyDvdTitles: true,
          discType: "dvd",
          processingMode: "remux",
        },
        translate,
      ),
    ).toBe("scan.ffmpegDvdUnsupported");
    expect(
      discVerificationMessage(
        {
          track: track({
            verificationStatus: "verified",
            streams: [stream({ codecType: "audio", codecName: "aac" })],
          }),
          isVerifying: false,
          verifyDvdTitles: true,
          discType: "dvd",
          processingMode: "remux",
        },
        translate,
      ),
    ).toBe("scan.noVideoStream");
  });

  it("reports HandBrake title and Blu-ray mapping problems", () => {
    expect(
      discVerificationMessage(
        {
          track: track({ streams: [stream({})] }),
          isVerifying: false,
          verifyDvdTitles: false,
          discType: "dvd",
          processingMode: "compress",
        },
        translate,
      ),
    ).toBe("scan.handbrakeNoTitle");
    expect(
      discVerificationMessage(
        {
          track: track({ titleId: "playlist-1", playlistId: null }),
          isVerifying: false,
          verifyDvdTitles: false,
          discType: "bluray",
          processingMode: "remux",
        },
        translate,
      ),
    ).toBe("scan.makemkvUnavailable");
  });

  it("blocks mapping when a selected title cannot be mapped", () => {
    expect(
      isDiscProcessingMappingBlocked({
        processingMode: "remux",
        discType: "dvd",
        selectedIndexes: [0],
        getTrack: () => track({ verificationStatus: "failed" }),
      }),
    ).toBe(true);
    expect(
      isDiscProcessingMappingBlocked({
        processingMode: "remux",
        discType: "dvd",
        selectedIndexes: [0],
        getTrack: () =>
          track({ verificationStatus: "verified", dvdVtsNumber: 1 }),
      }),
    ).toBe(false);
    expect(
      isDiscProcessingMappingBlocked({
        processingMode: "none",
        discType: "dvd",
        selectedIndexes: [0],
        getTrack: () => undefined,
      }),
    ).toBe(false);
  });
});
