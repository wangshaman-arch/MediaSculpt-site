import { Router } from "express";
import os from "os";
import path from "path";
import fs from "fs/promises";
import type { ChildProcess } from "child_process";
import { db, jobsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { resolveToolPath } from "../lib/tool-runtime";
import { ffmpegPath } from "../lib/runtime-paths";
import { processRunner } from "../infrastructure/process-runner";
import { previewService } from "../media/preview-service";
import { readSubtitleText, toWebVtt } from "../media/subtitle-service";
import {
  resolveJobSubtitleDirectories,
  scanJobSubtitleFiles,
} from "./jobs-subtitle-files";

const router = Router();
router.get("/jobs/:id/download", async (req, res) => {
  const id = Number(req.params.id);
  const kind =
    req.query.kind === "subtitle"
      ? "subtitlePath"
      : req.query.kind === "translated"
        ? "translatedSubtitlePath"
        : "outputPath";
  const [job] = await db
    .select({
      outputPath: jobsTable.outputPath,
      subtitlePath: jobsTable.subtitlePath,
      translatedSubtitlePath: jobsTable.translatedSubtitlePath,
    })
    .from(jobsTable)
    .where(eq(jobsTable.id, id))
    .limit(1);
  const filePath = job?.[kind];
  if (!filePath) return res.status(404).json({ error: "文件尚未生成" });
  try {
    await fs.access(filePath);
    return res.download(filePath, path.basename(filePath));
  } catch {
    return res.status(404).json({ error: "文件不存在或无法读取" });
  }
});

router.get("/jobs/:id/subtitles", async (req, res) => {
  const id = Number(req.params.id);
  const [job] = await db
    .select({
      filePath: jobsTable.filePath,
      outputPath: jobsTable.outputPath,
      mainTrackPath: jobsTable.mainTrackPath,
      subtitlePath: jobsTable.subtitlePath,
      translatedSubtitlePath: jobsTable.translatedSubtitlePath,
    })
    .from(jobsTable)
    .where(eq(jobsTable.id, id))
    .limit(1);
  if (!job) return res.status(404).json({ error: "任务不存在" });
  const files = await scanJobSubtitleFiles(job);
  // Repair stale DB paths so downloads / later steps point at real files.
  const updates: Partial<typeof jobsTable.$inferInsert> = {};
  const original = files.find((file) => file.kind === "original");
  const translated = files.find((file) => file.kind === "translated");
  if (job.subtitlePath) {
    try {
      await fs.access(job.subtitlePath);
    } catch {
      if (original) updates.subtitlePath = original.path;
    }
  } else if (original) {
    updates.subtitlePath = original.path;
  }
  if (job.translatedSubtitlePath) {
    try {
      await fs.access(job.translatedSubtitlePath);
    } catch {
      if (translated) updates.translatedSubtitlePath = translated.path;
    }
  } else if (translated) {
    updates.translatedSubtitlePath = translated.path;
  }
  if (Object.keys(updates).length > 0) {
    await db
      .update(jobsTable)
      .set(updates)
      .where(eq(jobsTable.id, id))
      .catch(() => {});
  }
  return res.json({
    files,
    subtitlePath: updates.subtitlePath ?? job.subtitlePath,
    translatedSubtitlePath:
      updates.translatedSubtitlePath ?? job.translatedSubtitlePath,
  });
});

router.get("/jobs/:id/subtitle-preview", async (req, res) => {
  const id = Number(req.params.id);
  const fileQuery =
    typeof req.query.file === "string" && req.query.file
      ? req.query.file
      : null;
  if (fileQuery) {
    const [job] = await db
      .select({
        filePath: jobsTable.filePath,
        outputPath: jobsTable.outputPath,
        mainTrackPath: jobsTable.mainTrackPath,
        subtitlePath: jobsTable.subtitlePath,
        translatedSubtitlePath: jobsTable.translatedSubtitlePath,
      })
      .from(jobsTable)
      .where(eq(jobsTable.id, id))
      .limit(1);
    if (!job) return res.status(404).json({ error: "任务不存在" });
    if (path.basename(fileQuery) !== fileQuery || fileQuery.includes("..")) {
      return res.status(400).json({ error: "字幕文件名无效" });
    }
    const dirs = await resolveJobSubtitleDirectories(job);
    for (const dir of dirs) {
      const fullPath = path.join(dir, fileQuery);
      try {
        const stat = await fs.stat(fullPath);
        if (stat.isFile()) {
          const content = await readSubtitleText(fullPath);
          return res.type("text/plain; charset=utf-8").send(content);
        }
      } catch {
        // try next directory
      }
    }
    return res.status(404).json({ error: "字幕文件不存在或无法读取" });
  }
  const kind =
    req.query.kind === "translated" ? "translatedSubtitlePath" : "subtitlePath";
  const [job] = await db
    .select({
      subtitlePath: jobsTable.subtitlePath,
      translatedSubtitlePath: jobsTable.translatedSubtitlePath,
    })
    .from(jobsTable)
    .where(eq(jobsTable.id, id))
    .limit(1);
  const filePath = job?.[kind];
  if (filePath) {
    try {
      const content = await readSubtitleText(filePath);
      return res.type("text/plain; charset=utf-8").send(content);
    } catch {
      // stored path is stale; fall through to directory scan
    }
  }
  const [fullJob] = await db
    .select({
      filePath: jobsTable.filePath,
      outputPath: jobsTable.outputPath,
      mainTrackPath: jobsTable.mainTrackPath,
      subtitlePath: jobsTable.subtitlePath,
      translatedSubtitlePath: jobsTable.translatedSubtitlePath,
    })
    .from(jobsTable)
    .where(eq(jobsTable.id, id))
    .limit(1);
  if (fullJob) {
    const files = await scanJobSubtitleFiles(fullJob);
    const preferredKind =
      kind === "translatedSubtitlePath" ? "translated" : "original";
    const match = files.find((file) => file.kind === preferredKind) ?? files[0];
    if (match) {
      try {
        const content = await fs.readFile(match.path, "utf8");
        return res.type("text/plain; charset=utf-8").send(content);
      } catch {
        // fall through
      }
    }
  }
  return res.status(404).json({ error: "字幕尚未生成" });
});

router.get("/jobs/:id/subtitle-vtt", async (req, res) => {
  const id = Number(req.params.id);
  let embeddedStream =
    req.query.stream != null ? Number(req.query.stream) : null;
  // 未指定字幕轨时自动选用第一条内置文本字幕轨，保证前端叠加层总能拿到字幕。
  if (embeddedStream === null) {
    const [job] = await db
      .select({
        filePath: jobsTable.filePath,
        mainTrackPath: jobsTable.mainTrackPath,
        outputPath: jobsTable.outputPath,
      })
      .from(jobsTable)
      .where(eq(jobsTable.id, id))
      .limit(1);
    const sourceFile = job?.outputPath ?? job?.mainTrackPath ?? job?.filePath;
    if (sourceFile && !/[\\/]$/.test(sourceFile)) {
      const indices = await previewService.subtitleContainerIndices(sourceFile);
      if (indices.length > 0) embeddedStream = indices[0];
    }
  }
  if (embeddedStream !== null) {
    if (!Number.isInteger(embeddedStream) || embeddedStream < 0)
      return res.status(400).json({ error: "字幕轨参数无效" });
    const [job] = await db
      .select({
        filePath: jobsTable.filePath,
        mainTrackPath: jobsTable.mainTrackPath,
        outputPath: jobsTable.outputPath,
      })
      .from(jobsTable)
      .where(eq(jobsTable.id, id))
      .limit(1);
    const sourceFile = job?.outputPath ?? job?.mainTrackPath ?? job?.filePath;
    if (!sourceFile || /[\\/]$/.test(sourceFile))
      return res.status(404).json({ error: "没有可提取的内置字幕源" });
    const sourceFilePath: string = sourceFile;
    const cacheDir = path.join(os.tmpdir(), "MediaSculpt", "subtitle-preview");
    await fs.mkdir(cacheDir, { recursive: true });
    const cacheFile = path.join(
      cacheDir,
      `job-${id}-stream-${embeddedStream}.vtt`,
    );
    try {
      await fs.access(cacheFile);
      return res
        .type("text/vtt; charset=utf-8")
        .send(await fs.readFile(cacheFile, "utf8"));
    } catch {
      // cache miss
    }
    try {
      const ffmpegExecutable =
        (await resolveToolPath("ffmpeg").catch(() => null)) ?? "ffmpeg";
      await new Promise<void>((resolve, reject) => {
        const ff: ChildProcess = processRunner.spawn({
          executable: ffmpegExecutable,
          args: [
            "-y",
            "-i",
            ffmpegPath(sourceFilePath),
            "-map",
            `0:${embeddedStream}`,
            "-f",
            "webvtt",
            ffmpegPath(cacheFile),
          ],
          stage: "subtitle-preview",
          timeoutMs: 120_000,
        }).child;
        let stderr = "";
        ff.stderr?.on("data", (chunk: Buffer) => {
          if (stderr.length < 64_000) stderr += chunk.toString();
        });
        ff.on("close", (code) =>
          code === 0
            ? resolve()
            : reject(new Error(stderr.slice(-600) || `ffmpeg exit ${code}`)),
        );
        ff.on("error", reject);
      });
      return res
        .type("text/vtt; charset=utf-8")
        .send(await fs.readFile(cacheFile, "utf8"));
    } catch (error) {
      return res.status(500).json({
        error: `内置字幕轨无法转换为浏览器字幕：${error instanceof Error ? error.message : String(error)}`,
      });
    }
  }
  const kind =
    req.query.kind === "translated" ? "translatedSubtitlePath" : "subtitlePath";
  const [job] = await db
    .select({
      subtitlePath: jobsTable.subtitlePath,
      translatedSubtitlePath: jobsTable.translatedSubtitlePath,
    })
    .from(jobsTable)
    .where(eq(jobsTable.id, id))
    .limit(1);
  const filePath = job?.[kind];
  if (!filePath) return res.status(404).json({ error: "字幕尚未生成" });
  try {
    const content = await readSubtitleText(filePath);
    return res.type("text/vtt; charset=utf-8").send(toWebVtt(content));
  } catch {
    return res.status(404).json({ error: "字幕文件不存在或无法读取" });
  }
});
export const subtitlePreviewRouter = router;
