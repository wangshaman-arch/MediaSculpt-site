// Job API router entry point. It only composes the focused sub-routers; shared
// helpers live in their own modules under routes/ and lib/.
import { Router } from "express";
import { jobsOperationsRouter } from "./jobs-operations";
import { discRouter } from "./disc";
import { adminRouter } from "./admin";
import { jobsCrudRouter } from "./jobs-crud";
import { previewRouter } from "./jobs-preview";

const router = Router();

// Registration order is preserved from the pre-split file: the miscellaneous
// job endpoints are matched before the disc/admin/crud/preview sub-routers.
router.use(jobsOperationsRouter);
router.use(discRouter);
router.use(adminRouter);
router.use(jobsCrudRouter);
router.use(previewRouter);

export default router;
