import { afterEach, describe, expect, it, vi } from "vitest";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import type { Server } from "node:http";
import type { DiscAnalysisResult } from "../lib/disc-analysis";

function fixture(sourcePath: string): DiscAnalysisResult {
  return {
    analysisId: "disc-route-a1",
    sourcePath,
    sourceFingerprint: "route-fingerprint",
    mediaType: "dvd",
    createdAt: "2026-08-02T00:00:00.000Z",
    diagnosticLogPath: null,
    diagnostics: [],
    warnings: [],
    exportCandidates: [],
    titles: [
      {
        titleId: "handbrake:2",
        titleIndex: 0,
        sourcePath,
        displayName: "Title 2",
        durationSeconds: 600,
        chapterCount: 1,
        chapters: [{ id: 0, startSeconds: 0, endSeconds: 600, title: null }],
        estimatedSize: 1000,
        streams: [
          {
            index: 0,
            codecType: "video",
            codecName: "mpeg2video",
            language: null,
            title: null,
            handbrakeTrackNumber: 1,
          },
          {
            index: 1,
            codecType: "audio",
            codecName: "ac3",
            language: "zh",
            title: null,
            handbrakeTrackNumber: 1,
          },
        ],
        videoTracks: [
          {
            index: 0,
            codecType: "video",
            codecName: "mpeg2video",
            language: null,
            title: null,
            handbrakeTrackNumber: 1,
          },
        ],
        audioTracks: [
          {
            index: 1,
            codecType: "audio",
            codecName: "ac3",
            language: "zh",
            title: null,
            handbrakeTrackNumber: 1,
          },
        ],
        subtitleTracks: [],
        toolMappings: {
          handbrakeTitleNumber: 2,
          makemkvTitleIndex: null,
          dvdVtsNumber: 1,
          physicalVtsNumber: 1,
        },
        mappingStatus: "not-required",
      },
    ],
  };
}

describe("POST /jobs immutable task snapshot boundary", () => {
  let tempDirectory: string | undefined;
  let server: Server | undefined;
  let previousDatabasePath: string | undefined;
  let previousDatabaseDriver: string | undefined;
  let previousDiagnosticsLog: string | undefined;

  afterEach(async () => {
    if (server)
      await new Promise<void>((resolve, reject) =>
        server!.close((error) => (error ? reject(error) : resolve())),
      );
    server = undefined;
    if (previousDatabasePath === undefined)
      delete process.env.VX_AGENT_DATABASE_PATH;
    else process.env.VX_AGENT_DATABASE_PATH = previousDatabasePath;
    if (previousDatabaseDriver === undefined)
      delete process.env.DATABASE_DRIVER;
    else process.env.DATABASE_DRIVER = previousDatabaseDriver;
    if (previousDiagnosticsLog === undefined)
      delete process.env.VX_AGENT_DIAGNOSTICS_LOG;
    else process.env.VX_AGENT_DIAGNOSTICS_LOG = previousDiagnosticsLog;
    vi.resetModules();
    if (tempDirectory) {
      // Windows can hold the SQLite file handles until GC after the server
      // closes; retry for a few seconds and tolerate a leftover temp folder
      // (it lives under the OS temp directory) instead of flaking on EBUSY.
      for (let attempt = 0; attempt < 20; attempt += 1) {
        try {
          await fs.rm(tempDirectory, { recursive: true, force: true });
          break;
        } catch {
          await new Promise((resolve) => setTimeout(resolve, 250));
        }
      }
    }
    tempDirectory = undefined;
  });

  it("persists the selected analysis title snapshot instead of accepting an unstated default title", async () => {
    tempDirectory = await fs.mkdtemp(
      path.join(os.tmpdir(), "vx-jobs-snapshot-route-"),
    );
    const sourcePath = path.join(tempDirectory, "Movie");
    const videoTsPath = path.join(sourcePath, "VIDEO_TS");
    await fs.mkdir(videoTsPath, { recursive: true });
    await fs.writeFile(path.join(videoTsPath, "VIDEO_TS.IFO"), "dvd");
    previousDatabasePath = process.env.VX_AGENT_DATABASE_PATH;
    previousDatabaseDriver = process.env.DATABASE_DRIVER;
    previousDiagnosticsLog = process.env.VX_AGENT_DIAGNOSTICS_LOG;
    process.env.VX_AGENT_DATABASE_PATH = path.join(
      tempDirectory,
      "vx-agent.db",
    );
    process.env.DATABASE_DRIVER = "sqlite";
    process.env.VX_AGENT_DIAGNOSTICS_LOG = path.join(
      tempDirectory,
      "diagnostics.log",
    );
    vi.resetModules();

    const { registerDiscAnalysisForTaskCreation } =
      await import("../lib/disc-analysis-registry");
    registerDiscAnalysisForTaskCreation(fixture(videoTsPath));
    const { default: app } = await import("../app");
    server = app.listen(0);
    await new Promise<void>((resolve) => server!.once("listening", resolve));
    const port = (server.address() as { port: number }).port;

    const response = await fetch(`http://127.0.0.1:${port}/api/jobs`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        filePath: sourcePath,
        mediaType: "dvd",
        processingMode: "compress",
        subtitleMode: "skip",
        analysisId: "disc-route-a1",
        sourceFingerprint: "route-fingerprint",
        selectedTitleId: "handbrake:2",
        outputMode: "compress",
        selectedStreams: "[0,1]",
        selectedChapters: "[0]",
        compressionSettings: {
          encoder: "x264_10bit",
          crf: 19,
          encoderPreset: "slow",
          encoderTune: "grain",
          encoderProfile: "high10",
          encoderLevel: "3.1",
          frameRate: "same",
          outputResolution: "source",
        },
      }),
    });
    const responseText = await response.text();
    expect(response.headers.get("content-type"), responseText).toContain(
      "application/json",
    );
    const body = JSON.parse(responseText) as {
      taskSnapshot?: string;
      taskSnapshotVersion?: number;
      legacyTask?: boolean;
      snapshot?: { selectedTitleId?: string; handbrakeTitleNumber?: number };
    };

    expect(response.status).toBe(201);
    expect(body).toMatchObject({
      taskSnapshotVersion: 1,
      legacyTask: false,
      snapshot: { selectedTitleId: "handbrake:2", handbrakeTitleNumber: 2 },
    });
    expect(JSON.parse(body.taskSnapshot ?? "{}")).toMatchObject({
      selectedTitleId: "handbrake:2",
      toolSelections: { handbrakeTitleNumber: 2, physicalVtsNumber: 1 },
      compression: {
        encoder: "x264_10bit",
        crf: 19,
        encoderTune: "grain",
        encoderProfile: "high10",
        encoderLevel: "3.1",
      },
    });
  }, 30_000);
});

describe("PATCH /jobs/:id/execution applies assistant-confirmed options", () => {
  let tempDirectory: string | undefined;
  let server: Server | undefined;
  let previousDatabasePath: string | undefined;
  let previousDatabaseDriver: string | undefined;
  let previousDiagnosticsLog: string | undefined;

  afterEach(async () => {
    if (server)
      await new Promise<void>((resolve, reject) =>
        server!.close((error) => (error ? reject(error) : resolve())),
      );
    server = undefined;
    if (previousDatabasePath === undefined)
      delete process.env.VX_AGENT_DATABASE_PATH;
    else process.env.VX_AGENT_DATABASE_PATH = previousDatabasePath;
    if (previousDatabaseDriver === undefined)
      delete process.env.DATABASE_DRIVER;
    else process.env.DATABASE_DRIVER = previousDatabaseDriver;
    if (previousDiagnosticsLog === undefined)
      delete process.env.VX_AGENT_DIAGNOSTICS_LOG;
    else process.env.VX_AGENT_DIAGNOSTICS_LOG = previousDiagnosticsLog;
    vi.resetModules();
    if (tempDirectory) {
      for (let attempt = 0; attempt < 20; attempt += 1) {
        try {
          await fs.rm(tempDirectory, { recursive: true, force: true });
          break;
        } catch {
          await new Promise((resolve) => setTimeout(resolve, 250));
        }
      }
    }
    tempDirectory = undefined;
  });

  async function setupJob(): Promise<{
    jobId: number;
    sourcePath: string;
    videoTsPath: string;
    port: number;
  }> {
    tempDirectory = await fs.mkdtemp(
      path.join(os.tmpdir(), "vx-jobs-execution-route-"),
    );
    const sourcePath = path.join(tempDirectory, "Movie");
    const videoTsPath = path.join(sourcePath, "VIDEO_TS");
    await fs.mkdir(videoTsPath, { recursive: true });
    await fs.writeFile(path.join(videoTsPath, "VIDEO_TS.IFO"), "dvd");
    previousDatabasePath = process.env.VX_AGENT_DATABASE_PATH;
    previousDatabaseDriver = process.env.DATABASE_DRIVER;
    previousDiagnosticsLog = process.env.VX_AGENT_DIAGNOSTICS_LOG;
    process.env.VX_AGENT_DATABASE_PATH = path.join(
      tempDirectory,
      "vx-agent.db",
    );
    process.env.DATABASE_DRIVER = "sqlite";
    process.env.VX_AGENT_DIAGNOSTICS_LOG = path.join(
      tempDirectory,
      "diagnostics.log",
    );
    vi.resetModules();

    const { registerDiscAnalysisForTaskCreation } =
      await import("../lib/disc-analysis-registry");
    registerDiscAnalysisForTaskCreation(fixture(videoTsPath));
    const { default: app } = await import("../app");
    server = app.listen(0);
    await new Promise<void>((resolve) => server!.once("listening", resolve));
    const port = (server.address() as { port: number }).port;

    const created = await fetch(`http://127.0.0.1:${port}/api/jobs`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        filePath: sourcePath,
        mediaType: "dvd",
        processingMode: "compress",
        subtitleMode: "skip",
        analysisId: "disc-route-a1",
        sourceFingerprint: "route-fingerprint",
        selectedTitleId: "handbrake:2",
        outputMode: "compress",
        selectedStreams: "[0,1]",
        selectedChapters: "[0]",
      }),
    });
    expect(created.status).toBe(201);
    const createdBody = (await created.json()) as { id: number };
    return { jobId: createdBody.id, sourcePath, videoTsPath, port };
  }

  it("updates a pending job's pipeline and task snapshot in place", async () => {
    const { jobId, port } = await setupJob();

    const response = await fetch(
      `http://127.0.0.1:${port}/api/jobs/${jobId}/execution`,
      {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          pipelineSteps: ["remux"],
          subtitleMode: "skip",
        }),
      },
    );
    expect(response.status).toBe(200);
    const body = (await response.json()) as {
      recreated?: boolean;
      job?: {
        status?: string;
        processingMode?: string;
        pipelineSteps?: string | null;
        taskSnapshot?: string | null;
        movieYear?: number | null;
      };
    };
    expect(body.recreated).toBe(false);
    expect(body.job?.status).toBe("pending");
    expect(body.job?.processingMode).toBe("remux");
    expect(JSON.parse(body.job?.pipelineSteps ?? "{}")).toMatchObject({
      steps: ["remux"],
    });
    expect(JSON.parse(body.job?.taskSnapshot ?? "{}")).toMatchObject({
      outputMode: "remux",
    });
  }, 30_000);

  it("updates frozen compression settings when a queued job changes preset", async () => {
    const { jobId, port } = await setupJob();

    const response = await fetch(
      `http://127.0.0.1:${port}/api/jobs/${jobId}/execution`,
      {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          presetId: "dvd-convert",
          compressionSettings: {
            encoder: "x264_10bit",
            crf: 19,
            encoderPreset: "slow",
            encoderTune: "grain",
            encoderProfile: "high10",
            encoderLevel: "3.1",
            frameRate: "same",
            outputResolution: "source",
          },
        }),
      },
    );
    expect(response.status).toBe(200);
    const body = (await response.json()) as {
      job?: { taskSnapshot?: string | null; status?: string };
    };
    expect(body.job?.status).toBe("pending");
    expect(JSON.parse(body.job?.taskSnapshot ?? "{}")).toMatchObject({
      compression: {
        encoder: "x264_10bit",
        crf: 19,
        encoderTune: "grain",
        encoderProfile: "high10",
        encoderLevel: "3.1",
      },
    });
  }, 30_000);

  it("clones a completed job with the new options and keeps the original done", async () => {
    const { jobId, port } = await setupJob();

    const { db, jobsTable } = await import("@workspace/db");
    const { eq } = await import("drizzle-orm");
    await db
      .update(jobsTable)
      .set({ status: "done", completedAt: new Date() })
      .where(eq(jobsTable.id, jobId));

    const response = await fetch(
      `http://127.0.0.1:${port}/api/jobs/${jobId}/execution`,
      {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          pipelineSteps: ["remux"],
          subtitleMode: "skip",
          movieTitle: "确认片名",
        }),
      },
    );
    expect(response.status).toBe(201);
    const body = (await response.json()) as {
      id?: number;
      recreated?: boolean;
      job?: {
        status?: string;
        processingMode?: string;
        movieTitle?: string | null;
      };
    };
    expect(body.recreated).toBe(true);
    expect(typeof body.id).toBe("number");
    expect(body.id).not.toBe(jobId);
    expect(body.job?.status).toBe("pending");
    expect(body.job?.processingMode).toBe("remux");
    expect(body.job?.movieTitle).toBe("确认片名");

    const cloned = await fetch(`http://127.0.0.1:${port}/api/jobs/${body.id}`);
    const clonedBody = (await cloned.json()) as {
      status?: string;
      processingMode?: string;
      pipelineSteps?: string | null;
    };
    expect(clonedBody.status).toBe("pending");
    expect(clonedBody.processingMode).toBe("remux");
    expect(JSON.parse(clonedBody.pipelineSteps ?? "{}")).toMatchObject({
      steps: ["remux"],
    });

    const original = await fetch(`http://127.0.0.1:${port}/api/jobs/${jobId}`);
    const originalBody = (await original.json()) as { status?: string };
    expect(originalBody.status).toBe("done");
  }, 30_000);

  it("does not clone a completed job when only metadata changed", async () => {
    const { jobId, port } = await setupJob();

    const { db, jobsTable } = await import("@workspace/db");
    const { eq } = await import("drizzle-orm");
    await db
      .update(jobsTable)
      .set({ status: "done", completedAt: new Date() })
      .where(eq(jobsTable.id, jobId));

    const response = await fetch(
      `http://127.0.0.1:${port}/api/jobs/${jobId}/execution`,
      {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ movieTitle: "仅改片名" }),
      },
    );
    expect(response.status).toBe(200);
    const body = (await response.json()) as {
      recreated?: boolean;
      job?: { movieTitle?: string | null; status?: string };
    };
    expect(body.recreated).toBe(false);
    expect(body.job?.movieTitle).toBe("仅改片名");
    expect(body.job?.status).toBe("done");
  }, 30_000);
});
