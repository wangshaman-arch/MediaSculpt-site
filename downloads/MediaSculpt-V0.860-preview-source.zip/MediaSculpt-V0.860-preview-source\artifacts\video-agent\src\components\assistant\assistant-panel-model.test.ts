import { describe, expect, it } from "vitest";
import {
  folderChineseTitleForSource,
  formatDuration,
  sourceDisplayName,
  splitSourceName,
} from "./assistant-panel-model";

describe("assistant panel model helpers", () => {
  it("derives the source display name from disc structures and video files", () => {
    expect(sourceDisplayName("H:/Movies/Example DVD/VIDEO_TS")).toBe(
      "Example DVD",
    );
    expect(sourceDisplayName("H:/Movies/Example.2020.mkv")).toBe(
      "Example.2020",
    );
    expect(sourceDisplayName("H:/Movies/Example.2020")).toBe("Example.2020");
  });

  it("splits a release name into foreign title, Chinese title and year", () => {
    expect(splitSourceName("Prisoners.of.Terpsichore.1995.特彼斯霍瑞")).toEqual(
      {
        titleEn: "Prisoners.of.Terpsichore",
        titleZh: "特彼斯霍瑞",
        year: 1995,
      },
    );
  });

  it("uses the folder Chinese segment when it matches the video file name", () => {
    expect(
      folderChineseTitleForSource(
        "H:/Movies/Serenade.of.Darkness.造就亚瑟王/Serenade.of.Darkness.2010.mkv",
      ),
    ).toBe("造就亚瑟王");
  });

  it("formats durations as h:mm:ss", () => {
    expect(formatDuration(0)).toBe("0:00:00");
    expect(formatDuration(3725)).toBe("1:02:05");
  });
});
