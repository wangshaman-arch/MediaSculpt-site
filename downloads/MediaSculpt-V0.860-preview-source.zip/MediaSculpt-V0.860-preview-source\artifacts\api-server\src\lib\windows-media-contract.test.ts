import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";
import {
  enPack,
  projectRoot,
  readProjectFile,
  zhPack,
} from "./windows-contract-helpers";

describe("Windows contract", () => {
  it("keeps API runtime and job diagnostics in service logs that can be merged into the unified diagnostics view", () => {
    const services = readProjectFile("windows-setup/start-services.ps1");
    const diagnostics = readProjectFile(
      "windows-setup/start-with-diagnostics.ps1",
    );

    expect(services).toContain("VX_AGENT_RUNTIME_TOOLS_LOG_PATH");
    expect(services).toContain("VX_AGENT_JOB_LOG_PATH");
    expect(services).toContain(
      'set "VX_AGENT_RUNTIME_TOOLS_LOG_PATH=$toolEventsLog"',
    );
    expect(services).toContain('set "VX_AGENT_JOB_LOG_PATH=$jobEventsLog"');
    expect(diagnostics).toContain("mediasculpt-diagnostics.log");
  });

  it("exposes one unified diagnostics log for user-uploaded diagnostics", () => {
    const runtimeRoute = readProjectFile(
      "artifacts/api-server/src/routes/runtime.ts",
    );
    const settingsPage = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );
    const installerWrapper = readProjectFile(
      "windows-setup/install-with-diagnostics.ps1",
    );
    const startupWrapper = readProjectFile(
      "windows-setup/start-with-diagnostics.ps1",
    );
    const chineseDiagnostics = readProjectFile(
      "windows-setup/收集影刻诊断信息.bat",
    );

    expect(runtimeRoute).toContain("diagnosticsLogPath");
    expect(runtimeRoute).toContain("logRuntimeTool");
    expect(settingsPage + zhPack()).toContain("统一诊断日志");
    expect(settingsPage).toContain("toolLogPath");
    expect(installerWrapper).toContain("mediasculpt-diagnostics.log");
    expect(startupWrapper).toContain("mediasculpt-diagnostics.log");
    expect(chineseDiagnostics).toContain("mediasculpt-diagnostics.log");
    expect(chineseDiagnostics).toContain("collect-diagnostics.ps1");
    expect(installerWrapper).not.toContain("install-output.log");
    expect(startupWrapper).not.toContain("startup-diagnostics.log");
    expect(startupWrapper).not.toContain("api.log");
    expect(startupWrapper).not.toContain("runtime-tools.log");
  });

  it("collects a deterministic inventory instead of silently omitting missing runtime logs", () => {
    const collector = readProjectFile("windows-setup/collect-diagnostics.ps1");
    expect(collector).toContain("RUNTIME LOG INVENTORY");
    expect(collector).toContain("COLLECTION COMPLETED");
    expect(collector).toContain("job-events.tmp.log");
    expect(collector).toContain("HandBrakeCLI");
  });

  it("exposes package version information inside the app UI", () => {
    const runtimeRoute = readProjectFile(
      "artifacts/api-server/src/routes/runtime.ts",
    );
    const app = readProjectFile("artifacts/video-agent/src/App.tsx");
    const logs = readProjectFile("artifacts/video-agent/src/pages/Logs.tsx");

    expect(runtimeRoute).toContain('router.get("/runtime/version"');
    expect(runtimeRoute).toContain("release-id.txt");
    expect(runtimeRoute).toContain("VX_AGENT_GITHUB_BRANCH");
    expect(runtimeRoute).toContain("VX_AGENT_GITHUB_COMMIT");
    expect(app).toContain("useAppVersion");
    expect(app).not.toContain("GitHub 分支");
    expect(app).not.toContain("提交号");
    expect(logs + zhPack()).toContain("软件版本");
    expect(logs).not.toContain("GitHub 分支");
    expect(logs).not.toContain("提交号");
  });

  it("keeps generated logs, old archives, and pasted test assets out of the source package", () => {
    const generatedResidues = [
      "diagnostics.txt",
      "install-output.log",
      "runtime-tools.log",
      "job-runtime.log",
      "startup-diagnostics.log",
      "vx-agent.zip",
      "vx-agent.tar.gz",
      "vx-agent-source.zip",
      "vx-agent-patch.zip",
      "vx-agent-patch.tar.gz",
      "vx-agent-latest.tar.gz",
      "vx-agent-20260611b.tar.gz",
      "attached_assets",
    ];

    for (const residue of generatedResidues) {
      expect(fs.existsSync(path.join(projectRoot, residue)), residue).toBe(
        false,
      );
    }
  });

  it("keeps tool installation controls independent per tool", () => {
    const settingsPage = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );

    expect(settingsPage).toContain("busyTools");
    expect(settingsPage).toContain("isToolBusy");
    expect(settingsPage + zhPack()).toContain("正在处理");
    expect(settingsPage).toContain("tool.version &&");
    expect(settingsPage).toContain("tool.path");
    expect(settingsPage).not.toContain(
      "disabled={busy !== null || !tool.sources.length}",
    );
    expect(settingsPage).not.toContain("disabled={busy !== null}");
  });

  it("starts the API and web services in parallel and lets the UI load before tool checks", () => {
    const services = readProjectFile("windows-setup/start-services.ps1");
    expect(
      services.indexOf("$webProc = New-HiddenBatchProcess -BatchPath $webBat"),
    ).toBeGreaterThan(
      services.indexOf("$apiProc = New-HiddenBatchProcess -BatchPath $apiBat"),
    );
    expect(services.indexOf("Waiting for API to initialize")).toBeGreaterThan(
      services.indexOf("$webProc = New-HiddenBatchProcess -BatchPath $webBat"),
    );
    expect(
      services.indexOf("Opening the local UI in the default browser"),
    ).toBeGreaterThan(services.indexOf("Waiting for web frontend"));
  });

  it("collapses recent network locations and uses the settings strip as the back target", () => {
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    const settings = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );
    expect(scan).toContain("recentLocationsOpen");
    expect(scan + zhPack()).toContain("最近使用");
    expect(scan).toContain("max-w-full truncate");
    expect(settings + zhPack()).toContain("工具状态与安装");
    expect(settings).not.toContain('data-testid="settings-back-overview"');
  });

  it("does not ship obsolete duplicate Windows batch entrypoints", () => {
    const obsoleteEntrypoints = [
      "windows-setup/collect-diagnostics.cmd",
      "windows-setup/diagnose-install.cmd",
      "windows-setup/一键诊断安装.bat",
      "windows-setup/启动VX-Agent.bat",
    ];

    for (const entrypoint of obsoleteEntrypoints) {
      expect(
        fs.existsSync(path.join(projectRoot, entrypoint)),
        entrypoint,
      ).toBe(false);
    }
  });

  it("labels remux progress as packaging instead of compression in the UI", () => {
    const badge = readProjectFile(
      "artifacts/video-agent/src/components/JobStatusBadge.tsx",
    );
    const dashboard = readProjectFile(
      "artifacts/video-agent/src/pages/Dashboard.tsx",
    );
    const jobs = readProjectFile("artifacts/video-agent/src/pages/Jobs.tsx");
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );

    expect(badge).toContain("processingMode?: string | null");
    expect(badge).toContain('processingMode === "remux"');
    expect(badge + zhPack()).toContain("封装中");
    expect(dashboard).toContain("<Jobs embedded />");
    expect(jobs).toContain("processingMode={job.processingMode}");
    expect(detail).toContain("processingMode={job.processingMode}");
  });

  it("uses SQLite-safe stats aggregation without PostgreSQL-only syntax", () => {
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");

    expect(jobsRoute).toContain(".select({");
    expect(jobsRoute).toContain("totalSavedBytes");
    expect(jobsRoute).not.toContain("count(*)::int");
    expect(jobsRoute).not.toContain("filter (where");
    expect(jobsRoute).not.toContain("::float");
  });

  it("keeps the legacy MakeMKV executor only for Blu-ray and ISO Remux", () => {
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");
    const discAnalysis = readProjectFile(
      "artifacts/api-server/src/lib/disc-analysis.ts",
    );

    expect(jobsRoute).not.toContain("scanMakeMkvTitles");
    expect(jobsRoute).not.toContain("exportMakeMkvTitle");
    expect(jobsRoute).toMatch(
      /const isDiscRemux\s*=\s*job\.mediaType === "bluray"\s*\|\|\s*job\.mediaType === "iso"\s*\|\|\s*isMplsInput/,
    );
    expect(jobsRoute).toContain("scanBlurayPlaylists");
    expect(jobsRoute).toContain("parseBlurayMpls");
    expect(jobsRoute).toContain("runFfmpegCapture");
    expect(discAnalysis).toContain("scanBlurayPlaylists");
    expect(discAnalysis).toContain("probeBlurayTitleStreams");
    expect(discAnalysis).not.toContain('from "./makemkv"');
  });

  it("routes verified DVD Remux through FFmpeg dvdvideo before the legacy MakeMKV branch", () => {
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");
    const discAnalysis = readProjectFile(
      "artifacts/api-server/src/lib/disc-analysis.ts",
    );
    const scanPage = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );

    expect(jobsRoute).toContain('job.mediaType === "dvd"');
    expect(jobsRoute).toContain('job.processingMode === "remux"');
    expect(jobsRoute.indexOf("processVerifiedDvdRemuxJob")).toBeLessThan(
      jobsRoute.indexOf("playlistDuration"),
    );
    expect(jobsRoute).toContain("runDvdRemux");
    expect(jobsRoute).toContain("snapshot.toolSelections.dvdVtsNumber");
    // The DVD/Blu-ray analyzers were split into disc-analysis-dvd.ts and
    // disc-analysis-bluray.ts; the entry point still dispatches on mediaType.
    expect(discAnalysis).toContain('input.mediaType === "dvd"');
    expect(discAnalysis).toContain("analyzeDvdWithHandBrake");
    expect(scanPage).toContain('fetch("/api/disc/verify-title"');
    expect(scanPage).toContain('data.discType === "dvd"');
  });

  it("defaults DVD and Blu-ray stream choices to all parsed streams and chapters", () => {
    const scanPage = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );
    const discDialog = readProjectFile(
      "artifacts/video-agent/src/features/workbench/DiscAnalyzeDialog.tsx",
    );
    expect(discDialog).toContain("defaultStreamSelection");
    expect(discDialog).toContain("defaultChapterSelection");
    expect(discDialog).toContain("track?.streams");
    expect(discDialog).toContain("track?.chapters");
    expect(discDialog).toContain("setSelectedTrackIndices(new Set());");
    expect(scanPage).toContain("DiscAnalyzeDialog");
    expect(scanPage + zhPack()).toContain("正在读取准确的音视频与字幕流轨");
    expect(scanPage + zhPack()).toContain("重新验证");
    expect(scanPage).not.toContain(
      "当前标题没有可靠的工具标题映射，已阻止创建任务，避免错误处理其他标题。",
    );
    expect(scanPage + zhPack()).toContain(
      "HandBrake未返回该标题的有效编号，暂时无法创建压缩任务",
    );
  });

  it("exposes an independent Remux directory setting and keeps it out of compression/subtitle directories", () => {
    const settings = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );
    const schema = readProjectFile("lib/db/src/schema/config.ts");
    const sqliteSchema = readProjectFile("lib/db/src/sqlite-schema.ts");
    const snapshot = readProjectFile(
      "artifacts/api-server/src/lib/task-snapshot.ts",
    );
    const jobs =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");
    expect(settings).toContain("remuxOutputDirectory");
    expect(settings + zhPack()).toContain("Remux无损封装导出目录");
    expect(settings + zhPack()).toContain("恢复默认");
    expect(schema).toContain("remuxOutputDirectory");
    expect(sqliteSchema).toContain("remuxOutputDirectory");
    expect(snapshot).toContain("remuxOutputDirectory");
    expect(jobs).toContain("snapshot.output.directory");
    expect(jobs + zhPack()).toContain("验证 Remux 输出目录");
    expect(jobs).not.toContain(
      'if (job.processingMode === "remux") return defaultRemuxOutputDirectory(job.filePath, job.mediaType);',
    );
  });

  it("uses precise DVD/MakeMKV error messages and records validation cache hits", () => {
    const scanPage = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );
    const jobs =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");
    expect(scanPage + zhPack()).toContain("正在验证所选DVD标题，请稍候");
    expect(scanPage + zhPack()).toContain("所选DVD标题没有可处理的视频流");
    expect(scanPage + zhPack()).toContain(
      "当前FFmpeg不支持DVD标题读取，请修复FFmpeg工具",
    );
    expect(scanPage + zhPack()).toContain("未找到蓝光播放列表（.mpls）");
    expect(jobs).toContain("analysisId + titleId + sourceFingerprint");
    expect(jobs + zhPack()).toContain("标题验证缓存命中");
  });

  it("initializes the installer download source before StrictMode validation", () => {
    const installer = readProjectFile("windows-setup/install.ps1");
    expect(installer).toContain("Set-StrictMode -Version Latest");
    expect(installer).toContain("$script:lastDownloadSource = $null");
  });

  it("keeps the disc preview from polling the whole job queue or rerunning stale verification", () => {
    const scanPage = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );
    expect(scanPage).toContain("refetchInterval: false");
    expect(scanPage).toContain("refetchOnWindowFocus: false");
    expect(scanPage).toContain("staleTime: 30_000");
    expect(scanPage).toContain("new AbortController()");
    expect(scanPage).toContain("activeTrackRef.current !== trackIdx");
    expect(scanPage).toContain('id="DiscAnalyzeDialog"');
    expect(scanPage).toContain('id="DiscTitleList"');
    expect(scanPage).toContain('id="StreamSelectionPanel"');
    expect(scanPage).not.toContain(
      "refetchInterval: 3000, queryKey: getListJobsQueryKey({})",
    );
    expect(scanPage).not.toContain("backdrop-blur-sm");
  });

  it("keeps DVD stream checkbox changes local and records frame-to-frame latency", () => {
    const scanPage = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );
    const streamToggle =
      scanPage.match(
        /function toggleStream[\s\S]*?function toggleChapter/,
      )?.[0] ?? "";
    const chapterToggle =
      scanPage.match(
        /function toggleChapter[\s\S]*?const selectedStreamIndices/,
      )?.[0] ?? "";
    expect(scanPage).toContain("recordDiscPreviewInteraction");
    expect(scanPage).toContain('measureDiscPreviewInteraction("streamToggle"');
    expect(scanPage).toContain('measureDiscPreviewInteraction("chapterToggle"');
    expect(streamToggle).not.toContain("fetch(");
    expect(streamToggle).not.toContain("useAnalyzeDisc");
    expect(chapterToggle).not.toContain("fetch(");
    expect(chapterToggle).not.toContain("useAnalyzeDisc");
  });

  it("explains browser video preview failures instead of showing a silent black player", () => {
    const selector = readProjectFile(
      "artifacts/video-agent/src/components/StreamSelector.tsx",
    );
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const player = readProjectFile(
      "artifacts/video-agent/src/components/PreviewPlayer.tsx",
    );

    expect(player).toContain("previewFailed");
    expect(detail + zhPack()).toContain("当前格式可能无法被浏览器直接预览");
    expect(player).toContain("element?.error && element.error.code !== 1");
    expect(selector + zhPack()).toContain("源选择和流轨设置");
    expect(selector).not.toContain("当前格式可能无法被浏览器直接预览");
    expect(selector).not.toContain("onError={() => setPreviewFailed(true)}");
    // jobsRoute is the concatenation of every route module, so anchoring on a
    // contiguous expression breaks whenever the handler moves between files.
    // Assert the MIME mapping where it actually lives.
    const previewRoute = readProjectFile(
      "artifacts/api-server/src/routes/jobs-preview.ts",
    );
    expect(previewRoute).toContain('? "video/x-matroska"');
    expect(previewRoute).toContain('extension === ".mkv"');
  });

  it("uses a browser-safe transcoded video preview stream and themed native sliders", () => {
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const player = readProjectFile(
      "artifacts/video-agent/src/components/PreviewPlayer.tsx",
    );
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");
    const previewService = readProjectFile(
      "artifacts/api-server/src/media/preview-service.ts",
    );
    const settings = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );
    const css = readProjectFile("artifacts/video-agent/src/index.css");

    expect(detail).toContain("previewTranscodeSrc");
    expect(detail).toContain("rawPlayable");
    expect(detail).toContain("parseSubtitleCues");
    expect(detail).toContain("previewRawSrc");
    expect(player).toContain("href={rawUrl}");
    expect(jobsRoute).toContain('router.get("/jobs/:id/preview.mp4"');
    expect(previewService).toContain("-movflags");
    expect(previewService).toContain(
      "frag_keyframe+empty_moov+default_base_moof",
    );
    expect(jobsRoute).toContain('resolveToolPath("ffmpeg")');
    expect(jobsRoute).toContain('router.get("/jobs/:id/preview/raw"');
    expect(settings).toContain('className="vx-range w-full"');
    expect(settings).not.toContain("accent-primary");
    expect(css).toContain(".vx-range");
    expect(css).toContain("::-webkit-slider-thumb");
    expect(css).toContain("::-moz-range-thumb");
  });

  it("uses one invisible outer scroll owner, real preview metadata, seeked previews, and a visible AI assistant entry", () => {
    const app = readProjectFile("artifacts/video-agent/src/App.tsx");
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const player = readProjectFile(
      "artifacts/video-agent/src/components/PreviewPlayer.tsx",
    );
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");
    const previewService = readProjectFile(
      "artifacts/api-server/src/media/preview-service.ts",
    );
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    const css = readProjectFile("artifacts/video-agent/src/index.css");

    expect(app).toContain("app-scroll-shell");
    expect(app).not.toContain("scrollbar-none");
    expect(app).toContain("app-scroll-shell min-h-0 flex-1");
    expect(app).toContain('paddingBlock: "clamp(0.75rem, 2.5vh, 2rem)"');
    expect(app).toContain('paddingInline: "clamp(0.75rem, 2vw, 2rem)"');
    expect(app).toMatch(
      /isWorkbench\s*\|\|\s*location === "\/jobs"\s*\?\s*"overflow-hidden"\s*:\s*"overflow-y-auto"/,
    );
    expect(css).toContain(".scrollbar-none");
    expect(css).toContain("scrollbar-width: none");
    expect(jobsRoute).toContain('router.get("/jobs/:id/preview/meta"');
    expect(previewService).toContain('"-show_format"');
    expect(previewService).toContain("durationSeconds");
    expect(previewService).toContain(
      "frag_keyframe+empty_moov+default_base_moof",
    );
    expect(jobsRoute).toContain("res.write(chunk)");
    expect(previewService).toContain('"-maxrate"');
    expect(previewService).toContain('"4500k"');
    expect(previewService).toContain('"-preset"');
    expect(previewService).toContain('"veryfast"');
    expect(previewService).toContain('"-b:v"');
    expect(previewService).toContain('"3200k"');
    expect(previewService).toContain("min(1280");
    expect(jobsRoute).toContain("req.query.seek");
    expect(jobsRoute).toContain('"-ss"');
    expect(jobsRoute).toContain("req.query.sub");
    expect(previewService).toContain("eof_action=pass");
    expect(previewService).toContain("scale2ref");
    expect(previewService).toContain("subtitleContainerIndices");
    expect(previewService).toContain('"-g"');
    expect(previewService).toContain('"48"');
    expect(player).toContain("fetch(metaUrl)");
    expect(player).toContain("setPreviewDuration(body?.durationSeconds ?? 0)");
    expect(player).toContain("previewSeekBaseRef");
    // The preview URL is assembled from a params object, not string
    // concatenation, so assert both the seek parameter and its formatting.
    expect(player).toContain("params.seek = seekSeconds.toFixed(2)");
    expect(detail).toContain("parseSubtitleCues");
    expect(detail).toContain("previewTranscodeSrc");
    expect(player).toContain("seekPreviewCommitted");
    expect(player).toContain("previewBuffering");
    expect(player).toContain("seekInFlightRef");
    expect(detail).toContain("selectEmbeddedTrack");
    expect(detail).toContain("IMAGE_SUBTITLE_CODECS");
    expect(player).toContain("onStalled={() => setPreviewBuffering(true)}");
    expect(detail).toContain("assistantOpen");
    expect(detail + zhPack()).toContain("智能助手");
    expect(detail).toContain('data-testid="job-toolbar-assistant"');
    expect(scan).not.toContain('data-testid="ai-assistant-panel"');
  });

  it("keeps the job toolbar, assistant, and details available while the preview is playing", () => {
    const detail =
      readProjectFile("artifacts/video-agent/src/pages/JobDetail.tsx") +
      readProjectFile(
        "artifacts/video-agent/src/components/SettingsPreviewShell.tsx",
      );
    const playerCard = readProjectFile(
      "artifacts/video-agent/src/components/PreviewPlayerCard.tsx",
    );

    expect(detail).toContain('data-testid="job-detail-toolbar"');
    expect(detail).toContain("const sourceStem = filename");
    expect(detail).not.toContain("if (previewPlaying)");
    expect(detail).not.toContain('previewPlaying ? "hidden"');
    expect(playerCard).toContain('"w-full min-h-0"');
    expect(playerCard).toContain("previewLayoutMode");
    expect(detail).toContain(
      "flex h-full min-h-0 w-full min-w-0 max-w-full flex-col gap-3 overflow-hidden",
    );
  });

  it("shows four compression presets under video compression in the workbench and persists preset to config; compression jobs auto-open details", () => {
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );

    expect(scan).toContain("onCompressionPresetSelect");
    expect(scan).toContain('processingMode === "compress"');
    expect(scan).toContain("<CompressionPresetPanel");
    expect(scan).toContain("presets.map((preset)");
    expect(scan).toContain("presetConfigValues(preset)");
    expect(scan).toContain("updateConfig.mutateAsync");
    expect(scan).toContain("RESOLUTION_OPTIONS");
    expect(scan).toContain("<SelectItem");
    expect(scan).toContain("startEditPreset");
    expect(scan).toContain("saveEditedPreset");
    expect(scan).toContain("ARCHIVE_PRESET_LS_KEY");
    expect(scan).toContain("settings.editingPreset");
    expect(detail).toContain("useUpdateConfig");
    expect(detail).toContain("updateConfig");
    expect(detail).toContain("mutateAsync");
    expect(detail).toContain("RESOLUTION_OPTIONS");
    expect(detail).toContain(
      'job?.processingMode === "compress" && !detailsDrawerOpen',
    );
  });

  it("deduplicates preview transcodes per job and auto-retries transient browser media errors; desktop opens the media workbench", () => {
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const player = readProjectFile(
      "artifacts/video-agent/src/components/PreviewPlayer.tsx",
    );
    const mainRs = readProjectFile("desktop-tauri/src-tauri/src/main.rs");
    const services = readProjectFile("windows-setup/start-services.ps1");

    expect(jobsRoute).toContain("genericPreviewFfmpeg");
    expect(jobsRoute).toContain('genericPreviewFfmpeg.kill("SIGKILL")');
    expect(player).toContain("retryPreviewPlayback");
    expect(player).toContain("previewRetryCountRef");
    expect(player).toContain("previewErrorCode");
    expect(player).toContain("jobDetail.previewErrorCode");
    expect(mainRs).toContain('"http://127.0.0.1:18080"');
    expect(services).toContain('"http://127.0.0.1:24403/workbench"');
  });

  // Regression: the client poll budget used to be exactly the server's segment
  // kill deadline (150 attempts x 600 ms = 90 s == preview-segments timeoutMs),
  // so the client gave up at the instant the server was able to answer, and it
  // reported "segment" even though the segment was not ready.
  it("keeps the preview segment wait budget above the server transcode timeout", () => {
    // The budget constants live in preview-segment-wait.ts, which has its own
    // unit tests; PreviewPlayer holds the call site that must not treat an
    // exhausted wait as a ready segment.
    const waiter = readProjectFile(
      "artifacts/video-agent/src/components/preview-segment-wait.ts",
    );
    const player = readProjectFile(
      "artifacts/video-agent/src/components/PreviewPlayer.tsx",
    );
    const segments = readProjectFile(
      "artifacts/api-server/src/lib/preview-segments.ts",
    );

    const serverTimeoutMs = Number(
      /timeoutMs:\s*([\d_]+)/.exec(segments)?.[1].replace(/_/g, "") ?? "0",
    );
    expect(serverTimeoutMs).toBeGreaterThan(0);

    const attempts = Number(
      /SEGMENT_WAIT_ATTEMPTS\s*=\s*(\d+)/.exec(waiter)?.[1] ?? "0",
    );
    const intervalMs = Number(
      /SEGMENT_WAIT_INTERVAL_MS\s*=\s*(\d+)/.exec(waiter)?.[1] ?? "0",
    );
    expect(attempts).toBeGreaterThan(0);
    expect(intervalMs).toBeGreaterThan(0);
    expect(attempts * intervalMs).toBeGreaterThan(serverTimeoutMs);

    // Exhausting the budget must not be reported as a ready segment.
    expect(waiter).toContain('return "timeout";');
    expect(player).toContain('if (ready === "timeout")');
    expect(player).toContain("setPreviewFailed(true);");
  });

  it("supports DVD VobSub OCR through HandBrake passthrough with type-relative subtitle mapping", () => {
    const lib = readProjectFile("artifacts/api-server/src/lib/subtitle-ocr.ts");

    expect(lib).toContain("detectDvdOcrTarget");
    expect(lib).toContain("extractDvdSubtitleMkv");
    expect(lib).toContain("decodeVobSubToFrames");
    expect(lib).toContain("buildEventsFromVobFrames");
    expect(lib).toContain("runVobSubOcr");
    expect(lib).toContain("subTypeIndex");
    expect(lib).toContain("fps_mode");
    expect(lib).toContain("subtitleTrackNumber");
    // "auto" prefers the English graphic subtitle track on multi-language sources.
    expect(lib).toContain("pickPreferredGraphicStream");
    expect(lib).toContain('(stream.language ?? "").toLowerCase() === "eng"');
    expect(lib).toContain("OCR_LANGUAGE_CODES");
  });

  it("runs OCR as a queue job: preset engine/language, video files queue directly, discs analyze then select streams", () => {
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    const jobs =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts") +
      readProjectFile("artifacts/api-server/src/routes/job-orchestrator.ts") +
      // OCR flow moved from jobs-ocr-flow.ts to the singular pipeline prefix.
      readProjectFile("artifacts/api-server/src/routes/job-ocr-flow.ts");
    const ocrLib = readProjectFile(
      "artifacts/api-server/src/lib/subtitle-ocr.ts",
    );
    const smartWorkflow = readProjectFile(
      "artifacts/api-server/src/lib/smart-workflow.ts",
    );
    const posterLib = readProjectFile("artifacts/api-server/src/lib/poster.ts");
    const spec = readProjectFile("lib/api-spec/openapi.yaml");
    const zod = readProjectFile("lib/api-zod/src/generated/api.ts");
    const jobsPage = readProjectFile(
      "artifacts/video-agent/src/pages/Jobs.tsx",
    );
    const badge = readProjectFile(
      "artifacts/video-agent/src/components/JobStatusBadge.tsx",
    );

    // The OCR tile selects a workbench subtitle mode; there is no separate OCR dialog.
    expect(scan).toContain('"subtitle-mode-ocr"');
    expect(scan).toContain("setSubtitleMode(mode);");
    expect(scan).not.toContain("OcrDialog");
    expect(scan).not.toContain("ocrOpen");
    // OCR preset panel: engine + full language list, persisted as global defaults.
    expect(scan).toContain('data-testid="ocr-options-panel"');
    expect(scan).toContain('data-testid="ocr-engine-select"');
    expect(scan).toContain('data-testid="ocr-language-select"');
    expect(scan).toContain("OCR_ENGINE_KEY");
    expect(scan).toContain("OCR_LANGUAGE_KEY");
    expect(scan).toContain("OcrLanguagePicker");
    expect(scan).toContain("filtered.map((code)");
    // OCR jobs are created like other subtitle jobs, with the preset attached.
    expect(scan).toContain('subtitleMode: isRemuxMode ? "skip" : subtitleMode');
    expect(scan).toContain("ocrEngine");
    expect(scan).toContain("ocrLanguage");
    // The API accepts ocr as a subtitle mode and stores the preset on the job.
    expect(spec).toContain(
      "enum: [auto, extract, whisper, transcribe_translate, skip, ocr, bilingual]",
    );
    expect(zod).toContain("'ocr'");
    expect(zod).toContain("ocrEngine");
    expect(zod).toContain("ocrLanguage");
    // The executor runs the OCR pipeline with job-preset engine/language and logs tools.
    expect(jobs).toContain('subtitleMode === "ocr"');
    expect(jobs).toContain("runSubtitleOcr");
    expect(jobs).toContain("ocrTitleIdForTaskSnapshot");
    expect(jobs).toContain("【图形字幕 OCR】");
    expect(jobs).toContain('status: "transcribing"');
    // V 0.76: content-based existing-subtitle detection, timestamp alignment,
    // three-file output (.ocr/.en/.zhs) and Douban Chinese-title calibration.
    expect(jobs).toContain("detectExistingSubtitleFiles");
    expect(jobs).toContain("alignEnglishReference");
    expect(jobs).toContain(".en.srt");
    expect(jobs).toContain("豆瓣中文片名");
    expect(jobs).toContain("ocrBilingualCorrection");
    // V 0.77: faster-whisper CPU engine and RapidOCR Chinese OCR engine.
    expect(jobs).toContain("faster-whisper");
    expect(zod).toContain("'rapidocr'");
    expect(scan).toContain("rapidocr");
    // V 0.792: adaptive bilingual gate driven by OCR quality score.
    expect(jobs).toContain("qualityScore");
    expect(jobs).toContain("识别质量");
    expect(ocrLib).toContain("computeOcrQuality");
    // V 0.793: native English-track OCR preferred over reusing a Whisper SRT,
    // and TMDb is searched from the filename when no movie metadata exists.
    expect(jobs).toContain("result.dvdReferenceTrack");
    expect(jobs).toContain('reference.language ?? "外语"');
    expect(jobs).toContain("search/movie");
    // V 0.794: capacity-model estimates, <5min guard, local poster cascade.
    expect(smartWorkflow).toContain("targetCapacityBytes");
    expect(jobs).toContain("ensureLocalPoster");
    expect(posterLib).toContain("folder.jpg");
    // V 0.839: related Wikipedia/iTunes images are no longer accepted as
    // automatic posters without title/year or IMDb identity provenance.
    expect(posterLib).toContain("posterSearchIdentityMatches");
    // Queue shows the OCR plan and an OCR-specific running label.
    expect(jobsPage).toContain("jobs.planOcr");
    expect(jobsPage).toContain("ocrEngineLabel");
    expect(badge).toContain("jobs.ocrRunning");
  });

  it("exposes AI generation toggles in the assistant and per-job endpoints", () => {
    const jobs =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");
    const assistant = readProjectFile(
      "artifacts/video-agent/src/components/AssistantPanel.tsx",
    );
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const workflow = readProjectFile(
      "artifacts/video-agent/src/pages/Workflow.tsx",
    );
    const zh = readProjectFile("artifacts/video-agent/src/i18n/zh-CN.ts");
    const en = readProjectFile("artifacts/video-agent/src/i18n/en-US.ts");

    expect(jobs).toContain("/jobs/:id/ai-options");
    expect(jobs).toContain("ai-options/apply-all");
    expect(jobs).toContain("generateAiReview");
    expect(assistant).toContain("assistant-toolbar");
    expect(assistant).toContain("usePlanTitle");
    expect(assistant).toContain("generateReview");
    expect(assistant).toContain("assistant-generate-bar");
    expect(detail).toContain("job-decision-basis");
    expect(detail).toContain("workflow-confirm-banner");
    expect(detail).toContain("btn-workflow-confirm");
    expect(workflow).toContain("setLocation(`/jobs/${results[0].id}`)");
    expect(workflow).toContain("onPreferencesChange");
    expect(zh).toContain("generateReadme");
    expect(en).toContain("generateReadme");
  });

  it("keeps preview subtitles based on real files on disk and supports seeking the streaming preview", () => {
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const player = readProjectFile(
      "artifacts/video-agent/src/components/PreviewPlayer.tsx",
    );
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");

    expect(jobsRoute).toContain('router.get("/jobs/:id/subtitles"');
    expect(jobsRoute).toContain("scanJobSubtitleFiles");
    expect(jobsRoute).toContain("req.query.file");
    expect(detail).toContain("/api/jobs/${jobId}/subtitles");
    expect(detail).toContain("subtitle-preview?file=");
    // The preview-kind switch was extracted into useJobSourceInfo; a "file:"
    // selection is still resolved through subtitleCueUrl.
    expect(detail).toContain("subtitleCueUrl(jobId, subtitlePreviewKind)");
    expect(detail).toContain("file:${preferred.name}");
    expect(player).toContain("onWaiting={() => setPreviewBuffering(true)}");
  });

  it("picks a full embedded subtitle track and skips auto subtitle work when Chinese subtitles exist", () => {
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");

    expect(jobsRoute).toContain("sampleEmbeddedSubtitleText");
    expect(jobsRoute).toContain("textLooksChinese");
    expect(jobsRoute).toContain("probeSubtitlePacketCount");
    expect(jobsRoute).toContain("MIN_FULL_SUBTITLE_PACKETS");
    expect(jobsRoute).toContain("MIN_FULL_SUBTITLE_PACKETS = 400");
    expect(jobsRoute).toContain("fullSubtitlePacketThreshold");
    expect(jobsRoute).toContain("FULL_SUBTITLE_PACKETS_PER_MINUTE");
    expect(jobsRoute).toContain("MIN_FULL_SUBTITLE_ABSOLUTE");
    expect(jobsRoute).toContain(
      "fullSubtitlePacketThreshold(job.durationSeconds)",
    );
    expect(jobsRoute).toContain("languageTagIsChinese");
    expect(jobsRoute).toContain("embeddedChineseSkipped");
    expect(jobsRoute).toContain("自动模式无需提取或翻译，跳过字幕处理");
    expect(jobsRoute).toContain("Primary = the fullest extracted track");
    expect(jobsRoute).toContain("primaryPath = candidate");
  });

  it("derives media background from filenames and persists confirmed movie metadata on jobs", () => {
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");
    const workflowPage = readProjectFile(
      "artifacts/video-agent/src/pages/Workflow.tsx",
    );

    expect(jobsRoute).toContain("deriveMediaContextFromFilename");
    expect(jobsRoute).toContain("【媒体背景（从文件名推断）】");
    expect(jobsRoute).toMatch(
      /const wikiTitle =\s*job\.movieTitleEn \|\|\s*job\.movieTitle \|\|\s*derivedMedia\.seriesTitle/,
    );
    expect(jobsRoute).toContain("rawBody.movieTitle");
    expect(jobsRoute).toContain("movieTitleEn,");
    expect(workflowPage).toContain("movieTitle: identity?.title || undefined");
    expect(workflowPage).toContain(
      "moviePoster: identity?.poster || undefined",
    );
  });

  it("labels finished auto jobs by actual subtitle outcome and distinguishes files in the directory picker", () => {
    const jobsPage = readProjectFile(
      "artifacts/video-agent/src/pages/Jobs.tsx",
    );
    const picker = readProjectFile(
      "artifacts/video-agent/src/components/DirectoryPicker.tsx",
    );
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");

    expect(jobsPage).toContain("planChineseSkip");
    expect(jobsPage).toContain("embedded-chinese");
    expect(jobsPage).toContain("planExtractTranslate");
    expect(jobsPage).toContain("planExternalTranslate");
    expect(jobsPage).toContain("planExternal");
    expect(zhPack()).toContain("已含中文字幕，无需处理");
    expect(enPack()).toContain("Chinese subtitles already present");
    expect(jobsRoute).toContain("subtitleSourceOutcome");
    expect(jobsRoute).toContain('"embedded-chinese"');
    expect(picker).toContain("FileVideo");
    expect(picker).toContain('entry.type !== "file"');
  });

  it("keeps the directory picker quick-access menu behind a labeled choose button", () => {
    const picker = readProjectFile(
      "artifacts/video-agent/src/components/DirectoryPicker.tsx",
    );

    expect(picker).toContain("chooseDirectory");
    expect(picker).toContain("quickAccess");
    expect(picker).toContain("networkLocations");
    expect(picker).toContain("defaultInputFolder");
    expect(picker).toContain("loadNetworkPaths");
    expect(picker).toContain("looksLikeNetworkPath");
    expect(picker).toContain("openCurrentValueFolder");
    expect(picker).toContain("openQuickMyComputer");
    expect(picker).toContain("h-10 gap-1.5 rounded-lg px-3");
    expect(picker).toContain(
      "active:bg-primary active:text-primary-foreground",
    );
    expect(picker).toContain("createPortal");
    expect(picker).toContain("z-[120]");
    expect(zhPack()).toContain("选择目录…");
    expect(zhPack()).toContain("网络位置");
    expect(zhPack()).toContain("默认输入文件夹");
    expect(enPack()).toContain("Choose directory…");
    expect(enPack()).toContain("Network locations");
  });

  it("turns the video preview area into the processing decision center", () => {
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");
    const plan = readProjectFile("docs/stability-naming-preview-plan.md");

    expect(scan + zhPack()).toContain("视频压缩");
    expect(scan + zhPack()).not.toContain("高质量压缩");
    expect(detail).toContain("MediaStreamInfo");
    expect(detail).toContain("sourceInfo");
    expect(detail + zhPack()).toContain("视频源信息");
    expect(detail + zhPack()).toContain("分辨率");
    expect(detail + zhPack()).toContain("视频编码");
    expect(detail + zhPack()).toContain("音轨");
    expect(detail + zhPack()).toContain("字幕");
    expect(detail + zhPack()).toContain("章节");
    expect(detail).toContain("DecisionParameterPanel");
    expect(detail + zhPack()).toContain("压缩参数预设");
    expect(detail + zhPack()).toContain("当前字幕模式");
    expect(detail).toContain('data-testid="job-toolbar-assistant"');
    expect(detail + zhPack()).toContain("处理目标");
    expect(detail + zhPack()).toContain("期望输出体积/质量");
    expect(detail + zhPack()).toContain("字幕语言");
    expect(detail + zhPack()).toContain("音轨保留策略");
    expect(detail.indexOf("videoSubtitlePreview")).toBeLessThan(
      detail.indexOf("<DecisionParameterPanel"),
    );
    expect(plan + zhPack()).toContain("本轮预览决策中心重构");
    expect(plan + zhPack()).toContain("视频与字幕预览窗口附近显示源信息摘要");
  });

  it("keeps job detail compact by merging the preview title, toolbar actions, source summary, and collapsed parameter details", () => {
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const scan = readProjectFile("artifacts/video-agent/src/pages/Scan.tsx");

    expect(detail).toContain('data-testid="job-detail-toolbar"');
    expect(detail + zhPack()).toContain("视频与字幕预览");
    // The toolbar markup now lives in job-detail-toolbar.tsx; the composed page
    // renders <JobDetailToolbar> before the preview card.
    expect(detail.indexOf("<JobDetailToolbar")).toBeLessThan(
      detail.indexOf("<PreviewPlayerCard"),
    );
    expect(detail).not.toContain(
      '<CardDescription className="line-clamp-2">\\n                预览窗口统一显示视频和字幕',
    );
    expect(detail).toContain("SourceInfoCompactBar");
    expect(detail).toContain("detailsOpen");
    expect(detail + zhPack()).toContain("展开详情");
    expect(detail + zhPack()).toContain("关闭字幕");
    expect(detail + zhPack()).toContain("压缩参数预设");
    expect(scan).not.toContain("assistantGoal");
    expect(scan).not.toContain("sendAssistantPrompt");
    expect(scan).not.toContain("uiText.compressionPresets");
    expect(scan).toContain("<CompressionPresetPanel");
  });

  it("uses HandBrake track metadata for professional DVD and Blu-ray compression selection", () => {
    const handbrakeScan = readProjectFile(
      "artifacts/api-server/src/lib/handbrake-scan.ts",
    );
    const handbrakeArgs = readProjectFile(
      "artifacts/api-server/src/lib/handbrake-compression-args.ts",
    );
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");
    const scanPage = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );
    const jobRuntimeLog = readProjectFile(
      "artifacts/api-server/src/lib/job-runtime-log.ts",
    );

    expect(handbrakeScan).toContain("AudioList");
    expect(handbrakeScan).toContain("SubtitleList");
    expect(handbrakeScan).toContain("handbrakeTrackNumber");
    expect(handbrakeScan).toContain("channelLayout");
    expect(handbrakeScan).toContain("sampleRate");
    expect(handbrakeArgs).toContain("buildHandBrakeSelectionArgs");
    expect(handbrakeArgs).toContain('"--audio"');
    expect(handbrakeArgs).toContain('"--subtitle"');
    expect(handbrakeArgs).toContain('"--chapters"');
    expect(jobsRoute).toContain("parseHandBrakeSelectionPlan");
    expect(jobsRoute + zhPack()).toContain("HandBrake 选择参数");
    expect(jobsRoute).not.toContain('"--all-audio",\\n    ];');
    expect(scanPage).toContain("HandBrake #");
    expect(scanPage).toContain("handBrakeTrackNumbers");
    expect(scanPage).toContain("audioTrackNumbers");
    expect(scanPage).toContain("subtitleTrackNumbers");
    expect(jobRuntimeLog).toContain("diagnosticsLogPath");
    expect(jobRuntimeLog).toContain("===== JOB");
  });

  it("checks local service readiness without localhost HTTP proxy or IPv6 resolution", () => {
    const services = readProjectFile("windows-setup/start-services.ps1");

    expect(services).toContain("[System.Net.Sockets.TcpClient]");
    expect(services).toContain('BeginConnect("127.0.0.1", $Port');
    expect(services).toContain("Wait-ForLocalPort -Port 8080");
    expect(services).toContain("Wait-ForLocalPort -Port 24403");
    expect(services).not.toContain("Invoke-WebRequest -Uri $Uri");
  });

  it("keeps disc stream selection out of job detail and directs users to media workbench setup", () => {
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );

    expect(detail).toContain("SourceInfoCompactBar");
    expect(detail + zhPack()).toContain("视频源信息");
    expect(detail).toContain("DecisionParameterPanel");
    expect(detail).not.toContain("<StreamSelector");
    expect(detail).not.toContain("源选择和流轨设置");
  });

  it("saves native Windows directories directly instead of converting them to Docker paths", () => {
    const settings = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );

    expect(settings).toContain("nativeWatchDirectory");
    expect(settings).toContain("nativeOutputDirectory");
    expect(settings).toContain("hostDownloadsPath: nativeWatchDirectory");
    expect(settings).toContain("hostOutputPath: nativeOutputDirectory");
    expect(settings).not.toContain("Convert Windows host paths");
    expect(settings).not.toContain("fromHostPath(values.watchDirectory");
  });

  it("allows local Python-based tools to install even when they do not have archive sources", () => {
    const settings = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );

    expect(settings).toContain("canInstallWithoutSource");
    expect(settings).toContain('tool.id === "libretranslate"');
    expect(settings).toContain("installSources");
    expect(settings).not.toContain(
      "disabled={isToolBusy(tool.id) || !tool.sources.length}",
    );
  });

  it("writes stream probe attempts and failures into the job runtime diagnostics log", () => {
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");

    expect(jobsRoute + zhPack()).toContain("正在探测流轨");
    expect(jobsRoute + zhPack()).toContain("流轨探测完成");
    expect(jobsRoute + zhPack()).toContain("流轨探测失败");
    expect(jobsRoute).toContain('await addLog(id, "error"');
  });

  it("persists the selected MakeMKV title index from the disc analysis dialog", () => {
    const scanPage = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );

    expect(scanPage).toContain("DiscTrackWithMakeMkv");
    expect(scanPage).toContain("makemkvTitleIndex");
    expect(scanPage).toContain("handbrakeTitleNumber");
    expect(scanPage).toContain("analyzer");
  });

  it("shows DVD/Blu-ray chapter timing information with start, end, and duration in the disc dialog", () => {
    const scanPage = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );

    expect(scanPage).toContain("fmtChapterDuration");
    expect(scanPage).toContain("chapter.endSeconds");
    expect(scanPage + zhPack()).toContain("时长");
    expect(scanPage + zhPack()).toContain("章节信息");
    expect(scanPage).not.toContain("章节预览");
    expect(scanPage + zhPack()).toContain("未解析到章节");
    expect(scanPage + zhPack()).toContain("HandBrakeCLI");
  });

  it("registers MakeMKV as an optional Blu-ray compatibility tool with portable import only", () => {
    const runtime = readProjectFile(
      "artifacts/api-server/src/lib/tool-runtime.ts",
    );
    const manifest = readProjectFile(
      "artifacts/api-server/src/lib/tool-manifest.ts",
    );

    expect(runtime).not.toContain("makemkv");
    expect(manifest).not.toContain("makemkv");
  });

  it("does not allow the legacy MakeMKV branch to precede verified FFmpeg dvdvideo DVD Remux", () => {
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts") +
      readProjectFile("artifacts/api-server/src/routes/job-orchestrator.ts");

    expect(jobsRoute.indexOf("processVerifiedDvdRemuxJob")).toBeGreaterThan(-1);
    expect(jobsRoute.indexOf("processVerifiedDvdRemuxJob")).toBeLessThan(
      jobsRoute.indexOf("playlistDuration"),
    );
    expect(jobsRoute).toContain('job.mediaType === "dvd"');
    expect(jobsRoute).toContain('job.processingMode === "remux"');
    expect(jobsRoute).toContain("pipelineHasRemux");
    expect(jobsRoute).toContain("shouldUseVerifiedDvdRemux");
  });

  it("does not display a fake version when a local optional tool has no version output", () => {
    const settings = readProjectFile(
      "artifacts/video-agent/src/pages/Settings.tsx",
    );

    expect(settings).toContain("tool.version &&");
    expect(settings).not.toContain("版本读取失败");
  });

  it("downloads faster-whisper models through the app's own Node fetch", () => {
    const whisperRuntime = readProjectFile(
      "artifacts/api-server/src/lib/whisper-runtime.ts",
    );

    expect(whisperRuntime).toContain("ensureFasterWhisperModel");
    expect(whisperRuntime).toContain("hf-mirror.com");
    expect(whisperRuntime).toContain("model.bin");
    expect(whisperRuntime).toContain("vx_faster_whisper_cli.py");
  });

  it("keeps preview and outputs visible while moving metadata and subtitle workflow out of job detail", () => {
    const detail = readProjectFile(
      "artifacts/video-agent/src/pages/JobDetail.tsx",
    );
    const selector = readProjectFile(
      "artifacts/video-agent/src/components/StreamSelector.tsx",
    );

    expect(detail + zhPack()).toContain("视频与字幕预览");
    expect(detail.indexOf("videoSubtitlePreview")).toBeLessThan(
      detail.indexOf("<SourceInfoCompactBar"),
    );
    expect(detail + zhPack()).toContain("原字幕");
    expect(detail + zhPack()).toContain("译文字幕");
    expect(detail + zhPack()).toContain("内置 #");
    expect(detail).toContain("embeddedSubtitleTracks");
    expect(detail + zhPack()).toContain("打开输出文件夹");
    expect(detail + zhPack()).toContain("封装后大小");
    expect(detail).toContain('job.processingMode !== "remux"');
    expect(detail + zhPack()).toContain("节省比例");
    expect(selector).not.toContain("<video");
    expect(selector).not.toContain("本地预览：视频不会上传到云端。");
    expect(detail).not.toContain("手动输入影片信息");
    expect(detail).not.toContain("btn-manual-metadata");
    expect(detail).not.toContain("useRunSubtitlePipeline");
    expect(detail).not.toContain("useLookupMetadata");
  });

  it("keeps queue output folders directly clickable and avoids stream selection in the queue list", () => {
    const jobs = readProjectFile("artifacts/video-agent/src/pages/Jobs.tsx");

    expect(jobs + zhPack()).toContain("打开输出文件夹");
    expect(jobs).toContain(
      "void openOutputPath(job.outputPath || job.filePath)",
    );
    expect(jobs).toContain("toHostPath(p, config) || p");
    expect(jobs).not.toContain("双击打开输出文件夹");
    expect(jobs).not.toContain("流轨选择");
    expect(jobs).not.toContain("开始探测流轨");
  });

  it("uses a sanitized pnpm path and app-controlled Node 22 LTS during Windows install", () => {
    const installer = readProjectFile("windows-setup/install.ps1");

    expect(installer).toContain("Normalize-CommandPathLine");
    expect(installer).toContain("Test-SafePath");
    expect(installer).toContain("Get-SafeExistingCommandPath");
    expect(installer).toContain(
      'Invoke-ExternalCommand -CommandParts @("where", "pnpm")',
    );
    expect(installer).not.toContain("if (-not (Test-Path $pnpmCommand))");
    expect(installer).toContain("$nodeMajor -gt 22");
    expect(installer).toContain("$preferPortableNode = $true");
    expect(installer).toContain("MediaSculpt installer uses Node.js 22.20 LTS");
  });

  it("starts consolidating disc analysis into a unified source preview and processing dialog", () => {
    const scanPage = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );

    expect(scanPage + zhPack()).toContain("源预览与处理设置");
    expect(enPack()).toContain("Source preview and processing setup");
    expect(scanPage).toContain('t("scan.processingLabelPrefix")');
    expect(zhPack()).toContain("处理方式：");
    expect(scanPage).not.toContain("光盘目录分析");
  });

  it("shows compression parameters directly in the job queue", () => {
    const jobs = readProjectFile("artifacts/video-agent/src/pages/Jobs.tsx");

    expect(jobs + zhPack()).toContain("压缩参数：");
    expect(jobs).toContain("config.encoder");
    expect(jobs).toContain("CRF");
    expect(jobs).toContain("config.encoderPreset");
  });

  it("removes the misleading video-only compression label from visible UI", () => {
    const scanPage = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );
    const jobsPage = readProjectFile(
      "artifacts/video-agent/src/pages/Jobs.tsx",
    );
    const dashboard = readProjectFile(
      "artifacts/video-agent/src/pages/Dashboard.tsx",
    );
    const workflow = readProjectFile("docs/workflow.md");

    expect(scanPage).not.toContain("仅视频压缩");
    expect(jobsPage).not.toContain("仅视频压缩");
    expect(dashboard).not.toContain("仅视频压缩");
    expect(workflow).not.toContain("仅视频压缩");
    expect(scanPage + zhPack()).toContain("跳过字幕");
    expect(jobsPage + zhPack()).toContain("跳过字幕");
  });

  it("shows Remux and speech/subtitle processing as first-level processing modes", () => {
    const scanPage = readProjectFile(
      "artifacts/video-agent/src/pages/Scan.tsx",
    );

    expect(scanPage + zhPack()).toContain("视频压缩");
    expect(scanPage + zhPack()).toContain("Remux 无损封装");
    expect(scanPage + zhPack()).toContain("语音与字幕文件处理");
    expect(scanPage + enPack()).toContain("Video compression");
    expect(scanPage + enPack()).toContain("Lossless Remux");
    expect(scanPage + enPack()).toContain("Speech and subtitle processing");
    expect(scanPage).toMatch(
      /WORKBENCH_TABS: WorkbenchTab\[\] = \[\s*"workflow",\s*"compress",\s*"none",\s*"remux",?\s*\]/,
    );
    expect(scanPage).toContain("modes={uiText.modes}");
    expect(scanPage).toContain("subtitleModes");
    expect(scanPage).not.toContain("uiText.compressionPresets");
    expect(scanPage).toContain("chooseNetworkLocation");
    expect(scanPage).toContain("networkPathInputRef");
    expect(scanPage).toContain("s.title");
    expect(scanPage).toContain("languageLabel(s, t)");
  });

  it("keeps Remux output beside the DVD or Blu-ray folder and names selected titles sequentially", () => {
    const workflow = readProjectFile(
      "artifacts/api-server/src/lib/job-workflow.ts",
    );
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");

    expect(workflow).toContain("pathApiFor");
    expect(workflow).toContain("return api.dirname(cleanPath)");
    expect(workflow).not.toContain('api.join(cleanPath, "VIDEO_TS")');
    expect(workflow).not.toContain('api.join(cleanPath, "BDMV")');
    expect(jobsRoute).toContain("remuxTitleSuffix");
    expect(jobsRoute).toContain("Title");
    expect(jobsRoute.indexOf("readMakeMkvTitleIndex")).toBeLessThan(
      jobsRoute.indexOf("buildRemuxOutputName"),
    );
  });

  it("continues from subtitle work into HandBrake compression without marking the job done early", () => {
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");
    const subtitleSection = jobsRoute.slice(
      jobsRoute.indexOf(
        'else if (subtitleMode !== "skip" && !bilingualDirectDone)',
      ),
      jobsRoute.indexOf("// ── END SUBTITLE"),
    );

    expect(subtitleSection).toContain('if (job.processingMode === "none")');
    expect(subtitleSection + zhPack()).toContain("只处理字幕完成");
    expect(subtitleSection).not.toContain(
      "Subtitle-only mode — mark done, do NOT compress",
    );
    expect(subtitleSection).not.toContain(
      'await db.update(jobsTable).set({\n        status: "done", progress: 100, subtitlePath, completedAt: new Date(),\n      }).where(eq(jobsTable.id, jobId));\n      await addLog(jobId, "info", `字幕处理完成',
    );
  });

  it("runs Whisper through the resolved managed tool path and logs the resolved executable", () => {
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");

    expect(jobsRoute).toContain("resolveToolPath");
    expect(jobsRoute).toContain(
      'const whisperExecutable = await resolveToolPath("whisper")',
    );
    expect(jobsRoute + zhPack()).toContain("Whisper 可执行文件：");
    expect(jobsRoute).not.toContain('trackSpawnForJob(jobId, "whisper", [');
  });

  it("guards HandBrake progress parsing so progress update failures do not crash the API process", () => {
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");

    expect(jobsRoute).toContain("safeHandleHbChunk");
    expect(jobsRoute + zhPack()).toContain("HandBrake 进度解析失败");
    expect(jobsRoute).not.toContain('hb.stdout?.on("data", handleHbChunk)');
    expect(jobsRoute).not.toContain('hb.stderr?.on("data", handleHbChunk)');
  });

  it("compresses DVD and Blu-ray sources directly through HandBrake rather than defaulting to MakeMKV", () => {
    const jobsRoute =
      readProjectFile("artifacts/api-server/src/routes/jobs.ts") +
      readProjectFile("artifacts/api-server/src/routes/jobs-preview.ts") +
      readProjectFile("artifacts/api-server/src/routes/disc.ts");
    const compressionService = readProjectFile(
      "artifacts/api-server/src/media/compression-service.ts",
    );
    const workflow = readProjectFile(
      "artifacts/api-server/src/lib/job-workflow.ts",
    );
    const workflowTest = readProjectFile(
      "artifacts/api-server/src/lib/job-workflow.test.ts",
    );

    expect(workflow).not.toContain(
      'return [{ processingMode: "remux" }, { processingMode: "compress" }]',
    );
    expect(workflowTest).toContain(
      "keeps disc compression as direct HandBrake compression instead of remuxing first",
    );
    expect(workflow).toContain(
      'if (requested === "compress" && isDiscMediaType(input.mediaType))',
    );
    expect(workflow).toContain('return "compress";');
    expect(jobsRoute).not.toContain("prepareDiscCompressionInput");
    expect(jobsRoute).not.toContain("MakeMKV 中间文件");
    expect(jobsRoute).not.toContain("光盘压缩准备：先用 MakeMKV");
    expect(jobsRoute + zhPack()).toContain(
      "光盘压缩模式 — HandBrake 直接分析 DVD/蓝光/ISO",
    );
    expect(jobsRoute).toContain("buildHandBrakeCompressionArgs");
    expect(compressionService).toContain("buildHandBrakeCompressionArgs");
    expect(compressionService).toContain('"-i"');
    expect(compressionService).toContain("ffmpegPath(input.inputPath)");
    expect(jobsRoute).toContain(
      "taskSnapshot?.toolSelections.handbrakeTitleNumber",
    );
    expect(jobsRoute).toContain("frozenHandBrakeTitleNumber");
    expect(jobsRoute + zhPack()).toContain("HandBrake DVD 标题：Title");
  });
});
