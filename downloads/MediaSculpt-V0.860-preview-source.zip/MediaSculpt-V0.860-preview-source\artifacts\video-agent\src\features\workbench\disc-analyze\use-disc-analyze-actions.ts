import { useState, useCallback } from "react";
import type { useCreateJob } from "@workspace/api-client-react";
import type { AnalyzeDiscQueryResult } from "@workspace/api-client-react";
import type { ProcessingMode, SubtitleMode } from "@/hooks/useWorkbenchState";
import type { ScanCopy } from "@/pages/Scan";
import type { BatchItem } from "@/pages/BatchConfirmPage";
import type { DiscTrackWithMakeMkv } from "../disc-display-model";
import {
  assessDiscRemuxCapacity,
  countSelectedDiscSubtitleStreams,
  selectCapacitySafeDiscTitles,
} from "../disc-job-mode-model";
import {
  filterValidSelection,
  selectionMatches,
} from "../disc-selection-reconciliation-model";
import {
  buildDiscBatchItems,
  buildDiscSelectionPlan,
  canCreateDiscJobSelection,
  discOutputMode,
  hasRunningRemuxDuplicate,
} from "../disc-create-model";
import type { DiscAnalyzeSelectionState } from "./use-disc-analyze-selection";
import type { DiscAnalyzeVerificationState } from "./use-disc-analyze-verification";

type Translate = (
  path: string,
  params?: Record<string, string | number>,
) => string;
type ToastFn = (input: {
  title?: string;
  description?: string;
  variant?: "default" | "destructive";
}) => void;
type ExistingJobs = Parameters<typeof hasRunningRemuxDuplicate>[0];

/**
 * Smart parsing, capacity checks and job creation for the disc analyze dialog.
 */
export function useDiscAnalyzeActions({
  data,
  discPath,
  processingMode,
  subtitleMode,
  ocrEngine,
  ocrLanguage,
  bilingualLayout,
  uiText,
  allowJobCreation,
  analysisOnly,
  includeVideoStreams,
  existingJobs,
  selection,
  verification,
  createJob,
  t,
  toast,
  onJobCreated,
  onClose,
  onAnalysisConfirmed,
}: {
  data: AnalyzeDiscQueryResult | undefined;
  discPath: string;
  processingMode: ProcessingMode;
  subtitleMode: SubtitleMode;
  ocrEngine?: string;
  ocrLanguage?: string;
  bilingualLayout: "zh-top" | "foreign-top";
  uiText: ScanCopy;
  allowJobCreation: boolean;
  analysisOnly: boolean;
  includeVideoStreams: boolean;
  existingJobs: ExistingJobs;
  selection: DiscAnalyzeSelectionState;
  verification: Pick<
    DiscAnalyzeVerificationState,
    "verifyingTracks" | "effectiveTrack" | "setVerifiedTracks"
  >;
  createJob: ReturnType<typeof useCreateJob>;
  t: Translate;
  toast: ToastFn;
  onJobCreated: (count: number, firstId?: number) => void;
  onClose: () => void;
  onAnalysisConfirmed?: (items: BatchItem[]) => void;
}) {
  const {
    activeTrackIdx,
    setActiveTrackIdx,
    selectedTrackIndices,
    setSelectedTrackIndices,
    streamSelections,
    setStreamSelections,
    chapterSelections,
    setChapterSelections,
    defaultStreamSelection,
    defaultChapterSelection,
  } = selection;
  const { verifyingTracks, effectiveTrack, setVerifiedTracks } = verification;

  const [smartParsing, setSmartParsing] = useState(false);
  const [smartNote, setSmartNote] = useState<string | null>(null);
  const [smartManifestId, setSmartManifestId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  // 智能解析：服务端先做真实读取和容量校验，再一次性应用最终标题清单。
  const runSmartParse = useCallback(async () => {
    if (!data) return;
    setSmartParsing(true);
    setSmartNote(null);
    try {
      const response = await fetch("/api/disc/analyze/smart", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ analysisId: data.analysisId, force: true }),
      });
      const result = (await response.json().catch(() => ({}))) as {
        applied?: boolean;
        manifestId?: string;
        selectedTitleIds?: string[];
        selectedStreamsByTitle?: Record<string, number[]>;
        selectedChaptersByTitle?: Record<string, number[]>;
        confidence?: "high" | "medium" | "low";
        requiresUserSelection?: boolean;
        reason?: string;
        reasons?: string[];
        ai?: {
          titleId?: string;
          videoIndex?: number | null;
          audioIndices?: number[];
          subtitleIndices?: number[];
          reason?: string;
        } | null;
      };
      const selectedIds = Array.isArray(result.selectedTitleIds)
        ? result.selectedTitleIds.filter(
            (value): value is string => typeof value === "string",
          )
        : [];
      const selectedIndices = selectedIds
        .map((titleId) =>
          (data.tracks ?? []).findIndex((track) => track.titleId === titleId),
        )
        .filter((idx) => idx >= 0);
      const safeSelectedIndices = selectCapacitySafeDiscTitles(
        data.tracks as Array<DiscTrackWithMakeMkv>,
        selectedIndices,
        data.sourceSizeBytes,
      );
      if (response.ok && result.applied && safeSelectedIndices.length > 0) {
        const selectedStreamsByTitle = result.selectedStreamsByTitle ?? {};
        const selectedChaptersByTitle = result.selectedChaptersByTitle ?? {};
        // Apply the server's safe title decision to the actual title checklist.
        // Previously only stream/chapter maps were updated, so the UI could
        // still keep an empty or stale title selection after smart parsing.
        setSelectedTrackIndices(new Set(safeSelectedIndices));
        setStreamSelections((current) => {
          const next = new Map(current);
          for (const idx of safeSelectedIndices) {
            const track = data.tracks[idx];
            const requested = track?.titleId
              ? selectedStreamsByTitle[track.titleId]
              : undefined;
            if (track && Array.isArray(requested)) {
              const allowedIndexes = track.streams
                .filter(
                  (stream) =>
                    includeVideoStreams ||
                    stream.codecType === "audio" ||
                    stream.codecType === "subtitle",
                )
                .map((stream) => stream.index);
              const cleaned = filterValidSelection(requested, allowedIndexes);
              next.set(
                idx,
                new Set(cleaned.length > 0 ? cleaned : allowedIndexes),
              );
            }
          }
          return next;
        });
        setChapterSelections((current) => {
          const next = new Map(current);
          for (const idx of safeSelectedIndices) {
            const track = data.tracks[idx];
            const requested = track?.titleId
              ? selectedChaptersByTitle[track.titleId]
              : undefined;
            if (track && Array.isArray(requested)) {
              next.set(
                idx,
                new Set(
                  filterValidSelection(
                    requested,
                    track.chapters?.map((chapter) => chapter.id) ?? [],
                  ),
                ),
              );
            }
          }
          return next;
        });
        setActiveTrackIdx(safeSelectedIndices[0] ?? 0);
        setSmartManifestId(
          typeof result.manifestId === "string" ? result.manifestId : null,
        );
        setVerifiedTracks((current) => {
          const next = new Map(current);
          for (const idx of safeSelectedIndices) {
            const track = data.tracks[idx] as DiscTrackWithMakeMkv | undefined;
            if (track)
              next.set(idx, {
                ...track,
                verificationStatus: "verified",
                verificationFailureReason: null,
                // This is the verified logical dvdvideo title number used by the
                // executor; it is intentionally distinct from physical VTS size mapping.
                dvdVtsNumber: track.handbrakeTitleNumber ?? null,
              });
          }
          return next;
        });
        const primaryTitleId =
          data.tracks[safeSelectedIndices[0] ?? -1]?.titleId ?? null;
        const localStreams = primaryTitleId
          ? selectedStreamsByTitle[primaryTitleId]
          : undefined;
        const aiStreams =
          result.ai && result.ai.titleId === primaryTitleId
            ? [
                ...(typeof result.ai.videoIndex === "number"
                  ? [result.ai.videoIndex]
                  : []),
                ...(result.ai.audioIndices ?? []),
                ...(result.ai.subtitleIndices ?? []),
              ]
            : undefined;
        const unknownTitle = t("scan.unknownTitle");
        const aiHint = result.ai?.titleId
          ? result.ai.titleId !== primaryTitleId
            ? t("scan.smartAiSuggestedTitle", {
                suggested: result.ai.titleId,
                primary: primaryTitleId ?? unknownTitle,
              })
            : selectionMatches(localStreams, aiStreams)
              ? t("scan.smartAiStreamsMatch", { title: result.ai.titleId })
              : t("scan.smartAiStreamsDiffer", { title: result.ai.titleId })
          : t("scan.smartAiUnavailable");
        setSmartNote(
          t("scan.smartValidatedCount", {
            count: String(safeSelectedIndices.length),
            confidence: result.confidence ?? "medium",
            hint: aiHint,
            reasons: (result.reasons ?? []).slice(0, 2).join("；"),
          }),
        );
      } else {
        setSmartManifestId(null);
        const noSelectionReason =
          result.reason ??
          ((result.reasons ?? []).join("；") || t("scan.noValidatedCandidate"));
        setSmartNote(
          t("scan.smartValidationNoTitle", { reason: noSelectionReason }),
        );
      }
    } catch (error) {
      setSmartNote(
        t("scan.smartValidationFailed", {
          reason: error instanceof Error ? error.message : String(error),
        }),
      );
    } finally {
      setSmartParsing(false);
    }
  }, [data, includeVideoStreams, processingMode]);

  const selectedTracks = Array.from(selectedTrackIndices).map((idx) => {
    const track = effectiveTrack(idx);
    return {
      idx,
      track,
      selectedStreams: track
        ? (streamSelections.get(idx) ?? defaultStreamSelection(track))
        : new Set<number>(),
      duplicate: track ? hasRunningRemuxDuplicate(existingJobs, track) : false,
    };
  });

  const remuxCapacity =
    !analysisOnly && processingMode === "remux" && data?.discType === "dvd"
      ? assessDiscRemuxCapacity({
          sourceBytes: data.sourceSizeBytes,
          tracks: data.tracks as Array<DiscTrackWithMakeMkv>,
          selectedIndexes: selectedTrackIndices,
        })
      : null;
  const canCreate =
    selectedTracks.every((entry) => entry.track !== undefined) &&
    canCreateDiscJobSelection({
      allowJobCreation,
      hasData: !!data,
      processingMode,
      subtitleMode,
      selectedTitleCount: selectedTrackIndices.size,
      creating,
      remuxBlocked: !!remuxCapacity?.blocked,
      discType: data?.discType ?? "dvd",
      selectedTracks: selectedTracks.flatMap((entry) =>
        entry.track ? [{ ...entry, track: entry.track }] : [],
      ),
    });

  async function handleCreate() {
    if (!data || !allowJobCreation) return;
    if (processingMode === "remux" && data.discType === "dvd") {
      const noSubtitleSelections = Array.from(selectedTrackIndices).flatMap(
        (trackIdx) => {
          const track = effectiveTrack(trackIdx);
          if (!track) return [];
          const selected =
            streamSelections.get(trackIdx) ?? defaultStreamSelection(track);
          const counts = countSelectedDiscSubtitleStreams(
            track.streams,
            selected,
          );
          return counts.available > 0 && counts.selected === 0
            ? [counts.available]
            : [];
        },
      );
      if (noSubtitleSelections.length > 0) {
        const availableCount = noSubtitleSelections.reduce(
          (sum, count) => sum + count,
          0,
        );
        const confirmed = window.confirm(
          t("scan.remuxNoSubtitleConfirm", {
            titleCount: noSubtitleSelections.length,
            trackCount: availableCount,
          }),
        );
        if (!confirmed) return;
      }
    }
    setCreating(true);
    try {
      let created = 0;
      let firstId: number | undefined;
      for (const trackIdx of Array.from(selectedTrackIndices).sort(
        (a, b) => a - b,
      )) {
        const track = effectiveTrack(trackIdx);
        if (!track) continue;
        const streamSet =
          streamSelections.get(trackIdx) ?? defaultStreamSelection(track);
        const chapterSet =
          chapterSelections.get(trackIdx) ?? defaultChapterSelection();
        const streamArr = Array.from(streamSet).sort((a, b) => a - b);
        const chapterArr = Array.from(chapterSet).sort((a, b) => a - b);
        const selectionPlan = buildDiscSelectionPlan({
          track,
          streamSet,
          chapterIds: chapterArr,
          smartManifestId,
          analysisId: data.analysisId ?? null,
        });
        const outputMode = discOutputMode(processingMode, subtitleMode);
        const result = await createJob.mutateAsync({
          data: {
            filePath: discPath,
            subtitleMode: processingMode === "remux" ? "skip" : subtitleMode,
            ocrEngine:
              subtitleMode === "ocr"
                ? ((ocrEngine || "auto") as
                    | "auto"
                    | "llm"
                    | "tesseract"
                    | "rapidocr"
                    | "subtitleedit")
                : undefined,
            ocrLanguage:
              subtitleMode === "ocr" ? ocrLanguage || "auto" : undefined,
            mediaType: data.discType,
            processingMode:
              subtitleMode === "bilingual" ? "none" : processingMode,
            mainTrackPath: track.path,
            selectedStreams:
              streamArr.length > 0 ? JSON.stringify(streamArr) : undefined,
            selectedChapters:
              chapterArr.length > 0 ? JSON.stringify(chapterArr) : undefined,
            selectionPlan,
            analysisId: data.analysisId,
            sourceFingerprint: data.sourceFingerprint,
            selectedTitleId: track.titleId,
            outputMode,
            ...(subtitleMode === "bilingual" ? { bilingualLayout } : {}),
          },
        });
        if (!firstId && typeof (result as { id?: unknown })?.id === "number")
          firstId = (result as { id: number }).id;
        created++;
      }
      toast({
        title: uiText.createdDiscJob,
        description: `${created} · ${processingMode === "remux" ? uiText.createRemuxJob : processingMode === "compress" ? uiText.createCompressionJob : uiText.createSubtitleJob}`,
      });
      onJobCreated(created, firstId);
      onClose();
    } catch (e) {
      toast({
        title: t("scan.createFailed"),
        description: e instanceof Error ? e.message : t("common.unknownError"),
        variant: "destructive",
      });
    } finally {
      setCreating(false);
    }
  }

  function confirmAnalysisSelection() {
    if (!data || selectedTrackIndices.size === 0 || verifyingTracks.size > 0)
      return;
    const items = buildDiscBatchItems({
      discPath,
      discType: data.discType,
      analysisId: data.analysisId ?? null,
      sourceFingerprint: data.sourceFingerprint ?? null,
      selectedTrackIndices,
      getTrack: effectiveTrack,
      getStreamSelection: (idx) => streamSelections.get(idx),
      getChapterSelection: (idx) => chapterSelections.get(idx),
      defaultStreamSelection,
      defaultChapterSelection,
    });
    if (items.length === 0) return;
    onAnalysisConfirmed?.(items);
  }

  return {
    smartParsing,
    smartNote,
    setSmartNote,
    smartManifestId,
    creating,
    runSmartParse,
    remuxCapacity,
    canCreate,
    handleCreate,
    confirmAnalysisSelection,
  };
}

export type DiscAnalyzeActionsState = ReturnType<typeof useDiscAnalyzeActions>;
