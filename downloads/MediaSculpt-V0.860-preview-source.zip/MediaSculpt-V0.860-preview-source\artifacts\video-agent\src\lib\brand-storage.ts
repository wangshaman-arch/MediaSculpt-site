type StorageLike = Pick<Storage, "getItem" | "setItem">;

export const ARCHIVE_PRESET_LS_KEY = "mediasculpt-archive-presets-v1";
export const CUSTOM_PRESET_KEY = "mediasculpt-custom-presets";
export const PRESET_CHANGED_EVENT = "mediasculpt-compression-presets-updated";
export const OCR_ENGINE_KEY = "mediasculpt-ocr-engine";
export const OCR_LANGUAGE_KEY = "mediasculpt-ocr-language";
export const TUNING_CUSTOM_PRESETS_KEY = "mediasculpt-tuning-custom-presets";

const LEGACY_ARCHIVE_PRESET_LS_KEY = "vx-agent-archive-presets-v1";
const LEGACY_CUSTOM_PRESET_KEY = "vx-agent-custom-presets";
const LEGACY_OCR_ENGINE_KEY = "vx-agent-ocr-engine";
const LEGACY_OCR_LANGUAGE_KEY = "vx-agent-ocr-language";
const LEGACY_TUNING_CUSTOM_PRESETS_KEY = "vx-agent-tuning-custom-presets";

function copyWhenMissing(
  storage: StorageLike,
  legacyKey: string,
  currentKey: string,
) {
  if (storage.getItem(currentKey) !== null) return;
  const legacyValue = storage.getItem(legacyKey);
  if (legacyValue !== null) storage.setItem(currentKey, legacyValue);
}

/** Copies existing VX-Agent browser presets once, without overwriting MediaSculpt data. */
export function migrateMediaSculptPresetStorage(storage: StorageLike) {
  copyWhenMissing(storage, LEGACY_ARCHIVE_PRESET_LS_KEY, ARCHIVE_PRESET_LS_KEY);
  copyWhenMissing(storage, LEGACY_CUSTOM_PRESET_KEY, CUSTOM_PRESET_KEY);
  copyWhenMissing(storage, LEGACY_OCR_ENGINE_KEY, OCR_ENGINE_KEY);
  copyWhenMissing(storage, LEGACY_OCR_LANGUAGE_KEY, OCR_LANGUAGE_KEY);
  copyWhenMissing(
    storage,
    LEGACY_TUNING_CUSTOM_PRESETS_KEY,
    TUNING_CUSTOM_PRESETS_KEY,
  );
}
