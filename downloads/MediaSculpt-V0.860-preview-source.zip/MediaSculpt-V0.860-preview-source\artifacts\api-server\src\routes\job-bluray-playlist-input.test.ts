import { describe, expect, it } from "vitest";
import { selectedBlurayPlaylistId } from "./job-bluray-playlist-input";

describe("Blu-ray playlist input", () => {
  it("prefers the frozen playlist id from the task snapshot", () => {
    expect(
      selectedBlurayPlaylistId({
        toolSelections: { playlistId: "00800" },
        selectedTitleId: "mpls:00900",
      }),
    ).toBe("00800");
  });

  it("falls back to an mpls title id when no explicit playlist is stored", () => {
    expect(
      selectedBlurayPlaylistId({
        toolSelections: { playlistId: null },
        selectedTitleId: "mpls:00900",
      }),
    ).toBe("00900");
  });

  it("rejects non-playlist title ids", () => {
    expect(
      selectedBlurayPlaylistId({
        toolSelections: { playlistId: null },
        selectedTitleId: "m2ts:00042",
      }),
    ).toBeNull();
  });
});
