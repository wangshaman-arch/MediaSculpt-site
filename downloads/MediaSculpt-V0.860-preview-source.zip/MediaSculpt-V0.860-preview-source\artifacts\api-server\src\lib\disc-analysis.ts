// The disc analysis entry point. Shared caching/types live in disc-analysis-shared;
// the DVD and Blu-ray analyzers live in their own modules.
export * from "./disc-analysis-shared";
export { analyzeDvdWithFfprobeFallback } from "./disc-analysis-dvd";

import { analyzeDvdDiscSource } from "./disc-analysis-dvd";
import { analyzeBlurayDiscSource } from "./disc-analysis-bluray";
import type {
  DiscAnalysisInput,
  DiscAnalysisResult,
} from "./disc-analysis-shared";

export async function analyzeDiscSource(
  input: DiscAnalysisInput,
): Promise<DiscAnalysisResult> {
  return input.mediaType === "dvd"
    ? analyzeDvdDiscSource(input)
    : analyzeBlurayDiscSource(input);
}
