import fs from "fs/promises";
import os from "os";
import path from "path";
import { db, jobsTable, configTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { buildGraphicSubtitleExportArgs } from "../lib/subtitle-ocr";
import {
  explicitTranslationFailureMessage,
  hasValidSubtitleCues,
  isGraphicSubtitleCodec,
  shouldExtractEmbeddedText,
  shouldFallbackToWhisper,
  shouldOcrGraphicSubtitles,
  shouldPreserveEmbeddedChinese,
  shouldTranslateSubtitleText,
  subtitleOnlyOutputDisposition,
} from "../lib/subtitle-utils";
import {
  ensureFasterWhisperModel,
  ensureWhisperCliScript,
} from "../lib/whisper-runtime";
import type { BilingualAssStyle } from "../lib/bilingual-subtitle";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import { resolveToolPath } from "../lib/tool-runtime";
import { ffmpegPath } from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput } from "../infrastructure/process-runner";
import {
  parseSrt,
  renderSrtSimplified,
  type SrtBlock,
} from "../media/subtitle-service";
import type { TaskSnapshotV1 } from "../lib/task-snapshot";
import type { DvdTitle } from "../lib/disc";
import { mapExternalToolProgress } from "../lib/job-workflow";
import { addLog } from "../lib/job-logging";
import { settlePreviewTaskSafely } from "../lib/preview-runtime";
import { whisperDetectedLanguage } from "../lib/whisper-runtime";
import {
  buildBilingualSubtitle,
  tryDirectBilingualMerge,
} from "./jobs-bilingual";
import {
  buildTranslationPrompt,
  buildWhisperCorrectionPrompt,
} from "./jobs-prompts";
import { cancelledJobs, trackJobOutputFile } from "./jobs-tracking";
import { dvdInputArg, dvdTitleNavigationInputArgs } from "./jobs-dvd";
import { executeOcrSubtitleFlow } from "./job-ocr-flow";
import {
  fullSubtitlePacketThreshold,
  languageTagIsChinese,
  probeSubtitlePacketCounts,
  sampleEmbeddedSubtitleText,
  textLooksChinese,
} from "./jobs-subtitle-probe";
import { ocrTitleIdForTaskSnapshot } from "./jobs-pipeline";
import { pickBestAudioTrack, probeAudioTracks } from "./jobs-audio";
import { translateBatch, translateBatchLibre } from "./jobs-translation";
import type { ResolvedJob } from "./job-media-input-context";

export type SubtitleStageInput = {
  jobId: number;
  job: ResolvedJob;
  config: typeof configTable.$inferSelect;
  taskSnapshot: TaskSnapshotV1 | null;
  mediaInputPath: string;
  dvdVideoInput: string;
  subtitleMode: string;
  isBilingual: boolean;
  bilingualStyle: BilingualAssStyle;
  dvdTitle: DvdTitle | null;
  outputBaseName: string;
  subtitleStageBaseName: string;
  subtitleDirJob: string;
  srtFile: string;
  subtitleOnlyTask: boolean;
  hasEmbeddedSubs: boolean;
  sourceHasAudio: boolean;
  externalSubtitleFound: string | null;
  externalChineseBilingualSource: boolean;
  getAiProxyUrl: () => Promise<string | null>;
  subtitlePath: string | null;
  translatedSubtitlePath: string | null;
  sourceSubtitleFile: string | null;
  subtitleSourceOutcome: string | null;
};

export type SubtitleStageResult = {
  shouldReturn: boolean;
  subtitlePath: string | null;
  translatedSubtitlePath: string | null;
  sourceSubtitleFile: string | null;
  subtitleSourceOutcome: string | null;
  graphicSubtitlePaths: string[];
};

export async function runSubtitleStage(
  input: SubtitleStageInput,
): Promise<SubtitleStageResult> {
  const {
    jobId,
    job,
    config,
    taskSnapshot,
    mediaInputPath,
    dvdVideoInput,
    subtitleMode,
    isBilingual,
    bilingualStyle,
    dvdTitle,
    outputBaseName,
    subtitleStageBaseName,
    subtitleDirJob,
    srtFile,
    subtitleOnlyTask,
    hasEmbeddedSubs,
    sourceHasAudio,
    externalSubtitleFound,
    externalChineseBilingualSource,
    getAiProxyUrl,
  } = input;
  let subtitlePath = input.subtitlePath;
  let translatedSubtitlePath = input.translatedSubtitlePath;
  let sourceSubtitleFile = input.sourceSubtitleFile;
  let subtitleSourceOutcome = input.subtitleSourceOutcome;
  let graphicSubtitlePaths: string[] = [];
  let bilingualDirectDone = false;
  let explicitTranslationError: string | null = null;
  let ocrForeignSubtitlePath: string | null = null;
  let sourceLang: string | null = null;
  let ocrProducedTranslation = false;
  let embeddedGraphicSubtitleDetected = false;
  let expectedTextSubtitle = false;
  let whisperProducedEmpty = false;
  let graphicSubtitlePreserved = false;
  const result = (shouldReturn: boolean): SubtitleStageResult => ({
    shouldReturn,
    subtitlePath,
    translatedSubtitlePath,
    sourceSubtitleFile,
    subtitleSourceOutcome,
    graphicSubtitlePaths,
  });
  // ── SUBTITLE STEP (auto / extract / whisper / ocr) ───────────────────────
  // Subtitle handling is independent from video processing. Compression jobs
  // must continue into HandBrake after subtitle work; only "none" finishes here.
  // 双语字幕：先尝试“目录内现成中英字幕直连合成”（跳过翻译/OCR）。
  if (isBilingual && !bilingualDirectDone) {
    const direct = await tryDirectBilingualMerge({
      jobId,
      mediaInputPath,
      baseName: subtitleStageBaseName,
      // Existing sidecars are matched against the source identity, while
      // the generated bilingual file follows the final video identity.
      matchBaseName: outputBaseName,
      // Disc folders commonly contain ASS files generated by an earlier
      // failed run. Reusing one would make the job flash to done without
      // re-reading the optical source. Disc subtitles must go through the
      // current OCR/translation pipeline; reuse is safe for normal videos.
      allowExistingAssReuse: job.mediaType === "video",
      videoProbeInputArgs: dvdTitle
        ? dvdTitleNavigationInputArgs(dvdTitle)
        : undefined,
      videoProbeFallbackPaths: dvdTitle?.vobFiles,
      outputDir: subtitleDirJob,
      style: bilingualStyle,
      addLog: (level, message) => addLog(jobId, level, message),
    });
    if (direct) {
      subtitlePath = direct.chineseSrtPath;
      translatedSubtitlePath = direct.assPath;
      subtitleSourceOutcome = "bilingual";
      bilingualDirectDone = true;
      // Direct bilingual merge completes the subtitle-only workflow without
      // entering the normal extraction/translation branch below. Persist the
      // result here so the job does not fall through to the misleading
      // "no executable steps" warning with empty output fields.
      if (job.processingMode === "none") {
        await db
          .update(jobsTable)
          .set({
            status: "done",
            progress: 100,
            subtitlePath,
            translatedSubtitlePath,
            subtitleSource: subtitleSourceOutcome,
            outputPath: translatedSubtitlePath,
            completedAt: new Date(),
          })
          .where(eq(jobsTable.id, jobId));
        await addLog(
          jobId,
          "info",
          `只处理字幕完成 — 已生成双语字幕：${translatedSubtitlePath}`,
        );
        return result(true);
      }
    }
  }
  if (subtitleMode === "ocr") {
    const ocrTitleId = ocrTitleIdForTaskSnapshot(taskSnapshot);
    const ocrFlow = await executeOcrSubtitleFlow({
      jobId,
      mediaInputPath,
      config,
      job,
      subtitleDirJob,
      outputBaseName: subtitleStageBaseName,
      ocrTitleId,
      forceChineseTarget: isBilingual,
      failJobOnError: true,
      addLog: (level, message) => addLog(jobId, level, message),
    });
    if (ocrFlow.cancelled || !ocrFlow.ok) return result(true);
    subtitlePath = ocrFlow.subtitlePath;
    translatedSubtitlePath = ocrFlow.translatedSubtitlePath;
    ocrProducedTranslation = Boolean(ocrFlow.translatedSubtitlePath);
    ocrForeignSubtitlePath = ocrFlow.foreignSubtitlePath ?? null;
    subtitleSourceOutcome = "ocr";
  } else if (subtitleMode !== "skip" && !bilingualDirectDone) {
    let embeddedChineseSkipped = false;
    if (
      !subtitlePath &&
      !externalSubtitleFound &&
      shouldExtractEmbeddedText({
        mode: subtitleMode,
        hasEmbeddedSubs,
        isDvd: job.mediaType === "dvd",
      })
    ) {
      await db
        .update(jobsTable)
        .set({ status: "transcribing", progress: 10 })
        .where(eq(jobsTable.id, jobId));
      await addLog(jobId, "info", "正在用 ffmpeg 提取内嵌字幕");
      if (cancelledJobs.has(jobId)) return result(true);
      try {
        // The packaged app does not put ffmpeg/ffprobe on PATH (they live in a
        // nested tools dir), so always spawn the resolved executable path.
        const ffmpegExecutable =
          (await resolveToolPath("ffmpeg").catch(() => null)) ?? "ffmpeg";
        const ffprobeExecutable =
          (await resolveToolPath("ffprobe").catch(() => null)) ?? "ffprobe";
        // Extract ALL subtitle tracks (numbered .srt files)
        // DVD（VIDEO_TS 目录）的字幕轨（VOBSUB）只有通过 dvdvideo 标题输入才能被
        // ffprobe 探测到；裸打开目录会把字幕流漏掉，导致自动模式误判“无字幕轨”
        // 而跳过 OCR 直接进入语音识别。
        const isDvdDirectoryInput =
          job.mediaType === "dvd" && !/\.(ifo|vob)$/i.test(mediaInputPath);
        const ocrTitleIdForProbe = isDvdDirectoryInput
          ? ocrTitleIdForTaskSnapshot(taskSnapshot)
          : null;
        const probeArgs = [
          "-v",
          "quiet",
          "-print_format",
          "json",
          "-show_streams",
          ...(ocrTitleIdForProbe
            ? ["-f", "dvdvideo", "-title", String(ocrTitleIdForProbe)]
            : []),
          dvdInputArg(isDvdDirectoryInput ? dvdVideoInput : mediaInputPath),
        ];
        const graphicSubtitleInputArgs =
          isDvdDirectoryInput && ocrTitleIdForProbe
            ? [
                "-f",
                "dvdvideo",
                "-title",
                String(ocrTitleIdForProbe),
                "-i",
                dvdInputArg(dvdVideoInput),
              ]
            : ["-i", ffmpegPath(mediaInputPath)];
        let probeError = "";
        const probeForSubs = await new Promise<string>((res2, rej2) => {
          const p = jobProcessController.spawnForJob(
            jobId,
            ffprobeExecutable,
            probeArgs,
          );
          let out = "";
          const errBuf = new BoundedOutput(64 * 1024);
          p.stdout?.on("data", (d: Buffer) => (out += d));
          p.stderr?.on("data", (d: Buffer) => errBuf.append(d));
          p.on("close", (code: number | null) => {
            const err = errBuf.toString();
            if (code === 0) res2(out);
            else
              rej2(
                new Error(
                  `ffprobe exit ${code}${err.trim() ? `: ${err.trim().slice(-400)}` : ""}`,
                ),
              );
          });
          p.on("error", rej2);
        }).catch((error: unknown) => {
          probeError = error instanceof Error ? error.message : String(error);
          return "{}";
        });
        let subStreams: Array<{
          index: number;
          streamIndex: number;
          codec: string;
          language?: string | null;
        }> = [];
        try {
          const pd = JSON.parse(probeForSubs);
          subStreams = (pd.streams ?? [])
            .filter((s: { codec_type: string }) => s.codec_type === "subtitle")
            .map(
              (
                s: {
                  index?: unknown;
                  codec_name?: unknown;
                  tags?: { language?: string };
                },
                i: number,
              ) => ({
                index: i,
                streamIndex: typeof s.index === "number" ? s.index : i,
                codec: String(s.codec_name ?? ""),
                language: s.tags?.language ?? null,
              }),
            );
        } catch {}
        if (probeError) {
          await addLog(
            jobId,
            "warn",
            `所选 DVD Title ${ocrTitleIdForProbe ?? "未知"} 的字幕流探测失败：${probeError}`,
          );
        } else {
          await addLog(
            jobId,
            "info",
            `所选 DVD Title ${ocrTitleIdForProbe ?? "默认"} 流探测结果：${subStreams.length} 条字幕轨${subStreams.length ? `（${subStreams.map((s) => s.codec).join(", ")}）` : ""}`,
          );
        }
        embeddedGraphicSubtitleDetected = subStreams.some((s) =>
          isGraphicSubtitleCodec(s.codec),
        );
        const textSubs = subStreams.filter(
          (s) => !isGraphicSubtitleCodec(s.codec),
        );
        const hasTextSub = textSubs.length > 0;
        expectedTextSubtitle = hasTextSub;

        // 双语 + 内置文字字幕：提取中文轨与外语轨直接合成双语 ASS，
        // 不再因为“已有中文字幕”而跳过/判定失败。
        if (isBilingual && hasTextSub) {
          let zhIndex: number | null = null;
          for (const sub of textSubs) {
            if (languageTagIsChinese(sub.language)) {
              zhIndex = sub.index;
              break;
            }
            const sample = await sampleEmbeddedSubtitleText(
              mediaInputPath,
              sub.index,
            );
            if (textLooksChinese(sample)) {
              zhIndex = sub.index;
              break;
            }
          }
          if (zhIndex !== null) {
            const foreignSub = textSubs.find((s) => s.index !== zhIndex);
            if (foreignSub) {
              const zhSrt = path.join(
                subtitleDirJob,
                `${subtitleStageBaseName}.zh-embedded.srt`,
              );
              const enSrt = path.join(
                subtitleDirJob,
                `${subtitleStageBaseName}.en-embedded.srt`,
              );
              try {
                await new Promise<void>((resolve, reject) => {
                  const p = jobProcessController.spawnForJob(
                    jobId,
                    ffmpegExecutable,
                    [
                      "-y",
                      "-i",
                      ffmpegPath(mediaInputPath),
                      "-map",
                      `0:s:${zhIndex}`,
                      ffmpegPath(zhSrt),
                    ],
                  );
                  p.on("close", (code) =>
                    code === 0
                      ? resolve()
                      : reject(new Error(`ffmpeg exit ${code}`)),
                  );
                  p.on("error", reject);
                });
                await new Promise<void>((resolve, reject) => {
                  const p = jobProcessController.spawnForJob(
                    jobId,
                    ffmpegExecutable,
                    [
                      "-y",
                      "-i",
                      ffmpegPath(mediaInputPath),
                      "-map",
                      `0:s:${foreignSub.index}`,
                      ffmpegPath(enSrt),
                    ],
                  );
                  p.on("close", (code) =>
                    code === 0
                      ? resolve()
                      : reject(new Error(`ffmpeg exit ${code}`)),
                  );
                  p.on("error", reject);
                });
                const bilingual = await buildBilingualSubtitle({
                  jobId,
                  mediaInputPath,
                  chineseSrtPath: zhSrt,
                  foreignSrtPath: enSrt,
                  baseName: subtitleStageBaseName,
                  style: bilingualStyle,
                  videoProbeInputArgs: dvdTitle
                    ? dvdTitleNavigationInputArgs(dvdTitle)
                    : undefined,
                  videoProbeFallbackPaths: dvdTitle?.vobFiles,
                  addLog: (level, message) => addLog(jobId, level, message),
                });
                if (bilingual) {
                  subtitlePath = enSrt;
                  translatedSubtitlePath = bilingual.assPath;
                  subtitleSourceOutcome = "bilingual";
                  bilingualDirectDone = true;
                  await addLog(
                    jobId,
                    "info",
                    `双语字幕：内置中文轨 + ${foreignSub.language ?? "外语"}轨已提取并合成 ${bilingual.assPath}`,
                  );
                }
              } catch (error) {
                await addLog(
                  jobId,
                  "warn",
                  `双语内置轨合成失败（${error instanceof Error ? error.message : String(error)}），回退常规流程`,
                );
              }
            } else {
              // 只有中文轨：提取并保留，不判定失败。
              const zhSrt = path.join(
                subtitleDirJob,
                `${subtitleStageBaseName}.zh-embedded.srt`,
              );
              try {
                await new Promise<void>((resolve, reject) => {
                  const p = jobProcessController.spawnForJob(
                    jobId,
                    ffmpegExecutable,
                    [
                      "-y",
                      "-i",
                      ffmpegPath(mediaInputPath),
                      "-map",
                      `0:s:${zhIndex}`,
                      ffmpegPath(zhSrt),
                    ],
                  );
                  p.on("close", (code) =>
                    code === 0
                      ? resolve()
                      : reject(new Error(`ffmpeg exit ${code}`)),
                  );
                  p.on("error", reject);
                });
                subtitlePath = zhSrt;
                subtitleSourceOutcome = "embedded-chinese";
                await addLog(
                  jobId,
                  "info",
                  "双语字幕：仅发现内置中文字幕轨（无外语文字轨），保留中文轨，不判定失败",
                );
              } catch (error) {
                await addLog(
                  jobId,
                  "warn",
                  `双语内置中文字幕提取失败：${error instanceof Error ? error.message : String(error)}`,
                );
              }
            }
          }
        }

        // Auto mode: if the container already has a Chinese subtitle track,
        // extraction/translation is unnecessary - keep the file untouched.
        if (shouldPreserveEmbeddedChinese(subtitleMode) && hasTextSub) {
          let chineseTypeIndex: number | null = null;
          for (const sub of textSubs) {
            if (languageTagIsChinese(sub.language)) {
              chineseTypeIndex = sub.index;
              break;
            }
            const sample = await sampleEmbeddedSubtitleText(
              mediaInputPath,
              sub.index,
            );
            if (textLooksChinese(sample)) {
              chineseTypeIndex = sub.index;
              break;
            }
          }
          if (chineseTypeIndex !== null) {
            embeddedChineseSkipped = true;
            subtitleSourceOutcome = "embedded-chinese";
            await addLog(
              jobId,
              "info",
              `检测到视频已内置中文字幕（字幕轨序号 ${chineseTypeIndex}），自动模式无需提取或翻译，跳过字幕处理`,
            );
          }
        }

        if (embeddedChineseSkipped) {
          // No extraction / translation needed.
        } else if (subStreams.length === 0) {
          await addLog(jobId, "warn", "未检测到内置字幕轨道");
        } else if (!hasTextSub) {
          // The original graphic subtitle remains inside the source media
          // even when OCR cannot produce a sidecar file.
          graphicSubtitlePreserved = embeddedGraphicSubtitleDetected;
          // Auto mode prefers OCR for graphic subtitles. A failed OCR attempt
          // must not be reinterpreted as a missing subtitle track and sent to
          // Whisper, because that loses the original cue timing/language.
          let ocrSucceeded = false;
          if (shouldOcrGraphicSubtitles(subtitleMode)) {
            const ocrTitleId = ocrTitleIdForTaskSnapshot(taskSnapshot);
            const ocrFlow = await executeOcrSubtitleFlow({
              jobId,
              mediaInputPath,
              config,
              job,
              subtitleDirJob,
              outputBaseName: subtitleStageBaseName,
              ocrTitleId,
              // 自动选择已安装的 OCR 引擎（Tesseract / RapidOCR / 大模型视觉），
              // 不要再硬编码 tesseract，否则未安装 Tesseract 时永远失败。
              engine: "auto",
              language: "auto",
              forceChineseTarget: isBilingual,
              failJobOnError: false,
              addLog: (level, message) => addLog(jobId, level, message),
            });
            if (ocrFlow.ok && ocrFlow.subtitlePath) {
              subtitlePath = ocrFlow.subtitlePath;
              translatedSubtitlePath = ocrFlow.translatedSubtitlePath;
              ocrProducedTranslation = Boolean(ocrFlow.translatedSubtitlePath);
              ocrForeignSubtitlePath = ocrFlow.foreignSubtitlePath ?? null;
              subtitleSourceOutcome = "ocr";
              ocrSucceeded = true;
            } else {
              await addLog(
                jobId,
                "warn",
                `图形字幕 OCR 未成功（${ocrFlow.error ?? "未知原因"}），保留原内置图形字幕，不转语音识别`,
              );
            }
          }
          if (!ocrSucceeded) {
            await addLog(
              jobId,
              "warn",
              `内置字幕为图形格式（${subStreams.map((s) => s.codec).join(", ")}），OCR 未产出文本；保留原格式，不改用语音识别`,
            );
          } else {
            await addLog(
              jobId,
              "info",
              subtitleOnlyTask
                ? "图形字幕 OCR 已产出文本；纯字幕任务跳过图形字幕旁车导出，原始图形字幕仍保留在源盘中"
                : "图形字幕 OCR 已产出文本；仍保留全部原始图形字幕轨",
            );
          }
          if (subtitleOnlyTask) {
            await addLog(
              jobId,
              "info",
              `纯字幕任务：跳过 ${subStreams.length} 条图形字幕旁车复制，避免逐轨导出阻塞字幕收尾`,
            );
          } else {
            let preservedCount = 0;
            for (const graphic of subStreams) {
              const outputBasePath = path.join(
                subtitleDirJob,
                `${subtitleStageBaseName}.graphic-${graphic.index}`,
              );
              const exportArgs = buildGraphicSubtitleExportArgs({
                sourceInputArgs: graphicSubtitleInputArgs,
                subtitleTypeIndex: graphic.index,
                codec: graphic.codec,
                outputBasePath,
              });
              if (!exportArgs) continue;
              const extension =
                graphic.codec === "hdmv_pgs_subtitle" ||
                graphic.codec === "pgssub" ||
                graphic.codec === "sup"
                  ? ".sup"
                  : ".mkv";
              const outputPath = `${outputBasePath}${extension}`;
              trackJobOutputFile(jobId, outputPath);
              try {
                await new Promise<void>((resolve, reject) => {
                  const ffmpeg = jobProcessController.spawnForJob(
                    jobId,
                    ffmpegExecutable,
                    exportArgs,
                  );
                  ffmpeg.on("close", (code) =>
                    code === 0
                      ? resolve()
                      : reject(new Error(`ffmpeg exit ${code}`)),
                  );
                  ffmpeg.on("error", reject);
                });
                const stat = await fs.stat(outputPath);
                if (!stat.isFile() || stat.size < 10)
                  throw new Error("FFmpeg 退出成功但未生成有效图形字幕文件");
                preservedCount += 1;
                graphicSubtitlePaths.push(outputPath);
                await addLog(
                  jobId,
                  "info",
                  `图形字幕原轨已保留：${outputPath}`,
                );
              } catch (error) {
                await fs.unlink(outputPath).catch(() => {});
                await addLog(
                  jobId,
                  "warn",
                  `图形字幕原轨导出失败（源文件内置字幕仍保留）：${error instanceof Error ? error.message : String(error)}`,
                );
              }
            }
            if (preservedCount === 0)
              await addLog(
                jobId,
                "warn",
                "未能生成图形字幕旁车文件；源文件内置字幕仍保留",
              );
          }
        } else {
          // Pick the base subtitle track by line count (cues; packets ≈ one
          // cue per line for text subs): prefer a full subtitle (first above
          // the forced/partial threshold), otherwise the one with the most
          // lines. If English is within 10% of the best line count, prefer
          // English as the base.
          const packetCounts = await probeSubtitlePacketCounts(
            mediaInputPath,
            isDvdDirectoryInput && ocrTitleIdForProbe
              ? [
                  "-f",
                  "dvdvideo",
                  "-title",
                  String(ocrTitleIdForProbe),
                  "-i",
                  dvdInputArg(dvdVideoInput),
                ]
              : undefined,
          );
          const counted: Array<{
            index: number;
            language: string | null;
            count: number;
          }> = textSubs.map((sub) => ({
            index: sub.index,
            language: sub.language ?? null,
            count: packetCounts.get(sub.streamIndex) ?? 0,
          }));
          const validTracks = counted.filter((track) => track.count > 0);
          const fullTracks = validTracks.filter(
            (track) =>
              track.count >= fullSubtitlePacketThreshold(job.durationSeconds),
          );
          const pool = fullTracks.length > 0 ? fullTracks : validTracks;
          const candidate = pool.reduce(
            (a, b) => (b.count > a.count ? b : a),
            counted[0] ?? { index: 0, language: null, count: 0 },
          );
          const englishTrack = pool.find((track) =>
            (track.language ?? "").toLowerCase().startsWith("en"),
          );
          const chosen =
            englishTrack &&
            candidate.count > 0 &&
            englishTrack.count >= candidate.count * 0.9
              ? englishTrack
              : candidate;
          // Extract candidates independently. A malformed/unsupported track
          // must not make a valid soft-subtitle track fall through to Whisper.
          const extractionOrder = [
            chosen,
            ...counted
              .filter((track) => track.index !== chosen.index)
              .sort((a, b) => b.count - a.count),
          ];
          for (
            let attempt = 0;
            attempt < extractionOrder.length && !subtitlePath;
            attempt += 1
          ) {
            const track = extractionOrder[attempt];
            const sourceTrack = textSubs.find(
              (sub) => sub.index === track.index,
            );
            const outputPath =
              attempt === 0 ? srtFile : `${srtFile}.candidate-${track.index}`;
            const streamMap = sourceTrack?.streamIndex ?? track.index;
            let stderr = "";
            try {
              await new Promise<void>((resolve, reject) => {
                const ffmpeg = jobProcessController.spawnForJob(
                  jobId,
                  ffmpegExecutable,
                  [
                    "-y",
                    "-i",
                    ffmpegPath(mediaInputPath),
                    "-map",
                    `0:${streamMap}`,
                    ffmpegPath(outputPath),
                  ],
                );
                ffmpeg.stderr?.on("data", (data: Buffer) => {
                  stderr += data.toString();
                });
                ffmpeg.on("close", (code) =>
                  code === 0
                    ? resolve()
                    : reject(new Error(`ffmpeg exit ${code}`)),
                );
                ffmpeg.on("error", reject);
              });
              const extracted = await fs
                .readFile(outputPath, "utf8")
                .catch(() => "");
              if (!hasValidSubtitleCues(extracted))
                throw new Error("输出没有有效字幕 cue");
              if (outputPath !== srtFile) await fs.rename(outputPath, srtFile);
              subtitlePath = srtFile;
              sourceSubtitleFile = srtFile;
              subtitleSourceOutcome = "embedded";
              await addLog(
                jobId,
                "info",
                `字幕已提取至 ${srtFile}（选择字幕轨 ${track.index}，源流 ${streamMap}，共 ${textSubs.length} 条文字字幕轨，包数 ${track.count}）`,
              );
            } catch (error) {
              await fs.unlink(outputPath).catch(() => {});
              await addLog(
                jobId,
                "warn",
                `字幕轨 ${track.index} 提取失败，尝试下一条软字幕：${error instanceof Error ? error.message : String(error)}${stderr.trim() ? `；${stderr.trim().slice(-300)}` : ""}`,
              );
            }
          }
          if (!subtitlePath)
            throw new Error(`所有 ${textSubs.length} 条文字字幕轨均提取失败`);
        }
      } catch (error) {
        await addLog(
          jobId,
          "warn",
          `字幕提取失败 — 跳过字幕：${error instanceof Error ? error.message : String(error)}`,
        );
      }
    }

    const whisperFallback = shouldFallbackToWhisper({
      mode: subtitleMode,
      hasEmbeddedSubs,
      hasGraphicSubs: embeddedGraphicSubtitleDetected,
      hasSubtitleOutput: Boolean(subtitlePath || translatedSubtitlePath),
      embeddedChineseSkipped,
    });
    if (whisperFallback) {
      if (hasEmbeddedSubs) {
        await addLog(
          jobId,
          "info",
          "自动模式：文字字幕提取失败，回退至 Whisper 语音识别",
        );
      } else {
        await addLog(
          jobId,
          "info",
          "自动模式：未检测到内置字幕，回退至 Whisper 语音识别",
        );
      }
    }
    const whisperRequested = whisperFallback;
    if (whisperRequested && !sourceHasAudio) {
      await addLog(jobId, "warn", "源文件没有音轨，跳过 Whisper 语音识别");
    }
    if (whisperRequested && sourceHasAudio) {
      await db
        .update(jobsTable)
        .set({ status: "transcribing", progress: 10 })
        .where(eq(jobsTable.id, jobId));
      const whisperTask = "transcribe";
      const whisperModel =
        config.whisperModel === "large" ? "large-v3" : config.whisperModel;
      await addLog(
        jobId,
        "info",
        `正在用 faster-whisper 处理音频（模型：${whisperModel} int8/CPU，语言：${config.subtitleLanguage || "自动"}，任务：${whisperTask}）`,
      );
      if (cancelledJobs.has(jobId)) return result(true);
      try {
        // Prepare the best audio source: discs are extracted to a 16k mono
        // wav (faster-whisper cannot read a DVD folder); for files the best
        // audio track is picked by language/quality scoring instead of the
        // container default (Russian dubs on track 1 are often poor).
        let whisperInput = ffmpegPath(mediaInputPath);
        let tempWavPath: string | null = null;
        const isDiscSource =
          job.mediaType === "dvd" ||
          job.mediaType === "bluray" ||
          job.mediaType === "iso";
        try {
          const audioStreams = await probeAudioTracks(
            job.mediaType === "dvd" ? dvdVideoInput : mediaInputPath,
            isDiscSource,
          );
          const best = pickBestAudioTrack(audioStreams);
          const ffmpeg = (await resolveToolPath("ffmpeg")) ?? "ffmpeg";
          if (best) {
            tempWavPath = path.join(
              os.tmpdir(),
              `vx-whisper-${jobId}-${Date.now()}.wav`,
            );
            trackJobOutputFile(jobId, tempWavPath, { temp: true });
            const inputArgs = isDiscSource
              ? [
                  "-v",
                  "error",
                  "-y",
                  "-f",
                  "dvdvideo",
                  "-i",
                  dvdInputArg(
                    job.mediaType === "dvd" ? dvdVideoInput : mediaInputPath,
                  ),
                  "-map",
                  `0:a:${best.typeIndex}`,
                  "-vn",
                  "-ac",
                  "1",
                  "-ar",
                  "16000",
                  tempWavPath,
                ]
              : [
                  "-v",
                  "error",
                  "-y",
                  "-i",
                  ffmpegPath(mediaInputPath),
                  "-map",
                  `0:a:${best.typeIndex}`,
                  "-vn",
                  "-ac",
                  "1",
                  "-ar",
                  "16000",
                  tempWavPath,
                ];
            await new Promise<void>((resolve, reject) => {
              const proc = jobProcessController.spawnForJob(
                jobId,
                ffmpeg,
                inputArgs,
              );
              proc.on("close", (code) =>
                code === 0
                  ? resolve()
                  : reject(new Error(`音频提取失败 ffmpeg exit ${code}`)),
              );
              proc.on("error", reject);
            });
            whisperInput = tempWavPath;
            await addLog(
              jobId,
              "info",
              `选用音轨 ${best.typeIndex + 1}（${best.language ?? "无标记"} · ${best.codec ?? "?"} · ${best.channels ?? "?"}ch）→ ${tempWavPath}`,
            );
          } else {
            await addLog(jobId, "warn", "未探测到音轨，使用源输入直接转写");
          }
        } catch (error) {
          await addLog(
            jobId,
            "warn",
            `音轨准备失败（回退源输入）：${error instanceof Error ? error.message : String(error)}`,
          );
        }
        const whisperExecutable = await resolveToolPath("whisper");
        if (!whisperExecutable)
          throw new Error(
            "Whisper 未安装或不可执行。请先在工具管理器安装 Whisper 环境和模型。",
          );
        const whisperScript = await ensureWhisperCliScript();
        const whisperModelDir = await ensureFasterWhisperModel(
          whisperModel,
          async (message) => addLog(jobId, "info", message),
        );
        await addLog(
          jobId,
          "info",
          `faster-whisper 执行：${whisperExecutable} ${whisperScript}（模型 ${whisperModelDir}）`,
        );
        let whisperErrOut = "";
        // The detected language is printed early, before the long progress
        // stream, so capture it as it arrives while keeping only a bounded
        // tail of stderr for error reporting.
        let whisperDetectedLang: string | null = null;
        await new Promise<void>((resolve, reject) => {
          const whisper = jobProcessController.spawnForJob(
            jobId,
            whisperExecutable,
            [
              whisperScript,
              whisperInput,
              "--model",
              whisperModelDir,
              "--device",
              "cpu",
              "--compute_type",
              "int8",
              "--output_format",
              "srt",
              "--output_dir",
              subtitleDirJob,
              ...(config.subtitleLanguage && config.subtitleLanguage !== "auto"
                ? ["--language", config.subtitleLanguage]
                : []),
              "--task",
              whisperTask,
            ],
            config.processHighPriority ?? false,
          );
          whisper.stderr?.on("data", async (d: Buffer) => {
            const textChunk = d.toString();
            whisperErrOut = (whisperErrOut + textChunk).slice(-65536);
            if (!whisperDetectedLang)
              whisperDetectedLang = whisperDetectedLanguage(textChunk);
            const pctMatch = textChunk.match(/(\d+)%\|/);
            if (pctMatch) {
              const pct = parseInt(pctMatch[1], 10);
              await db
                .update(jobsTable)
                .set({ progress: 10 + pct * 0.8 })
                .where(eq(jobsTable.id, jobId));
            }
          });
          whisper.on("close", (code) =>
            code === 0
              ? resolve()
              : reject(
                  new Error(
                    `whisper exit ${code}: ${whisperErrOut.slice(-400)}`,
                  ),
                ),
          );
          whisper.on("error", reject);
        });
        const detectedLang =
          whisperDetectedLang ?? whisperDetectedLanguage(whisperErrOut);
        sourceLang = detectedLang;
        const sourceSrtPath = detectedLang
          ? path.join(
              subtitleDirJob,
              `${subtitleStageBaseName}.${detectedLang}.srt`,
            )
          : srtFile;
        if (tempWavPath) {
          // The wrapper names the SRT after the wav file; relocate it to the
          // job's standard name.
          const wavBase = path.basename(tempWavPath, ".wav");
          const written = (
            await fs.readdir(subtitleDirJob).catch((): string[] => [])
          ).find(
            (name) => name.startsWith(`${wavBase}.`) && name.endsWith(".srt"),
          );
          if (
            written &&
            path.resolve(path.join(subtitleDirJob, written)) !==
              path.resolve(sourceSrtPath)
          ) {
            try {
              await fs.rename(
                path.join(subtitleDirJob, written),
                sourceSrtPath,
              );
            } catch {
              /* leave as-is */
            }
          }
        } else {
          try {
            await fs.rename(srtFile, sourceSrtPath);
          } catch {
            /* may already be named */
          }
        }
        if (tempWavPath) await fs.unlink(tempWavPath).catch(() => {});
        // 语音识别必须真的产出内容；空 SRT 会让后续步骤生成空的中文字幕文件，
        // 这里直接判定失败，避免任务“看似成功”却只有空字幕。
        const transcribedSrt = await fs
          .readFile(sourceSrtPath, "utf-8")
          .catch(() => "");
        if (parseSrt(transcribedSrt.replace(/\r\n/g, "\n")).length === 0) {
          await fs.unlink(sourceSrtPath).catch(() => {});
          whisperProducedEmpty = true;
          throw new Error(
            `语音识别未产生有效字幕（${sourceSrtPath} 为空或缺失）`,
          );
        }
        subtitlePath = sourceSrtPath;
        sourceSubtitleFile = sourceSrtPath;
        await addLog(
          jobId,
          "info",
          `转录完成：${sourceSrtPath}${detectedLang ? "（检测语言 " + detectedLang + "）" : ""}`,
        );
      } catch (e) {
        await addLog(jobId, "warn", `Whisper 转录失败：${String(e)}`);
      }
    }

    // 语音识别（whisper）任务：AI 纠错 → 简体中文 .zhs.srt
    if (subtitleMode === "whisper" && subtitlePath) {
      await addLog(
        jobId,
        "info",
        "【AI 纠错】语音识别完成，开始 AI 纠错（修正识别错误 + 简体中文）…",
      );
      const apiKey = resolveApiKey(config);
      if (!apiKey && config.aiProvider !== "libretranslate") {
        await addLog(
          jobId,
          "warn",
          "AI 纠错未配置 API Key — 跳过纠错，保留原始识别字幕",
        );
      } else if (config.aiProvider === "libretranslate") {
        await addLog(
          jobId,
          "warn",
          "本地 LibreTranslate 不支持 AI 纠错 — 跳过纠错，保留原始识别字幕",
        );
      } else {
        try {
          let srtContent = await fs.readFile(subtitlePath, "utf-8");
          srtContent = srtContent.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
          const blocks = parseSrt(srtContent);
          if (blocks.length === 0) {
            await addLog(jobId, "warn", "语音识别字幕为空，跳过纠错");
          } else {
            const isChineseSource = /^(zh|zh-cn|zh-tw|yue)/i.test(
              sourceLang ?? "",
            );
            await addLog(
              jobId,
              "info",
              `共 ${blocks.length} 条字幕，AI 纠错 → 简体中文（源语种 ${sourceLang ?? "未知"}）`,
            );
            const correctedPath = path.join(
              subtitleDirJob,
              `${subtitleStageBaseName}.zhs.srt`,
            );
            const correctedBlocks: SrtBlock[] = [];
            const BATCH = 40;
            const { baseUrl, model } = resolveAiEndpoint(config);
            const systemPrompt = buildWhisperCorrectionPrompt(
              job,
              isChineseSource,
              sourceLang,
            );
            for (let i = 0; i < blocks.length; i += BATCH) {
              const batch = blocks.slice(i, i + BATCH);
              const pct = Math.round((i / blocks.length) * 100);
              await addLog(
                jobId,
                "info",
                `纠错进度 ${pct}%（${i + 1}–${Math.min(i + BATCH, blocks.length)} / ${blocks.length}）`,
              );
              const corrected = await translateBatch(
                batch.map((b) => b.text),
                systemPrompt,
                apiKey!,
                baseUrl,
                model,
                await getAiProxyUrl(),
              );
              for (let j = 0; j < batch.length; j++)
                correctedBlocks.push({
                  ...batch[j],
                  text: corrected[j] || batch[j].text,
                });
            }
            await fs.writeFile(
              correctedPath,
              renderSrtSimplified(correctedBlocks, true),
              "utf-8",
            );
            translatedSubtitlePath = correctedPath;
            await addLog(jobId, "info", `AI 纠错完成 → ${correctedPath}`);
          }
        } catch (e) {
          await addLog(jobId, "warn", `AI 纠错失败：${String(e)}`);
        }
      }
    }

    // "识别+AI翻译" mode: run AI translation immediately after Whisper.
    // 若 OCR 流程已产出中文译文（含外文参考纠错），则跳过通用翻译，避免
    // 用原始 OCR 文本重译覆盖纠错结果并重复调用 LLM。
    if (
      shouldTranslateSubtitleText({
        mode: subtitleMode,
        hasSubtitle: Boolean(subtitlePath),
      }) &&
      subtitlePath &&
      !externalChineseBilingualSource &&
      !ocrProducedTranslation
    ) {
      await addLog(jobId, "info", "【AI 翻译】识别完成，开始 AI 字幕翻译…");
      const apiKey = resolveApiKey(config);
      if (!apiKey && config.aiProvider !== "libretranslate") {
        explicitTranslationError = "未配置当前 AI 提供商的 API Key";
        await addLog(
          jobId,
          "error",
          "AI 翻译未配置 API Key — 请在设置中填写 API Key",
        );
      } else {
        try {
          let srtContent = await fs.readFile(subtitlePath, "utf-8");
          srtContent = srtContent.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
          const blocks = parseSrt(srtContent);
          if (blocks.length === 0) {
            explicitTranslationError = "字幕文件无法解析（格式异常或内容为空）";
            await addLog(jobId, "error", explicitTranslationError);
          } else {
            const effectiveTargetLang = isBilingual
              ? "zh-CN"
              : config.translationTargetLang;
            await addLog(
              jobId,
              "info",
              `共 ${blocks.length} 条字幕，目标语言：${effectiveTargetLang}${isBilingual ? "（双语任务固定简体中文）" : ""}；翻译引擎：${config.aiProvider === "libretranslate" ? "LibreTranslate（本地）" : config.aiProvider || "OpenAI 兼容 LLM"}`,
            );
            const translatedPath = path.join(
              subtitleDirJob,
              `${subtitleStageBaseName}.zhs.srt`,
            );
            const translatedBlocks: SrtBlock[] = [];
            const BATCH = 40;

            // "转录+翻译" 使用用户选择的 AI 提供商；只有明确选择
            // LibreTranslate 时才走本地翻译服务。此前把模式本身当成
            // LibreTranslate 开关，导致 DeepSeek 配置实际请求不存在的
            // http://libretranslate:5000。
            if (config.aiProvider === "libretranslate") {
              const ltUrl =
                config.libreTranslateUrl || "http://libretranslate:5000";
              const tgtLang = effectiveTargetLang.split("-")[0];
              for (let i = 0; i < blocks.length; i += BATCH) {
                const batch = blocks.slice(i, i + BATCH);
                const pct = Math.round((i / blocks.length) * 100);
                await addLog(
                  jobId,
                  "info",
                  `本地翻译进度 ${pct}%（${i + 1}–${Math.min(i + BATCH, blocks.length)} / ${blocks.length}）`,
                );
                await db
                  .update(jobsTable)
                  .set({
                    progress: mapExternalToolProgress({
                      toolPercent: pct,
                      start: 50,
                      end: 95,
                    }),
                  })
                  .where(eq(jobsTable.id, jobId));
                const translated = await translateBatchLibre(
                  batch.map((b) => b.text),
                  "en",
                  tgtLang,
                  ltUrl,
                );
                for (let j = 0; j < batch.length; j++) {
                  translatedBlocks.push({
                    ...batch[j],
                    text: translated[j] || batch[j].text,
                  });
                }
              }
            } else {
              const { baseUrl, model } = resolveAiEndpoint(config);
              const systemPrompt = await buildTranslationPrompt(
                job,
                config,
                effectiveTargetLang,
                sourceLang,
              );
              for (let i = 0; i < blocks.length; i += BATCH) {
                const batch = blocks.slice(i, i + BATCH);
                const pct = Math.round((i / blocks.length) * 100);
                await addLog(
                  jobId,
                  "info",
                  `翻译进度 ${pct}%（${i + 1}–${Math.min(i + BATCH, blocks.length)} / ${blocks.length}）`,
                );
                const translated = await translateBatch(
                  batch.map((b) => b.text),
                  systemPrompt,
                  apiKey!,
                  baseUrl,
                  model,
                  await getAiProxyUrl(),
                );
                for (let j = 0; j < batch.length; j++) {
                  translatedBlocks.push({
                    ...batch[j],
                    text: translated[j] || batch[j].text,
                  });
                }
              }
            }

            await fs.writeFile(
              translatedPath,
              renderSrtSimplified(
                translatedBlocks,
                effectiveTargetLang.startsWith("zh-CN"),
              ),
              "utf-8",
            );
            translatedSubtitlePath = translatedPath;
            await addLog(jobId, "info", `AI 翻译完成 → ${translatedPath}`);
          }
        } catch (e) {
          explicitTranslationError = e instanceof Error ? e.message : String(e);
          await addLog(
            jobId,
            "error",
            `AI 翻译失败：${explicitTranslationError}`,
          );
        }
      }
    }

    // 双语字幕组装必须在公共路径执行：无论任务后续是否还有视频处理
    // （纯字幕 / Remux / 压缩流水线），都要产出合并后的 ASS 文件。
    // 此前该步骤只在 processingMode === "none" 里运行，导致
    // “双语字幕 + Remux”的任务只留下 OCR 英文和中文翻译两个 SRT，
    // 没有生成双语 ASS。
    if (
      isBilingual &&
      !bilingualDirectDone &&
      subtitleSourceOutcome !== "embedded-chinese" &&
      translatedSubtitlePath
    ) {
      const bilingual = await buildBilingualSubtitle({
        jobId,
        mediaInputPath,
        chineseSrtPath: translatedSubtitlePath,
        // 有翻译（中文）产出时，subtitlePath 通常是原文（如 OCR 英文 SRT），
        // 作为双语的外文侧备用来源。
        // The raw OCR artifact may itself be Chinese. Only pass a verified
        // foreign-language reference (DVD reference OCR or foreign OCR) so
        // we cannot render two Chinese lines as a “bilingual” subtitle.
        foreignSrtPath:
          subtitleSourceOutcome === "ocr"
            ? ocrForeignSubtitlePath
            : subtitlePath,
        // 用管道输出基名（与 remux/compress 产出同名），保证 .ass 与视频输出文件同名。
        baseName: subtitleStageBaseName,
        style: bilingualStyle,
        addLog: (level, message) => addLog(jobId, level, message),
        videoProbeInputArgs: dvdTitle
          ? dvdTitleNavigationInputArgs(dvdTitle)
          : undefined,
        videoProbeFallbackPaths: dvdTitle?.vobFiles,
      });
      if (bilingual) {
        translatedSubtitlePath = bilingual.assPath;
        subtitleSourceOutcome = "bilingual";
      }
    }

    if (job.processingMode === "none") {
      const translationFailure = explicitTranslationFailureMessage({
        mode: subtitleMode,
        translatedOutput: Boolean(translatedSubtitlePath),
        error: explicitTranslationError,
      });
      if (translationFailure) {
        const message = `字幕翻译失败：${translationFailure}`;
        await db
          .update(jobsTable)
          .set({
            status: "error",
            progress: 100,
            subtitlePath: sourceSubtitleFile ?? subtitlePath,
            translatedSubtitlePath: null,
            subtitleSource: subtitleSourceOutcome,
            errorMessage: message,
            completedAt: new Date(),
          })
          .where(eq(jobsTable.id, jobId));
        await addLog(jobId, "error", message);
        return result(true);
      }
      const hasSubtitleOutput = Boolean(
        sourceSubtitleFile ?? subtitlePath ?? translatedSubtitlePath,
      );
      const bilingualStat =
        isBilingual &&
        translatedSubtitlePath &&
        /\.ass$/i.test(translatedSubtitlePath)
          ? await fs.stat(translatedSubtitlePath).catch(() => null)
          : null;
      const hasBilingualOutput = Boolean(
        bilingualStat?.isFile() && bilingualStat.size > 0,
      );
      const outputDisposition = subtitleOnlyOutputDisposition({
        hasSubtitleOutput,
        hasBilingualOutput,
        sourceHasAudio,
        whisperProducedEmpty,
        graphicSubtitlePreserved,
        expectedTextSubtitle,
        requestedMode: job.subtitleMode,
      });
      // A requested bilingual sidecar is not complete until the merged ASS
      // exists. Auto mode may still complete with embedded graphic subtitles
      // preserved in the source when OCR is unavailable.
      if (outputDisposition === "error" && job.subtitleMode !== "skip") {
        const message = isBilingual
          ? "双语字幕生成失败：未生成有效的双语字幕文件（OCR、翻译或字幕合成未成功）"
          : "字幕处理失败：未生成任何字幕输出（OCR / 语音识别均未成功）";
        await db
          .update(jobsTable)
          .set({
            status: "error",
            progress: 100,
            subtitlePath: sourceSubtitleFile ?? subtitlePath,
            translatedSubtitlePath: hasBilingualOutput
              ? translatedSubtitlePath
              : null,
            subtitleSource: subtitleSourceOutcome,
            errorMessage: message,
            completedAt: new Date(),
          })
          .where(eq(jobsTable.id, jobId));
        await addLog(jobId, "error", message);
        return result(true);
      }
      await db
        .update(jobsTable)
        .set({
          status: "done",
          progress: 100,
          subtitlePath: sourceSubtitleFile ?? subtitlePath,
          translatedSubtitlePath,
          subtitleSource: subtitleSourceOutcome,
          completedAt: new Date(),
          // 双语字幕把 ASS 输出写入 outputPath，任务队列“打开输出文件夹”可直接定位。
          ...(isBilingual && translatedSubtitlePath
            ? { outputPath: translatedSubtitlePath }
            : {}),
        })
        .where(eq(jobsTable.id, jobId));
      const savedSubtitlePaths = [subtitlePath, translatedSubtitlePath].filter(
        (value): value is string => Boolean(value),
      );
      await addLog(
        jobId,
        "info",
        savedSubtitlePaths.length > 0
          ? `只处理字幕完成 — 已保存至 ${savedSubtitlePaths.join("；")}`
          : "只处理字幕完成（无字幕输出）",
      );
      await settlePreviewTaskSafely(jobId, {
        taskKind: "subtitle",
        outputValid: hasSubtitleOutput,
        isPreviewOnly: false,
        cancelled: false,
      });
      return result(true);
    }
    await addLog(
      jobId,
      "info",
      `字幕步骤完成${subtitlePath ? " — 继续视频处理并使用 " + subtitlePath : " — 继续视频处理"}`,
    );
  }
  // ── END SUBTITLE-ONLY MODES ───────────────────────────────────────────────

  if (cancelledJobs.has(jobId)) return result(true);
  if (job.processingMode === "none") {
    // A verified subtitle-only snapshot is executable even if the legacy
    // processingMode field is `none`. Some older tasks can miss the earlier
    // subtitle-only completion branch; do not turn successfully written OCR
    // files into a failed job at this final guard.
    const completedSubtitlePath =
      sourceSubtitleFile ?? subtitlePath ?? translatedSubtitlePath;
    if (subtitleOnlyTask && completedSubtitlePath) {
      await db
        .update(jobsTable)
        .set({
          status: "done",
          progress: 100,
          subtitlePath: sourceSubtitleFile ?? subtitlePath,
          translatedSubtitlePath,
          subtitleSource: subtitleSourceOutcome,
          ...(isBilingual && translatedSubtitlePath
            ? { outputPath: translatedSubtitlePath }
            : {}),
          errorMessage: null,
          completedAt: new Date(),
        })
        .where(eq(jobsTable.id, jobId));
      await addLog(
        jobId,
        "info",
        `只处理字幕完成 — 已保存至 ${[subtitlePath, translatedSubtitlePath].filter((value): value is string => Boolean(value)).join("；") || completedSubtitlePath}`,
      );
      await settlePreviewTaskSafely(jobId, {
        taskKind: "subtitle",
        outputValid: true,
        isPreviewOnly: false,
        cancelled: false,
      });
      return result(true);
    }
    const message =
      "未选择可执行的处理方式：请先选择 Remux、压缩或字幕处理；本次任务未生成输出文件";
    await db
      .update(jobsTable)
      .set({
        status: "error",
        progress: 100,
        errorMessage: message,
        completedAt: new Date(),
      })
      .where(eq(jobsTable.id, jobId));
    await addLog(jobId, "error", message);
    return result(true);
  }
  return result(false);
}
