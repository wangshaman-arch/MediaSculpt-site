// Extracted from disc-analysis.ts: DVD analysis (HandBrake scan, IFO/PGC navigation,
// ffprobe title verification and the title-only ffprobe fallback).
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import path from "node:path";
import {
  findDvdTitles,
  dvdTitleInputArgs,
  resolveDvdVideoTsDir,
  type DvdTitle,
} from "./disc";
import { resolveToolPath } from "./tool-runtime";
import { analyzeDvdWithHandBrake, verifyDvdTitle } from "./dvd-remux";
import { buildDvdStreamUid, buildDvdTitleUid } from "./dvd-manifest";
import { parseDvdNavigation, type DvdNavigationTitle } from "./dvd-ifo-parser";
import {
  safeNumber,
  MIN_DISC_TITLE_SECONDS,
  consolidateDiscTitles,
  measureDvdSourceBytes,
  persistDiscAnalysisDiagnostics,
  buildDiscAnalysisId,
  type DiscAnalysisTrackType,
  type DiscAnalysisStream,
  type DiscAnalysisChapter,
  type DiscToolDiagnostic,
  type UnifiedDiscTitle,
  type DiscAnalysisResult,
  type DiscAnalysisInput,
} from "./disc-analysis-shared";

const execFileAsync = promisify(execFile);
const MAX_TOOL_BUFFER = 32 * 1024 * 1024;
/** Resolve the VIDEO_TS folder for a disc root (accepts the root or the folder itself). */
function findVideoTsDirSync(discRoot: string): string {
  return /[\\/]VIDEO_TS$/i.test(discRoot)
    ? discRoot
    : path.join(discRoot, "VIDEO_TS");
}

/**
 * Fallback for DVDs that HandBrakeCLI cannot parse to a usable title set.
 * Probe the logical dvdvideo title namespace directly. VTS_XX is a physical
 * title-set number and must never be passed as a logical -title value.
 * Only runs when HandBrakeCLI returned no usable title, so discs that
 * HandBrakeCLI parses successfully are left completely untouched.
 */
export async function analyzeDvdWithFfprobeFallback(
  discRoot: string,
  sourceFingerprint: string,
): Promise<{
  titles: UnifiedDiscTitle[];
  diagnostic: DiscToolDiagnostic | null;
}> {
  const ffprobe = (await resolveToolPath("ffprobe")) ?? "ffprobe";
  const dvdTitles = Array.from({ length: 32 }, (_v, index) => ({
    titleNumber: index + 1,
    discRoot,
    videoTsDir: findVideoTsDirSync(discRoot),
    ifoPath: "",
    vobFiles: [] as string[],
    sizeBytes: 0,
  }));
  const titles: UnifiedDiscTitle[] = [];
  let representative: DiscToolDiagnostic | null = null;
  for (const dvd of dvdTitles) {
    if (dvd.titleNumber <= 0) continue;
    const args = [
      "-v",
      "error",
      "-show_streams",
      "-show_format",
      "-show_chapters",
      "-print_format",
      "json",
      ...dvdTitleInputArgs(dvd),
    ];
    const startedAt = new Date();
    let stdout = "";
    let stderr = "";
    let exitCode: number | null = null;
    try {
      const result = await execFileAsync(ffprobe, args, {
        timeout: 60_000,
        maxBuffer: MAX_TOOL_BUFFER,
        windowsHide: true,
      });
      stdout = String(result.stdout ?? "");
      stderr = String(result.stderr ?? "");
      exitCode = 0;
    } catch (error) {
      const e = error as { code?: unknown; stdout?: unknown; stderr?: unknown };
      exitCode = typeof e.code === "number" ? e.code : null;
      stdout = String(e.stdout ?? "");
      stderr = String(e.stderr ?? "");
    }
    if (!representative) {
      representative = {
        tool: "ffprobe",
        executable: ffprobe,
        args,
        startedAt: startedAt.toISOString(),
        finishedAt: new Date().toISOString(),
        durationMs: Date.now() - startedAt.getTime(),
        exitCode,
        stdout,
        stderr,
        failureReason: exitCode === 0 ? null : "ffprobe dvdvideo 探测失败",
      };
    }
    if (exitCode !== 0) continue;
    const info = (() => {
      try {
        return JSON.parse(stdout) as {
          streams?: Array<Record<string, unknown>>;
          format?: { duration?: string };
          chapters?: Array<Record<string, unknown>>;
        };
      } catch {
        return {};
      }
    })();
    const rawStreams: DiscAnalysisStream[] = (info.streams ?? []).map((s) => ({
      index: Number(s.index),
      codecType: ["video", "audio", "subtitle"].includes(String(s.codec_type))
        ? (String(s.codec_type) as DiscAnalysisTrackType)
        : "unknown",
      codecName: s.codec_name != null ? String(s.codec_name) : null,
      profile: s.profile != null ? String(s.profile) : null,
      language:
        (s.tags as Record<string, unknown> | undefined)?.language != null
          ? String((s.tags as Record<string, unknown>).language)
          : null,
      title:
        (s.tags as Record<string, unknown> | undefined)?.title != null
          ? String((s.tags as Record<string, unknown>).title)
          : null,
      width: s.width != null ? Number(s.width) : null,
      height: s.height != null ? Number(s.height) : null,
      channels: s.channels != null ? Number(s.channels) : null,
      channelLayout: s.channel_layout != null ? String(s.channel_layout) : null,
      sampleRate: s.sample_rate != null ? Number(s.sample_rate) : null,
      frameRate: s.avg_frame_rate != null ? String(s.avg_frame_rate) : null,
      ...(s.bits_per_raw_sample != null
        ? { bitsPerRawSample: Number(s.bits_per_raw_sample) }
        : {}),
    }));
    const titleUid = buildDvdTitleUid({
      sourceFingerprint,
      handbrakeTitleNumber: dvd.titleNumber,
    });
    const streams = rawStreams.map((stream, index) => ({
      ...stream,
      trackUid: buildDvdStreamUid({
        titleUid,
        type: stream.codecType === "unknown" ? "video" : stream.codecType,
        ordinal: rawStreams
          .slice(0, index)
          .filter((candidate) => candidate.codecType === stream.codecType)
          .length,
        codecName: stream.codecName,
        language: stream.language,
        channels: stream.channels,
      }),
    }));
    const duration =
      info.format?.duration != null ? safeNumber(info.format.duration) : null;
    const chapters: DiscAnalysisChapter[] = (info.chapters ?? []).map(
      (c, i) => ({
        id: Number(c.id ?? i + 1),
        startSeconds: safeNumber(c.start_time) ?? 0,
        endSeconds: safeNumber(c.end_time) ?? safeNumber(c.start_time) ?? 0,
        title:
          (c.tags as Record<string, unknown> | undefined)?.title != null
            ? String((c.tags as Record<string, unknown>).title)
            : null,
      }),
    );
    // dvdvideo title numbers are global logical PGC numbers; they are not VTS
    // file-group numbers. Do not pair a fallback title with VTS_NN merely
    // because the numeric values happen to be equal.
    const previewSourcePath = null;
    if (
      !duration ||
      duration < MIN_DISC_TITLE_SECONDS ||
      !streams.some((stream) => stream.codecType === "video")
    )
      continue;
    titles.push({
      titleId: `dvd-title:${dvd.titleNumber}`,
      titleUid,
      titleIndex: titles.length,
      sourcePath: discRoot,
      titleKind: null,
      previewSourcePath,
      displayName: `Title ${titles.length + 1}`,
      durationSeconds: duration,
      chapterCount: chapters.length,
      chapters,
      videoTracks: streams.filter((stream) => stream.codecType === "video"),
      audioTracks: streams.filter((stream) => stream.codecType === "audio"),
      subtitleTracks: streams.filter(
        (stream) => stream.codecType === "subtitle",
      ),
      estimatedSize: null,
      streams,
      toolMappings: {
        handbrakeTitleNumber: dvd.titleNumber,
        makemkvTitleIndex: null,
        dvdVtsNumber: null,
      },
      mappingStatus: "not-required",
      verificationStatus: "pending",
      verificationFailureReason: null,
    });
  }
  return { titles, diagnostic: representative };
}

export async function analyzeDvdDiscSource(
  input: DiscAnalysisInput,
): Promise<DiscAnalysisResult> {
  const handbrakeExecutable =
    input.handbrakeCliPath || (await resolveToolPath("handbrake"));
  const analysisId = buildDiscAnalysisId(input);
  if (!handbrakeExecutable) {
    const now = new Date().toISOString();
    const diagnostics: DiscToolDiagnostic[] = [
      {
        tool: "handbrake",
        executable: null,
        args: ["--input", input.sourcePath, "--title", "0", "--scan", "--json"],
        startedAt: now,
        finishedAt: now,
        durationMs: 0,
        exitCode: null,
        stdout: "",
        stderr: "",
        failureReason: "HandBrakeCLI 未安装或不可执行",
      },
    ];
    const diagnosticLogPath = await persistDiscAnalysisDiagnostics(
      analysisId,
      diagnostics,
    ).catch(() => null);
    return {
      analysisId,
      sourcePath: input.sourcePath,
      sourceFingerprint: input.sourceFingerprint,
      mediaType: "dvd",
      createdAt: now,
      titles: [],
      exportCandidates: [],
      diagnostics,
      diagnosticLogPath,
      warnings: ["DVD 初始分析需要 HandBrakeCLI；本轮未调用 ffprobe 兜底。"],
    };
  }
  const startedAt = new Date();
  const result = await analyzeDvdWithHandBrake({
    sourcePath: input.sourcePath,
    sourceFingerprint: input.sourceFingerprint,
    handbrakeExecutable,
    run: input.toolRunner,
  });
  const finishedAt = new Date();
  const diagnostics: DiscToolDiagnostic[] = [
    {
      tool: "handbrake",
      executable: result.diagnostic.executable,
      args: result.diagnostic.args,
      startedAt: startedAt.toISOString(),
      finishedAt: finishedAt.toISOString(),
      durationMs: result.diagnostic.durationMs,
      exitCode: result.diagnostic.exitCode,
      stdout: result.diagnostic.stdout,
      stderr: result.diagnostic.stderr,
      failureReason: result.diagnostic.failureReason,
    },
  ];
  // DVD titles have no per-file preview source (ffprobe cannot open a
  // VIDEO_TS directory). Use the largest title's VOB set via the concat
  // protocol so the preview can extract real frames from the movie.
  // Type the fallback explicitly: a bare `() => []` infers `never[]`, which
  // makes the union `DvdTitle[] | never[]` collapse the `.find()` callback
  // parameter to `never` (TS2339 on the line below).
  const dvdVts: DvdTitle[] = await findDvdTitles(input.sourcePath).catch(
    () => [] as DvdTitle[],
  );
  const mainVts =
    dvdVts.slice().sort((a, b) => b.sizeBytes - a.sizeBytes)[0] ?? null;
  const dvdPreviewSourceForVts = (vtsNumber: number | null | undefined) => {
    const vts =
      typeof vtsNumber === "number"
        ? dvdVts.find((candidate) => candidate.titleNumber === vtsNumber)
        : null;
    const files = vts?.vobFiles ?? mainVts?.vobFiles ?? [];
    return files.length > 0
      ? `concat:${files.map((file) => file.replace(/\\/g, "/")).join("|")}`
      : null;
  };
  const dvdPreviewSource = dvdPreviewSourceForVts(null);
  const warnings: string[] = [];
  warnings.push(...(result.warnings ?? []));
  for (const title of dvdVts) {
    if (title.missingVobFiles?.length) {
      warnings.push(
        `光盘文件不完整：VIDEO_TS 缺少 ${title.missingVobFiles.join("、")}，` +
          `该光盘标题将在缺失文件处提前截断。请重新抓轨，或改用完整的 ISO 镜像处理。`,
      );
    }
  }
  const sourceSizeBytes = await measureDvdSourceBytes(input.sourcePath);
  // Do not collapse DVD titles by duration/chapter/stream signatures before
  // reading IFO/PGC/Cell navigation. Two independent physical clips can be
  // intentionally identical at the stream level; physical Cell ranges are
  // the only safe duplicate key for DVD titles.
  const titles: UnifiedDiscTitle[] = consolidateDiscTitles(
    result.titles.map((title) => {
      const titleNumber = title.toolMappings.handbrakeTitleNumber;
      const titleUid = buildDvdTitleUid({
        sourceFingerprint: input.sourceFingerprint,
        handbrakeTitleNumber: titleNumber,
      });
      const streams = title.streams.map((stream, index) => ({
        ...stream,
        ...(stream.codecType !== "unknown"
          ? {
              trackUid: buildDvdStreamUid({
                titleUid,
                type: stream.codecType,
                ordinal: title.streams
                  .slice(0, index)
                  .filter(
                    (candidate) => candidate.codecType === stream.codecType,
                  ).length,
                codecName: stream.codecName,
                language: stream.language,
                channels: stream.channels,
              }),
            }
          : {}),
      }));
      return {
        ...title,
        titleUid,
        streams,
        videoTracks: streams.filter((stream) => stream.codecType === "video"),
        audioTracks: streams.filter((stream) => stream.codecType === "audio"),
        subtitleTracks: streams.filter(
          (stream) => stream.codecType === "subtitle",
        ),
        availabilityStatus: title.availabilityStatus ?? "confirmed",
        availabilityFailureReason: title.availabilityFailureReason ?? null,
        previewSourcePath: dvdPreviewSource,
        verificationStatus:
          title.availabilityStatus === "unavailable"
            ? ("failed" as const)
            : ("pending" as const),
        verificationFailureReason: title.availabilityFailureReason ?? null,
        mappingStatus: "unmapped" as const,
      };
    }),
    (message) => warnings.push(message),
    { preserveAll: true },
  );
  // The only authoritative DVD title identity is VMG title -> VTS TTN ->
  // PGC -> Cell. HandBrake remains the stream probe, but duration-based or
  // VTS-size-based title matching is forbidden because one VTS can contain
  // several different PGCs (or the same chain repeated with different names).
  const videoTsDir =
    (await resolveDvdVideoTsDir(input.sourcePath)) ?? input.sourcePath;
  let navigationTitles: DvdNavigationTitle[] = [];
  try {
    navigationTitles = await parseDvdNavigation(videoTsDir);
  } catch (error) {
    warnings.push(
      `DVD IFO/PGC 导航解析失败：${error instanceof Error ? error.message : String(error)}；已停止使用猜测式容量和物理标题映射`,
    );
  }
  if (navigationTitles.length > 0) {
    const navigationByTitle = new Map(
      navigationTitles.map((navigation) => [
        navigation.globalTitleNumber,
        navigation,
      ]),
    );
    const mappedTitles: UnifiedDiscTitle[] = [];
    const seenPhysicalChains = new Set<string>();
    let unmappedCount = 0;
    let duplicateCount = 0;
    for (const title of titles) {
      const titleNumber = title.toolMappings.handbrakeTitleNumber;
      const navigation = titleNumber
        ? navigationByTitle.get(titleNumber)
        : undefined;
      if (
        !navigation ||
        navigation.sizeBytes <= 0 ||
        navigation.physicalRanges.length === 0
      ) {
        unmappedCount += 1;
        continue;
      }
      const chainKey = navigation.physicalRanges
        .map((range) => `${range.path}:${range.startSector}-${range.endSector}`)
        .sort()
        .join("|");
      if (seenPhysicalChains.has(chainKey)) {
        duplicateCount += 1;
        continue;
      }
      seenPhysicalChains.add(chainKey);
      title.toolMappings.physicalVtsNumber = navigation.vtsNumber;
      title.previewSourcePath = dvdPreviewSourceForVts(navigation.vtsNumber);
      title.estimatedSize = navigation.sizeBytes;
      title.physicalRanges = navigation.physicalRanges.map((range) => ({
        path: range.path,
        startByte: range.startByte,
        endByte: range.endByte,
      }));
      title.mappingStatus = "not-required";
      if (navigation.durationSeconds != null) {
        if (
          title.durationSeconds != null &&
          Math.abs(title.durationSeconds - navigation.durationSeconds) > 5
        ) {
          warnings.push(
            `DVD Title ${titleNumber} 的 HandBrake 时长与 IFO/PGC 时长相差 ${Math.abs(title.durationSeconds - navigation.durationSeconds).toFixed(1)} 秒；已采用 IFO/PGC 时长`,
          );
        }
        title.durationSeconds = navigation.durationSeconds;
        title.dvdNavigationDurationSeconds = navigation.durationSeconds;
      }
      if (navigation.chapters.length > 0) {
        title.chapters = navigation.chapters.map((chapter) => ({
          ...chapter,
          title: null,
        }));
        title.chapterCount = title.chapters.length;
        title.dvdNavigationChapters = title.chapters;
      }
      mappedTitles.push(title);
    }
    titles.length = 0;
    titles.push(...mappedTitles);
    if (unmappedCount > 0)
      warnings.push(
        `DVD IFO/PGC 未能证明 ${unmappedCount} 个 HandBrake title 的物理 Cell 范围；这些标题已从可导出列表移除`,
      );
    if (duplicateCount > 0)
      warnings.push(
        `DVD IFO/PGC 确认并移除 ${duplicateCount} 条完全重复的物理 Cell 播放链`,
      );
  } else {
    warnings.push(
      "DVD 未获得可验证的 IFO/PGC/Cell 标题映射；标题容量保持未知，禁止按 VTS 总大小或时长猜测",
    );
  }
  // Complete the deterministic analysis before returning it. HandBrake's
  // scan describes logical titles, but it does not prove that a title is
  // readable by the actual dvdvideo demuxer. Leaving every title pending
  // made the main feature on multi-VOB concert DVDs look like a failed scan.
  const ffprobeExecutable = await resolveToolPath("ffprobe");
  if (ffprobeExecutable && titles.length > 0) {
    for (const title of titles) {
      const titleNumber = title.toolMappings.handbrakeTitleNumber;
      if (!titleNumber || titleNumber <= 0) continue;
      const verification = await verifyDvdTitle({
        sourcePath: input.sourcePath,
        titleNumber,
        handbrakeDurationSeconds: title.durationSeconds,
        handbrakeChapterCount: title.chapterCount,
        handbrakeStreams: title.streams,
        ffprobeExecutable,
        run: input.toolRunner,
      });
      diagnostics.push({
        tool: "ffprobe",
        executable: verification.diagnostic.executable,
        args: verification.diagnostic.args,
        startedAt: new Date(
          Date.now() - verification.diagnostic.durationMs,
        ).toISOString(),
        finishedAt: new Date().toISOString(),
        durationMs: verification.diagnostic.durationMs,
        exitCode: verification.diagnostic.exitCode,
        stdout: verification.diagnostic.stdout,
        stderr: verification.diagnostic.stderr,
        failureReason:
          verification.failureReason ?? verification.diagnostic.failureReason,
      });
      title.verificationStatus = verification.verified ? "verified" : "failed";
      title.verificationFailureReason = verification.failureReason;
      title.verificationWarnings = verification.warnings;
      if (!verification.verified) continue;
      const verifiedStreams = verification.streams.map((stream, index) => ({
        ...stream,
        ...(stream.codecType !== "unknown"
          ? {
              trackUid: buildDvdStreamUid({
                titleUid: title.titleUid ?? "",
                type: stream.codecType,
                ordinal: verification.streams
                  .slice(0, index)
                  .filter(
                    (candidate) => candidate.codecType === stream.codecType,
                  ).length,
                codecName: stream.codecName,
                language: stream.language,
                channels: stream.channels,
              }),
            }
          : {}),
      }));
      title.toolMappings.dvdVtsNumber = titleNumber;
      title.durationSeconds =
        title.dvdNavigationDurationSeconds ??
        verification.durationSeconds ??
        title.durationSeconds;
      title.chapters = title.dvdNavigationChapters ?? verification.chapters;
      title.chapterCount = title.chapters.length;
      title.streams = verifiedStreams;
      title.videoTracks = verifiedStreams.filter(
        (stream) => stream.codecType === "video",
      );
      title.audioTracks = verifiedStreams.filter(
        (stream) => stream.codecType === "audio",
      );
      title.subtitleTracks = verifiedStreams.filter(
        (stream) => stream.codecType === "subtitle",
      );
    }
  }
  // Always augment with the ffprobe dvdvideo title probe: HandBrakeCLI's
  // --scan --json is not reliably parsed (1.11.x outputs no "JSON Title Set"
  // marker) so we cannot trust a 0-title result to mean "no titles". The
  // ffprobe probe enumerates VIDEO_TS titles and reads streams directly.
  const ffprobeTitles =
    titles.length === 0
      ? await analyzeDvdWithFfprobeFallback(
          input.sourcePath,
          input.sourceFingerprint,
        ).catch(() => null)
      : null;
  if (ffprobeTitles && ffprobeTitles.titles.length > 0) {
    const probed = consolidateDiscTitles(
      ffprobeTitles.titles,
      (message) => warnings.push(message),
      { preserveAll: true },
    );
    for (const probeTitle of probed) {
      if (
        !titles.some(
          (title) =>
            title.toolMappings.dvdVtsNumber ===
            probeTitle.toolMappings.dvdVtsNumber,
        )
      ) {
        titles.push(probeTitle);
      }
    }
    if (ffprobeTitles.diagnostic) diagnostics.push(ffprobeTitles.diagnostic);
  }
  if (titles.length === 0) {
    warnings.push(
      `HandBrakeCLI 未返回可用 DVD 标题：${result.diagnostic.failureReason ?? `退出码 ${result.diagnostic.exitCode ?? "未知"}`}`,
    );
  }
  const diagnosticLogPath = await persistDiscAnalysisDiagnostics(
    analysisId,
    diagnostics,
  ).catch(() => null);
  return {
    analysisId,
    sourcePath: input.sourcePath,
    sourceFingerprint: input.sourceFingerprint,
    sourceSizeBytes,
    mediaType: "dvd",
    createdAt: startedAt.toISOString(),
    titles,
    exportCandidates: [],
    diagnostics,
    diagnosticLogPath,
    warnings,
  };
}
