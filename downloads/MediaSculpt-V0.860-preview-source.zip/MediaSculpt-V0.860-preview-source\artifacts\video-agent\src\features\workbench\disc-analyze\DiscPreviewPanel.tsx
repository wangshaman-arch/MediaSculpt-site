import type { Dispatch, SetStateAction } from "react";
import { useI18n } from "@/i18n";
import type { DiscTitlePreviewState } from "@/pages/Scan";
import {
  formatDiscDuration,
  type DiscTrackWithMakeMkv,
} from "../disc-display-model";
import { discPreviewPagination } from "../disc-preview-model";

export type DiscPreviewPanelProps = {
  selectedTrack: DiscTrackWithMakeMkv | undefined;
  previewState: DiscTitlePreviewState | undefined;
  previewPage: number;
  onPreviewPageChange: Dispatch<SetStateAction<number>>;
};

export function DiscPreviewPanel({
  selectedTrack,
  previewState,
  previewPage,
  onPreviewPageChange,
}: DiscPreviewPanelProps) {
  const { t } = useI18n();

  return (
    <div className="flex h-[220px] max-lg:h-[120px] min-w-0 flex-col overflow-hidden rounded-lg border bg-black/40 p-3">
      <div className="mb-2 flex items-center justify-between gap-2 text-xs text-muted-foreground">
        <span className="font-medium text-foreground">
          {t("scan.previewTitle")}
        </span>
        <span>{selectedTrack?.titleId ?? t("scan.selectTitleToPreview")}</span>
      </div>
      <div className="min-h-0 flex flex-1 flex-col overflow-hidden rounded-lg border border-white/10 bg-black">
        {selectedTrack?.titleId && previewState?.status === "ready" ? (
          (() => {
            const previews = previewState?.previews ?? [
              previewState?.url ?? "",
            ];
            const { page, pageCount, visible, canPrev, canNext } =
              discPreviewPagination(previews, previewPage);
            const hasChapters = (selectedTrack.chapters?.length ?? 0) > 0;
            return (
              <div className="flex h-full w-full flex-col">
                <div
                  className="flex min-h-0 flex-1 items-stretch gap-1 overflow-hidden p-1"
                  onWheel={(event) => {
                    if (event.deltaY > 0 && canNext)
                      onPreviewPageChange((value) => value + 1);
                    else if (event.deltaY < 0 && canPrev)
                      onPreviewPageChange((value) => value - 1);
                  }}
                >
                  {visible.map((preview, index) => {
                    const previewIndex = page * 2 + index + 1;
                    return (
                      <div
                        key={`${selectedTrack.titleId}-${previewIndex}`}
                        className="relative min-w-0 flex-1"
                      >
                        <img
                          src={preview}
                          alt={`${selectedTrack.name} ${t("scan.previewLabel", { n: previewIndex })}`}
                          className="h-full w-full rounded object-cover"
                          loading="lazy"
                        />
                        <span className="absolute bottom-1 left-1 rounded bg-black/60 px-1.5 py-0.5 text-[10px] text-white/90">
                          {hasChapters
                            ? t("scan.chapterLabel", { n: previewIndex })
                            : t("scan.previewLabel", { n: previewIndex })}
                        </span>
                      </div>
                    );
                  })}
                  {visible.length === 1 && <div className="min-w-0 flex-1" />}
                </div>
                <div className="flex items-center justify-between px-2 pb-1.5 pt-1">
                  <button
                    type="button"
                    onClick={() =>
                      onPreviewPageChange((value) => Math.max(0, value - 1))
                    }
                    disabled={!canPrev}
                    className="rounded border border-white/15 px-2 py-0.5 text-[11px] text-white/80 hover:bg-white/10 disabled:opacity-30"
                    aria-label={t("scan.prevPreview")}
                  >
                    ‹
                  </button>
                  <span className="text-[10px] text-white/70">
                    {page + 1} / {pageCount}
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      onPreviewPageChange((value) =>
                        Math.min(pageCount - 1, value + 1),
                      )
                    }
                    disabled={!canNext}
                    className="rounded border border-white/15 px-2 py-0.5 text-[11px] text-white/80 hover:bg-white/10 disabled:opacity-30"
                    aria-label={t("scan.nextPreview")}
                  >
                    ›
                  </button>
                </div>
                {previewState?.warning && (
                  <p className="px-3 py-1 text-center text-[10px] text-amber-300">
                    {previewState.warning}
                  </p>
                )}
              </div>
            );
          })()
        ) : previewState?.status === "loading" ? (
          <div className="text-sm text-muted-foreground">
            {t("scan.generatingPreview")}
          </div>
        ) : previewState?.status === "failed" ? (
          <div className="px-4 text-center text-xs text-muted-foreground">
            {t("scan.previewUnavailable")}
            <br />
            <span className="text-[10px]">{previewState?.message}</span>
          </div>
        ) : (
          <div className="px-4 text-center text-xs text-muted-foreground">
            {t("scan.selectTitleForPreview")}
          </div>
        )}
      </div>
      {selectedTrack && (
        <div className="mt-2 grid grid-cols-2 gap-2 text-xs text-muted-foreground sm:grid-cols-4">
          <span>
            {t("scan.titleMeta", {
              value: selectedTrack.titleId ?? "--",
            })}
          </span>
          <span>
            {t("scan.durationValue", {
              value: formatDiscDuration(selectedTrack.durationSeconds),
            })}
          </span>
          <span>
            {t("scan.resolutionMeta", {
              value:
                selectedTrack.streams
                  .filter((s) => s.codecType === "video")
                  .map((s) =>
                    s.width && s.height
                      ? `${s.width}×${s.height}`
                      : t("scan.unknown"),
                  )
                  .join(" / ") || t("scan.unknown"),
            })}
          </span>
          <span>
            {t("scan.chaptersMeta", {
              count: selectedTrack.chapters?.length ?? 0,
            })}
          </span>
        </div>
      )}
    </div>
  );
}
