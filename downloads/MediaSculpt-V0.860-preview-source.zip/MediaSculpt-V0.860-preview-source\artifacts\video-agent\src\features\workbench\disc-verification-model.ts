import type { ProcessingMode } from "../../hooks/useWorkbenchState";
import { isDirectM2tsTitle } from "../../pages/scan-model";
import type { DiscTrackWithMakeMkv } from "./disc-display-model";

/**
 * Resolve the blocking/warning message shown beside a title. Kept pure so the
 * dialog only has to know which title is active.
 */
export function discVerificationMessage(
  input: {
    track: DiscTrackWithMakeMkv | undefined;
    isVerifying: boolean;
    verifyDvdTitles: boolean;
    discType: "dvd" | "bluray";
    processingMode: ProcessingMode;
  },
  t: (key: string) => string,
): string | null {
  const { track, isVerifying, verifyDvdTitles, discType, processingMode } =
    input;
  if (!track) return null;
  if (verifyDvdTitles && discType === "dvd") {
    if (isVerifying || track.verificationStatus === "pending")
      return t("scan.verifyingDiscTitle");
    if (track.verificationStatus === "failed") {
      const reason =
        track.verificationFailureReason ?? t("scan.dvdTitleVerifyFailed");
      if (/dvdvideo|dvd标题读取|demuxer|unknown format/i.test(reason))
        return t("scan.ffmpegDvdUnsupported");
      if (/没有可处理的视频流/.test(reason)) return t("scan.noVideoStream");
      return reason;
    }
    if (
      track.verificationStatus === "verified" &&
      !track.streams.some((stream) => stream.codecType === "video")
    ) {
      return t("scan.noVideoStream");
    }
    return null;
  }
  if (
    processingMode === "compress" &&
    (typeof track.handbrakeTitleNumber !== "number" ||
      track.handbrakeTitleNumber <= 0)
  ) {
    return t("scan.handbrakeNoTitle");
  }
  if (processingMode === "remux" && discType === "bluray") {
    if (!isDirectM2tsTitle(track) && typeof track.playlistId !== "string")
      return t("scan.makemkvUnavailable");
    if (track.mappingStatus === "unmapped")
      return t("scan.blurayMappingFailed");
  }
  return null;
}

export function isDiscProcessingMappingBlocked(input: {
  processingMode: ProcessingMode;
  discType: "dvd" | "bluray";
  selectedIndexes: Iterable<number>;
  getTrack: (idx: number) => DiscTrackWithMakeMkv | undefined;
}): boolean {
  if (!["remux", "compress"].includes(input.processingMode)) return false;
  return Array.from(input.selectedIndexes).some((idx) => {
    const track = input.getTrack(idx);
    if (!track) return true;
    if (input.processingMode === "remux" && input.discType === "dvd")
      return (
        track.verificationStatus !== "verified" ||
        typeof track.dvdVtsNumber !== "number"
      );
    if (input.processingMode === "remux")
      return (
        (!isDirectM2tsTitle(track) && typeof track.playlistId !== "string") ||
        track.mappingStatus === "unmapped"
      );
    return (
      typeof track.handbrakeTitleNumber !== "number" ||
      track.handbrakeTitleNumber <= 0
    );
  });
}
