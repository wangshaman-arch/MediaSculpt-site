// Extracted from pages/Scan.tsx: the disc analyze dialog.
import { Profiler } from "react";
import { onDiscPreviewRender } from "@/pages/Scan";
import { DiscAnalyzeFooter } from "./disc-analyze/DiscAnalyzeFooter";
import { DiscAnalyzeHeader } from "./disc-analyze/DiscAnalyzeHeader";
import { DiscAnalyzeSmartNote } from "./disc-analyze/DiscAnalyzeSmartNote";
import { DiscExpandedTitleControls } from "./disc-analyze/DiscExpandedTitleControls";
import { DiscPreviewPanel } from "./disc-analyze/DiscPreviewPanel";
import { DiscSelectionSummary } from "./disc-analyze/DiscSelectionSummary";
import { DiscTrackSelector } from "./disc-analyze/DiscTrackSelector";
import {
  useDiscAnalyzeDialog,
  type DiscAnalyzeDialogProps,
} from "./disc-analyze/use-disc-analyze-dialog";

export function DiscAnalyzeDialog(props: DiscAnalyzeDialogProps) {
  const {
    discPath,
    uiText,
    onClose,
    onSelectMode,
    analysisOnly = false,
  } = props;
  const model = useDiscAnalyzeDialog(props);
  const {
    data,
    isLoading,
    isError,
    discType,
    activeTrackIdx,
    selectedTrackIndices,
    verifyingTracks,
    trackSummaries,
    selectedTrack,
    selectedStreamIndices,
    selectedChapterIds,
    selectableStreams,
    selectableDiscTitleCount,
    remuxCapacity,
    previewPage,
    setPreviewPage,
    selectedTrackPreview,
    smartParsing,
    smartNote,
    setSmartNote,
    smartParseHasLlm,
    processingMode,
    modeChosen,
    creating,
    modeSelectionAttention,
    showModePicker,
    verifyDvdTitles,
    processingMappingBlocked,
    processingLabel,
    canCreate,
    showModeRequired,
    isTrackVisibleForMode,
    isTrackSelectionDisabled,
    chooseProcessingMode,
    runSmartParse,
    handleTrackSelect,
    toggleTrackSelected,
    setAllDiscTitlesSelected,
    toggleStream,
    toggleChapter,
    setAllStreamsSelected,
    setAllStreamsForSelectedTitles,
    setAllChaptersSelected,
    requestReverification,
    handleCreate,
    confirmAnalysisSelection,
  } = model;

  const verifyingActiveTrack = verifyingTracks.has(activeTrackIdx);

  return (
    <Profiler
      id="DiscAnalyzeDialog"
      onRender={(id, phase, actualDuration) =>
        onDiscPreviewRender(id, phase, actualDuration)
      }
    >
      <div
        className="fixed inset-x-0 bottom-0 top-36 z-50 flex items-center justify-center bg-background/70 p-3 sm:p-6"
        role="dialog"
        aria-modal="true"
      >
        <div className="w-full max-w-full min-w-0 h-full max-h-full rounded-xl border bg-background shadow-2xl flex flex-col">
          <div className="flex h-full min-h-0 max-h-full w-full min-w-0 flex-col">
            {/* Header */}
            <DiscAnalyzeHeader
              uiText={uiText}
              discPath={discPath}
              hasData={!!data}
              discType={discType}
              trackCount={data?.tracks.length ?? 0}
              sourceSizeBytes={data?.sourceSizeBytes}
              analysisOnly={analysisOnly}
              processingMode={processingMode}
              showModePicker={showModePicker}
              modeChosen={modeChosen}
              modeSelectionAttention={modeSelectionAttention}
              selectedTitleCount={selectedTrackIndices.size}
              verifyingCount={verifyingTracks.size}
              smartParsing={smartParsing}
              smartParseHasLlm={smartParseHasLlm}
              onChooseProcessingMode={chooseProcessingMode}
              onRunSmartParse={runSmartParse}
              onClose={onClose}
              onConfirmAnalysis={confirmAnalysisSelection}
            />

            {smartNote && (
              <DiscAnalyzeSmartNote
                note={smartNote}
                onDismiss={() => setSmartNote(null)}
              />
            )}

            {/* Body */}
            <div className="flex min-h-0 flex-1 flex-col overflow-y-auto p-4 space-y-4">
              {isLoading && (
                <div className="text-center py-12 text-muted-foreground text-sm animate-pulse">
                  {uiText.analyzingDisc}
                </div>
              )}
              {isError && (
                <div className="text-center py-12 text-destructive text-sm space-y-1">
                  <p className="font-medium">{uiText.discAnalysisFailed}</p>
                  <p className="text-xs text-muted-foreground">
                    {uiText.discAnalysisHint}
                  </p>
                </div>
              )}

              {data && (
                <div className="grid min-w-0 gap-3 lg:min-h-full lg:items-stretch lg:grid-cols-[minmax(0,0.92fr)_minmax(22rem,1.08fr)]">
                  <div className="min-w-0 space-y-3">
                    <DiscPreviewPanel
                      selectedTrack={selectedTrack}
                      previewState={selectedTrackPreview}
                      previewPage={previewPage}
                      onPreviewPageChange={setPreviewPage}
                    />
                    <DiscTrackSelector
                      uiText={uiText}
                      tracks={trackSummaries}
                      selectedTrackIndices={selectedTrackIndices}
                      activeTrackIdx={activeTrackIdx}
                      verifyingTracks={verifyingTracks}
                      discType={discType}
                      processingMode={processingMode}
                      selectableTitleCount={selectableDiscTitleCount}
                      remuxCapacity={remuxCapacity}
                      onSelect={handleTrackSelect}
                      onToggleSelected={toggleTrackSelected}
                      onSetAllTitles={setAllDiscTitlesSelected}
                      isSelectionDisabled={isTrackSelectionDisabled}
                      isTrackVisible={isTrackVisibleForMode}
                    />
                  </div>
                  <DiscSelectionSummary
                    uiText={uiText}
                    selectedTrack={selectedTrack}
                    selectedTitleCount={selectedTrackIndices.size}
                    selectedTrackIndices={selectedTrackIndices}
                    selectedStreamIndices={selectedStreamIndices}
                    selectedChapterIds={selectedChapterIds}
                    verifyingTracks={verifyingTracks}
                    processingLabel={processingLabel}
                    analysisOnly={analysisOnly}
                    onSetAllStreamsForSelectedTitles={
                      setAllStreamsForSelectedTitles
                    }
                    expandedControls={
                      <DiscExpandedTitleControls
                        uiText={uiText}
                        selectedTrack={selectedTrack}
                        activeTrackIdx={activeTrackIdx}
                        verifying={verifyingActiveTrack}
                        selectableStreams={selectableStreams}
                        selectedStreamIndices={selectedStreamIndices}
                        selectedTitleCount={selectedTrackIndices.size}
                        selectedChapterIds={selectedChapterIds}
                        discType={discType}
                        processingMode={processingMode}
                        verifyDvdTitles={verifyDvdTitles}
                        processingMappingBlocked={processingMappingBlocked}
                        onToggleStream={toggleStream}
                        onSetAllStreams={setAllStreamsSelected}
                        onToggleChapter={toggleChapter}
                        onSetAllChapters={setAllChaptersSelected}
                        onRequestReverification={requestReverification}
                        onSelectMode={onSelectMode}
                      />
                    }
                  />
                </div>
              )}
            </div>

            {/* Footer */}
            {!analysisOnly && (
              <DiscAnalyzeFooter
                uiText={uiText}
                creating={creating}
                canCreate={canCreate}
                showModePicker={showModePicker}
                modeChosen={modeChosen}
                selectedTitleCount={selectedTrackIndices.size}
                showModeRequired={showModeRequired}
                onClose={onClose}
                onCreate={handleCreate}
              />
            )}
          </div>
        </div>
      </div>
    </Profiler>
  );
}
