import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ChevronDown,
  ChevronUp,
  Download,
  FlaskConical,
  Plus,
  RotateCcw,
  Save,
  Settings2,
  Trash2,
  Upload,
} from "lucide-react";
import { useI18n } from "@/i18n";
import { DEFAULT_COMPRESSION_PRESETS } from "@/lib/compression-presets";
import {
  DEFAULT_CUSTOM_TUNING,
  DEFAULT_LOGIC_PARAMETERS,
  logicParam,
  parseCustomTuning,
  TUNING_CUSTOM_PRESETS_KEY,
  TUNING_SCENARIOS,
  type CustomTuning,
  type TuningLogicParam,
  type TuningLogicParamKind,
  type TuningScenario,
} from "@/lib/custom-tuning";
import { cn } from "@/lib/utils";

type CustomPreset = { id: string; name: string; values: CustomTuning["logic"] };

type NewParamDraft = {
  key: string;
  label: string;
  kind: TuningLogicParamKind;
  value: string;
  unit: string;
  min: string;
  max: string;
  step: string;
  options: string;
  hint: string;
};

const EMPTY_DRAFT: NewParamDraft = {
  key: "",
  label: "",
  kind: "number",
  value: "",
  unit: "",
  min: "",
  max: "",
  step: "",
  options: "",
  hint: "",
};

function loadCustomPresets(): CustomPreset[] {
  try {
    const raw = window.localStorage.getItem(TUNING_CUSTOM_PRESETS_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed)
      ? parsed.filter((p): p is CustomPreset =>
          Boolean(
            p &&
            typeof p === "object" &&
            typeof p.name === "string" &&
            p.values &&
            Array.isArray(p.values.parameters),
          ),
        )
      : [];
  } catch {
    return [];
  }
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

type TuningLogicCardProps = {
  tuning: CustomTuning;
  onChange: (next: CustomTuning) => void;
  onSave: (next: CustomTuning) => Promise<void>;
};

export function TuningLogicCard({
  tuning,
  onChange,
  onSave,
}: TuningLogicCardProps) {
  const { t } = useI18n();
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);
  const [customPresets, setCustomPresets] = useState<CustomPreset[]>(() =>
    loadCustomPresets(),
  );
  const [customName, setCustomName] = useState("");
  const [advancedKeys, setAdvancedKeys] = useState<Set<string>>(new Set());
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [draft, setDraft] = useState<NewParamDraft>(EMPTY_DRAFT);
  const [draftErrors, setDraftErrors] = useState<{
    key?: string;
    label?: string;
    value?: string;
  }>({});

  const save = async () => {
    setBusy(true);
    try {
      await onSave(tuning);
      setSaved(true);
      window.setTimeout(() => setSaved(false), 2000);
    } finally {
      setBusy(false);
    }
  };

  const restoreDefaults = () => {
    onChange({
      ...tuning,
      logic: JSON.parse(
        JSON.stringify(DEFAULT_CUSTOM_TUNING.logic),
      ) as CustomTuning["logic"],
    });
  };

  const exportJson = () => {
    const blob = new Blob(
      [
        JSON.stringify(
          {
            schema: "mediasculpt-tuning",
            section: "logic",
            logic: tuning.logic,
          },
          null,
          2,
        ),
      ],
      { type: "application/json" },
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "mediasculpt-tuning-logic.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const importJson = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result ?? "")) as {
          logic?: unknown;
        };
        if (!isPlainObject(parsed.logic)) return;
        // 只替换逻辑部分；提示词保持不变（兼容旧版整份 {prompts, logic} 导出文件）
        const next = parseCustomTuning(JSON.stringify({ logic: parsed.logic }));
        onChange({ ...tuning, logic: next.logic });
      } catch {
        /* ignore invalid files */
      }
    };
    reader.readAsText(file);
  };

  const updateParam = (key: string, patch: Partial<TuningLogicParam>) => {
    onChange({
      ...tuning,
      logic: {
        parameters: tuning.logic.parameters.map((param) =>
          param.key === key ? { ...param, ...patch } : param,
        ),
      },
    });
  };

  const removeParam = (key: string) => {
    onChange({
      ...tuning,
      logic: {
        parameters: tuning.logic.parameters.filter(
          (param) => param.key !== key,
        ),
      },
    });
  };

  const restoreParamDefault = (key: string) => {
    onChange({
      ...tuning,
      logic: {
        parameters: tuning.logic.parameters.map((param) =>
          param.key === key ? { ...param, value: param.default } : param,
        ),
      },
    });
  };

  const toggleAdvanced = (key: string) => {
    setAdvancedKeys((current) => {
      const next = new Set(current);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const applyScenario = (scenario: TuningScenario) => {
    onChange({
      ...tuning,
      logic: {
        parameters: tuning.logic.parameters.map((param) =>
          scenario.values[param.key] !== undefined
            ? { ...param, value: scenario.values[param.key] }
            : param,
        ),
      },
    });
  };

  const saveCustomPreset = () => {
    const name = customName.trim();
    if (!name) return;
    const next: CustomPreset[] = [
      ...customPresets.filter((p) => p.name !== name),
      {
        id: `custom-${Date.now()}`,
        name,
        values: JSON.parse(
          JSON.stringify(tuning.logic),
        ) as CustomTuning["logic"],
      },
    ];
    setCustomPresets(next);
    window.localStorage.setItem(
      TUNING_CUSTOM_PRESETS_KEY,
      JSON.stringify(next),
    );
    setCustomName("");
  };

  const removeCustomPreset = (id: string) => {
    const next = customPresets.filter((p) => p.id !== id);
    setCustomPresets(next);
    window.localStorage.setItem(
      TUNING_CUSTOM_PRESETS_KEY,
      JSON.stringify(next),
    );
  };

  const addBuiltinParam = (definition: TuningLogicParam) => {
    onChange({
      ...tuning,
      logic: { parameters: [...tuning.logic.parameters, { ...definition }] },
    });
  };

  const submitCustomParam = () => {
    const errors: { key?: string; label?: string; value?: string } = {};
    const key = draft.key.trim();
    if (!key) errors.key = t("settings.tuningParamKeyRequired");
    else if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(key))
      errors.key = t("settings.tuningParamKeyInvalid");
    else if (logicParam(tuning.logic, key))
      errors.key = t("settings.tuningParamKeyExists");
    const label = draft.label.trim();
    if (!label) errors.label = t("settings.tuningParamLabelRequired");
    let value: number | string = draft.value;
    if (draft.kind === "number") {
      const parsed = Number(draft.value);
      if (!Number.isFinite(parsed))
        errors.value = t("settings.tuningParamValueRequired");
      else value = parsed;
    } else if (draft.kind === "select") {
      const options = draft.options
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean);
      if (options.length === 0)
        errors.value = t("settings.tuningParamOptionsRequired");
      else if (draft.value.trim() && !options.includes(draft.value.trim()))
        errors.value = t("settings.tuningParamValueInOptions");
      else if (!draft.value.trim()) value = options[0];
    }
    setDraftErrors(errors);
    if (Object.keys(errors).length > 0) return;
    const param: TuningLogicParam = {
      key,
      label,
      value,
      kind: draft.kind,
      ...(draft.kind === "number"
        ? {
            ...(draft.unit.trim() ? { unit: draft.unit.trim() } : {}),
            ...(draft.min.trim() && Number.isFinite(Number(draft.min))
              ? { min: Number(draft.min) }
              : {}),
            ...(draft.max.trim() && Number.isFinite(Number(draft.max))
              ? { max: Number(draft.max) }
              : {}),
            ...(draft.step.trim() &&
            Number.isFinite(Number(draft.step)) &&
            Number(draft.step) > 0
              ? { step: Number(draft.step) }
              : {}),
          }
        : draft.kind === "select"
          ? {
              options: draft.options
                .split(",")
                .map((item) => item.trim())
                .filter(Boolean),
            }
          : {}),
      ...(draft.hint.trim() ? { hint: draft.hint.trim() } : {}),
      default: value,
      custom: true,
    };
    onChange({
      ...tuning,
      logic: { parameters: [...tuning.logic.parameters, param] },
    });
    setDraft(EMPTY_DRAFT);
    setDraftErrors({});
    setAddDialogOpen(false);
  };

  const activeScenario = TUNING_SCENARIOS.find((scenario) =>
    Object.entries(scenario.values).every(
      ([key, value]) => logicParam(tuning.logic, key)?.value === value,
    ),
  );
  const presetOptions = DEFAULT_COMPRESSION_PRESETS.map((preset) => ({
    value: preset.id,
    label: t(preset.labelKey),
  }));
  const missingBuiltins = useMemo(
    () =>
      DEFAULT_LOGIC_PARAMETERS.filter(
        (definition) => !logicParam(tuning.logic, definition.key),
      ),
    [tuning.logic],
  );

  const selectOptions = (
    param: TuningLogicParam,
  ): Array<{ value: string; label: string }> => {
    if (param.key === "dvdCompressPreset") return presetOptions;
    return (param.options ?? []).map((option) => ({
      value: option,
      label:
        option === "remux"
          ? t("settings.tuningLogic.dvdModeRemux")
          : option === "compress"
            ? t("settings.tuningLogic.dvdModeCompress")
            : option,
    }));
  };

  return (
    <div className="space-y-4" data-testid="settings-custom-tuning">
      <Card className="border-amber-400/25">
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <CardTitle>{t("settings.tuningTitle")}</CardTitle>
              <CardDescription className="mt-1">
                {t("settings.tuningDesc")}
              </CardDescription>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={restoreDefaults}
              >
                <RotateCcw className="mr-1.5 h-3.5 w-3.5" />
                {t("settings.tuningRestore")}
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={exportJson}
              >
                <Download className="mr-1.5 h-3.5 w-3.5" />
                {t("settings.tuningExport")}
              </Button>
              <label className="inline-flex h-8 cursor-pointer items-center gap-1.5 rounded-md border px-3 text-xs text-muted-foreground hover:border-primary/50 hover:text-foreground">
                <Upload className="h-3.5 w-3.5" />
                {t("settings.tuningImport")}
                <input
                  type="file"
                  accept="application/json,.json"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.currentTarget.files?.[0];
                    if (file) importJson(file);
                    e.currentTarget.value = "";
                  }}
                />
              </label>
              <Button
                type="button"
                size="sm"
                disabled={busy}
                onClick={() => void save()}
              >
                <Save className="mr-1.5 h-3.5 w-3.5" />
                {saved ? t("settings.tuningSaved") : t("settings.tuningSave")}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <p className="text-xs leading-relaxed text-muted-foreground">
            {t("settings.tuningIntro")}
          </p>

          {/* 场景预设（鼠标点选） */}
          <div>
            <p className="mb-2 flex items-center gap-1.5 text-xs font-medium text-foreground">
              <FlaskConical className="h-3.5 w-3.5 text-primary" />
              {t("settings.tuningLogicLabel")}
            </p>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {TUNING_SCENARIOS.map((scenario) => (
                <button
                  key={scenario.id}
                  type="button"
                  onClick={() => applyScenario(scenario)}
                  className={cn(
                    "rounded-lg border p-3 text-left transition-colors",
                    activeScenario?.id === scenario.id
                      ? "border-primary/60 bg-primary/10"
                      : "border-border/70 bg-background/55 hover:border-primary/50 hover:bg-primary/5",
                  )}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-medium">
                      {t(scenario.labelKey)}
                    </span>
                    {activeScenario?.id === scenario.id && (
                      <Badge variant="secondary" className="text-[10px]">
                        {t("settings.tuningScenarioActive")}
                      </Badge>
                    )}
                  </div>
                  <p className="mt-1 text-[11px] leading-snug text-muted-foreground">
                    {t(scenario.descKey)}
                  </p>
                </button>
              ))}
            </div>

            {/* 自定义预设（另存为） */}
            <div className="mt-3 flex flex-wrap items-center gap-2 rounded-lg border bg-background/60 p-2">
              <Input
                value={customName}
                onChange={(e) => setCustomName(e.currentTarget.value)}
                placeholder={t("settings.tuningCustomPresetName")}
                className="h-8 w-52 text-xs"
              />
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={saveCustomPreset}
                disabled={!customName.trim()}
              >
                <Plus className="mr-1.5 h-3.5 w-3.5" />
                {t("settings.tuningSaveCustom")}
              </Button>
              {customPresets.map((preset) => (
                <span
                  key={preset.id}
                  className="inline-flex items-center gap-1 rounded-md border border-amber-400/30 bg-amber-400/5 px-2 py-1 text-[11px] text-amber-400"
                >
                  <button
                    type="button"
                    onClick={() =>
                      onChange({
                        ...tuning,
                        logic: JSON.parse(
                          JSON.stringify(preset.values),
                        ) as CustomTuning["logic"],
                      })
                    }
                  >
                    {preset.name}
                  </button>
                  <button
                    type="button"
                    onClick={() => removeCustomPreset(preset.id)}
                    aria-label={t("settings.tuningRemoveCustom")}
                  >
                    <Trash2 className="h-3 w-3 opacity-60 hover:opacity-100" />
                  </button>
                </span>
              ))}
            </div>

            <p className="mt-3 text-[11px] leading-relaxed text-muted-foreground/80">
              {t("settings.tuningParamLogicIntro")}
            </p>

            {/* 参数表：每行可改名/编辑/恢复默认/删除 */}
            <div className="mt-3 space-y-2">
              {tuning.logic.parameters.map((param) => {
                const advancedOpen = advancedKeys.has(param.key);
                const options = selectOptions(param);
                return (
                  <div
                    key={param.key}
                    className="rounded-lg border bg-background/60 p-3"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <Input
                        value={param.label ?? ""}
                        placeholder={
                          param.labelKey
                            ? t(param.labelKey)
                            : t("settings.tuningParamLabelPlaceholder")
                        }
                        onChange={(e) =>
                          updateParam(param.key, {
                            label: e.currentTarget.value.trim() || undefined,
                          })
                        }
                        className="h-8 w-52 text-xs"
                        aria-label={t("settings.tuningParamLabel")}
                      />
                      <Badge
                        variant={param.custom ? "outline" : "secondary"}
                        className="text-[10px] font-normal"
                      >
                        {param.custom
                          ? t("settings.tuningParamCustomBadge")
                          : t("settings.tuningParamBuiltinBadge")}
                      </Badge>
                      <div className="ml-auto flex flex-wrap items-center gap-1">
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          className="h-6 px-2 text-[10px] text-muted-foreground"
                          onClick={() => toggleAdvanced(param.key)}
                        >
                          <Settings2 className="mr-1 h-3 w-3" />
                          {advancedOpen ? (
                            <ChevronUp className="h-3 w-3" />
                          ) : (
                            <ChevronDown className="h-3 w-3" />
                          )}
                          {t("settings.tuningParamAdvanced")}
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          className="h-6 px-2 text-[10px] text-muted-foreground"
                          onClick={() => restoreParamDefault(param.key)}
                        >
                          <RotateCcw className="mr-1 h-3 w-3" />
                          {t("settings.tuningParamRestoreDefault")}
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          className="h-6 px-2 text-[10px] text-destructive/80 hover:text-destructive"
                          onClick={() => removeParam(param.key)}
                        >
                          <Trash2 className="mr-1 h-3 w-3" />
                          {t("settings.tuningParamDelete")}
                        </Button>
                      </div>
                    </div>

                    <div className="mt-2 flex flex-wrap items-center gap-3">
                      {param.kind === "number" ? (
                        <>
                          <Slider
                            value={[Number(param.value)]}
                            min={param.min ?? 0}
                            max={param.max ?? 100}
                            step={param.step ?? 1}
                            onValueChange={(value) =>
                              updateParam(param.key, {
                                value: value[0] ?? param.value,
                              })
                            }
                            className="max-w-56"
                          />
                          <div className="flex items-center gap-1">
                            <Input
                              type="number"
                              value={String(param.value)}
                              min={param.min}
                              max={param.max}
                              step={param.step}
                              onChange={(e) => {
                                const parsed = Number(e.currentTarget.value);
                                updateParam(param.key, {
                                  value: Number.isFinite(parsed)
                                    ? parsed
                                    : param.value,
                                });
                              }}
                              className="h-7 w-20 text-xs"
                            />
                            {param.unit && (
                              <span className="text-[11px] text-muted-foreground">
                                {param.unit}
                              </span>
                            )}
                          </div>
                        </>
                      ) : param.kind === "select" ? (
                        <Select
                          value={String(param.value)}
                          onValueChange={(value) =>
                            updateParam(param.key, { value })
                          }
                        >
                          <SelectTrigger className="h-8 w-56 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {options.map((option) => (
                              <SelectItem
                                key={option.value}
                                value={option.value}
                              >
                                {option.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <Input
                          value={String(param.value)}
                          onChange={(e) =>
                            updateParam(param.key, {
                              value: e.currentTarget.value,
                            })
                          }
                          className="h-8 w-72 text-xs"
                        />
                      )}
                    </div>

                    <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground/80">
                      {param.hintKey ? t(param.hintKey) : param.hint}
                    </p>

                    {advancedOpen && (
                      <div className="mt-2 space-y-2 rounded-md border border-border/60 bg-background/40 p-2">
                        <p className="text-[11px] text-muted-foreground">
                          {t("settings.tuningParamKeyHint")}{" "}
                          <code className="rounded bg-secondary/60 px-1.5 py-0.5 font-mono text-[10px]">
                            {param.key}
                          </code>
                        </p>
                        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
                          {param.kind === "number" && (
                            <>
                              <label className="block text-[11px] text-muted-foreground">
                                {t("settings.tuningParamMin")}
                                <Input
                                  type="number"
                                  value={param.min ?? ""}
                                  onChange={(e) =>
                                    updateParam(param.key, {
                                      min: Number.isFinite(
                                        Number(e.currentTarget.value),
                                      )
                                        ? Number(e.currentTarget.value)
                                        : undefined,
                                    })
                                  }
                                  className="mt-1 h-7 text-xs"
                                />
                              </label>
                              <label className="block text-[11px] text-muted-foreground">
                                {t("settings.tuningParamMax")}
                                <Input
                                  type="number"
                                  value={param.max ?? ""}
                                  onChange={(e) =>
                                    updateParam(param.key, {
                                      max: Number.isFinite(
                                        Number(e.currentTarget.value),
                                      )
                                        ? Number(e.currentTarget.value)
                                        : undefined,
                                    })
                                  }
                                  className="mt-1 h-7 text-xs"
                                />
                              </label>
                              <label className="block text-[11px] text-muted-foreground">
                                {t("settings.tuningParamStep")}
                                <Input
                                  type="number"
                                  value={param.step ?? ""}
                                  onChange={(e) =>
                                    updateParam(param.key, {
                                      step:
                                        Number.isFinite(
                                          Number(e.currentTarget.value),
                                        ) && Number(e.currentTarget.value) > 0
                                          ? Number(e.currentTarget.value)
                                          : undefined,
                                    })
                                  }
                                  className="mt-1 h-7 text-xs"
                                />
                              </label>
                            </>
                          )}
                          <label className="block text-[11px] text-muted-foreground">
                            {t("settings.tuningParamUnit")}
                            <Input
                              value={param.unit ?? ""}
                              onChange={(e) =>
                                updateParam(param.key, {
                                  unit:
                                    e.currentTarget.value.trim() || undefined,
                                })
                              }
                              className="mt-1 h-7 text-xs"
                            />
                          </label>
                          {param.kind === "select" && param.custom && (
                            <label className="block text-[11px] text-muted-foreground">
                              {t("settings.tuningParamOptions")}
                              <Input
                                value={(param.options ?? []).join(", ")}
                                onChange={(e) =>
                                  updateParam(param.key, {
                                    options: e.currentTarget.value
                                      .split(",")
                                      .map((item) => item.trim())
                                      .filter(Boolean),
                                  })
                                }
                                className="mt-1 h-7 text-xs"
                              />
                            </label>
                          )}
                          {param.custom && (
                            <label className="block text-[11px] text-muted-foreground">
                              {t("settings.tuningParamDefault")}
                              <Input
                                value={String(param.default)}
                                onChange={(e) => {
                                  const raw = e.currentTarget.value;
                                  const parsed = Number(raw);
                                  updateParam(param.key, {
                                    default:
                                      param.kind === "number" &&
                                      Number.isFinite(parsed)
                                        ? parsed
                                        : raw,
                                  });
                                }}
                                className="mt-1 h-7 text-xs"
                              />
                            </label>
                          )}
                          {param.custom && (
                            <label className="block text-[11px] text-muted-foreground">
                              {t("settings.tuningParamHint")}
                              <Input
                                value={param.hint ?? ""}
                                onChange={(e) =>
                                  updateParam(param.key, {
                                    hint:
                                      e.currentTarget.value.trim() || undefined,
                                  })
                                }
                                className="mt-1 h-7 text-xs"
                              />
                            </label>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
              {tuning.logic.parameters.length === 0 && (
                <p className="rounded-lg border border-dashed bg-background/40 p-4 text-center text-xs text-muted-foreground">
                  {t("settings.tuningParamEmpty")}
                </p>
              )}
            </div>

            <Button
              type="button"
              size="sm"
              variant="outline"
              className="mt-3"
              onClick={() => setAddDialogOpen(true)}
            >
              <Plus className="mr-1.5 h-3.5 w-3.5" />
              {t("settings.tuningParamAdd")}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* 添加参数对话框 */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{t("settings.tuningParamAdd")}</DialogTitle>
            <DialogDescription>
              {t("settings.tuningParamAddDesc")}
            </DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="custom">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="custom">
                {t("settings.tuningParamAddCustom")}
              </TabsTrigger>
              <TabsTrigger value="builtin">
                {t("settings.tuningParamAddBuiltin")}
              </TabsTrigger>
            </TabsList>
            <TabsContent value="custom" className="space-y-3">
              <label className="block text-xs text-muted-foreground">
                {t("settings.tuningParamKey")}
                <Input
                  value={draft.key}
                  onChange={(e) =>
                    setDraft({ ...draft, key: e.currentTarget.value })
                  }
                  placeholder={t("settings.tuningParamKeyPlaceholder")}
                  className="mt-1 h-8 text-xs"
                />
                {draftErrors.key && (
                  <span className="mt-1 block text-[11px] text-destructive">
                    {draftErrors.key}
                  </span>
                )}
              </label>
              <label className="block text-xs text-muted-foreground">
                {t("settings.tuningParamLabel")}
                <Input
                  value={draft.label}
                  onChange={(e) =>
                    setDraft({ ...draft, label: e.currentTarget.value })
                  }
                  placeholder={t("settings.tuningParamLabelPlaceholder")}
                  className="mt-1 h-8 text-xs"
                />
                {draftErrors.label && (
                  <span className="mt-1 block text-[11px] text-destructive">
                    {draftErrors.label}
                  </span>
                )}
              </label>
              <label className="block text-xs text-muted-foreground">
                {t("settings.tuningParamKind")}
                <Select
                  value={draft.kind}
                  onValueChange={(value) =>
                    setDraft({ ...draft, kind: value as TuningLogicParamKind })
                  }
                >
                  <SelectTrigger className="mt-1 h-8 w-full text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="number">
                      {t("settings.tuningParamKindNumber")}
                    </SelectItem>
                    <SelectItem value="select">
                      {t("settings.tuningParamKindSelect")}
                    </SelectItem>
                    <SelectItem value="text">
                      {t("settings.tuningParamKindText")}
                    </SelectItem>
                  </SelectContent>
                </Select>
              </label>
              <label className="block text-xs text-muted-foreground">
                {t("settings.tuningParamValue")}
                <Input
                  value={draft.value}
                  onChange={(e) =>
                    setDraft({ ...draft, value: e.currentTarget.value })
                  }
                  placeholder={
                    draft.kind === "number"
                      ? "2"
                      : draft.kind === "select"
                        ? t("settings.tuningParamValueSelectHint")
                        : t("settings.tuningParamValueTextHint")
                  }
                  className="mt-1 h-8 text-xs"
                />
                {draftErrors.value && (
                  <span className="mt-1 block text-[11px] text-destructive">
                    {draftErrors.value}
                  </span>
                )}
              </label>
              {draft.kind === "select" && (
                <label className="block text-xs text-muted-foreground">
                  {t("settings.tuningParamOptions")}
                  <Input
                    value={draft.options}
                    onChange={(e) =>
                      setDraft({ ...draft, options: e.currentTarget.value })
                    }
                    placeholder={t("settings.tuningParamOptionsPlaceholder")}
                    className="mt-1 h-8 text-xs"
                  />
                </label>
              )}
              {draft.kind === "number" && (
                <div className="grid grid-cols-4 gap-2">
                  <label className="block text-xs text-muted-foreground">
                    {t("settings.tuningParamMin")}
                    <Input
                      value={draft.min}
                      onChange={(e) =>
                        setDraft({ ...draft, min: e.currentTarget.value })
                      }
                      className="mt-1 h-8 text-xs"
                    />
                  </label>
                  <label className="block text-xs text-muted-foreground">
                    {t("settings.tuningParamMax")}
                    <Input
                      value={draft.max}
                      onChange={(e) =>
                        setDraft({ ...draft, max: e.currentTarget.value })
                      }
                      className="mt-1 h-8 text-xs"
                    />
                  </label>
                  <label className="block text-xs text-muted-foreground">
                    {t("settings.tuningParamStep")}
                    <Input
                      value={draft.step}
                      onChange={(e) =>
                        setDraft({ ...draft, step: e.currentTarget.value })
                      }
                      className="mt-1 h-8 text-xs"
                    />
                  </label>
                  <label className="block text-xs text-muted-foreground">
                    {t("settings.tuningParamUnit")}
                    <Input
                      value={draft.unit}
                      onChange={(e) =>
                        setDraft({ ...draft, unit: e.currentTarget.value })
                      }
                      className="mt-1 h-8 text-xs"
                    />
                  </label>
                </div>
              )}
              <label className="block text-xs text-muted-foreground">
                {t("settings.tuningParamHint")}
                <Input
                  value={draft.hint}
                  onChange={(e) =>
                    setDraft({ ...draft, hint: e.currentTarget.value })
                  }
                  className="mt-1 h-8 text-xs"
                />
              </label>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setAddDialogOpen(false)}
                >
                  {t("common.cancel")}
                </Button>
                <Button type="button" onClick={submitCustomParam}>
                  {t("settings.tuningParamAdd")}
                </Button>
              </DialogFooter>
            </TabsContent>
            <TabsContent value="builtin" className="space-y-2">
              <p className="text-[11px] leading-relaxed text-muted-foreground">
                {t("settings.tuningParamAddBuiltinDesc")}
              </p>
              {missingBuiltins.length === 0 ? (
                <p className="rounded-lg border border-dashed p-4 text-center text-xs text-muted-foreground">
                  {t("settings.tuningParamNoMissingBuiltins")}
                </p>
              ) : (
                missingBuiltins.map((definition) => (
                  <div
                    key={definition.key}
                    className="flex items-center justify-between gap-2 rounded-lg border bg-background/50 p-2"
                  >
                    <div className="min-w-0">
                      <p className="truncate text-xs font-medium">
                        {definition.labelKey
                          ? t(definition.labelKey)
                          : (definition.label ?? definition.key)}
                      </p>
                      <p className="truncate font-mono text-[10px] text-muted-foreground">
                        {definition.key}
                      </p>
                    </div>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="h-7 px-2 text-[11px]"
                      onClick={() => addBuiltinParam(definition)}
                    >
                      <Plus className="mr-1 h-3 w-3" />
                      {t("settings.tuningParamAdd")}
                    </Button>
                  </div>
                ))
              )}
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
}
