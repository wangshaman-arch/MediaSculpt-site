import { EventEmitter } from "node:events";
import type { ChildProcess } from "node:child_process";
import { describe, expect, it, vi } from "vitest";
import { JobToolExecutor, type JobProcessSpawner } from "./job-tool-executor";

function fakeProcess() {
  const child = new EventEmitter() as EventEmitter & {
    stdout: EventEmitter;
    stderr: EventEmitter;
  };
  child.stdout = new EventEmitter();
  child.stderr = new EventEmitter();
  return child;
}

function spawner(child: EventEmitter): JobProcessSpawner {
  return { spawnForJob: vi.fn(() => child as unknown as ChildProcess) };
}

describe("JobToolExecutor", () => {
  it("collects stdout and stderr for a successful tool", async () => {
    const child = fakeProcess();
    const executor = new JobToolExecutor(spawner(child));
    const resultPromise = executor.run(9, "ffprobe", ["-version"]);
    child.stdout.emit("data", Buffer.from("json"));
    child.stderr.emit("data", Buffer.from("diagnostic"));
    child.emit("close", 0);

    await expect(resultPromise).resolves.toEqual({
      stdout: "json",
      stderr: "diagnostic",
    });
  });

  it("bounds captured output so a chatty tool cannot exhaust memory", async () => {
    const child = fakeProcess();
    const executor = new JobToolExecutor(spawner(child));
    const resultPromise = executor.run(9, "ffmpeg", ["-i", "big.mkv"], {
      maxOutputBytes: 16,
    });
    child.stdout.emit("data", Buffer.from("0123456789abcdef"));
    child.stdout.emit("data", Buffer.from("XYZ"));
    child.emit("close", 0);

    const result = await resultPromise;
    expect(result.stdout).toContain("output truncated");
    expect(result.stdout.endsWith("XYZ")).toBe(true);
    expect(result.stdout.length).toBeLessThan(64);
  });

  it("reports the tail of stderr when a tool fails", async () => {
    const child = fakeProcess();
    const executor = new JobToolExecutor(spawner(child));
    const resultPromise = executor.run(9, "ffmpeg", ["-i", "missing.mkv"]);
    child.stderr.emit("data", Buffer.from("input error"));
    child.emit("close", 2);

    await expect(resultPromise).rejects.toThrow("input error");
  });
});
