import { describe, it, expect } from "vitest";
import { basicsLineToRow } from "./imdb-import";

const ratings = new Map([["tt0116477", { rating: 7.8, votes: 42000 }]]);

// title.basics columns:
// tconst titleType primaryTitle originalTitle isAdult startYear endYear runtimeMinutes genres
const line = (f: Partial<Record<string, string>> = {}) =>
  [
    f.tconst ?? "tt0116477",
    f.titleType ?? "movie",
    f.primaryTitle ?? "Hamlet",
    f.originalTitle ?? "Hamlet",
    f.isAdult ?? "0",
    f.startYear ?? "1996",
    f.endYear ?? "\\N",
    f.runtimeMinutes ?? "242",
    f.genres ?? "Drama",
  ].join("\t");

describe("basicsLineToRow", () => {
  it("parses a movie line and joins ratings", () => {
    expect(basicsLineToRow(line(), ratings)).toEqual({
      tconst: "tt0116477",
      titleType: "movie",
      primaryTitle: "Hamlet",
      originalTitle: "Hamlet",
      startYear: 1996,
      runtimeMinutes: 242,
      genres: "Drama",
      rating: 7.8,
      votes: 42000,
    });
  });

  it("treats \\N as null and missing ratings as null", () => {
    const row = basicsLineToRow(
      line({
        tconst: "tt9999999",
        startYear: "\\N",
        runtimeMinutes: "\\N",
        genres: "\\N",
      }),
      ratings,
    );
    expect(row).toMatchObject({
      startYear: null,
      runtimeMinutes: null,
      genres: null,
      rating: null,
      votes: null,
    });
  });

  it("skips the header line", () => {
    const header =
      "tconst\ttitleType\tprimaryTitle\toriginalTitle\tisAdult\tstartYear\tendYear\truntimeMinutes\tgenres";
    expect(basicsLineToRow(header, ratings)).toBeNull();
  });

  it("skips TV episodes and other unwanted types", () => {
    expect(
      basicsLineToRow(line({ titleType: "tvEpisode" }), ratings),
    ).toBeNull();
    expect(basicsLineToRow(line({ titleType: "short" }), ratings)).toBeNull();
  });

  it("keeps DVD-relevant types", () => {
    for (const t of ["movie", "tvMovie", "tvSeries", "tvMiniSeries", "video"]) {
      expect(basicsLineToRow(line({ titleType: t }), ratings)).not.toBeNull();
    }
  });

  it("skips adult titles and malformed lines", () => {
    expect(basicsLineToRow(line({ isAdult: "1" }), ratings)).toBeNull();
    expect(basicsLineToRow("garbage line", ratings)).toBeNull();
  });
});
