import crypto from "node:crypto";
import type {
  DiscAnalysisResult,
  UnifiedDiscTitle,
  DiscAnalysisStream,
} from "./disc-analysis";
import { resolveDvdVideoTsDir } from "./disc";
import { runExternalTool, type ExternalToolRunner } from "./dvd-remux";
import {
  validateDvdTitleRead,
  type DvdTitleReadEvidence,
} from "./dvd-title-validation";
import { readDvdVtsSizes } from "./dvd-size-estimate";
import {
  validateDvdCandidates,
  type DvdSmartCapacity,
  type DvdSmartCandidateVerdict,
  type DvdSmartDecision,
} from "./dvd-smart-validation";

export type SmartDvdManifestCandidate = DvdSmartCandidateVerdict & {
  durationSeconds: number | null;
  availabilityStatus: "confirmed" | "unavailable";
  validationStatus: "passed" | "failed" | "unverified";
  validationFailureReason: string | null;
  videoFrameCount: number;
};

export type SmartDvdManifest = {
  manifestVersion: 1;
  manifestId: string;
  analysisId: string;
  selectedTitleIds: string[];
  selectedStreamsByTitle: Record<string, number[]>;
  selectedChaptersByTitle: Record<string, number[]>;
  candidates: SmartDvdManifestCandidate[];
  confidence: DvdSmartDecision["confidence"];
  requiresUserSelection: boolean;
  reasons: string[];
  capacity: DvdSmartCapacity;
  ai?: {
    titleId: string;
    videoIndex: number | null;
    audioIndices: number[];
    subtitleIndices: number[];
    reason: string;
    confidence: "high" | "medium" | "low";
  } | null;
};

function signature(streams: DiscAnalysisStream[]): string {
  return streams
    .map((stream) =>
      [
        stream.codecType,
        stream.codecName ?? "",
        stream.language ?? "",
        stream.channels ?? "",
        stream.width ?? "",
        stream.height ?? "",
        stream.frameRate ?? "",
      ].join(":"),
    )
    .join(",");
}

function candidateInput(
  title: UnifiedDiscTitle,
  validationStatus: "passed" | "failed" | "unverified",
  validationFailureReason?: string | null,
) {
  const physicalVtsNumber = title.toolMappings.physicalVtsNumber;
  return {
    titleId: title.titleId,
    titleNumber:
      title.toolMappings.handbrakeTitleNumber ?? title.titleIndex + 1,
    durationSeconds: title.durationSeconds,
    chapterStarts: (title.chapters ?? []).map(
      (chapter) => chapter.startSeconds,
    ),
    videoSignature: signature(title.videoTracks ?? []),
    audioSignature: signature(title.audioTracks ?? []),
    subtitleSignature: signature(title.subtitleTracks ?? []),
    availabilityStatus: title.availabilityStatus ?? ("confirmed" as const),
    validationStatus,
    validationFailureReason,
    // HandBrake title numbers are logical playback chains. The physical VTS
    // mapping is the evidence needed to deduplicate repeated chains and to
    // count DVD bytes only once.
    physicalVtsNumbers:
      typeof physicalVtsNumber === "number" && physicalVtsNumber > 0
        ? [physicalVtsNumber]
        : undefined,
  };
}

function selectedStreamIndexes(title: UnifiedDiscTitle): number[] {
  return (title.streams ?? []).map((stream) => stream.index);
}

function selectedChapterIndexes(title: UnifiedDiscTitle): number[] {
  return (title.chapters ?? []).map((chapter) => chapter.id);
}

function manifestId(analysisId: string, selectedTitleIds: string[]): string {
  return crypto
    .createHash("sha256")
    .update(`${analysisId}|${selectedTitleIds.join("|")}`)
    .digest("hex")
    .slice(0, 16);
}

export async function buildDvdSmartManifest(input: {
  analysis: DiscAnalysisResult;
  ffprobeExecutable: string;
  ffmpegExecutable: string;
  run?: ExternalToolRunner;
  vtsSizes?: ReadonlyMap<number, number>;
}): Promise<SmartDvdManifest> {
  const run = input.run ?? runExternalTool;
  const physicalDir = await resolveDvdVideoTsDir(input.analysis.sourcePath);
  const toolSourcePath = physicalDir ?? input.analysis.sourcePath;
  const vtsSizes =
    input.vtsSizes ??
    (physicalDir
      ? await readDvdVtsSizes(physicalDir)
      : new Map<number, number>());
  const prepared: Array<ReturnType<typeof candidateInput>> = [];
  const evidenceById = new Map<string, DvdTitleReadEvidence>();

  for (const title of input.analysis.titles) {
    const duration = title.durationSeconds ?? 0;
    if (title.availabilityStatus === "unavailable") {
      prepared.push(
        candidateInput(
          title,
          "failed",
          title.availabilityFailureReason ?? "标题无法读取",
        ),
      );
      continue;
    }
    if (duration < 300) {
      // Short menu/extra titles are rejected by the pure selector without
      // spending a full DVD navigation pass on them.
      prepared.push(
        candidateInput(title, "unverified", "短标题不进入正片读取校验"),
      );
      continue;
    }
    const titleNumber = title.toolMappings.handbrakeTitleNumber;
    if (
      typeof titleNumber !== "number" ||
      !Number.isInteger(titleNumber) ||
      titleNumber <= 0
    ) {
      prepared.push(
        candidateInput(
          title,
          "failed",
          "标题没有可执行的 HandBrake/DVD 标题编号",
        ),
      );
      continue;
    }
    const evidence = await validateDvdTitleRead(
      {
        sourcePath: toolSourcePath,
        titleNumber,
        handbrakeDurationSeconds: title.durationSeconds,
        handbrakeChapterCount: title.chapterCount,
        handbrakeStreams: title.streams.map((stream) => ({
          index: stream.index,
          codecType:
            stream.codecType === "unknown" ? "unknown" : stream.codecType,
          codecName: stream.codecName,
          language: stream.language,
          title: stream.title,
          channels: stream.channels,
          channelLayout: stream.channelLayout,
          handbrakeTrackNumber: stream.handbrakeTrackNumber,
        })),
        ffprobeExecutable: input.ffprobeExecutable,
        ffmpegExecutable: input.ffmpegExecutable,
      },
      run,
    );
    evidenceById.set(title.titleId, evidence);
    prepared.push(
      candidateInput(title, evidence.status, evidence.failureReason),
    );
  }

  const decision = validateDvdCandidates({
    candidates: prepared,
    physicalBytes: input.analysis.sourceSizeBytes ?? null,
    vtsSizes,
  });
  const verdictById = new Map(
    decision.candidates.map((verdict) => [verdict.titleId, verdict]),
  );
  const candidates = prepared.map((candidate) => {
    const verdict = verdictById.get(candidate.titleId);
    const evidence = evidenceById.get(candidate.titleId);
    return {
      ...(verdict ?? {
        titleId: candidate.titleId,
        titleNumber: candidate.titleNumber,
        status: "rejected" as const,
        reason: candidate.validationFailureReason ?? "未生成候选判定",
        fingerprint: null,
      }),
      durationSeconds: candidate.durationSeconds,
      availabilityStatus: candidate.availabilityStatus,
      validationStatus: candidate.validationStatus,
      validationFailureReason: candidate.validationFailureReason ?? null,
      videoFrameCount: evidence?.videoFrameCount ?? 0,
    };
  });
  const selectedTitles = input.analysis.titles.filter((title) =>
    decision.selectedTitleIds.includes(title.titleId),
  );
  return {
    manifestVersion: 1,
    manifestId: manifestId(
      input.analysis.analysisId,
      decision.selectedTitleIds,
    ),
    analysisId: input.analysis.analysisId,
    selectedTitleIds: decision.selectedTitleIds,
    selectedStreamsByTitle: Object.fromEntries(
      selectedTitles.map((title) => [
        title.titleId,
        selectedStreamIndexes(title),
      ]),
    ),
    selectedChaptersByTitle: Object.fromEntries(
      selectedTitles.map((title) => [
        title.titleId,
        selectedChapterIndexes(title),
      ]),
    ),
    candidates,
    confidence: decision.confidence,
    requiresUserSelection: decision.requiresUserSelection,
    reasons: decision.reasons,
    capacity: decision.capacity,
    ai: null,
  };
}
