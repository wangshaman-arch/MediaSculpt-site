import { useState, useEffect } from "react";
import {
  useCreateJob,
  useGetConfig,
  getGetConfigQueryKey,
  useAnalyzeDisc,
  useListJobs,
  getListJobsQueryKey,
} from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { useI18n } from "@/i18n";
import type { ProcessingMode, SubtitleMode } from "@/hooks/useWorkbenchState";
import type { ScanCopy } from "@/pages/Scan";
import type { BatchItem } from "@/pages/BatchConfirmPage";
import { stableDiscTitleKey } from "@/pages/scan-model";
import { hasSelectedCloudLlmKey } from "@/lib/ai-capabilities";
import {
  assessDiscRemuxCapacity,
  canCreateDiscJobsWithMode,
} from "../disc-job-mode-model";
import { discAnalysisDialogBehavior } from "../disc-analysis-mode-model";
import type { DiscTrackWithMakeMkv } from "../disc-display-model";
import { isDiscProcessingMappingBlocked } from "../disc-verification-model";
import { useDiscAnalyzeSelection } from "./use-disc-analyze-selection";
import { useDiscAnalyzeVerification } from "./use-disc-analyze-verification";
import { useDiscAnalyzeSelectionView } from "./use-disc-analyze-selection-view";
import { useDiscAnalyzePreview } from "./use-disc-analyze-preview";
import { useDiscAnalyzeActions } from "./use-disc-analyze-actions";

export type DiscAnalyzeDialogProps = {
  discPath: string;
  processingMode: ProcessingMode;
  subtitleMode: SubtitleMode;
  ocrEngine?: string;
  ocrLanguage?: string;
  bilingualLayout?: "zh-top" | "foreign-top";
  uiText: ScanCopy;
  onClose: () => void;
  onJobCreated: (count: number, firstId?: number) => void;
  /** Smart Workflow hands the verified selection to the pre-queue preview page. */
  onAnalysisConfirmed?: (items: BatchItem[]) => void;
  onSelectMode?: (mode: ProcessingMode, subtitleMode?: SubtitleMode) => void;
  /** Smart Workflow analyzes the disc here and chooses the job mode later. */
  analysisOnly?: boolean;
};

export function useDiscAnalyzeDialog({
  discPath,
  processingMode: requestedProcessingMode,
  subtitleMode: requestedSubtitleMode,
  ocrEngine,
  ocrLanguage,
  bilingualLayout = "zh-top",
  uiText,
  onClose,
  onJobCreated,
  onAnalysisConfirmed,
  onSelectMode,
  analysisOnly = false,
}: DiscAnalyzeDialogProps) {
  const { t } = useI18n();
  const { data: appConfig } = useGetConfig({
    query: {
      queryKey: getGetConfigQueryKey(),
      refetchOnWindowFocus: false,
    },
  });
  const smartParseHasLlm = hasSelectedCloudLlmKey(appConfig);
  // A newly opened analysis must observe the current VOB layout. The server
  // may retain a five-minute snapshot for job hand-off, but the selection UI
  // must not show a stale title list after the source or parser changed.
  const { data, isLoading, isError } = useAnalyzeDisc({
    path: discPath,
    force: true,
  });
  // The dialog only needs a snapshot for the duplicate hint.  The server
  // performs the authoritative check when a job is created; polling the full
  // queue here used to rerender the whole preview every three seconds.
  const { data: existingJobs } = useListJobs(
    {},
    {
      query: {
        refetchInterval: false,
        refetchOnWindowFocus: false,
        staleTime: 30_000,
        queryKey: getListJobsQueryKey({}),
      },
    },
  );
  const createJob = useCreateJob();
  const { toast } = useToast();

  const [previewPage, setPreviewPage] = useState(0);
  // Normal workbench entries may choose a job mode here. Smart Workflow keeps
  // that decision for the next stage and uses this dialog only for analysis.
  const [processingMode, setProcessingMode] = useState<ProcessingMode>(
    requestedProcessingMode,
  );
  const [subtitleMode, setSubtitleMode] = useState<SubtitleMode>(
    requestedSubtitleMode,
  );
  const [modeChosen, setModeChosen] = useState(
    requestedProcessingMode !== "none" || requestedSubtitleMode !== "skip",
  );

  const {
    showModePicker,
    includeVideoStreams,
    verifyDvdTitles,
    filterTitlesByProcessingMode,
    allowJobCreation,
  } = discAnalysisDialogBehavior({
    analysisOnly,
    processingMode,
    subtitleMode,
  });

  useEffect(() => {
    setProcessingMode(requestedProcessingMode);
    setSubtitleMode(requestedSubtitleMode);
    setModeChosen(
      requestedProcessingMode !== "none" || requestedSubtitleMode !== "skip",
    );
  }, [requestedProcessingMode, requestedSubtitleMode]);

  const modeSelectionAttention =
    showModePicker && Boolean(data) && !isLoading && !isError && !modeChosen;

  const selection = useDiscAnalyzeSelection({
    data,
    includeVideoStreams,
    filterTitlesByProcessingMode,
    processingMode,
    verifyDvdTitles,
    setPreviewPage,
  });

  const verification = useDiscAnalyzeVerification({
    data,
    processingMode,
    verifyDvdTitles,
    activeTrackIdx: selection.activeTrackIdx,
    initializeTrackSelection: selection.initializeTrackSelection,
    t,
    toast,
  });

  const selectionView = useDiscAnalyzeSelectionView({
    data,
    processingMode,
    includeVideoStreams,
    verifyDvdTitles,
    filterTitlesByProcessingMode,
    analysisOnly,
    selection,
    verification,
    t,
    toast,
    setPreviewPage,
  });

  const preview = useDiscAnalyzePreview({
    data,
    activeTrackIdx: selection.activeTrackIdx,
    trackSummaries: selectionView.trackSummaries,
    setPreviewPage,
    t,
  });

  const actions = useDiscAnalyzeActions({
    data,
    discPath,
    processingMode,
    subtitleMode,
    ocrEngine,
    ocrLanguage,
    bilingualLayout,
    uiText,
    allowJobCreation,
    analysisOnly,
    includeVideoStreams,
    existingJobs,
    selection,
    verification,
    createJob,
    t,
    toast,
    onJobCreated,
    onClose,
    onAnalysisConfirmed,
  });

  function chooseProcessingMode(mode: ProcessingMode) {
    setProcessingMode(mode);
    setModeChosen(true);
    // Video actions do not run subtitle processing. Selecting the subtitle
    // action from the neutral workflow state needs an explicit usable mode.
    const nextSubtitleMode: SubtitleMode = mode === "none" ? "auto" : "skip";
    setSubtitleMode(nextSubtitleMode);
    // The neutral workflow initially exposes only audio/subtitle streams.
    // When the user confirms a video action, reconcile any existing selection
    // so a stale audio-only set cannot create an invalid DVD Remux snapshot.
    selection.setStreamSelections((current) => {
      if (!data) return current;
      const next = new Map(current);
      const indexes = new Set([
        ...current.keys(),
        ...selection.selectedTrackIndices,
      ]);
      for (const idx of indexes) {
        const track = data.tracks[idx] as DiscTrackWithMakeMkv | undefined;
        if (!track) continue;
        const existing = current.get(idx) ?? new Set<number>();
        const hasVideo = track.streams.some(
          (stream) =>
            stream.codecType === "video" && existing.has(stream.index),
        );
        if (mode !== "none" && !hasVideo) {
          next.set(idx, selection.defaultStreamSelection(track));
        } else if (mode === "none") {
          next.set(
            idx,
            new Set(
              Array.from(existing).filter((streamIndex) =>
                track.streams.some(
                  (stream) =>
                    stream.index === streamIndex &&
                    (stream.codecType === "audio" ||
                      stream.codecType === "subtitle"),
                ),
              ),
            ),
          );
        }
      }
      return next;
    });
    onSelectMode?.(mode, nextSubtitleMode);
  }

  const processingLabel = uiText.modes[processingMode].label;
  const processingMappingBlocked = isDiscProcessingMappingBlocked({
    processingMode,
    discType: data?.discType ?? "dvd",
    selectedIndexes: selection.selectedTrackIndices,
    getTrack: verification.effectiveTrack,
  });
  const isTrackSelectionDisabled = (idx: number): boolean =>
    selectionView.trackSummaries[idx]?.availabilityStatus === "unavailable" ||
    (processingMode === "remux" &&
      data?.discType === "dvd" &&
      !selection.selectedTrackIndices.has(idx) &&
      assessDiscRemuxCapacity({
        sourceBytes: data?.sourceSizeBytes,
        tracks: (data?.tracks ?? []) as Array<DiscTrackWithMakeMkv>,
        selectedIndexes: [...selection.selectedTrackIndices, idx],
      }).blocked);
  const selectedTrackPreviewKey = selectionView.selectedTrack?.titleId
    ? stableDiscTitleKey(
        data?.sourceFingerprint,
        selectionView.selectedTrack.titleId,
      )
    : "";
  const selectedTrackPreview =
    preview.previewByTitleId[selectedTrackPreviewKey];
  const showModeRequired =
    !analysisOnly &&
    !canCreateDiscJobsWithMode({
      processingMode,
      subtitleMode,
      selectedTitleCount: selection.selectedTrackIndices.size,
    }) &&
    selection.selectedTrackIndices.size > 0 &&
    !modeChosen;

  return {
    data,
    isLoading,
    isError,
    discType: data?.discType ?? "dvd",
    activeTrackIdx: selection.activeTrackIdx,
    selectedTrackIndices: selection.selectedTrackIndices,
    verifyingTracks: verification.verifyingTracks,
    trackSummaries: selectionView.trackSummaries,
    selectedTrack: selectionView.selectedTrack,
    selectedStreamIndices: selectionView.selectedStreamIndices,
    selectedChapterIds: selectionView.selectedChapterIds,
    selectableStreams: selectionView.selectableStreams,
    selectableDiscTitleCount: selectionView.selectableDiscTitleIndices.length,
    remuxCapacity: actions.remuxCapacity,
    previewPage,
    setPreviewPage,
    selectedTrackPreview,
    smartParsing: actions.smartParsing,
    smartNote: actions.smartNote,
    setSmartNote: actions.setSmartNote,
    smartParseHasLlm,
    processingMode,
    subtitleMode,
    modeChosen,
    creating: actions.creating,
    modeSelectionAttention,
    showModePicker,
    verifyDvdTitles,
    processingMappingBlocked,
    processingLabel,
    canCreate: actions.canCreate,
    showModeRequired,
    isTrackVisibleForMode: selectionView.isTrackVisibleForMode,
    isTrackSelectionDisabled,
    chooseProcessingMode,
    runSmartParse: actions.runSmartParse,
    handleTrackSelect: selectionView.handleTrackSelect,
    toggleTrackSelected: selectionView.toggleTrackSelected,
    setAllDiscTitlesSelected: selectionView.setAllDiscTitlesSelected,
    toggleStream: selectionView.toggleStream,
    toggleChapter: selectionView.toggleChapter,
    setAllStreamsSelected: selectionView.setAllStreamsSelected,
    setAllStreamsForSelectedTitles:
      selectionView.setAllStreamsForSelectedTitles,
    setAllChaptersSelected: selectionView.setAllChaptersSelected,
    requestReverification: verification.requestReverification,
    handleCreate: actions.handleCreate,
    confirmAnalysisSelection: actions.confirmAnalysisSelection,
  };
}
