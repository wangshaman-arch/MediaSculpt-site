import fs from "node:fs/promises";
import path from "node:path";

/**
 * Resolve a path to a directory that is guaranteed to exist before handing it
 * to Explorer/Finder/xdg-open. Output files are often not present yet (or may
 * have been removed after a failed task), so walk upward instead of claiming
 * success while opening a non-existent path.
 */
export async function resolveExistingOpenDirectory(
  inputPath: string,
): Promise<string> {
  if (!inputPath.trim()) throw new Error("路径为空");
  let current = path.resolve(inputPath);
  const initial = await fs.stat(current).catch(() => null);
  if (initial?.isDirectory()) return current;
  if (initial?.isFile()) current = path.dirname(current);
  else current = path.dirname(current);

  while (true) {
    const stat = await fs.stat(current).catch(() => null);
    if (stat?.isDirectory()) return current;
    const parent = path.dirname(current);
    if (parent === current) break;
    current = parent;
  }
  throw new Error(`找不到可打开的目录：${inputPath}`);
}
