import { useEffect, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import {
  getGetJobLogsQueryKey,
  getGetJobQueryKey,
  type Config,
  type Job,
} from "@workspace/api-client-react";
import type {
  AiGenerateOptions,
  AssistantPreferences,
  ProcessingStep,
  SubtitleChoice,
} from "../components/AssistantPanel";
import { useI18n } from "../i18n";
import {
  presetConfigValues,
  type ArchivePreset,
} from "../lib/compression-presets";
import { useToast } from "./use-toast";

export type AssistantIdentity = {
  titleEn: string;
  titleZh: string;
  year: number | null;
  imdbId: string;
};

type JobMutation = { mutateAsync: (input: { id: number }) => Promise<unknown> };

/** 片名/年代/IMDb 改动才提交，避免已完成任务被“重建重跑”。 */
export function buildJobMetadataPatch(
  job: Job | undefined,
  p: AssistantIdentity | null,
): Record<string, unknown> {
  const body: Record<string, unknown> = {};
  if (!p) return body;
  const titleZh = p.titleZh.trim() || job?.movieTitle || null;
  const titleEn = p.titleEn.trim() || job?.movieTitleEn || null;
  const year = p.year || null;
  const imdbId = p.imdbId.trim() || null;
  if (titleZh !== (job?.movieTitle ?? null)) body.movieTitle = titleZh;
  if (titleEn !== (job?.movieTitleEn ?? null)) body.movieTitleEn = titleEn;
  if (year !== (job?.movieYear ?? null)) body.movieYear = year;
  if ((imdbId ?? null) !== (job?.movieImdbId ?? null))
    body.movieImdbId = imdbId;
  return body;
}

/**
 * 处理流程 / 字幕策略变更补丁；章节预览与其他步骤并存时，主任务剔除章节预览
 * （章节预览由调用方另建独立任务）。
 */
export function buildPipelinePatch({
  processing,
  baselineProcessing,
  subtitle,
  baselineSubtitle,
  chapterSamplePosition,
}: {
  processing: ProcessingStep[];
  baselineProcessing: ProcessingStep[];
  subtitle: SubtitleChoice | null;
  baselineSubtitle: SubtitleChoice | null;
  chapterSamplePosition: "middle" | "start" | "end";
}): { patch: Record<string, unknown>; previewPlusOthers: boolean } {
  const previewPlusOthers =
    processing.includes("chapterPreview") &&
    processing.some((step) => step !== "chapterPreview");
  const mainSteps = previewPlusOthers
    ? processing.filter((step) => step !== "chapterPreview")
    : processing;
  const patch: Record<string, unknown> = {};
  if (JSON.stringify(processing) !== JSON.stringify(baselineProcessing)) {
    patch.pipelineSteps = mainSteps;
    if (processing.includes("chapterPreview")) {
      patch.chapterSamplePosition = chapterSamplePosition;
    }
  }
  if (subtitle !== baselineSubtitle) patch.subtitleMode = subtitle;
  return { patch, previewPlusOthers };
}

/** 预设被手动改选时提交 presetId 与冻结的压缩参数。 */
export function buildCompressionPatch({
  selectedPresetLabel,
  compressionPresets,
  config,
}: {
  selectedPresetLabel: string;
  compressionPresets: ArchivePreset[];
  config: Config | undefined;
}): Record<string, unknown> {
  const body: Record<string, unknown> = {
    presetId: selectedPresetLabel || null,
  };
  const selectedPreset = compressionPresets.find(
    (preset) => preset.id === selectedPresetLabel,
  );
  if (selectedPreset) {
    body.compressionSettings = presetConfigValues(selectedPreset);
  } else if (selectedPresetLabel === "custom" && config) {
    body.compressionSettings = {
      encoder: config.encoder,
      crf: config.crf,
      encoderPreset: config.encoderPreset,
      encoderTune: config.encoderTune,
      encoderProfile: config.encoderProfile,
      encoderLevel: config.encoderLevel,
      frameRate: config.frameRate,
      outputResolution: config.outputResolution,
    };
  }
  return body;
}

/**
 * 智能助手执行状态：任务当前 AI 生成开关的同步、用户偏好变更的联动，以及“确认”时
 * 把片名/流程/字幕/预设真正写回任务（含章节预览独立任务与已完成任务的即时生成）。
 */
export function useJobAssistantExecution({
  jobId,
  job,
  config,
  assistantOpen,
  chapterSamplePosition,
  assistantBaselineProcessing,
  assistantBaselineSubtitle,
  selectedPresetLabel,
  compressionPresets,
  presetDirtyRef,
  aiAvailable,
  setEffectivePipeline,
  setAssistantOpen,
  setDetailsDrawerOpen,
  startJob,
}: {
  jobId: number;
  job: Job | undefined;
  config: Config | undefined;
  assistantOpen: boolean;
  chapterSamplePosition: "middle" | "start" | "end";
  assistantBaselineProcessing: ProcessingStep[];
  assistantBaselineSubtitle: SubtitleChoice | null;
  selectedPresetLabel: string;
  compressionPresets: ArchivePreset[];
  presetDirtyRef: React.MutableRefObject<boolean>;
  aiAvailable: boolean;
  setEffectivePipeline: (pipeline: string[] | null) => void;
  setAssistantOpen: (open: boolean) => void;
  setDetailsDrawerOpen: (open: boolean) => void;
  startJob: JobMutation;
}) {
  const { t } = useI18n();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const assistantPrefsRef = useRef<AssistantIdentity | null>(null);
  // 智能助手面板中确认要应用的处理流程 / 字幕策略；只有用户实际改动过才会提交。
  const assistantExecutionRef = useRef<{
    processing: ProcessingStep[];
    subtitle: SubtitleChoice | null;
  }>({ processing: [], subtitle: null });
  const assistantGenRef = useRef<AiGenerateOptions>({
    generateReadme: false,
    generatePoster: false,
    generateReview: false,
  });
  const assistantExecutionDirtyRef = useRef(false);
  // 记录上一次同步给详情区的处理流程/字幕策略，用于区分“用户改步骤”与“标题等无关编辑”。
  const lastAssistantPrefsRef = useRef<{
    processing: ProcessingStep[];
    subtitle: SubtitleChoice | null;
  } | null>(null);

  // 打开助手时，以任务当前 AI 生成开关为初始值
  useEffect(() => {
    if (assistantOpen) {
      const raw = job as
        | {
            generateReadme?: boolean;
            generatePoster?: boolean;
            generateReview?: boolean;
          }
        | undefined;
      assistantGenRef.current = {
        generateReadme: raw?.generateReadme === true,
        generatePoster: raw?.generatePoster === true,
        generateReview: raw?.generateReview === true,
      };
    }
  }, [assistantOpen, job]);

  const handlePreferencesChange = (prefs: AssistantPreferences) => {
    // 标题/年代/IMDb 等编辑也会走到这里，但它们不应联动详情；
    // 只有处理流程或字幕策略真正变化时才打开详情抽屉。
    const prev = lastAssistantPrefsRef.current;
    const processingChanged =
      !prev ||
      JSON.stringify(prev.processing) !== JSON.stringify(prefs.processing);
    const subtitleChanged = !prev || prev.subtitle !== prefs.subtitle;
    // 首次同步（打开面板时的源名回填）不算用户操作，不联动详情。
    lastAssistantPrefsRef.current = {
      processing: [...prefs.processing],
      subtitle: prefs.subtitle,
    };
    assistantPrefsRef.current = {
      titleEn: prefs.titleEn,
      titleZh: prefs.titleZh,
      year: prefs.year,
      imdbId: prefs.imdbId,
    };
    const baselineChanged =
      JSON.stringify(prefs.processing) !==
        JSON.stringify(assistantBaselineProcessing) ||
      prefs.subtitle !== assistantBaselineSubtitle;
    assistantExecutionRef.current = {
      processing: [...prefs.processing],
      subtitle: prefs.subtitle,
    };
    if (baselineChanged) assistantExecutionDirtyRef.current = true;
    setEffectivePipeline(prefs.processing);
    if (!processingChanged && !subtitleChanged) return;
    // 只负责“步骤变化时打开详情抽屉”；展开/滚动由 onFeatureClick 精确处理，
    // 否则点字幕时会强制展开压缩参数区，与字幕区块的切换互相干扰。
    setDetailsDrawerOpen(true);
  };

  // 章节预览与其他步骤同时选择时，为当前任务源创建独立的章节预览任务。
  const buildChapterPreviewJobBody = (
    position: "middle" | "start" | "end",
  ): Record<string, unknown> => {
    let plan: Record<string, unknown> = {};
    try {
      plan = job?.selectionPlan
        ? (JSON.parse(job.selectionPlan) as Record<string, unknown>)
        : {};
    } catch {
      /* 使用空计划 */
    }
    const analysis = (plan.analysis ?? {}) as Record<string, unknown>;
    if (job?.mediaType && job.mediaType !== "video") {
      const video = Array.isArray(plan.video) ? plan.video : [];
      const audio = Array.isArray(plan.audio) ? plan.audio : [];
      const subtitle = Array.isArray(plan.subtitle) ? plan.subtitle : [];
      const chapterCount = Array.isArray(plan.chapters)
        ? plan.chapters.length
        : 0;
      const chapterArr =
        chapterCount > 0
          ? Array.from({ length: chapterCount }, (_, index) => index)
          : [0];
      return {
        filePath: job.filePath,
        subtitleMode: "skip",
        mediaType: job.mediaType,
        processingMode: "chapterPreview",
        outputMode: "compress",
        mainTrackPath: job.mainTrackPath ?? undefined,
        selectedStreams: JSON.stringify([...video, ...audio, ...subtitle]),
        selectedChapters: JSON.stringify(chapterArr),
        selectionPlan: JSON.stringify({
          ...plan,
          chapterSamplePosition: position,
        }),
        analysisId:
          typeof analysis.analysisId === "string"
            ? analysis.analysisId
            : undefined,
        sourceFingerprint:
          typeof plan.sourceFingerprint === "string"
            ? plan.sourceFingerprint
            : undefined,
        selectedTitleId:
          typeof analysis.titleId === "string" ? analysis.titleId : undefined,
      };
    }
    return {
      filePath: job?.filePath ?? "",
      subtitleMode: "skip",
      mediaType: "video",
      processingMode: "chapterPreview",
      outputMode: "compress",
      selectedStreams: job?.selectedStreams ?? undefined,
      selectedChapters: "[]",
      selectionPlan: JSON.stringify({
        version: 1,
        chapterSamplePosition: position,
      }),
    };
  };

  const handleConfirm = async () => {
    // 确认：把校对后的片名/年代、处理流程、字幕策略、画质预设真正应用到任务。
    const p = assistantPrefsRef.current;
    const execution = assistantExecutionRef.current;
    const processing = execution.processing;
    // 章节预览与其他步骤同时选择：主任务执行其余步骤，章节预览另建独立预览任务。
    const previewPlusOthers =
      processing.includes("chapterPreview") &&
      processing.some((step) => step !== "chapterPreview");
    const body = buildJobMetadataPatch(job, p);
    if (assistantExecutionDirtyRef.current) {
      // 处理流程变化（含清空=不做任何视频处理）都提交：
      // 空数组也必须传给后端，否则任务会保留原处理模式继续压缩。
      Object.assign(
        body,
        buildPipelinePatch({
          processing,
          baselineProcessing: assistantBaselineProcessing,
          subtitle: execution.subtitle,
          baselineSubtitle: assistantBaselineSubtitle,
          chapterSamplePosition,
        }).patch,
      );
    }
    if (presetDirtyRef.current) {
      Object.assign(
        body,
        buildCompressionPatch({
          selectedPresetLabel,
          compressionPresets,
          config,
        }),
      );
    }
    const gen = assistantGenRef.current;
    try {
      // 1) 持久化 AI 生成开关（任何状态的任务都可更新）
      await fetch(`/api/jobs/${jobId}/ai-options`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(gen),
      });
      // 2) 其他执行选项（片名/流程/字幕/预设）仅在确实改动时才提交，
      //    避免只勾选 AI 生成时把已完成任务重建成新任务重跑。
      if (Object.keys(body).length > 0) {
        const response = await fetch(`/api/jobs/${jobId}/execution`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        const data = (await response.json().catch(() => ({}))) as {
          id?: number;
          recreated?: boolean;
          error?: string;
        };
        if (!response.ok)
          throw new Error(data.error ?? `HTTP ${response.status}`);
        queryClient.invalidateQueries({
          queryKey: getGetJobQueryKey(jobId),
        });
        queryClient.invalidateQueries({
          queryKey: getGetJobLogsQueryKey(jobId),
        });
        // 章节预览与其他步骤并存：主任务已应用，另建独立章节预览任务。
        if (previewPlusOthers) {
          try {
            const previewResponse = await fetch("/api/jobs", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(
                buildChapterPreviewJobBody(chapterSamplePosition),
              ),
            });
            if (previewResponse.ok) {
              const previewData = (await previewResponse
                .json()
                .catch(() => null)) as { id?: number } | null;
              toast({
                title: t("assistant.chapterPreviewJobCreated", {
                  id: previewData?.id ?? "",
                }),
              });
            } else {
              const previewError = (await previewResponse
                .json()
                .catch(() => null)) as { error?: string } | null;
              toast({
                title: t("assistant.chapterPreviewJobFailed"),
                description: previewError?.error,
                variant: "destructive",
              });
            }
          } catch (error) {
            toast({
              title: t("assistant.chapterPreviewJobFailed"),
              description:
                error instanceof Error ? error.message : String(error),
              variant: "destructive",
            });
          }
        }
        if (data.recreated && typeof data.id === "number") {
          toast({
            title: t("assistant.executionRecreated", { id: data.id }),
          });
          setAssistantOpen(false);
          setLocation("/jobs");
          startJob.mutateAsync({ id: data.id }).catch(() => {});
          return;
        }
      }
      // 3) 已完成任务：立即生成所勾选的 Readme / 影评 / 海报
      if (job?.status === "done") {
        const tasks: Array<Promise<Response>> = [];
        if (gen.generateReadme)
          tasks.push(fetch(`/api/jobs/${jobId}/readme`, { method: "POST" }));
        if (gen.generateReview && aiAvailable)
          tasks.push(fetch(`/api/jobs/${jobId}/review`, { method: "POST" }));
        if (gen.generatePoster)
          tasks.push(fetch(`/api/jobs/${jobId}/poster`, { method: "POST" }));
        if (tasks.length > 0) {
          const results = await Promise.allSettled(tasks);
          const okCount = results.filter(
            (r) => r.status === "fulfilled" && (r.value as Response).ok,
          ).length;
          toast({
            title: t("jobDetail.aiGenerateStarted"),
            description:
              okCount > 0
                ? t("jobDetail.aiGenerateDone", { count: okCount })
                : t("jobDetail.aiGenerateFailed"),
          });
          queryClient.invalidateQueries({
            queryKey: getGetJobQueryKey(jobId),
          });
        }
      }
      toast({ title: t("assistant.executionApplied") });
      setAssistantOpen(false);
      // 确认完成后进入任务队列阶段，不在设置与预览环节停留。
      setLocation("/jobs");
    } catch (error) {
      toast({
        title: t("assistant.executionFailed"),
        description: error instanceof Error ? error.message : String(error),
      });
    }
  };

  const resetAssistantExecution = () => {
    lastAssistantPrefsRef.current = null;
    assistantPrefsRef.current = null;
    assistantExecutionRef.current = { processing: [], subtitle: null };
    assistantExecutionDirtyRef.current = false;
  };

  return {
    assistantGenRef,
    handlePreferencesChange,
    handleConfirm,
    resetAssistantExecution,
  };
}
