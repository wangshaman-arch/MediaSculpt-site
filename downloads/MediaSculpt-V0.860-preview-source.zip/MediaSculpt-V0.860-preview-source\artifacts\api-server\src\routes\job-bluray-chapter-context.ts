export type BlurayChapterRecord = {
  id: number;
  startSeconds: number;
  endSeconds: number;
  title: string | null;
};

/** Read chapter times frozen in a job selection plan. */
export function readPersistedBlurayChapters(
  selectionPlan: string | null | undefined,
): BlurayChapterRecord[] {
  try {
    const parsed = selectionPlan
      ? (JSON.parse(selectionPlan) as { chapterTimes?: unknown })
      : null;
    if (
      !Array.isArray(parsed?.chapterTimes) ||
      parsed.chapterTimes.length === 0
    )
      return [];
    return parsed.chapterTimes.map((chapter) => {
      const value = chapter as {
        id?: unknown;
        startSeconds?: unknown;
        endSeconds?: unknown;
      };
      return {
        id: Number(value.id) || 0,
        startSeconds: Number(value.startSeconds) || 0,
        endSeconds: Number(value.endSeconds) || 0,
        title: null,
      };
    });
  } catch {
    return [];
  }
}

/** Choose the frozen HandBrake title, or the closest title by duration. */
export function chooseBlurayHandBrakeChapterTitle<
  T extends {
    titleNumber: number;
    durationSeconds: number | null;
    chapters: unknown[];
  },
>(
  titles: T[],
  selectedTitleId: string | null | undefined,
  expectedDurationSeconds: number | null,
): T | null {
  const selected = titles.find(
    (title) => `handbrake:${title.titleNumber}` === selectedTitleId,
  );
  if (selected) return selected;
  return (
    titles
      .slice()
      .sort(
        (a, b) =>
          Math.abs((a.durationSeconds ?? 0) - (expectedDurationSeconds ?? 0)) -
          Math.abs((b.durationSeconds ?? 0) - (expectedDurationSeconds ?? 0)),
      )[0] ?? null
  );
}

/** Clamp chapter ends to the retained media and remove invalid duplicates. */
export function clampBlurayChapters(
  chapters: BlurayChapterRecord[],
  effectiveDuration: number,
): BlurayChapterRecord[] {
  return chapters
    .map((chapter) => ({
      ...chapter,
      endSeconds: Math.min(chapter.endSeconds, effectiveDuration),
    }))
    .filter((chapter) => chapter.endSeconds > chapter.startSeconds)
    .filter((chapter) => chapter.startSeconds < effectiveDuration)
    .sort((a, b) => a.startSeconds - b.startSeconds)
    .filter(
      (chapter, index, all) =>
        index === 0 || chapter.startSeconds > all[index - 1].startSeconds,
    );
}
