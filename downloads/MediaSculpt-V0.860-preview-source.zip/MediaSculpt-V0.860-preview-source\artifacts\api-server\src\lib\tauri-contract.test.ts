import { existsSync, readdirSync } from "node:fs";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { describe, expect, it } from "vitest";

const configPath = path.resolve(
  import.meta.dirname,
  "../../../../desktop-tauri/src-tauri/tauri.conf.json",
);
const projectRoot = path.resolve(import.meta.dirname, "../../../..");

async function readProjectFile(relativePath: string): Promise<string> {
  return readFile(path.join(projectRoot, relativePath), "utf8");
}

describe("MediaSculpt Tauri configuration", () => {
  it("packages MediaSculpt as an NSIS app with its supplied icon", async () => {
    const config = JSON.parse(await readFile(configPath, "utf8"));

    expect(config.productName).toBe("MediaSculpt");
    expect(config.identifier).toBe("com.wangshaman.mediasculpt");
    expect(config.bundle.targets).toBe("nsis");
    expect(config.bundle.icon).toContain("icons/icon.png");
    expect(config.build.frontendDist).toBe(
      "../../artifacts/video-agent/dist/public",
    );
    expect(config.build.beforeBuildCommand).toContain(
      "../scripts/build-tauri.ps1",
    );
    expect(config.build.beforeDevCommand).toContain(
      "../scripts/start-tauri-dev.ps1",
    );
    expect(config.bundle.resources).toMatchObject({
      "resources/sidecar": "sidecar",
      "resources/tools": "tools",
      "resources/WebView2Loader.dll": "WebView2Loader.dll",
    });
    expect(config.bundle.windows.nsis.startMenuFolder).toBe("MediaSculpt");
    expect(config.bundle.windows.nsis.installMode).toBe("currentUser");
    expect(config.bundle.windows.webviewInstallMode).toEqual({
      type: "embedBootstrapper",
      silent: true,
    });
    await expect(
      readProjectFile("artifacts/video-agent/public/vx-agent-256.png"),
    ).rejects.toThrow();
    await expect(
      readProjectFile("artifacts/video-agent/public/vx-agent.ico"),
    ).rejects.toThrow();
  });

  it("starts the packaged window from the local API after its sidecar is ready", async () => {
    const [main, sidecar, capability] = await Promise.all([
      readProjectFile("desktop-tauri/src-tauri/src/main.rs"),
      readProjectFile("desktop-tauri/src-tauri/src/sidecar.rs"),
      readProjectFile("desktop-tauri/src-tauri/capabilities/default.json"),
    ]);

    expect(main).toContain("WebviewUrl::External");
    expect(main).toContain('"http://127.0.0.1:18080"');
    expect(main).not.toContain("http://127.0.0.1:18080/workbench");
    expect(main).toContain(".decorations(false)");
    expect(main).toContain(
      "let (window_width, window_height, min_window_width, min_window_height)",
    );
    expect(main).toContain(".inner_size(window_width, window_height)");
    expect(main).toContain(
      ".min_inner_size(min_window_width, min_window_height)",
    );
    expect(main).toContain('windows_subsystem = "windows"');
    expect(main).toContain("fn notify_task_complete(");
    expect(main).toContain(
      "request_user_attention(Some(UserAttentionType::Informational))",
    );
    expect(sidecar).toContain(".current_dir(");
    expect(sidecar).toContain("MEDIASCULPT_RELEASE_ID");
    expect(sidecar).toContain("CREATE_NO_WINDOW");
    expect(sidecar).toContain("validate_startup_resources");
    expect(sidecar).toContain("ensure_api_port_available");
    expect(sidecar).toContain("MissingResource");
    expect(sidecar).toContain("PortInUse");
    expect(sidecar).toContain("append_diagnostics");
    expect(capability).toContain("allow-minimize-window");
    expect(capability).toContain("allow-toggle-maximize-window");
    expect(capability).toContain("allow-close-window");
    expect(sidecar).toContain("const API_PORT: u16 = 18080");
  });

  it("opens directly into the smart workflow with the branded hybrid title bar", async () => {
    const app = await readProjectFile("artifacts/video-agent/src/App.tsx");

    expect(app).toContain('t("brand.desktopTitle")');
    expect(app).toContain('data-testid="desktop-titlebar"');
    expect(app).toContain("data-tauri-drag-region");
    expect(app).toContain('data-testid="desktop-window-controls"');
    expect(app).toContain("desktop-titlebar-spacer");
    expect(app).toContain('href: "/jobs"');
    expect(app).toContain('<Redirect to="/workbench?tab=workflow" />');
  });

  it("is the only desktop shell in the repository", async () => {
    expect(existsSync(path.join(projectRoot, "desktop-shell"))).toBe(false);
    const files = [
      ...readdirSync(path.join(projectRoot, "windows-setup"))
        .filter((name) => /\.(ps1|vbs)$/.test(name))
        .map((name) => `windows-setup/${name}`),
      ...readdirSync(path.join(projectRoot, "scripts"))
        .filter((name) => name.endsWith(".ps1"))
        .map((name) => `scripts/${name}`),
      "artifacts/video-agent/src/lib/desktop-bridge.ts",
      "artifacts/video-agent/src/index.css",
      ".github/workflows/windows-script-compatibility.yml",
      ".gitignore",
    ];
    for (const file of files) {
      expect(await readProjectFile(file), file).not.toMatch(
        /electron|desktop-shell/i,
      );
    }
  });

  it("keeps the desktop shell registered with its CLI dependency locked", async () => {
    const [workspace, lockfile] = await Promise.all([
      readProjectFile("pnpm-workspace.yaml"),
      readProjectFile("pnpm-lock.yaml"),
    ]);

    expect(workspace).toMatch(/^\s*- desktop-tauri\s*$/m);
    expect(lockfile).toMatch(/\r?\n  desktop-tauri:\r?\n/);
    expect(lockfile).toMatch(/@tauri-apps\/cli@2\.\d+\.\d+/);
  });
});
