import { describe, expect, it } from "vitest";
import type { HandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import {
  createMediaPipelineManifest,
  type MediaPipelineInput,
} from "./media-pipeline-contract";
import {
  buildHandBrakeCompressionArgs,
  buildHandBrakeCompressionArgsFromManifest,
  buildHandBrakeSelectionPlanFromManifest,
} from "./compression-service";

const baseConfig = {
  encoder: "x265",
  crf: 22,
  outputFormat: "mkv",
  audioCopy: false,
  encoderPreset: "slow",
  encoderTune: "grain",
  encoderProfile: "main10",
  encoderLevel: "5.1",
  frameRate: "same",
  outputResolution: "1080p",
};

describe("buildHandBrakeCompressionArgs", () => {
  function manifest() {
    const input: MediaPipelineInput = {
      source: {
        kind: "dvd",
        path: "D:\\DVD",
        fingerprint: "dvd-v1",
        physicalBytes: 7_000_000_000,
      },
      title: {
        id: "handbrake:1",
        titleNumber: 7,
        durationSeconds: 5_400,
        streams: [
          { id: "video:0", index: 0, type: "video", codec: "mpeg2video" },
          {
            id: "audio:1",
            index: 1,
            type: "audio",
            codec: "ac3",
            handbrakeTrackNumber: 1,
          },
          {
            id: "subtitle:2",
            index: 2,
            type: "subtitle",
            codec: "dvd_subtitle",
            handbrakeTrackNumber: 1,
          },
        ],
        chapters: [
          { id: 1, startSeconds: 0, endSeconds: 5_400, title: "Main" },
        ],
      },
      selection: {
        streamIds: ["video:0", "audio:1", "subtitle:2"],
        chapterIds: [1],
      },
      output: {
        mode: "compress",
        directory: "D:\\Output",
        fileName: "Movie.mkv",
      },
    };
    return createMediaPipelineManifest(input);
  }

  it("builds compression selection from the same manifest without using physical source size", () => {
    const plan = buildHandBrakeSelectionPlanFromManifest(manifest());

    expect(plan).toMatchObject({
      video: [0],
      audio: [1],
      subtitle: [2],
      chapters: [1],
      handbrake: {
        titleNumber: 7,
        titleSizeBytes: null,
        durationSeconds: 5_400,
        audioTrackNumbers: [1],
        subtitleTrackNumbers: [1],
        chapterNumbers: [1],
      },
    });
  });

  it("builds HandBrake arguments from the immutable manifest selections", () => {
    const result = buildHandBrakeCompressionArgsFromManifest({
      manifest: manifest(),
      config: baseConfig,
      deinterlace: false,
    });

    expect(result.args).toEqual(
      expect.arrayContaining([
        "-i",
        "D:/DVD",
        "-o",
        "D:/Output/Movie.mkv",
        "--title",
        "7",
        "--audio",
        "1",
        "--subtitle",
        "1",
        "--chapters",
        "1",
        "--markers",
      ]),
    );
    expect(result.args).not.toContain("--all-audio");
    expect(result.args).not.toContain("--all-subtitles");
  });

  it("blocks a disc compression selection when a selected track has no verified HandBrake number", () => {
    const inputManifest = manifest();
    expect(() =>
      buildHandBrakeSelectionPlanFromManifest(
        createMediaPipelineManifest({
          source: inputManifest.source,
          title: {
            ...inputManifest.title,
            streams: inputManifest.title.streams.map((stream) =>
              stream.id === "audio:1"
                ? { ...stream, handbrakeTrackNumber: null }
                : stream,
            ),
          },
          selection: inputManifest.selection,
          output: inputManifest.output,
        }),
      ),
    ).toThrow("缺少已验证的 HandBrake 音轨编号");
  });

  it("builds explicit title, stream, codec and output arguments", () => {
    const plan: HandBrakeSelectionPlan = {
      version: 1,
      video: [0],
      audio: [1],
      subtitle: [2],
      chapters: [1, 2, 3],
      handbrake: {
        titleNumber: 4,
        audioTrackNumbers: [1],
        subtitleTrackNumbers: [1],
        chapterNumbers: [1, 2, 3],
      },
    };
    const result = buildHandBrakeCompressionArgs({
      inputPath: "D:/source/VIDEO_TS",
      outputPath: "D:/output/movie.mkv",
      config: baseConfig,
      selectionPlan: plan,
      deinterlace: true,
    });

    expect(result.selectionArgs).toEqual(
      expect.arrayContaining([
        "--title",
        "4",
        "--audio",
        "1",
        "--subtitle",
        "1",
        "--chapters",
        "1-3",
      ]),
    );
    expect(result.args).toEqual(
      expect.arrayContaining([
        "-i",
        "D:/source/VIDEO_TS",
        "-o",
        "D:/output/movie.mkv",
        "--encoder",
        "x265",
        "--quality",
        "22",
        "--format",
        "av_mkv",
        "--encoder-preset",
        "slow",
        "--encoder-tune",
        "grain",
        "--encoder-profile",
        "main10",
        "--encoder-level",
        "5.1",
        "--vfr",
        "--height",
        "1080",
        "--deinterlace",
      ]),
    );
  });

  it("keeps all streams when no precise plan exists", () => {
    const result = buildHandBrakeCompressionArgs({
      inputPath: "movie.mkv",
      outputPath: "movie-out.mkv",
      config: {
        ...baseConfig,
        encoder: "x264",
        audioCopy: true,
        frameRate: "24",
        outputResolution: "source",
      },
      selectionPlan: null,
      deinterlace: false,
    });

    expect(result.selectionArgs).toEqual([]);
    expect(result.args).toEqual(
      expect.arrayContaining([
        "--aencoder",
        "copy",
        "--all-audio",
        "--all-subtitles",
        "--rate",
        "24",
        "--cfr",
      ]),
    );
    expect(result.args).not.toContain("--deinterlace");
  });
});
