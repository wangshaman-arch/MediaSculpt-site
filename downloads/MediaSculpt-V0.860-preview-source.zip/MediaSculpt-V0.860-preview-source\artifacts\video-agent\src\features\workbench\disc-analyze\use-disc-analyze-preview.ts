import { useState, useEffect } from "react";
import type { AnalyzeDiscQueryResult } from "@workspace/api-client-react";
import type { DiscTitlePreviewState } from "@/pages/Scan";
import { stableDiscTitleKey } from "@/pages/scan-model";
import type { DiscTrackWithMakeMkv } from "../disc-display-model";

type Translate = (
  path: string,
  params?: Record<string, string | number>,
) => string;

/**
 * Loads and caches the per-title preview image for the currently focused title.
 */
export function useDiscAnalyzePreview({
  data,
  activeTrackIdx,
  trackSummaries,
  setPreviewPage,
  t,
}: {
  data: AnalyzeDiscQueryResult | undefined;
  activeTrackIdx: number;
  trackSummaries: DiscTrackWithMakeMkv[];
  setPreviewPage: (page: number) => void;
  t: Translate;
}) {
  const [previewByTitleId, setPreviewByTitleId] = useState<
    Record<string, DiscTitlePreviewState>
  >({});
  const [previewGeneration, setPreviewGeneration] = useState(0);

  useEffect(() => {
    setPreviewByTitleId({});
    setPreviewGeneration((value) => value + 1);
    setPreviewPage(0);
  }, [data?.analysisId, data?.sourceFingerprint, setPreviewPage]);

  useEffect(() => {
    const track =
      activeTrackIdx >= 0 ? trackSummaries[activeTrackIdx] : undefined;
    const titleId = track?.titleId;
    const previewKey = titleId
      ? stableDiscTitleKey(data?.sourceFingerprint, titleId)
      : "";
    if (
      !titleId ||
      !data?.analysisId ||
      previewByTitleId[previewKey]?.status === "loading" ||
      previewByTitleId[previewKey]?.status === "ready"
    )
      return;
    const generation = previewGeneration;
    setPreviewByTitleId((current) => ({
      ...current,
      [previewKey]: { status: "loading" },
    }));
    const params = new URLSearchParams({
      analysisId: data.analysisId,
      titleId,
      source: data.sourceFingerprint,
    });
    fetch(`/api/disc/title-preview?${params.toString()}`)
      .then(async (response) => {
        if (!response.ok)
          throw new Error(
            (await response.text().catch(() => "")) ||
              t("scan.previewServiceUnavailable"),
          );
        const body = (await response.json()) as {
          url?: string;
          previews?: string[];
          warning?: string;
        };
        if (!body.url) throw new Error(t("scan.previewNoImage"));
        const primaryUrl = body.url;
        const previews = (body.previews ?? [primaryUrl]).filter(
          (preview): preview is string =>
            typeof preview === "string" && preview.length > 0,
        );
        if (generation !== previewGeneration) return;
        setPreviewByTitleId((current) => ({
          ...current,
          [previewKey]: {
            status: "ready",
            url: primaryUrl,
            previews,
            warning: body.warning,
          },
        }));
      })
      .catch((error) => {
        if (generation !== previewGeneration) return;
        setPreviewByTitleId((current) => ({
          ...current,
          [previewKey]: {
            status: "failed",
            message: error instanceof Error ? error.message : String(error),
          },
        }));
      });
  }, [
    activeTrackIdx,
    data?.analysisId,
    data?.sourceFingerprint,
    previewByTitleId,
    previewGeneration,
    trackSummaries,
    t,
  ]);

  return {
    previewByTitleId,
    setPreviewByTitleId,
    previewGeneration,
  };
}

export type DiscAnalyzePreviewState = ReturnType<typeof useDiscAnalyzePreview>;
