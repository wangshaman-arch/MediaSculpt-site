import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { getToolPackage, ghMirrorChain } from "./tool-manifest";
import {
  candidatePaths,
  executableName,
  resolveToolPath,
  type ToolId,
} from "./tool-runtime";

const execFileAsync = promisify(execFile);
export type DownloadProgress = {
  receivedBytes: number;
  totalBytes: number | null;
  percent: number | null;
};
export type DownloadToolOptions = {
  sha256?: string;
  /** Replace an existing install instead of reusing it (explicit reinstall). */
  force?: boolean;
  /** Tesseract language data (traineddata codes) to install next to the binary. */
  tesseractLanguages?: string[];
  onProgress?: (progress: DownloadProgress) => void;
  onLog?: (message: string) => void | Promise<void>;
};

export type SourceProbeResult = {
  url: string;
  ok: boolean;
  latencyMs: number;
  bytesPerSecond: number | null;
  status: number | null;
  directFile: boolean;
};

const DIRECT_FILE_EXT_RE =
  /\.(zip|exe|7z|tgz|tar(\.gz|\.bz2|\.xz)?|gz|bz2|xz|msi|dmg|whl|py|pkg|deb|rpm|apk)([?#].*)?$/i;

/** 判断 URL 是否指向可直接下载的文件（vs. releases 目录页/说明页）。 */
export function isDirectDownloadUrl(url: string): boolean {
  try {
    return DIRECT_FILE_EXT_RE.test(new URL(url).pathname);
  } catch {
    return false;
  }
}

/**
 * 校验下载内容的文件头魔数是否与扩展名匹配。有些镜像对失效文件也返回
 * HTTP 200（错误页/重定向页），仅靠状态码无法识别，必须看真实字节。
 */
export function fileMagicMatches(fileName: string, head: Uint8Array): boolean {
  const ext = path.extname(fileName).toLowerCase();
  const bytes = (offset: number, expected: number[]) =>
    head.length >= offset + expected.length &&
    expected.every((value, index) => head[offset + index] === value);
  switch (ext) {
    case ".exe":
    case ".msi":
      // PE 可执行文件以 MZ 开头。
      return bytes(0, [0x4d, 0x5a]);
    case ".zip":
    case ".whl":
    case ".apk":
      return bytes(0, [0x50, 0x4b]);
    case ".7z":
      return bytes(0, [0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c]);
    case ".gz":
    case ".tgz":
      return bytes(0, [0x1f, 0x8b]);
    case ".bz2":
      return bytes(0, [0x42, 0x5a, 0x68]);
    case ".xz":
      return bytes(0, [0xfd, 0x37, 0x7a, 0x58, 0x5a, 0x00]);
    default:
      // 未知/脚本类文件不校验，避免误杀。
      return true;
  }
}

/**
 * 对多个下载源做并行基础探测（小范围 Range GET，最多 timeoutMs），
 * 量测连通性、响应延迟和首段下载速度，供“哪个快用哪个”排序。
 */
export async function probeDownloadSources(
  sources: string[],
  options: {
    timeoutMs?: number;
    readMs?: number;
    maxBytes?: number;
    onLog?: (message: string) => void | Promise<void>;
  } = {},
): Promise<SourceProbeResult[]> {
  const timeoutMs = options.timeoutMs ?? 8_000;
  const readMs = options.readMs ?? 5_000;
  const maxBytes = options.maxBytes ?? 512 * 1024;
  const log = async (message: string) => {
    await options.onLog?.(message);
  };
  const probeOne = async (url: string): Promise<SourceProbeResult> => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const started = performance.now();
    let status: number | null = null;
    let received = 0;
    const head: number[] = [];
    try {
      const response = await fetch(url, {
        headers: { Range: "bytes=0-262143" },
        redirect: "follow",
        signal: controller.signal,
      });
      const latencyMs = Math.round(performance.now() - started);
      status = response.status;
      const reader = response.body?.getReader();
      const deadline = performance.now() + readMs;
      while (reader && performance.now() < deadline && received < maxBytes) {
        const { done, value } = await reader.read();
        if (done) break;
        received += value?.byteLength ?? 0;
        for (const byte of value ?? []) {
          if (head.length < 16) head.push(byte);
          else break;
        }
      }
      await reader?.cancel().catch(() => {});
      const elapsedSec = Math.max((performance.now() - started) / 1000, 0.001);
      const bytesPerSecond =
        received > 0 ? Math.round(received / elapsedSec) : null;
      const magicOk =
        isDirectDownloadUrl(url) && received > 0
          ? fileMagicMatches(new URL(url).pathname, new Uint8Array(head))
          : true;
      const ok = (response.ok || response.status === 206) && magicOk;
      await log(
        `probe: ${url} → ${ok ? "OK" : `HTTP ${status}${!magicOk ? "（内容与文件类型不符）" : ""}`} latency=${latencyMs}ms bytes=${received}`,
      );
      return {
        url,
        ok,
        latencyMs,
        bytesPerSecond,
        status,
        directFile: isDirectDownloadUrl(url),
      };
    } catch (error) {
      const latencyMs = Math.round(performance.now() - started);
      await log(
        `probe: ${url} → FAIL (${error instanceof Error ? error.message.slice(0, 80) : String(error)})`,
      );
      return {
        url,
        ok: false,
        latencyMs,
        bytesPerSecond: null,
        status,
        directFile: isDirectDownloadUrl(url),
      };
    } finally {
      clearTimeout(timer);
    }
  };
  return Promise.all(sources.map(probeOne));
}

/**
 * 排序下载源：可用优先于不可用；可直接下载的文件优先于 releases 页面；
 * 同类型按首段下载速度降序、响应延迟升序。排序稳定，并列时保持原顺序。
 */
export function rankDownloadSources(
  sources: string[],
  probes: SourceProbeResult[],
): string[] {
  const byUrl = new Map(probes.map((probe) => [probe.url, probe]));
  return [...sources].sort((a, b) => {
    const pa = byUrl.get(a);
    const pb = byUrl.get(b);
    const okA = pa?.ok ?? false;
    const okB = pb?.ok ?? false;
    if (okA !== okB) return okA ? -1 : 1;
    const directA = isDirectDownloadUrl(a) ? 0 : 1;
    const directB = isDirectDownloadUrl(b) ? 0 : 1;
    if (directA !== directB) return directA - directB;
    const speedA = pa?.bytesPerSecond ?? 0;
    const speedB = pb?.bytesPerSecond ?? 0;
    if (speedA !== speedB) return speedB - speedA;
    const latencyA = pa?.latencyMs ?? Number.MAX_SAFE_INTEGER;
    const latencyB = pb?.latencyMs ?? Number.MAX_SAFE_INTEGER;
    return latencyA - latencyB;
  });
}

/**
 * Languages installed together with Tesseract by default. The UB-Mannheim
 * installer already ships `eng`, so we only add the small `tessdata_fast`
 * models for Simplified/Traditional Chinese here. Any other OCR preset is
 * installed on demand (also tessdata_fast) through
 * POST /runtime/tools/tesseract/language/:lang — downloading all 20 languages
 * up front is slow and unreliable on CN networks.
 */
export const TESSERACT_INSTALL_LANGUAGES = ["eng", "chi_sim", "chi_tra"];

/** Full OCR preset list kept for reference; languages are added on demand. */
export const TESSERACT_CORE_LANGUAGES = [
  "eng",
  "chi_sim",
  "chi_tra",
  "jpn",
  "kor",
  "rus",
  "deu",
  "fra",
  "spa",
  "por",
  "ita",
  "nld",
  "pol",
  "tur",
  "ara",
  "heb",
  "tha",
  "vie",
  "ukr",
  "hin",
];

/** tessdata repositories in preference order (small fast models first; best is a fallback). */
export const TESSDATA_REPOS = [
  { owner: "tesseract-ocr", repo: "tessdata_fast", tier: "fast" },
  { owner: "tesseract-ocr", repo: "tessdata_best", tier: "best" },
];

/**
 * tessdata 镜像（2026-10 实测：jsdelivr/ghfast.top/ghproxy.net/gh-proxy.com/
 * raw 直连可达且支持 Range；gitee.com/mirrors/<repo> 两个路径均 404，已移除）。
 */
export const TESSDATA_MIRRORS: Array<
  (repo: string, language: string) => string
> = [
  (repo, language) =>
    `https://cdn.jsdelivr.net/gh/tesseract-ocr/${repo}@main/${language}.traineddata`,
  (repo, language) =>
    `https://ghfast.top/https://raw.githubusercontent.com/tesseract-ocr/${repo}/main/${language}.traineddata`,
  (repo, language) =>
    `https://ghproxy.net/https://raw.githubusercontent.com/tesseract-ocr/${repo}/main/${language}.traineddata`,
  (repo, language) =>
    `https://gh-proxy.com/https://raw.githubusercontent.com/tesseract-ocr/${repo}/main/${language}.traineddata`,
  (repo, language) =>
    `https://raw.githubusercontent.com/tesseract-ocr/${repo}/main/${language}.traineddata`,
];

/** Verify a downloaded file against an expected sha256; on mismatch delete it so
 * the caller can try another source instead of installing a corrupt payload. */
async function verifyFileSha256(
  target: string,
  expected?: string,
): Promise<void> {
  if (!expected) return;
  const hash = crypto.createHash("sha256");
  hash.update(await fs.readFile(target));
  const actual = hash.digest("hex");
  if (actual.toLowerCase() !== expected.toLowerCase()) {
    await fs.rm(target, { force: true }).catch(() => {});
    throw new Error(`文件校验失败（期望 ${expected}，实际 ${actual}）`);
  }
}

/**
 * 单个文件稳健下载（断点续传 + 60s 建连限时 + 30s 无进展看门狗 + 完整性校验），
 * 成功后原子改名，失败保留 .download 供后续续传。
 */
export async function downloadSingleFileWithResume(
  url: string,
  target: string,
  log: DownloadToolOptions["onLog"],
  expectedSha256?: string,
): Promise<void> {
  const temp = `${target}.download`;
  const partialSize = await fs
    .stat(temp)
    .then((stat) => stat.size)
    .catch(() => 0);
  const connectController = new AbortController();
  const connectTimer = setTimeout(() => connectController.abort(), 60_000);
  let response: Response;
  try {
    response = await fetch(url, {
      signal: connectController.signal,
      headers:
        partialSize > 0
          ? { Range: `bytes=${partialSize}-` }
          : { Range: "bytes=0-0" },
    });
  } finally {
    clearTimeout(connectTimer);
  }
  if (!response.ok && response.status !== 206 && response.status !== 416)
    throw new Error(`HTTP ${response.status}`);
  if (!response.body) throw new Error(`HTTP ${response.status}`);
  const contentRangeTotal = /\/\s*(\d+)\s*$/.exec(
    response.headers.get("content-range") ?? "",
  )?.[1];
  const totalBytes = contentRangeTotal
    ? Number(contentRangeTotal)
    : Number(response.headers.get("content-length")) || null;
  if (response.status === 416) {
    // 文件已完整（Range 超出），直接改名。
    await fs.rename(temp, target);
    await verifyFileSha256(target, expectedSha256);
    return;
  }
  // Range: bytes=0-0 探测只返回 1 字节；全新文件必须重新完整请求，
  // 否则会把“1 字节”误当成下载结果（文件越大越明显）。
  if (partialSize === 0 && response.status === 206) {
    await response.body.cancel().catch(() => {});
    const secondController = new AbortController();
    const secondTimer = setTimeout(() => secondController.abort(), 60_000);
    try {
      response = await fetch(url, { signal: secondController.signal });
    } finally {
      clearTimeout(secondTimer);
    }
    if (!response.ok || !response.body)
      throw new Error(`HTTP ${response.status}`);
  }
  const file = await fs.open(
    temp,
    partialSize > 0 && response.status === 206 ? "a" : "w",
  );
  const reader = response.body.getReader();
  let received = partialSize > 0 && response.status === 206 ? partialSize : 0;
  let stallTimer: NodeJS.Timeout | null = null;
  let stallReject: ((error: Error) => void) | null = null;
  const armStallTimer = () => {
    if (stallTimer) clearTimeout(stallTimer);
    stallTimer = setTimeout(() => {
      stallReject?.(new Error("下载 30 秒无进展"));
    }, 30_000);
  };
  try {
    armStallTimer();
    for (;;) {
      const readPromise = reader.read();
      const { done, value } = await Promise.race([
        readPromise,
        new Promise<never>((_, reject) => {
          stallReject = reject;
        }),
      ]);
      stallReject = null;
      if (done) break;
      if (value.byteLength > 0) {
        await file.write(value);
        received += value.byteLength;
        armStallTimer();
      }
    }
    if (totalBytes && received < totalBytes - 1024) {
      throw new Error(`下载不完整（${received}/${totalBytes} 字节）`);
    }
  } finally {
    if (stallTimer) clearTimeout(stallTimer);
    await reader.cancel().catch(() => {});
    await file.close();
  }
  await log?.(
    `tesseract: language data ${path.basename(target)} fetched (${received} bytes)`,
  );
  await fs.rename(temp, target);
  await verifyFileSha256(target, expectedSha256);
}

import {
  findTessdataDirectory,
  installTesseractLanguageData,
  ensureSevenZip,
  extractNsisWithSevenZip,
  extractArchive,
  deployExecutable,
  installManagedTesseract,
} from "./tool-install-tesseract";
export {
  findTessdataDirectory,
  installTesseractLanguageData,
  ensureSevenZip,
  extractNsisWithSevenZip,
} from "./tool-install-tesseract";

import { downloadSegmentedParallel } from "./tool-download-segmented";
export { downloadSegmentedParallel } from "./tool-download-segmented";

export async function downloadTool(
  id: ToolId,
  url: string,
  sha256OrOptions?: string | DownloadToolOptions,
  onProgress?: (progress: DownloadProgress) => void,
): Promise<string> {
  const options: DownloadToolOptions =
    typeof sha256OrOptions === "object"
      ? sha256OrOptions
      : { sha256: sha256OrOptions, onProgress };
  const log = async (message: string) => {
    await options.onLog?.(message);
  };
  if (options.force) {
    const pkg = getToolPackage(id);
    await fs
      .rm(pkg.installDirectory, { recursive: true, force: true })
      .catch(() => {});
    for (const candidate of candidatePaths(id)) {
      await fs.rm(candidate, { force: true }).catch(() => {});
    }
    await log(`${id}: removed existing install before reinstall`);
  }
  const existing = await resolveToolPath(id);
  if (existing) {
    await log(`${id}: already installed at ${existing}; reusing local tool`);
    return existing;
  }
  const pkg = getToolPackage(id);
  await fs.mkdir(pkg.installDirectory, { recursive: true });
  const target = path.join(
    pkg.installDirectory,
    path.basename(new URL(url).pathname) || id,
  );
  const temp = `${target}.download`;
  await log(`${id}: downloading ${url}`);
  // 断点续传：上一个源失败/卡住后保留部分文件，下一个源用 Range 从已下载字节继续，
  // 避免 95% 卡住后换源又从头下载。
  const partialSize = await fs
    .stat(temp)
    .then((stat) => stat.size)
    .catch(() => 0);
  // 建连阶段限时 + 正文“无进度看门狗”：60 秒连不上，或正文 30 秒无任何进展，
  // 都中止本次下载并抛错，由上层换下一个源。
  const connectController = new AbortController();
  const connectTimer = setTimeout(() => connectController.abort(), 60_000);
  let response: Response;
  try {
    response = await fetch(url, {
      signal: connectController.signal,
      // 已有部分文件：从断点续传；全新文件：用 Range: bytes=0-0 探测源是否支持
      // Range 并拿到总大小——只有探测到 206 才会启用多线程分段下载，
      // 否则会一直走单连接、撞上大文件截断墙（例如 95% 后失败）。
      headers:
        partialSize > 0
          ? { Range: `bytes=${partialSize}-` }
          : { Range: "bytes=0-0" },
    });
  } finally {
    clearTimeout(connectTimer);
  }
  if (!response.ok && response.status !== 206 && response.status !== 416)
    throw new Error(`下载失败：HTTP ${response.status}`);
  if (!response.body) throw new Error(`下载失败：HTTP ${response.status}`);
  await log(`${id}: HTTP ${response.status}; saving to ${target}`);
  let hash = crypto.createHash("sha256");
  let resumeOffset = 0;
  let append = false;
  // 源不支持 Range（返回 200）且已有部分文件时，完整下载写到独立临时文件，
  // 成功后才替换；失败则保留原部分文件供后续续传，绝不提前删除。
  let fullTemp: string | null = null;
  if (partialSize > 0 && response.status === 206) {
    resumeOffset = partialSize;
    append = true;
    await log(`${id}: 断点续传，从字节 ${partialSize} 继续`);
  } else if (response.status === 416) {
    resumeOffset = partialSize;
    append = false;
    await log(`${id}: 文件已完整（HTTP 416），直接校验`);
  } else if (partialSize > 0) {
    fullTemp = `${temp}.new`;
    await fs.rm(fullTemp, { force: true }).catch(() => {});
    await log(
      `${id}: 源不支持断点续传，完整下载到新文件（保留已有 ${partialSize} 字节部分，成功后才替换）`,
    );
  }
  const contentRangeTotal = /\/\s*(\d+)\s*$/.exec(
    response.headers.get("content-range") ?? "",
  )?.[1];
  const totalBytes = contentRangeTotal
    ? Number(contentRangeTotal)
    : Number(response.headers.get("content-length")) || null;
  // 全新小文件（源支持 Range 但 <8MB）：探测只拿到 1 字节，重新请求完整内容再单流下载。
  if (
    partialSize === 0 &&
    response.status === 206 &&
    totalBytes &&
    totalBytes < 8 * 1024 * 1024
  ) {
    await response.body.cancel().catch(() => {});
    const secondController = new AbortController();
    const secondTimer = setTimeout(() => secondController.abort(), 60_000);
    try {
      response = await fetch(url, { signal: secondController.signal });
    } finally {
      clearTimeout(secondTimer);
    }
    if (!response.ok || !response.body)
      throw new Error(`下载失败：HTTP ${response.status}`);
    await log(`${id}: HTTP ${response.status}; 完整下载（小文件）`);
  }
  let receivedBytes = resumeOffset;
  // ── 多线程分段下载：全新文件、源支持 Range、文件足够大时启用（原理同迅雷）──
  let segmentedDownload = false;
  if (
    partialSize === 0 &&
    response.status === 206 &&
    totalBytes &&
    totalBytes >= 8 * 1024 * 1024
  ) {
    segmentedDownload = true;
    await response.body.cancel().catch(() => {});
    await log(`${id}: 使用多线程分段下载（总 ${totalBytes} 字节，分片并行）`);
    await downloadSegmentedParallel({
      id,
      url,
      totalBytes,
      temp,
      onProgress: (received, total) => {
        options.onProgress?.({
          receivedBytes: received,
          totalBytes: total,
          percent: total ? Math.round((received * 100) / total) : null,
        });
      },
      log,
    });
    // 分段下载无法边下边哈希：合并完成后对完整文件重算哈希。
    const mergedHash = crypto.createHash("sha256");
    const mergedHandle = await fs.open(temp, "r");
    try {
      const buf = Buffer.alloc(1024 * 1024);
      for (;;) {
        const { bytesRead } = await mergedHandle.read(buf, 0, buf.length);
        if (bytesRead <= 0) break;
        mergedHash.update(buf.subarray(0, bytesRead));
      }
    } finally {
      await mergedHandle.close();
    }
    hash = mergedHash;
    receivedBytes = totalBytes;
  }
  if (!segmentedDownload) {
    const reader = response.body.getReader();
    const downloadStartedAt = Date.now();
    let speedCheckAt = downloadStartedAt;
    let speedCheckBytes = resumeOffset;
    let stallTimer: NodeJS.Timeout | null = null;
    let stallReject: ((error: Error) => void) | null = null;
    const armStallTimer = () => {
      if (stallTimer) clearTimeout(stallTimer);
      stallTimer = setTimeout(() => {
        stallReject?.(new Error("下载 30 秒无进展，中止并换源"));
      }, 30_000);
    };
    let file: Awaited<ReturnType<typeof fs.open>> | null = null;
    try {
      if (resumeOffset > 0 && response.status === 206) {
        // 续传：先把已下载字节计入哈希（校验用），再以追加模式打开。
        const existingHandle = await fs.open(temp, "r");
        try {
          const buf = Buffer.alloc(1024 * 1024);
          let pos = 0;
          while (pos < resumeOffset) {
            const { bytesRead } = await existingHandle.read(
              buf,
              0,
              Math.min(buf.length, resumeOffset - pos),
              pos,
            );
            if (bytesRead <= 0) break;
            hash.update(buf.subarray(0, bytesRead));
            pos += bytesRead;
          }
        } finally {
          await existingHandle.close();
        }
        file = await fs.open(temp, "a");
      } else if (response.status === 416) {
        // 文件已完整：把整个文件计入哈希，直接进入魔数/校验阶段（不再写入）。
        const existingHandle = await fs.open(temp, "r");
        try {
          const buf = Buffer.alloc(1024 * 1024);
          let pos = 0;
          for (;;) {
            const { bytesRead } = await existingHandle.read(
              buf,
              0,
              buf.length,
              pos,
            );
            if (bytesRead <= 0) break;
            hash.update(buf.subarray(0, bytesRead));
            pos += bytesRead;
          }
          receivedBytes = pos;
        } finally {
          await existingHandle.close();
        }
      } else if (fullTemp) {
        file = await fs.open(fullTemp, "w");
      } else {
        file = await fs.open(temp, "w");
      }
      if (response.status !== 416) {
        armStallTimer();
        while (true) {
          const readPromise = reader.read();
          const { done, value } = await Promise.race([
            readPromise,
            new Promise<never>((_, reject) => {
              stallReject = reject;
            }),
          ]);
          stallReject = null;
          if (done) break;
          // 只有收到实际数据才写入并重置看门狗；空块（byteLength=0）不会
          // 让“30 秒无进展”计时器重新计时，避免卡死流被空块喂活。
          if (value.byteLength > 0) {
            hash.update(value);
            await file!.write(value);
            receivedBytes += value.byteLength;
            options.onProgress?.({
              receivedBytes,
              totalBytes,
              percent: totalBytes
                ? Math.round((receivedBytes * 100) / totalBytes)
                : null,
            });
            // 慢速源检测：10 秒内平均速度过低（<8 KB/s）说明镜像基本不可用，
            // 立即中止由上层换下一个源，避免在近乎卡死的慢镜像上无限下载大文件。
            // 阈值刻意放低，并配合断点续传：带宽受限（10–60 KB/s）的源不会被误杀，
            // 慢但持续有进度就让它继续下载。
            const now = Date.now();
            if (
              now - speedCheckAt >= 10_000 &&
              receivedBytes - speedCheckBytes >= 256 * 1024
            ) {
              const elapsedSec = (now - speedCheckAt) / 1000;
              const speedBytesPerSec =
                (receivedBytes - speedCheckBytes) / elapsedSec;
              speedCheckAt = now;
              speedCheckBytes = receivedBytes;
              if (speedBytesPerSec < 8 * 1024) {
                throw new Error(
                  `下载速度过慢（约 ${Math.round(speedBytesPerSec / 1024)} KB/s），中止并换源`,
                );
              }
            }
            armStallTimer();
          }
        }
        // 某些镜像/连接会在中途提前断开：流结束了但字节数明显少于
        // Content-Length，绝不能当作“下载完成”（截断的 exe 头部仍是 MZ，
        // 魔数校验拦不住）。保留部分文件由上层换源续传。
        if (totalBytes && receivedBytes < totalBytes - 1024) {
          throw new Error(
            `下载不完整（已收 ${receivedBytes}/${totalBytes} 字节），中止并换源续传`,
          );
        }
      }
    } catch (error) {
      // 保留部分文件，换源后可断点续传；不再删除 temp。
      throw error;
    } finally {
      if (stallTimer) clearTimeout(stallTimer);
      await reader.cancel().catch(() => {});
      await file?.close();
    }
  }
  // 内容魔数校验：部分镜像对失效文件也返回 HTTP 200（错误页），
  // 只有真实文件头匹配才继续（.exe=MZ、.zip=PK 等）。
  const headBuffer = Buffer.alloc(16);
  const magicSource = fullTemp ?? temp;
  const headHandle = await fs.open(magicSource, "r");
  try {
    await headHandle.read(headBuffer, 0, headBuffer.length, 0);
  } finally {
    await headHandle.close();
  }
  if (!fileMagicMatches(path.basename(target), headBuffer)) {
    if (fullTemp) await fs.rm(fullTemp, { force: true }).catch(() => {});
    else await fs.rm(temp, { force: true }).catch(() => {});
    throw new Error(`下载内容与文件类型不符（镜像可能返回了错误页）：${url}`);
  }
  const actual = hash.digest("hex");
  await log(`${id}: downloaded ${receivedBytes} bytes; sha256=${actual}`);
  if (options.sha256 && actual.toLowerCase() !== options.sha256.toLowerCase()) {
    if (fullTemp) await fs.unlink(fullTemp).catch(() => {});
    else await fs.unlink(temp).catch(() => {});
    throw new Error(`文件校验失败：期望 ${options.sha256}，实际 ${actual}`);
  }
  if (fullTemp) {
    // 完整新文件成功：删除旧部分文件并替换为完整文件。
    await fs.rm(temp, { force: true }).catch(() => {});
    await fs.rename(fullTemp, target);
  } else {
    await fs.rename(temp, target);
  }
  await log(`${id}: saved ${target}`);
  if (await extractArchive(target, pkg.installDirectory)) {
    await log(`${id}: extracted archive into ${pkg.installDirectory}`);
    await fs.unlink(target).catch(() => {});
    const deployed =
      (await deployExecutable(id, pkg.installDirectory)) ??
      pkg.installDirectory;
    await log(`${id}: deployed ${deployed}`);
    return deployed;
  }
  if (id === "tesseract") {
    return installManagedTesseract(target, options, pkg);
  }
  if (process.platform !== "win32") await fs.chmod(target, 0o755);
  await log(`${id}: installed ${target}`);
  return target;
}
