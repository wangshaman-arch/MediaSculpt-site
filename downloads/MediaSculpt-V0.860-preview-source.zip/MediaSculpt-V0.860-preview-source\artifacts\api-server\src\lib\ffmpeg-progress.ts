/** Extract the media timestamp emitted by FFmpeg's `-progress pipe:1` protocol. */
export function parseFfmpegProgressSeconds(
  progressText: string,
): number | null {
  let seconds: number | null = null;
  for (const line of progressText.split(/\r?\n/)) {
    const separator = line.indexOf("=");
    if (separator < 0) continue;
    const key = line.slice(0, separator).trim();
    const value = line.slice(separator + 1).trim();
    if (key === "out_time") {
      const match = /^(\d+):(\d{2}):(\d{2})(?:\.(\d+))?$/.exec(value);
      if (match) {
        const candidate =
          Number(match[1]) * 3600 +
          Number(match[2]) * 60 +
          Number(match[3]) +
          Number(`0.${match[4] ?? "0"}`);
        if (Number.isFinite(candidate) && candidate >= 0) seconds = candidate;
      }
    } else if (
      (key === "out_time_us" || key === "out_time_ms") &&
      /^\d+$/.test(value)
    ) {
      // FFmpeg's out_time_ms is historically named but also reports microseconds.
      const candidate = Number(value) / 1_000_000;
      if (Number.isFinite(candidate) && candidate >= 0) seconds = candidate;
    }
  }
  return seconds;
}

/** Human-readable media timestamp; avoid exposing long durations as raw seconds. */
export function formatFfmpegTimestamp(seconds: number): string {
  const totalSeconds =
    Number.isFinite(seconds) && seconds > 0 ? Math.floor(seconds) : 0;
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const remainder = totalSeconds % 60;
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(remainder).padStart(2, "0")}`;
}

/** True only when FFmpeg explicitly rejects the progress option we injected. */
export function doesNotSupportFfmpegProgressOption(
  exitCode: number | null,
  stderr: string,
): boolean {
  if (exitCode === 0 || !stderr) return false;
  return (
    /unrecognized option\s+['"]?-?progress['"]?/i.test(stderr) ||
    /unknown option\s+['"]?-?progress['"]?/i.test(stderr) ||
    /option\s+['"]?-?progress['"]?\s+(?:not found|not recognized)/i.test(
      stderr,
    ) ||
    (/error splitting the argument list[\s\S]*option not found/i.test(stderr) &&
      /progress/i.test(stderr))
  );
}
