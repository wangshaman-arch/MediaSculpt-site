import { describe, expect, it } from "vitest";
import {
  isIsoFileName,
  lastPathSegment,
  normalizeBatchStreams,
  sortBrowserEntries,
} from "./source-browser-model";

describe("source browser model", () => {
  it("sorts names numerically and keeps unknown dates last", () => {
    const entries = [
      { name: "part10.mkv", modifiedAt: "2026-01-02T00:00:00Z" },
      { name: "part2.mkv", modifiedAt: null },
      { name: "part1.mkv", modifiedAt: "2026-01-01T00:00:00Z" },
    ];
    expect(
      sortBrowserEntries(entries, "name", "asc").map((entry) => entry.name),
    ).toEqual(["part1.mkv", "part2.mkv", "part10.mkv"]);
    expect(
      sortBrowserEntries(entries, "modified", "asc").map((entry) => entry.name),
    ).toEqual(["part1.mkv", "part10.mkv", "part2.mkv"]);
  });

  it("normalizes batch streams and ignores unsupported entries", () => {
    expect(
      normalizeBatchStreams([
        { codecType: "video", codecName: "h264" },
        { codecType: "data", codecName: "bin" },
        { codecType: "audio", language: "en" },
      ]),
    ).toEqual([
      {
        index: 0,
        codecType: "video",
        codecName: "h264",
        language: null,
        channels: null,
        width: null,
        height: null,
        frameRate: null,
      },
      {
        index: 2,
        codecType: "audio",
        codecName: null,
        language: "en",
        channels: null,
        width: null,
        height: null,
        frameRate: null,
      },
    ]);
    expect(lastPathSegment("C:\\Media\\Movie\\")).toBe("Movie");
    expect(isIsoFileName("Movie.ISO")).toBe(true);
    expect(isIsoFileName("Movie.mkv")).toBe(false);
  });
});
