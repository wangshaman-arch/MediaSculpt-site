// Extracted from routes/jobs.ts: LLM prompt builders (translation / whisper correction / poster).
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import {
  lookupAll,
  metadataIdentityMatches,
  normalizeTitleEn,
} from "../lib/metadata";
import {
  servePreviewSegment,
  cleanupPreviewSegments,
} from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import {
  buildFfconcatFileContent as buildManifest,
  buildFfconcatChapterContent,
  buildFfconcatTimedContent,
  type FfconcatTimedSegment,
} from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import {
  appendJobRuntimeLog,
  appendJobToolOutput,
} from "../lib/job-runtime-log";
import {
  appendRuntimeToolLog,
  appendRuntimeToolOutput,
} from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import {
  buildCompressionOutputName,
  buildRemuxOutputName,
  cleanSegment,
  encoderBitDepth,
  selectBestAudioTrack,
} from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import {
  renderBilingualAss,
  DEFAULT_BILINGUAL_STYLE,
  type BilingualAssStyle,
  type SubtitleBlock,
} from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import {
  ensureLocalPoster,
  MEDIA_INFO_DIR,
  POSTER_META_FILE,
  posterIdentityMatches,
} from "../lib/poster";
import {
  ensureFasterWhisperModel,
  ensureWhisperCliScript,
} from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import {
  hasValidSubtitleCues,
  isGraphicSubtitleCodec,
  shouldFallbackToWhisper,
} from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import {
  buildDvdRemuxArgs,
  runDvdRemux,
  verifyDvdTitle,
} from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import {
  buildDvdStructurePayload,
  resolveRemuxPlanWithLlm,
  validateRemuxPlan,
} from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import {
  assertPreviewTaskAllowed,
  recordPreviewAiCall,
  settlePreviewTask,
} from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import {
  parseCustomTuning,
  resolveLogicPlaceholders,
} from "../lib/custom-tuning";
import {
  decryptSecret,
  encryptSecret,
  isEncryptedSecret,
} from "../lib/secrets";
import {
  ffmpegPath,
  resolveOutputDir,
  resolveRuntimePath,
  type RuntimePathConfig,
} from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import {
  assertCompleteMediaTitle,
  createDvdMediaTitle,
} from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import {
  buildPreviewTranscodeArgs,
  isPreviewVideoCandidate,
  previewService,
} from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";

/** Build the AI translation system prompt with full movie context */
type DerivedMediaContext = {
  seriesTitle: string;
  episodeTitle: string | null;
  season: number | null;
  episode: number | null;
  year: number | null;
};

/** Infer series/episode/year context from a media filename (no metadata needed). */
function deriveMediaContextFromFilename(filePath: string): DerivedMediaContext {
  const base = path.basename(filePath, path.extname(filePath));
  const yearMatch = base.match(/(19|20)\d{2}/);
  const year = yearMatch ? Number(yearMatch[0]) : null;
  const episodeMatch = base.match(
    /^(.*?)\s*[-–—]\s*S(\d{1,2})E(\d{1,2})\s*[-–—]\s*(.*)$/i,
  );
  if (episodeMatch) {
    return {
      seriesTitle: episodeMatch[1].trim(),
      season: Number(episodeMatch[2]),
      episode: Number(episodeMatch[3]),
      episodeTitle: episodeMatch[4].trim() || null,
      year,
    };
  }
  const clean = base
    .replace(/[._]+/g, " ")
    .replace(
      /\s*[-–—]\s*(?:HD|WEB|BluRay|Blu-ray|2160p|1080p|720p|HDR|DV|x26[45]|HEVC|AVC|AAC|DTS|AC3|TrueHD).*$/i,
      "",
    )
    .replace(/\s*\(\s*(19|20)\d{2}\s*\)\s*$/, "")
    .replace(/\s*[-–—]\s*(19|20)\d{2}\s*$/, "")
    .trim();
  return {
    seriesTitle: clean,
    episodeTitle: null,
    season: null,
    episode: null,
    year,
  };
}

/** 语音识别（Whisper）转写结果的 AI 纠错提示词：修正识别错误并输出简体中文。 */
export function buildWhisperCorrectionPrompt(
  job: typeof jobsTable.$inferSelect,
  isChineseSource: boolean,
  sourceLang: string | null,
): string {
  const sourceName = job.movieTitle || path.basename(job.filePath || "视频");
  const langNote = sourceLang ? `（检测语言 ${sourceLang}）` : "";
  const head = `以下字幕是通过语音识别（Whisper）从“${sourceName}”${langNote}的音频自动转写的，可能存在识别错误（同音字、人名、专名、错字、漏字、断句）。`;
  const tail = "逐条输出，保持行号与时间轴不变，不要输出任何多余说明。";
  return isChineseSource
    ? `${head}\n要求：\n1. 结合上下文纠正明显的识别错误（人名、专名、错字、漏字、断句）。\n2. 输出必须为简体中文：把所有繁体字转换为简体字，例如「我們」→「我们」、「認識」→「认识」、「因為」→「因为」。\n3. 禁止输出任何繁体字，输出繁体即视为错误。\n${tail}`
    : `${head}\n请先结合上下文纠正明显的识别错误（人名、专名、错字、漏字、断句），再翻译成简体中文。\n${tail}`;
}

/** 海报最后兜底：让 LLM 返回一个公开可访问的真实海报 URL（绝不生成/伪造图片）。 */
export async function findPosterUrlByLlm(
  job: typeof jobsTable.$inferSelect,
  config: typeof configTable.$inferSelect,
): Promise<string | null> {
  const apiKey = resolveApiKey(config);
  if (!apiKey || config.aiProvider === "libretranslate") return null;
  const title = job.movieTitle || job.movieTitleEn;
  if (!title) return null;
  try {
    const { baseUrl, model } = resolveAiEndpoint(config);
    const system =
      "你是影视资料助手。根据影片信息，返回一张公开可访问的真实海报/封面图片直链（jpg/png/webp），优先 TMDb 图库（https://image.tmdb.org/t/p/original/...）、IMDb 或官方网站。只输出一行 URL，不要任何解释；找不到就输出 NONE。";
    const user = `片名：${job.movieTitle || ""}；英文名：${job.movieTitleEn || ""}；年份：${job.movieYear || ""}${job.movieGenres ? `；类型：${job.movieGenres}` : ""}`;
    const response = await fetch(
      `${baseUrl.replace(/\/$/, "")}/chat/completions`,
      {
        method: "POST",
        signal: AbortSignal.timeout(25_000),
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model,
          temperature: 0.1,
          max_tokens: 200,
          messages: [
            { role: "system", content: system },
            { role: "user", content: user },
          ],
        }),
      },
    );
    void recordPreviewAiCall("poster").catch(() => {});
    if (!response.ok) return null;
    const payload = (await response.json().catch(() => ({}))) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const content = payload.choices?.[0]?.message?.content?.trim() ?? "";
    const token = content
      .split(/\s+/)
      .find((part) => /^https?:\/\//i.test(part));
    return token && !/^NONE$/i.test(token) ? token : null;
  } catch {
    return null;
  }
}

export async function buildTranslationPrompt(
  job: typeof jobsTable.$inferSelect,
  config: typeof configTable.$inferSelect,
  targetLang: string,
  sourceLang?: string | null,
): Promise<string> {
  const langName: Record<string, string> = {
    "zh-CN": "简体中文",
    "zh-TW": "繁體中文",
    ja: "日语",
    ko: "韩语",
    fr: "法语",
    de: "德语",
    es: "西班牙语",
  };
  const langDisplay = langName[targetLang] ?? targetLang;
  const sourceLangName: Record<string, string> = {
    en: "英文",
    zh: "中文",
    fr: "法文",
    de: "德文",
    es: "西班牙文",
    ja: "日文",
    ko: "韩文",
    it: "意大利文",
    pt: "葡萄牙文",
    ru: "俄文",
    nl: "荷兰文",
    pl: "波兰文",
    tr: "土耳其文",
    ar: "阿拉伯文",
    th: "泰文",
  };
  const sourceDisplay = sourceLang
    ? (sourceLangName[sourceLang] ?? sourceLang)
    : "自动识别";

  const derivedMedia = deriveMediaContextFromFilename(job.filePath || "");
  let context = "";

  // 0. Filename-derived media background (works even without saved metadata)
  {
    const mediaLines: string[] = [];
    if (derivedMedia.seriesTitle)
      mediaLines.push(`片名（文件名推断）：${derivedMedia.seriesTitle}`);
    if (derivedMedia.year) mediaLines.push(`年份：${derivedMedia.year}`);
    if (derivedMedia.season !== null)
      mediaLines.push(`季数：第 ${derivedMedia.season} 季`);
    if (derivedMedia.episode !== null)
      mediaLines.push(`集数：第 ${derivedMedia.episode} 集`);
    if (derivedMedia.episodeTitle)
      mediaLines.push(`集标题：${derivedMedia.episodeTitle}`);
    if (mediaLines.length > 0)
      context += `【媒体背景（从文件名推断）】\n${mediaLines.join("\n")}\n\n`;
  }

  // 1. Basic movie info from saved metadata
  if (job.movieTitle || job.movieTitleEn) {
    context += `【影片信息】\n`;
    if (job.movieTitle) context += `中文片名：${job.movieTitle}\n`;
    if (job.movieTitleEn) context += `英文片名：${job.movieTitleEn}\n`;
    if (job.movieYear) context += `年份：${job.movieYear}\n`;
    if (job.movieDirector) context += `导演：${job.movieDirector}\n`;
    if (job.movieGenres) context += `类型：${job.movieGenres}\n`;
    if (job.movieRating)
      context += `TMDb 评分：${job.movieRating.toFixed(1)}/10\n`;
    if (job.movieOverview) context += `剧情简介：${job.movieOverview}\n`;
    context += "\n";
  }

  // 2. Fetch full cast + character list from TMDb for proper noun consistency.
  // When no movie has been confirmed yet, search TMDb by the filename-derived
  // title + year so proper nouns (actor/character Chinese names) are available
  // to the LLM instead of guessing from OCR alone.
  let tmdbId = job.tmdbId ?? null;
  if (!tmdbId && config.tmdbApiKey) {
    const derivedTitle = derivedMedia.seriesTitle || derivedMedia.episodeTitle;
    if (derivedTitle) {
      const searchQuery = [derivedTitle, derivedMedia.year]
        .filter(Boolean)
        .join(" ");
      try {
        const searchResp = await fetch(
          `https://api.themoviedb.org/3/search/movie?api_key=${config.tmdbApiKey}&query=${encodeURIComponent(searchQuery)}&language=en-US&include_adult=false`,
        );
        if (searchResp.ok) {
          const searchData = (await searchResp.json()) as {
            results?: Array<{ id?: number; release_date?: string }>;
          };
          const results = searchData.results ?? [];
          tmdbId =
            results.find(
              (item) =>
                derivedMedia.year &&
                String(item.release_date ?? "").startsWith(
                  String(derivedMedia.year),
                ),
            )?.id ??
            results[0]?.id ??
            null;
        }
      } catch {
        // TMDb search unavailable - fall through to filename-only context
      }
    }
  }
  if (tmdbId && config.tmdbApiKey) {
    try {
      const mediaType = "movie"; // default; TV would require knowing media_type
      const castUrl = `https://api.themoviedb.org/3/${mediaType}/${tmdbId}/credits?api_key=${config.tmdbApiKey}&language=en-US`;
      const castResp = await fetch(castUrl);
      if (castResp.ok) {
        const castData = (await castResp.json()) as {
          cast?: Array<{ name: string; character: string }>;
          crew?: Array<{ job: string; name: string }>;
        };
        const cast = (castData.cast ?? []).slice(0, 20);
        if (cast.length > 0) {
          context += `【主要角色与演员（用于专有名词保持一致）】\n`;
          for (const c of cast) {
            if (c.character && c.name) {
              context += `  ${c.character} — 演员：${c.name}\n`;
            }
          }
          context += "\n";
        }
        // Also get Chinese title for cross-reference
        const zhUrl = `https://api.themoviedb.org/3/${mediaType}/${tmdbId}?api_key=${config.tmdbApiKey}&language=zh-CN`;
        const zhResp = await fetch(zhUrl);
        if (zhResp.ok) {
          const zhData = (await zhResp.json()) as {
            title?: string;
            overview?: string;
            tagline?: string;
          };
          if (zhData.tagline) context += `【中文宣传语】${zhData.tagline}\n\n`;
          if (zhData.overview && zhData.overview !== job.movieOverview) {
            context += `【中文剧情简介（参考）】\n${zhData.overview}\n\n`;
          }
        }
      }
    } catch {
      // TMDb fetch failed — use whatever metadata we have
    }
  }

  // 3. Fetch Wikipedia summary for additional context (falls back to the
  // filename-derived series title when no metadata has been confirmed)
  const wikiTitle =
    job.movieTitleEn ||
    job.movieTitle ||
    derivedMedia.seriesTitle ||
    derivedMedia.episodeTitle;
  if (wikiTitle) {
    try {
      const wikiQuery = encodeURIComponent(wikiTitle);
      const wikiUrl = `https://en.wikipedia.org/api/rest_v1/page/summary/${wikiQuery}`;
      const wikiResp = await fetch(wikiUrl, {
        headers: { "User-Agent": "MediaSculpt/1.0" },
      });
      if (wikiResp.ok) {
        const wikiData = (await wikiResp.json()) as { extract?: string };
        if (wikiData.extract && wikiData.extract.length > 50) {
          const excerpt = wikiData.extract.slice(0, 600);
          context += `【Wikipedia 摘要（英文背景参考）】\n${excerpt}\n\n`;
        }
      }
    } catch {
      // Wikipedia unavailable
    }
  }

  // 3.5 Chinese-title calibration: Douban is authoritative for the Chinese
  // title and name translations (Wikipedia-zh is often Taiwan-maintained and
  // has differing translations). Best-effort, never blocking.
  {
    const searchTitle =
      job.movieTitleEn || derivedMedia.seriesTitle || derivedMedia.episodeTitle;
    const searchYear = job.movieYear ?? derivedMedia.year;
    if (searchTitle) {
      try {
        const query = `${searchTitle}${searchYear ? ` ${searchYear}` : ""}`;
        const doubanResp = await fetch(
          `https://www.douban.com/search?q=${encodeURIComponent(query)}`,
          {
            headers: {
              "User-Agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
              "Accept-Language": "zh-CN,zh;q=0.9",
            },
            signal: AbortSignal.timeout(8000),
          },
        );
        if (doubanResp.ok) {
          const html = await doubanResp.text();
          const movieLink =
            /href="https:\/\/movie\.douban\.com\/subject\/\d+[^"]*"[^>]*>([^<]{2,80})<\/a>/i.exec(
              html,
            );
          const titleText = /class="title-text"[^>]*>([^<]{2,80})</i.exec(html);
          const doubanTitle = (movieLink?.[1] ?? titleText?.[1] ?? "")
            .trim()
            .replace(/\s+/g, " ");
          if (doubanTitle && doubanTitle.length >= 2) {
            context += `【豆瓣中文片名（用于校准中文片名与译名，优先采用）】\n${doubanTitle}\n\n`;
          }
        }
      } catch {
        // Douban unavailable — Wikipedia/TMDb still provide context
      }
    }
  }

  const genreHints: Record<string, string> = {
    "Science Fiction": "译文应保留科幻术语的专业感，技术词汇不过度意译。",
    Action: "台词简洁有力，动作指令直接翻译，不拖沓。",
    Drama: "注重情感表达，台词应自然流畅，贴近生活。",
    Comedy: "保留幽默感，双关语在无法直译时可意译，加注 (译注) 说明。",
    Horror: "保持紧张氛围，不软化恐怖描写。",
    Romance: "台词温柔细腻，情感丰富。",
    Documentary: "准确传达信息，术语翻译专业。",
    Animation: "台词活泼，适合家庭观众。",
    Crime: "对话写实，街头俚语酌情保留原味。",
    Thriller: "节奏紧张，措辞精准。",
  };

  let styleGuide = "";
  if (job.movieGenres) {
    for (const [genre, hint] of Object.entries(genreHints)) {
      if (job.movieGenres.includes(genre)) {
        styleGuide += `- ${hint}\n`;
        break;
      }
    }
  }

  const mediaContext = `【片名】${path.basename(job.filePath || "")}【时长】${job.durationSeconds ? Math.round(Number(job.durationSeconds)) + " 秒" : "未知"}\n`;
  const basePrompt = `你是一位专业的影视字幕翻译师，精通将字幕翻译为${langDisplay}。你的翻译风格自然流畅，符合目标语言观众的表达习惯，绝不逐字死译。

${mediaContext}${context}【翻译规则】
- 源语言：${sourceDisplay}；直接据此翻译，不要经过中间语言转译
- 目标语言：${langDisplay}
- 保留 SRT 格式：换行、<i>、<b> 等 HTML 标签原样保留
- 专有名词（人名、地名、机构名）按以上角色表翻译；若表中无收录，使用通用中文译名或音译
- 中文片名与中文译名以「豆瓣中文片名 / TMDb 官方中译」为准（若已提供）；维基百科中文仅作参考，可能存在台湾译名差异，不要照搬
- 台词中的俚语、口语应用自然的目标语言表达还原，不要生硬直译
- 数字、时间、电话号码保持原样
- 不添加译者注释，除非是无法翻译的文化特定双关语（加括号说明）
${styleGuide}- 每次输出必须覆盖全部输入条目，不跳过、不合并
- 输出格式严格遵守：每条字幕以 [编号] 开头，与输入编号一一对应`;
  const tuning = parseCustomTuning(config.customTuning);
  const customTranslate = resolveLogicPlaceholders(
    tuning.prompts.translate,
    tuning.logic,
  ).trim();
  return customTranslate
    ? `【用户补充指令】\n${customTranslate}\n\n${basePrompt}`
    : basePrompt;
}
