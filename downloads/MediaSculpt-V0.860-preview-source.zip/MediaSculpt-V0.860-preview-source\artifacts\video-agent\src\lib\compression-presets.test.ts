import { describe, expect, it } from "vitest";
import { DEFAULT_COMPRESSION_PRESETS } from "./compression-presets";

describe("内置收藏压缩预设", () => {
  it("以 H.264 10-bit 作为 DVD 默认，并使用 RF19、grain、High10、Level 3.1", () => {
    const preset = DEFAULT_COMPRESSION_PRESETS.find(
      (item) => item.id === "dvd-convert",
    );

    expect(preset?.values).toMatchObject({
      encoder: "x264_10bit",
      crf: 19,
      encoderPreset: "slow",
      encoderTune: "grain",
      encoderProfile: "high10",
      encoderLevel: "3.1",
      frameRate: "same",
      outputResolution: "source",
    });
  });

  it("以 H.264 10-bit 作为蓝光默认，并使用 RF22-23 范围内的收藏质量", () => {
    const preset = DEFAULT_COMPRESSION_PRESETS.find(
      (item) => item.id === "bluray-collection",
    );

    expect(preset?.values.encoder).toBe("x264_10bit");
    expect(preset?.values.crf).toBeGreaterThanOrEqual(22);
    expect(preset?.values.crf).toBeLessThanOrEqual(23);
    expect(preset?.values.encoderPreset).toBe("slow");
    expect(preset?.values.frameRate).toBe("same");
    expect(preset?.values.outputResolution).toBe("source");
  });
});
