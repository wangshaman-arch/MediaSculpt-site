type RemuxProbeLike = {
  duration?: number | null;
  streams?: Array<{ codecType?: string | null }>;
};

/** A successful process exit is not enough; the container must contain video. */
export function isPlayableRemuxProbe(
  probe: RemuxProbeLike | null | undefined,
  minimumDurationSeconds = 0.5,
): boolean {
  return Boolean(
    probe &&
    typeof probe.duration === "number" &&
    Number.isFinite(probe.duration) &&
    probe.duration >= minimumDurationSeconds &&
    probe.streams?.some((stream) => stream.codecType === "video"),
  );
}
