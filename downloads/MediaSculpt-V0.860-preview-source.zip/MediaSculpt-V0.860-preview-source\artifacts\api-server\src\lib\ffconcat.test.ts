import { describe, expect, it } from "vitest";
import {
  buildFfconcatChapterContent,
  buildFfconcatFileContent,
} from "./ffconcat";

describe("ffconcat manifest", () => {
  it("normalizes Windows paths and quotes filenames", () => {
    expect(
      buildFfconcatFileContent(["C:\\Videos\\a b.m2ts"], "win32"),
    ).toContain("file 'C:/Videos/a b.m2ts'");
  });

  it("writes selected chapter time ranges", () => {
    expect(
      buildFfconcatChapterContent(
        "C:\\Videos\\movie.mkv",
        [{ startSeconds: 12, endSeconds: 34 }],
        "win32",
      ),
    ).toContain("inpoint 12\noutpoint 34");
  });
});
