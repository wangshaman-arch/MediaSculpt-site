// Extracted from routes/jobs.ts: DVD audio codec selection and probing.
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import {
  lookupAll,
  metadataIdentityMatches,
  normalizeTitleEn,
} from "../lib/metadata";
import {
  servePreviewSegment,
  cleanupPreviewSegments,
} from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import {
  buildFfconcatFileContent as buildManifest,
  buildFfconcatChapterContent,
  buildFfconcatTimedContent,
  type FfconcatTimedSegment,
} from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import {
  appendJobRuntimeLog,
  appendJobToolOutput,
} from "../lib/job-runtime-log";
import {
  appendRuntimeToolLog,
  appendRuntimeToolOutput,
} from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import {
  buildCompressionOutputName,
  buildRemuxOutputName,
  cleanSegment,
  encoderBitDepth,
  selectBestAudioTrack,
} from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import {
  renderBilingualAss,
  DEFAULT_BILINGUAL_STYLE,
  type BilingualAssStyle,
  type SubtitleBlock,
} from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import {
  ensureLocalPoster,
  MEDIA_INFO_DIR,
  POSTER_META_FILE,
  posterIdentityMatches,
} from "../lib/poster";
import {
  ensureFasterWhisperModel,
  ensureWhisperCliScript,
} from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import {
  hasValidSubtitleCues,
  isGraphicSubtitleCodec,
  shouldFallbackToWhisper,
} from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import {
  buildDvdRemuxArgs,
  runDvdRemux,
  verifyDvdTitle,
} from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import {
  buildDvdStructurePayload,
  resolveRemuxPlanWithLlm,
  validateRemuxPlan,
} from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import {
  assertPreviewTaskAllowed,
  recordPreviewAiCall,
  settlePreviewTask,
} from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import {
  parseCustomTuning,
  resolveLogicPlaceholders,
} from "../lib/custom-tuning";
import {
  decryptSecret,
  encryptSecret,
  isEncryptedSecret,
} from "../lib/secrets";
import {
  ffmpegPath,
  resolveOutputDir,
  resolveRuntimePath,
  type RuntimePathConfig,
} from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import {
  assertCompleteMediaTitle,
  createDvdMediaTitle,
} from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import {
  buildPreviewTranscodeArgs,
  isPreviewVideoCandidate,
  previewService,
} from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";
import { discAnalysisRegistry } from "../lib/disc-analysis-registry";
import { ensureDvdCssSupport, dvdInputArg } from "./jobs-dvd";

export function snapshotStreamIndexes(ids: string[]): number[] {
  return ids
    .map((id) => Number(id.replace(/^stream:/, "")))
    .filter((index) => Number.isInteger(index) && index >= 0);
}

export function selectedDvdAudioCodecs(
  snapshot: ReturnType<typeof loadTaskSnapshot>,
  audioStreams: number[],
  selectionPlan?: string | null,
) {
  if (!snapshot || snapshot.sourceType !== "dvd") return [];
  try {
    const parsed = selectionPlan
      ? (JSON.parse(selectionPlan) as { audioStreams?: unknown })
      : null;
    if (Array.isArray(parsed?.audioStreams)) {
      const fromPlan = parsed.audioStreams
        .filter(
          (
            value,
          ): value is {
            inputIndex: number;
            codecName: string | null;
            bitsPerRawSample?: number | null;
          } => {
            if (!value || typeof value !== "object") return false;
            const candidate = value as Record<string, unknown>;
            return (
              typeof candidate.inputIndex === "number" &&
              Number.isInteger(candidate.inputIndex) &&
              (candidate.codecName === null ||
                typeof candidate.codecName === "string")
            );
          },
        )
        .filter((stream) => audioStreams.includes(stream.inputIndex));
      if (fromPlan.length > 0 || audioStreams.length === 0) return fromPlan;
    }
  } catch {
    // Fall through to the live analysis registry for older selection plans.
  }
  const analysis = discAnalysisRegistry.find(snapshot.analysisId);
  const title = analysis?.titles.find(
    (candidate) => candidate.titleId === snapshot.selectedTitleId,
  );
  return (title?.audioTracks ?? [])
    .filter((stream) => audioStreams.includes(stream.index))
    .map((stream) => ({
      inputIndex: stream.index,
      codecName: stream.codecName,
      bitsPerRawSample: stream.bitsPerRawSample ?? null,
    }));
}

function escapeSubtitlesFilterPath(filePath: string): string {
  const fwd = filePath.replace(/\\/g, "/");
  return (
    "'" +
    fwd.replace(/:/g, "\\:").replace(/'/g, "\\'").replace(/,/g, "\\,") +
    "'"
  );
}

async function extractTextSubtitle(
  sourcePath: string,
  streamIndex: number,
  outputSrt: string,
): Promise<boolean> {
  const ffmpegExecutable =
    (await resolveToolPath("ffmpeg").catch(() => null)) ?? "ffmpeg";
  return new Promise<boolean>((resolve) => {
    const ff = processRunner.spawn({
      executable: ffmpegExecutable,
      args: [
        "-y",
        "-i",
        ffmpegPath(sourcePath),
        "-map",
        "0:" + streamIndex,
        ffmpegPath(outputSrt),
      ],
      stage: "extract-text-subtitle",
      timeoutMs: 10 * 60_000,
    }).child;
    let stderr = "";
    ff.stderr?.on("data", (chunk: Buffer) => {
      if (stderr.length < 64_000) stderr += chunk.toString();
    });
    ff.on("close", (code) => resolve(code === 0));
    ff.on("error", () => resolve(false));
  });
}

export async function probeDvdAudioCodecs(
  ffprobe: string,
  sourcePath: string,
  titleNumber: number,
  audioStreams: number[],
): Promise<
  Array<{
    inputIndex: number;
    codecName: string | null;
    bitsPerRawSample?: number | null;
  }>
> {
  await ensureDvdCssSupport(ffprobe).catch(() => {});
  try {
    const out = await new Promise<string>((resolve, reject) => {
      const p = processRunner.spawn({
        executable: ffprobe,
        args: [
          "-v",
          "quiet",
          "-print_format",
          "json",
          "-f",
          "dvdvideo",
          "-title",
          String(titleNumber),
          "-show_streams",
          dvdInputArg(sourcePath),
        ],
        stage: "probe-dvd-audio",
        timeoutMs: 60_000,
      }).child;
      let data = "";
      p.stdout?.on("data", (d: Buffer) => (data += d));
      p.on("close", (code: number | null) =>
        code === 0 ? resolve(data) : reject(new Error(`ffprobe exit ${code}`)),
      );
      p.on("error", reject);
    });
    const parsed = JSON.parse(out) as {
      streams?: Array<{
        index?: number;
        codec_name?: string;
        bits_per_raw_sample?: number | string;
      }>;
    };
    return (parsed.streams ?? [])
      .filter((stream) => audioStreams.includes(Number(stream.index ?? -1)))
      .map((stream) => ({
        inputIndex: Number(stream.index),
        codecName: stream.codec_name ?? null,
        bitsPerRawSample:
          stream.bits_per_raw_sample != null
            ? Number(stream.bits_per_raw_sample)
            : null,
      }));
  } catch {
    return [];
  }
}
