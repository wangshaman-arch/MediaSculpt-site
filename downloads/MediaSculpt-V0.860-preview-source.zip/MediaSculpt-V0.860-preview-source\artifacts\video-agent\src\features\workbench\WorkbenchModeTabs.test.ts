import { describe, expect, it } from "vitest";
import { modeTechnology } from "./workbench-mode-model";

describe("WorkbenchModeTabs", () => {
  it("exposes the tool responsible for each processing mode", () => {
    expect(modeTechnology("workflow")).toBe("AI 辅助");
    expect(modeTechnology("compress")).toBe("HandBrake");
    expect(modeTechnology("remux")).toBe("FFmpeg（DVD / BD 播放列表）");
    expect(modeTechnology("none")).toBe("Whisper / AI");
  });
});
