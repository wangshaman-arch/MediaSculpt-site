import { useCallback, useEffect, useMemo, useRef } from "react";
import type { AnalyzeDiscQueryResult } from "@workspace/api-client-react";
import type { ProcessingMode } from "@/hooks/useWorkbenchState";
import { measureDiscPreviewInteraction } from "@/pages/Scan";
import type { DiscTrackWithMakeMkv } from "../disc-display-model";
import {
  assessDiscRemuxCapacity,
  isClearlyInvalidDiscTrack,
  selectCapacitySafeDiscTitles,
  setDiscTitleSelection,
} from "../disc-job-mode-model";
import { selectableStreamsForTrack } from "../disc-selection-model";
import type { DiscAnalyzeSelectionState } from "./use-disc-analyze-selection";
import type { DiscAnalyzeVerificationState } from "./use-disc-analyze-verification";

type Translate = (
  path: string,
  params?: Record<string, string | number>,
) => string;
type ToastFn = (input: {
  title?: string;
  description?: string;
  variant?: "default" | "destructive";
}) => void;

/**
 * Derives the visible/selectable title list and the per-title stream/chapter
 * handlers from the raw selection state plus verified title metadata.
 */
export function useDiscAnalyzeSelectionView({
  data,
  processingMode,
  includeVideoStreams,
  verifyDvdTitles,
  filterTitlesByProcessingMode,
  analysisOnly,
  selection,
  verification,
  t,
  toast,
  setPreviewPage,
}: {
  data: AnalyzeDiscQueryResult | undefined;
  processingMode: ProcessingMode;
  includeVideoStreams: boolean;
  verifyDvdTitles: boolean;
  filterTitlesByProcessingMode: boolean;
  analysisOnly: boolean;
  selection: DiscAnalyzeSelectionState;
  verification: Pick<
    DiscAnalyzeVerificationState,
    | "verifiedTracks"
    | "verifyingTracks"
    | "dvdVerificationComplete"
    | "effectiveTrack"
  >;
  t: Translate;
  toast: ToastFn;
  setPreviewPage: (page: number) => void;
}) {
  const {
    activeTrackIdx,
    setActiveTrackIdx,
    selectedTrackIndices,
    setSelectedTrackIndices,
    streamSelections,
    setStreamSelections,
    chapterSelections,
    setChapterSelections,
    selectionInitialized,
    setSelectionInitialized,
    defaultStreamSelection,
    defaultChapterSelection,
    initializeTrackSelection,
  } = selection;
  const { verifyingTracks, dvdVerificationComplete, effectiveTrack } =
    verification;
  const autoDvdSelectionScopeRef = useRef("");
  const autoDvdResetScopeRef = useRef("");

  const ensureTrackSelection = useCallback(
    (idx: number) => {
      const track = effectiveTrack(idx);
      if (!track) return;
      // DVD Remux controls are locked until FFprobe enriches the title. Initialize
      // once from the verified stream list so newly discovered subtitles/audio are
      // included without overwriting later user changes.
      if (
        verifyDvdTitles &&
        data?.discType === "dvd" &&
        track.verificationStatus !== "verified"
      )
        return;
      initializeTrackSelection(idx, track);
    },
    [
      data?.discType,
      effectiveTrack,
      initializeTrackSelection,
      processingMode,
      verifyDvdTitles,
    ],
  );

  const handleTrackSelect = useCallback(
    (idx: number) => {
      setActiveTrackIdx(idx);
      setPreviewPage(0);
      ensureTrackSelection(idx);
    },
    [ensureTrackSelection],
  );

  const toggleTrackSelected = useCallback(
    (idx: number, selected: boolean) => {
      ensureTrackSelection(idx);
      setSelectedTrackIndices((prev) => {
        const next = setDiscTitleSelection(prev, idx, selected);
        if (
          selected &&
          processingMode === "remux" &&
          data?.discType === "dvd" &&
          assessDiscRemuxCapacity({
            sourceBytes: data.sourceSizeBytes,
            tracks: data.tracks as Array<DiscTrackWithMakeMkv>,
            selectedIndexes: next,
          }).blocked
        ) {
          toast({
            title: t("scan.capacitySelectionBlocked"),
            variant: "destructive",
          });
          return prev;
        }
        return next;
      });
      setActiveTrackIdx(idx);
      setPreviewPage(0);
    },
    [data, ensureTrackSelection, processingMode, t, toast],
  );

  const trackSummaries = useMemo<DiscTrackWithMakeMkv[]>(
    () =>
      (data?.tracks ?? []).map(
        (initialTrack, idx) =>
          effectiveTrack(idx) ?? (initialTrack as DiscTrackWithMakeMkv),
      ),
    [data?.tracks, effectiveTrack],
  );
  const hasHandbrakeTitles = (data?.tracks ?? []).some(
    (track) => (track as DiscTrackWithMakeMkv).titleKind === "handbrake",
  );
  const isTrackVisibleForMode = useCallback(
    (track: DiscTrackWithMakeMkv): boolean => {
      // Keep metadata-only titles visible so the user sees the authoritative
      // duration and missing-file reason; selection remains blocked below.
      if (track.availabilityStatus === "unavailable") return true;
      if (isClearlyInvalidDiscTrack(track)) return false;
      if (!filterTitlesByProcessingMode) return true;
      if (track.titleKind === "handbrake")
        return (
          processingMode === "compress" ||
          (processingMode === "remux" && typeof track.playlistId === "string")
        );
      if (track.titleKind === "m2ts")
        return processingMode !== "compress" || !hasHandbrakeTitles;
      return true;
    },
    [filterTitlesByProcessingMode, processingMode, hasHandbrakeTitles],
  );

  // Drop any cached auto-selection marker when the analysis scope changes.
  useEffect(() => {
    if (!data?.tracks[0]) return;
    const scope = `${data.analysisId}:${data.sourceFingerprint}:${data.discType}:${processingMode}`;
    if (autoDvdResetScopeRef.current === scope) return;
    autoDvdResetScopeRef.current = scope;
    autoDvdSelectionScopeRef.current = "";
  }, [
    data?.analysisId,
    data?.sourceFingerprint,
    data?.discType,
    processingMode,
  ]);

  // DVD video actions verify titles asynchronously. Once a verified title is
  // available, select the valid capacity-safe set instead of leaving the user
  // with an empty queue or selecting an unverified decoy title.
  useEffect(() => {
    if (
      data?.discType !== "dvd" ||
      !verifyDvdTitles ||
      analysisOnly ||
      !dvdVerificationComplete
    )
      return;
    const scope = `${data.analysisId}:${data.sourceFingerprint}:${processingMode}`;
    if (autoDvdSelectionScopeRef.current === scope) return;
    const verifiedIndices = trackSummaries.flatMap((track, idx) =>
      track.verificationStatus === "verified" && isTrackVisibleForMode(track)
        ? [idx]
        : [],
    );
    if (verifiedIndices.length === 0) return;
    const defaults = selectCapacitySafeDiscTitles(
      trackSummaries,
      verifiedIndices,
      data.sourceSizeBytes,
    );
    if (defaults.length === 0) return;
    autoDvdSelectionScopeRef.current = scope;
    setSelectedTrackIndices((current) => {
      const next = new Set(current);
      defaults.forEach((idx) => next.add(idx));
      return next;
    });
    setStreamSelections((current) => {
      const next = new Map(current);
      for (const idx of defaults) {
        const track = trackSummaries[idx];
        if (track && !current.has(idx))
          next.set(idx, defaultStreamSelection(track));
      }
      return next;
    });
    setChapterSelections((current) => {
      const next = new Map(current);
      for (const idx of defaults) {
        const track = trackSummaries[idx];
        if (track && !current.has(idx))
          next.set(idx, defaultChapterSelection(track));
      }
      return next;
    });
    setSelectionInitialized((current) => {
      const next = new Set(current);
      defaults.forEach((idx) => next.add(idx));
      return next;
    });
  }, [
    data?.discType,
    data?.analysisId,
    data?.sourceSizeBytes,
    data?.sourceFingerprint,
    defaultChapterSelection,
    defaultStreamSelection,
    includeVideoStreams,
    dvdVerificationComplete,
    isTrackVisibleForMode,
    processingMode,
    selectedTrackIndices.size,
    trackSummaries,
    analysisOnly,
    verifyDvdTitles,
  ]);

  const selectableDiscTitleIndices = useMemo(
    () =>
      trackSummaries.flatMap((track, idx) => {
        if (!isTrackVisibleForMode(track)) return [];
        if (track.availabilityStatus === "unavailable") return [];
        if (
          data?.discType === "dvd" &&
          verifyDvdTitles &&
          track.verificationStatus !== "verified"
        )
          return [];
        return [idx];
      }),
    [data?.discType, isTrackVisibleForMode, trackSummaries, verifyDvdTitles],
  );

  function setAllDiscTitlesSelected(selected: boolean) {
    if (!data) return;
    if (!selected) {
      setSelectedTrackIndices(new Set());
      return;
    }
    const indexes =
      data.discType === "dvd"
        ? selectCapacitySafeDiscTitles(
            trackSummaries,
            selectableDiscTitleIndices,
            data.sourceSizeBytes,
          )
        : selectableDiscTitleIndices;
    setSelectedTrackIndices(new Set(indexes));
    setStreamSelections((current) => {
      const next = new Map(current);
      for (const idx of indexes) {
        const track = trackSummaries[idx];
        if (track) next.set(idx, defaultStreamSelection(track));
      }
      return next;
    });
    setChapterSelections((current) => {
      const next = new Map(current);
      for (const idx of indexes) {
        const track = trackSummaries[idx];
        if (track) next.set(idx, defaultChapterSelection(track));
      }
      return next;
    });
    setSelectionInitialized((current) => {
      const next = new Set(current);
      indexes.forEach((idx) => next.add(idx));
      return next;
    });
  }

  const selectedTrack = effectiveTrack(activeTrackIdx);

  function toggleStream(idx: number) {
    if (!selectedTrack || verifyingTracks.has(activeTrackIdx)) return;
    const startedAt =
      typeof performance !== "undefined" ? performance.now() : Date.now();
    setStreamSelections((prev) => {
      const next = new Map(prev);
      const base =
        prev.get(activeTrackIdx) ?? defaultStreamSelection(selectedTrack);
      const current = new Set(base);
      current.has(idx) ? current.delete(idx) : current.add(idx);
      next.set(activeTrackIdx, current);
      return next;
    });
    measureDiscPreviewInteraction("streamToggle", startedAt);
  }

  function toggleChapter(id: number) {
    if (!selectedTrack || verifyingTracks.has(activeTrackIdx)) return;
    const startedAt =
      typeof performance !== "undefined" ? performance.now() : Date.now();
    setChapterSelections((prev) => {
      const next = new Map(prev);
      const base =
        prev.get(activeTrackIdx) ?? defaultChapterSelection(selectedTrack);
      const current = new Set(base);
      current.has(id) ? current.delete(id) : current.add(id);
      next.set(activeTrackIdx, current);
      return next;
    });
    measureDiscPreviewInteraction("chapterToggle", startedAt);
  }

  function setAllStreamsSelected(selected: boolean) {
    if (!selectedTrack || verifyingTracks.has(activeTrackIdx)) return;
    const selectableStreams = selectedTrack.streams.filter(
      (stream) =>
        includeVideoStreams ||
        stream.codecType === "audio" ||
        stream.codecType === "subtitle",
    );
    setStreamSelections((previous) => {
      const next = new Map(previous);
      next.set(
        activeTrackIdx,
        selected
          ? new Set(selectableStreams.map((stream) => stream.index))
          : new Set(),
      );
      return next;
    });
  }

  function setAllStreamsForSelectedTitles(selected: boolean) {
    if (selectedTrackIndices.size === 0) return;
    setStreamSelections((previous) => {
      const next = new Map(previous);
      for (const idx of selectedTrackIndices) {
        const track = trackSummaries[idx];
        if (!track || verifyingTracks.has(idx)) continue;
        const selectableStreams = track.streams.filter(
          (stream) =>
            includeVideoStreams ||
            stream.codecType === "audio" ||
            stream.codecType === "subtitle",
        );
        next.set(
          idx,
          selected
            ? new Set(selectableStreams.map((stream) => stream.index))
            : new Set(),
        );
      }
      return next;
    });
  }

  function setAllChaptersSelected(selected: boolean) {
    if (!selectedTrack || verifyingTracks.has(activeTrackIdx)) return;
    setChapterSelections((previous) => {
      const next = new Map(previous);
      next.set(
        activeTrackIdx,
        selected
          ? new Set(selectedTrack.chapters?.map((chapter) => chapter.id) ?? [])
          : new Set(),
      );
      return next;
    });
  }

  const selectedStreamIndices = selectedTrack
    ? (streamSelections.get(activeTrackIdx) ??
      defaultStreamSelection(selectedTrack))
    : new Set<number>();
  const selectedChapterIds = selectedTrack
    ? (chapterSelections.get(activeTrackIdx) ??
      defaultChapterSelection(selectedTrack))
    : new Set<number>();
  const selectableStreams = selectableStreamsForTrack(
    selectedTrack,
    includeVideoStreams,
  );

  return {
    trackSummaries,
    selectedTrack,
    ensureTrackSelection,
    handleTrackSelect,
    toggleTrackSelected,
    isTrackVisibleForMode,
    selectableDiscTitleIndices,
    setAllDiscTitlesSelected,
    toggleStream,
    toggleChapter,
    setAllStreamsSelected,
    setAllStreamsForSelectedTitles,
    setAllChaptersSelected,
    selectedStreamIndices,
    selectedChapterIds,
    selectableStreams,
  };
}

export type DiscAnalyzeSelectionViewState = ReturnType<
  typeof useDiscAnalyzeSelectionView
>;
