import { describe, expect, it } from "vitest";
import { resolveBluRayM2tsTitlePath } from "./job-remux-bluray-m2ts";

describe("Blu-ray m2ts remux", () => {
  it("resolves a playlist-less m2ts title from the immutable title id", () => {
    expect(resolveBluRayM2tsTitlePath("D:\\Films\\Example", "m2ts:00042")).toBe(
      "D:\\Films\\Example\\BDMV\\STREAM\\00042.m2ts",
    );
  });

  it("does not treat playlist titles or malformed ids as m2ts fallback titles", () => {
    expect(
      resolveBluRayM2tsTitlePath("D:\\Films\\Example", "mpls:00042"),
    ).toBeNull();
    expect(
      resolveBluRayM2tsTitlePath("D:\\Films\\Example", "m2ts:x"),
    ).toBeNull();
  });
});
