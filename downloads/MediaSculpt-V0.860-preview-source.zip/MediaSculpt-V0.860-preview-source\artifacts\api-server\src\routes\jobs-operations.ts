// Miscellaneous job endpoints that are neither CRUD, preview, disc, nor admin:
// AI asset generation, stream/media probing, disc settings, subtitle pipeline.
// Extracted from routes/jobs.ts so the route entry is only a composition point.
import { Router } from "express";
import path from "path";
import { db, jobsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { GetJobParams } from "@workspace/api-zod";
import { resolveRuntimePath } from "../lib/runtime-paths";
import { ensureLocalPoster, MEDIA_INFO_DIR } from "../lib/poster";
import { addLog } from "../lib/job-logging";
import { discAnalysisRegistry } from "../lib/disc-analysis-registry";
import { getConfig } from "./jobs-config";
import { findPosterUrlByLlm } from "./jobs-prompts";
import { generateAndWriteReadme, generateAiReview } from "./job-readme-ai";
import { runSubtitlePipeline } from "./jobs-subtitle-pipeline";
import { probeMediaStreams } from "./jobs-probe";
import { sourceDirectoryForJob } from "./jobs-output-paths";

const router = Router();

// POST /jobs/:id/readme
router.post("/jobs/:id/readme", async (req, res) => {
  const idParsed = GetJobParams.safeParse(req.params);
  if (!idParsed.success)
    return res.status(400).json({ error: "无效的任务 ID" });

  const jobId = idParsed.data.id;
  const rows = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, jobId))
    .limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });

  const config = await getConfig();
  const result = await generateAndWriteReadme(jobId, config);
  return res.json(result);
});

// POST /jobs/:id/review — 立即生成专家影评（需要 LLM）。
router.post("/jobs/:id/review", async (req, res) => {
  const idParsed = GetJobParams.safeParse(req.params);
  if (!idParsed.success)
    return res.status(400).json({ error: "无效的任务 ID" });
  const jobId = idParsed.data.id;
  const rows = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, jobId))
    .limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });
  const config = await getConfig();
  const reviewPath = await generateAiReview(jobId, config);
  return res.json({ reviewPath });
});

// POST /jobs/:id/poster — 立即刮削/下载真实海报到源目录。
router.post("/jobs/:id/poster", async (req, res) => {
  const idParsed = GetJobParams.safeParse(req.params);
  if (!idParsed.success)
    return res.status(400).json({ error: "无效的任务 ID" });
  const jobId = idParsed.data.id;
  const rows = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, jobId))
    .limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });
  const config = await getConfig();
  const job = {
    ...rows[0],
    filePath: resolveRuntimePath(rows[0].filePath, config),
    mainTrackPath: rows[0].mainTrackPath
      ? resolveRuntimePath(rows[0].mainTrackPath, config)
      : null,
  };
  const posterDir = path.join(sourceDirectoryForJob(job), MEDIA_INFO_DIR);
  const posterPath = await ensureLocalPoster({
    title: job.movieTitle,
    titleEn: job.movieTitleEn,
    imdbId: job.movieImdbId,
    posterUrl: job.moviePoster,
    tmdbId: job.tmdbId,
    tmdbApiKey: config.tmdbApiKey,
    omdbApiKey: config.omdbApiKey,
    posterMirrorUrl: config.posterMirrorUrl,
    posterProxyUrl: config.posterProxyUrl,
    findPosterUrlByLlm: () => findPosterUrlByLlm(job, config),
    year: job.movieYear,
    targetDirectory: posterDir,
    onLog: async (message) => addLog(jobId, "info", message),
  });
  if (!posterPath)
    return res.status(404).json({ error: "未找到真实海报来源，跳过" });
  return res.json({ posterPath });
});

// GET /jobs/:id/streams
router.get("/jobs/:id/streams", async (req, res) => {
  const id = parseInt(req.params.id ?? "", 10);
  if (isNaN(id)) return res.status(400).json({ error: "无效的任务 ID" });

  const rows = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, id))
    .limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });

  const cfg = await getConfig();
  const job = {
    ...rows[0],
    filePath: resolveRuntimePath(rows[0].filePath, cfg),
    mainTrackPath: rows[0].mainTrackPath
      ? resolveRuntimePath(rows[0].mainTrackPath, cfg)
      : null,
    outputPath: rows[0].outputPath
      ? resolveRuntimePath(rows[0].outputPath, cfg)
      : null,
  };
  const sourcePath = job.outputPath || job.mainTrackPath || job.filePath;

  try {
    // Disc jobs (DVD/Blu-ray/ISO) point at a disc root that plain ffprobe
    // cannot enumerate. Prefer the live disc analysis for the selected title
    // so the detail drawer's source info is populated.
    let snapshot: { analysisId?: string; selectedTitleId?: string } | null =
      null;
    if (typeof job.taskSnapshot === "string" && job.taskSnapshot) {
      try {
        snapshot = JSON.parse(job.taskSnapshot) as {
          analysisId?: string;
          selectedTitleId?: string;
        };
      } catch {
        snapshot = null;
      }
    }
    const isDiscJob =
      job.mediaType === "dvd" ||
      job.mediaType === "bluray" ||
      job.mediaType === "iso";
    if (isDiscJob && snapshot?.analysisId && snapshot?.selectedTitleId) {
      const analysis = discAnalysisRegistry.find(snapshot.analysisId);
      const title = analysis?.titles.find(
        (candidate) => candidate.titleId === snapshot?.selectedTitleId,
      );
      if (title && title.streams.length > 0) {
        await addLog(
          id,
          "info",
          `使用光盘分析源信息：title=${title.titleId} streams=${title.streams.length}`,
        );
        return res.json({
          streams: title.streams.map((s) => ({
            index: s.index,
            codecType: s.codecType,
            codecName: s.codecName,
            profile: s.profile ?? null,
            description: s.description ?? null,
            language: s.language,
            title: s.title,
            channels: s.channels ?? null,
            channelLayout: s.channelLayout ?? null,
            sampleRate: s.sampleRate ?? null,
            width: s.width ?? null,
            height: s.height ?? null,
            frameRate: s.frameRate ?? null,
            bitRate: s.bitrate != null ? String(s.bitrate) : null,
            hdr: false,
            default: s.default ?? false,
            forced: s.forced ?? false,
          })),
          chapters: (title.chapters ?? []).map((c) => ({
            id: c.id,
            startSeconds: c.startSeconds,
            endSeconds: c.endSeconds,
            title: c.title,
          })),
          duration: title.durationSeconds ?? null,
          formatName: analysis?.mediaType === "bluray" ? "bluray" : "dvd",
          bitRate: null,
        });
      }
    }
    await addLog(id, "info", `正在探测流轨：${sourcePath}`);
    const result = await probeMediaStreams(sourcePath, job.mediaType);
    await addLog(
      id,
      "info",
      `流轨探测完成：${result.streams.length} 条流，${result.chapters?.length ?? 0} 个章节`,
    );
    return res.json(result);
  } catch (e) {
    await addLog(id, "error", `流轨探测失败：${String(e)}`);
    return res.status(500).json({ error: `ffprobe 失败：${String(e)}` });
  }
});

// GET /media/analyze?path= — unified analysis entry for ordinary media files.
// Disc sources continue to use /disc/analyze until playlist/title selection is
// migrated to the same source manifest in the next stage of this work.
router.get("/media/analyze", async (req, res) => {
  const rawPath = String(req.query.path ?? "");
  if (!rawPath) return res.status(400).json({ error: "path 参数不能为空" });
  const cfg = await getConfig();
  const sourcePath = resolveRuntimePath(rawPath, cfg);
  try {
    const ext = path.extname(sourcePath).toLowerCase();
    const mediaType = ext === ".iso" ? "iso" : "video";
    const result = await probeMediaStreams(sourcePath, mediaType);
    return res.json({
      sourcePath,
      mediaType,
      durationSeconds: result.duration,
      streams: result.streams.map((stream) => ({
        index: stream.index,
        codecType: stream.codecType,
        codecName: stream.codecName,
        language: stream.language,
        title: stream.title,
        width: stream.width,
        height: stream.height,
        channels: stream.channels,
        default: stream.default,
        forced: stream.forced,
      })),
      chapters: result.chapters ?? [],
    });
  } catch (e) {
    return res.status(500).json({ error: `媒体分析失败：${String(e)}` });
  }
});

// PUT /jobs/:id/disc-settings
router.put("/jobs/:id/disc-settings", async (req, res) => {
  const id = parseInt(req.params.id ?? "", 10);
  if (isNaN(id)) return res.status(400).json({ error: "无效的任务 ID" });

  const rows = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, id))
    .limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });

  const { selectedStreams, selectedChapters, processingMode, mainTrackPath } =
    req.body as {
      selectedStreams?: string | null;
      selectedChapters?: string | null;
      processingMode?: string;
      mainTrackPath?: string | null;
    };

  const update: Partial<typeof jobsTable.$inferInsert> = {};
  if (selectedStreams !== undefined) update.selectedStreams = selectedStreams;
  if (selectedChapters !== undefined)
    update.selectedChapters = selectedChapters;
  if (
    processingMode === "compress" ||
    processingMode === "remux" ||
    processingMode === "none"
  )
    update.processingMode = processingMode;
  if (mainTrackPath !== undefined) update.mainTrackPath = mainTrackPath;

  const [updated] = await db
    .update(jobsTable)
    .set(update)
    .where(eq(jobsTable.id, id))
    .returning();
  return res.json(updated);
});

// POST /jobs/:id/subtitle-pipeline
router.post("/jobs/:id/subtitle-pipeline", async (req, res) => {
  const idParsed = GetJobParams.safeParse(req.params);
  if (!idParsed.success)
    return res.status(400).json({ error: "无效的任务 ID" });

  const jobId = idParsed.data.id;
  const rows = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, jobId))
    .limit(1);
  if (!rows.length) return res.status(404).json({ error: "任务未找到" });

  // Mark pipeline as running
  await db
    .update(jobsTable)
    .set({ subtitlePipelineStatus: "running" })
    .where(eq(jobsTable.id, jobId));

  try {
    const result = await runSubtitlePipeline(jobId);
    return res.json({
      jobId,
      subtitleSource: result.subtitleSource,
      rawSubtitlePath: result.rawSubtitlePath,
      translatedSubtitlePath: result.translatedSubtitlePath,
      steps: result.steps,
    });
  } catch (e) {
    await db
      .update(jobsTable)
      .set({ subtitlePipelineStatus: "error" })
      .where(eq(jobsTable.id, jobId));
    return res.status(500).json({ error: String(e) });
  }
});

export const jobsOperationsRouter = router;
