import { useState, type ReactNode } from "react";
import { FolderOpen, List } from "lucide-react";
import { Button } from "../../components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../../components/ui/card";
import { DirectoryPicker } from "../../components/DirectoryPicker";
import type { ProcessingMode } from "../../hooks/useWorkbenchState";
import { cn } from "../../lib/utils";
import {
  defaultSourceBrowserExpanded,
  shouldShowSourceBrowser,
} from "./source-entry-model";

type WorkbenchSourceEntryText = {
  sourceDirectory: string;
  sourceDirectoryDesc: string;
  chooseDirPlaceholder: string;
  collapseList: string;
  expandList: string;
  loadingConfig: string;
  modes: Record<ProcessingMode, { label: string }>;
};

export interface WorkbenchSourceEntryProps {
  directory: string;
  configReady: boolean;
  processingMode: ProcessingMode;
  defaultExpanded?: boolean;
  hideModeBadge?: boolean;
  title?: string;
  description?: string;
  uiText: WorkbenchSourceEntryText;
  onDirectoryChange: (value: string) => void;
  browser: ReactNode;
}

export function WorkbenchSourceEntry({
  directory,
  configReady,
  processingMode,
  defaultExpanded = defaultSourceBrowserExpanded(processingMode),
  hideModeBadge,
  title,
  description,
  uiText,
  onDirectoryChange,
  browser,
}: WorkbenchSourceEntryProps) {
  const [expanded, setExpanded] = useState(defaultExpanded);
  const showToggle = shouldShowSourceBrowser(expanded, directory);

  return (
    <Card
      data-testid="workbench-source-entry"
      className="relative overflow-hidden border-primary/25 bg-primary/[0.03]"
    >
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "linear-gradient(rgba(34,211,238,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(34,211,238,0.05) 1px, transparent 1px)",
            backgroundSize: "26px 26px",
          }}
        />
      </div>
      <CardHeader className="relative z-[1] pb-3">
        <div className="flex flex-wrap items-center gap-3">
          <div className="min-w-0 flex-1">
            <CardTitle className="flex items-center gap-2 text-base">
              <FolderOpen className="h-4 w-4 text-amber-400" />
              {title ?? uiText.sourceDirectory}
            </CardTitle>
            <CardDescription className="mt-1">
              {description ?? uiText.sourceDirectoryDesc}
            </CardDescription>
          </div>
        </div>
        <div
          className="relative mt-2 flex h-9 w-full items-end overflow-hidden"
          aria-hidden
        >
          <svg
            className="h-full w-full"
            viewBox="0 0 240 40"
            preserveAspectRatio="none"
          >
            <path
              className="vx-ecg-line"
              fill="none"
              stroke="rgba(34,211,238,0.5)"
              strokeWidth="0.8"
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M0,20 L18,20 L22,14 L25,28 L28,20 L40,20 L46,16 L49,25 L52,20 L70,20 L74,2 L78,38 L82,20 L100,20 L104,14 L107,28 L110,20 L130,20 L148,20 L152,14 L155,28 L158,20 L170,20 L176,16 L179,25 L182,20 L200,20 L204,2 L208,38 L212,20 L230,20 L234,14 L237,28 L240,20"
            />
          </svg>
        </div>
        <div className="mt-2 flex min-w-0 flex-col gap-2 sm:flex-row">
          <DirectoryPicker
            value={directory}
            onChange={(value) => {
              onDirectoryChange(value);
              setExpanded(true);
            }}
            placeholder={uiText.chooseDirPlaceholder}
            className="min-w-0 flex-1"
          />
          {!hideModeBadge && (
            <span className="flex items-center gap-1 rounded border border-primary/20 bg-primary/5 px-3 py-2 text-xs text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-primary" />
              {uiText.modes[processingMode].label}
            </span>
          )}
          {showToggle && (
            <Button
              type="button"
              variant="outline"
              className="h-10 shrink-0 gap-1.5 rounded-lg px-3"
              onClick={() => setExpanded((value) => !value)}
              data-testid="source-entry-toggle"
            >
              <List className="h-4 w-4" />
              {expanded ? uiText.collapseList : uiText.expandList}
            </Button>
          )}
        </div>
      </CardHeader>
      {expanded && configReady && (
        <CardContent className="relative z-[1] border-t border-primary/15 pt-3">
          {browser}
        </CardContent>
      )}
      {expanded && !configReady && (
        <CardContent className="relative z-[1] border-t border-primary/15 pt-4 text-sm text-muted-foreground">
          {uiText.loadingConfig}
        </CardContent>
      )}
    </Card>
  );
}
