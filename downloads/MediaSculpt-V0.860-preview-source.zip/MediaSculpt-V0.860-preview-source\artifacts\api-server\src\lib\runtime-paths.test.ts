import { describe, expect, it } from "vitest";
import path from "path";
import {
  buildFfconcatFileContent,
  mapContainerToHostPath,
  resolveRuntimePath,
} from "./runtime-paths";

describe("runtime path helpers", () => {
  it("maps container paths back to host paths on native Windows", () => {
    const mapped = resolveRuntimePath(
      "/media/downloads/Movie/VIDEO_TS",
      {
        watchDirectory: "/media/downloads",
        outputDirectory: "/media/output",
        hostDownloadsPath: "H:\\Videos",
        hostOutputPath: "C:\\VX.Agent\\output",
      },
      "win32",
    );

    expect(mapped).toBe(path.win32.join("H:\\Videos", "Movie", "VIDEO_TS"));
  });

  it("maps Windows host paths to container paths only on non-Windows runtimes", () => {
    const mapped = resolveRuntimePath(
      "H:\\Videos\\Movie\\VIDEO_TS",
      {
        watchDirectory: "/media/downloads",
        outputDirectory: "/media/output",
        hostDownloadsPath: "H:\\Videos",
        hostOutputPath: "C:\\VX.Agent\\output",
      },
      "linux",
    );

    expect(mapped).toBe("/media/downloads/Movie/VIDEO_TS");
  });

  it("uses native directory settings when host mapping fields are absent", () => {
    const mapped = mapContainerToHostPath("/media/output/Movie/result.mkv", {
      outputDirectory: "C:\\Videos\\Output",
      hostOutputPath: null,
    });
    expect(mapped).toBe("C:\\Videos\\Output\\Movie\\result.mkv");
  });

  it("writes ffconcat manifests with quoted absolute paths", () => {
    const content = buildFfconcatFileContent(
      [
        "H:\\11 Days 11 Nights Part 3 (1989) DVD\\VIDEO_TS\\VTS_01_1.VOB",
        "H:\\11 Days 11 Nights Part 3 (1989) DVD\\VIDEO_TS\\VTS_01_2.VOB",
      ],
      "win32",
    );

    expect(content).toContain("ffconcat version 1.0");
    expect(content).toContain(
      "file 'H:/11 Days 11 Nights Part 3 (1989) DVD/VIDEO_TS/VTS_01_1.VOB'",
    );
    expect(content).not.toContain("file:///");
  });
});
