import path from "node:path";
import {
  buildHandBrakeSelectionArgs,
  type HandBrakeSelectionPlan,
} from "../lib/handbrake-compression-args";
import { ffmpegPath } from "../lib/runtime-paths";
import type { MediaPipelineManifest } from "./media-pipeline-contract";

export interface HandBrakeCompressionConfig {
  encoder: string;
  crf: number | string;
  outputFormat: string;
  audioCopy: boolean;
  encoderPreset?: string | null;
  encoderTune?: string | null;
  encoderProfile?: string | null;
  encoderLevel?: string | null;
  frameRate?: string | null;
  outputResolution?: string | null;
}

export interface BuildHandBrakeCompressionArgsInput {
  inputPath: string;
  outputPath: string;
  config: HandBrakeCompressionConfig;
  selectionPlan: HandBrakeSelectionPlan | null;
  deinterlace: boolean;
}

export interface BuiltHandBrakeCompressionArgs {
  args: string[];
  selectionArgs: string[];
}

function handbrakeResolutionArgs(value: string | null | undefined): string[] {
  switch (value) {
    case "2160p":
      return ["--height", "2160"];
    case "1080p":
      return ["--height", "1080"];
    case "720p":
      return ["--height", "720"];
    case "576p":
      return ["--height", "576"];
    case "480p":
      return ["--height", "480"];
    default:
      return [];
  }
}

export function buildHandBrakeCompressionArgs(
  input: BuildHandBrakeCompressionArgsInput,
): BuiltHandBrakeCompressionArgs {
  const { config } = input;
  const isX264Family =
    config.encoder.startsWith("x264") || config.encoder.startsWith("x265");
  const selectionArgs = buildHandBrakeSelectionArgs(input.selectionPlan, {
    audioCopy: config.audioCopy,
  });
  const args = [
    "-i",
    ffmpegPath(input.inputPath),
    "-o",
    ffmpegPath(input.outputPath),
    "--encoder",
    config.encoder,
    "--quality",
    String(config.crf),
    "--format",
    `av_${config.outputFormat}`,
    ...selectionArgs,
  ];

  if (selectionArgs.length === 0) {
    args.push(
      "--aencoder",
      config.audioCopy ? "copy" : "av_aac",
      "--all-audio",
      "--all-subtitles",
    );
  }

  const encoderPreset = config.encoderPreset || "slow";
  if (encoderPreset !== "none") args.push("--encoder-preset", encoderPreset);

  const encoderTune = config.encoderTune || "";
  if (isX264Family && encoderTune && encoderTune !== "none")
    args.push("--encoder-tune", encoderTune);

  const encoderProfile = config.encoderProfile || "auto";
  if (encoderProfile !== "auto") args.push("--encoder-profile", encoderProfile);

  const encoderLevel = config.encoderLevel || "auto";
  if (encoderLevel !== "auto") args.push("--encoder-level", encoderLevel);

  const frameRate = config.frameRate || "same";
  if (frameRate === "same") args.push("--vfr");
  else args.push("--rate", frameRate, "--cfr");

  args.push(...handbrakeResolutionArgs(config.outputResolution));
  if (input.deinterlace) args.push("--deinterlace");

  return { args, selectionArgs };
}

function selectedStreamIndexes(
  manifest: MediaPipelineManifest,
  ids: readonly string[],
  type: "video" | "audio" | "subtitle",
): number[] {
  const streamsById = new Map(
    manifest.title.streams.map((stream) => [stream.id, stream]),
  );
  return ids.map((id) => {
    const stream = streamsById.get(id);
    if (!stream || stream.type !== type)
      throw new Error(`压缩清单中的${type}流轨选择无效：${id}`);
    return stream.index;
  });
}

function selectedHandBrakeTrackNumbers(
  manifest: MediaPipelineManifest,
  ids: readonly string[],
  type: "audio" | "subtitle",
): number[] {
  const streamsById = new Map(
    manifest.title.streams.map((stream) => [stream.id, stream]),
  );
  return ids.map((id) => {
    const stream = streamsById.get(id);
    if (!stream || stream.type !== type)
      throw new Error(`压缩清单中的${type}流轨选择无效：${id}`);
    if (
      typeof stream.handbrakeTrackNumber !== "number" ||
      !Number.isInteger(stream.handbrakeTrackNumber) ||
      stream.handbrakeTrackNumber <= 0
    ) {
      throw new Error(
        `选中的${type === "audio" ? "音轨" : "字幕"}缺少已验证的 HandBrake ${type === "audio" ? "音轨" : "字幕"}编号：${id}`,
      );
    }
    return stream.handbrakeTrackNumber;
  });
}

export function buildHandBrakeSelectionPlanFromManifest(
  manifest: MediaPipelineManifest,
): HandBrakeSelectionPlan {
  if (manifest.output.mode !== "compress")
    throw new Error("输出模式必须是 compress");
  return {
    version: 1,
    video: selectedStreamIndexes(
      manifest,
      manifest.selection.videoStreamIds,
      "video",
    ),
    audio: selectedStreamIndexes(
      manifest,
      manifest.selection.audioStreamIds,
      "audio",
    ),
    subtitle: selectedStreamIndexes(
      manifest,
      manifest.selection.subtitleStreamIds,
      "subtitle",
    ),
    chapters: [...manifest.selection.chapterIds],
    handbrake: {
      titleNumber: manifest.title.titleNumber,
      // This is intentionally not source.physicalBytes: a disc can contain
      // multiple logical titles that share the same physical VTS payload.
      titleSizeBytes: null,
      durationSeconds: manifest.title.durationSeconds,
      audioTrackNumbers: selectedHandBrakeTrackNumbers(
        manifest,
        manifest.selection.audioStreamIds,
        "audio",
      ),
      subtitleTrackNumbers: selectedHandBrakeTrackNumbers(
        manifest,
        manifest.selection.subtitleStreamIds,
        "subtitle",
      ),
      chapterNumbers: [...manifest.selection.chapterIds],
    },
  };
}

export function buildHandBrakeCompressionArgsFromManifest(input: {
  manifest: MediaPipelineManifest;
  config: HandBrakeCompressionConfig;
  deinterlace: boolean;
}): BuiltHandBrakeCompressionArgs {
  const { manifest } = input;
  if (manifest.output.mode !== "compress")
    throw new Error("输出模式必须是 compress");
  return buildHandBrakeCompressionArgs({
    inputPath: manifest.source.path,
    outputPath: path.join(manifest.output.directory, manifest.output.fileName),
    config: input.config,
    selectionPlan: buildHandBrakeSelectionPlanFromManifest(manifest),
    deinterlace: input.deinterlace,
  });
}
