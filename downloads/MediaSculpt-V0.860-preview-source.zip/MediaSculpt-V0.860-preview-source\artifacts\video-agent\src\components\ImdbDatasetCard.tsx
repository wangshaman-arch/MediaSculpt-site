import { useState } from "react";
import {
  useGetImdbStatus,
  getGetImdbStatusQueryKey,
  useImportImdbDatasets,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useI18n } from "@/i18n";
import { useQueryClient } from "@tanstack/react-query";
import { Database, Download, FolderOpen, Loader2, Users } from "lucide-react";

/**
 * IMDb 本地数据集管理块 —— 显示导入状态并触发后台导入。
 * 数据来自 IMDb 官方免费 TSV 数据包（datasets.imdbws.com，非商业用途免费）。
 *
 * 两种导入方式：
 *  - 一键下载导入：自动下载全部 5 个数据集（含导演/演员）。
 *  - 本地文件导入：网络慢时可先手动下载，填写本地路径；留空的项自动走官方下载。
 * 导入后即使不配置任何 API Key 也能离线查询影片信息。
 */
const LOCAL_FIELDS: Array<{
  key:
    | "basicsPath"
    | "ratingsPath"
    | "crewPath"
    | "namesPath"
    | "principalsPath";
  file: string;
  required?: boolean;
}> = [
  { key: "basicsPath", file: "title.basics.tsv(.gz)", required: true },
  { key: "ratingsPath", file: "title.ratings.tsv(.gz)", required: true },
  { key: "crewPath", file: "title.crew.tsv(.gz)" },
  { key: "namesPath", file: "name.basics.tsv(.gz)" },
  { key: "principalsPath", file: "title.principals.tsv(.gz)" },
];

export function ImdbDatasetCard() {
  const { toast } = useToast();
  const { t, lang } = useI18n();
  const queryClient = useQueryClient();
  const [paths, setPaths] = useState<Record<string, string>>({});

  const { data: status } = useGetImdbStatus({
    query: {
      queryKey: getGetImdbStatusQueryKey(),
      // Poll while an import is running so progress numbers stay live
      refetchInterval: (q) =>
        q.state.data?.status === "running" ? 2000 : false,
      refetchOnWindowFocus: false,
    },
  });
  const importDatasets = useImportImdbDatasets();

  const running = status?.status === "running";
  const hasData = (status?.titleCount ?? 0) > 0;

  const handleImport = async (
    body: Record<string, string | boolean | undefined>,
  ) => {
    try {
      await importDatasets.mutateAsync({ data: body });
      queryClient.invalidateQueries({ queryKey: getGetImdbStatusQueryKey() });
      toast({
        title: t("imdb.importStarted"),
        description: t("imdb.importStartedDesc"),
      });
    } catch (e: unknown) {
      toast({
        title: t("imdb.importStartFailed"),
        description: e instanceof Error ? e.message : t("common.unknownError"),
        variant: "destructive",
      });
    }
  };

  const handleAutoImport = () => void handleImport({ withPeople: true });

  const handleLocalImport = () => {
    const basics = (paths.basicsPath ?? "").trim();
    const ratings = (paths.ratingsPath ?? "").trim();
    if (!basics || !ratings) {
      toast({
        title: t("imdb.importStartFailed"),
        description: t("imdb.localRequiresBasicsRatings"),
        variant: "destructive",
      });
      return;
    }
    void handleImport({
      basicsPath: basics,
      ratingsPath: ratings,
      crewPath: (paths.crewPath ?? "").trim() || undefined,
      namesPath: (paths.namesPath ?? "").trim() || undefined,
      principalsPath: (paths.principalsPath ?? "").trim() || undefined,
      withPeople: true,
    });
  };

  return (
    <div className="rounded-lg border border-dashed p-4 space-y-3">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-sm font-medium">
          <Database className="h-4 w-4 text-muted-foreground" />
          {t("imdb.title")}
          {hasData ? (
            <Badge variant="secondary" className="text-[10px]">
              {t("imdb.imported", {
                count: status!.titleCount.toLocaleString(),
              })}
            </Badge>
          ) : (
            <Badge
              variant="outline"
              className="text-[10px] text-muted-foreground"
            >
              {t("imdb.notImported")}
            </Badge>
          )}
        </div>
        <Button
          type="button"
          size="sm"
          variant="outline"
          className="h-7 text-xs gap-1.5"
          onClick={handleAutoImport}
          disabled={running || importDatasets.isPending}
          data-testid="btn-imdb-import"
        >
          {running ? (
            <Loader2 className="h-3 w-3 animate-spin" />
          ) : (
            <Download className="h-3 w-3" />
          )}
          {running
            ? t("imdb.importing")
            : hasData
              ? t("imdb.reimportWithPeople")
              : t("imdb.downloadImportWithPeople")}
        </Button>
      </div>

      {running && (
        <p className="text-xs text-muted-foreground">
          {status?.phase} —{" "}
          {t("imdb.linesRead", { count: status?.linesRead.toLocaleString() })}
          {t("imdb.titlesImported", {
            count: status?.titlesImported.toLocaleString(),
          })}
          {status && status.peopleImported
            ? t("imdb.peopleImported", {
                count: status.peopleImported.toLocaleString(),
              })
            : ""}
        </p>
      )}
      {status?.status === "error" && (
        <p className="text-xs text-destructive">
          {t("imdb.lastFailed", { error: status.error ?? "" })}
        </p>
      )}
      {!running && hasData && status?.lastImportAt && (
        <p className="text-xs text-muted-foreground">
          {t("imdb.lastImport")}：
          {new Date(status.lastImportAt).toLocaleString(
            lang === "en-US" ? "en-US" : "zh-CN",
          )}
        </p>
      )}

      <Separator />

      <div className="space-y-2">
        <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
          <FolderOpen className="h-3.5 w-3.5" />
          {t("imdb.localImportTitle")}
        </div>
        <p className="text-[11px] text-muted-foreground leading-relaxed">
          {t("imdb.localImportHint")}
        </p>
        {LOCAL_FIELDS.map((field) => (
          <div key={field.key} className="flex items-center gap-2">
            <Label className="w-44 shrink-0 text-[11px] text-muted-foreground">
              {field.file}
              {field.required && <span className="text-destructive"> *</span>}
            </Label>
            <Input
              type="text"
              className="h-7 flex-1 text-xs"
              value={paths[field.key] ?? ""}
              placeholder={
                field.required
                  ? t("imdb.localRequiredPath")
                  : t("imdb.localOptionalPath")
              }
              onChange={(e) =>
                setPaths((prev) => ({ ...prev, [field.key]: e.target.value }))
              }
            />
          </div>
        ))}
        <Button
          type="button"
          size="sm"
          variant="secondary"
          className="h-7 text-xs gap-1.5"
          onClick={handleLocalImport}
          disabled={running || importDatasets.isPending}
          data-testid="btn-imdb-local-import"
        >
          {running ? (
            <Loader2 className="h-3 w-3 animate-spin" />
          ) : (
            <Users className="h-3 w-3" />
          )}
          {t("imdb.localImport")}
        </Button>
      </div>

      <p className="text-[11px] text-muted-foreground leading-relaxed">
        {t("imdb.desc")}
      </p>
    </div>
  );
}
