// Extracted from task-snapshot.ts: snapshot validation, (de)serialization and summary.
import {
  deepFreeze,
  configVersion,
  TaskSnapshotError,
  type CompressionSourceStrategy,
  type TaskSnapshotV1,
} from "./task-snapshot";

export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function hasStringArray(value: unknown): value is string[] {
  return (
    Array.isArray(value) && value.every((item) => typeof item === "string")
  );
}

export function hasNumberOrNull(value: unknown): value is number | null {
  return value === null || typeof value === "number";
}

export function isTaskSnapshotV1(value: unknown): value is TaskSnapshotV1 {
  if (!isRecord(value) || value.snapshotVersion !== 1) return false;
  const strings = [
    "analysisId",
    "sourcePath",
    "sourceFingerprint",
    "sourceType",
    "selectedTitleId",
    "outputMode",
    "createdAt",
  ];
  if (!strings.every((key) => typeof value[key] === "string")) return false;
  if (
    !["video", "dvd", "bluray", "iso"].includes(value.sourceType as string) ||
    !["compress", "remux", "both", "subtitle", "whisper", "audio"].includes(
      value.outputMode as string,
    )
  )
    return false;
  if (
    value.compressionSourceStrategy !== undefined &&
    !["auto", "direct-disc", "remux-output", "temporary-remux"].includes(
      value.compressionSourceStrategy as string,
    )
  )
    return false;
  if (
    !isRecord(value.toolSelections) ||
    !isRecord(value.streamSelection) ||
    !isRecord(value.chapterSelection) ||
    !isRecord(value.remux) ||
    !isRecord(value.compression) ||
    !isRecord(value.whisper) ||
    !isRecord(value.output) ||
    !isRecord(value.toolVersions)
  )
    return false;
  if (
    !hasNumberOrNull(value.toolSelections.handbrakeTitleNumber) ||
    !hasNumberOrNull(value.toolSelections.makemkvTitleIndex) ||
    !hasNumberOrNull(value.toolSelections.dvdVtsNumber) ||
    (value.toolSelections.physicalVtsNumber !== undefined &&
      !hasNumberOrNull(value.toolSelections.physicalVtsNumber)) ||
    !hasNumberOrNull(value.toolSelections.remuxExportCandidateIndex)
  )
    return false;
  if (
    !hasStringArray(value.streamSelection.videoTrackIds) ||
    !hasStringArray(value.streamSelection.audioTrackIds) ||
    !hasStringArray(value.streamSelection.subtitleTrackIds) ||
    !hasStringArray(value.chapterSelection.chapterIds)
  )
    return false;
  if (
    !["all", "range", "selected"].includes(
      value.chapterSelection.mode as string,
    ) ||
    !hasNumberOrNull(value.chapterSelection.start) ||
    !hasNumberOrNull(value.chapterSelection.end)
  )
    return false;
  if (!["mkv", "mp4"].includes(value.remux.container as string)) return false;
  const compression = value.compression;
  if (
    typeof compression.encoder !== "string" ||
    typeof compression.crf !== "number" ||
    typeof compression.resolution !== "string" ||
    typeof compression.preset !== "string" ||
    typeof compression.audioCopy !== "boolean" ||
    typeof compression.frameRate !== "string" ||
    typeof compression.outputFormat !== "string" ||
    typeof compression.deinterlace !== "boolean" ||
    (compression.encoderTune !== undefined &&
      typeof compression.encoderTune !== "string") ||
    (compression.encoderProfile !== undefined &&
      typeof compression.encoderProfile !== "string") ||
    (compression.encoderLevel !== undefined &&
      typeof compression.encoderLevel !== "string")
  )
    return false;
  const whisper = value.whisper;
  if (
    ![
      "original-title",
      "remux-output",
      "compression-output",
      "media-file",
    ].includes(whisper.inputSource as string) ||
    !(whisper.language === null || typeof whisper.language === "string") ||
    typeof whisper.model !== "string"
  )
    return false;
  const output = value.output;
  if (
    typeof output.directory !== "string" ||
    typeof output.fileName !== "string" ||
    typeof output.format !== "string" ||
    !(
      output.subtitleDirectory === null ||
      typeof output.subtitleDirectory === "string"
    )
  )
    return false;
  const toolVersions = value.toolVersions;
  return (
    typeof toolVersions.configVersion === "string" &&
    ["handbrake", "makemkv", "ffmpeg", "whisper"].every(
      (key) =>
        toolVersions[key] === null || typeof toolVersions[key] === "string",
    )
  );
}

export function serializeTaskSnapshot(snapshot: TaskSnapshotV1): string {
  return JSON.stringify(snapshot);
}

export function parseTaskSnapshot(value: string): TaskSnapshotV1 {
  let parsed: unknown;
  try {
    parsed = JSON.parse(value);
  } catch {
    throw new TaskSnapshotError("TASK_SNAPSHOT_INVALID");
  }
  if (
    isRecord(parsed) &&
    typeof parsed.snapshotVersion === "number" &&
    parsed.snapshotVersion !== 1
  ) {
    throw new TaskSnapshotError("TASK_SNAPSHOT_UNSUPPORTED_VERSION");
  }
  if (!isTaskSnapshotV1(parsed))
    throw new TaskSnapshotError("TASK_SNAPSHOT_INVALID");
  return deepFreeze(parsed);
}

export function loadTaskSnapshot(job: {
  taskSnapshot?: string | null;
  taskSnapshotVersion?: number | null;
  legacyTask?: boolean | null;
}): TaskSnapshotV1 | null {
  if (!job.taskSnapshot) {
    if (job.legacyTask) return null;
    throw new TaskSnapshotError("TASK_SNAPSHOT_MISSING");
  }
  const snapshot = parseTaskSnapshot(job.taskSnapshot);
  if (
    job.taskSnapshotVersion !== null &&
    job.taskSnapshotVersion !== undefined &&
    job.taskSnapshotVersion !== snapshot.snapshotVersion
  ) {
    throw new TaskSnapshotError("TASK_SNAPSHOT_INVALID");
  }
  return snapshot;
}

export function taskSnapshotSummary(snapshot: TaskSnapshotV1) {
  return {
    snapshotVersion: snapshot.snapshotVersion,
    analysisId: snapshot.analysisId,
    selectedTitleId: snapshot.selectedTitleId,
    outputMode: snapshot.outputMode,
    compressionSourceStrategy: snapshot.compressionSourceStrategy ?? "auto",
    handbrakeTitleNumber: snapshot.toolSelections.handbrakeTitleNumber,
    makemkvTitleIndex: snapshot.toolSelections.makemkvTitleIndex,
    playlistId: snapshot.toolSelections.playlistId ?? null,
  };
}
