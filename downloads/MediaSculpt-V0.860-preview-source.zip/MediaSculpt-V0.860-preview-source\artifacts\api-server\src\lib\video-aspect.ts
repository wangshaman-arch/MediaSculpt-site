export type VideoAspectStream = {
  codecType?: string | null;
  attachedPicture?: boolean | null;
  default?: boolean | null;
  width?: number | null;
  height?: number | null;
  sampleAspectRatio?: string | null;
  displayAspectRatio?: string | null;
};

/** Build an ASS canvas that matches the video's display aspect, not just its pixel dimensions. */
export function playResFromVideoStreams(
  streams: VideoAspectStream[],
): { playResX: number; playResY: number } | null {
  const videos = streams.filter(
    (stream) => stream.codecType === "video" && !stream.attachedPicture,
  );
  const video = videos.find((stream) => stream.default) ?? videos[0];
  if (!video) return null;
  let dar: number | null = null;
  if (video.displayAspectRatio) {
    const [width, height] = video.displayAspectRatio.split(":").map(Number);
    if (
      Number.isFinite(width) &&
      Number.isFinite(height) &&
      width > 0 &&
      height > 0
    )
      dar = width / height;
  }
  if (dar == null && video.width && video.height) {
    let sar = 1;
    if (video.sampleAspectRatio) {
      const [width, height] = video.sampleAspectRatio.split(":").map(Number);
      if (
        Number.isFinite(width) &&
        Number.isFinite(height) &&
        width > 0 &&
        height > 0
      )
        sar = width / height;
    }
    dar = (video.width * sar) / video.height;
  }
  if (dar == null || !Number.isFinite(dar) || dar <= 0.25 || dar >= 4)
    return null;
  return { playResX: Math.round(288 * dar), playResY: 288 };
}
