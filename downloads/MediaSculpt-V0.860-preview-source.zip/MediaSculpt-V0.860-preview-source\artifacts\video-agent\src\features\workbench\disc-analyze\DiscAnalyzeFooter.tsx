import { Button } from "@/components/ui/button";
import { useI18n } from "@/i18n";
import type { ScanCopy } from "@/pages/Scan";

export type DiscAnalyzeFooterProps = {
  uiText: ScanCopy;
  creating: boolean;
  canCreate: boolean;
  showModePicker: boolean;
  modeChosen: boolean;
  selectedTitleCount: number;
  showModeRequired: boolean;
  onClose: () => void;
  onCreate: () => void;
};

export function DiscAnalyzeFooter({
  uiText,
  creating,
  canCreate,
  showModePicker,
  modeChosen,
  selectedTitleCount,
  showModeRequired,
  onClose,
  onCreate,
}: DiscAnalyzeFooterProps) {
  const { t } = useI18n();

  return (
    <>
      {showModeRequired && (
        <div className="px-4 pb-2 text-xs text-destructive">
          {t("scan.modeRequired")}
        </div>
      )}
      <div className="p-4 border-t flex gap-2 shrink-0">
        <Button variant="outline" onClick={onClose} className="flex-1">
          {uiText.cancel}
        </Button>
        <Button
          onClick={onCreate}
          disabled={!canCreate || (showModePicker && !modeChosen)}
          className="flex-1"
        >
          {creating
            ? uiText.creating
            : !modeChosen
              ? t("scan.chooseProcessingBeforeCreate")
              : selectedTitleCount === 0
                ? t("scan.chooseTitleBeforeCreate")
                : t("scan.createTaskCount", {
                    count: selectedTitleCount,
                  })}
        </Button>
      </div>
    </>
  );
}
