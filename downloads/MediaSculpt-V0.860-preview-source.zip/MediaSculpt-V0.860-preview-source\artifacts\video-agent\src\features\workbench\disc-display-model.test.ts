import { describe, expect, it } from "vitest";
import type { DiscStream, DiscTrack } from "@workspace/api-client-react";
import {
  discTrackAvailabilityReason,
  formatDiscBytes,
  formatDiscChapterDuration,
  formatDiscDuration,
  streamLanguageDisplay,
  streamDisplayLabel,
  trackLanguageDisplay,
} from "./disc-display-model";

const translate = (key: string, params?: Record<string, string | number>) => {
  if (key === "scan.noAudioInfo") return "No audio";
  if (key === "scan.noSubtitleInfo") return "No subtitles";
  if (key === "scan.unknownLanguage") return "Unknown";
  return `${key}:${JSON.stringify(params ?? {})}`;
};

const stream = (overrides: Partial<DiscStream>): DiscStream => ({
  index: 0,
  codecType: "audio",
  codecName: "aac",
  ...overrides,
});

describe("disc display model", () => {
  it("formats stream metadata and language summaries", () => {
    expect(
      streamDisplayLabel(
        stream({
          codecType: "video",
          codecName: "h264",
          width: 1920,
          height: 1080,
        }),
      ),
    ).toBe("H264 1920×1080");
    expect(
      trackLanguageDisplay(
        { streams: [stream({ language: "en", title: "Main" })] } as DiscTrack,
        "audio",
        translate,
      ),
    ).toBe("#1 英语（EN） AAC · Main");
    expect(
      streamLanguageDisplay(
        stream({
          codecType: "subtitle",
          codecName: "dvd_subtitle",
          language: "spa",
        }),
        translate,
      ),
    ).toBe("西班牙语（SPA）");
    expect(
      trackLanguageDisplay(
        {
          streams: [
            stream({
              codecType: "subtitle",
              codecName: "dvd_subtitle",
              language: "spa",
            }),
            stream({
              codecType: "subtitle",
              codecName: "dvd_subtitle",
              language: "spa",
              title: "Forced",
            }),
          ],
        } as DiscTrack,
        "subtitle",
        translate,
      ),
    ).toBe(
      "#1 西班牙语（SPA） DVD_SUBTITLE / #2 西班牙语（SPA） DVD_SUBTITLE · Forced",
    );
    expect(
      trackLanguageDisplay({ streams: [] } as DiscTrack, "subtitle", translate),
    ).toBe("No subtitles");
  });

  it("formats durations and sizes consistently", () => {
    expect(formatDiscDuration(3661)).toBe("1:01:01");
    expect(formatDiscChapterDuration(12, 75)).toBe("1:03");
    expect(formatDiscChapterDuration(75, 12)).toBe("");
    expect(formatDiscBytes(1_500_000)).toBe("1.5 MB");
  });

  it("explains why an unavailable disc title cannot be selected", () => {
    expect(
      discTrackAvailabilityReason({
        availabilityStatus: "unavailable",
        availabilityFailureReason: "缺少源文件：00000.m2ts",
      }),
    ).toBe("缺少源文件：00000.m2ts");
  });
});
