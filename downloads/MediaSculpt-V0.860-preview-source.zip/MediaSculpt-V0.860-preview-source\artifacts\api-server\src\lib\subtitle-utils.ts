export interface SubtitleTrack {
  streamIndex: number;
  typeIndex: number;
  codec: string;
  language?: string | null;
  packetCount?: number;
}

// FFmpeg has several names for bitmap, teletext and DVD subtitle codecs.
// "bitmap" is HandBrakeCLI's label for DVD/PGS graphic subtitles; "sup" is the
// PGS carrier. Kept here as the single source of truth for graphic detection.
const GRAPHIC_SUBTITLE_CODECS = new Set([
  "dvd_subtitle",
  "hdmv_pgs_subtitle",
  "pgssub",
  "vobsub",
  "dvb_subtitle",
  "dvb_teletext",
  "teletext",
  "xsub",
  "arib_caption",
  "eia_608",
  "eia_708",
  "bitmap",
  "sup",
]);

export function isGraphicSubtitleCodec(codec: string): boolean {
  return GRAPHIC_SUBTITLE_CODECS.has(codec.trim().toLowerCase());
}

export type SubtitleModeName =
  | "auto"
  | "ocr"
  | "extract"
  | "whisper"
  | "transcribe_translate"
  | "bilingual"
  | "skip";

export type SubtitleModePolicy = Readonly<{
  inspectExternal: boolean;
  extractEmbeddedText: "never" | "always-probe" | "if-detected";
  ocrGraphic: boolean;
  whisper: "never" | "when-no-subtitle" | "always";
  translateText: "never" | "when-available";
  preserveEmbeddedChinese: boolean;
}>;

const SUBTITLE_MODE_POLICIES: Record<SubtitleModeName, SubtitleModePolicy> = {
  auto: {
    inspectExternal: true,
    extractEmbeddedText: "if-detected",
    ocrGraphic: true,
    whisper: "when-no-subtitle",
    translateText: "when-available",
    preserveEmbeddedChinese: true,
  },
  ocr: {
    inspectExternal: false,
    extractEmbeddedText: "never",
    ocrGraphic: true,
    whisper: "never",
    translateText: "never",
    preserveEmbeddedChinese: false,
  },
  extract: {
    inspectExternal: true,
    extractEmbeddedText: "always-probe",
    ocrGraphic: false,
    whisper: "never",
    translateText: "never",
    preserveEmbeddedChinese: false,
  },
  whisper: {
    inspectExternal: false,
    extractEmbeddedText: "never",
    ocrGraphic: false,
    whisper: "always",
    translateText: "never",
    preserveEmbeddedChinese: false,
  },
  transcribe_translate: {
    inspectExternal: true,
    extractEmbeddedText: "always-probe",
    ocrGraphic: true,
    whisper: "when-no-subtitle",
    translateText: "when-available",
    preserveEmbeddedChinese: false,
  },
  bilingual: {
    inspectExternal: true,
    extractEmbeddedText: "always-probe",
    ocrGraphic: true,
    whisper: "when-no-subtitle",
    translateText: "when-available",
    preserveEmbeddedChinese: false,
  },
  skip: {
    inspectExternal: false,
    extractEmbeddedText: "never",
    ocrGraphic: false,
    whisper: "never",
    translateText: "never",
    preserveEmbeddedChinese: false,
  },
};

/** Single executable policy for the choices shown in the subtitle-mode UI. */
export function subtitleModePolicy(
  mode: string | null | undefined,
): SubtitleModePolicy {
  return SUBTITLE_MODE_POLICIES[
    (mode as SubtitleModeName) in SUBTITLE_MODE_POLICIES
      ? (mode as SubtitleModeName)
      : "auto"
  ];
}

export function shouldInspectExternalSubtitles(
  mode: string | null | undefined,
): boolean {
  return subtitleModePolicy(mode).inspectExternal;
}

export function shouldExtractEmbeddedText(params: {
  mode: string | null | undefined;
  hasEmbeddedSubs: boolean;
  isDvd: boolean;
}): boolean {
  const policy = subtitleModePolicy(params.mode);
  if (policy.extractEmbeddedText === "never") return false;
  if (policy.extractEmbeddedText === "always-probe") return true;
  return params.hasEmbeddedSubs || params.isDvd;
}

export function shouldOcrGraphicSubtitles(
  mode: string | null | undefined,
): boolean {
  return subtitleModePolicy(mode).ocrGraphic;
}

export function shouldPreserveEmbeddedChinese(
  mode: string | null | undefined,
): boolean {
  return subtitleModePolicy(mode).preserveEmbeddedChinese;
}

export function shouldTranslateSubtitleText(params: {
  mode: string | null | undefined;
  hasSubtitle: boolean;
}): boolean {
  const policy = subtitleModePolicy(params.mode);
  if (policy.translateText === "never") return false;
  return params.hasSubtitle;
}

/**
 * Whisper is a valid fallback only when no graphic subtitle track was found.
 * A failed OCR attempt must not reinterpret an existing bitmap subtitle as
 * missing subtitles, otherwise the audio transcript can replace the real cue
 * timing and language.
 */
export function shouldFallbackToWhisper(params: {
  mode: string;
  hasEmbeddedSubs: boolean;
  hasGraphicSubs: boolean;
  hasSubtitleOutput: boolean;
  embeddedChineseSkipped: boolean;
}): boolean {
  const whisperPolicy = subtitleModePolicy(params.mode).whisper;
  if (whisperPolicy === "always") return true;
  return (
    whisperPolicy === "when-no-subtitle" &&
    !params.hasSubtitleOutput &&
    !params.embeddedChineseSkipped &&
    (!params.hasEmbeddedSubs || !params.hasGraphicSubs)
  );
}

/** Select the fullest usable text track; graphic tracks never force speech recognition. */
export function pickBestTextSubtitle(
  tracks: SubtitleTrack[],
): SubtitleTrack | null {
  const textTracks = tracks.filter(
    (track) => !isGraphicSubtitleCodec(track.codec),
  );
  if (textTracks.length === 0) return null;
  return (
    textTracks.slice().sort((a, b) => {
      const count = (b.packetCount ?? 0) - (a.packetCount ?? 0);
      if (count !== 0) return count;
      const aEnglish = /^en(?:g)?(?:[-_]|$)/i.test(a.language ?? "") ? 1 : 0;
      const bEnglish = /^en(?:g)?(?:[-_]|$)/i.test(b.language ?? "") ? 1 : 0;
      return bEnglish - aEnglish;
    })[0] ?? null
  );
}

export function hasValidSubtitleCues(text: string): boolean {
  return /(?:^|\n)\s*\d+\s*\r?\n\s*\d{2}:\d{2}:\d{2}[,.]\d{3}\s*-->/.test(text);
}

/**
 * Reject known local/test placeholders before an AI translation is written to
 * disk. A provider returning a canned test response must fail the subtitle
 * step, never become a seemingly successful .zhs.srt or bilingual .ass file.
 */
export function assertUsableTranslatedTexts(texts: string[]): void {
  const testMarker =
    /(?:本机测试(?:中文)?|仅限本机开发测试|local development only|test subtitle)/iu;
  if (texts.some((text) => testMarker.test(text))) {
    throw new Error("AI 返回了测试占位字幕，已拒绝写入翻译文件");
  }
}

export type EmbeddedSubtitleAction = "ocr" | "extract-text" | "skip";

/**
 * Keep the route-level decision explicit: graphic subtitles are OCR input,
 * not a missing-subtitle signal that can fall through to Whisper.
 */
export function chooseEmbeddedSubtitleAction(params: {
  mode: string;
  textSubtitleCount: number;
  graphicSubtitleCount: number;
  embeddedChineseSkipped?: boolean;
}): EmbeddedSubtitleAction {
  if (params.embeddedChineseSkipped) return "skip";
  if (
    params.textSubtitleCount > 0 &&
    subtitleModePolicy(params.mode).extractEmbeddedText !== "never"
  )
    return "extract-text";
  if (params.graphicSubtitleCount > 0 && shouldOcrGraphicSubtitles(params.mode))
    return "ocr";
  return "skip";
}

export type SubtitleOnlyOutputDisposition = "success" | "error";

/** Explicit translation requests must never be reported as successful without a translated file. */
export function explicitTranslationFailureMessage(params: {
  mode: string;
  translatedOutput: boolean;
  error?: string | null;
}): string | null {
  if (params.mode !== "transcribe_translate") return null;
  if (params.error?.trim()) return params.error.trim();
  return params.translatedOutput ? null : "未生成翻译字幕文件";
}

/**
 * Decide whether a subtitle-only task may finish without a standalone file.
 * No speech and an OCR miss are valid media outcomes when the source remains
 * usable; an expected text subtitle that failed every extraction still needs
 * to be reported as an error.
 */
export function subtitleOnlyOutputDisposition(params: {
  hasSubtitleOutput: boolean;
  hasBilingualOutput?: boolean;
  sourceHasAudio: boolean;
  whisperProducedEmpty: boolean;
  graphicSubtitlePreserved: boolean;
  expectedTextSubtitle?: boolean;
  requestedMode: string;
}): SubtitleOnlyOutputDisposition {
  if (params.requestedMode === "skip") return "success";
  // A bilingual task promises a merged, usable sidecar. An OCR SRT or an
  // embedded DVD bitmap subtitle remaining in the source is not that output.
  if (params.requestedMode === "bilingual")
    return params.hasBilingualOutput ? "success" : "error";
  if (params.hasSubtitleOutput) return "success";
  if (params.whisperProducedEmpty || params.graphicSubtitlePreserved)
    return "success";
  if (!params.sourceHasAudio && !params.expectedTextSubtitle) return "success";
  return "error";
}
