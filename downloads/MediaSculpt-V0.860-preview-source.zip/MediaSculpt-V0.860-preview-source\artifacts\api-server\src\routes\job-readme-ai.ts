// Extracted from routes/jobs.ts: README / AI review generation helpers (the AI asset stage).
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import {
  lookupAll,
  metadataIdentityMatches,
  normalizeTitleEn,
} from "../lib/metadata";
import {
  servePreviewSegment,
  cleanupPreviewSegments,
} from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import {
  buildFfconcatFileContent as buildManifest,
  buildFfconcatChapterContent,
  buildFfconcatTimedContent,
  type FfconcatTimedSegment,
} from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import {
  appendJobRuntimeLog,
  appendJobToolOutput,
} from "../lib/job-runtime-log";
import {
  appendRuntimeToolLog,
  appendRuntimeToolOutput,
} from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import {
  buildCompressionOutputName,
  buildRemuxOutputName,
  cleanSegment,
  encoderBitDepth,
  selectBestAudioTrack,
} from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import {
  renderBilingualAss,
  DEFAULT_BILINGUAL_STYLE,
  type BilingualAssStyle,
  type SubtitleBlock,
} from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import {
  ensureLocalPoster,
  MEDIA_INFO_DIR,
  POSTER_META_FILE,
  posterIdentityMatches,
} from "../lib/poster";
import {
  ensureFasterWhisperModel,
  ensureWhisperCliScript,
} from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import {
  hasValidSubtitleCues,
  isGraphicSubtitleCodec,
  shouldFallbackToWhisper,
} from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import {
  buildDvdRemuxArgs,
  runDvdRemux,
  verifyDvdTitle,
} from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import {
  buildDvdStructurePayload,
  resolveRemuxPlanWithLlm,
  validateRemuxPlan,
} from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import {
  assertPreviewTaskAllowed,
  recordPreviewAiCall,
  settlePreviewTask,
} from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import {
  parseCustomTuning,
  resolveLogicPlaceholders,
} from "../lib/custom-tuning";
import {
  decryptSecret,
  encryptSecret,
  isEncryptedSecret,
} from "../lib/secrets";
import {
  ffmpegPath,
  resolveOutputDir,
  resolveRuntimePath,
  type RuntimePathConfig,
} from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import {
  assertCompleteMediaTitle,
  createDvdMediaTitle,
} from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import {
  buildPreviewTranscodeArgs,
  isPreviewVideoCandidate,
  previewService,
} from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";
import { addLog } from "../lib/job-logging";
import { getConfig } from "./jobs-config";
import { probeMediaStreams } from "./jobs-probe";
import {
  resolveJobOutputDirectory,
  ensureDirectory,
  sourceDirectoryForJob,
} from "./jobs-output-paths";
import { findPosterUrlByLlm } from "./jobs-prompts";

function wrapText(text: string, width = 60): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let line = "";
  for (const w of words) {
    // 无空格的长中文段落按字符硬换行，避免一行超长
    if (w.length > width) {
      if (line) {
        lines.push(line);
        line = "";
      }
      for (let i = 0; i < w.length; i += width)
        lines.push(w.slice(i, i + width));
      continue;
    }
    if (line && (line + " " + w).length > width) {
      lines.push(line);
      line = w;
    } else {
      line += (line ? " " : "") + w;
    }
  }
  if (line) lines.push(line);
  return lines;
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/** 带海报的 HTML 资料卡：正文与 readme.txt 完全一致（白色卡片 + 左侧海报）。 */
function buildReadmeHtml(
  titleLine: string,
  content: string,
  posterRef: string | null,
): string {
  const posterHtml = posterRef
    ? `<img src="${escapeHtml(posterRef)}" alt="Poster">`
    : `<div class="placeholder">Poster</div>`;
  return `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(titleLine)}</title>
<style>
  body { margin:0; padding:24px; background:#f3f4f6; font-family:"Segoe UI","Microsoft YaHei",sans-serif; color:#222; }
  .card { max-width:860px; margin:0 auto; background:#fff; border:1px solid #d9d9d9; border-radius:10px; padding:20px; display:flex; gap:20px; box-shadow:0 2px 10px rgba(0,0,0,.08); }
  .poster { flex:0 0 200px; }
  .poster img { width:100%; border-radius:6px; box-shadow:0 2px 8px rgba(0,0,0,.2); display:block; }
  .poster .placeholder { width:100%; aspect-ratio:2/3; border-radius:6px; background:#e8e8e8; display:flex; align-items:center; justify-content:center; color:#888; font-size:13px; }
  .content { flex:1; min-width:0; white-space:pre-wrap; word-break:break-word; font-size:13.5px; line-height:1.65; }
</style>
</head>
<body>
<div class="card">
  <div class="poster">${posterHtml}</div>
  <div class="content">${escapeHtml(content)}</div>
</div>
</body>
</html>`;
}

/** 源名：DVD/蓝光光碟结构目录（VIDEO_TS/BDMV 等）取影片文件夹名，普通文件取文件名（去扩展名）。 */
function sourceBaseName(filePath: string): string {
  const parts = filePath.split(/[\\/]/).filter(Boolean);
  const last = parts[parts.length - 1] ?? "";
  if (/^(VIDEO_TS|BDMV|DVD|AUDIO_TS)$/i.test(last))
    return parts[parts.length - 2] ?? last;
  return path.basename(filePath, path.extname(filePath)) || last;
}

export async function generateAndWriteReadme(
  jobId: number,
  config: Awaited<ReturnType<typeof getConfig>>,
): Promise<{ readmePath: string; content: string }> {
  const rows = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, jobId))
    .limit(1);
  if (!rows.length) throw new Error("任务未找到");
  const job = {
    ...rows[0],
    filePath: resolveRuntimePath(rows[0].filePath, config),
    mainTrackPath: rows[0].mainTrackPath
      ? resolveRuntimePath(rows[0].mainTrackPath, config)
      : null,
  };

  // 用剧集/影片英文名而不是视频文件全名：movieTitleEn 优先，
  // 缺失时对源文件夹/文件名做标签清洗（去掉年份/分辨率/编码/发布组）。
  const rawSourceName = sourceBaseName(job.filePath);
  const titleEn =
    normalizeTitleEn(job.movieTitleEn || rawSourceName) ||
    job.movieTitleEn ||
    job.movieTitle ||
    rawSourceName;
  const fmtBytes = (bytes: number | null | undefined): string =>
    bytes && bytes > 0
      ? `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB (${(bytes / 1024 / 1024).toFixed(0)} MB)`
      : "N/A";
  const fmtDuration = (seconds: number | null | undefined): string => {
    if (!seconds || seconds <= 0) return "N/A";
    const total = Math.round(seconds);
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = total % 60;
    return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  };
  const codecLabel = (codec: string | null | undefined): string => {
    const map: Record<string, string> = {
      h264: "H.264 / AVC",
      hevc: "H.265 / HEVC",
      mpeg2video: "MPEG-2 Video",
      mpeg4: "MPEG-4 Part 2",
      vc1: "VC-1",
      vp9: "VP9",
      av1: "AV1",
      ac3: "AC-3 (Dolby Digital)",
      eac3: "E-AC-3 (Dolby Digital Plus)",
      dts: "DTS",
      truehd: "DTS-HD MA / TrueHD",
      flac: "FLAC",
      pcm_s16le: "PCM 16-bit",
      pcm_s24le: "PCM 24-bit",
      pcm_dvd: "PCM (DVD)",
      mp3: "MP3",
      aac: "AAC",
      vobsub: "VobSub (DVD)",
      dvd_subtitle: "DVD Subtitle",
      subrip: "SubRip (SRT)",
      ass: "ASS/SSA",
      hdmv_pgs_subtitle: "PGS (Blu-ray)",
    };
    return map[String(codec ?? "").toLowerCase()] ?? String(codec ?? "N/A");
  };
  const langLabel = (lang: string | null | undefined): string => {
    const map: Record<string, string> = {
      eng: "English / 英语",
      en: "English / 英语",
      zho: "Chinese / 中文",
      chi: "Chinese / 中文",
      zh: "Chinese / 中文",
      ger: "German / 德语",
      de: "German / 德语",
      fre: "French / 法语",
      fr: "French / 法语",
      spa: "Spanish / 西班牙语",
      es: "Spanish / 西班牙语",
      rus: "Russian / 俄语",
      ru: "Russian / 俄语",
      jpn: "Japanese / 日语",
      ja: "Japanese / 日语",
      ita: "Italian / 意大利语",
      it: "Italian / 意大利语",
      kor: "Korean / 韩语",
      ko: "Korean / 韩语",
    };
    return map[String(lang ?? "").toLowerCase()] ?? String(lang ?? "und");
  };

  // 标题：标准格式 英语名.年代.中文名
  const titleZh = job.movieTitle || "";
  const titleLine = [
    titleEn.replace(/[.]{2,}/g, ".").replace(/^\.+|\.+$/g, ""),
    job.movieYear,
    titleZh,
  ]
    .filter(Boolean)
    .join(".");
  const mediaLabel =
    job.mediaType === "dvd"
      ? "DVD"
      : job.mediaType === "bluray"
        ? "BluRay"
        : job.mediaType === "iso"
          ? "ISO"
          : "Video";

  // 影片简介与主创资料：任务已有 overview 直接用；缺失时用 LLM 按已确认的片名/年份生成，
  // 同时提取导演/类型/主演（中英双语），失败则标注待补充（绝不编造）。
  let overview = job.movieOverview || "";
  let director = job.movieDirector || "";
  let genres = job.movieGenres || "";
  let castZh = "";
  let castEn = "";
  if ((!overview || !director || !genres) && (titleEn || titleZh)) {
    try {
      const apiKey = resolveApiKey(config);
      if (apiKey) {
        const { baseUrl, model } = resolveAiEndpoint(config);
        const response = await fetch(
          `${baseUrl.replace(/\/$/, "")}/chat/completions`,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${apiKey}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              model,
              temperature: 0.3,
              max_tokens: 500,
              messages: [
                {
                  role: "system",
                  content:
                    "你是影视资料助手。根据片名与年份，输出影片资料。格式严格如下（每行一个字段，纯文本）：\nDIRECTOR=<导演，中文名（英文原名），不确定留空>\nGENRE=<类型，如 剧情/爱情>\nCAST_ZH=<主要演员中文名，顿号分隔，不确定留空>\nCAST_EN=<主要演员英文原名，逗号分隔，与 CAST_ZH 一一对应，不确定留空>\nOVERVIEW=<150-250 字中文简介，不编造；不确定处标注“待确认”>\n不要输出任何其他内容。",
                },
                {
                  role: "user",
                  content: `片名：${titleZh || titleEn}；英文名：${titleEn}；年份：${job.movieYear ?? ""}`,
                },
              ],
            }),
          },
        );
        void recordPreviewAiCall("readme-metadata").catch(() => {});
        if (response.ok) {
          const payload = (await response.json().catch(() => ({}))) as {
            choices?: Array<{ message?: { content?: string } }>;
          };
          const generated = payload.choices?.[0]?.message?.content?.trim();
          if (generated) {
            const directorMatch = /^DIRECTOR=(.*)$/im.exec(generated);
            const genreMatch = /^GENRE=(.*)$/im.exec(generated);
            const castZhMatch = /^CAST_ZH=(.*)$/im.exec(generated);
            const castEnMatch = /^CAST_EN=(.*)$/im.exec(generated);
            const overviewMatch = /^OVERVIEW=([\s\S]*)$/im.exec(generated);
            if (directorMatch?.[1]?.trim() && !director)
              director = directorMatch[1].trim();
            if (genreMatch?.[1]?.trim() && !genres)
              genres = genreMatch[1].trim();
            if (castZhMatch?.[1]?.trim()) castZh = castZhMatch[1].trim();
            if (castEnMatch?.[1]?.trim()) castEn = castEnMatch[1].trim();
            if (overviewMatch?.[1]?.trim())
              overview = cleanReviewText(overviewMatch[1].trim());
          }
        }
      }
    } catch {
      overview = "";
    }
    if (!overview)
      overview =
        "（简介待补充：当前未配置 AI 或简介生成失败，可通过任务分析获取）";
  }

  // 原始视频参数：ffprobe 探测（失败时降级用任务快照）
  let probe: {
    streams: Array<{
      codecType: string;
      codecName: string | null;
      profile: string | null;
      language: string | null;
      channels: number | null;
      sampleRate: number | null;
      width: number | null;
      height: number | null;
      frameRate: string | null;
      bitRate: string | null;
      title: string | null;
    }>;
    duration: number | null;
    bitRate: string | null;
    formatName: string | null;
  } | null = null;
  try {
    probe = await probeMediaStreams(job.filePath, job.mediaType);
  } catch {
    probe = null;
  }
  const duration = probe?.duration ?? job.durationSeconds ?? null;
  const videoStreams = (probe?.streams ?? []).filter(
    (stream) => stream.codecType === "video",
  );
  const audioStreams = (probe?.streams ?? []).filter(
    (stream) => stream.codecType === "audio",
  );
  const subtitleStreams = (probe?.streams ?? []).filter(
    (stream) => stream.codecType === "subtitle",
  );
  const video = videoStreams[0] ?? null;

  // 格式：收藏级资料卡，参考经典 DVD 封底排版——纯资料字段，无处理过程信息、无装饰线段。
  const lines: string[] = [];
  lines.push(`${titleLine}`);
  lines.push("");

  // 基本信息（双语）
  lines.push(`Title: ${titleEn}`);
  if (titleZh && titleZh !== titleEn) lines.push(`中文名: ${titleZh}`);
  lines.push(`The Genre: ${genres || "N/A"}`);
  lines.push(`Year of manufacture: ${job.movieYear ?? "N/A"}`);
  lines.push(`The duration: ${fmtDuration(duration)}`);
  lines.push(`The manufacturer: ${mediaLabel}`);
  if (director) lines.push(`导演 Director: ${director}`);
  if (castZh && castEn)
    lines.push(
      `主演 Cast: ${castZh
        .split(/[、,，]/)
        .map(
          (name, index) =>
            `${name}（${castEn.split(",")[index]?.trim() ?? ""}）`,
        )
        .join("；")}`,
    );
  else if (castZh) lines.push(`主演 Cast: ${castZh}`);
  if (job.movieRating)
    lines.push(`The Rating: ${job.movieRating.toFixed(1)} / 10`);
  if (job.tmdbId) lines.push(`TMDb ID: ${job.tmdbId}`);
  lines.push("");

  // 影片简介：与智能助手“概要预览”为同一段文字（analysisResult 已持久化为 movieOverview），
  // 按段落换行，避免长中文段落挤成一行。
  if (overview) {
    lines.push("Synopsis:");
    const paragraphs = overview
      .split(/\n+/)
      .map((paragraph: string) => paragraph.trim())
      .filter(Boolean);
    for (const paragraph of paragraphs)
      lines.push(...wrapText(paragraph, 66).map((line) => `  ${line}`));
    lines.push("");
  }

  // 原始视频参数（无处理信息）
  lines.push("The quality: 原始视频源");
  lines.push(
    `The Format: ${(probe?.formatName ?? "N/A").split(",")[0]}${video && video.width && video.height ? ` ${video.width}x${video.height}` : ""}${
      video?.frameRate && video.frameRate !== "0/0"
        ? ` ${(() => {
            const [n, d] = video.frameRate.split("/").map(Number);
            return n && d ? (n / d).toFixed(3) : video.frameRate;
          })()}fps`
        : ""
    }${video?.bitRate ? ` ${(Number(video.bitRate) / 1000).toFixed(0)}kbps` : ""}`,
  );
  if (video)
    lines.push(
      `Video: ${codecLabel(video.codecName)}${video.profile ? ` (${video.profile})` : ""}${video.width && video.height ? ` ${video.width}x${video.height}` : ""}`,
    );
  lines.push(
    `Audio: ${audioStreams.length > 0 ? audioStreams.map((stream) => `${codecLabel(stream.codecName)} ${stream.channels ? `${stream.channels}ch` : ""} ${langLabel(stream.language)}`).join(" / ") : "N/A"}`,
  );
  lines.push(
    `The Subtitles: ${subtitleStreams.length > 0 ? subtitleStreams.map((stream) => langLabel(stream.language)).join(", ") : "N/A"}`,
  );
  lines.push(`The Size: ${fmtBytes(job.fileSizeBefore ?? null)}`);
  lines.push("");

  const content = lines.join("\n");

  const outputDir = resolveJobOutputDirectory(config, job);
  const infoDir = path.join(outputDir, MEDIA_INFO_DIR);
  await ensureDirectory(infoDir);
  const readmeStem =
    titleEn.replace(/[.]{2,}/g, ".").replace(/^\.+|\.+$/g, "") ||
    rawSourceName ||
    "movie";
  const txtPath = path.join(infoDir, `${readmeStem}.readme.txt`);
  await fs.writeFile(txtPath, content, "utf-8");

  // 海报图片：优先用 MediaInfo 里的 poster.jpg/folder.jpg（与 readme 同目录）；
  // 输出目录不同时复制一份，保证 HTML 卡片能用相对路径引用真实海报。
  let posterRef: string | null = null;
  try {
    const posterSourceDir = path.join(
      sourceDirectoryForJob(job),
      MEDIA_INFO_DIR,
    );
    const found = ["poster.jpg", "folder.jpg"]
      .map((name) => path.join(posterSourceDir, name))
      .find((candidate) => {
        try {
          return fsSync.statSync(candidate).isFile();
        } catch {
          return false;
        }
      });
    if (found) {
      const target = path.join(infoDir, path.basename(found));
      if (
        path.resolve(target) !== path.resolve(found) &&
        !fsSync.existsSync(target)
      ) {
        await fs.copyFile(found, target);
      }
      posterRef = path.basename(found);
    }
  } catch {
    // 海报缺失或复制失败不阻塞 readme 生成
  }

  const htmlPath = path.join(infoDir, `${readmeStem}.readme.html`);
  await fs.writeFile(
    htmlPath,
    buildReadmeHtml(titleLine, content, posterRef),
    "utf-8",
  );
  await db
    .update(jobsTable)
    .set({ readmePath: htmlPath })
    .where(eq(jobsTable.id, jobId));

  return { readmePath: htmlPath, content };
}

/**
 * 智能生成优先阶段：说明 → 影评 → 海报，任何队列任务都在视频处理
 * （Remux → 字幕 → 压缩）之前完成这三项。单项失败只记录日志，不阻塞后续步骤。
 */
export async function runAiAssetStage(
  jobId: number,
  config: typeof configTable.$inferSelect,
  job: typeof jobsTable.$inferSelect,
): Promise<void> {
  await addLog(
    jobId,
    "info",
    "智能生成阶段开始：说明 → 影评 → 海报（优先于视频处理）",
  );
  // 1) 说明（readme）
  if (job.generateReadme !== false) {
    try {
      await generateAndWriteReadme(jobId, config);
      await addLog(
        jobId,
        "info",
        "说明已生成（readme.txt + readme.html，含海报）",
      );
    } catch (error) {
      await addLog(
        jobId,
        "warn",
        `说明（readme.txt）生成失败：${error instanceof Error ? error.message : String(error)}`,
      );
    }
  }
  // 2) 影评
  if (job.generateReview === true) {
    try {
      await generateAiReview(jobId, config);
    } catch (error) {
      await addLog(
        jobId,
        "warn",
        `影评生成失败：${error instanceof Error ? error.message : String(error)}`,
      );
    }
  }
  // 3) 海报（刮削落盘：TMDb → OMDb → 豆瓣/维基/iTunes → 信息卡兜底）
  if (
    job.generatePoster !== false &&
    (job.moviePoster || job.movieTitleEn || job.movieTitle || job.tmdbId)
  ) {
    try {
      const posterDir = path.join(sourceDirectoryForJob(job), MEDIA_INFO_DIR);
      const posterPath = await ensureLocalPoster({
        title: job.movieTitle,
        titleEn: job.movieTitleEn,
        imdbId: job.movieImdbId,
        posterUrl: job.moviePoster,
        tmdbId: job.tmdbId,
        tmdbApiKey: config.tmdbApiKey,
        omdbApiKey: config.omdbApiKey,
        posterMirrorUrl: config.posterMirrorUrl,
        posterProxyUrl: config.posterProxyUrl,
        findPosterUrlByLlm: () => findPosterUrlByLlm(job, config),
        year: job.movieYear,
        targetDirectory: posterDir,
        onLog: async (message) => addLog(jobId, "info", message),
      });
      if (posterPath) {
        await addLog(jobId, "info", `海报已就绪：${posterPath}`);
        // 把本地海报端点写回任务，UI 才能显示（此前只落了文件、未写 moviePoster）。
        const posterQuery = new URLSearchParams({
          path: job.filePath,
          t: String(Date.now()),
        });
        if (job.movieImdbId) posterQuery.set("imdbId", job.movieImdbId);
        if (job.movieTitle) posterQuery.set("title", job.movieTitle);
        if (job.movieTitleEn) posterQuery.set("titleEn", job.movieTitleEn);
        if (job.movieYear) posterQuery.set("year", String(job.movieYear));
        await db
          .update(jobsTable)
          .set({ moviePoster: `/api/media/poster?${posterQuery.toString()}` })
          .where(eq(jobsTable.id, jobId))
          .catch((err: unknown) =>
            addLog(
              jobId,
              "warn",
              `海报端点写回失败：${err instanceof Error ? err.message : String(err)}`,
            ),
          );
      }
    } catch (error) {
      await addLog(
        jobId,
        "warn",
        `海报获取失败：${error instanceof Error ? error.message : String(error)}`,
      );
    }
  }
  await addLog(jobId, "info", "智能生成阶段完成");
}

/** 清理影评中的 Markdown 残留（###、星号、反引号、列表符等），保证纯文本格式。 */
function cleanReviewText(text: string): string {
  return text
    .replace(/^#{1,6}\s*/gm, "")
    .replace(/^\s*[*_\-+]\s+/gm, "")
    .replace(/[*_`~]/g, "")
    .replace(/!?\[([^\]]*)\]\([^)]*\)/g, "$1")
    .replace(/^>\s*/gm, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/** Generate a professional expert-style review via the configured LLM. */
export async function generateAiReview(
  jobId: number,
  config: Awaited<ReturnType<typeof getConfig>>,
): Promise<string | null> {
  const rows = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.id, jobId))
    .limit(1);
  if (!rows.length) throw new Error("任务未找到");
  const job = rows[0];
  const apiKey = resolveApiKey(config);
  if (!apiKey) {
    await addLog(jobId, "warn", "未配置 AI API Key，跳过影评生成");
    return null;
  }
  const { baseUrl, model } = resolveAiEndpoint(config);
  const title =
    job.movieTitle ??
    (normalizeTitleEn(sourceBaseName(job.filePath)) ||
      sourceBaseName(job.filePath));
  const contextParts = [
    job.movieTitle ? `中文片名：${job.movieTitle}` : null,
    job.movieTitleEn ? `英文片名：${job.movieTitleEn}` : null,
    job.movieYear ? `年份：${job.movieYear}` : null,
    job.movieDirector ? `导演：${job.movieDirector}` : null,
    job.movieGenres ? `类型：${job.movieGenres}` : null,
    job.movieRating ? `评分：${job.movieRating.toFixed(1)}/10` : null,
    job.movieOverview ? `剧情简介：${job.movieOverview}` : null,
  ].filter(Boolean) as string[];
  // 尽力抓取演员信息（网络不可达时静默跳过）
  if (job.tmdbId && config.tmdbApiKey) {
    try {
      const castResp = await fetch(
        `https://api.themoviedb.org/3/movie/${job.tmdbId}/credits?api_key=${encodeURIComponent(config.tmdbApiKey)}&language=zh-CN`,
        { signal: AbortSignal.timeout(8_000) },
      );
      if (castResp.ok) {
        const castData = (await castResp.json()) as {
          cast?: Array<{ name?: string }>;
        };
        const names = (castData.cast ?? [])
          .slice(0, 5)
          .map((entry) => entry.name)
          .filter((name): name is string => Boolean(name));
        if (names.length > 0)
          contextParts.push(`主要演员：${names.join("、")}`);
      }
    } catch {
      // 网络不可达，跳过演员信息
    }
  }
  const context = contextParts.join("\n");
  const reviewTuning = parseCustomTuning(config.customTuning);
  const customReview = resolveLogicPlaceholders(
    reviewTuning.prompts.review,
    reviewTuning.logic,
  ).trim();
  const systemPrompt = `${customReview ? `【用户补充指令】\n${customReview}\n\n` : ""}你是一位资深影视评论家，为收藏级影片库撰写专业影评。你的读者是认真收藏与欣赏影视作品的人。\n\n写作要求：\n1. 只使用【影片信息】中提供的事实（片名、年份、类型、导演、主演、剧情简介、评分等），不得编造具体情节、人物、数字或引文。\n2. 结构（纯文本分节，不要 Markdown 符号）：\n   第一部分（约 500 字影评，写在专家意见之前）：先写一段约 500 字的独立影评——开篇一句话定调，然后依次是作品背景与内容概述（忠实概括、不剧透关键转折）、主题与艺术分析（叙事、摄影/画面/配乐/舞台等制作层面）、表演与创作评价（导演/指挥/主演/主创的表现）、适合人群与推荐结论。这部分要有作者立场、专业但不晦涩。\n   第二部分（专家与媒体评价，放在 500 字影评之后）：必须引用 3 家以上具体、知名的媒体或评论家观点，逐条列出并标明出处（如《纽约时报 The New York Times》《卫报 The Guardian》《观察家报 The Observer》、Rotten Tomatoes、Metacritic、Variety、Sight & Sound、Roger Ebert 等）。引用非中文资源时，媒体/专家名称与引文必须中英双语（格式：媒体中文名（English Name），引文先给中文译文，再在括号内附英文原文或注明出处与时间）；只引用你确知真实存在的评价；若你无法确知任何具体媒体评价，明确写出“未能核实到权威媒体评论”，并用「多家媒体普遍认为」作概括，绝不虚构媒体名称、专家姓名或引文。\n3. 特殊情形：如果影片/演出刚刚上映（发布不足数月）或公开资料不足以支撑影评，则以「作品介绍」代替影评——客观介绍主创阵容、题材内容、已知的制作背景与已发布的资料，明确标注“资料有限，暂以介绍代替影评”，禁止编造评价或评分。\n4. 格式：纯文本；禁止一切 Markdown 符号（#、###、*、**、- 列表符、反引号、链接语法）；分节用「一、二、三……」或空行；结尾另起一行注明：「本文由 AI 综合公开资料与媒体评论生成，仅供参考。」\n\n【影片信息】\n${context || "（无）"}`;
  const endpoint = `${baseUrl.replace(/\/$/, "")}/chat/completions`;
  const chat = async (userContent: string): Promise<string> => {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        temperature: 0.7,
        max_tokens: 2400,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userContent },
        ],
      }),
    });
    void recordPreviewAiCall("readme-review").catch(() => {});
    if (!response.ok) throw new Error(`AI API 错误 ${response.status}`);
    const data = (await response.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const content = data.choices?.[0]?.message?.content?.trim();
    if (!content) throw new Error("影评内容为空");
    return content;
  };
  // 两段式：先出提纲，再按提纲成稿；提纲失败时退回单段生成。
  let outline = "";
  try {
    outline = await chat(
      `请先只输出一份约 200 字的影评提纲与要点，不要输出正文。影片：《${title}》。`,
    );
  } catch {
    outline = "";
  }
  const rawContent = outline
    ? await chat(
        `请为《${title}》撰写一篇约 1200–1500 字的专业影评，严格按照上面的提纲组织内容，纯文本格式，不要任何 Markdown 符号。\n\n【提纲】\n${outline}`,
      )
    : await chat(
        `请为《${title}》撰写一篇约 1200–1500 字的专业影评，纯文本格式，不要任何 Markdown 符号。`,
      );
  const content = cleanReviewText(rawContent);
  const outputDir = resolveJobOutputDirectory(config, {
    filePath: job.filePath,
    mainTrackPath: job.mainTrackPath,
    mediaType: job.mediaType,
  });
  const reviewPath = path.join(outputDir, "review.txt");
  await fs.writeFile(reviewPath, `${content}\n`, "utf-8");
  await addLog(
    jobId,
    "info",
    `影评已生成（纯文本，已清理 Markdown）：${reviewPath}`,
  );
  return reviewPath;
}
