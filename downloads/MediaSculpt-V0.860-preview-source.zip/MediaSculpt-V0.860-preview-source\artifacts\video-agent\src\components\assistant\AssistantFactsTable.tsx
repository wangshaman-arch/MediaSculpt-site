export type AssistantFactRow = readonly [string, string | number];

export function AssistantFactsTable({
  rows,
}: {
  rows: ReadonlyArray<AssistantFactRow>;
}) {
  return (
    <dl
      className="grid min-w-0 grid-cols-1 gap-y-1.5 rounded-md border bg-secondary/15 p-2"
      data-testid="assistant-facts"
    >
      {rows.map(([label, value]) => (
        <div
          key={label}
          className="grid min-w-0 grid-cols-[max-content_minmax(0,1fr)] gap-x-2"
        >
          <dt className="whitespace-nowrap font-medium text-foreground/80">
            {label}
          </dt>
          <dd className="min-w-0 break-words whitespace-pre-wrap text-muted-foreground">
            {value}
          </dd>
        </div>
      ))}
    </dl>
  );
}
