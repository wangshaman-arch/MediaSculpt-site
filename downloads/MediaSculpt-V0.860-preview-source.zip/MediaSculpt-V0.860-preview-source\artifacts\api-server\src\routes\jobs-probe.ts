// Extracted from routes/jobs.ts: media stream probing (ffprobe / dvdvideo / BDMV).
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import {
  lookupAll,
  metadataIdentityMatches,
  normalizeTitleEn,
} from "../lib/metadata";
import {
  servePreviewSegment,
  cleanupPreviewSegments,
} from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import {
  buildFfconcatFileContent as buildManifest,
  buildFfconcatChapterContent,
  buildFfconcatTimedContent,
  type FfconcatTimedSegment,
} from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import {
  appendJobRuntimeLog,
  appendJobToolOutput,
} from "../lib/job-runtime-log";
import {
  appendRuntimeToolLog,
  appendRuntimeToolOutput,
} from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import {
  dvdTitleNavigationInputArgs,
  withDvdConcatList,
  dvdConcatInputArgs,
  dvdVideoInputPath,
} from "./jobs-dvd";
import { mountBlurayIso, unmountBlurayIso } from "./jobs-iso";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import {
  buildCompressionOutputName,
  buildRemuxOutputName,
  cleanSegment,
  encoderBitDepth,
  selectBestAudioTrack,
} from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import {
  renderBilingualAss,
  DEFAULT_BILINGUAL_STYLE,
  type BilingualAssStyle,
  type SubtitleBlock,
} from "../lib/bilingual-subtitle";
import { playResFromVideoStreams } from "../lib/video-aspect";
import { resolveToolPath } from "../lib/tool-runtime";
import {
  ensureLocalPoster,
  MEDIA_INFO_DIR,
  POSTER_META_FILE,
  posterIdentityMatches,
} from "../lib/poster";
import {
  ensureFasterWhisperModel,
  ensureWhisperCliScript,
} from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import {
  hasValidSubtitleCues,
  isGraphicSubtitleCodec,
  shouldFallbackToWhisper,
} from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import {
  buildDvdRemuxArgs,
  runDvdRemux,
  verifyDvdTitle,
} from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import {
  buildDvdStructurePayload,
  resolveRemuxPlanWithLlm,
  validateRemuxPlan,
} from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import {
  assertPreviewTaskAllowed,
  recordPreviewAiCall,
  settlePreviewTask,
} from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import {
  parseCustomTuning,
  resolveLogicPlaceholders,
} from "../lib/custom-tuning";
import {
  decryptSecret,
  encryptSecret,
  isEncryptedSecret,
} from "../lib/secrets";
import {
  ffmpegPath,
  resolveOutputDir,
  resolveRuntimePath,
  type RuntimePathConfig,
} from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import {
  assertCompleteMediaTitle,
  createDvdMediaTitle,
} from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import {
  buildPreviewTranscodeArgs,
  isPreviewVideoCandidate,
  previewService,
} from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";

interface FfprobeStream {
  index: number;
  codec_type: string;
  codec_name: string;
  profile?: string;
  tags?: { language?: string; title?: string; [k: string]: string | undefined };
  channels?: number;
  channel_layout?: string;
  sample_rate?: string;
  width?: number;
  height?: number;
  sample_aspect_ratio?: string;
  display_aspect_ratio?: string;
  r_frame_rate?: string;
  avg_frame_rate?: string;
  bit_rate?: string;
  color_transfer?: string;
  color_primaries?: string;
  field_order?: string;
  disposition?: { default?: number; forced?: number; attached_pic?: number };
}

/** Run ffprobe and return parsed stream info */
export async function probeStreams(sourcePath: string, inputArgs?: string[]) {
  const ffprobe =
    (await resolveToolPath("ffprobe").catch(() => null)) ?? "ffprobe";
  const raw = await new Promise<string>((resolve, reject) => {
    const p = processRunner.spawn({
      executable: ffprobe,
      args: buildFfprobeAnalysisArgs(
        sourcePath,
        inputArgs ?? [ffmpegPath(sourcePath)],
      ),
      stage: "probe-streams",
      timeoutMs: 60_000,
    }).child;
    let out = "";
    p.stdout?.on("data", (d) => (out += d));
    p.on("close", (code) =>
      code === 0 ? resolve(out) : reject(new Error(`ffprobe exit ${code}`)),
    );
    p.on("error", reject);
  });
  const data = JSON.parse(raw) as {
    streams: FfprobeStream[];
    chapters?: Array<{
      start_time?: string;
      end_time?: string;
      tags?: { title?: string };
    }>;
    format?: { format_name?: string; duration?: string; bit_rate?: string };
  };

  const HDR_TRANSFERS = new Set(["smpte2084", "arib-std-b67", "smpte428"]);
  const HDR_PRIMARIES = new Set(["bt2020"]);

  const streams = (data.streams ?? []).map((s) => ({
    index: s.index,
    codecType: s.codec_type,
    codecName: s.codec_name,
    profile: s.profile ?? null,
    language: s.tags?.language ?? null,
    title: s.tags?.title ?? null,
    channels: s.channels ?? null,
    channelLayout: s.channel_layout ?? null,
    sampleRate: s.sample_rate ? parseInt(s.sample_rate) : null,
    width: s.width ?? null,
    height: s.height ?? null,
    sampleAspectRatio: s.sample_aspect_ratio ?? null,
    displayAspectRatio: s.display_aspect_ratio ?? null,
    pixelAspectRatio: s.width && s.height ? `${s.width}/${s.height}` : null,
    frameRate: s.avg_frame_rate !== "0/0" ? (s.avg_frame_rate ?? null) : null,
    bitRate: s.bit_rate ?? null,
    fieldOrder:
      s.field_order && s.field_order !== "unknown"
        ? (s.field_order ?? null)
        : null,
    hdr:
      HDR_TRANSFERS.has(s.color_transfer ?? "") ||
      HDR_PRIMARIES.has(s.color_primaries ?? ""),
    default: (s.disposition?.default ?? 0) === 1,
    forced: (s.disposition?.forced ?? 0) === 1,
    attachedPicture: (s.disposition?.attached_pic ?? 0) === 1,
  }));

  return {
    streams,
    sourcePath,
    formatName: data.format?.format_name ?? null,
    duration: data.format?.duration ? parseFloat(data.format.duration) : null,
    bitRate: data.format?.bit_rate ?? null,
    chapters: (data.chapters ?? []).map((chapter, id) => ({
      id,
      startSeconds: Number(chapter.start_time ?? 0),
      endSeconds: Number(chapter.end_time ?? 0),
      title: chapter.tags?.title ?? null,
    })),
  };
}

/**
 * 按视频实际显示宽高比（DAR）计算双语 ASS 的 PlayRes：
 * PlayResY 固定 288，PlayResX = 288 × DAR。播放器按 PlayRes 与视频尺寸
 * 等比缩放，这样字体在任意宽高比视频上占相同高度比例且不会变形
 * （锁定字体的高宽比）。探测失败时回退 384×288（4:3）。
 */
export async function probeVideoPlayRes(
  mediaPath: string,
  onWarning?: (message: string) => Promise<void> | void,
  inputArgs?: string[],
  fallbackPaths?: string[],
): Promise<{ playResX: number; playResY: number }> {
  let sourceProbeError: unknown = null;
  try {
    const probe = await probeStreams(mediaPath, inputArgs);
    const playRes = playResFromVideoStreams(probe.streams);
    if (playRes) return playRes;
  } catch (error) {
    sourceProbeError = error;
  }
  // Some Windows dvdvideo probes fail against the navigation input even
  // though the selected title's VOB files remain independently probeable.
  // Use those exact title files, not an arbitrary disc-wide VOB, so mixed
  // 4:3/16:9 DVDs retain the aspect ratio of the selected title.
  if (inputArgs?.includes("dvdvideo")) {
    for (const vobPath of fallbackPaths ?? []) {
      try {
        const fallbackProbe = await probeStreams(vobPath);
        const playRes = playResFromVideoStreams(fallbackProbe.streams);
        if (playRes) {
          await onWarning?.(
            `DVD 导航比例探测${sourceProbeError ? "失败" : "未返回有效比例"}，已从所选标题 VOB 恢复画面比例：${path.basename(vobPath)}`,
          );
          return playRes;
        }
      } catch {
        // Try the next VOB belonging to this exact selected title.
      }
    }
  }
  if (sourceProbeError) {
    await onWarning?.(
      `视频比例探测失败，双语 ASS 暂按 4:3 画布生成：${sourceProbeError instanceof Error ? sourceProbeError.message : String(sourceProbeError)}`,
    );
  } else {
    await onWarning?.(
      "无法从源视频流确定有效显示比例，双语 ASS 暂按 4:3 画布生成；请检查媒体探测结果",
    );
  }
  return { playResX: 384, playResY: 288 };
}

/** Detect interlaced video from probed stream info (field order first, then
 * the classic 480i/576i/1080i frame-rate signature). */
export function detectInterlacedFromStreams(
  streams: Array<{
    codecType?: string | null;
    fieldOrder?: string | null;
    frameRate?: string | null;
    height?: number | null;
  }>,
): boolean {
  const video = streams.find((stream) => stream.codecType === "video");
  if (!video) return false;
  const fieldOrder = video.fieldOrder?.toLowerCase();
  if (
    fieldOrder === "tt" ||
    fieldOrder === "bb" ||
    fieldOrder === "tb" ||
    fieldOrder === "bt"
  )
    return true;
  if (fieldOrder === "progressive") return false;
  const frameRate = video.frameRate ?? "";
  const match = /^(\d+)\/(\d+)$/.exec(frameRate);
  if (!match || Number(match[2]) === 0) return false;
  const fps = Number(match[1]) / Number(match[2]);
  const isInterlacedFps =
    Math.abs(fps - 29.97) < 0.05 ||
    Math.abs(fps - 25) < 0.05 ||
    Math.abs(fps - 30) < 0.05;
  const height = video.height ?? 0;
  return (
    isInterlacedFps && (height === 480 || height === 576 || height === 1080)
  );
}

async function probeDvdTitleStreams(title: DvdTitle) {
  if (title.titleNumber > 0) {
    try {
      return probeStreams(title.ifoPath, [
        "-analyzeduration",
        "100M",
        "-probesize",
        "100M",
        ...dvdTitleNavigationInputArgs(title),
      ]);
    } catch {
      // Fall back to raw VOB probing below when the local ffmpeg build lacks
      // the dvdvideo demuxer. Remux itself still logs the concrete failure.
    }
  }
  if (title.vobFiles.length === 0) return probeStreams(title.ifoPath);

  const firstVob = title.vobFiles[0];
  try {
    const result = await withDvdConcatList(title, "probe", (listFile) =>
      probeStreams(title.ifoPath, [
        "-analyzeduration",
        "100M",
        "-probesize",
        "100M",
        ...dvdConcatInputArgs(listFile),
      ]),
    );
    if (result.streams.length > 0 || !firstVob) return result;
  } catch (concatError) {
    if (!firstVob) throw concatError;
  }

  return probeStreams(title.ifoPath, [
    "-analyzeduration",
    "100M",
    "-probesize",
    "100M",
    ffmpegPath(firstVob),
  ]);
}

/**
 * Probe a DVD title by its global dvdvideo title number.
 *
 * The dvdvideo demuxer numbers titles globally (one entry per PGC), which is NOT
 * the same as the per-VTS index returned by resolveDvdTitleForSource whenever a
 * single VTS holds more than one title. Probing with the verified number is the
 * only way to read the streams/duration of the title the user actually selected;
 * otherwise a job that picked title N is silently measured against a different,
 * much shorter title (e.g. MC.14.22: VTS_03 holds the 53:55 feature, but
 * dvdvideo title 3 is a 1.1 s clip while the feature is title 4).
 */
export async function probeDvdTitleByNumber(
  sourcePath: string,
  titleNumber: number,
) {
  const inputPath = dvdVideoInputPath(sourcePath);
  return probeStreams(inputPath, [
    "-analyzeduration",
    "100M",
    "-probesize",
    "100M",
    "-f",
    "dvdvideo",
    "-title",
    String(titleNumber),
    "-i",
    inputPath,
  ]);
}

export async function probeMediaStreams(
  sourcePath: string,
  mediaType?: string | null,
) {
  if (mediaType === "dvd" || /\.ifo$/i.test(sourcePath)) {
    const dvdTitle = await resolveDvdTitleForSource(sourcePath);
    if (dvdTitle) return probeDvdTitleStreams(dvdTitle);
  }
  if (/\.iso$/i.test(sourcePath)) {
    // ISO 镜像必须挂载后才能读取内部 m2ts / VOB；探测完立即卸载。
    const mounted = await mountBlurayIso(sourcePath);
    if (mounted) {
      try {
        const m2ts = await findMainBlurayM2ts(mounted);
        if (m2ts) return await probeStreams(m2ts);
      } finally {
        await unmountBlurayIso(sourcePath).catch(() => {});
      }
    }
  }
  if (
    mediaType === "bluray" ||
    /[\\/]BDMV$/i.test(sourcePath) ||
    /\.iso$/i.test(sourcePath)
  ) {
    const m2ts = await findMainBlurayM2ts(sourcePath);
    if (m2ts) return probeStreams(m2ts);
  }
  return probeStreams(sourcePath);
}

/** Locate the main m2ts inside a BDMV folder so ffprobe has a real file to read. */
async function findMainBlurayM2ts(sourcePath: string): Promise<string | null> {
  const streamDir = /[\\/]STREAM$/i.test(sourcePath)
    ? sourcePath
    : path.join(sourcePath, "BDMV", "STREAM");
  const entries = await fs.readdir(streamDir).catch(() => []);
  const m2tsFiles = entries.filter((name) => /\.m2ts$/i.test(name));
  if (m2tsFiles.length === 0) return null;
  let best: { name: string; size: number } | null = null;
  for (const name of m2tsFiles) {
    const filePath = path.join(streamDir, name);
    const size = (await fs.stat(filePath).catch(() => null))?.size ?? 0;
    if (!best || size > best.size) best = { name, size };
  }
  return best ? path.join(streamDir, best.name) : null;
}
