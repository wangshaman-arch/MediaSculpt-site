import { describe, expect, it } from "vitest";
import {
  extractAssistantImdbId,
  extractAssistantMetadata,
  extractAssistantOverview,
} from "./assistant-overview";

describe("extractAssistantOverview", () => {
  it("extracts the prose overview from the real assistant response layout", () => {
    const reply = [
      "IMDBID=tt0106206",
      "Abrahams.Valley · 亚伯拉罕山谷 · 1993 · 剧情 · 葡萄牙 · 187分钟",
      "IMDb 编号：tt0106206",
      "IMDb 评分：7.2（约2100票）",
      "豆瓣评分：8.0（来源：豆瓣）",
      "导演：曼努埃尔·德·奥利维拉",
      "主要演员：塞西莉亚·卡瓦略、路易斯·米格尔·辛特拉",
      "本片改编自葡萄牙作家阿古斯蒂娜·贝萨-路易斯的同名小说，围绕埃玛的婚姻与情感经历展开。",
      "",
      "资料信息：",
      "IMDb：tt0108471",
    ].join("\n");

    expect(extractAssistantOverview(reply)).toBe(
      "本片改编自葡萄牙作家阿古斯蒂娜·贝萨-路易斯的同名小说，围绕埃玛的婚姻与情感经历展开。",
    );
  });

  it("supports an inline overview label", () => {
    expect(extractAssistantOverview("内容简介：一段已核验的简介。")).toBe(
      "一段已核验的简介。",
    );
  });

  it("does not repeat the compact metadata header in the prose overview", () => {
    expect(
      extractAssistantOverview(
        [
          "内容简介：The.Making.of.King.Arthur · 造就亚瑟王 · 2010 · 纪录片 · 英国 · 约59分钟",
          "本片聚焦亚瑟王传说的历史起源。",
          "本片聚焦亚瑟王传说的历史起源。",
        ].join("\n"),
      ),
    ).toBe("本片聚焦亚瑟王传说的历史起源。");
  });

  it("keeps prose when the compact header and 主创栏 share one line", () => {
    expect(
      extractAssistantOverview(
        "内容简介：The.Making.of.King.Arthur · 造就亚瑟王 · 2010 · 纪录片 · 英国 · 约59分钟 主创栏：本片从历史学与考古学角度探究亚瑟王传说。",
      ),
    ).toBe("本片从历史学与考古学角度探究亚瑟王传说。");
  });

  it("does not append metadata repeated after an explicit overview heading", () => {
    expect(
      extractAssistantOverview(
        [
          "内容简介：一段已核验的简介。",
          "导演：示例导演",
          "主要演员：示例演员",
          "IMDb 评分：7.2",
          "资料信息：",
          "IMDb：tt0106206",
        ].join("\n"),
      ),
    ).toBe("一段已核验的简介。");
  });

  it("returns no overview for an identity-only reply", () => {
    expect(extractAssistantOverview("IMDb 编号：tt0108471")).toBe("");
  });

  it("extracts rating and crew fields without treating them as the overview", () => {
    const reply = [
      "IMDb 评分：7.1（约 2,000 票）",
      "豆瓣评分：8.1",
      "导演：马诺埃尔·德·奥利维拉（Manoel de Oliveira）",
      "主要演员：塞西莉亚·卡多佐饰 Ema、路易斯·米格尔·辛特拉饰 Carlos Paiva",
      "类型：剧情/爱情",
      "片长：163分钟",
      "",
      "影片围绕年轻女子 Ema 的婚姻与情感经历展开。",
      "IMDb 编号：tt0108471",
    ].join("\n");

    expect(extractAssistantMetadata(reply)).toMatchObject({
      rating: 7.1,
      ratingVotes: 2000,
      doubanRating: 8.1,
      director: "马诺埃尔·德·奥利维拉（Manoel de Oliveira）",
      cast: ["塞西莉亚·卡多佐饰 Ema", "路易斯·米格尔·辛特拉饰 Carlos Paiva"],
      genres: "剧情/爱情",
      runtimeMinutes: 163,
    });
    expect(extractAssistantOverview(reply)).toBe(
      "影片围绕年轻女子 Ema 的婚姻与情感经历展开。",
    );
  });
});

describe("assistant overview against a captured real reply", () => {
  const blowUpReply = [
    "IMDBID=tt0060176",
    "Blow-Up · 放大 · 1966 · 剧情/悬疑/惊悚 · 英国/意大利/美国 · 111分钟",
    "IMDb 编号：tt0060176",
    "IMDb 评分：7.5（约7.5万票）",
    "豆瓣评分：8.5（豆瓣，约4.5万票）",
    "主创：",
    "导演：米开朗基罗·安东尼奥尼（Michelangelo Antonioni）",
    "编剧：米开朗基罗·安东尼奥尼（Michelangelo Antonioni）、托尼诺·格拉（Tonino Guerra）",
    "主演：大卫·海明斯（David Hemmings）饰 托马斯（Thomas）",
    "摄影：卡洛·迪·帕尔马（Carlo Di Palma）",
    "配乐：赫伯特·汉考克（Herbie Hancock）",
    "制片：卡洛·庞蒂（Carlo Ponti）",
    "简介：",
    "《放大》是意大利导演米开朗基罗·安东尼奥尼于1966年执导的英语电影，讲述时尚摄影师托马斯在公园拍下一对男女的画面。",
  ].join("\n");

  it("keeps a plot paragraph that mentions a year and a dotted name", () => {
    const overview = extractAssistantOverview(blowUpReply);
    expect(overview).toContain(
      "《放大》是意大利导演米开朗基罗·安东尼奥尼于1966年执导",
    );
    expect(overview).not.toContain("基本信息");
    expect(overview).not.toContain("摄影：");
  });

  it("keeps writers out of the director field and reports them as a credit", () => {
    const metadata = extractAssistantMetadata(blowUpReply);
    expect(metadata.director).toBe(
      "米开朗基罗·安东尼奥尼（Michelangelo Antonioni）",
    );
    expect(metadata.credits).toContainEqual({
      label: "编剧",
      value:
        "米开朗基罗·安东尼奥尼（Michelangelo Antonioni）、托尼诺·格拉（Tonino Guerra）",
    });
    expect(metadata.credits).toContainEqual({
      label: "摄影",
      value: "卡洛·迪·帕尔马（Carlo Di Palma）",
    });
    expect(metadata.credits).toContainEqual({
      label: "制片",
      value: "卡洛·庞蒂（Carlo Ponti）",
    });
    expect(metadata.rating).toBe(7.5);
    expect(metadata.ratingVotes).toBe(75000);
    expect(metadata.doubanRating).toBe(8.5);
  });
});

describe("extractAssistantImdbId", () => {
  it("reads the model's claim so it can be offered as an unverified suggestion", () => {
    expect(extractAssistantImdbId("IMDBID=tt0060176\nTITLE_EN=Blow-Up")).toBe(
      "tt0060176",
    );
    expect(extractAssistantImdbId("资料：IMDb 编号：tt34745960")).toBe(
      "tt34745960",
    );
  });

  it("returns nothing when the reply carries no id", () => {
    expect(
      extractAssistantImdbId("本片为历史纪实节目，具体资料待确认。"),
    ).toBeNull();
    expect(extractAssistantImdbId(null)).toBeNull();
  });
});

describe("crew labels the reply joins or leaves unconfirmed", () => {
  it("captures a joined label such as 主持人/旁白", () => {
    const metadata = extractAssistantMetadata(
      "主持人/旁白：丹·斯诺（Dan Snow）\n制片方：待确认",
    );
    expect(metadata.credits).toContainEqual({
      label: "主持人/旁白",
      value: "丹·斯诺（Dan Snow）",
    });
  });

  it("does not record an unconfirmed placeholder as a credit", () => {
    const metadata =
      extractAssistantMetadata("制片方：待确认\n播出平台：待确认");
    expect(metadata.credits).toBeUndefined();
  });
});
