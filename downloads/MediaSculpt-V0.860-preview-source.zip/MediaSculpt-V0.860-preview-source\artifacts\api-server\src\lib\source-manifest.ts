export type SourceMediaType = "video" | "bluray" | "dvd" | "iso";

export type SourceManifest = {
  version: 1;
  kind: "file" | "disc";
  mediaType: SourceMediaType;
  path: string;
  mainTrackPath?: string | null;
};

export function buildSourceManifest(input: {
  filePath: string;
  mediaType: SourceMediaType;
  mainTrackPath?: string | null;
}): SourceManifest {
  const kind =
    input.mediaType === "video" || input.mediaType === "iso" ? "file" : "disc";
  return {
    version: 1,
    kind,
    mediaType: input.mediaType,
    path: input.filePath,
    ...(input.mainTrackPath ? { mainTrackPath: input.mainTrackPath } : {}),
  };
}
