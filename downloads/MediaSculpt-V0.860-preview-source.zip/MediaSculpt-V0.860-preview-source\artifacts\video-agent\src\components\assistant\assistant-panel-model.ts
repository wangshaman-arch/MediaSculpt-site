import type { AssistantPreferences, ProcessingStep } from "../AssistantPanel";

export const DEFAULT_PREFERENCES: AssistantPreferences = {
  titleEn: "",
  titleZh: "",
  year: null,
  imdbId: "",
  processing: [],
  subtitle: null,
};

/** 年代字段的界面占位值：仅用于灰色显示与加减按钮的起点，绝不进入请求。 */
export const YEAR_PLACEHOLDER = 2010;

export const DEFAULT_STEP_ORDER: ProcessingStep[] = [
  "remux",
  "subtitle",
  "compress",
  "chapterPreview",
];

const VIDEO_EXT_RE = /\.(mkv|mp4|avi|mov|wmv|flv|m4v|ts|m2ts|vob|iso)$/i;

function extractYearFromTitle(value: string): number | null {
  const match = /(?:19|20)\d{2}/.exec(value);
  return match ? Number(match[0]) : null;
}

/** 源显示名：DVD/蓝光取光碟文件夹名（VIDEO_TS/BDMV/DVD/AUDIO_TS 等光碟结构目录则取上层影片文件夹），视频取文件名。 */
export function sourceDisplayName(value: string): string {
  const parts = value.split(/[\\/]/).filter(Boolean);
  const last = parts[parts.length - 1] ?? "";
  if (/^(VIDEO_TS|BDMV|DVD|AUDIO_TS)$/i.test(last))
    return parts[parts.length - 2] ?? last;
  return VIDEO_EXT_RE.test(last) ? last.replace(VIDEO_EXT_RE, "") : last;
}

export function parentBasename(value: string): string {
  const parts = value.split(/[\\/]/).filter(Boolean);
  return parts[parts.length - 2] ?? "";
}

/** 年代提取顺序：源名（文件夹/文件名）→ 与片名同名的上级目录名 → null */
export function yearFromSource(value: string): number | null {
  return (
    extractYearFromTitle(sourceDisplayName(value)) ??
    extractYearFromTitle(parentBasename(value))
  );
}

/** 把显示名拆成 外语名 / 中文名 / 年代：Prisoners.of.Terpsichore.1995.特彼斯霍瑞 → … */
export function splitSourceName(value: string): {
  titleEn: string;
  titleZh: string;
  year: number | null;
} {
  const year = extractYearFromTitle(value);
  const zhMatch = value.match(
    /[\u3400-\u9fff][\u3400-\u9fff·•\u2022\u2027\u30fb\uff65]*/,
  );
  const titleZh = zhMatch?.[0] ?? "";
  let english = titleZh ? value.replace(titleZh, "") : value;
  english = english
    .replace(/(?:19|20)\d{2}/, "")
    .replace(/^[.\s]+|[.\s]+$/g, "");
  // 剥离方括号/圆括号/花括号，避免 [2007]、[]、[rutracker] 等发布标签碎片残留
  english = english.replace(/[\[\](){}]/g, " ");
  const tagPatterns: RegExp[] = [
    /^\d{3,4}p$/i,
    /^(s\d{1,2}(e\d{1,4})?)$/i,
    /^(season|seasons|episode|episodes|series)$/i,
    /^第?\d{1,2}季$/,
    /^(19|20)\d{2}$/,
    /^(x264|x265|h264|h265|hevc|avc|av1|10bit|8bit)$/i,
    /^(aac|ac3|dts|truehd|flac|mp3|pcm|eac3|atmos)$/i,
    /^(bluray|bdrip|dvdrip|webdl|web-dl|webrip|hdtv|hdtvrip|pdtv|remux|hdr|dv|uhd|4k|2160p|1080p|720p|480p|576p|amzn|amazon)$/i,
    /^(mvgroup|rutracker|kinosvalka|yify|rarbg|fgt|ctrlhd|nzb|deflate)$/i,
    /^(org|com|net|info)$/i,
    /^part\s*\d+$/i,
    /^p\d{1,2}$/i,
    /^\d{1,2}$/,
    /^(x26[45]|h26[45]|hevc|avc|av1|web|bd|bluray|dvdrip|webrip|hdtv|remux|uhd|2160p|1080p|720p|480p|576p)-[a-z0-9]+$/i,
    /^\d{1,2}of\d{1,2}$/i,
    /^\d{1,2}x\d{1,4}$/i,
    /^(dvd5|dvd9|2dvd5|2dvd9|dvdr|bd25|bd50|bdr)$/i,
    /^(multi|rus|eng|chi|zho|ger|deu|fre|fra|spa|jpn|kor|ita|pol|cze|hun|nld|swe|nor|dan|fin|por|ara|heb|tur|tha|vie|ind)$/i,
    /^(complete|proper|repack)$/i,
    /^(mkv|mp4|avi|mov|wmv|flv|m4v|ts|m2ts|vob|iso|srt|ass|idx|sub)$/i,
    /^(cc|uk|us|criterion|criterioncollection)$/i,
  ];
  const releaseMarkerPatterns: RegExp[] = [
    /^(19|20)\d{2}$/,
    /^\d{3,4}p$/i,
    /^(s\d{1,2}(e\d{1,4})?)$/i,
    /^\d{1,2}x\d{1,4}$/i,
    /^\d{1,2}of\d{1,2}$/i,
    /^(amzn|amazon|bluray|bdrip|dvdrip|webdl|web-dl|webrip|hdtv|hdtvrip|pdtv|remux|uhd|4k|2160p|1080p|720p|480p|576p|hdr|dv|x264|x265|h264|h265|hevc|avc|av1|10bit|8bit|aac|ac3|dts|truehd|flac|mp3|pcm|eac3|atmos|dvd5|dvd9|2dvd5|2dvd9|complete|proper|repack)$/i,
  ];
  const isTag = (token: string): boolean => {
    if (tagPatterns.some((pattern) => pattern.test(token))) return true;
    if (token.includes("&")) {
      const parts = token.split("&").filter(Boolean);
      return (
        parts.length >= 2 &&
        parts.every((part) => tagPatterns.some((pattern) => pattern.test(part)))
      );
    }
    return false;
  };
  const rawTokens = english.split(/[.\s_]+/).filter(Boolean);
  const markerIndex = rawTokens.findIndex((token) =>
    releaseMarkerPatterns.some((pattern) => pattern.test(token)),
  );
  const titleTokens =
    markerIndex >= 0 ? rawTokens.slice(0, markerIndex) : rawTokens;
  const titleEn = titleTokens
    .filter((token) => !/[\u3400-\u9fff]/.test(token))
    .filter((token) => !isTag(token))
    .join(".");
  return { titleEn, titleZh, year };
}

/** 目录名的中文段：取末尾连续的纯中文 token（允许 . 或 · 分隔），如 唐璜.大都会歌剧院。 */
export function folderChineseSegment(dirName: string): string {
  const tokens = dirName.split(".").filter(Boolean);
  const zhTokens: string[] = [];
  for (let i = tokens.length - 1; i >= 0; i--) {
    const token = tokens[i];
    if (/^[\u3400-\u9fff·•\u2022\u2027\u30fb\uff65]+$/.test(token)) {
      zhTokens.unshift(token);
    } else {
      break;
    }
  }
  return zhTokens.join(".");
}

function longestCommonPrefixLen(a: string, b: string): number {
  let i = 0;
  while (i < a.length && i < b.length && a[i] === b[i]) i += 1;
  return i;
}

/** 视频文件所在目录规则：目录英文段与文件名基本一致时，目录的中文段即视频的中文片名。 */
export function folderChineseTitleForSource(sourcePath: string): string {
  if (!sourcePath) return "";
  const parts = sourcePath.split(/[\\/]/).filter(Boolean);
  const last = parts[parts.length - 1] ?? "";
  if (!VIDEO_EXT_RE.test(last)) return "";
  const dir = parentBasename(sourcePath);
  const dirZh = folderChineseSegment(dir);
  if (!dirZh) return "";
  const dirEn = dir
    .replace(dirZh, "")
    .replace(/(?:19|20)\d{2}/, "")
    .replace(/^[.\s]+|[.\s]+$/g, "");
  const fileEn = splitSourceName(sourceDisplayName(sourcePath)).titleEn;
  const norm = (value: string) =>
    value.toLowerCase().replace(/[^a-z0-9]+/g, "");
  const dn = norm(dirEn);
  const fn = norm(fileEn);
  if (!dn || !fn || dn.length < 8 || fn.length < 8) return "";
  const common = longestCommonPrefixLen(dn, fn);
  const shorter = Math.min(dn.length, fn.length);
  return common >= 10 && common >= shorter * 0.6 ? dirZh : "";
}

export function formatDuration(seconds: number): string {
  const total = Math.max(0, Math.round(seconds));
  return `${Math.floor(total / 3600)}:${String(Math.floor((total % 3600) / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
}
