import type { MetadataResult } from "./metadata";

export interface AuthoritativeMetadata {
  imdbId?: string | null;
  doubanId?: string | null;
  rating?: number | null;
  ratingLabel?: string;
  doubanRating?: number | null;
  rottenTomatoesRating?: number | null;
  metacriticRating?: number | null;
}

export interface AssistantMetadataSnapshot {
  identityStatus: "confirmed" | "probable" | "candidate" | "unknown";
  title?: string;
  titleEn?: string;
  year?: number;
  imdb?: { id?: string; rating?: number; votes?: number };
  tmdb?: { rating?: number; votes?: number };
  douban?: { id?: string; rating?: number };
  rottenTomatoes?: number;
  metacritic?: number;
  director?: string;
  cast?: string[];
  genres?: string;
  runtimeMinutes?: number;
  overview?: string;
  source?: string;
  sourceLabels: string[];
  /** Crew the assistant credited under its own label (缂栧墽/鎽勫奖/閰嶄箰/鍒剁墖鈥?. */
  credits?: Array<{ label: string; value: string }>;
}

function splitNames(value?: string): string[] {
  return (value ?? "")
    .split(/\s*(?:、|,|，|;|；|\\)\s*/)
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 12);
}

/** Convert provider output into the small, stable payload used by the UI and job storage. */
export function buildAssistantMetadataSnapshot(
  metadata: MetadataResult | null | undefined,
): AssistantMetadataSnapshot | null {
  if (!metadata) return null;
  const sourceLabels = new Set<string>();
  if (
    metadata.imdbId ||
    metadata.ratingSource === "imdb" ||
    metadata.source === "imdb" ||
    metadata.source === "omdb"
  )
    sourceLabels.add("IMDb");
  if (metadata.doubanId || metadata.doubanRating != null)
    sourceLabels.add("豆瓣");
  if (metadata.rottenTomatoesRating != null)
    sourceLabels.add("Rotten Tomatoes");
  if (metadata.metacriticRating != null) sourceLabels.add("Metacritic");
  if (metadata.source === "tmdb") sourceLabels.add("TMDb");
  if (metadata.source === "wikipedia") sourceLabels.add("Wikipedia");
  const imdbRating =
    metadata.ratingSource === "imdb" ||
    metadata.source === "imdb" ||
    metadata.source === "omdb"
      ? metadata.rating
      : undefined;
  const tmdbRating =
    metadata.ratingSource === "tmdb" || metadata.source === "tmdb"
      ? metadata.rating
      : undefined;
  const snapshot: AssistantMetadataSnapshot = {
    identityStatus:
      metadata.imdbId || metadata.doubanId
        ? "confirmed"
        : metadata.title
          ? "probable"
          : "unknown",
    title: metadata.title || undefined,
    titleEn: metadata.titleEn || undefined,
    year: metadata.year,
    imdb:
      metadata.imdbId ||
      metadata.ratingSource === "imdb" ||
      metadata.source === "imdb" ||
      metadata.source === "omdb"
        ? {
            id: metadata.imdbId,
            rating: imdbRating,
            votes:
              metadata.ratingSource === "imdb"
                ? metadata.ratingVotes
                : undefined,
          }
        : undefined,
    tmdb:
      tmdbRating != null
        ? { rating: tmdbRating, votes: metadata.ratingVotes }
        : undefined,
    douban:
      metadata.doubanId || metadata.doubanRating != null
        ? { id: metadata.doubanId, rating: metadata.doubanRating }
        : undefined,
    rottenTomatoes: metadata.rottenTomatoesRating,
    metacritic: metadata.metacriticRating,
    director: metadata.director,
    cast: splitNames(metadata.cast),
    genres: metadata.genres,
    runtimeMinutes: metadata.runtimeMinutes,
    overview: metadata.overview,
    source: metadata.source,
    sourceLabels: [...sourceLabels],
  };
  if (snapshot.imdb && !snapshot.imdb.id && snapshot.imdb.rating == null)
    delete snapshot.imdb;
  if (snapshot.tmdb && snapshot.tmdb.rating == null) delete snapshot.tmdb;
  if (snapshot.douban && !snapshot.douban.id && snapshot.douban.rating == null)
    delete snapshot.douban;
  if (!snapshot.cast?.length) delete snapshot.cast;
  return snapshot;
}

/** Render machine-verified identifiers after the LLM prose has been cleaned. */
export function buildAuthoritativeMetadataBlock(
  metadata: AuthoritativeMetadata,
): string {
  const lines: string[] = [];
  if (metadata.imdbId) lines.push(`IMDb：${metadata.imdbId}`);
  if (metadata.doubanId) lines.push(`豆瓣：${metadata.doubanId}`);
  if (typeof metadata.rating === "number" && metadata.rating > 0)
    lines.push(
      `${metadata.ratingLabel ?? "资料评分"}：${metadata.rating.toFixed(1)}`,
    );
  if (typeof metadata.doubanRating === "number" && metadata.doubanRating > 0)
    lines.push(`豆瓣评分：${metadata.doubanRating.toFixed(1)}`);
  if (
    typeof metadata.rottenTomatoesRating === "number" &&
    metadata.rottenTomatoesRating > 0
  )
    lines.push(`烂番茄：${metadata.rottenTomatoesRating.toFixed(0)}%`);
  if (
    typeof metadata.metacriticRating === "number" &&
    metadata.metacriticRating > 0
  )
    lines.push(`Metacritic：${metadata.metacriticRating.toFixed(0)}`);
  return lines.length > 0 ? `资料信息：\n${lines.join("\n")}` : "";
}
