import type { DiscStream } from "@workspace/api-client-react";
import { formatDate } from "@/lib/utils";
import { formatDiscBytes as fmtBytes } from "./disc-display-model";

type DiscPreviewMetric = {
  renders: number;
  totalDurationMs: number;
  lastDurationMs: number;
  lastPhase: "mount" | "update" | "nested-update";
};

type DiscPreviewInteractionMetric = {
  count: number;
  totalDurationMs: number;
  lastDurationMs: number;
};

export type DiscTitlePreviewState = {
  status: "idle" | "loading" | "ready" | "failed";
  url?: string;
  previews?: string[];
  message?: string;
  warning?: string;
};

const discPreviewMetrics: Record<string, DiscPreviewMetric> = {};
const discPreviewInteractionMetrics: Record<
  string,
  DiscPreviewInteractionMetric
> = {};

function recordDiscPreviewMetric(
  id: string,
  phase: "mount" | "update" | "nested-update",
  actualDuration: number,
) {
  const previous = discPreviewMetrics[id] ?? {
    renders: 0,
    totalDurationMs: 0,
    lastDurationMs: 0,
    lastPhase: phase,
  };
  const next = {
    renders: previous.renders + 1,
    totalDurationMs: previous.totalDurationMs + actualDuration,
    lastDurationMs: actualDuration,
    lastPhase: phase,
  } satisfies DiscPreviewMetric;
  discPreviewMetrics[id] = next;
  if (typeof window !== "undefined") {
    (
      window as Window & {
        __VX_AGENT_DISC_PREVIEW_METRICS__?: Record<string, DiscPreviewMetric>;
      }
    ).__VX_AGENT_DISC_PREVIEW_METRICS__ = discPreviewMetrics;
  }
}

export function onDiscPreviewRender(
  id: string,
  phase: "mount" | "update" | "nested-update",
  actualDuration: number,
) {
  recordDiscPreviewMetric(id, phase, actualDuration);
}

function recordDiscPreviewInteraction(id: string, durationMs: number) {
  const previous = discPreviewInteractionMetrics[id] ?? {
    count: 0,
    totalDurationMs: 0,
    lastDurationMs: 0,
  };
  const next = {
    count: previous.count + 1,
    totalDurationMs: previous.totalDurationMs + durationMs,
    lastDurationMs: durationMs,
  } satisfies DiscPreviewInteractionMetric;
  discPreviewInteractionMetrics[id] = next;
  if (typeof window !== "undefined") {
    const target = window as Window & {
      __VX_AGENT_DISC_PREVIEW_METRICS__?: Record<string, DiscPreviewMetric>;
      __VX_AGENT_DISC_PREVIEW_INTERACTIONS__?: Record<
        string,
        DiscPreviewInteractionMetric
      >;
    };
    target.__VX_AGENT_DISC_PREVIEW_INTERACTIONS__ =
      discPreviewInteractionMetrics;
  }
}

export function measureDiscPreviewInteraction(id: string, startedAt: number) {
  const finish = () =>
    recordDiscPreviewInteraction(
      id,
      Math.max(0, performance.now() - startedAt),
    );
  if (
    typeof window !== "undefined" &&
    typeof window.requestAnimationFrame === "function"
  ) {
    window.requestAnimationFrame(finish);
  } else {
    finish();
  }
}

export function streamKindLabel(
  type: DiscStream["codecType"],
  t: (key: string) => string,
) {
  if (type === "video") return t("scan.streamVideo");
  if (type === "audio") return t("scan.streamAudio");
  return t("scan.streamSubtitle");
}

export function fileHoverTitle(
  entry: {
    name: string;
    path: string;
    sizeBytes?: number;
    modifiedAt?: string;
  },
  t: (key: string) => string,
  lang: string,
): string {
  return [
    `${t("scan.fileName")}: ${entry.name}`,
    `${t("common.path")}: ${entry.path}`,
    entry.sizeBytes != null
      ? `${t("scan.fileSize")}: ${fmtBytes(entry.sizeBytes)}`
      : null,
    entry.modifiedAt
      ? `${t("scan.modifiedTime")}: ${formatDate(entry.modifiedAt, lang)}`
      : null,
  ]
    .filter(Boolean)
    .join("\n");
}
