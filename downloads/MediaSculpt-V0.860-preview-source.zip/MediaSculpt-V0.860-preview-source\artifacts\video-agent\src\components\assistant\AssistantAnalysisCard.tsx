import { Button } from "@/components/ui/button";
import { ChevronUp, Maximize2, Search, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  AssistantFactsTable,
  type AssistantFactRow,
} from "./AssistantFactsTable";

type Translate = (
  path: string,
  params?: Record<string, string | number>,
) => string;

export function AssistantAnalysisCard({
  t,
  analysisOpen,
  analysisPlacement,
  hasExistingResult,
  aiAvailable,
  analyzing,
  analysisError,
  analysisBody,
  persistedOverview,
  factsRows,
  onRetryAnalysis,
  onReadingOpen,
  onClose,
}: {
  t: Translate;
  analysisOpen: boolean;
  analysisPlacement: "inline" | "sidebar" | "video-overlay";
  hasExistingResult: boolean;
  aiAvailable: boolean;
  analyzing: boolean;
  analysisError: string | null | undefined;
  analysisBody: string;
  persistedOverview: string;
  factsRows: ReadonlyArray<AssistantFactRow>;
  onRetryAnalysis: () => void;
  onReadingOpen: () => void;
  onClose: () => void;
}) {
  if (!analysisOpen) return null;
  const factsTable = <AssistantFactsTable rows={factsRows} />;
  return (
    <div
      className={cn(
        "pointer-events-auto flex w-full flex-col overflow-hidden rounded-lg border bg-card/80 shadow-none",
        analysisPlacement === "video-overlay"
          ? "m-0 h-full max-h-full"
          : "mt-2",
      )}
      data-testid="assistant-analysis"
    >
      <div className="flex shrink-0 items-center justify-between px-2.5 py-1.5">
        <span className="flex items-center gap-1.5 text-xs font-medium text-foreground">
          <Sparkles className="h-3.5 w-3.5 text-primary" />
          {t("assistant.analysisTitle")}
        </span>
        <div className="flex items-center gap-1">
          {hasExistingResult && (
            <Button
              type="button"
              size="sm"
              variant="outline"
              className="h-6 border-amber-400/40 px-2 text-[11px] text-amber-400 hover:bg-amber-400/10 disabled:border-border/40 disabled:text-muted-foreground/40"
              onClick={onRetryAnalysis}
              disabled={!aiAvailable || analyzing}
              title={aiAvailable ? undefined : t("assistant.aiNeedsKey")}
              data-testid="assistant-retry-analysis"
            >
              <Search className="mr-1 h-3 w-3" />
              {t("assistant.retryAnalysis")}
            </Button>
          )}
          {hasExistingResult && (
            <Button
              type="button"
              size="sm"
              variant="ghost"
              className="h-6 px-2 text-[11px] text-muted-foreground hover:text-foreground"
              onClick={onReadingOpen}
              title={t("assistant.expandReading")}
              data-testid="assistant-expand-reading"
            >
              <Maximize2 className="mr-1 h-3 w-3" />
              {t("assistant.expandReading")}
            </Button>
          )}
          <Button
            type="button"
            size="icon"
            variant="ghost"
            className="h-6 w-6 text-muted-foreground hover:text-foreground"
            onClick={onClose}
            aria-label={t("assistant.hideAnalysis")}
          >
            <ChevronUp className="h-4 w-4" />
          </Button>
        </div>
      </div>
      {hasExistingResult ? (
        <div
          className={cn(
            "flex min-h-0 min-w-0 flex-1 gap-2 overflow-hidden border-t p-3",
            analysisPlacement === "sidebar"
              ? "flex-col"
              : "flex-col lg:flex-row lg:gap-3",
          )}
        >
          {/* The card carries only what the assistant toolbar does not already
              show. The toolbar owns the poster, the titles, the year and the
              IMDb input, so that rail holds scores, crew and technical facts;
              it scrolls on its own and cannot squeeze the overview. */}
          <div
            className={cn(
              "flex min-h-0 min-w-0 shrink-0 flex-col gap-2 text-xs leading-relaxed",
              analysisPlacement !== "sidebar" &&
                "max-h-[45%] overflow-y-auto overscroll-contain lg:h-full lg:max-h-none lg:w-[17rem]",
            )}
            data-testid="assistant-facts-rail"
          >
            {factsTable}
          </div>
          {/* Reading column: takes the remaining width and the full height. */}
          <div className="flex min-h-0 min-w-0 flex-1 flex-col gap-1">
            <span className="text-xs font-medium text-foreground/80">
              {t("assistant.overviewLabel")}
            </span>
            <div
              className={cn(
                "rounded-md border border-border/60 bg-background/50 p-2 text-xs leading-relaxed text-muted-foreground",
                analysisPlacement !== "sidebar" &&
                  "min-h-0 flex-1 overflow-y-auto overscroll-contain pr-3",
              )}
            >
              <div className="max-w-[68ch] whitespace-pre-wrap">
                {analysisBody || persistedOverview}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="border-t px-3 py-2 text-xs text-muted-foreground">
          {t("assistant.analysisEmpty")}
        </div>
      )}
      {analysisError && (
        <div
          className="border-t px-3 py-2 text-xs text-destructive"
          data-testid="assistant-analysis-error"
        >
          {analysisError}
        </div>
      )}
    </div>
  );
}
