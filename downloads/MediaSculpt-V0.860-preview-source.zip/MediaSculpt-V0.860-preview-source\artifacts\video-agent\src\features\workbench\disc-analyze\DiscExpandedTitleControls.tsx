import { Profiler } from "react";
import type { DiscStream } from "@workspace/api-client-react";
import type { ProcessingMode } from "@/hooks/useWorkbenchState";
import type { ScanCopy } from "@/pages/Scan";
import { onDiscPreviewRender } from "@/pages/Scan";
import type { DiscTrackWithMakeMkv } from "../disc-display-model";
import { DiscChapterControls } from "./DiscChapterControls";
import { DiscStreamControls } from "./DiscStreamControls";

export type DiscExpandedTitleControlsProps = {
  uiText: ScanCopy;
  selectedTrack: DiscTrackWithMakeMkv | undefined;
  activeTrackIdx: number;
  verifying: boolean;
  selectableStreams: DiscStream[];
  selectedStreamIndices: Set<number>;
  selectedTitleCount: number;
  selectedChapterIds: Set<number>;
  discType: "dvd" | "bluray";
  processingMode: ProcessingMode;
  verifyDvdTitles: boolean;
  processingMappingBlocked: boolean;
  onToggleStream: (index: number) => void;
  onSetAllStreams: (selected: boolean) => void;
  onToggleChapter: (id: number) => void;
  onSetAllChapters: (selected: boolean) => void;
  onRequestReverification: (idx: number) => void;
  onSelectMode?: (mode: ProcessingMode) => void;
};

export function DiscExpandedTitleControls({
  uiText,
  selectedTrack,
  activeTrackIdx,
  verifying,
  selectableStreams,
  selectedStreamIndices,
  selectedTitleCount,
  selectedChapterIds,
  discType,
  processingMode,
  verifyDvdTitles,
  processingMappingBlocked,
  onToggleStream,
  onSetAllStreams,
  onToggleChapter,
  onSetAllChapters,
  onRequestReverification,
  onSelectMode,
}: DiscExpandedTitleControlsProps) {
  if (!selectedTrack) return null;
  if (selectedTrack.streams.length === 0) {
    return (
      <div className="mt-2 rounded-lg border bg-secondary/10 px-3 py-3 text-sm text-muted-foreground">
        {uiText.noStreams}
      </div>
    );
  }
  return (
    <Profiler
      id="StreamSelectionPanel"
      onRender={(id, phase, actualDuration) =>
        onDiscPreviewRender(id, phase, actualDuration)
      }
    >
      <div
        className="mt-2 space-y-3 rounded-lg border bg-background/55 p-3"
        onPointerDown={(event) => event.stopPropagation()}
        onClick={(event) => event.stopPropagation()}
      >
        <DiscStreamControls
          uiText={uiText}
          selectedTrack={selectedTrack}
          activeTrackIdx={activeTrackIdx}
          verifying={verifying}
          selectableStreams={selectableStreams}
          selectedStreamIndices={selectedStreamIndices}
          selectedTitleCount={selectedTitleCount}
          discType={discType}
          processingMode={processingMode}
          verifyDvdTitles={verifyDvdTitles}
          processingMappingBlocked={processingMappingBlocked}
          onToggleStream={onToggleStream}
          onSetAllStreams={onSetAllStreams}
          onRequestReverification={onRequestReverification}
          onSelectMode={onSelectMode}
        />
        {(selectedTrack.chapters?.length ?? 0) > 0 ? (
          <DiscChapterControls
            uiText={uiText}
            selectedTrack={selectedTrack}
            verifying={verifying}
            selectedChapterIds={selectedChapterIds}
            onToggleChapter={onToggleChapter}
            onSetAllChapters={onSetAllChapters}
          />
        ) : (
          <div className="rounded-lg border border-yellow-500/25 bg-yellow-500/5 px-3 py-2 text-sm text-muted-foreground">
            <p className="font-medium text-foreground">{uiText.noChapters}</p>
            <p className="mt-1 text-xs">{uiText.noChaptersHint}</p>
          </div>
        )}
      </div>
    </Profiler>
  );
}
