export const SEGMENT_WAIT_ATTEMPTS = 200;
export const SEGMENT_WAIT_INTERVAL_MS = 600;

export type SegmentReadyState = "segment" | "legacy" | "not-found" | "timeout";

export type SegmentWaitOptions = {
  /** Injectable for tests; production uses the global fetch. */
  fetchImpl?: typeof fetch;
  attempts?: number;
  intervalMs?: number;
  sleep?: (ms: number) => Promise<void>;
};

/**
 * 轮询等待片段就绪（后端 425=转码中）。
 *
 * 返回 "timeout" 表示等待预算耗尽或请求被取消——此时片段并未就绪，不能当作
 * "segment"：那会让调用方把未就绪的 URL 交给 <video>，而 <video> 会以一个
 * 误导性的媒体格式错误（MEDIA_ERR_SRC_NOT_SUPPORTED，"错误码 4"）失败，尽管
 * 源文件完全可以处理。服务端单段转码上限为 90 秒（preview-segments.ts
 * timeoutMs），所以客户端预算必须显著大于它。
 */
export async function waitForSegmentReady(
  url: string,
  signal: AbortSignal,
  options: SegmentWaitOptions = {},
): Promise<SegmentReadyState> {
  const doFetch = options.fetchImpl ?? fetch;
  const attempts = options.attempts ?? SEGMENT_WAIT_ATTEMPTS;
  const intervalMs = options.intervalMs ?? SEGMENT_WAIT_INTERVAL_MS;
  const sleep =
    options.sleep ??
    ((ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms)));

  for (let attempt = 0; attempt < attempts; attempt += 1) {
    if (signal.aborted) return "timeout";
    try {
      const response = await doFetch(url, {
        headers: { Range: "bytes=0-0" },
        signal,
      });
      if (response.status === 404) {
        // 片段不存在（通常已到视频结尾）：停止等待，优雅停在当前画面。
        await response.body?.cancel().catch(() => {});
        return "not-found";
      }
      if (response.status === 206 || response.status === 200) {
        const mode = response.headers.get("X-Preview-Mode");
        await response.body?.cancel().catch(() => {});
        return mode === "segment" ? "segment" : "legacy";
      }
      await response.body?.cancel().catch(() => {});
    } catch {
      // 网络瞬时错误，稍后重试。
      if (signal.aborted) return "timeout";
    }
    await sleep(intervalMs);
  }
  return "timeout";
}
