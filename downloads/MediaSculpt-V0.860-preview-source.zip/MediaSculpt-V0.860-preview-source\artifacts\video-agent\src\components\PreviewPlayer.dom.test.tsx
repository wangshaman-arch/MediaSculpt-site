// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { act, cleanup, render, screen } from "@testing-library/react";
import { I18nProvider } from "@/i18n";
import { PreviewPlayer } from "./PreviewPlayer";

beforeEach(() => {
  vi.stubGlobal(
    "fetch",
    vi.fn(async () => ({
      ok: true,
      status: 200,
      json: async () => ({ durationSeconds: 0 }),
    })),
  );
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

type PlayerProps = Parameters<typeof PreviewPlayer>[0];

function renderPlayer(overrides: Partial<PlayerProps> = {}) {
  return render(
    <I18nProvider lang="zh-CN">
      <PreviewPlayer
        src="/api/jobs/1/preview"
        metaUrl="/api/jobs/1/preview/meta"
        {...overrides}
      />
    </I18nProvider>,
  );
}

function stageAspectRatio(): string | undefined {
  const stage = screen.getByTestId("preview-stage");
  return (stage.style as CSSStyleDeclaration & { aspectRatio?: string })
    .aspectRatio;
}

describe("PreviewPlayer stage scaling", () => {
  it("falls back to a 16:9 stage and object-contain video when no metadata is available", async () => {
    renderPlayer();
    await act(async () => {});

    const stage = screen.getByTestId("preview-stage");
    expect(stageAspectRatio()).toBe("16 / 9");
    expect(stage).toHaveClass(
      "min-h-[260px]",
      "w-full",
      "overflow-hidden",
      "items-center",
      "justify-center",
      "bg-black",
    );

    const video = stage.querySelector("video");
    expect(video).not.toBeNull();
    expect(video).toHaveClass("object-contain", "h-full", "w-full", "bg-black");
    expect(screen.getByTestId("preview-control-overlay")).toBeInTheDocument();
  });

  it("honours an explicit aspect ratio without crashing when metadata is missing", async () => {
    renderPlayer({ style: { aspectRatio: "4 / 3" } });
    await act(async () => {});

    expect(stageAspectRatio()).toBe("4 / 3");
    expect(screen.getByTestId("preview-stage")).toHaveClass(
      "relative",
      "rounded-lg",
      "border",
    );
  });
});
