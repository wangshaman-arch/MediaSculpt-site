export type HandBrakeSelectionPlan = {
  version: 1;
  video: number[];
  audio: number[];
  subtitle: number[];
  chapters: number[];
  handbrake?: {
    titleNumber?: number | null;
    titleSizeBytes?: number | null;
    durationSeconds?: number | null;
    audioTrackNumbers?: number[];
    subtitleTrackNumbers?: number[];
    chapterNumbers?: number[];
  };
};

function numericArray(value: unknown): number[] | null {
  if (!Array.isArray(value)) return null;
  return value
    .map((item) => Number(item))
    .filter((item) => Number.isInteger(item) && item >= 0);
}

function positiveNumericArray(value: unknown): number[] {
  return Array.from(
    new Set((numericArray(value) ?? []).filter((item) => item > 0)),
  ).sort((a, b) => a - b);
}

export function parseHandBrakeSelectionPlan(
  raw: string | null | undefined,
): HandBrakeSelectionPlan | null {
  if (!raw) return null;
  try {
    const value = JSON.parse(raw) as Record<string, unknown>;
    if (value.version !== 1) return null;
    const video = numericArray(value.video);
    const audio = numericArray(value.audio);
    const subtitle = numericArray(value.subtitle);
    const chapters = numericArray(value.chapters);
    if (!video || !audio || !subtitle || !chapters) return null;
    const handbrake = value.handbrake as
      | Record<string, unknown>
      | null
      | undefined;
    return {
      version: 1,
      video,
      audio,
      subtitle,
      chapters,
      handbrake: handbrake
        ? {
            titleNumber:
              typeof handbrake.titleNumber === "number" &&
              handbrake.titleNumber > 0
                ? handbrake.titleNumber
                : null,
            titleSizeBytes:
              typeof handbrake.titleSizeBytes === "number" &&
              handbrake.titleSizeBytes > 0
                ? handbrake.titleSizeBytes
                : null,
            durationSeconds:
              typeof handbrake.durationSeconds === "number" &&
              handbrake.durationSeconds > 0
                ? handbrake.durationSeconds
                : null,
            audioTrackNumbers: positiveNumericArray(
              handbrake.audioTrackNumbers,
            ),
            subtitleTrackNumbers: positiveNumericArray(
              handbrake.subtitleTrackNumbers,
            ),
            chapterNumbers: positiveNumericArray(handbrake.chapterNumbers),
          }
        : undefined,
    };
  } catch {
    return null;
  }
}

function compactChapterRange(chapters: number[]): string {
  const sorted = Array.from(
    new Set(chapters.filter((chapter) => chapter > 0)),
  ).sort((a, b) => a - b);
  if (sorted.length === 0) return "";
  const ranges: string[] = [];
  let start = sorted[0];
  let previous = sorted[0];
  for (const chapter of sorted.slice(1)) {
    if (chapter === previous + 1) {
      previous = chapter;
      continue;
    }
    ranges.push(start === previous ? String(start) : `${start}-${previous}`);
    start = previous = chapter;
  }
  ranges.push(start === previous ? String(start) : `${start}-${previous}`);
  return ranges.join(",");
}

export function buildHandBrakeSelectionArgs(
  plan: HandBrakeSelectionPlan | null,
  options: { audioCopy: boolean },
): string[] {
  const args: string[] = [];
  const handbrake = plan?.handbrake;
  if (!handbrake) return args;

  if (handbrake.titleNumber && handbrake.titleNumber > 0) {
    args.push("--title", String(handbrake.titleNumber));
  }

  // The user's selection (`plan.audio` / `plan.subtitle`) is the intent; the
  // HandBrake track numbers are only the tool mapping. They can disagree: a
  // selected stream keeps no `handbrakeTrackNumber` when the scan did not
  // report one. Deciding on the mapping alone silently dropped those tracks —
  // an empty mapping forced `--subtitle none` and let HandBrake pick its own
  // audio default. Decide on the intent instead, and fall back to "keep all"
  // when the intent is non-empty but no mapping could be produced.
  if (Array.isArray(handbrake.audioTrackNumbers)) {
    if (handbrake.audioTrackNumbers.length > 0) {
      args.push("--audio", handbrake.audioTrackNumbers.join(","));
      const encoder = options.audioCopy ? "copy" : "av_aac";
      args.push(
        "--aencoder",
        handbrake.audioTrackNumbers.map(() => encoder).join(","),
      );
    } else if (plan.audio.length === 0) {
      args.push("--audio", "none");
    } else {
      args.push("--all-audio");
    }
  }

  if (Array.isArray(handbrake.subtitleTrackNumbers)) {
    if (handbrake.subtitleTrackNumbers.length > 0) {
      args.push("--subtitle", handbrake.subtitleTrackNumbers.join(","));
    } else if (plan.subtitle.length === 0) {
      args.push("--subtitle", "none");
    } else {
      args.push("--all-subtitles");
    }
  }

  if (Array.isArray(handbrake.chapterNumbers)) {
    const range = compactChapterRange(handbrake.chapterNumbers);
    if (range) args.push("--chapters", range, "--markers");
  }

  return args;
}
