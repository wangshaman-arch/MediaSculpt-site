import { describe, expect, it } from "vitest";
import { DEFAULT_BILINGUAL_STYLE } from "../lib/bilingual-subtitle";
import { buildJobExecutionContext } from "./job-execution-context";

describe("job execution context", () => {
  it("derives ordered pipeline flags from the persisted job payload", () => {
    const context = buildJobExecutionContext({
      job: {
        pipelineSteps: JSON.stringify({
          steps: ["compress", "remux", "compress", "subtitle"],
          names: { remux: "保存版.mkv", compress: "压缩版.mkv" },
        }),
        subtitleMode: "skip",
        selectionPlan: null,
      },
      config: {},
    });

    expect(context.pipelineSteps).toEqual(["compress", "remux", "subtitle"]);
    expect(context.pipelineRemuxIndex).toBe(1);
    expect(context.pipelineSubtitleIndex).toBe(2);
    expect(context.pipelineCompressIndex).toBe(0);
    expect(context.pipelineHasRemux).toBe(true);
    expect(context.pipelineHasSubtitle).toBe(true);
    expect(context.pipelineHasCompress).toBe(true);
    expect(context.pipelineContinuesAfterRemux).toBe(true);
    expect(context.pipelineNames).toEqual({
      remux: "保存版.mkv",
      compress: "压缩版.mkv",
    });
  });

  it("normalizes bilingual processing to automatic source subtitle discovery", () => {
    const context = buildJobExecutionContext({
      job: {
        pipelineSteps: null,
        subtitleMode: "bilingual",
        selectionPlan: JSON.stringify({ bilingualLayout: "foreign-top" }),
      },
      config: {},
    });

    expect(context.isBilingual).toBe(true);
    expect(context.subtitleMode).toBe("auto");
    expect(context.selectionPlanOptions).toEqual({
      bilingualLayout: "foreign-top",
    });
    expect(context.bilingualStyle.layout).toBe("foreign-top");
  });

  it("uses configured bilingual style and ignores malformed selection plans", () => {
    const context = buildJobExecutionContext({
      job: {
        pipelineSteps: null,
        subtitleMode: "auto",
        selectionPlan: "not-json",
      },
      config: {
        bilingualLayout: "zh-top",
        bilingualOutlineWidth: 3,
        bilingualShadowWidth: 2,
        bilingualOutlineColor: "&H00FFFFFF",
        bilingualFontSizeTop: 42,
        bilingualFontSizeBottom: 21,
      },
    });

    expect(context.isBilingual).toBe(false);
    expect(context.subtitleMode).toBe("auto");
    expect(context.selectionPlanOptions).toEqual({});
    expect(context.bilingualStyle).toEqual({
      ...DEFAULT_BILINGUAL_STYLE,
      layout: "zh-top",
      outlineWidth: 3,
      shadowWidth: 2,
      outlineColor: "&H00FFFFFF",
      fontSizeTop: 42,
      fontSizeBottom: 21,
    });
  });
});
