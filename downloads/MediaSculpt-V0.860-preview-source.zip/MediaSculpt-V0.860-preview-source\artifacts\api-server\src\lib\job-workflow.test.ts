import path from "path";
import { describe, expect, it } from "vitest";
import {
  buildSequentialJobPlan,
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  hasExecutableWorkflowSelection,
  requiresWorkflowSelection,
  shouldUseVerifiedDvdRemux,
  shouldStartJobNow,
} from "./job-workflow";

describe("job workflow rules", () => {
  it("uses the directory containing the DVD or Blu-ray folder as the default remux output directory", () => {
    expect(
      defaultRemuxOutputDirectory(
        path.join("D:", "Movies", "Film", "VIDEO_TS"),
        "dvd",
      ),
    ).toBe(path.join("D:", "Movies", "Film"));
    expect(
      defaultRemuxOutputDirectory(
        path.join("D:", "Movies", "Film", "BDMV"),
        "bluray",
      ),
    ).toBe(path.join("D:", "Movies", "Film"));
    expect(
      defaultRemuxOutputDirectory(
        path.join("D:", "Movies", "Film", "VIDEO_TS", "VTS_01_0.IFO"),
        "dvd",
      ),
    ).toBe(path.join("D:", "Movies", "Film"));
    expect(
      defaultRemuxOutputDirectory(
        path.join("D:", "Movies", "Film", "BDMV", "PLAYLIST", "00001.mpls"),
        "bluray",
      ),
    ).toBe(path.join("D:", "Movies", "Film"));
    expect(
      defaultRemuxOutputDirectory(
        path.join("D:", "Movies", "Film", "BDMV", "index.bdmv"),
        "bluray",
      ),
    ).toBe(path.join("D:", "Movies", "Film"));
    expect(
      defaultRemuxOutputDirectory(
        path.join("D:", "Movies", "Film", "BDMV", "STREAM", "00001.m2ts"),
        "bluray",
      ),
    ).toBe(path.join("D:", "Movies", "Film"));
    expect(
      defaultRemuxOutputDirectory(path.join("D:", "Movies", "Film"), "dvd"),
    ).toBe(path.join("D:", "Movies", "Film"));
    expect(
      defaultRemuxOutputDirectory(
        path.join("D:", "Movies", "Film.mkv"),
        "video",
      ),
    ).toBe(path.join("D:", "Movies"));
    expect(
      defaultRemuxOutputDirectory(
        "H:\\National.Ballet.of.Canada.James.Kudelka.2003.Blu-ray.1080i.AVC.LPCM.2.0",
        "bluray",
      ),
    ).toBe(
      "H:\\National.Ballet.of.Canada.James.Kudelka.2003.Blu-ray.1080i.AVC.LPCM.2.0",
    );
    expect(
      defaultRemuxOutputDirectory(
        "H:\\Movies\\Movie.2003.1080p.BluRay.x264",
        "bluray",
      ),
    ).toBe("H:\\Movies\\Movie.2003.1080p.BluRay.x264");
  });

  it("keeps Windows DVD remux output beside the DVD folder instead of inside VIDEO_TS or the DVD root", () => {
    expect(defaultRemuxOutputDirectory("D:\\", "dvd")).toBe("D:\\");
    expect(defaultRemuxOutputDirectory("D:\\MOVIE\\", "dvd")).toBe("D:\\MOVIE");
    expect(defaultRemuxOutputDirectory("D:\\MOVIE\\VIDEO_TS\\", "dvd")).toBe(
      "D:\\MOVIE",
    );
    expect(
      defaultRemuxOutputDirectory("D:\\MOVIE\\VIDEO_TS\\VTS_01_0.IFO", "dvd"),
    ).toBe("D:\\MOVIE");
  });

  it("keeps disc compression as direct HandBrake compression instead of remuxing first", () => {
    expect(
      buildSequentialJobPlan({
        mediaType: "dvd",
        processingMode: "compress",
      }).map((step) => step.processingMode),
    ).toEqual(["compress"]);
    expect(
      buildSequentialJobPlan({
        mediaType: "bluray",
        processingMode: "compress",
      }).map((step) => step.processingMode),
    ).toEqual(["compress"]);
    expect(
      buildSequentialJobPlan({
        mediaType: "video",
        processingMode: "compress",
      }).map((step) => step.processingMode),
    ).toEqual(["compress"]);
    expect(
      buildSequentialJobPlan({ mediaType: "dvd", processingMode: "remux" }).map(
        (step) => step.processingMode,
      ),
    ).toEqual(["remux"]);
  });

  it("maps tool progress from zero rather than starting at thirty percent", () => {
    expect(mapExternalToolProgress({ toolPercent: 0, start: 0, end: 95 })).toBe(
      0,
    );
    expect(
      mapExternalToolProgress({ toolPercent: 50, start: 0, end: 95 }),
    ).toBe(47.5);
    expect(
      mapExternalToolProgress({ toolPercent: 100, start: 0, end: 95 }),
    ).toBe(95);
  });

  it("allows only one running queue job at a time", () => {
    expect(shouldStartJobNow([])).toBe(true);
    expect(shouldStartJobNow(["pending", "done", "error"])).toBe(true);
    expect(shouldStartJobNow(["compressing"])).toBe(false);
    expect(shouldStartJobNow(["transcribing"])).toBe(false);
    expect(shouldStartJobNow(["scanning"])).toBe(false);
    expect(shouldStartJobNow(["remuxing"])).toBe(false);
  });

  it("keeps requested disc compression as compression for direct HandBrake analysis", () => {
    expect(
      normalizeRequestedProcessingMode({
        mediaType: "dvd",
        processingMode: "compress",
      }),
    ).toBe("compress");
    expect(
      normalizeRequestedProcessingMode({
        mediaType: "bluray",
        processingMode: "compress",
      }),
    ).toBe("compress");
    expect(
      normalizeRequestedProcessingMode({
        mediaType: "video",
        processingMode: "compress",
      }),
    ).toBe("compress");
  });

  it("blocks a smart-workflow draft until the user chooses its processing options", () => {
    expect(
      requiresWorkflowSelection(
        '{"workflow":"smart-workflow-v1","needsUserSelection":true}',
      ),
    ).toBe(true);
    expect(requiresWorkflowSelection('{"workflow":"smart-workflow-v1"}')).toBe(
      false,
    );
    expect(requiresWorkflowSelection(null)).toBe(false);
  });

  it("rejects an empty media task when subtitles are explicitly skipped", () => {
    expect(
      hasExecutableWorkflowSelection({
        processingMode: "none",
        subtitleMode: "skip",
        outputMode: "subtitle",
      }),
    ).toBe(false);
    expect(
      hasExecutableWorkflowSelection({
        processingMode: "none",
        subtitleMode: "skip",
        outputMode: "whisper",
      }),
    ).toBe(false);
  });

  it("recognizes a real media or subtitle step as executable", () => {
    expect(
      hasExecutableWorkflowSelection({
        processingMode: "remux",
        subtitleMode: "skip",
        outputMode: "remux",
      }),
    ).toBe(true);
    expect(
      hasExecutableWorkflowSelection({
        processingMode: "none",
        subtitleMode: "auto",
        outputMode: "subtitle",
      }),
    ).toBe(true);
    expect(
      hasExecutableWorkflowSelection({
        processingMode: "none",
        subtitleMode: "skip",
        outputMode: "compress",
      }),
    ).toBe(true);
  });

  it("keeps a DVD remux-only pipeline on the verified remux executor", () => {
    expect(
      shouldUseVerifiedDvdRemux({
        mediaType: "dvd",
        processingMode: "remux",
        pipelineHasRemux: true,
        pipelineHasCompress: false,
        pipelineContinuesAfterRemux: false,
      }),
    ).toBe(true);
    expect(
      shouldUseVerifiedDvdRemux({
        mediaType: "dvd",
        processingMode: "remux",
        pipelineHasRemux: true,
        pipelineHasCompress: true,
        pipelineContinuesAfterRemux: true,
      }),
    ).toBe(false);
    expect(
      shouldUseVerifiedDvdRemux({
        mediaType: "bluray",
        processingMode: "remux",
        pipelineHasRemux: true,
        pipelineHasCompress: false,
        pipelineContinuesAfterRemux: false,
      }),
    ).toBe(false);
  });
});
