import { describe, expect, it } from "vitest";
import type { DiscStream } from "@workspace/api-client-react";
import {
  buildDiscSelectionPlan,
  discOutputMode,
  hasRunningRemuxDuplicate,
} from "./disc-create-model";
import type { DiscTrackWithMakeMkv } from "./disc-display-model";

const stream = (overrides: Partial<DiscStream>): DiscStream => ({
  index: 0,
  codecType: "audio",
  codecName: "aac",
  ...overrides,
});

const track = (
  overrides: Partial<DiscTrackWithMakeMkv> = {},
): DiscTrackWithMakeMkv => ({
  path: "D:/disc/VIDEO_TS",
  name: "Title 1",
  sizeBytes: 2_000_000,
  titleId: "vts-1",
  titleIndex: 1,
  handbrakeTitleNumber: 1,
  streams: [
    stream({ index: 0, codecType: "video", codecName: "h264" }),
    stream({
      index: 1,
      codecType: "audio",
      codecName: "aac",
      handbrakeTrackNumber: 1,
    }),
    stream({
      index: 2,
      codecType: "subtitle",
      codecName: "sub",
      handbrakeTrackNumber: 2,
    }),
  ],
  chapters: [
    { id: 0, startSeconds: 0, endSeconds: 10 },
    { id: 1, startSeconds: 10, endSeconds: 20 },
  ],
  ...overrides,
});

describe("disc create model", () => {
  it("maps processing and subtitle modes to the executor output mode", () => {
    expect(discOutputMode("remux", "skip")).toBe("remux");
    expect(discOutputMode("compress", "skip")).toBe("compress");
    expect(discOutputMode("none", "whisper")).toBe("whisper");
    expect(discOutputMode("none", "transcribe_translate")).toBe("whisper");
    expect(discOutputMode("none", "auto")).toBe("subtitle");
  });

  it("builds the selection plan from the chosen streams and chapters", () => {
    const plan = JSON.parse(
      buildDiscSelectionPlan({
        track: track(),
        streamSet: new Set([0, 1]),
        chapterIds: [0, 1],
        smartManifestId: "manifest-1",
        analysisId: "analysis-1",
      }),
    );
    expect(plan).toMatchObject({
      version: 1,
      smartManifestId: "manifest-1",
      analysis: {
        analysisId: "analysis-1",
        titleId: "vts-1",
        titleIndex: 1,
        mappingStatus: "not-required",
      },
      video: [0],
      audio: [1],
      subtitle: [],
      chapters: [0, 1],
      dvdvideo: { titleNumber: null, verified: false },
      analyzer: "unified",
    });
    expect(plan.handbrake).toMatchObject({
      titleNumber: 1,
      titleSizeBytes: 2_000_000,
      audioTrackNumbers: [1],
      subtitleTrackNumbers: [],
      chapterNumbers: [1, 2],
    });
  });

  it("detects an in-flight remux job for the same title and path", () => {
    const jobs = [
      {
        status: "compressing",
        processingMode: "remux",
        taskSnapshot: JSON.stringify({
          selectedTitleId: "vts-1",
          sourcePath: "D:\\disc\\VIDEO_TS",
        }),
      },
    ];
    expect(hasRunningRemuxDuplicate(jobs, track())).toBe(true);
    expect(hasRunningRemuxDuplicate(jobs, track({ titleId: "vts-2" }))).toBe(
      false,
    );
    expect(
      hasRunningRemuxDuplicate(
        [{ status: "done", processingMode: "remux", taskSnapshot: "{}" }],
        track(),
      ),
    ).toBe(false);
    expect(hasRunningRemuxDuplicate(undefined, track())).toBe(false);
  });
});
