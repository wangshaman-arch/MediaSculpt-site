import type {
  ProcessingMode,
  SubtitleMode,
} from "../../hooks/useWorkbenchState";

export type DiscJobOutputMode = "compress" | "remux" | "subtitle" | "whisper";

export function requiresExplicitDiscProcessingMode(input: {
  processingMode: ProcessingMode;
  subtitleMode: SubtitleMode;
}): boolean {
  return input.processingMode === "none" && input.subtitleMode === "skip";
}

export function canCreateDiscJobsWithMode(input: {
  processingMode: ProcessingMode;
  subtitleMode: SubtitleMode;
  selectedTitleCount: number;
}): boolean {
  return (
    input.selectedTitleCount > 0 && !requiresExplicitDiscProcessingMode(input)
  );
}

export function resolveDiscCreateIndices(
  selectedIndexes: Set<number>,
  activeIndex: number,
): number[] {
  if (selectedIndexes.size > 0) return Array.from(selectedIndexes);
  return activeIndex >= 0 ? [activeIndex] : [];
}

export function setDiscTitleSelection(
  selectedIndexes: Set<number>,
  index: number,
  selected: boolean,
): Set<number> {
  const next = new Set(selectedIndexes);
  if (selected) next.add(index);
  else next.delete(index);
  if (next.size === 0) next.add(index);
  return next;
}

export function selectableDiscTitleIndices(
  tracks: Array<{
    availabilityStatus?: string | null;
    streams?: Array<{ codecType: string }>;
  }>,
  visibleIndices: Iterable<number>,
): number[] {
  const visible = new Set(visibleIndices);
  return tracks.flatMap((track, index) =>
    visible.has(index) &&
    track.availabilityStatus !== "unavailable" &&
    (track.streams === undefined ||
      track.streams.some((stream) => stream.codecType === "video"))
      ? [index]
      : [],
  );
}

export function assessDiscRemuxCapacity(input: {
  sourceBytes: number | null | undefined;
  tracks: Array<{
    sizeBytes?: number | null;
    physicalVtsNumber?: number | null;
    physicalRanges?: Array<{
      path: string;
      startByte: number;
      endByte: number;
    }>;
  }>;
  selectedIndexes: Iterable<number>;
}): {
  blocked: boolean;
  estimatedBytes: number;
  summedTitleBytes: number;
  overlapBytes: number;
  hasOverlap: boolean;
  unknownCount: number;
  sourceBytes: number | null;
} {
  const selected = Array.from(new Set(input.selectedIndexes));
  let estimatedBytes = 0;
  let summedTitleBytes = 0;
  let unknownCount = 0;
  const selectedTracks = selected.map((index) => input.tracks[index]);
  const hasCompleteRanges = selectedTracks.every(
    (track) => (track?.physicalRanges?.length ?? 0) > 0,
  );
  const rangesByPath = new Map<
    string,
    Array<{ startByte: number; endByte: number }>
  >();
  for (const index of selected) {
    const track = input.tracks[index];
    const value = track?.sizeBytes;
    if (typeof value !== "number" || !Number.isFinite(value) || value <= 0) {
      unknownCount += 1;
      continue;
    }
    summedTitleBytes += value;
    if (!hasCompleteRanges) estimatedBytes += value;
    for (const range of track?.physicalRanges ?? []) {
      if (
        !Number.isFinite(range.startByte) ||
        !Number.isFinite(range.endByte) ||
        range.endByte <= range.startByte
      )
        continue;
      const ranges = rangesByPath.get(range.path) ?? [];
      ranges.push({ startByte: range.startByte, endByte: range.endByte });
      rangesByPath.set(range.path, ranges);
    }
  }
  if (hasCompleteRanges) {
    estimatedBytes = 0;
    for (const ranges of rangesByPath.values()) {
      ranges.sort((left, right) => left.startByte - right.startByte);
      let start = ranges[0]?.startByte;
      let end = ranges[0]?.endByte;
      for (const range of ranges.slice(1)) {
        if (start == null || end == null) break;
        if (range.startByte <= end) end = Math.max(end, range.endByte);
        else {
          estimatedBytes += end - start;
          start = range.startByte;
          end = range.endByte;
        }
      }
      if (start != null && end != null) estimatedBytes += end - start;
    }
  }
  const sourceBytes =
    typeof input.sourceBytes === "number" &&
    Number.isFinite(input.sourceBytes) &&
    input.sourceBytes > 0
      ? input.sourceBytes
      : null;
  const blocked =
    (sourceBytes !== null && estimatedBytes > sourceBytes) ||
    (selected.length > 1 && (unknownCount > 0 || sourceBytes === null));
  const overlapBytes = hasCompleteRanges
    ? Math.max(0, summedTitleBytes - estimatedBytes)
    : 0;
  return {
    blocked,
    estimatedBytes,
    summedTitleBytes,
    overlapBytes,
    hasOverlap: overlapBytes > 0,
    unknownCount,
    sourceBytes,
  };
}

/**
 * When DVD verification enriches a title with FFprobe-only streams, add those
 * streams to the existing selection without reselecting streams the user
 * already turned off. This avoids losing non-Japanese subtitles when the
 * verification pass replaces the initial HandBrake stream list.
 */
export function mergeNewlyDiscoveredDiscStreams(input: {
  selectedIndexes: Iterable<number>;
  previouslyKnownIndexes: Iterable<number>;
  verifiedIndexes: Iterable<number>;
}): Set<number> {
  const selected = new Set(input.selectedIndexes);
  const known = new Set(input.previouslyKnownIndexes);
  for (const index of input.verifiedIndexes) {
    if (!known.has(index)) selected.add(index);
  }
  return selected;
}

export function countSelectedDiscSubtitleStreams(
  streams: Array<{ index: number; codecType: string }>,
  selectedIndexes: Iterable<number>,
): { available: number; selected: number } {
  const selected = new Set(selectedIndexes);
  const subtitles = streams.filter((stream) => stream.codecType === "subtitle");
  return {
    available: subtitles.length,
    selected: subtitles.filter((stream) => selected.has(stream.index)).length,
  };
}

type DiscTitleCandidate = {
  sizeBytes?: number | null;
  durationSeconds?: number | null;
  streams?: Array<{ codecType: string }>;
  physicalVtsNumber?: number | null;
  physicalRanges?: Array<{ path: string; startByte: number; endByte: number }>;
  availabilityStatus?: string | null;
  verificationStatus?: string | null;
};

export function isClearlyInvalidDiscTrack(track: DiscTitleCandidate): boolean {
  return (
    track.availabilityStatus === "unavailable" ||
    track.verificationStatus === "failed" ||
    !track.streams?.some((stream) => stream.codecType === "video") ||
    typeof track.durationSeconds !== "number" ||
    !Number.isFinite(track.durationSeconds) ||
    track.durationSeconds <= 0
  );
}

export function selectCapacitySafeDiscTitles<T extends DiscTitleCandidate>(
  tracks: T[],
  candidateIndexes: Iterable<number>,
  sourceBytes: number | null | undefined,
): number[] {
  const selected: number[] = [];
  const candidates = Array.from(new Set(candidateIndexes)).filter(
    (index) => tracks[index] && !isClearlyInvalidDiscTrack(tracks[index]),
  );
  for (const index of candidates) {
    const next = [...selected, index];
    if (
      assessDiscRemuxCapacity({
        sourceBytes,
        tracks,
        selectedIndexes: next,
      }).blocked
    )
      continue;
    selected.push(index);
  }
  return selected;
}

export function hasExecutableDiscStreamSelection(
  streams: Array<{ index: number; codecType: string }>,
  selectedIndexes: Iterable<number>,
): boolean {
  const selected = new Set(selectedIndexes);
  const videoIndexes = streams
    .filter((stream) => stream.codecType === "video")
    .map((stream) => stream.index);
  // An empty selection is intentional: the API interprets it as “all streams”.
  // A non-empty selection must still contain a video stream to be executable.
  return selected.size === 0
    ? videoIndexes.length > 0
    : videoIndexes.some((index) => selected.has(index));
}

export function resolveDiscJobModes(input: {
  processingMode: ProcessingMode;
  subtitleMode: SubtitleMode;
}): {
  processingMode: ProcessingMode;
  subtitleMode: SubtitleMode;
  outputMode: DiscJobOutputMode;
} {
  if (input.processingMode === "compress" || input.processingMode === "remux") {
    return {
      processingMode: input.processingMode,
      // The subtitle selector belongs to subtitle-only mode. It must not
      // override a DVD video action or leak from a previous tab selection.
      subtitleMode: "skip",
      outputMode: input.processingMode,
    };
  }
  return {
    processingMode: "none",
    subtitleMode: input.subtitleMode,
    outputMode:
      input.subtitleMode === "whisper" ||
      input.subtitleMode === "transcribe_translate"
        ? "whisper"
        : "subtitle",
  };
}
