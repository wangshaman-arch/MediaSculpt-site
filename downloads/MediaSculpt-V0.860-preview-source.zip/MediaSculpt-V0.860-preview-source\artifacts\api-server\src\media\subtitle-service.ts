import fs from "node:fs/promises";
import { toSimplifiedChinese } from "../lib/chinese-utils";
import type { SubtitleBlock } from "../lib/bilingual-subtitle";

export interface SrtBlock {
  index: string;
  timestamp: string;
  text: string;
}

export function parseSrt(content: string): SrtBlock[] {
  const blocks: SrtBlock[] = [];
  const raw = content.replace(/\r\n/g, "\n").replace(/\r/g, "\n").trim();
  const parts = raw.split(/\n\n+/);
  for (const part of parts) {
    const lines = part.trim().split("\n");
    if (lines.length < 3) continue;
    const index = lines[0].trim();
    const timestamp = lines[1].trim();
    const text = lines.slice(2).join("\n").trim();
    if (/^\d+$/.test(index) && timestamp.includes("-->")) {
      blocks.push({ index, timestamp, text });
    }
  }
  return blocks;
}

export function renderSrt(blocks: SrtBlock[]): string {
  return (
    blocks
      .map(
        (block) =>
          `${block.index}\n${block.timestamp}\n${block.text.replace(/<[^>]+>/g, "")}`,
      )
      .join("\n\n") + "\n"
  );
}

export function srtStartMs(timestamp: string): number {
  const match = /(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})/.exec(timestamp);
  if (!match) return 0;
  return (
    (Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3])) *
      1000 +
    Number(match[4].padEnd(3, "0"))
  );
}

export function toSubtitleBlocks(blocks: SrtBlock[]): SubtitleBlock[] {
  return blocks.map((block) => {
    const [startRaw, endRaw] = block.timestamp.split("-->");
    const startMs = srtStartMs(startRaw);
    const endMs = endRaw ? srtStartMs(endRaw.trim()) : startMs;
    return { startMs, endMs, text: block.text.replace(/<[^>]+>/g, "") };
  });
}

function assTimestampToMs(timestamp: string): number {
  const match = /(\d+):(\d{2}):(\d{2})\.(\d{2})/.exec(timestamp.trim());
  if (!match) return 0;
  return (
    Number(match[1]) * 3_600_000 +
    Number(match[2]) * 60_000 +
    Number(match[3]) * 1000 +
    Number(match[4].padEnd(3, "0"))
  );
}

function parseAssBlocks(content: string): SubtitleBlock[] {
  const blocks: SubtitleBlock[] = [];
  for (const line of content.split("\n")) {
    const match = /^Dialogue:\s*\d+,([^,]+),([^,]+),(.*)$/.exec(line);
    if (!match) continue;
    const fields = match[3]!.split(",");
    if (fields.length < 7) continue;
    const rawText = fields
      .slice(6)
      .join(",")
      .replace(/<[^>]+>/g, "")
      .replace(/\{[^}]*\}/g, "");
    const hasCjk = /[\u3400-\u9fff]/.test(rawText);
    const text = rawText
      .replace(/\\N/gi, hasCjk ? "" : " ")
      .replace(/\\n/gi, hasCjk ? "" : " ")
      .trim();
    if (!text) continue;
    blocks.push({
      startMs: assTimestampToMs(match[1]!),
      endMs: assTimestampToMs(match[2]!),
      text,
    });
  }
  return blocks;
}

function parseVttBlocks(content: string): SubtitleBlock[] {
  const blocks: SubtitleBlock[] = [];
  const body = content.replace(/^WEBVTT.*?(?=\r?\n\r?\n)/s, "");
  for (const part of body.split(/\n\n+/)) {
    const lines = part.trim().split("\n");
    const cueIndex = lines.findIndex((line) => line.includes("-->"));
    if (cueIndex < 0) continue;
    const [startRaw, endRaw] = lines[cueIndex]!.split("-->");
    const text = lines
      .slice(cueIndex + 1)
      .join("\n")
      .replace(/<[^>]+>/g, "")
      .trim();
    if (!text) continue;
    blocks.push({
      startMs: srtStartMs(startRaw.trim()),
      endMs: srtStartMs((endRaw ?? "").trim().split(/\s+/)[0] ?? ""),
      text,
    });
  }
  return blocks;
}

export async function readSubtitleBlocks(
  filePath: string,
): Promise<SubtitleBlock[]> {
  const content = await fs.readFile(filePath, "utf8");
  const normalized = content
    .replace(/^\uFEFF/, "")
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .trim();
  if (
    /^\[Script Info\]/m.test(normalized) ||
    /^Dialogue:\s*\d+/m.test(normalized)
  ) {
    return parseAssBlocks(normalized);
  }
  if (/^WEBVTT/m.test(normalized)) {
    return parseVttBlocks(normalized);
  }
  return toSubtitleBlocks(parseSrt(normalized));
}

export function alignEnglishReference(
  chineseBlocks: SrtBlock[],
  englishBlocks: SrtBlock[],
): string[] {
  return chineseBlocks.map((block) => {
    const target = srtStartMs(block.timestamp);
    let best: SrtBlock | null = null;
    let bestDiff = Infinity;
    for (const candidate of englishBlocks) {
      const diff = Math.abs(srtStartMs(candidate.timestamp) - target);
      if (diff < bestDiff) {
        bestDiff = diff;
        best = candidate;
      }
    }
    return best && bestDiff <= 5000 ? best.text : "";
  });
}

export function renderSrtSimplified(
  blocks: SrtBlock[],
  forceSimplified: boolean,
): string {
  return renderSrt(
    forceSimplified
      ? blocks.map((block) => ({
          ...block,
          text: toSimplifiedChinese(block.text),
        }))
      : blocks,
  );
}

// Moved here from routes/jobs.ts: keep subtitle text conversion next to the
// other SRT/ASS/VTT parsing helpers.
export function toWebVtt(content: string): string {
  const normalized = content
    .replace(/^\uFEFF/, "")
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n");
  return /^WEBVTT\b/.test(normalized)
    ? normalized
    : `WEBVTT\n\n${normalized
        .replace(/^\d+\n(?=\d{2}:\d{2}:\d{2}[,.]\d{3}\s+-->\s+)/gm, "")
        .replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, "$1.$2")}`;
}

/** 读取字幕文件并统一为 UTF-8：UTF-8 直读，非法 UTF-8（GBK/GB2312 等）按 GB18030 解码。 */
export async function readSubtitleText(filePath: string): Promise<string> {
  const buffer = await fs.readFile(filePath);
  if (
    buffer.length >= 3 &&
    buffer[0] === 0xef &&
    buffer[1] === 0xbb &&
    buffer[2] === 0xbf
  ) {
    return buffer.subarray(3).toString("utf8");
  }
  const utf8 = buffer.toString("utf8");
  if (!utf8.includes("\uFFFD")) return utf8;
  try {
    return new TextDecoder("gb18030").decode(buffer);
  } catch {
    return utf8;
  }
}
