import { useEffect, useMemo, useRef, useState } from "react";
import {
  useUpdateConfig,
  type Config,
  type Job,
} from "@workspace/api-client-react";
import { useI18n } from "../i18n";
import {
  PRESET_CHANGED_EVENT,
  loadCompressionPresets,
  presetConfigValues,
  type ArchivePreset,
} from "../lib/compression-presets";

export type EditableJobPreset = {
  encoder: string;
  crf: string;
  encoderPreset: string;
  outputResolution: string;
};

export type PresetSelectionPlan = {
  presetId?: string | null;
};

/** 按来源类型选择默认压缩预设（工作流计划未给出 presetId 时的兜底）。 */
export function defaultPresetLabelForMediaType(
  mediaType: string | null | undefined,
): string {
  if (mediaType === "dvd") return "dvd-convert";
  if (mediaType === "bluray" || mediaType === "iso") return "bluray-collection";
  return "balanced";
}

/** 找出与当前全局压缩配置完全匹配的内置预设 id，用于“预设显示跟随全局配置”。 */
export function matchPresetId(
  presets: ArchivePreset[],
  config: Pick<
    Config,
    "encoder" | "crf" | "encoderPreset" | "outputResolution"
  >,
): string {
  const match = presets.find(
    (preset) =>
      preset.values.encoder === config.encoder &&
      preset.values.crf === config.crf &&
      (preset.values.encoderPreset || "slow") ===
        (config.encoderPreset || "slow") &&
      (preset.values.outputResolution || "source") ===
        (config.outputResolution || "source"),
  );
  return match?.id ?? "";
}

/**
 * 任务详情页的压缩预设状态：内置预设加载、全局配置同步、本任务手动修改标记，
 * 以及预设参数的选择/编辑（写回全局压缩配置）。
 */
export function useJobPresets({
  jobId,
  job,
  config,
  isWorkflowJob,
  selectionPlan,
}: {
  jobId: number;
  job: Pick<Job, "id" | "selectionPlan" | "mediaType"> | undefined;
  config: Config | undefined;
  isWorkflowJob: boolean;
  selectionPlan: PresetSelectionPlan | null;
}) {
  const { t } = useI18n();
  const updateConfig = useUpdateConfig();
  const [compressionPresets, setCompressionPresets] = useState<ArchivePreset[]>(
    () => loadCompressionPresets(),
  );
  const [selectedPresetLabel, setSelectedPresetLabel] = useState("");
  const [editableJobPreset, setEditableJobPreset] = useState<EditableJobPreset>(
    {
      encoder: "",
      crf: "",
      encoderPreset: "",
      outputResolution: "",
    },
  );
  const editableJobPresetRef = useRef(editableJobPreset);
  const presetSaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const presetDirtyRef = useRef(false);

  const presetOptions = useMemo(
    () =>
      compressionPresets.map((preset) => ({
        id: preset.id,
        label: t(preset.labelKey),
      })),
    [compressionPresets, t],
  );

  // 详情默认选中压缩预设：工作流计划带出的 presetId 优先，其次按来源类型（DVD→DVD转制）
  useEffect(() => {
    if (!job) return;
    if (
      typeof job.selectionPlan === "string" &&
      job.selectionPlan.includes("smart-workflow-v1")
    ) {
      setSelectedPresetLabel("");
      return;
    }
    setSelectedPresetLabel(
      (current) =>
        current ||
        selectionPlan?.presetId ||
        defaultPresetLabelForMediaType(job.mediaType),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [job?.id, job?.mediaType]);

  useEffect(() => {
    const reloadPresets = () => setCompressionPresets(loadCompressionPresets());
    window.addEventListener("storage", reloadPresets);
    window.addEventListener(PRESET_CHANGED_EVENT, reloadPresets);
    return () => {
      window.removeEventListener("storage", reloadPresets);
      window.removeEventListener(PRESET_CHANGED_EVENT, reloadPresets);
      if (presetSaveTimerRef.current) clearTimeout(presetSaveTimerRef.current);
    };
  }, []);

  useEffect(() => {
    editableJobPresetRef.current = editableJobPreset;
  }, [editableJobPreset]);

  useEffect(() => {
    if (!config) return;
    if (isWorkflowJob) {
      // A workflow job owns its preset choice. Do not erase the user's
      // selection when the preset also updates the global config query.
      if (!presetDirtyRef.current) setSelectedPresetLabel("");
      return;
    }
    // 同组任务统一：本任务未被手动修改时，预设显示跟随全局压缩配置（改一个 → 全组同步）
    if (presetDirtyRef.current) return;
    setSelectedPresetLabel(matchPresetId(compressionPresets, config));
    setEditableJobPreset({
      encoder: config.encoder || "",
      crf: String(config.crf ?? ""),
      encoderPreset: config.encoderPreset || "slow",
      outputResolution: config.outputResolution || "source",
    });
  }, [config, compressionPresets]);

  // 切换任务时重置“本任务已手动修改”标记，回到跟随全局配置
  useEffect(() => {
    presetDirtyRef.current = false;
  }, [jobId]);

  const onCompressionPresetSelect = (preset: ArchivePreset) => {
    presetDirtyRef.current = true;
    setSelectedPresetLabel(preset.id);
    setEditableJobPreset({
      encoder: preset.values.encoder,
      crf: String(preset.values.crf),
      encoderPreset: preset.values.encoderPreset || "slow",
      outputResolution: preset.values.outputResolution || "source",
    });
    void updateConfig
      .mutateAsync({ data: presetConfigValues(preset) })
      .catch(() => {});
  };

  const onEditableJobPresetChange = (next: Partial<EditableJobPreset>) => {
    presetDirtyRef.current = true;
    setSelectedPresetLabel(t("jobDetail.customPreset"));
    setEditableJobPreset((current) => ({ ...current, ...next }));
    if (presetSaveTimerRef.current) clearTimeout(presetSaveTimerRef.current);
    presetSaveTimerRef.current = setTimeout(() => {
      const merged = { ...editableJobPresetRef.current, ...next };
      void updateConfig
        .mutateAsync({
          data: {
            encoder: merged.encoder || undefined,
            crf: merged.crf ? Number(merged.crf) : undefined,
            encoderPreset: merged.encoderPreset || undefined,
            outputResolution: merged.outputResolution || undefined,
          },
        })
        .catch(() => {});
    }, 500);
  };

  return {
    compressionPresets,
    selectedPresetLabel,
    editableJobPreset,
    presetDirtyRef,
    presetOptions,
    onCompressionPresetSelect,
    onEditableJobPresetChange,
  };
}
