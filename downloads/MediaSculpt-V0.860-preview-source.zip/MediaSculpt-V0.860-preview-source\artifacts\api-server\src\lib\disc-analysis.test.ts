import { describe, expect, it } from "vitest";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import {
  DiscAnalysisCache,
  analyzeDiscSource,
  buildDiscAnalysisId,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  consolidateDiscTitles,
  fillStreamSizeEstimates,
  measureDvdSourceBytes,
  type HandBrakeDiscScanResult,
} from "./disc-analysis";
import type { ExternalToolRunner } from "./dvd-remux";

describe("unified disc analysis", () => {
  it("completes DVD analysis with HandBrake plus deterministic ffprobe verification", async () => {
    const calls: string[] = [];
    const run: ExternalToolRunner = async (request) => {
      calls.push(request.tool);
      if (request.tool === "ffprobe") {
        return {
          tool: request.tool,
          executable: request.executable,
          args: request.args,
          exitCode: 0,
          stdout:
            '{"streams":[{"index":0,"codec_type":"video","codec_name":"mpeg2video","width":720,"height":480}],"format":{"duration":"60"},"chapters":[]}',
          stderr: "",
          durationMs: 2,
          failureReason: null,
        };
      }
      return {
        tool: request.tool,
        executable: request.executable,
        args: request.args,
        exitCode: 0,
        stdout:
          'JSON Title Set: {"TitleList":[{"Index":3,"Duration":{"Hours":0,"Minutes":1,"Seconds":0},"Geometry":{"Width":720,"Height":480},"ChapterList":[],"AudioList":[],"SubtitleList":[]}]}',
        stderr: "",
        durationMs: 2,
        failureReason: null,
      };
    };
    const result = await analyzeDiscSource({
      sourcePath: "D:\\电影\\VIDEO_TS",
      sourceFingerprint: "fingerprint",
      mediaType: "dvd",
      handbrakeCliPath: "C:\\VX Tools\\HandBrakeCLI.exe",
      toolRunner: run,
    });

    expect(calls).toEqual(["handbrake", "ffprobe"]);
    expect(result.diagnostics.map((diagnostic) => diagnostic.tool)).toEqual([
      "handbrake",
      "ffprobe",
    ]);
    expect(result.titles[0]).toMatchObject({
      titleId: "handbrake:3",
      verificationStatus: "verified",
      durationSeconds: 60,
    });
    expect(result.exportCandidates).toEqual([]);
  });

  it("asks ffprobe to return chapters instead of parsing a field that was never requested", () => {
    expect(
      buildFfprobeAnalysisArgs("/Volumes/Movie/VIDEO_TS/VTS_01_0.IFO"),
    ).toEqual([
      "-v",
      "error",
      "-print_format",
      "json",
      "-show_streams",
      "-show_format",
      "-show_chapters",
      "/Volumes/Movie/VIDEO_TS/VTS_01_0.IFO",
    ]);
  });

  it("estimates stream sizes from bitrate and title duration", () => {
    const filled = fillStreamSizeEstimates(
      [
        {
          index: 1,
          codecType: "audio",
          codecName: "pcm_dvd",
          language: "und",
          title: null,
          bitrate: 1_536_000,
        },
      ],
      600,
      null,
    );
    expect(filled[0]?.estimatedSizeBytes).toBe(
      Math.round((1_536_000 * 600) / 8),
    );
  });

  it("fills a video stream size from the title size when bitrate is missing", () => {
    const filled = fillStreamSizeEstimates(
      [
        {
          index: 0,
          codecType: "video",
          codecName: "mpeg2video",
          language: null,
          title: null,
        },
      ],
      600,
      5_000_000_000,
    );
    expect(filled[0].estimatedSizeBytes).toBeGreaterThan(4_000_000_000);
    expect(filled[0].bitrate).toBeGreaterThan(0);
  });

  it("keeps display-only stream estimates within the physical title size", () => {
    const filled = fillStreamSizeEstimates(
      [
        {
          index: 0,
          codecType: "video",
          codecName: "mpeg2video",
          language: null,
          title: null,
          bitrate: 8_000_000,
        },
        {
          index: 1,
          codecType: "audio",
          codecName: "ac3",
          language: "eng",
          title: null,
          bitrate: 192_000,
        },
      ],
      600,
      500_000_000,
    );
    const total = filled.reduce(
      (sum, stream) => sum + (stream.estimatedSizeBytes ?? 0),
      0,
    );
    expect(total).toBeLessThanOrEqual(500_000_000);
    expect(filled[0]?.estimatedSizeBytes).toBeGreaterThan(0);
  });

  it("measures VIDEO_TS bytes once instead of summing logical title payloads", async () => {
    const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), "vx-dvd-size-"));
    const videoTs = path.join(tempDir, "VIDEO_TS");
    await fs.mkdir(videoTs, { recursive: true });
    await fs.writeFile(path.join(videoTs, "VIDEO_TS.IFO"), Buffer.alloc(10));
    await fs.writeFile(path.join(videoTs, "VTS_01_1.VOB"), Buffer.alloc(90));
    try {
      await expect(measureDvdSourceBytes(tempDir)).resolves.toBe(100);
    } finally {
      await fs.rm(tempDir, { recursive: true, force: true });
    }
  });

  it("creates a stable analysis id for the same source fingerprint", () => {
    expect(
      buildDiscAnalysisId({ sourcePath: "D:\\Movie", sourceFingerprint: "v1" }),
    ).toBe(
      buildDiscAnalysisId({ sourcePath: "D:\\Movie", sourceFingerprint: "v1" }),
    );
  });

  it("uses one source fingerprint whether a DVD root or its VIDEO_TS directory is selected", async () => {
    const tempDir = await fs.mkdtemp(
      path.join(os.tmpdir(), "vx-disc-analysis-"),
    );
    const discRoot = path.join(tempDir, "Movie");
    const videoTs = path.join(discRoot, "VIDEO_TS");
    await fs.mkdir(videoTs, { recursive: true });
    await fs.writeFile(path.join(videoTs, "VIDEO_TS.IFO"), "ifo");
    await fs.writeFile(path.join(videoTs, "VTS_01_1.VOB"), "vob");

    try {
      const rootFingerprint = await buildDiscSourceFingerprint(discRoot, "dvd");
      const videoTsFingerprint = await buildDiscSourceFingerprint(
        videoTs,
        "dvd",
      );
      expect(rootFingerprint).toBe(videoTsFingerprint);
      expect(
        buildDiscAnalysisId({
          sourcePath: discRoot,
          sourceFingerprint: rootFingerprint,
        }),
      ).toBe(
        buildDiscAnalysisId({
          sourcePath: videoTs,
          sourceFingerprint: videoTsFingerprint,
        }),
      );
    } finally {
      await fs.rm(tempDir, { recursive: true, force: true });
    }
  });

  it("shares concurrent identical scans, reuses a valid cache entry, and invalidates on source change or force", async () => {
    const cache = new DiscAnalysisCache<number>();
    let scans = 0;
    const scan = async () => {
      scans += 1;
      return scans;
    };

    const [first, second] = await Promise.all([
      cache.getOrAnalyze({ cacheKey: "movie:v1", force: false }, scan),
      cache.getOrAnalyze({ cacheKey: "movie:v1", force: false }, scan),
    ]);
    const cached = await cache.getOrAnalyze(
      { cacheKey: "movie:v1", force: false },
      scan,
    );
    const changed = await cache.getOrAnalyze(
      { cacheKey: "movie:v2", force: false },
      scan,
    );
    const forced = await cache.getOrAnalyze(
      { cacheKey: "movie:v2", force: true },
      scan,
    );

    expect([first.value, second.value, cached.value]).toEqual([1, 1, 1]);
    expect(first.cached).toBe(false);
    expect(second.shared).toBe(true);
    expect(cached.cached).toBe(true);
    expect(changed.value).toBe(2);
    expect(forced.value).toBe(3);
    expect(scans).toBe(3);
  });
});

describe("consolidateDiscTitles", () => {
  function title(
    id: string,
    durationSeconds: number | null,
    hasVideo = true,
    overrides: Partial<
      Parameters<typeof consolidateDiscTitles>[0][number]
    > = {},
  ): Parameters<typeof consolidateDiscTitles>[0][number] {
    return {
      titleId: id,
      titleIndex: 0,
      sourcePath: "X:\\disc",
      displayName: id,
      durationSeconds,
      chapterCount: 0,
      chapters: [],
      estimatedSize: null,
      streams: [],
      videoTracks: hasVideo
        ? [
            {
              index: 0,
              codecType: "video",
              codecName: "mpeg2video",
              language: null,
              title: null,
            },
          ]
        : [],
      audioTracks: [],
      subtitleTracks: [],
      toolMappings: {
        handbrakeTitleNumber: null,
        makemkvTitleIndex: null,
        dvdVtsNumber: null,
        playlistId: null,
      },
      mappingStatus: "not-required",
      ...overrides,
    };
  }

  it("drops menu stubs and puts the longest title first", () => {
    const notes: string[] = [];
    const result = consolidateDiscTitles(
      [
        title("stub", 8),
        title("no-video", 600, false),
        title("extra", 120),
        title("main", 5400),
      ],
      (message) => notes.push(message),
    );
    expect(result.map((t) => t.titleId)).toEqual(["main", "extra"]);
    expect(notes).toEqual([]);
  });

  it("keeps a long unavailable playlist so a short clip cannot masquerade as the main title", () => {
    const result = consolidateDiscTitles([
      title("mpls:00000", 5290, false, { availabilityStatus: "unavailable" }),
      title("mpls:00007", 22, true),
    ]);
    expect(result.map((item) => item.titleId)).toEqual(["mpls:00000"]);
  });

  it("caps a flood of HandBrake PGC titles to a usable list", () => {
    const notes: string[] = [];
    const titles = Array.from({ length: 60 }, (_, index) =>
      title(`t${index}`, 30 + index),
    );
    const result = consolidateDiscTitles(titles, (message) =>
      notes.push(message),
    );
    expect(result.length).toBeLessThanOrEqual(15);
    expect(result[0]!.titleId).toBe(`t${59}`);
    expect(notes.some((message) => message.includes("已折叠"))).toBe(true);
  });

  it("preserves every DVD title when the caller needs complete title selection", () => {
    const titles = Array.from({ length: 40 }, (_, index) =>
      title(`dvd-${index}`, 30 + index),
    );
    const result = consolidateDiscTitles(titles, undefined, {
      preserveAll: true,
    });

    expect(result).toHaveLength(40);
    expect(result[0]!.titleId).toBe("dvd-39");
  });
});
