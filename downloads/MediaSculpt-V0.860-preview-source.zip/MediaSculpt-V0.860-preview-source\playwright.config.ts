import { defineConfig } from "@playwright/test";

// Windows dev machines reuse the installed Edge (channel: "msedge") so no
// Chromium download is required. CI can override with PW_CHANNEL (or leave it
// unset to use Playwright's bundled browser after `playwright install`).
const channel =
  process.env.PW_CHANNEL ||
  (process.platform === "win32" ? "msedge" : undefined);

export default defineConfig({
  testDir: "./e2e",
  fullyParallel: false,
  timeout: 60_000,
  expect: { timeout: 10_000 },
  reporter: [["list"]],
  outputDir: "e2e/.artifacts",
  use: {
    baseURL: "http://127.0.0.1:5173",
    channel,
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
  },
  webServer: {
    command: "pnpm --filter @workspace/video-agent dev",
    url: "http://127.0.0.1:5173",
    reuseExistingServer: true,
    timeout: 120_000,
    env: { PORT: "5173" },
  },
});
