import {
  BookOpenCheck,
  CircleHelp,
  ExternalLink,
  Film,
  SearchCheck,
  Wrench,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useI18n } from "@/i18n";

export type HelpTab =
  | "quick-start"
  | "workflow"
  | "compatibility"
  | "troubleshooting"
  | "updates";

export function HelpCenterDialog({
  open,
  onOpenChange,
  defaultTab = "quick-start",
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  defaultTab?: HelpTab;
}) {
  const { t } = useI18n();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[min(86vh,720px)] max-w-3xl overflow-hidden p-0">
        <DialogHeader className="border-b px-6 pb-4 pt-6 pr-12">
          <DialogTitle className="flex items-center gap-2">
            <CircleHelp className="h-5 w-5 text-primary" />
            {t("help.title")}
          </DialogTitle>
          <DialogDescription>{t("help.description")}</DialogDescription>
        </DialogHeader>
        <Tabs
          defaultValue={defaultTab}
          key={defaultTab}
          className="flex min-h-0 flex-col"
        >
          <div className="overflow-x-auto border-b px-4 py-2">
            <TabsList className="h-auto min-w-max justify-start">
              <TabsTrigger value="quick-start" className="gap-1.5">
                <BookOpenCheck className="h-3.5 w-3.5" />
                {t("help.quickStartTab")}
              </TabsTrigger>
              <TabsTrigger value="workflow" className="gap-1.5">
                <Film className="h-3.5 w-3.5" />
                {t("help.workflowTab")}
              </TabsTrigger>
              <TabsTrigger value="compatibility" className="gap-1.5">
                <SearchCheck className="h-3.5 w-3.5" />
                {t("help.compatibilityTab")}
              </TabsTrigger>
              <TabsTrigger value="troubleshooting" className="gap-1.5">
                <Wrench className="h-3.5 w-3.5" />
                {t("help.troubleshootingTab")}
              </TabsTrigger>
              <TabsTrigger value="updates" className="gap-1.5">
                <ExternalLink className="h-3.5 w-3.5" />
                {t("help.updatesTab")}
              </TabsTrigger>
            </TabsList>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto px-6 py-5 text-sm leading-6 text-muted-foreground">
            <TabsContent value="quick-start" className="mt-0 space-y-4">
              <section>
                <h3 className="text-base font-semibold text-foreground">
                  {t("help.quickStartTitle")}
                </h3>
                <p>{t("help.quickStartBody")}</p>
              </section>
              <ol className="list-decimal space-y-2 pl-5">
                <li>{t("help.quickStartStep1")}</li>
                <li>{t("help.quickStartStep2")}</li>
                <li>{t("help.quickStartStep3")}</li>
                <li>{t("help.quickStartStep4")}</li>
              </ol>
            </TabsContent>
            <TabsContent value="workflow" className="mt-0 space-y-4">
              <section>
                <h3 className="text-base font-semibold text-foreground">
                  {t("help.workflowTitle")}
                </h3>
                <p>{t("help.workflowBody")}</p>
              </section>
              <section>
                <h3 className="text-base font-semibold text-foreground">
                  {t("help.subtitleTitle")}
                </h3>
                <p>{t("help.subtitleBody")}</p>
              </section>
            </TabsContent>
            <TabsContent value="compatibility" className="mt-0 space-y-4">
              <section>
                <h3 className="text-base font-semibold text-foreground">
                  {t("help.compatibilityTitle")}
                </h3>
                <p>{t("help.compatibilityBody")}</p>
              </section>
              <p className="rounded-md border bg-muted/30 px-3 py-2 text-xs">
                {t("help.compatibilityNote")}
              </p>
            </TabsContent>
            <TabsContent value="troubleshooting" className="mt-0 space-y-4">
              <section>
                <h3 className="text-base font-semibold text-foreground">
                  {t("help.troubleshootingTitle")}
                </h3>
                <p>{t("help.troubleshootingBody")}</p>
              </section>
              <ol className="list-decimal space-y-2 pl-5">
                <li>{t("help.troubleshootingStep1")}</li>
                <li>{t("help.troubleshootingStep2")}</li>
                <li>{t("help.troubleshootingStep3")}</li>
              </ol>
            </TabsContent>
            <TabsContent value="updates" className="mt-0 space-y-4">
              <section>
                <h3 className="text-base font-semibold text-foreground">
                  {t("help.updatesTitle")}
                </h3>
                <p>{t("help.updatesBody")}</p>
              </section>
              <a
                className="inline-flex items-center gap-1.5 text-primary underline-offset-4 hover:underline"
                href="https://github.com/wangshaman-arch/MediaSculpt-site/releases"
                target="_blank"
                rel="noreferrer"
              >
                {t("help.updatesLink")}
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
