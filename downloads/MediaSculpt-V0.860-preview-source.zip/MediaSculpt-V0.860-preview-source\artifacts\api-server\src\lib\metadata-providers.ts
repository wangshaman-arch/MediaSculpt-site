// Extracted from metadata.ts: TMDb / OMDb / Wikipedia providers.
import path from "path";
import { db, imdbTitlesTable, configTable } from "@workspace/db";
import { and, or, between, desc, eq, sql } from "drizzle-orm";
import { fetchLike, resolvePosterProxyUrl } from "./http-client";
import { FETCH_TIMEOUT_MS, stdName, type MetadataResult } from "./metadata";

// ─── TMDb ─────────────────────────────────────────────────────────────────────

export async function searchTmdb(
  searchTitle: string,
  opts: {
    year?: number;
    language: string;
    apiKey: string;
    originalQuery: string;
  },
  fetchFn: typeof fetch = fetch,
): Promise<MetadataResult[]> {
  const params = new URLSearchParams({
    api_key: opts.apiKey,
    query: searchTitle,
    language: opts.language,
    include_adult: "false",
  });
  if (opts.year) params.set("year", String(opts.year));

  const searchResp = await fetchFn(
    `https://api.themoviedb.org/3/search/multi?${params}`,
    {
      signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
    },
  );
  if (!searchResp.ok) throw new Error(`TMDb HTTP ${searchResp.status}`);

  const searchData = (await searchResp.json()) as {
    results: Array<{
      id: number;
      title?: string;
      name?: string;
      original_title?: string;
      original_name?: string;
      release_date?: string;
      first_air_date?: string;
      vote_average?: number;
      vote_count?: number;
      overview?: string;
      poster_path?: string;
      media_type: "movie" | "tv" | "person";
    }>;
  };

  const hits = (searchData.results ?? [])
    .filter((r) => r.media_type !== "person")
    .slice(0, 5);

  return Promise.all(
    hits.map(async (item) => {
      const mediaType = item.media_type as "movie" | "tv";
      let director = "";
      let cast = "";
      let genres = "";
      let imdbId: string | undefined;
      let runtimeMinutes: number | undefined;

      try {
        const detailUrl =
          `https://api.themoviedb.org/3/${mediaType}/${item.id}` +
          `?api_key=${opts.apiKey}&language=${opts.language}&append_to_response=credits,external_ids`;
        const detailResp = await fetchFn(detailUrl, {
          signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
        });
        if (detailResp.ok) {
          const detail = (await detailResp.json()) as {
            credits?: {
              crew?: Array<{ job: string; name: string }>;
              // `credits` already carries the cast; it was simply never read, so
              // actors stayed blank while the payload sat in the response.
              cast?: Array<{ name?: string; order?: number }>;
            };
            created_by?: Array<{ name?: string }>;
            genres?: Array<{ name: string }>;
            external_ids?: { imdb_id?: string | null };
            runtime?: number;
            episode_run_time?: number[];
          };
          // A film can have more than one credited director; keep them all.
          const directors = (detail.credits?.crew ?? [])
            .filter((c) => c.job === "Director" && c.name)
            .map((c) => c.name);
          // Series have no director credit; TMDb exposes the creators instead.
          const creators = (detail.created_by ?? [])
            .map((c) => c.name)
            .filter(Boolean) as string[];
          director = Array.from(new Set([...directors, ...creators])).join(
            "、",
          );
          cast = (detail.credits?.cast ?? [])
            .slice()
            .sort((a, b) => (a.order ?? 999) - (b.order ?? 999))
            .map((member) => member.name)
            .filter(Boolean)
            .slice(0, 15)
            .join("、");
          genres = (detail.genres ?? []).map((g) => g.name).join("、");
          imdbId = detail.external_ids?.imdb_id ?? undefined;
          runtimeMinutes = detail.runtime ?? detail.episode_run_time?.[0];
        }
      } catch {
        /* detail fetch is best-effort */
      }

      const title = item.title ?? item.name ?? "";
      const titleEn = item.original_title ?? item.original_name ?? "";
      const rawDate = item.release_date ?? item.first_air_date ?? "";
      const year = rawDate ? parseInt(rawDate.slice(0, 4)) : undefined;

      const result: MetadataResult = {
        tmdbId: item.id,
        imdbId,
        title,
        titleEn,
        year,
        rating: item.vote_average,
        ratingSource: "tmdb",
        ratingVotes: item.vote_count,
        runtimeMinutes,
        director,
        cast: cast || undefined,
        genres,
        overview: item.overview ?? "",
        poster: item.poster_path
          ? `https://image.tmdb.org/t/p/w500${item.poster_path}`
          : undefined,
        mediaType,
        source: "tmdb",
      };
      result.standardizedName = stdName(result, opts.originalQuery);
      return result;
    }),
  );
}

// ─── Douban (keyless) ─────────────────────────────────────────────────────────

/**
 * Douban's public suggestion feed. No key required.
 *
 * This is the only source that maps a Chinese title and an English title onto
 * one identity in a single response (`title` + `sub_title`), which is exactly
 * what a Chinese library needs: a Chinese-named folder can be matched to an
 * English-named provider result, and vice versa. The previous build called this
 * endpoint for posters only and threw away `sub_title`, `id` and `type`, so
 * `doubanId`/`doubanRating` were declared in the result type but never
 * populated by any provider.
 */
export async function searchDouban(
  searchTitle: string,
  opts: { year?: number; originalQuery: string; fetchFn: typeof fetch },
): Promise<MetadataResult[]> {
  const q = searchTitle.trim();
  if (!q) return [];
  const request = opts.fetchFn;
  const response = await request(
    `https://movie.douban.com/j/subject_suggest?q=${encodeURIComponent(q)}`,
    { signal: AbortSignal.timeout(FETCH_TIMEOUT_MS) },
  );
  if (!response.ok) throw new Error(`Douban HTTP ${response.status}`);
  const payload = (await response.json().catch(() => null)) as Array<{
    id?: string;
    title?: string;
    sub_title?: string;
    year?: string | number;
    img?: string;
    type?: string;
    episode?: string;
  }> | null;
  if (!Array.isArray(payload)) return [];

  const compact = (value: string): string =>
    value.toLowerCase().replace(/[^a-z0-9\u3400-\u9fff]/g, "");
  const queryKey = compact(q);
  const rows = payload
    .flatMap((item, index) => {
      const doubanId = typeof item.id === "string" ? item.id.trim() : "";
      const title = typeof item.title === "string" ? item.title.trim() : "";
      if (!doubanId || !title) return [];
      const titleEn =
        typeof item.sub_title === "string" ? item.sub_title.trim() : "";
      const parsedYear = Number(item.year);
      const year =
        Number.isFinite(parsedYear) && parsedYear >= 1800
          ? parsedYear
          : undefined;
      const poster =
        typeof item.img === "string" && /^https?:\/\//i.test(item.img)
          ? item.img
          : undefined;
      // A folder named after either language must be able to match this entry.
      const titleKey = compact(title);
      const enKey = compact(titleEn);
      const score =
        (titleKey === queryKey || (enKey && enKey === queryKey)
          ? 100
          : titleKey.includes(queryKey) ||
              queryKey.includes(titleKey) ||
              (enKey && (enKey.includes(queryKey) || queryKey.includes(enKey)))
            ? 60
            : 0) +
        (opts.year && year
          ? year === opts.year
            ? 50
            : Math.max(0, 20 - Math.abs(year - opts.year))
          : 0) -
        index / 1000;
      const result: MetadataResult = {
        doubanId,
        title,
        titleEn: titleEn || undefined,
        year,
        poster,
        mediaType: /tv|series/i.test(item.type ?? "") ? "tv" : "movie",
        source: "douban",
      };
      result.standardizedName = stdName(result, opts.originalQuery);
      return [{ result, score }];
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
    .map((entry) => entry.result);
  return rows;
}

// ─── OMDb ─────────────────────────────────────────────────────────────────────

export async function searchOmdb(
  searchTitle: string,
  opts: { year?: number; apiKey: string; originalQuery: string },
  fetchFn: typeof fetch = fetch,
): Promise<MetadataResult[]> {
  const params = new URLSearchParams({ s: searchTitle, apikey: opts.apiKey });
  if (opts.year) params.set("y", String(opts.year));

  const resp = await fetchFn(`https://www.omdbapi.com/?${params}`, {
    signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
  });
  if (!resp.ok) throw new Error(`OMDb HTTP ${resp.status}`);

  const data = (await resp.json()) as {
    Response: "True" | "False";
    Error?: string;
    Search?: Array<{
      imdbID: string;
      Title: string;
      Year: string;
      Type: string;
      Poster: string;
    }>;
  };
  // OMDb signals "no matches" via Response=False + Error — that's an empty
  // result, not a provider failure. Real failures (bad key, rate limit) also
  // come back this way, so surface those as errors.
  if (data.Response === "False") {
    const err = data.Error ?? "";
    if (/not found/i.test(err)) return [];
    throw new Error(`OMDb: ${err || "unknown error"}`);
  }
  if (!data.Search?.length) return [];

  return Promise.all(
    data.Search.slice(0, 5).map(async (item) => {
      let director = "";
      let cast = "";
      let genres = "";
      let rating: number | undefined;
      let ratingVotes: number | undefined;
      let rottenTomatoesRating: number | undefined;
      let metacriticRating: number | undefined;
      let overview = "";
      let runtimeMinutes: number | undefined;
      try {
        const detResp = await fetchFn(
          `https://www.omdbapi.com/?i=${item.imdbID}&apikey=${opts.apiKey}&plot=short`,
          { signal: AbortSignal.timeout(FETCH_TIMEOUT_MS) },
        );
        if (detResp.ok) {
          const det = (await detResp.json()) as {
            Director?: string;
            Writer?: string;
            Actors?: string;
            Genre?: string;
            imdbRating?: string;
            imdbVotes?: string;
            Metascore?: string;
            Ratings?: Array<{ Source?: string; Value?: string }>;
            Plot?: string;
            Runtime?: string;
          };
          // OMDb returns comma-separated lists in one field; keep them all rather
          // than only the first name (the previous build requested neither
          // `Actors` nor `Writer`, so cast was always empty).
          const clean = (value?: string) =>
            value && value !== "N/A"
              ? value
                  .split(",")
                  .map((part) => part.trim())
                  .filter(Boolean)
                  .join("、")
              : "";
          director = clean(det.Director);
          cast = clean(det.Actors);
          genres = clean(det.Genre);
          rating =
            det.imdbRating && det.imdbRating !== "N/A"
              ? parseFloat(det.imdbRating)
              : undefined;
          const parsedVotes =
            det.imdbVotes && det.imdbVotes !== "N/A"
              ? Number(det.imdbVotes.replace(/,/g, ""))
              : NaN;
          ratingVotes = Number.isFinite(parsedVotes) ? parsedVotes : undefined;
          const parsedRottenTomatoes = Number(
            det.Ratings?.find((item) =>
              /rotten tomatoes/i.test(item.Source ?? ""),
            )?.Value?.replace("%", ""),
          );
          rottenTomatoesRating = Number.isFinite(parsedRottenTomatoes)
            ? parsedRottenTomatoes
            : undefined;
          const parsedMetacritic = Number(det.Metascore);
          metacriticRating = Number.isFinite(parsedMetacritic)
            ? parsedMetacritic
            : undefined;
          overview = det.Plot && det.Plot !== "N/A" ? det.Plot : "";
          const rtMatch = det.Runtime?.match(/(\d+)\s*min/);
          if (rtMatch) runtimeMinutes = parseInt(rtMatch[1]);
        }
      } catch {
        /* detail fetch is best-effort */
      }

      const year = item.Year ? parseInt(item.Year) : undefined;
      const result: MetadataResult = {
        imdbId: item.imdbID,
        title: item.Title,
        titleEn: item.Title,
        year: Number.isNaN(year) ? undefined : year,
        rating,
        ratingSource: "imdb",
        ratingVotes,
        rottenTomatoesRating,
        metacriticRating,
        runtimeMinutes,
        director,
        cast: cast || undefined,
        genres,
        overview,
        poster: item.Poster && item.Poster !== "N/A" ? item.Poster : undefined,
        mediaType: item.Type === "series" ? "tv" : "movie",
        source: "omdb",
      };
      result.standardizedName = stdName(result, opts.originalQuery);
      return result;
    }),
  );
}

// ─── IMDb public suggestion endpoint ─────────────────────────────────────────

import {
  searchImdbSuggestion,
  searchImdbTitlePage,
  searchImdbLocal,
  searchImdbByTconst,
} from "./metadata-imdb";
export {
  searchImdbSuggestion,
  searchImdbTitlePage,
  searchImdbLocal,
  searchImdbByTconst,
} from "./metadata-imdb";

// ─── Wikipedia poster (free, no API key) ──────────────────────────────────────

/** Find a real poster/thumbnail AND a short text intro via Wikipedia's public API (no key needed). */
export async function searchWikipediaPoster(
  searchTitle: string,
  opts: { year?: number; originalQuery: string; proxyUrl?: string | null },
): Promise<MetadataResult[]> {
  const q = searchTitle.trim();
  if (!q) return [];
  const query = opts.year ? `${q} ${opts.year}` : q;
  const mapResult = (
    title: string,
    year: number | undefined,
    poster: string,
    mediaType: "movie" | "tv",
  ): MetadataResult => {
    const result: MetadataResult = {
      title,
      titleEn: title,
      year,
      poster,
      mediaType,
      source: "wikipedia",
    };
    result.standardizedName = stdName(result, opts.originalQuery);
    return result;
  };
  const providers: Array<() => Promise<MetadataResult[]>> = [
    // Douban subject suggest (domestic, free, no key)
    async () => {
      const response = await fetchLike(
        `https://movie.douban.com/j/subject_suggest?q=${encodeURIComponent(q)}`,
        opts.proxyUrl ?? null,
        6_000,
      );
      if (!response || !response.ok) return [];
      const rawBody = (await new Response(response.body as ReadableStream)
        .json()
        .catch(() => null)) as Array<{
        id?: string;
        title?: string;
        year?: string;
        subtype?: string;
        img?: string;
        rate?: string;
      }> | null;
      const data = rawBody ?? [];
      return data
        .filter((item) => item.img)
        .map((item) => {
          const title = item.title ?? q;
          const isTv =
            item.subtype === "tv" ||
            /第\s*(?:\d{1,2}|[一二三四五六七八九十百零〇两]+\s*)?季/i.test(
              title,
            ) ||
            /\bS\d{1,2}\b|\bSeason\s*\d+/i.test(title);
          const result = mapResult(
            title,
            item.year ? Number(item.year) : undefined,
            (item.img as string).replace(/\/s\//, "/l/"),
            isTv ? "tv" : "movie",
          );
          if (item.id && /^\d+$/.test(item.id)) result.doubanId = item.id;
          const doubanRating = Number(item.rate);
          if (Number.isFinite(doubanRating) && doubanRating > 0)
            result.doubanRating = doubanRating;
          return result;
        });
    },
    // Wikipedia page image
    async () => {
      const response = await fetchLike(
        `https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(query)}&gsrlimit=3&prop=pageimages|extracts&piprop=thumbnail&pithumbsize=1000&exintro=1&explaintext=1&format=json`,
        opts.proxyUrl ?? null,
        6_000,
      );
      if (!response || !response.ok) return [];
      const rawBody = (await new Response(response.body as ReadableStream)
        .json()
        .catch(() => null)) as {
        query?: {
          pages?: Record<
            string,
            {
              title?: string;
              thumbnail?: { source?: string };
              extract?: string;
            }
          >;
        };
      } | null;
      const data = rawBody ?? {};
      return Object.values(data.query?.pages ?? {}).flatMap((page) => {
        const src = page?.thumbnail?.source;
        if (!src) return [];
        const result = mapResult(
          page.title ?? q,
          undefined,
          src,
          /(?:series|episode)/i.test(page.title ?? "") ? "tv" : "movie",
        );
        if (page.extract) result.overview = page.extract.slice(0, 600);
        return [result];
      });
    },
    // iTunes Search API (free, no key) — real artwork scaled to 600x600
    async () => {
      for (const media of ["movie", "tvShow"] as const) {
        const response = await fetchLike(
          `https://itunes.apple.com/search?term=${encodeURIComponent(query)}&media=${media}&entity=${media}&limit=3`,
          opts.proxyUrl ?? null,
          6_000,
        );
        if (!response || !response.ok) continue;
        const rawBody = (await new Response(response.body as ReadableStream)
          .json()
          .catch(() => null)) as {
          results?: Array<{
            trackName?: string;
            releaseDate?: string;
            artworkUrl100?: string;
          }>;
        } | null;
        const data = rawBody ?? {};
        const found = (data.results ?? [])
          .filter((r) => r.artworkUrl100)
          .map((r) => {
            const parsedYear = r.releaseDate
              ? Number(r.releaseDate.slice(0, 4))
              : undefined;
            const year =
              typeof parsedYear === "number" &&
              Number.isFinite(parsedYear) &&
              parsedYear >= 1900
                ? parsedYear
                : undefined;
            return mapResult(
              r.trackName ?? q,
              year,
              r.artworkUrl100!.replace(/100x100bb\.jpg$/, "600x600bb.jpg"),
              media === "tvShow" ? "tv" : "movie",
            );
          });
        if (found.length > 0) return found;
      }
      return [];
    },
    // TVmaze (free, no key) — structured TV/movie data incl. Chinese-ish titles,
    // year, genres, official synopsis, IMDb id and high-res poster. TVmaze's
    // coverage of TV series is stronger than the free movie APIs, so it fills
    // the gap left by TMDb/OMDb (both key-gated).
    async () => {
      const response = await fetchLike(
        `https://api.tvmaze.com/search/shows?q=${encodeURIComponent(query)}`,
        opts.proxyUrl ?? null,
        8_000,
      );
      if (!response || !response.ok) return [];
      const rawBody = (await new Response(response.body as ReadableStream)
        .json()
        .catch(() => null)) as Array<{
        show?: {
          id?: number;
          name?: string;
          type?: string;
          language?: string;
          premiered?: string;
          genres?: string[];
          summary?: string;
          url?: string;
          image?: { medium?: string; original?: string };
          externals?: { imdb?: string };
        };
      }> | null;
      const shows = (rawBody ?? [])
        .map((entry) => entry.show)
        .filter((show): show is NonNullable<typeof show> => Boolean(show));
      const results = shows.slice(0, 3).map((show) => {
        const year = show.premiered
          ? Number(show.premiered.slice(0, 4))
          : undefined;
        const result: MetadataResult = {
          title: show.name ?? q,
          titleEn: show.name ?? q,
          year: Number.isFinite(year) && year! >= 1900 ? year : undefined,
          mediaType: /game|movie|film/i.test(show.type ?? "") ? "movie" : "tv",
          source: "tvmaze",
          imdbId: show.externals?.imdb ?? undefined,
          poster: show.image?.original ?? show.image?.medium ?? undefined,
          overview: show.summary
            ? show.summary
                .replace(/<[^>]+>/g, " ")
                .replace(/\s+/g, " ")
                .trim()
                .slice(0, 600)
            : undefined,
          genres:
            Array.isArray(show.genres) && show.genres.length
              ? show.genres.join("、")
              : undefined,
        };
        result.standardizedName = stdName(result, opts.originalQuery);
        return result;
      });
      return results;
    },
  ];
  const settled = await Promise.allSettled(
    providers.map((provider) => provider()),
  );
  const results = settled.flatMap((entry) =>
    entry.status === "fulfilled" ? entry.value : [],
  );
  return results.slice(0, 3);
}
