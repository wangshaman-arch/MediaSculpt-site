import type { ChildProcess } from "node:child_process";
import { describe, expect, it, vi } from "vitest";

const { execFile } = vi.hoisted(() => ({
  execFile: vi.fn(
    (
      _file: string,
      _args: string[],
      _options: object,
      callback: (error: Error | null) => void,
    ) => {
      callback(null);
      return undefined;
    },
  ),
}));

vi.mock("node:child_process", () => ({ execFile }));

import { terminateProcessTree } from "./process-termination";

describe("terminateProcessTree", () => {
  it("requests Windows tree termination first (taskkill /T), killing directly only as fallback", () => {
    const child = { pid: 4321, kill: vi.fn() } as unknown as ChildProcess;

    terminateProcessTree(child, "SIGKILL", "win32");

    expect(execFile).toHaveBeenCalledWith(
      "taskkill",
      ["/F", "/T", "/PID", "4321"],
      { windowsHide: true },
      expect.any(Function),
    );
    // taskkill 成功（mock 回调 null）时不再单独 kill：先杀父进程会让子树被孤立，
    // taskkill /T 可能再也找不到它们。
    expect(child.kill).not.toHaveBeenCalled();
  });

  it("falls back to a direct kill when taskkill fails", () => {
    execFile.mockImplementationOnce((_file, _args, _options, callback) => {
      callback(new Error("taskkill failed"));
      return undefined;
    });
    const child = { pid: 5555, kill: vi.fn() } as unknown as ChildProcess;

    terminateProcessTree(child, "SIGKILL", "win32");

    expect(child.kill).toHaveBeenCalledWith("SIGKILL");
  });
});
