import {
  Switch,
  Route,
  Router as WouterRouter,
  Link,
  Redirect,
  useLocation,
} from "wouter";
import {
  QueryClient,
  QueryClientProvider,
  useQueryClient,
} from "@tanstack/react-query";
import {
  useGetConfig,
  getGetConfigQueryKey,
  useUpdateConfig,
  useListJobs,
  getListJobsQueryKey,
} from "@workspace/api-client-react";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import {
  Cpu,
  ListVideo,
  MonitorCog,
  Power,
  SlidersHorizontal,
} from "lucide-react";
import {
  Menubar,
  MenubarContent,
  MenubarItem,
  MenubarMenu,
  MenubarSeparator,
  MenubarTrigger,
} from "@/components/ui/menubar";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import JobDetail from "@/pages/JobDetail";
import BatchConfirmPage from "@/pages/BatchConfirmPage";
import Scan from "@/pages/Scan";
import Settings from "@/pages/Settings";
import Logs from "@/pages/Logs";
import { cn } from "@/lib/utils";
import { useEffect, useState, type CSSProperties, type ReactNode } from "react";
import { I18nProvider, useI18n } from "@/i18n";
import {
  ARCHIVE_PRESET_LS_KEY,
  CUSTOM_PRESET_KEY,
  PRESET_CHANGED_EVENT,
  migrateMediaSculptPresetStorage,
} from "@/lib/brand-storage";
import {
  closeDesktopWindow,
  isMaximizedDesktopWindow,
  isTauriDesktop,
  minimizeDesktopWindow,
  notifyTaskComplete,
  onTauriEvent,
  setDesktopTheme,
  toggleMaximizeDesktopWindow,
} from "@/lib/desktop-bridge";
import { useToast } from "@/hooks/use-toast";
import { hasNavigationGuard, runNavigationGuard } from "@/lib/navigation-guard";
import { LegalInfoDialog } from "@/components/LegalInfoDialog";
import { HelpCenterDialog, type HelpTab } from "@/components/HelpCenterDialog";

const queryClient = new QueryClient();

type AppLanguage = "zh-CN" | "en-US";

function appLanguage(value: unknown): AppLanguage {
  return value === "en-US" ? "en-US" : "zh-CN";
}

function applyTheme(themeMode: string | null | undefined) {
  const root = document.documentElement;
  const light = themeMode === "morning-light";
  root.classList.toggle("dark", !light);
  root.classList.toggle("light", light);
  root.classList.toggle("theme-morning-light", light);
  root.dataset.theme = light ? "morning-light" : "deep-ocean";
}

type AppVersion = {
  releaseId: string;
  softwareVersion?: string;
};

function useAppVersion(): AppVersion | null {
  const [version, setVersion] = useState<AppVersion | null>(null);
  useEffect(() => {
    fetch("/api/runtime/version")
      .then((response) => (response.ok ? response.json() : null))
      .then((body) => {
        if (body?.releaseId) setVersion(body);
      })
      .catch(() => {});
  }, []);
  return version;
}

function TopToggleButton({
  label,
  icon,
  checked,
  onToggle,
}: {
  label: string;
  icon: ReactNode;
  checked: boolean;
  onToggle: () => void;
}) {
  const { t } = useI18n();
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onDoubleClick={onToggle}
      title={`${label}（${t("common.doubleClickToToggle")}）`}
      data-testid={checked ? "top-toggle-on" : "top-toggle-off"}
      className={cn(
        "group relative flex min-w-[104px] flex-col items-center justify-center gap-1.5 rounded-2xl border px-3 py-2 text-center transition-all",
        "border-border/70 bg-secondary/20 text-muted-foreground hover:border-primary/30 hover:bg-secondary/50 hover:text-foreground",
      )}
    >
      <span className="flex items-center gap-1.5 text-xs font-medium leading-tight">
        {icon}
        <span>{label}</span>
      </span>
      <span
        className={cn(
          "relative inline-flex h-4 w-7 shrink-0 items-center rounded-full border transition-all",
          checked
            ? "border-transparent bg-primary shadow-[0_0_10px_hsl(var(--primary)/0.9)]"
            : "border-border bg-input",
        )}
      >
        <span
          className={cn(
            "pointer-events-none block h-3 w-3 rounded-full bg-background shadow transition-transform",
            checked ? "translate-x-3.5" : "translate-x-0.5",
          )}
        />
      </span>
    </button>
  );
}

function DesktopWindowControls() {
  const { t } = useI18n();
  const [maximized, setMaximized] = useState(false);
  if (!isTauriDesktop()) return null;

  const refreshMaximized = () => {
    void isMaximizedDesktopWindow()
      .then((value) => setMaximized(Boolean(value)))
      .catch(() => {});
  };
  useEffect(refreshMaximized, []);
  useEffect(() => {
    const onFocus = () => refreshMaximized();
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, []);

  const toggleMaximize = () => {
    setMaximized((value) => !value);
    void toggleMaximizeDesktopWindow().then(refreshMaximized);
  };

  // Windows caption buttons: the Segoe MDL2 Assets Chrome* glyphs are the exact
  // glyphs Windows draws for minimize / maximize / restore / close.
  const glyphStyle = {
    fontFamily: '"Segoe MDL2 Assets","Segoe Fluent Icons",sans-serif',
    fontStyle: "normal",
  } as CSSProperties;

  const controls = [
    {
      label: t("window.minimize"),
      glyph: "\uE921",
      onClick: minimizeDesktopWindow,
      close: false,
    },
    {
      label: t("window.maximize"),
      glyph: maximized ? "\uE923" : "\uE922",
      onClick: toggleMaximize,
      close: false,
    },
    {
      label: t("window.close"),
      glyph: "\uE8BB",
      onClick: closeDesktopWindow,
      close: true,
    },
  ];

  return (
    <div
      data-testid="desktop-window-controls"
      className="flex shrink-0 items-stretch self-stretch"
      style={
        { WebkitAppRegion: "no-drag", pointerEvents: "auto" } as CSSProperties
      }
    >
      {controls.map(({ label, glyph, onClick, close }) => (
        <button
          key={label}
          type="button"
          aria-label={label}
          title={label}
          onPointerDown={(event) => event.stopPropagation()}
          onClick={() => void onClick()}
          className={cn(
            "flex h-full w-[46px] items-center justify-center text-[14px] leading-none text-foreground/80 transition-colors",
            close
              ? "hover:bg-[#c42b1c] hover:text-white"
              : "hover:bg-[rgba(255,255,255,0.09)] hover:text-foreground",
          )}
          style={glyphStyle}
        >
          {glyph}
        </button>
      ))}
    </div>
  );
}

function AppMenu() {
  const [location, setLocation] = useLocation();
  const version = useAppVersion();
  const { data: recentJobs } = useListJobs(
    { limit: 1 },
    {
      query: {
        queryKey: getListJobsQueryKey({ limit: 1 }),
        staleTime: 5_000,
        refetchOnWindowFocus: true,
      },
    },
  );
  const currentJobPath = /^\/jobs\/[^/]+$/.test(location) ? location : null;
  const previewJobId = currentJobPath
    ? currentJobPath.slice("/jobs/".length)
    : recentJobs?.[0]?.id;
  const previewHref = previewJobId ? `/jobs/${previewJobId}` : null;
  const { data: config } = useGetConfig({
    query: { queryKey: getGetConfigQueryKey(), refetchOnWindowFocus: false },
  });
  const updateConfig = useUpdateConfig();
  const queryClient = useQueryClient();
  const language = appLanguage(config?.uiLanguage);
  const { t } = useI18n();
  const [helpOpen, setHelpOpen] = useState(false);
  const [helpTab, setHelpTab] = useState<HelpTab>("quick-start");
  const [legalOpen, setLegalOpen] = useState(false);
  const [legalTab, setLegalTab] = useState<
    "about" | "license" | "third-party" | "privacy" | "rights" | "runtime"
  >("about");
  const workspaceIconClass =
    "flex h-11 w-11 items-center justify-center rounded-2xl border bg-background/70 shadow-inner transition-colors";
  useEffect(() => {
    migrateMediaSculptPresetStorage(window.localStorage);
  }, []);
  const topWorkspaceItems = [
    {
      href: "/workbench",
      label: t("nav.workbench"),
      hint: t("nav.workbenchHint"),
      icon: MonitorCog,
      testId: "workspace-/workbench",
      enabled: true,
      match: (p: string) =>
        p === "/workbench" || p === "/scan" || p === "/workflow",
    },
    {
      href: previewHref ?? "/jobs",
      label: t("nav.settingsPreview"),
      hint: t("nav.settingsPreviewHint"),
      icon: SlidersHorizontal,
      testId: "workspace-/settings-preview",
      enabled: Boolean(previewHref) || location === "/batch",
      match: (p: string) => /^\/jobs\/[^/]+$/.test(p) || p === "/batch",
    },
    {
      href: "/jobs",
      label: t("nav.jobs"),
      hint: t("nav.jobsHint"),
      icon: ListVideo,
      testId: "workspace-/jobs",
      enabled: true,
      match: (p: string) => p === "/jobs",
    },
  ];

  const toggleHighPriority = async () => {
    await updateConfig.mutateAsync({
      data: { processHighPriority: !config?.processHighPriority },
    });
    await queryClient.invalidateQueries({ queryKey: getGetConfigQueryKey() });
  };

  const toggleShutdownAfterComplete = async () => {
    await updateConfig.mutateAsync({
      data: { shutdownAfterComplete: !config?.shutdownAfterComplete },
    });
    await queryClient.invalidateQueries({ queryKey: getGetConfigQueryKey() });
  };

  const exportPresets = () => {
    const payload = {
      archive: localStorage.getItem(ARCHIVE_PRESET_LS_KEY),
      custom: localStorage.getItem(CUSTOM_PRESET_KEY),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "mediasculpt-presets.json";
    link.click();
    URL.revokeObjectURL(url);
  };

  const importPresets = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "application/json";
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      const body = JSON.parse(await file.text()) as {
        archive?: string | null;
        custom?: string | null;
      };
      if (body.archive)
        localStorage.setItem(ARCHIVE_PRESET_LS_KEY, body.archive);
      if (body.custom) localStorage.setItem(CUSTOM_PRESET_KEY, body.custom);
      window.dispatchEvent(new Event(PRESET_CHANGED_EVENT));
      window.alert(t("menu.presetsImported"));
    };
    input.click();
  };

  const go = (path: string) => {
    const [pathname, hash] = path.split("#");
    void runNavigationGuard(path).then((ok) => {
      if (!ok) return;
      setLocation(pathname);
      if (hash) {
        window.setTimeout(() => {
          window.location.hash = hash;
          window.dispatchEvent(new HashChangeEvent("hashchange"));
        }, 0);
      }
    });
  };

  const shutdown = async () => {
    if (isTauriDesktop()) {
      await closeDesktopWindow();
      return;
    }
    try {
      const response = await fetch("/api/shutdown", { method: "POST" });
      if (response.status === 409) {
        const body = (await response.json().catch(() => null)) as {
          error?: string;
        } | null;
        window.alert(body?.error ?? t("menu.exitBlocked"));
        return;
      }
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      window.alert(t("menu.exiting"));
    } catch (error) {
      window.alert(
        `${t("menu.exitFailed")}: ${error instanceof Error ? error.message : String(error)}`,
      );
    }
  };

  const openHelp = (tab: HelpTab) => {
    setHelpTab(tab);
    setHelpOpen(true);
  };

  return (
    <div
      data-testid="desktop-titlebar"
      className="desktop-titlebar sticky top-0 z-40 border-b bg-background/95 text-foreground"
    >
      <div
        className="flex h-9 items-center gap-2 pl-3"
        data-tauri-drag-region
        style={{ WebkitAppRegion: "drag" } as CSSProperties}
      >
        <div className="flex min-w-0 items-center gap-2" data-tauri-drag-region>
          <img src="/mediasculpt-256.png" alt="" className="h-6 w-6 shrink-0" />
          <div className="truncate font-mono text-xs font-semibold tracking-[0.16em] text-foreground">
            {t("brand.desktopTitle")}
          </div>
        </div>
        <Menubar
          className="border-none bg-transparent shadow-none"
          style={{ WebkitAppRegion: "no-drag" } as CSSProperties}
        >
          <MenubarMenu>
            <MenubarTrigger>{t("menu.file")}</MenubarTrigger>
            <MenubarContent>
              <MenubarItem onSelect={() => importPresets()}>
                {t("menu.importPresets")}
              </MenubarItem>
              <MenubarItem onSelect={() => exportPresets()}>
                {t("menu.exportPresets")}
              </MenubarItem>
              <MenubarSeparator />
              <MenubarItem onSelect={() => void shutdown()}>
                {t("menu.exit")}
              </MenubarItem>
            </MenubarContent>
          </MenubarMenu>

          <MenubarMenu>
            <MenubarTrigger>{t("menu.process")}</MenubarTrigger>
            <MenubarContent>
              <MenubarItem onSelect={() => go("/workbench")}>
                {t("menu.openWorkbench")}
              </MenubarItem>
              <MenubarItem onSelect={() => go("/jobs")}>
                {t("nav.jobs")}
              </MenubarItem>
            </MenubarContent>
          </MenubarMenu>

          <MenubarMenu>
            <MenubarTrigger>{t("menu.settings")}</MenubarTrigger>
            <MenubarContent>
              <MenubarItem onSelect={() => go("/settings#directories")}>
                {t("settings.directoriesTitle")}
              </MenubarItem>
              <MenubarItem onSelect={() => go("/settings#compression")}>
                {t("settings.compressionTitle")}
              </MenubarItem>
              <MenubarItem onSelect={() => go("/settings#subtitles")}>
                {t("settings.subtitlesTitle")}
              </MenubarItem>
              <MenubarItem onSelect={() => go("/settings#ai")}>
                {t("settings.aiTitle")}
              </MenubarItem>
              <MenubarItem onSelect={() => go("/settings#tools")}>
                {t("settings.toolsTitle")}
              </MenubarItem>
              <MenubarItem onSelect={() => go("/settings#tuning")}>
                {t("settings.tuningTitle")}
              </MenubarItem>
              <MenubarItem onSelect={() => go("/settings#tuningPrompts")}>
                {t("settings.tuningPromptsTitle")}
              </MenubarItem>
              <MenubarItem onSelect={() => go("/settings#system")}>
                {t("settings.systemTitle")}
              </MenubarItem>
            </MenubarContent>
          </MenubarMenu>

          <MenubarMenu>
            <MenubarTrigger>{t("menu.help")}</MenubarTrigger>
            <MenubarContent>
              <MenubarItem disabled>
                {t("menu.version")}: {version?.softwareVersion ?? "V 0.860"}
              </MenubarItem>
              <MenubarSeparator />
              <MenubarItem onSelect={() => openHelp("quick-start")}>
                {t("menu.quickStart")}
              </MenubarItem>
              <MenubarItem onSelect={() => openHelp("workflow")}>
                {t("menu.workflowHelp")}
              </MenubarItem>
              <MenubarItem onSelect={() => openHelp("compatibility")}>
                {t("menu.compatibility")}
              </MenubarItem>
              <MenubarItem onSelect={() => openHelp("troubleshooting")}>
                {t("menu.troubleshooting")}
              </MenubarItem>
              <MenubarItem
                onSelect={() =>
                  window.open(
                    "https://github.com/wangshaman-arch/MediaSculpt-site/releases",
                    "_blank",
                    "noopener,noreferrer",
                  )
                }
              >
                {t("menu.checkUpdates")}
              </MenubarItem>
              <MenubarSeparator />
              <MenubarItem onSelect={() => go("/logs")}>
                {t("menu.logs")}
              </MenubarItem>
              <MenubarItem
                onSelect={() => {
                  setLegalTab("about");
                  setLegalOpen(true);
                }}
              >
                {t("menu.about")}
              </MenubarItem>
            </MenubarContent>
          </MenubarMenu>
        </Menubar>
        <div
          className="desktop-titlebar-spacer min-w-4 flex-1"
          data-tauri-drag-region
        />
        <DesktopWindowControls />
      </div>
      <div className="mx-auto flex w-full max-w-[1680px] flex-col gap-2 px-3 py-2 sm:px-4 lg:px-6">
        <nav
          data-testid="top-workspace-switcher"
          className="flex flex-wrap items-stretch gap-3"
          style={{ WebkitAppRegion: "no-drag" } as CSSProperties}
        >
          {topWorkspaceItems.map((item) => {
            const isActive = item.match
              ? item.match(location)
              : location === item.href;
            return (
              <Link
                key={item.testId}
                href={item.href}
                onClick={(event) => {
                  if (item.enabled === false) {
                    event.preventDefault();
                    return;
                  }
                  // 有未保存修改时先过导航守卫，避免直接丢弃。
                  if (hasNavigationGuard()) {
                    event.preventDefault();
                    void runNavigationGuard(item.href).then(
                      (ok) => ok && setLocation(item.href),
                    );
                  }
                }}
                data-testid={item.testId}
                title={
                  item.enabled
                    ? item.label
                    : `${item.label} · ${t("nav.settingsPreviewUnavailable")}`
                }
                aria-label={item.label}
                aria-disabled={item.enabled === false}
                className={cn(
                  "group relative flex min-w-0 flex-1 items-center gap-3 rounded-2xl border px-4 py-3 text-left transition-all",
                  item.enabled === false && "cursor-not-allowed opacity-45",
                  isActive
                    ? "border-primary/50 bg-primary/10 text-primary shadow-[0_0_30px_hsl(var(--primary)/0.22)] after:absolute after:inset-x-3 after:bottom-1 after:h-0.5 after:rounded-full after:bg-gradient-to-r after:from-primary after:to-teal-400"
                    : "border-border/70 bg-secondary/20 text-muted-foreground hover:border-primary/30 hover:bg-secondary/50 hover:text-foreground",
                )}
              >
                <span
                  className={cn(
                    workspaceIconClass,
                    isActive
                      ? "vx-icon-chip-active text-primary"
                      : "border-border/70 text-muted-foreground group-hover:text-primary",
                  )}
                >
                  <item.icon className="h-6 w-6 shrink-0" />
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-[15px] font-medium leading-tight">
                    {item.label}
                  </span>
                  <span className="mt-1 hidden truncate text-xs font-normal text-muted-foreground sm:block">
                    {item.hint}
                  </span>
                </span>
              </Link>
            );
          })}
          <TopToggleButton
            label={t("settings.highPriorityShort")}
            icon={<Cpu className="h-4 w-4 shrink-0 text-primary" />}
            checked={Boolean(config?.processHighPriority)}
            onToggle={() => void toggleHighPriority()}
          />
          <TopToggleButton
            label={t("settings.shutdownShortLabel")}
            icon={<Power className="h-4 w-4 shrink-0 text-orange-400" />}
            checked={Boolean(config?.shutdownAfterComplete)}
            onToggle={() => void toggleShutdownAfterComplete()}
          />
        </nav>
      </div>
      <HelpCenterDialog
        open={helpOpen}
        onOpenChange={setHelpOpen}
        defaultTab={helpTab}
      />
      <LegalInfoDialog
        open={legalOpen}
        onOpenChange={setLegalOpen}
        defaultTab={legalTab}
        version={version?.softwareVersion ?? "V 0.860"}
      />
    </div>
  );
}

function Router() {
  const [location] = useLocation();
  const { data: config } = useGetConfig({
    query: { queryKey: getGetConfigQueryKey(), refetchOnWindowFocus: false },
  });
  const language = appLanguage(config?.uiLanguage);
  const isWorkbench =
    location === "/workbench" ||
    location === "/scan" ||
    location === "/workflow";
  useEffect(() => {
    applyTheme(config?.themeMode);
    void setDesktopTheme(config?.themeMode ?? "deep-ocean");
  }, [config?.themeMode]);
  return (
    <I18nProvider lang={language}>
      <BrandDocumentTitle />
      <TaskCompletionWatcher />
      <ShutdownBlockWatcher />
      <div className="flex h-screen w-full flex-col overflow-hidden bg-background">
        <AppMenu />
        <main
          className={cn(
            "app-scroll-shell min-h-0 flex-1",
            isWorkbench || location === "/jobs"
              ? "overflow-hidden"
              : "overflow-y-auto",
          )}
          style={{
            paddingBlock: "clamp(0.75rem, 2.5vh, 2rem)",
            paddingInline: "clamp(0.75rem, 2vw, 2rem)",
          }}
        >
          <div className="mx-auto h-full min-h-0 w-full min-w-0 max-w-[1680px]">
            <Switch>
              <Route path="/">
                <Redirect to="/workbench?tab=workflow" />
              </Route>
              <Route path="/workflow">
                <Redirect to="/workbench?tab=workflow" />
              </Route>
              <Route path="/jobs" component={Dashboard} />
              <Route path="/jobs/:id" component={JobDetail} />
              <Route path="/batch" component={BatchConfirmPage} />
              <Route path="/workbench" component={Scan} />
              <Route path="/scan" component={Scan} />
              <Route path="/settings" component={Settings} />
              <Route path="/logs" component={Logs} />
              <Route component={NotFound} />
            </Switch>
          </div>
        </main>
      </div>
    </I18nProvider>
  );
}

/** 全局任务完成监听：任意页面下任务结束都在任务栏闪烁并弹系统通知。 */
function TaskCompletionWatcher() {
  const { t } = useI18n();
  useEffect(() => {
    const seen = new Map<number, string>();
    let initialized = false;
    const check = async () => {
      try {
        const response = await fetch("/api/jobs");
        if (!response.ok) return;
        const jobs = (await response.json()) as Array<{
          id: number;
          status: string;
          movieTitle?: string | null;
          filePath?: string | null;
        }>;
        for (const job of jobs) {
          const previous = seen.get(job.id);
          seen.set(job.id, job.status);
          if (!initialized || !previous) continue;
          const terminal = job.status === "done" || job.status === "error";
          if (
            terminal &&
            previous !== job.status &&
            previous !== "done" &&
            previous !== "error"
          ) {
            const name =
              job.movieTitle ||
              (job.filePath
                ? (String(job.filePath).split(/[\\/]/).pop() ?? `#${job.id}`)
                : `#${job.id}`);
            void notifyTaskComplete(
              t(
                job.status === "done"
                  ? "menu.notificationTaskDone"
                  : "menu.notificationTaskFailed",
              ),
              t(
                job.status === "done"
                  ? "menu.notificationTaskDoneBody"
                  : "menu.notificationTaskFailedBody",
                { name },
              ),
            );
          }
        }
        initialized = true;
      } catch {
        // 瞬时网络错误忽略，下个周期再试。
      }
    };
    void check();
    const timer = setInterval(() => void check(), 12_000);
    return () => clearInterval(timer);
  }, [t]);
  return null;
}

function BrandDocumentTitle() {
  const { t } = useI18n();
  useEffect(() => {
    document.title = t("brand.documentTitle");
  }, [t]);
  return null;
}

/** 有正在运行的任务时桌面壳阻止关闭：监听事件并给出明确提示。 */
function ShutdownBlockWatcher() {
  const { t } = useI18n();
  const { toast } = useToast();
  useEffect(() => {
    if (!isTauriDesktop()) return;
    const off = onTauriEvent("shutdown-blocked", () => {
      toast({
        title: t("window.shutdownBlockedTitle"),
        description: t("window.shutdownBlockedDesc"),
        variant: "destructive",
      });
    });
    return off;
  }, [t, toast]);
  return null;
}

function App() {
  // Heartbeat — keeps the local API server informed that a browser tab is open.
  // When all tabs close, the server auto-exits after 60 s (dev mode only),
  // releasing file locks so the install directory can be deleted/updated.
  useEffect(() => {
    const ping = () =>
      fetch(`${import.meta.env.BASE_URL}api/ping`, { method: "POST" }).catch(
        () => {},
      );
    ping();
    const id = setInterval(ping, 15_000);
    return () => clearInterval(id);
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
