// Extracted from metadata.ts: IMDb title-suggestion / title-page / local-dataset lookups.
import path from "path";
import { db, imdbTitlesTable, configTable } from "@workspace/db";
import { and, or, between, desc, eq, sql } from "drizzle-orm";
import { fetchLike, resolvePosterProxyUrl } from "./http-client";
import {
  FETCH_TIMEOUT_MS,
  proxyAwareFetch,
  stdName,
  type MetadataResult,
} from "./metadata";

/**
 * Query IMDb's public title-suggestion feed.  This endpoint does not require
 * an API key and, unlike poster-only fallbacks, returns the IMDb tconst and
 * the poster URL as one identity candidate.  It is deliberately best-effort:
 * callers still keep TMDb/OMDb/local/Wikipedia providers in the same lookup.
 */
export async function searchImdbSuggestion(
  searchTitle: string,
  opts: { year?: number; originalQuery: string },
  fetchFn: typeof fetch = fetch,
): Promise<MetadataResult[]> {
  const q = searchTitle.trim();
  if (!q) return [];
  const endpoint = `https://v3.sg.media-imdb.com/suggestion/x/${encodeURIComponent(q)}.json`;
  const response = await fetchFn(endpoint, {
    signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
  });
  if (!response.ok) throw new Error(`IMDb suggestion HTTP ${response.status}`);
  const payload = (await response.json().catch(() => null)) as {
    d?: Array<{
      id?: string;
      l?: string;
      s?: string;
      y?: number | string;
      q?: string;
      i?: { imageUrl?: string };
    }>;
  } | null;
  const compact = (value: string): string =>
    value.toLowerCase().replace(/[^a-z0-9\u3400-\u9fff]/g, "");
  const queryKey = compact(q);
  const targetYear = opts.year;
  const rows = (payload?.d ?? [])
    .flatMap((item, index) => {
      const imdbId = typeof item.id === "string" ? item.id.trim() : "";
      const title = typeof item.l === "string" ? item.l.trim() : "";
      if (!/^tt\d{7,8}$/i.test(imdbId) || !title) return [];
      const parsedYear = Number(item.y);
      const year =
        Number.isFinite(parsedYear) && parsedYear >= 1800
          ? parsedYear
          : undefined;
      const mediaType = /series|tv|episode/i.test(item.q ?? "")
        ? "tv"
        : "movie";
      const poster =
        typeof item.i?.imageUrl === "string" &&
        /^https?:\/\//i.test(item.i.imageUrl)
          ? item.i.imageUrl
          : undefined;
      const titleKey = compact(title);
      const score =
        (titleKey === queryKey
          ? 100
          : titleKey.includes(queryKey) || queryKey.includes(titleKey)
            ? 60
            : 0) +
        (targetYear && year
          ? year === targetYear
            ? 50
            : Math.max(0, 20 - Math.abs(year - targetYear))
          : 0) -
        index / 1000;
      const result: MetadataResult = {
        imdbId,
        title,
        titleEn: title,
        year,
        poster,
        mediaType,
        source: "imdb",
      };
      result.standardizedName = stdName(result, opts.originalQuery);
      return [{ result, score }];
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
    .map((entry) => entry.result);
  return rows;
}

/**
 * Read IMDb's public title JSON-LD when a tconst is already known. The
 * suggestion feed intentionally exposes only identity/poster; the reference
 * page supplies rating, director and genres without requiring an API key.
 * Parsing is best-effort and returns null for blocked/changed pages.
 */
export async function searchImdbTitlePage(
  tconstInput: string,
  opts: { originalQuery: string; proxyUrl?: string | null },
  fetchFn?: typeof fetch,
): Promise<MetadataResult | null> {
  const imdbId = tconstInput.trim();
  if (!/^tt\d{7,8}$/i.test(imdbId)) return null;
  const request = fetchFn ?? proxyAwareFetch(opts.proxyUrl ?? null);
  const response = await request(
    `https://www.imdb.com/title/${encodeURIComponent(imdbId)}/reference/`,
    {
      headers: { Accept: "text/html", "Accept-Language": "en-US,en;q=0.8" },
      signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
    },
  );
  if (!response.ok) return null;
  const html = await response.text();
  const scripts = [
    ...html.matchAll(
      /<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi,
    ),
  ]
    .map((match) => match[1].trim())
    .flatMap((raw) => {
      try {
        const parsed = JSON.parse(raw) as unknown;
        return Array.isArray(parsed) ? parsed : [parsed];
      } catch {
        return [];
      }
    }) as Array<Record<string, unknown>>;
  const json = scripts.find((item) => {
    const type = item["@type"];
    return (
      type === "Movie" ||
      type === "TVSeries" ||
      type === "TVEpisode" ||
      type === "CreativeWork"
    );
  });
  if (!json) return null;
  const names = (value: unknown): string[] =>
    (Array.isArray(value) ? value : [value])
      .flatMap((item) => {
        if (typeof item === "string") return [item.trim()];
        if (
          item &&
          typeof item === "object" &&
          typeof (item as { name?: unknown }).name === "string"
        )
          return [(item as { name: string }).name.trim()];
        return [];
      })
      .filter(Boolean);
  const aggregateRating = json.aggregateRating as
    | { ratingValue?: unknown; ratingCount?: unknown }
    | undefined;
  const ratingValue = Number(aggregateRating?.ratingValue);
  const ratingVotes = Number(aggregateRating?.ratingCount);
  const datePublished =
    typeof json.datePublished === "string" ? json.datePublished : "";
  const year = /^\d{4}/.test(datePublished)
    ? Number(datePublished.slice(0, 4))
    : undefined;
  const title =
    typeof json.name === "string" ? json.name.trim() : opts.originalQuery;
  const image =
    typeof json.image === "string" && /^https?:\/\//i.test(json.image)
      ? json.image
      : undefined;
  const result: MetadataResult = {
    imdbId,
    title,
    titleEn: title,
    year,
    rating:
      Number.isFinite(ratingValue) && ratingValue > 0 ? ratingValue : undefined,
    ratingSource: "imdb",
    ratingVotes: Number.isFinite(ratingVotes) ? ratingVotes : undefined,
    director: names(json.director).join("、") || undefined,
    genres: names(json.genre).join("、") || undefined,
    poster: image,
    mediaType:
      json["@type"] === "TVSeries" || json["@type"] === "TVEpisode"
        ? "tv"
        : "movie",
    source: "imdb",
  };
  result.standardizedName = stdName(result, opts.originalQuery);
  return result;
}

// ─── Local IMDb dataset ───────────────────────────────────────────────────────

export async function searchImdbLocal(
  searchTitle: string,
  opts: { year?: number; originalQuery: string },
): Promise<MetadataResult[]> {
  const q = searchTitle.trim();
  if (!q) return [];
  const like = `%${q}%`;

  const rows = await db
    .select()
    .from(imdbTitlesTable)
    .where(
      and(
        or(
          // lower() + LIKE is portable across SQLite and Postgres (ilike is
          // not valid SQL on SQLite)
          sql`lower(${imdbTitlesTable.primaryTitle}) like lower(${like})`,
          sql`lower(${imdbTitlesTable.originalTitle}) like lower(${like})`,
        ),
        // DVD releases can carry the year of a re-release, so allow ±1
        opts.year
          ? between(imdbTitlesTable.startYear, opts.year - 1, opts.year + 1)
          : undefined,
      ),
    )
    .orderBy(
      sql`CASE WHEN lower(${imdbTitlesTable.primaryTitle}) = lower(${q})
                 OR lower(${imdbTitlesTable.originalTitle}) = lower(${q})
            THEN 0 ELSE 1 END`,
      desc(sql`coalesce(${imdbTitlesTable.votes}, 0)`),
    )
    .limit(5);

  return rows.map((r: (typeof rows)[number]) => {
    const result: MetadataResult = {
      imdbId: r.tconst,
      title: r.primaryTitle,
      titleEn: r.originalTitle,
      year: r.startYear ?? undefined,
      rating: r.rating ?? undefined,
      ratingSource: "imdb",
      ratingVotes: r.votes ?? undefined,
      runtimeMinutes: r.runtimeMinutes ?? undefined,
      director: r.directors ?? undefined,
      cast: r.cast ?? undefined,
      genres: r.genres ? r.genres.split(",").join("、") : undefined,
      mediaType: /Series/i.test(r.titleType) ? "tv" : "movie",
      source: "imdb",
    };
    result.standardizedName = stdName(result, opts.originalQuery);
    return result;
  });
}

/**
 * 精确按 IMDb 号（tconst）查询本地 IMDb 库。当模糊查找（同名异年、发布标签污染）
 * 难以区分时，用户提供确定的 IMDb 号可直接锁定唯一身份。
 */
export async function searchImdbByTconst(
  tconstInput: string,
  opts: { originalQuery?: string } = {},
): Promise<MetadataResult | null> {
  const id = (tconstInput || "").trim();
  if (!/^tt\d+$/i.test(id)) return null;
  const rows = await db
    .select()
    .from(imdbTitlesTable)
    .where(eq(imdbTitlesTable.tconst, id))
    .limit(1);
  const row = rows[0];
  if (!row) return null;
  const result: MetadataResult = {
    imdbId: row.tconst,
    title: row.primaryTitle,
    titleEn: row.originalTitle,
    year: row.startYear ?? undefined,
    rating: row.rating ?? undefined,
    ratingSource: "imdb",
    ratingVotes: row.votes ?? undefined,
    runtimeMinutes: row.runtimeMinutes ?? undefined,
    director: row.directors ?? undefined,
    cast: row.cast ?? undefined,
    genres: row.genres ? row.genres.split(",").join("、") : undefined,
    mediaType: /Series/i.test(row.titleType) ? "tv" : "movie",
    source: "imdb",
  };
  result.standardizedName = stdName(
    result,
    opts.originalQuery ?? row.primaryTitle ?? "",
  );
  return result;
}
