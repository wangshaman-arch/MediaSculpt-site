import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

/**
 * 全软件唯一的“设置与预览”外壳（助手竖排右侧栏）。
 * 所有“选源后的详细设置 + 预览”界面（任务详情、批量创建等）都必须复用它，
 * 以保证只有一种布局；任何布局改动只在这里发生。
 *
 * 结构：标题栏 / [ 预览列(身份槽 + 预览) | 右侧栏(助手 + 页面补充内容) ]
 */
export function SettingsPreviewShell({
  header,
  toolbar,
  toolbarTestId,
  preview,
  sidebar,
  sidebarHidden = false,
  sidebarTestId,
  testId,
}: {
  /** 顶部标题/动作栏 */
  header: ReactNode;
  /** 预览上方的槽位（影片身份编辑器会被 portal 到这里） */
  toolbar?: ReactNode;
  /** 上方槽位容器的 data-testid */
  toolbarTestId?: string;
  /** 中部预览区 */
  preview: ReactNode;
  /** 右侧栏内容（智能助手 + 页面补充内容） */
  sidebar: ReactNode;
  /** 为 true 时折叠为单列（详情页“详情”开关用），默认 false */
  sidebarHidden?: boolean;
  sidebarTestId?: string;
  testId?: string;
}) {
  return (
    <div
      className="mx-auto flex h-full min-h-0 w-full min-w-0 max-w-full flex-col gap-3 overflow-hidden"
      data-testid={testId}
    >
      {header}
      <div
        className={cn(
          "grid min-h-0 min-w-0 flex-1 gap-3",
          sidebarHidden
            ? "grid-cols-1 md:grid-rows-1"
            : "md:grid-cols-[minmax(0,1fr)_minmax(19rem,23rem)] md:grid-rows-1",
        )}
      >
        <div className="flex min-h-0 min-w-0 flex-col gap-2">
          {toolbar !== undefined && (
            <div
              className="flex shrink-0 flex-col gap-2 rounded-lg border bg-card/40 px-2 py-1.5"
              data-testid={toolbarTestId}
            >
              {toolbar}
            </div>
          )}
          <div className="relative flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden">
            {preview}
          </div>
        </div>

        <aside
          className={cn(
            "min-h-0 min-w-0 flex-col overflow-hidden rounded-lg border bg-card/30",
            sidebarHidden ? "hidden" : "flex",
          )}
          data-testid={sidebarTestId}
        >
          {sidebar}
        </aside>
      </div>
    </div>
  );
}
