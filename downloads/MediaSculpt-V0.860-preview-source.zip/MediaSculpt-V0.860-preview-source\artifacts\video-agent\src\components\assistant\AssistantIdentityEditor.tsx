import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { cn } from "@/lib/utils";
import type { AssistantPreferences } from "../AssistantPanel";
import { YEAR_PLACEHOLDER } from "./assistant-panel-model";

type Translate = (
  path: string,
  params?: Record<string, string | number>,
) => string;

export function AssistantIdentityEditor({
  t,
  prefs,
  updatePrefs,
  onImdbInput,
  unverifiedImdbId,
  inputImdbId,
  contextType,
  workflowIdentity,
  contextSourceName,
  currentYear,
  effectivePoster,
  onPosterOpen,
}: {
  t: Translate;
  prefs: AssistantPreferences;
  updatePrefs: (patch: Partial<AssistantPreferences>) => void;
  onImdbInput: (value: string) => void;
  unverifiedImdbId: string | null;
  inputImdbId: string;
  contextType: "workflow" | "job";
  workflowIdentity: { title?: string } | undefined;
  contextSourceName: string;
  currentYear: number;
  effectivePoster: string | null;
  onPosterOpen: () => void;
}) {
  const yearEditor = (
    <div className="flex shrink-0 items-center gap-1">
      <span className="mx-1 text-[10px] text-muted-foreground">
        {t("assistant.yearField")}
      </span>
      <button
        type="button"
        className="h-7 w-7 rounded border text-xs"
        onClick={() =>
          updatePrefs({
            year: Math.max(1920, (prefs.year ?? YEAR_PLACEHOLDER) - 1),
          })
        }
        aria-label={`${t("assistant.yearField")} − 1`}
      >
        −
      </button>
      <button
        type="button"
        title={t("assistant.clearYear")}
        onClick={() => updatePrefs({ year: null })}
        className={cn(
          "w-12 shrink-0 cursor-pointer text-center text-xs font-mono",
          prefs.year == null ? "text-muted-foreground/60" : "text-foreground",
        )}
      >
        {prefs.year ?? YEAR_PLACEHOLDER}
      </button>
      <button
        type="button"
        className="h-7 w-7 rounded border text-xs"
        onClick={() =>
          updatePrefs({
            year: Math.min(currentYear, (prefs.year ?? YEAR_PLACEHOLDER) + 1),
          })
        }
        aria-label={`${t("assistant.yearField")} + 1`}
      >
        ＋
      </button>
    </div>
  );
  const imdbEditor = (
    <label
      className="flex min-w-0 shrink-0 items-center gap-1 text-[10px] text-muted-foreground"
      title={t("assistant.imdbHint")}
    >
      <span className="font-medium text-amber-400/80">IMDb</span>
      <Input
        value={prefs.imdbId}
        onChange={(e) => {
          onImdbInput(e.currentTarget.value.trim());
        }}
        placeholder="tt0000000"
        className={cn(
          "h-7",
          "w-[6.5rem] min-w-0 px-1.5 font-mono text-[10px]",
          unverifiedImdbId &&
            inputImdbId === unverifiedImdbId &&
            "border-amber-400/60",
        )}
        aria-label={t("assistant.imdbField")}
      />
      {unverifiedImdbId && inputImdbId === unverifiedImdbId && (
        <span className="shrink-0 text-[9px] text-amber-400/90">
          {t("assistant.metadataUnverified")}
        </span>
      )}
    </label>
  );
  const posterControl = effectivePoster ? (
    <button
      type="button"
      onClick={onPosterOpen}
      title={t("assistant.posterClickToEnlarge")}
      className="group relative shrink-0"
    >
      <img
        src={effectivePoster}
        alt={t("assistant.posterPreview")}
        className="h-16 w-11 shrink-0 rounded object-cover transition-transform group-hover:scale-[1.03]"
      />
      <span className="absolute inset-0 flex items-center justify-center rounded bg-black/0 text-white opacity-0 transition group-hover:bg-black/30 group-hover:opacity-100">
        <Search className="h-4 w-4" />
      </span>
    </button>
  ) : (
    <div className="flex h-16 w-11 shrink-0 items-center justify-center rounded bg-secondary/60 text-xl">
      🎬
    </div>
  );
  return (
    <div
      className="flex min-w-0 flex-1 items-center gap-3"
      data-testid="assistant-identity-editor"
    >
      {posterControl}
      <div className="flex min-w-0 flex-1 flex-col justify-center gap-1">
        <div
          className="flex min-w-0 items-center gap-1"
          data-testid="assistant-title-year-row"
        >
          <span className="w-10 shrink-0 text-[10px] text-muted-foreground">
            {t("assistant.titleEnField")}
          </span>
          <Input
            value={prefs.titleEn}
            onChange={(e) => updatePrefs({ titleEn: e.currentTarget.value })}
            placeholder={t("assistant.titleEnPlaceholder")}
            className="h-7 min-w-0 flex-1 text-xs"
            aria-label={t("assistant.titleEnField")}
          />
          {yearEditor}
        </div>
        <div
          className="flex min-w-0 items-center gap-1"
          data-testid="assistant-title-imdb-row"
        >
          <span className="w-10 shrink-0 text-[10px] text-muted-foreground">
            {t("assistant.titleZhField")}
          </span>
          <Input
            value={prefs.titleZh}
            onChange={(e) => updatePrefs({ titleZh: e.currentTarget.value })}
            placeholder={t("assistant.titleZhPlaceholder")}
            className="h-7 min-w-0 flex-1 text-xs"
            aria-label={t("assistant.titleZhField")}
          />
          {contextType === "workflow" &&
            typeof workflowIdentity?.title === "string" &&
            workflowIdentity.title.trim() && (
              <Button
                type="button"
                size="sm"
                variant="outline"
                className="h-7 shrink-0 px-2 text-[11px]"
                onClick={() =>
                  updatePrefs({ titleZh: String(workflowIdentity.title) })
                }
              >
                {t("assistant.usePlanTitle")}
              </Button>
            )}
          {imdbEditor}
        </div>
        {contextSourceName && (
          <p
            className="min-w-0 truncate text-[10px] text-muted-foreground/80"
            title={contextSourceName}
          >
            {t("assistant.sourceLabel")}
            <span className="ml-1 font-mono text-foreground/70">
              {contextSourceName}
            </span>
          </p>
        )}
      </div>
    </div>
  );
}
