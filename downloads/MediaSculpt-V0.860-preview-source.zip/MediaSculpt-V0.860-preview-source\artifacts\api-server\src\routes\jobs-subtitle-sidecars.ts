// Extracted from routes/jobs.ts: subtitle sidecar staging and ASS PlayRes fixing.
import { Router, type Response } from "express";
import os from "os";
import { createHash } from "node:crypto";
import { db, jobsTable, jobLogsTable, configTable } from "@workspace/db";
import { eq, desc, asc, and, inArray, sql } from "drizzle-orm";
import type { ChildProcess } from "child_process";
import {
  ListJobsQueryParams,
  CreateJobBody,
  ScanDirectoryBody,
  GetJobParams,
  DeleteJobParams,
  StartJobParams,
  RetryJobParams,
  CancelJobParams,
  GetJobLogsParams,
} from "@workspace/api-zod";
import { spawn } from "child_process";
import path from "path";
import fs from "fs/promises";
import fsSync from "fs";
import { trackJobOutputFile } from "../infrastructure/job-output-tracker";
import {
  lookupAll,
  metadataIdentityMatches,
  normalizeTitleEn,
} from "../lib/metadata";
import {
  servePreviewSegment,
  cleanupPreviewSegments,
} from "../lib/preview-segments";
import { buildSourceManifest } from "../lib/source-manifest";
import { validateRemuxOutput } from "../lib/remux-validation";
import { buildSelectedChapterMetadata } from "../lib/remux-chapters";
import { buildRemuxCopyArgs, buildRemuxMapArgs } from "../lib/remux-mapping";
import {
  buildFfconcatFileContent as buildManifest,
  buildFfconcatChapterContent,
  buildFfconcatTimedContent,
  type FfconcatTimedSegment,
} from "../lib/ffconcat";
import { mapBlurayChaptersToSegments } from "../lib/bluray-chapters";
import {
  appendJobRuntimeLog,
  appendJobToolOutput,
} from "../lib/job-runtime-log";
import {
  appendRuntimeToolLog,
  appendRuntimeToolOutput,
} from "../lib/runtime-tool-log";
import { parseBlurayChapters, scanBlurayPlaylists } from "../lib/disc";
import { scanHandBrakeTitles } from "../lib/handbrake-scan";
import {
  buildCompressionOutputName,
  buildRemuxOutputName,
  cleanSegment,
  encoderBitDepth,
  selectBestAudioTrack,
} from "../lib/output-naming";
import {
  defaultRemuxOutputDirectory,
  mapExternalToolProgress,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
  type WorkflowProcessingMode,
} from "../lib/job-workflow";
import { parseHandBrakeSelectionPlan } from "../lib/handbrake-compression-args";
import { gradeCompressionOutput } from "../lib/compression-validation";
import {
  renderBilingualAss,
  DEFAULT_BILINGUAL_STYLE,
  type BilingualAssStyle,
  type SubtitleBlock,
} from "../lib/bilingual-subtitle";
import { resolveToolPath } from "../lib/tool-runtime";
import {
  ensureLocalPoster,
  MEDIA_INFO_DIR,
  POSTER_META_FILE,
  posterIdentityMatches,
} from "../lib/poster";
import {
  ensureFasterWhisperModel,
  ensureWhisperCliScript,
} from "../lib/whisper-runtime";
import { runSubtitleOcr, type OcrEngine } from "../lib/subtitle-ocr";
import {
  hasValidSubtitleCues,
  isGraphicSubtitleCodec,
  shouldFallbackToWhisper,
} from "../lib/subtitle-utils";
import {
  analyzeDiscSource,
  buildDiscAnalysisCacheKey,
  buildDiscSourceFingerprint,
  buildFfprobeAnalysisArgs,
  DiscAnalysisCache,
  fillStreamSizeEstimates,
  normalizeDiscSourcePath,
  persistDiscAnalysisDiagnostics,
  summarizeDiscDiagnostics,
  type DiscAnalysisResult,
} from "../lib/disc-analysis";
import {
  buildDvdRemuxArgs,
  runDvdRemux,
  verifyDvdTitle,
} from "../lib/dvd-remux";
import { buildDvdStreamUid } from "../lib/dvd-manifest";
import { mapDvdTitleSizes } from "../lib/dvd-size-estimate";
import { assessDiscComplexity } from "../lib/disc-complexity";
import {
  buildDvdStructurePayload,
  resolveRemuxPlanWithLlm,
  validateRemuxPlan,
} from "../lib/dvd-llm";
import { buildDvdSmartManifest } from "../lib/dvd-smart-manifest";
import { ensureLibdvdcss } from "../lib/libdvdcss";
import { resolveExistingOpenDirectory } from "../lib/open-path";
import { resolveAiEndpoint, resolveApiKey } from "../lib/ai-provider";
import {
  assertPreviewTaskAllowed,
  recordPreviewAiCall,
  settlePreviewTask,
} from "../lib/preview-runtime";
import type { PreviewJobSettlementInput } from "../lib/preview-job-settlement";
import { isPreviewLimitError } from "../lib/preview-entitlement";
import {
  parseCustomTuning,
  resolveLogicPlaceholders,
} from "../lib/custom-tuning";
import {
  decryptSecret,
  encryptSecret,
  isEncryptedSecret,
} from "../lib/secrets";
import {
  ffmpegPath,
  resolveOutputDir,
  resolveRuntimePath,
  type RuntimePathConfig,
} from "../lib/runtime-paths";
import { jobProcessController } from "../infrastructure/job-process-controller";
import { BoundedOutput, processRunner } from "../infrastructure/process-runner";
import { jobToolExecutor } from "../application/job-tool-executor";
import { JobRunner } from "../application/job-runner";
import { JobService } from "../application/job-service";
import {
  assertCompleteMediaTitle,
  createDvdMediaTitle,
} from "../media/dvd-source";
import { executeDvdRemux } from "../media/remux-service";
import { buildRemuxCommandPlan } from "../media/remux-pipeline";
import { buildMediaPipelineManifestFromSnapshot } from "../media/task-snapshot-manifest";
import {
  buildPreviewTranscodeArgs,
  isPreviewVideoCandidate,
  previewService,
} from "../media/preview-service";
import { buildHandBrakeCompressionArgs } from "../media/compression-service";
import {
  alignEnglishReference,
  parseSrt,
  readSubtitleBlocks,
  renderSrt,
  renderSrtSimplified,
  srtStartMs,
  toSubtitleBlocks,
  type SrtBlock,
} from "../media/subtitle-service";
import {
  createStandaloneTaskSnapshotV1,
  DiscAnalysisRegistry,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotJobCreationRequest,
  type TaskSnapshotOutputMode,
  type TaskSnapshotV1,
} from "../lib/task-snapshot";
import {
  type DvdTitle,
  dvdTitleInputArgs,
  parseBlurayMpls,
  isBlurayDisc as isBlurayDiscSource,
  isDvdDisc as isDvdDiscSource,
  resolveDvdHandbrakeInputForIfo,
  resolveDvdTitleForIfo,
  resolveDvdTitleForSource,
  resolveDvdVideoInputPath,
  resolveDvdVideoTsDir,
  resolveMainTrack as resolveDiscMainTrack,
} from "../lib/disc";
import { addLog } from "../lib/job-logging";
import { probeStreams } from "./jobs-probe";

/**
 * 把生成的字幕 sidecar（.ass / .zhs.srt / .ocr.srt 等）复制到视频输出文件旁边，
 * 并以输出文件的基础名命名，播放器即可自动加载外挂字幕（不内嵌进 MKV）。
 * 空文件跳过；复制失败只告警，不阻断任务。
 */
export async function stageSubtitleSidecars(
  jobId: number,
  outputFile: string,
  subtitlePath: string | null,
  translatedSubtitlePath: string | null,
  addLog: (level: "info" | "warn" | "error", message: string) => Promise<void>,
  graphicSubtitlePaths: readonly string[] = [],
): Promise<void> {
  try {
    const outputBase = path.basename(outputFile, path.extname(outputFile));
    const outputDir = path.dirname(outputFile);
    const staged = new Set<string>();
    const copyCandidate = async (source: string, suffix: string) => {
      if (!source) return;
      const stat = await fs.stat(source).catch(() => null);
      if (!stat || stat.size === 0) return; // 空文件不落盘
      const target = path.join(outputDir, `${outputBase}${suffix}`);
      if (staged.has(target) || path.resolve(target) === path.resolve(source))
        return;
      trackJobOutputFile(jobId, target);
      await fs.copyFile(source, target);
      staged.add(target);
      await addLog("info", `字幕已输出到视频旁（自动加载）：${target}`);
    };
    if (subtitlePath) {
      await copyCandidate(subtitlePath, path.extname(subtitlePath));
    }
    if (translatedSubtitlePath) {
      const translatedStem = path.basename(
        translatedSubtitlePath,
        path.extname(translatedSubtitlePath),
      );
      await copyCandidate(
        translatedSubtitlePath,
        path.extname(translatedSubtitlePath),
      );
      // 同源目录里与双语/翻译字幕同名的其他 sidecar（.zhs.srt / .zhs.ass 等）一起带过去
      const siblings = await fs
        .readdir(path.dirname(translatedSubtitlePath))
        .catch(() => [] as string[]);
      for (const name of siblings) {
        if (!name.startsWith(`${translatedStem}.`)) continue;
        if (!/\.(srt|ass|vtt)$/i.test(name)) continue;
        const suffix = `.${name.slice(translatedStem.length + 1)}`;
        await copyCandidate(
          path.join(path.dirname(translatedSubtitlePath), name),
          suffix,
        );
      }
    }
    for (const source of graphicSubtitlePaths) {
      const extension = path.extname(source).toLowerCase();
      if (extension !== ".sup" && extension !== ".mkv") continue;
      const sourceName = path.basename(source);
      const sourceExt = path.extname(sourceName);
      const sourceStem = path.basename(sourceName, sourceExt);
      const suffix = /\.graphic(?:-\d+)?$/i.test(sourceStem)
        ? `${sourceStem.slice(sourceStem.toLowerCase().lastIndexOf(".graphic"))}${sourceExt}`
        : sourceStem.startsWith(`${outputBase}.`)
          ? `${sourceStem.slice(outputBase.length)}${sourceExt}`
          : `.graphic${sourceExt}`;
      await copyCandidate(source, suffix);
    }
  } catch (error) {
    await addLog(
      "warn",
      `字幕 sidecar 输出失败：${error instanceof Error ? error.message : String(error)}`,
    );
  }
}

/**
 * 输出文件生成后，按输出视频的实际显示宽高比（DAR）修正双语 ASS 的 PlayResX
 * （PlayResY 保持 288，字号按高度比例不变）。这样播放器按 1:1 等比缩放，
 * 字幕文字的高宽比被锁死，不会随视频/屏幕宽高比变化而变形。
 * 源盘 DAR 与输出 DAR 不一致时（例如 4:3 源压缩到 16:9 帧）尤为重要。
 */
export async function fixAssPlayResForOutput(
  outputFile: string,
  assPath: string | null,
  addLog: (level: "info" | "warn" | "error", message: string) => Promise<void>,
): Promise<void> {
  if (!assPath || !/\.ass$/i.test(assPath)) return;
  try {
    const probe = await probeStreams(outputFile);
    const video = probe.streams.find(
      (stream) => stream.codecType === "video" && !stream.attachedPicture,
    );
    if (!video?.width || !video?.height) return;
    let dar: number | null = null;
    const ratio = video.displayAspectRatio ?? null;
    if (ratio) {
      const [width, height] = ratio.split(":").map(Number);
      if (
        Number.isFinite(width) &&
        Number.isFinite(height) &&
        width > 0 &&
        height > 0
      )
        dar = width / height;
    }
    if (dar == null) {
      let sar = 1;
      if (video.sampleAspectRatio) {
        const [sw, sh] = video.sampleAspectRatio.split(":").map(Number);
        if (Number.isFinite(sw) && Number.isFinite(sh) && sw > 0 && sh > 0)
          sar = sw / sh;
      }
      if (video.width && video.height) dar = (video.width * sar) / video.height;
    }
    if (dar == null || !Number.isFinite(dar) || dar <= 0.25 || dar >= 4) return;
    const playResX = Math.round(288 * dar);
    const content = await fs.readFile(assPath, "utf8");
    const updated = content.replace(/^(PlayResX:\s*)\d+/m, `$1${playResX}`);
    if (updated !== content) {
      await fs.writeFile(assPath, updated, "utf8");
      await addLog(
        "info",
        `双语 ASS 已按输出画面比例锁定（PlayResX=${playResX}×288，DAR=${dar.toFixed(3)}）`,
      );
    }
  } catch (error) {
    await addLog(
      "warn",
      `双语 ASS 画面比例修正失败：${error instanceof Error ? error.message : String(error)}`,
    );
  }
}
