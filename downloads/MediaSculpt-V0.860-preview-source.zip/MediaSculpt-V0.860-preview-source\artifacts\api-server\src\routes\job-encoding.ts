// Compression-output validation and lossless Remux argument building.
// Extracted from routes/jobs.ts.
import fs from "fs/promises";
import { addLog } from "../lib/job-logging";
import { gradeCompressionOutput } from "../lib/compression-validation";
import { probeStreams } from "./jobs-probe";

export async function validateCompressionOutput(input: {
  jobId: number;
  outputFile: string;
  expectedDurationSeconds?: number | null;
  expectedStreamCounts?: { video: number; audio: number; subtitle: number };
  expectedChapterCount?: number | null;
  requiredAudioCount?: number;
}): Promise<{ fileSize: number; durationSeconds: number | null }> {
  const {
    jobId,
    outputFile,
    expectedDurationSeconds,
    expectedStreamCounts,
    expectedChapterCount,
    requiredAudioCount = 0,
  } = input;
  try {
    const stat = await fs.stat(outputFile);
    if (!stat.isFile() || stat.size < 1024) {
      throw new Error("压缩输出文件不存在或为空");
    }

    let durationSeconds: number | null = null;
    try {
      const probe = await probeStreams(outputFile);
      durationSeconds = probe.duration ?? null;
      const grade = gradeCompressionOutput({
        probe: {
          durationSeconds,
          streams: probe.streams,
          chapters: probe.chapters,
        },
        expectedDurationSeconds,
        expectedVideoCount: expectedStreamCounts?.video ?? 1,
        expectedAudioCount: expectedStreamCounts?.audio ?? 0,
        requiredAudioCount,
        expectedSubtitleCount: expectedStreamCounts?.subtitle ?? 0,
        expectedChapterCount: expectedChapterCount ?? 0,
      });
      for (const warning of grade.warnings)
        await addLog(jobId, "warn", `压缩后置校验警告：${warning}`);
      if (grade.errors.length > 0) {
        throw new Error(
          `HandBrake 已成功退出，但后置校验失败：${grade.errors.join("；")}`,
        );
      }
    } catch (error) {
      if (error instanceof Error && error.message.includes("后置校验失败"))
        throw error;
      await addLog(
        jobId,
        "warn",
        `压缩输出时长校验无法完成：${error instanceof Error ? error.message : String(error)}`,
      );
    }

    return { fileSize: stat.size, durationSeconds };
  } catch (error) {
    await addLog(
      jobId,
      "error",
      `压缩输出校验失败：${error instanceof Error ? error.message : String(error)}`,
    );
    throw error;
  }
}

/**
 * Build lossless Remux args for Blu-ray/DVD sources.  Everything is copied
 * except `pcm_bluray` audio: MKV has no codec tag for Blu-ray LPCM, so those
 * tracks are transcoded losslessly to pcm_s24le (same sample values, MKV-safe).
 */
export async function buildLosslessRemuxArgs(
  probeTarget: string,
  inputArgs?: string[],
  selectedStreams?: number[] | null,
): Promise<{ args: string[]; transcodedPcmBluray: boolean }> {
  const probe = await probeStreams(probeTarget, inputArgs);
  const args = ["-dn", "-ignore_unknown", "-avoid_negative_ts", "make_zero"];
  // Honour the user's stream selection: map only the selected indexes. Without
  // this the Blu-ray Remux copied every track regardless of what was picked.
  const wanted =
    selectedStreams && selectedStreams.length > 0
      ? new Set(selectedStreams)
      : null;
  let audioOutIndex = 0;
  let transcodedPcmBluray = false;
  for (const stream of probe.streams) {
    if (wanted && !wanted.has(stream.index)) continue;
    args.push("-map", `0:${stream.index}`);
    if (stream.codecType === "audio") {
      if (stream.codecName === "pcm_bluray") {
        args.push(`-c:a:${audioOutIndex}`, "pcm_s24le");
        transcodedPcmBluray = true;
      } else {
        args.push(`-c:a:${audioOutIndex}`, "copy");
      }
      audioOutIndex += 1;
    } else if (stream.codecType === "video") {
      args.push("-c:v", "copy");
    } else if (stream.codecType === "subtitle") {
      args.push("-c:s", "copy");
    }
  }
  return { args, transcodedPcmBluray };
}
