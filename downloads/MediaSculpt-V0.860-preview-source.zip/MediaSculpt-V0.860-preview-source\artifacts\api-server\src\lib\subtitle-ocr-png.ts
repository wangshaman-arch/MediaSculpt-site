// Extracted from subtitle-ocr.ts: minimal RGBA PNG encoder/decoder.
import { deflateSync, inflateSync } from "node:zlib";

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (const byte of buf) c = CRC_TABLE[(c ^ byte) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function pngChunk(type: string, data: Buffer): Buffer {
  const typeBuf = Buffer.from(type, "ascii");
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crc]);
}

export function encodePng(rgba: Buffer, width: number, height: number): Buffer {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // color type RGBA
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y += 1) {
    raw[y * (width * 4 + 1)] = 0;
    rgba.copy(raw, y * (width * 4 + 1) + 1, y * width * 4, (y + 1) * width * 4);
  }
  const idat = deflateSync(raw);
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    pngChunk("IHDR", ihdr),
    pngChunk("IDAT", idat),
    pngChunk("IEND", Buffer.alloc(0)),
  ]);
}

/**
 * VobSub/PGS subtitle bitmaps are white text with a dark outline on a
 * transparent canvas. Tesseract performs poorly on that representation, so we
 * premultiply alpha onto black and invert: black glyphs on a white background.
 */
export function toBlackOnWhite(
  rgba: Buffer,
  width: number,
  height: number,
): Buffer {
  const out = Buffer.alloc(width * height * 4);
  for (let i = 0; i < width * height; i += 1) {
    const o = i * 4;
    const a = rgba[o + 3] / 255;
    const lum =
      0.299 * rgba[o] * a + 0.587 * rgba[o + 1] * a + 0.114 * rgba[o + 2] * a;
    const v = Math.max(0, Math.min(255, Math.round(255 - lum)));
    out[o] = v;
    out[o + 1] = v;
    out[o + 2] = v;
    out[o + 3] = 255;
  }
  return out;
}

/** Decode an 8-bit RGBA PNG into a raw RGBA buffer (for subtitle frames). */
export function decodePngRgba(buffer: Buffer): {
  width: number;
  height: number;
  rgba: Buffer;
} {
  if (buffer.length < 33 || buffer.readUInt32BE(0) !== 0x89504e47)
    throw new Error("无效的 PNG 文件");
  let width = 0;
  let height = 0;
  let bitDepth = 0;
  let colorType = 0;
  const idat: Buffer[] = [];
  let offset = 8;
  while (offset + 8 <= buffer.length) {
    const length = buffer.readUInt32BE(offset);
    const type = buffer.toString("ascii", offset + 4, offset + 8);
    const data = buffer.subarray(offset + 8, offset + 8 + length);
    if (type === "IHDR") {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      bitDepth = data[8];
      colorType = data[9];
    } else if (type === "IDAT") {
      idat.push(data);
    } else if (type === "IEND") {
      break;
    }
    offset += 12 + length;
  }
  if (!width || !height || bitDepth !== 8 || colorType !== 6) {
    throw new Error(
      `不支持的 PNG 格式（bitDepth=${bitDepth}, colorType=${colorType}）`,
    );
  }
  const raw = inflateSync(Buffer.concat(idat));
  const stride = width * 4;
  const rgba = Buffer.alloc(width * height * 4);
  const prev = Buffer.alloc(stride);
  const paeth = (a: number, b: number, c: number): number => {
    const pa = Math.abs(b - c);
    const pb = Math.abs(a - c);
    const pc = Math.abs(a + b - 2 * c);
    return pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
  };
  let p = 0;
  for (let y = 0; y < height; y += 1) {
    const filter = raw[p];
    p += 1;
    const row = Buffer.alloc(stride);
    for (let x = 0; x < stride; x += 1) {
      const rawByte = raw[p];
      p += 1;
      const a = x >= 4 ? row[x - 4] : 0;
      const b = prev[x];
      const c = x >= 4 ? prev[x - 4] : 0;
      let v = rawByte;
      if (filter === 1) v = (rawByte + a) & 0xff;
      else if (filter === 2) v = (rawByte + b) & 0xff;
      else if (filter === 3) v = (rawByte + ((a + b) >> 1)) & 0xff;
      else if (filter === 4) v = (rawByte + paeth(a, b, c)) & 0xff;
      row[x] = v;
    }
    row.copy(rgba, y * stride);
    prev.set(row);
  }
  return { width, height, rgba };
}
