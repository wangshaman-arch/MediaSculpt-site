import path from "node:path";

/** 根据原始媒体路径定位 MediaInfo，保持 Windows、macOS/Linux 根路径不变。 */
export function mediaInfoDirectoryForSource(
  rawPath: string,
  mediaInfoDir = "MediaInfo",
): string {
  const isWindowsPath =
    /^[A-Za-z]:[\\/]/.test(rawPath) || rawPath.startsWith("\\\\");
  const pathApi = isWindowsPath ? path.win32 : path.posix;
  const normalized = pathApi.normalize(rawPath);
  const last = pathApi.basename(normalized);
  const isDiscContainer = /^(VIDEO_TS|BDMV|DVD|AUDIO_TS)$/i.test(last);
  const base =
    isDiscContainer || pathApi.extname(last)
      ? pathApi.dirname(normalized)
      : normalized;
  return pathApi.join(base, mediaInfoDir);
}
