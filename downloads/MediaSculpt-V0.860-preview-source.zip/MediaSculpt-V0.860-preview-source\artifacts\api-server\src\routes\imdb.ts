import { Router } from "express";
import { db, configTable } from "@workspace/db";
import { getImportStatus, runImdbImport } from "../lib/imdb-import";

const router = Router();

// GET /imdb/status — current import state + dataset stats
router.get("/imdb/status", async (_req, res) => {
  const live = getImportStatus();
  const rows = await db
    .select({
      imdbTitleCount: configTable.imdbTitleCount,
      imdbLastImportAt: configTable.imdbLastImportAt,
    })
    .from(configTable)
    .limit(1);
  const cfg = rows[0];
  return res.json({
    ...live,
    titleCount: cfg?.imdbTitleCount ?? 0,
    lastImportAt: cfg?.imdbLastImportAt?.toISOString() ?? null,
  });
});

// POST /imdb/import — start a background import of the IMDb TSV datasets.
// Optional body: local paths for any of the datasets (useful when
// datasets.imdbws.com is slow — download manually first). Omitted datasets
// fall back to the official URLs. Set withPeople: true to also populate
// directors/cast from title.crew + title.principals + name.basics.
router.post("/imdb/import", async (req, res) => {
  if (getImportStatus().status === "running") {
    return res.status(409).json({ error: "导入已在进行中" });
  }
  const body = (req.body ?? {}) as {
    basicsPath?: string;
    ratingsPath?: string;
    crewPath?: string;
    namesPath?: string;
    principalsPath?: string;
    withPeople?: boolean;
  };

  // Fire and forget — progress is polled via GET /imdb/status
  runImdbImport({
    basicsPath:
      typeof body.basicsPath === "string" && body.basicsPath
        ? body.basicsPath
        : undefined,
    ratingsPath:
      typeof body.ratingsPath === "string" && body.ratingsPath
        ? body.ratingsPath
        : undefined,
    crewPath:
      typeof body.crewPath === "string" && body.crewPath
        ? body.crewPath
        : undefined,
    namesPath:
      typeof body.namesPath === "string" && body.namesPath
        ? body.namesPath
        : undefined,
    principalsPath:
      typeof body.principalsPath === "string" && body.principalsPath
        ? body.principalsPath
        : undefined,
    withPeople: body.withPeople === true,
  }).catch(() => {
    /* error is captured in import status */
  });

  return res.status(202).json(getImportStatus());
});

export default router;
