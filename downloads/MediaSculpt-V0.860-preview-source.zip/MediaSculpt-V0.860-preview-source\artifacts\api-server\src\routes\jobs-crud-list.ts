import { Router } from "express";
import { db, jobsTable, jobLogsTable } from "@workspace/db";
import { and, desc, eq, inArray } from "drizzle-orm";
import { ListJobsQueryParams } from "@workspace/api-zod";

const router = Router();
router.get("/jobs", async (req, res) => {
  const parsed = ListJobsQueryParams.safeParse(req.query);
  const params = parsed.success ? parsed.data : { limit: 50 };

  const conditions = [];
  if (params.status) {
    conditions.push(eq(jobsTable.status, params.status));
  }

  const rows: Array<typeof jobsTable.$inferSelect> = await db
    .select()
    .from(jobsTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(jobsTable.createdAt))
    .limit(params.limit ?? 50);

  if (rows.length > 0) {
    const logRows = await db
      .select({
        jobId: jobLogsTable.jobId,
        message: jobLogsTable.message,
        createdAt: jobLogsTable.createdAt,
      })
      .from(jobLogsTable)
      .where(
        inArray(
          jobLogsTable.jobId,
          rows.map((row) => row.id),
        ),
      )
      .orderBy(desc(jobLogsTable.createdAt));
    const lastByJob = new Map<number, string>();
    for (const log of logRows) {
      if (!lastByJob.has(log.jobId)) lastByJob.set(log.jobId, log.message);
    }
    return res.json(
      rows.map((row) => ({ ...row, lastLog: lastByJob.get(row.id) ?? null })),
    );
  }

  return res.json(rows);
});

export const jobsCrudListRouter = router;
