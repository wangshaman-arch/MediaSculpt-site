import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  resolveAiEndpoint,
  resolveApiKey,
  testAiConnection,
} from "./ai-provider";

describe("AI provider connection test", () => {
  it("sends a minimal authenticated request without exposing the API key in diagnostics", async () => {
    const fetchMock = vi.fn(
      async () =>
        new Response(
          JSON.stringify({ choices: [{ message: { content: "pong" } }] }),
          { status: 200, headers: { "content-type": "application/json" } },
        ),
    );
    const result = await testAiConnection(
      {
        provider: "gemini",
        apiKey: "secret-gemini-key",
        model: "gemini-2.0-flash",
      },
      fetchMock as unknown as typeof fetch,
    );

    expect(result.connected).toBe(true);
    expect(result.provider).toBe("Gemini");
    expect(fetchMock).toHaveBeenCalledWith(
      "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
      expect.objectContaining({
        method: "POST",
        headers: expect.objectContaining({
          Authorization: "Bearer secret-gemini-key",
        }),
      }),
    );
    expect(JSON.stringify(result)).not.toContain("secret-gemini-key");
  });

  it("resolves database-shaped custom endpoint fields", () => {
    expect(
      resolveAiEndpoint({
        aiProvider: "custom",
        aiBaseUrl: "http://127.0.0.1:19090/v1",
        aiModel: "local-mock",
      }),
    ).toMatchObject({
      baseUrl: "http://127.0.0.1:19090/v1",
      model: "local-mock",
    });
  });
});

const ENV_KEY = "AI_INTEGRATIONS_OPENAI_API_KEY";

describe("resolveApiKey env fallback", () => {
  const original = process.env[ENV_KEY];

  beforeEach(() => {
    delete process.env[ENV_KEY];
  });

  afterEach(() => {
    if (original === undefined) delete process.env[ENV_KEY];
    else process.env[ENV_KEY] = original;
  });

  it("prefers the explicitly configured provider key over the env fallback", () => {
    process.env[ENV_KEY] = "env-key";
    expect(
      resolveApiKey({ aiProvider: "deepseek", deepseekApiKey: "cfg-key" }),
    ).toBe("cfg-key");
    expect(
      resolveApiKey({ aiProvider: "custom", openaiApiKey: "custom-key" }),
    ).toBe("custom-key");
  });

  it("falls back to the env-injected key when no key is configured", () => {
    process.env[ENV_KEY] = "env-key";
    expect(resolveApiKey({ aiProvider: "deepseek" })).toBe("env-key");
    expect(resolveApiKey({ aiProvider: "custom" })).toBe("env-key");
  });

  it("returns undefined when neither config nor env provides a key", () => {
    expect(resolveApiKey({ aiProvider: "deepseek" })).toBeUndefined();
    expect(resolveApiKey({ aiProvider: "custom" })).toBeUndefined();
  });
});
