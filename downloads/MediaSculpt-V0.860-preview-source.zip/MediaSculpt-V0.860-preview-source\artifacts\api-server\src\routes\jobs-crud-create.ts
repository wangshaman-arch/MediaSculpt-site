import { Router } from "express";
import fs from "fs/promises";
import { db, jobsTable } from "@workspace/db";
import { sql } from "drizzle-orm";
import { CreateJobBody } from "@workspace/api-zod";
import {
  createStandaloneTaskSnapshotV1,
  loadTaskSnapshot,
  prepareTaskSnapshotForJobCreation,
  serializeTaskSnapshot,
  taskSnapshotSummary,
  TaskSnapshotError,
  type TaskSnapshotSettings,
} from "../lib/task-snapshot";
import {
  defaultRemuxOutputDirectory,
  hasExecutableWorkflowSelection,
  normalizeRequestedProcessingMode,
  requiresWorkflowSelection,
} from "../lib/job-workflow";
import { normalizeDiscSourcePath } from "../lib/disc-analysis";
import { buildSourceManifest } from "../lib/source-manifest";
import { normalizeTitleEn } from "../lib/metadata";
import { resolveDvdVideoTsDir } from "../lib/disc";
import { resolveRuntimePath } from "../lib/runtime-paths";
import { resolveToolPath } from "../lib/tool-runtime";
import { appendRuntimeToolLog } from "../lib/runtime-tool-log";
import { verifyDvdTitle } from "../lib/dvd-remux";
import { addLog } from "../lib/job-logging";
import { discAnalysisRegistry } from "../lib/disc-analysis-registry";
import { isBlurayDisc, isDvdDisc, resolveMainTrack } from "../lib/disc";
import {
  defaultTaskSnapshotOutputMode,
  normalizePipelineSteps,
  parseTaskSnapshotIndexArray,
} from "./jobs-pipeline";
import { dvdVideoInputPath } from "./jobs-dvd";
import { ensureAnalysisIsoReady } from "./jobs-iso";
import { getConfig } from "./jobs-config";
import {
  SOURCE_DIRECTORY_VALUE,
  validateWritableDirectory,
} from "./jobs-output-paths";
import {
  reconcileMovieOverview,
  requestedWorkflowOutputFileName,
  resolveLlmRemuxPlanForCreate,
} from "./jobs-crud-helpers";

const router = Router();
router.post("/jobs", async (req, res) => {
  const parsed = CreateJobBody.safeParse(req.body);
  if (!parsed.success) {
    await appendRuntimeToolLog(
      `创建任务失败：请求体无效 ${JSON.stringify(parsed.error.flatten())}`,
    ).catch(() => {});
    return res.status(400).json({ error: "请求体无效" });
  }

  const {
    filePath,
    subtitleMode,
    ocrEngine,
    ocrLanguage,
    processingMode,
    mainTrackPath,
    selectedStreams,
    selectedChapters,
    selectionPlan,
    mediaType,
    analysisId,
    sourceFingerprint,
    selectedTitleId,
    outputMode,
    remuxExportCandidateIndex,
    forceSmartRemux,
    pipelineSteps,
    pipelineNames,
    compressionSettings,
  } = parsed.data;
  const config = await getConfig();
  // A workflow preset is selected per item. Freeze its concrete values into
  // this task before it enters the queue; later global setting changes must
  // not alter an already-created job.
  const taskSettings: TaskSnapshotSettings = {
    ...config,
    ...(compressionSettings ?? {}),
  };
  const workflowOutputFileName = requestedWorkflowOutputFileName(selectionPlan);
  let smartOutcome:
    | { invoked: boolean; applied: boolean; reason?: string }
    | undefined;
  const runtimeFilePath = resolveRuntimePath(filePath, config);
  let runtimeMainTrackPath = mainTrackPath
    ? resolveRuntimePath(mainTrackPath, config)
    : null;
  let normalizedMediaType = mediaType ?? "video";

  // ISO 镜像按光盘源处理：无论前端提交 bluray/dvd，都以 iso 类型执行（执行器会挂载镜像）。
  if (/\.iso$/i.test(runtimeFilePath)) normalizedMediaType = "iso";

  if (normalizedMediaType === "dvd" || (await isDvdDisc(runtimeFilePath))) {
    normalizedMediaType = "dvd";
    // The verified dvdvideo title is the only execution input. Do not resolve an
    // IFO/VOB "main track" here because that would reintroduce title guessing.
    runtimeMainTrackPath =
      (await resolveDvdVideoTsDir(runtimeFilePath)) ?? runtimeFilePath;
  } else if (
    normalizedMediaType === "bluray" ||
    (await isBlurayDisc(runtimeFilePath))
  ) {
    normalizedMediaType = "bluray";
    runtimeMainTrackPath =
      runtimeMainTrackPath ||
      (await resolveMainTrack(runtimeFilePath, "bluray"));
  }
  let normalizedProcessingMode = normalizeRequestedProcessingMode({
    mediaType: normalizedMediaType,
    processingMode: processingMode ?? "compress",
  });
  let normalizedSubtitleMode = subtitleMode ?? "auto";
  // 流水线（多选 压缩/Remux/仅字幕）：Remux 仅对光盘源有效；视频文件自动剔除 Remux。
  const normalizedPipelineSteps = normalizePipelineSteps(
    pipelineSteps,
    normalizedMediaType,
  );
  if (normalizedPipelineSteps.length > 0) {
    normalizedProcessingMode = normalizedPipelineSteps.includes("compress")
      ? "compress"
      : normalizedPipelineSteps.includes("remux")
        ? "remux"
        : "none";
    if (!normalizedPipelineSteps.includes("subtitle"))
      normalizedSubtitleMode = "skip";
  }

  const normalizedOutputMode =
    outputMode ??
    defaultTaskSnapshotOutputMode({
      processingMode: normalizedProcessingMode,
      subtitleMode: normalizedSubtitleMode,
    });
  if (
    !requiresWorkflowSelection(selectionPlan) &&
    !hasExecutableWorkflowSelection({
      processingMode: normalizedProcessingMode,
      subtitleMode: normalizedSubtitleMode,
      outputMode: normalizedOutputMode,
      pipelineSteps: normalizedPipelineSteps,
    })
  ) {
    return res.status(400).json({
      error:
        "未选择可执行的处理方式：请至少选择 Remux、压缩或字幕处理；如果只想保留原文件，请不要创建任务。",
    });
  }
  if (normalizedOutputMode === "both") {
    return res.status(400).json({
      error: "同时 Remux 和压缩的执行器将在下一阶段迁移；请先分别创建任务",
    });
  }

  const discTaskSourcePath =
    normalizedMediaType === "dvd"
      ? ((await resolveDvdVideoTsDir(runtimeFilePath)) ?? runtimeFilePath)
      : normalizeDiscSourcePath(runtimeFilePath);
  let taskSnapshot;
  try {
    const selectedStreamIndexes = parseTaskSnapshotIndexArray(selectedStreams);
    const selectedChapterIds = parseTaskSnapshotIndexArray(selectedChapters);
    if (
      normalizedMediaType === "dvd" ||
      normalizedMediaType === "bluray" ||
      normalizedMediaType === "iso"
    ) {
      if (
        !analysisId ||
        !sourceFingerprint ||
        !selectedTitleId ||
        !outputMode
      ) {
        return res.status(400).json({
          error:
            "光盘任务必须提交 analysisId、sourceFingerprint、selectedTitleId 和 outputMode；请重新分析后创建任务",
        });
      }
      // ISO analyses store the mounted drive path (e.g. E:\VIDEO_TS), while the
      // create request carries the ISO file path. Use the analysis' mounted
      // sourcePath (re-mounted on demand) so the snapshot matches the registry.
      const registeredAnalysis = discAnalysisRegistry.find(analysisId);
      const requestSourcePath = registeredAnalysis?.isoPath
        ? await ensureAnalysisIsoReady(registeredAnalysis)
        : discTaskSourcePath;
      // DVD Remux requires a verified title. Auto-verify it here (fresh, bypassing
      // any stale cached failure) so remux + bilingual just works instead of being
      // blocked by "title not verified / verification failed".
      if (
        registeredAnalysis?.mediaType === "dvd" &&
        normalizedOutputMode === "remux"
      ) {
        const targetTitle = registeredAnalysis.titles.find(
          (candidate) => candidate.titleId === selectedTitleId,
        );
        const titleNumber = targetTitle?.toolMappings.handbrakeTitleNumber;
        if (
          targetTitle &&
          targetTitle.verificationStatus !== "verified" &&
          typeof titleNumber === "number" &&
          titleNumber > 0
        ) {
          const ffprobeExecutable = await resolveToolPath("ffprobe");
          if (ffprobeExecutable) {
            const verification = await verifyDvdTitle({
              sourcePath: dvdVideoInputPath(registeredAnalysis.sourcePath),
              titleNumber,
              handbrakeDurationSeconds: targetTitle.durationSeconds,
              handbrakeChapterCount: targetTitle.chapterCount,
              handbrakeStreams: targetTitle.streams,
              ffprobeExecutable,
            }).catch(() => null);
            if (verification?.verified) {
              targetTitle.verificationStatus = "verified";
              targetTitle.verificationFailureReason = null;
              targetTitle.toolMappings.dvdVtsNumber = titleNumber;
              targetTitle.durationSeconds =
                verification.durationSeconds ?? targetTitle.durationSeconds;
              targetTitle.chapters = verification.chapters;
              targetTitle.chapterCount = verification.chapters.length;
              targetTitle.streams = verification.streams;
              targetTitle.videoTracks = verification.videoTracks;
              targetTitle.audioTracks = verification.audioTracks;
              targetTitle.subtitleTracks = verification.subtitleTracks;
              targetTitle.verificationWarnings = verification.warnings;
              discAnalysisRegistry.remember(registeredAnalysis);
              await appendRuntimeToolLog(
                `DVD Remux 自动验证成功 analysis=${analysisId} title=${titleNumber}`,
              ).catch(() => {});
            }
          }
        }
      }
      const smartResult = await resolveLlmRemuxPlanForCreate({
        analysis: registeredAnalysis,
        selectedTitleId,
        outputMode: normalizedOutputMode,
        config,
        forceSmartRemux,
      });
      smartOutcome = smartResult.outcome;
      taskSnapshot = prepareTaskSnapshotForJobCreation({
        registry: discAnalysisRegistry,
        request: {
          analysisId,
          sourcePath: requestSourcePath,
          sourceFingerprint,
          selectedTitleId,
          smartManifestId: (() => {
            try {
              const parsedPlan = selectionPlan
                ? (JSON.parse(selectionPlan) as { smartManifestId?: unknown })
                : {};
              return typeof parsedPlan.smartManifestId === "string"
                ? parsedPlan.smartManifestId
                : null;
            } catch {
              return null;
            }
          })(),
          outputMode: normalizedOutputMode,
          physicalVtsNumber:
            registeredAnalysis?.titles.find(
              (candidate) => candidate.titleId === selectedTitleId,
            )?.toolMappings.physicalVtsNumber ?? null,
          remuxExportCandidateIndex: remuxExportCandidateIndex ?? null,
          selectedStreamIndexes,
          selectedChapterIds,
          outputFileName: workflowOutputFileName,
          // 复杂光碟（结构含糊/多义）：把真实结构推给 LLM，用其校验过的流选择精确 remux。
          // 仅在 LLM 与该标题一致且经真实流校验通过时生效；任何失败一律回退确定性路径。
          llmRemuxPlan: smartResult.plan,
        },
        settings: taskSettings,
      }).snapshot;
    } else {
      taskSnapshot = createStandaloneTaskSnapshotV1({
        sourcePath: runtimeFilePath,
        sourceType: "video",
        outputMode: normalizedOutputMode,
        selectedStreamIndexes,
        selectedChapterIds,
        settings: taskSettings,
        outputFileName: workflowOutputFileName,
      });
    }
  } catch (error) {
    const code =
      error instanceof TaskSnapshotError ? error.code : "TASK_SNAPSHOT_INVALID";
    const detail = error instanceof Error ? error.message : String(error);
    if (code === "TASK_SNAPSHOT_ANALYSIS_NOT_FOUND") {
      const registered = discAnalysisRegistry.find(analysisId ?? "");
      await appendRuntimeToolLog(
        `创建任务诊断 analysisId=${analysisId ?? ""} registryFound=${Boolean(registered)} ` +
          `registrySource=${registered?.sourcePath ?? "n/a"} requestSource=${discTaskSourcePath} ` +
          `registryFp=${registered?.sourceFingerprint ?? "n/a"} requestFp=${sourceFingerprint ?? "n/a"}` +
          `requestFpLen=${String(sourceFingerprint ?? "").length} registryFpLen=${String(registered?.sourceFingerprint ?? "").length}`,
      ).catch(() => {});
    }
    await appendRuntimeToolLog(
      `创建任务失败：taskSnapshot ${code} source=${runtimeFilePath} detail=${detail}`,
    ).catch(() => {});
    return res.status(400).json({
      error: `创建任务失败：${code}。${detail !== code ? detail : "请重新分析并确认标题、流轨和章节选择。"}`,
    });
  }

  if (
    ["dvd", "bluray", "iso"].includes(normalizedMediaType) &&
    normalizedProcessingMode === "remux"
  ) {
    const remuxDirectory =
      taskSnapshot.output.directory === SOURCE_DIRECTORY_VALUE
        ? /\.iso$/i.test(runtimeFilePath)
          ? defaultRemuxOutputDirectory(runtimeFilePath, "iso")
          : defaultRemuxOutputDirectory(
              taskSnapshot.sourcePath,
              normalizedMediaType,
            )
        : resolveRuntimePath(taskSnapshot.output.directory, config);
    try {
      await validateWritableDirectory(remuxDirectory);
      await appendRuntimeToolLog(
        `Remux 输出目录已验证：${remuxDirectory}`,
      ).catch(() => {});
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      await appendRuntimeToolLog(
        `Remux 输出目录不可写：${remuxDirectory} ${reason}`,
      ).catch(() => {});
      return res
        .status(400)
        .json({ error: `Remux 输出目录不可用或不可写：${remuxDirectory}` });
    }
  }

  if (normalizedMediaType === "dvd" && normalizedProcessingMode === "remux") {
    const activeRows = await db
      .select()
      .from(jobsTable)
      .where(
        sql`${jobsTable.status} in ('pending', 'scanning', 'transcribing', 'compressing', 'remuxing')`,
      );
    const duplicate = activeRows.some((row: typeof jobsTable.$inferSelect) => {
      const activeSnapshot = loadTaskSnapshot(row);
      return (
        activeSnapshot?.sourceType === "dvd" &&
        activeSnapshot.outputMode === "remux" &&
        activeSnapshot.sourceFingerprint === taskSnapshot.sourceFingerprint &&
        activeSnapshot.selectedTitleId === taskSnapshot.selectedTitleId
      );
    });
    if (duplicate)
      return res
        .status(409)
        .json({ error: "同一 DVD 标题的 Remux 任务已在队列或运行中" });
  }

  // For regular video files, verify the file exists.
  // Remux jobs point to a disc directory — skip the file check (ffmpeg validates at runtime).
  if (normalizedProcessingMode !== "remux") {
    try {
      await fs.access(runtimeFilePath);
    } catch {
      await appendRuntimeToolLog(
        `创建任务失败：文件未找到 ${runtimeFilePath}`,
      ).catch(() => {});
      return res.status(400).json({ error: `文件未找到：${runtimeFilePath}` });
    }
  }

  // Optional confirmed movie metadata from the smart workflow identity.
  const rawBody = (req.body ?? {}) as Record<string, unknown>;
  const movieTitle =
    typeof rawBody.movieTitle === "string" && rawBody.movieTitle.trim()
      ? rawBody.movieTitle.trim()
      : null;
  const movieTitleEnRaw =
    typeof rawBody.movieTitleEn === "string" ? rawBody.movieTitleEn.trim() : "";
  const movieTitleEn =
    normalizeTitleEn(movieTitleEnRaw) || movieTitleEnRaw || null;
  const movieYear =
    typeof rawBody.movieYear === "number" && Number.isFinite(rawBody.movieYear)
      ? rawBody.movieYear
      : null;
  const movieImdbId =
    typeof rawBody.movieImdbId === "string" &&
    /^tt\d{7,8}$/i.test(rawBody.movieImdbId.trim())
      ? rawBody.movieImdbId.trim()
      : null;
  const movieOverview = reconcileMovieOverview(
    typeof rawBody.movieOverview === "string" && rawBody.movieOverview.trim()
      ? rawBody.movieOverview.trim()
      : null,
    movieImdbId,
  );
  const moviePoster =
    typeof rawBody.moviePoster === "string" && rawBody.moviePoster.trim()
      ? rawBody.moviePoster.trim()
      : null;

  // Persist the selected title's chapter times so the Remux chapter pass can
  // write the real chapter layout even after the in-memory analysis cache
  // expires (e.g. when a queued job runs later).
  let persistedSelectionPlan = selectionPlan;
  try {
    const chapterAnalysis = discAnalysisRegistry.find(taskSnapshot.analysisId);
    const chapterTitle = chapterAnalysis?.titles.find(
      (candidate) => candidate.titleId === taskSnapshot.selectedTitleId,
    );
    if (chapterTitle?.chapters && chapterTitle.chapters.length > 0) {
      const parsedPlan = selectionPlan
        ? (JSON.parse(selectionPlan) as Record<string, unknown>)
        : {};
      parsedPlan.chapterTimes = chapterTitle.chapters.map((chapter) => ({
        id: chapter.id,
        startSeconds: chapter.startSeconds,
        endSeconds: chapter.endSeconds,
      }));
      persistedSelectionPlan = JSON.stringify(parsedPlan);
    }
  } catch {
    persistedSelectionPlan = selectionPlan;
  }
  // 双语字幕的自定义参数写入 selectionPlan，供执行阶段读取。
  try {
    const customPlan = persistedSelectionPlan
      ? (JSON.parse(persistedSelectionPlan) as Record<string, unknown>)
      : {};
    let customChanged = false;
    if (
      rawBody.bilingualLayout === "zh-top" ||
      rawBody.bilingualLayout === "foreign-top"
    ) {
      customPlan.bilingualLayout = rawBody.bilingualLayout;
      customChanged = true;
    }
    if (customChanged) persistedSelectionPlan = JSON.stringify(customPlan);
  } catch {
    // 保持原 selectionPlan 不变。
  }

  const [job] = await db
    .insert(jobsTable)
    .values({
      filePath: runtimeFilePath,
      subtitleMode: normalizedSubtitleMode,
      ocrEngine: subtitleMode === "ocr" ? (ocrEngine ?? "auto") : null,
      ocrLanguage: subtitleMode === "ocr" ? (ocrLanguage ?? "auto") : null,
      generateReadme:
        typeof rawBody.generateReadme === "boolean"
          ? rawBody.generateReadme
          : false,
      generatePoster:
        typeof rawBody.generatePoster === "boolean"
          ? rawBody.generatePoster
          : false,
      generateReview:
        typeof rawBody.generateReview === "boolean"
          ? rawBody.generateReview
          : false,
      processingMode: normalizedProcessingMode,
      mediaType: normalizedMediaType,
      mainTrackPath: runtimeMainTrackPath,
      movieTitle,
      movieTitleEn,
      movieYear,
      movieImdbId,
      movieOverview,
      moviePoster,
      selectedStreams: selectedStreams ?? null,
      selectedChapters: selectedChapters ?? null,
      selectionPlan: persistedSelectionPlan ?? null,
      pipelineSteps:
        normalizedPipelineSteps.length > 0
          ? JSON.stringify({
              steps: normalizedPipelineSteps,
              names: {
                remux:
                  typeof pipelineNames?.remux === "string" &&
                  pipelineNames.remux.trim()
                    ? pipelineNames.remux.trim()
                    : null,
                compress:
                  typeof pipelineNames?.compress === "string" &&
                  pipelineNames.compress.trim()
                    ? pipelineNames.compress.trim()
                    : null,
              },
            })
          : null,
      taskSnapshot: serializeTaskSnapshot(taskSnapshot),
      taskSnapshotVersion: taskSnapshot.snapshotVersion,
      legacyTask: false,
      sourceManifest: JSON.stringify(
        buildSourceManifest({
          filePath: runtimeFilePath,
          mediaType: normalizedMediaType,
          mainTrackPath: runtimeMainTrackPath,
        }),
      ),
    })
    .returning();

  const snapshotSummary = taskSnapshotSummary(taskSnapshot);
  await addLog(
    job.id,
    "info",
    `任务快照已创建：version=${snapshotSummary.snapshotVersion} analysis=${snapshotSummary.analysisId} title=${snapshotSummary.selectedTitleId} mode=${snapshotSummary.outputMode} sourceStrategy=${snapshotSummary.compressionSourceStrategy} handbrake=${snapshotSummary.handbrakeTitleNumber ?? "n/a"}`,
  );
  await appendRuntimeToolLog(
    `创建任务成功：job=${job.id} mode=${normalizedProcessingMode} media=${normalizedMediaType} file=${runtimeFilePath} analysis=${snapshotSummary.analysisId} title=${snapshotSummary.selectedTitleId}`,
  ).catch(() => {});

  return res.status(201).json({
    ...job,
    snapshot: snapshotSummary,
    smartOutcome: smartOutcome ?? undefined,
  });
});

export const jobsCrudCreateRouter = router;
