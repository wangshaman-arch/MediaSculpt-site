// @vitest-environment jsdom
import { useState } from "react";
import { afterEach, describe, expect, it } from "vitest";
import { cleanup, render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import type { DiscStream } from "@workspace/api-client-react";
import { I18nProvider, useScanCopy } from "@/i18n";
import { zhCN } from "@/i18n/zh-CN";
import { canCreateDiscJobSelection } from "../disc-create-model";
import type { DiscTrackWithMakeMkv } from "../disc-display-model";
import { DiscAnalyzeFooter } from "./DiscAnalyzeFooter";
import { DiscSelectionSummary } from "./DiscSelectionSummary";
import { DiscTrackSelector } from "./DiscTrackSelector";

afterEach(cleanup);

function stream(index: number, codecType: DiscStream["codecType"]): DiscStream {
  return {
    index,
    codecType,
    codecName: codecType === "video" ? "h264" : "ac3",
  };
}

function dvdTrack(
  overrides: Partial<DiscTrackWithMakeMkv> & { name: string },
): DiscTrackWithMakeMkv {
  return {
    path: `D:/disc/${overrides.name}`,
    sizeBytes: 2_000_000_000,
    durationSeconds: 3600,
    titleId: overrides.name,
    streams: [stream(0, "video"), stream(1, "audio")],
    verificationStatus: "verified",
    dvdVtsNumber: 1,
    availabilityStatus: "confirmed",
    mappingStatus: "not-required",
    handbrakeTitleNumber: 1,
    ...overrides,
  };
}

const validTitle = dvdTrack({ name: "Title 1", titleId: "title-1" });
const unavailableTitle = dvdTrack({
  name: "Title 2",
  titleId: "title-2",
  availabilityStatus: "unavailable",
  availabilityFailureReason: "title source is gone",
});
const tracks: DiscTrackWithMakeMkv[] = [validTitle, unavailableTitle];

type HarnessProps = {
  trackList: DiscTrackWithMakeMkv[];
  resolveTrack: (index: number) => DiscTrackWithMakeMkv | undefined;
  initialSelected?: number[];
};

/** Wires the real disc components to the real create-gating model. */
function DiscGatingHarness({
  trackList,
  resolveTrack,
  initialSelected = [],
}: HarnessProps) {
  const uiText = useScanCopy();
  const [selected, setSelected] = useState<Set<number>>(
    () => new Set(initialSelected),
  );
  const [active, setActive] = useState(0);

  const selectedTracks = Array.from(selected).map((index) => {
    const resolved = resolveTrack(index);
    return {
      track: resolved,
      selectedStreams: resolved
        ? new Set(
            resolved.streams
              .filter((item) => item.codecType === "video")
              .map((item) => item.index),
          )
        : new Set<number>(),
      duplicate: false,
    };
  });

  const canCreate =
    selectedTracks.every((entry) => entry.track !== undefined) &&
    canCreateDiscJobSelection({
      allowJobCreation: true,
      hasData: true,
      processingMode: "remux",
      subtitleMode: "skip",
      selectedTitleCount: selected.size,
      creating: false,
      remuxBlocked: false,
      discType: "dvd",
      selectedTracks: selectedTracks.flatMap((entry) =>
        entry.track ? [{ ...entry, track: entry.track }] : [],
      ),
    });

  const selectedTrack = resolveTrack(active) ?? trackList[0];
  const selectedStreamIndices = new Set(
    selectedTrack?.streams
      .filter((item) => item.codecType === "video")
      .map((item) => item.index) ?? [],
  );

  return (
    <>
      <DiscTrackSelector
        uiText={uiText}
        tracks={trackList}
        selectedTrackIndices={selected}
        activeTrackIdx={active}
        verifyingTracks={new Set<number>()}
        discType="dvd"
        processingMode="remux"
        selectableTitleCount={
          trackList.filter(
            (track) => track.availabilityStatus !== "unavailable",
          ).length
        }
        remuxCapacity={null}
        onSelect={setActive}
        onToggleSelected={(index, isSelected) =>
          setSelected((current) => {
            const next = new Set(current);
            if (isSelected) next.add(index);
            else next.delete(index);
            return next;
          })
        }
        onSetAllTitles={(isSelected) =>
          setSelected(
            isSelected
              ? new Set(
                  trackList.flatMap((track, index) =>
                    track.availabilityStatus === "unavailable" ? [] : [index],
                  ),
                )
              : new Set(),
          )
        }
        isSelectionDisabled={(index) =>
          trackList[index]?.availabilityStatus === "unavailable"
        }
        isTrackVisible={() => true}
      />
      <DiscSelectionSummary
        uiText={uiText}
        selectedTrack={selectedTrack}
        selectedTitleCount={selected.size}
        selectedTrackIndices={selected}
        selectedStreamIndices={selectedStreamIndices}
        selectedChapterIds={new Set<number>()}
        verifyingTracks={new Set<number>()}
        processingLabel={uiText.modes.remux.label}
        analysisOnly={false}
        onSetAllStreamsForSelectedTitles={() => {}}
        expandedControls={<div data-testid="disc-expanded-controls" />}
      />
      <div data-testid="disc-gating-footer">
        <DiscAnalyzeFooter
          uiText={uiText}
          creating={false}
          canCreate={canCreate}
          showModePicker={false}
          modeChosen
          selectedTitleCount={selected.size}
          showModeRequired={false}
          onClose={() => {}}
          onCreate={() => {}}
        />
      </div>
    </>
  );
}

function renderHarness(props: HarnessProps) {
  return render(
    <I18nProvider lang="zh-CN">
      <DiscGatingHarness {...props} />
    </I18nProvider>,
  );
}

function createButton() {
  return within(screen.getByTestId("disc-gating-footer")).getAllByRole(
    "button",
  )[1];
}

describe("disc analyze create gating through the real components", () => {
  it("keeps create disabled until a valid DVD title is selected, then enables it", async () => {
    const user = userEvent.setup();
    renderHarness({ trackList: tracks, resolveTrack: (i) => tracks[i] });

    expect(createButton()).toBeDisabled();

    await user.click(screen.getAllByRole("checkbox")[0]);

    expect(createButton()).toBeEnabled();
  });

  it("enables create after the select-all control picks only selectable titles", async () => {
    const user = userEvent.setup();
    renderHarness({ trackList: tracks, resolveTrack: (i) => tracks[i] });

    await user.click(
      screen.getByRole("button", { name: zhCN.scan.selectAllTitles }),
    );

    expect(createButton()).toBeEnabled();
    expect(screen.getAllByRole("checkbox")[1]).toBeDisabled();
  });

  it("keeps create disabled when the selected title is unavailable", () => {
    renderHarness({
      trackList: tracks,
      resolveTrack: (i) => tracks[i],
      initialSelected: [1],
    });

    const button = createButton();
    expect(button).toBeDisabled();
    expect(button.textContent).toContain("1");
    expect(screen.getAllByRole("checkbox")[1]).toBeDisabled();
  });

  it("keeps create disabled when a selected title has no resolvable track", () => {
    renderHarness({
      trackList: [validTitle],
      resolveTrack: () => undefined,
      initialSelected: [0],
    });

    expect(createButton()).toBeDisabled();
  });
});
