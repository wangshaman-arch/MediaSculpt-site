import { describe, expect, it } from "vitest";
import {
  getAnalysisAction,
  getRetryPromptState,
  hasExistingAnalysis,
  preserveAnalysisAfterFailure,
} from "./assistant-analysis-state";

describe("assistant analysis interaction state", () => {
  it("opens the existing result instead of starting another request", () => {
    expect(getAnalysisAction({ hasResult: true, analyzing: false })).toBe(
      "show-existing",
    );
    expect(
      getAnalysisAction({
        hasResult: true,
        analyzing: false,
        retryRequested: true,
      }),
    ).toBe("analyze");
    expect(getAnalysisAction({ hasResult: false, analyzing: false })).toBe(
      "analyze",
    );
    expect(getAnalysisAction({ hasResult: true, analyzing: true })).toBe(
      "noop",
    );
  });

  it("opens and focuses the prompt when the user asks to search again", () => {
    expect(getRetryPromptState()).toEqual({
      promptOpen: true,
      focusPrompt: true,
    });
  });

  it("recognizes a persisted overview as an existing analysis", () => {
    expect(
      hasExistingAnalysis({
        analysisResult: null,
        persistedOverview: "已保存的简介",
      }),
    ).toBe(true);
    expect(
      hasExistingAnalysis({
        analysisResult: "当前简介",
        persistedOverview: null,
      }),
    ).toBe(true);
    expect(
      hasExistingAnalysis({ analysisResult: "  ", persistedOverview: "  " }),
    ).toBe(false);
  });

  it("keeps the previous result visible when a retry fails", () => {
    expect(preserveAnalysisAfterFailure("旧的影片简介", "网络错误")).toEqual({
      result: "旧的影片简介",
      error: "网络错误",
    });
  });
});
