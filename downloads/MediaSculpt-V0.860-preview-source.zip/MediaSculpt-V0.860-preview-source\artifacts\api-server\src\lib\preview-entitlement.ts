export type Edition = "development" | "preview";
export type PreviewBlockedReason =
  | "expired"
  | "quota_exhausted"
  | "clock_invalid";

export type PreviewPolicy = {
  taskLimit: number;
  trialDays: number;
};

export type PreviewEntitlementState = {
  edition: Edition;
  installationId: string;
  firstStartedAt: Date;
  lastSeenAt: Date;
  expiresAt: Date;
  taskLimit: number;
  successfulTaskCount: number;
  aiCallCount: number;
};

export type PreviewStatus = {
  edition: Edition;
  isActive: boolean;
  firstStartedAt: string;
  expiresAt: string | null;
  daysRemaining: number | null;
  taskLimit: number | null;
  successfulTaskCount: number;
  remainingTasks: number | null;
  aiCallCount: number;
  blockedReason: PreviewBlockedReason | null;
};

export class PreviewLimitError extends Error {
  constructor(
    public readonly errorCode: string,
    message: string,
    public readonly preview: PreviewStatus,
  ) {
    super(message);
    this.name = "PreviewLimitError";
  }
}

export function isPreviewLimitError(
  error: unknown,
): error is PreviewLimitError {
  return error instanceof PreviewLimitError;
}

export const DEFAULT_PREVIEW_POLICY: PreviewPolicy = {
  taskLimit: 20,
  trialDays: 30,
};

const DAY_MS = 24 * 60 * 60 * 1000;

export function createPreviewState(
  firstStartedAt: Date,
  installationId: string,
  policy: PreviewPolicy = DEFAULT_PREVIEW_POLICY,
): PreviewEntitlementState {
  return {
    edition: "preview",
    installationId,
    firstStartedAt,
    lastSeenAt: firstStartedAt,
    expiresAt: new Date(firstStartedAt.getTime() + policy.trialDays * DAY_MS),
    taskLimit: policy.taskLimit,
    successfulTaskCount: 0,
    aiCallCount: 0,
  };
}

export function evaluatePreviewStatus(
  state: PreviewEntitlementState,
  now: Date,
  policy: PreviewPolicy = DEFAULT_PREVIEW_POLICY,
): PreviewStatus {
  const daysRemaining = Math.max(
    0,
    Math.ceil((state.expiresAt.getTime() - now.getTime()) / DAY_MS),
  );
  if (state.edition === "development") {
    return {
      edition: "development",
      isActive: true,
      firstStartedAt: state.firstStartedAt.toISOString(),
      expiresAt: null,
      daysRemaining: null,
      taskLimit: null,
      successfulTaskCount: state.successfulTaskCount,
      remainingTasks: null,
      aiCallCount: state.aiCallCount,
      blockedReason: null,
    };
  }

  const blockedReason =
    now.getTime() < state.lastSeenAt.getTime()
      ? "clock_invalid"
      : now.getTime() >= state.expiresAt.getTime()
        ? "expired"
        : state.successfulTaskCount >= policy.taskLimit
          ? "quota_exhausted"
          : null;
  return {
    edition: "preview",
    isActive: blockedReason === null,
    firstStartedAt: state.firstStartedAt.toISOString(),
    expiresAt: state.expiresAt.toISOString(),
    daysRemaining,
    taskLimit: policy.taskLimit,
    successfulTaskCount: Math.max(0, state.successfulTaskCount),
    remainingTasks: Math.max(0, policy.taskLimit - state.successfulTaskCount),
    aiCallCount: Math.max(0, state.aiCallCount),
    blockedReason,
  };
}

export function previewErrorCode(reason: PreviewBlockedReason): string {
  return `PREVIEW_LIMIT_${reason === "expired" ? "EXPIRED" : reason === "quota_exhausted" ? "EXHAUSTED" : "CLOCK_INVALID"}`;
}
