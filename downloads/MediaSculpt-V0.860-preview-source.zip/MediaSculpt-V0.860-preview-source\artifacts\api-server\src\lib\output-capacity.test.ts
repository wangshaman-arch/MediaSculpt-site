import { describe, expect, it } from "vitest";
import {
  describeOutputCapacity,
  estimateOutputCapacity,
  MIN_OUTPUT_FREE_BYTES,
} from "./output-capacity";

describe("output capacity estimates", () => {
  it("reserves the full source payload for lossless remux", () => {
    const estimate = estimateOutputCapacity("remux", 10 * 1024 ** 3);
    expect(estimate.requiredFreeBytes).toBeGreaterThan(10 * 1024 ** 3);
    expect(estimate.mode).toBe("remux");
  });

  it("reserves both intermediate and final output for a combined pipeline", () => {
    const estimate = estimateOutputCapacity("both", 20 * 1024 ** 3);
    expect(estimate.requiredFreeBytes).toBeGreaterThan(25 * 1024 ** 3);
  });

  it("keeps a conservative floor when a network/disc source has no size", () => {
    expect(estimateOutputCapacity("compress", null).requiredFreeBytes).toBe(
      MIN_OUTPUT_FREE_BYTES,
    );
  });

  it("reports available and required space in a user-facing error", () => {
    const message = describeOutputCapacity(
      1_000_000_000,
      estimateOutputCapacity("remux", 4 * 1024 ** 3),
    );
    expect(message).toContain("可用 1.0 GB");
    expect(message).toContain("至少需要");
  });
});
