import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import { Button } from "@/components/ui/button";
import {
  Loader2,
  Maximize2,
  Pause,
  Play,
  RotateCcw,
  Volume2,
} from "lucide-react";
import { cn, formatDuration } from "@/lib/utils";
import { useI18n } from "@/i18n";
import { appendPreviewParams } from "./preview-url";
import { waitForSegmentReady } from "./preview-segment-wait";

export type PreviewSubtitleTrack = {
  index: number;
  label: string;
  disabled?: boolean;
  disabledHint?: string;
};

/**
 * 视频与字幕预览播放器：与任务详情页同一套实现
 * （转码流 + seek 重建 + 时长 meta + 字幕烧录 + 全屏 + 错误自动重试）。
 */
export type PreviewPlayerHandle = {
  rebuild: (seekSeconds: number, subIndex: number | null) => void;
  getCurrentTime: () => number;
};

/** 后端分段预览的固定片段时长（秒）。 */
const SEGMENT_SECONDS = 5;

export const PreviewPlayer = forwardRef<
  PreviewPlayerHandle,
  {
    src: string;
    metaUrl: string;
    subtitleTracks?: PreviewSubtitleTrack[];
    rawUrl?: string;
    /** 转码预览基址（字幕烧录 / 非原生可播格式使用）；缺省回退到 src */
    transcodeUrl?: string;
    /** src 是原生可播流（mp4/webm 等）：seek 直接定位，不重建转码 */
    nativeSeek?: boolean;
    /** 分段预览模式（后端按 5s 片段转码 + Range 随机访问）；光盘预览等直播流传 false。 */
    segmentMode?: boolean;
    className?: string;
    style?: CSSProperties;
    /** 叠加层（如 VTT 字幕文本覆盖），渲染在视频之上。 */
    overlay?: ReactNode;
    /** 字幕提示（文本字幕解析后的 cue）：由播放器按播放位置实时渲染，播放中持续跟随。 */
    subtitleCues?: Array<{ start: number; end: number; text: string }>;
    /** 自定义字幕选择控件（任务详情页的完整字幕列表）；传入时替代 subtitleTracks 按钮。 */
    extraControls?: ReactNode;
    /** 播放状态变化（用于外层工具栏收起等）。 */
    onPlayingChange?: (playing: boolean) => void;
  }
>(function PreviewPlayer(
  {
    src,
    metaUrl,
    subtitleTracks = [],
    rawUrl,
    transcodeUrl,
    nativeSeek,
    // 连续流是默认行为；只有明确需要分段随机访问时才启用分段模式。
    segmentMode = false,
    className,
    style,
    overlay,
    subtitleCues,
    extraControls,
    onPlayingChange,
  },
  ref,
) {
  const { t } = useI18n();
  const videoRef = useRef<HTMLVideoElement>(null);
  const previewStageRef = useRef<HTMLDivElement>(null);
  const [previewFailed, setPreviewFailed] = useState(false);
  const [previewPlaying, setPreviewPlaying] = useState(false);
  const [previewBuffering, setPreviewBuffering] = useState(false);
  const [previewTime, setPreviewTime] = useState(0);
  const [previewDuration, setPreviewDuration] = useState(0);
  const [previewControlsVisible, setPreviewControlsVisible] = useState(true);
  const previewControlsTimerRef = useRef<ReturnType<typeof setTimeout> | null>(
    null,
  );
  const previewSeekBaseRef = useRef(0);
  const previewSubBurnRef = useRef<number | null>(null);
  const seekInFlightRef = useRef(false);
  const previewRetryCountRef = useRef(0);
  const previewRetryTimerRef = useRef<ReturnType<typeof setTimeout> | null>(
    null,
  );
  const segmentModeRef = useRef(false);
  const advancingRef = useRef(false);
  const prefetchedStartRef = useRef(-1);
  const loadAbortRef = useRef<AbortController | null>(null);
  const seekingRef = useRef(false);
  const lastSeekCommitRef = useRef(0);
  const [previewErrorCode, setPreviewErrorCode] = useState<number | null>(null);
  const [previewUnavailable, setPreviewUnavailable] = useState(false);
  const [previewVolume, setPreviewVolume] = useState(1);
  const [videoAspect, setVideoAspect] = useState<string | null>(null);
  const transcodeBase = transcodeUrl ?? src;
  const rawBase = rawUrl ?? src;

  useImperativeHandle(ref, () => ({
    rebuild: rebuildPreviewStream,
    getCurrentTime: () => {
      const video = videoRef.current;
      return (
        previewSeekBaseRef.current +
        (video && Number.isFinite(video.currentTime) ? video.currentTime : 0)
      );
    },
  }));

  useEffect(() => {
    if (videoRef.current) videoRef.current.volume = previewVolume;
  }, [previewVolume]);

  // 时长校准：转码 fMP4 流没有时长头，进度条/时长显示以 meta 为准。
  useEffect(() => {
    let cancelled = false;
    setPreviewTime(0);
    setPreviewDuration(0);
    previewSeekBaseRef.current = 0;
    setPreviewFailed(false);
    setPreviewUnavailable(false);
    setPreviewErrorCode(null);
    fetch(metaUrl)
      .then((response) => {
        if (!response.ok) {
          if (!cancelled) {
            // A missing source is a permanent failure for this task, not a
            // transient codec error. Stop the automatic retry loop so the UI
            // reports the actionable state instead of flashing error code 4.
            previewRetryCountRef.current = 2;
            setPreviewBuffering(false);
            setPreviewFailed(true);
            setPreviewUnavailable(response.status === 404);
            setPreviewErrorCode(
              response.status === 404 ? null : response.status,
            );
          }
          return null;
        }
        if (!cancelled) setPreviewUnavailable(false);
        return response.json();
      })
      .then((body: { durationSeconds?: number | null } | null) => {
        if (!cancelled) setPreviewDuration(body?.durationSeconds ?? 0);
      })
      .catch(() => {
        if (!cancelled) setPreviewDuration(0);
      });
    return () => {
      cancelled = true;
    };
  }, [metaUrl]);

  const buildPreviewUrl = (seekSeconds: number, subIndex: number | null) => {
    const params: Record<string, string> = {};
    if (seekSeconds > 0) params.seek = seekSeconds.toFixed(2);
    if (subIndex !== null) params.sub = String(subIndex);
    return appendPreviewParams(transcodeBase, params);
  };

  // waitForSegmentReady lives in preview-segment-wait.ts so the timeout rule has a test.

  /**
   * 分段模式：定位到绝对时间 t，加载对应 5s 片段（#t= 片段内偏移），
   * 已生成片段由后端 Range 秒开；未生成片段轮询等待后播放。
   */
  const loadSegmentStream = async (
    absoluteTime: number,
    subIndex: number | null,
  ) => {
    const video = videoRef.current;
    if (!video) return;
    loadAbortRef.current?.abort();
    const controller = new AbortController();
    loadAbortRef.current = controller;
    if (nativeSeek && subIndex === null) {
      previewSeekBaseRef.current = 0;
      setPreviewTime(absoluteTime);
      setPreviewFailed(false);
      setPreviewBuffering(false);
      seekInFlightRef.current = false;
      video.currentTime = absoluteTime;
      void video.play().catch(() => {});
      return;
    }
    if (!segmentMode) {
      // 直播流模式（旧行为）：直接设置 src，由服务端重启转码。
      previewSeekBaseRef.current = absoluteTime;
      setPreviewTime(absoluteTime);
      setPreviewFailed(false);
      setPreviewBuffering(true);
      seekInFlightRef.current = true;
      video.src = buildPreviewUrl(absoluteTime, subIndex);
      video.load();
      return;
    }
    const t = Math.max(0, absoluteTime);
    const segStart = Math.floor(t / SEGMENT_SECONDS) * SEGMENT_SECONDS;
    const offset = t - segStart;
    const url = buildPreviewUrl(t, subIndex);
    const advancing = advancingRef.current;
    setPreviewTime(t);
    setPreviewFailed(false);
    seekInFlightRef.current = true;
    if (!advancing) {
      // 手动 seek / 初始加载：暂停旧片段，显示等待指示；自动续播则让旧片段继续播完。
      try {
        video.pause();
      } catch {
        /* ignore */
      }
      setPreviewBuffering(true);
    }
    const ready = await waitForSegmentReady(url, controller.signal);
    if (controller.signal.aborted || !videoRef.current) return;
    if (ready === "timeout") {
      // 等待预算耗尽：片段仍未就绪。明确报"预览超时"，而不是把未就绪的 URL
      // 交给 <video> 让它以一个看不懂的媒体错误码失败。
      setPreviewBuffering(false);
      seekInFlightRef.current = false;
      advancingRef.current = false;
      setPreviewFailed(true);
      return;
    }
    if (ready === "not-found") {
      // 已到视频结尾：不切换、不报错，保持当前画面。
      setPreviewBuffering(false);
      seekInFlightRef.current = false;
      advancingRef.current = false;
      return;
    }
    segmentModeRef.current = ready === "segment";
    if (ready === "legacy") {
      // 服务端不支持分段（如旧版/光盘直播流）：按直播方式加载。
      previewSeekBaseRef.current = t;
      setPreviewBuffering(true);
      video.src = url;
      video.load();
      return;
    }
    // 片段就绪后再更新基准时间，避免等待期间旧片段播放位置被错误换算。
    previewSeekBaseRef.current = segStart;
    prefetchedStartRef.current = -1;
    video.src = offset > 0 ? `${url}#t=${offset.toFixed(2)}` : url;
    video.load();
  };

  /**
   * 预取下一段：只发一次请求触发后端优先转码（已就绪则秒回），不切换播放。
   * 连续播放/短距快进时，下一段在需要切换前就已转完。
   */
  const prefetchSegment = (absoluteStart: number, subIndex: number | null) => {
    if (prefetchedStartRef.current === absoluteStart) return;
    prefetchedStartRef.current = absoluteStart;
    const url = buildPreviewUrl(absoluteStart, subIndex);
    void fetch(url, {
      headers: { Range: "bytes=0-0" },
      signal: loadAbortRef.current?.signal,
    })
      .then((response) => response.body?.cancel().catch(() => {}))
      .catch(() => {});
  };

  const rebuildPreviewStream = (
    seekSeconds: number,
    subIndex: number | null,
  ) => {
    void loadSegmentStream(seekSeconds, subIndex);
  };

  const reloadCurrentPreview = () => {
    const video = videoRef.current;
    if (!video) return;
    if (nativeSeek) {
      seekInFlightRef.current = false;
      setPreviewBuffering(true);
      setPreviewFailed(false);
      setPreviewErrorCode(null);
      video.src = rawBase;
      video.load();
      return;
    }
    const absoluteNow =
      previewSeekBaseRef.current +
      (Number.isFinite(video.currentTime) ? video.currentTime : 0);
    void loadSegmentStream(absoluteNow, previewSubBurnRef.current);
  };

  const retryPreviewPlayback = () => {
    previewRetryCountRef.current = 0;
    setPreviewUnavailable(false);
    if (previewRetryTimerRef.current)
      clearTimeout(previewRetryTimerRef.current);
    reloadCurrentPreview();
  };

  const togglePreviewPlayback = async () => {
    const video = videoRef.current;
    if (!video) return;
    // 无手势自动播放被浏览器以静音放行：此时点击播放按钮应“取消静音”而不是暂停。
    if (!video.paused && video.muted) {
      video.muted = false;
      video.volume = previewVolume;
      return;
    }
    if (video.paused) {
      video.muted = false;
      video.volume = previewVolume;
      await video.play().catch(() => {
        if (video.error && video.error.code !== 1) setPreviewFailed(true);
      });
    } else {
      video.pause();
    }
  };

  const seekPreview = (value: string) => {
    const nextTime = Number(value);
    if (Number.isFinite(nextTime)) setPreviewTime(nextTime);
  };

  const seekPreviewCommitted = (value: string) => {
    const rawTime = Math.max(0, Number(value) || 0);
    const video = videoRef.current;
    if (!video) return;
    const nextTime =
      previewDuration > 0 ? Math.min(rawTime, previewDuration) : rawTime;
    if (
      seekInFlightRef.current &&
      Math.abs(previewSeekBaseRef.current - nextTime) < 0.05
    ) {
      setPreviewTime(nextTime);
      return;
    }
    // 分段模式：目标仍在当前已加载片段内 → 直接定位播放，零重建零等待。
    const targetSegStart =
      Math.floor(nextTime / SEGMENT_SECONDS) * SEGMENT_SECONDS;
    if (
      segmentModeRef.current &&
      !seekInFlightRef.current &&
      Math.abs(previewSeekBaseRef.current - targetSegStart) < 0.05
    ) {
      setPreviewTime(nextTime);
      video.currentTime = nextTime - previewSeekBaseRef.current;
      if (!video.paused) void video.play().catch(() => {});
      return;
    }
    rebuildPreviewStream(nextTime, previewSubBurnRef.current);
  };

  /** 拖动/键盘提交（防抖：pointerup 与 mouseup 可能重复触发）。 */
  const commitSeek = (value: string) => {
    const now = Date.now();
    if (now - lastSeekCommitRef.current < 250) return;
    lastSeekCommitRef.current = now;
    seekingRef.current = false;
    seekPreviewCommitted(value);
  };

  const selectSubtitleTrack = (track: PreviewSubtitleTrack) => {
    const video = videoRef.current;
    const absoluteNow =
      previewSeekBaseRef.current +
      (video && Number.isFinite(video.currentTime) ? video.currentTime : 0);
    const next = previewSubBurnRef.current === track.index ? null : track.index;
    previewSubBurnRef.current = next;
    rebuildPreviewStream(absoluteNow, next);
  };

  const scheduleHidePreviewControls = () => {
    if (previewControlsTimerRef.current)
      clearTimeout(previewControlsTimerRef.current);
    if (!previewPlaying) return;
    previewControlsTimerRef.current = setTimeout(
      () => setPreviewControlsVisible(false),
      2400,
    );
  };

  const showPreviewControls = () => {
    setPreviewControlsVisible(true);
    scheduleHidePreviewControls();
  };

  const updatePreviewControlsForPointer = (clientY: number) => {
    const stage = previewStageRef.current;
    if (!stage) return;
    const rect = stage.getBoundingClientRect();
    const nearBottom = clientY >= rect.top + rect.height * 0.8;
    if (nearBottom) {
      showPreviewControls();
    } else {
      if (previewControlsTimerRef.current)
        clearTimeout(previewControlsTimerRef.current);
      setPreviewControlsVisible(false);
    }
  };

  const togglePreviewFullscreen = () => {
    // 全屏的是整个舞台容器（含视频 + 字幕叠加层 + 控件），而不是单独的 <video>；
    // 否则字幕叠加层是 <video> 的兄弟节点，全屏后不会显示。
    const stage = previewStageRef.current;
    if (!stage) return;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void stage.requestFullscreen?.();
  };

  useEffect(
    () => () => {
      if (previewControlsTimerRef.current)
        clearTimeout(previewControlsTimerRef.current);
      if (previewRetryTimerRef.current)
        clearTimeout(previewRetryTimerRef.current);
      loadAbortRef.current?.abort();
    },
    [],
  );

  // 页面/窗口隐藏时暂停播放并中止轮询与预取，避免多个客户端同时请求转码互相抢占。
  useEffect(() => {
    const onVisibility = () => {
      if (document.visibilityState !== "hidden") return;
      const video = videoRef.current;
      if (video && !video.paused) video.pause();
      loadAbortRef.current?.abort();
      advancingRef.current = false;
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => document.removeEventListener("visibilitychange", onVisibility);
  }, []);

  useEffect(() => {
    if (previewPlaying) scheduleHidePreviewControls();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [previewPlaying]);

  // 分段模式初始加载第 0 段；直播/原生模式保持声明式 src。
  useEffect(() => {
    if (nativeSeek) return;
    if (segmentMode) void loadSegmentStream(0, previewSubBurnRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ESC：退出全屏；非全屏时暂停，让预览缩回常规布局。左右方向键：前/后快进。
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        if (document.fullscreenElement) {
          void document.exitFullscreen().catch(() => {});
          return;
        }
        const video = videoRef.current;
        if (video && !video.paused) video.pause();
        return;
      }
      if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
      // 正在输入（如提示词框/标题框）或聚焦到滑块时，交给输入控件自己处理
      const target = event.target as HTMLElement | null;
      if (target && /^(INPUT|TEXTAREA|SELECT)$/i.test(target.tagName)) return;
      event.preventDefault();
      const video = videoRef.current;
      if (!video) return;
      const STEP = 10;
      const absoluteNow =
        previewSeekBaseRef.current +
        (Number.isFinite(video.currentTime) ? video.currentTime : 0);
      const raw = absoluteNow + (event.key === "ArrowRight" ? STEP : -STEP);
      const targetTime =
        previewDuration > 0
          ? Math.min(Math.max(0, raw), previewDuration)
          : Math.max(0, raw);
      seekPreviewCommitted(String(targetTime));
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [previewDuration]);

  return (
    <div
      ref={previewStageRef}
      className={cn(
        "group relative flex min-h-[260px] w-full min-w-0 items-center justify-center overflow-hidden rounded-lg border bg-black",
        className,
      )}
      style={{
        // 外层根据原始视频 DAR 传入的 aspectRatio 必须优先于转码流的
        // coded width/height。字幕烧录或双语字幕切换时，转码流尺寸可能
        // 改变；用它覆盖原始 DAR 会导致预览窗口和字幕位置突然变形。
        aspectRatio: style?.aspectRatio ?? videoAspect ?? "16 / 9",
        ...style,
      }}
      onMouseMove={(event) => updatePreviewControlsForPointer(event.clientY)}
      onMouseLeave={() => {
        if (previewControlsTimerRef.current)
          clearTimeout(previewControlsTimerRef.current);
        setPreviewControlsVisible(false);
      }}
      onClick={showPreviewControls}
      onDoubleClick={togglePreviewFullscreen}
      data-testid="preview-stage"
    >
      <video
        ref={videoRef}
        className="h-full max-h-full min-h-0 w-full bg-black object-contain"
        preload="metadata"
        src={
          previewUnavailable
            ? undefined
            : nativeSeek
              ? rawBase
              : segmentMode
                ? undefined
                : transcodeBase
        }
        onError={() => {
          if (previewUnavailable) return;
          const element = videoRef.current;
          if (element?.error && element.error.code !== 1) {
            if (previewRetryCountRef.current < 2) {
              const attempt = previewRetryCountRef.current + 1;
              previewRetryCountRef.current = attempt;
              if (previewRetryTimerRef.current)
                clearTimeout(previewRetryTimerRef.current);
              previewRetryTimerRef.current = setTimeout(() => {
                setPreviewBuffering(true);
                setPreviewFailed(false);
                const video = videoRef.current;
                if (video) {
                  const absoluteNow =
                    previewSeekBaseRef.current +
                    (Number.isFinite(video.currentTime)
                      ? video.currentTime
                      : 0);
                  void loadSegmentStream(
                    absoluteNow,
                    previewSubBurnRef.current,
                  );
                }
              }, 800 * attempt);
            } else {
              setPreviewBuffering(false);
              setPreviewFailed(true);
              setPreviewErrorCode(element.error.code);
            }
          }
        }}
        onCanPlay={() => {
          setPreviewBuffering(false);
          setPreviewFailed(false);
          setPreviewErrorCode(null);
          previewRetryCountRef.current = 0;
          advancingRef.current = false;
          if (seekInFlightRef.current) {
            seekInFlightRef.current = false;
            void videoRef.current?.play().catch(() => {});
          }
        }}
        onLoadStart={() => setPreviewBuffering(true)}
        onWaiting={() => setPreviewBuffering(true)}
        onStalled={() => setPreviewBuffering(true)}
        onPlaying={() => setPreviewBuffering(false)}
        onPlay={() => {
          setPreviewPlaying(true);
          onPlayingChange?.(true);
        }}
        onPause={() => {
          // 重建/切换转码流时会产生一次短暂的 pause，忽略它保持“播放中”布局，
          // 否则外层布局切换会让视频在重新加载时收缩成细条
          if (seekInFlightRef.current) return;
          setPreviewPlaying(false);
          onPlayingChange?.(false);
        }}
        onLoadedMetadata={(event) => {
          const duration = event.currentTarget?.duration;
          setPreviewDuration(
            (current) => current || (Number.isFinite(duration) ? duration : 0),
          );
          const element = event.currentTarget;
          if (element && element.videoWidth > 0 && element.videoHeight > 0) {
            setVideoAspect(`${element.videoWidth} / ${element.videoHeight}`);
          }
        }}
        onTimeUpdate={(event) => {
          // 拖动进度条期间不更新播放位置，避免滑块被播放进度拉回。
          if (seekingRef.current) return;
          const rawTime = Number.isFinite(event.currentTarget.currentTime)
            ? event.currentTarget.currentTime
            : 0;
          const current = previewSeekBaseRef.current + rawTime;
          // 0.2s 粒度更新，让进度块紧跟真实播放位置（避免整秒跳格/滞后）
          setPreviewTime((prev) =>
            Math.floor(prev * 5) === Math.floor(current * 5) ? prev : current,
          );
          // 分段模式：播放到前 20% 就预取下一段，给首次生成和磁盘写入留下余量。
          if (
            segmentModeRef.current &&
            !advancingRef.current &&
            !seekInFlightRef.current &&
            !event.currentTarget.paused &&
            rawTime >= SEGMENT_SECONDS * 0.2 &&
            previewDuration > previewSeekBaseRef.current + SEGMENT_SECONDS
          ) {
            prefetchSegment(
              previewSeekBaseRef.current + SEGMENT_SECONDS,
              previewSubBurnRef.current,
            );
          }
          // 分段模式：接近片段末尾自动切下一段，播放不中断。
          if (
            segmentModeRef.current &&
            !advancingRef.current &&
            !seekInFlightRef.current &&
            !event.currentTarget.paused &&
            rawTime >= SEGMENT_SECONDS - 0.5 &&
            previewDuration > previewSeekBaseRef.current + SEGMENT_SECONDS
          ) {
            advancingRef.current = true;
            void loadSegmentStream(
              previewSeekBaseRef.current + SEGMENT_SECONDS,
              previewSubBurnRef.current,
            );
          }
        }}
        onEnded={() => {
          if (
            segmentModeRef.current &&
            !advancingRef.current &&
            previewDuration > previewSeekBaseRef.current + SEGMENT_SECONDS
          ) {
            advancingRef.current = true;
            void loadSegmentStream(
              previewSeekBaseRef.current + SEGMENT_SECONDS,
              previewSubBurnRef.current,
            );
          }
        }}
      >
        {t("jobDetail.browserNoPreview")}
      </video>
      {previewBuffering && (
        <div className="pointer-events-none absolute inset-0 z-10 flex flex-col items-center justify-center gap-2 bg-black/40">
          <Loader2 className="h-8 w-8 animate-spin text-white/90" />
          <p className="text-xs text-white/90">
            {previewSubBurnRef.current !== null
              ? t("jobDetail.subtitleBurning")
              : t("jobDetail.previewBuffering")}
          </p>
        </div>
      )}
      {overlay}
      {typeof subtitleCues !== "undefined" &&
        (() => {
          const cue = subtitleCues.find(
            (item) => previewTime >= item.start && previewTime < item.end,
          );
          return cue ? (
            <div className="pointer-events-none absolute inset-x-0 bottom-10 z-10 flex justify-center px-4">
              <p
                className="max-w-[92%] whitespace-pre-line text-center text-lg font-medium leading-relaxed text-white sm:text-xl"
                style={{
                  textShadow:
                    "0 2px 4px rgba(0,0,0,0.95), 0 0 2px rgba(0,0,0,0.9), -1px -1px 0 rgba(0,0,0,0.85), 1px -1px 0 rgba(0,0,0,0.85), -1px 1px 0 rgba(0,0,0,0.85), 1px 1px 0 rgba(0,0,0,0.85)",
                }}
              >
                {cue.text}
              </p>
            </div>
          ) : null;
        })()}
      <div
        data-testid="preview-control-overlay"
        className={cn(
          "absolute inset-x-0 bottom-0 z-20 flex min-w-0 flex-wrap items-center gap-1 bg-gradient-to-t from-black/90 via-black/60 to-transparent px-2 pb-2 pt-8 transition-opacity",
          previewControlsVisible
            ? "opacity-100"
            : "pointer-events-none opacity-0",
        )}
        onMouseEnter={showPreviewControls}
        onMouseMove={showPreviewControls}
        onClick={(event) => event.stopPropagation()}
      >
        <Button
          type="button"
          variant="secondary"
          size="icon"
          className="h-8 w-8 shrink-0"
          onClick={() => void togglePreviewPlayback()}
          aria-label={t("jobDetail.playPauseAria")}
        >
          {previewPlaying ? (
            <Pause className="h-4 w-4" />
          ) : (
            <Play className="h-4 w-4" />
          )}
        </Button>
        <input
          type="range"
          min={0}
          max={previewDuration || 0}
          step={0.25}
          value={Math.min(previewTime, previewDuration || previewTime)}
          onChange={(event) => {
            seekingRef.current = true;
            seekPreview(event.currentTarget.value);
          }}
          onPointerUp={(event) => commitSeek(event.currentTarget.value)}
          onMouseUp={(event) => commitSeek(event.currentTarget.value)}
          onTouchEnd={(event) => commitSeek(event.currentTarget.value)}
          onKeyUp={(event) => commitSeek(event.currentTarget.value)}
          onBlur={(event) => commitSeek(event.currentTarget.value)}
          className="vx-range min-w-[90px] flex-[1_1_120px]"
          aria-label={t("jobDetail.previewProgressAria")}
        />
        {/* No max-width here: "current / total" reaches 17 characters for a
            feature-length title and was being ellipsised at 9rem. */}
        <span className="shrink-0 whitespace-nowrap font-mono text-[11px] text-white/80">
          {formatDuration(previewTime)} /{" "}
          {previewDuration ? formatDuration(previewDuration) : "--"}
        </span>
        <label
          className="flex shrink-0 items-center gap-1 text-white/80"
          title={t("jobDetail.volumeTitle")}
        >
          <Volume2 className="h-4 w-4" />
          <input
            type="range"
            min={0}
            max={1}
            step={0.05}
            value={previewVolume}
            onChange={(event) =>
              setPreviewVolume(Number(event.currentTarget.value))
            }
            className="vx-range w-20"
            aria-label={t("jobDetail.volumeTitle")}
          />
        </label>
        {/* Subtitle tracks and fullscreen form one right-aligned cluster so the
            fullscreen button cannot wrap onto its own row on narrow windows. */}
        <div className="ml-auto flex min-w-0 max-w-[70%] items-center gap-1">
          <div className="flex min-w-0 flex-1 items-center gap-1 overflow-x-auto scrollbar-none">
            {extraControls ??
              subtitleTracks.map((track) => (
                <button
                  key={track.index}
                  type="button"
                  disabled={track.disabled}
                  title={track.disabled ? track.disabledHint : track.label}
                  onClick={() => selectSubtitleTrack(track)}
                  className={cn(
                    "h-7 max-w-[10rem] shrink-0 truncate rounded-md border px-2 text-[11px] leading-none transition-colors disabled:cursor-not-allowed disabled:opacity-40",
                    previewSubBurnRef.current === track.index
                      ? "border-primary/60 bg-primary/20 text-primary"
                      : "border-white/20 text-white/80 hover:border-white/40 hover:text-white",
                  )}
                >
                  {track.label}
                </button>
              ))}
          </div>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="h-7 w-7 shrink-0 text-white hover:bg-white/15"
            onClick={togglePreviewFullscreen}
            aria-label={t("jobDetail.fullscreenAria")}
          >
            <Maximize2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
      {previewFailed && (
        <div className="absolute inset-x-0 bottom-0 z-30 bg-black/85 px-3 py-2 text-xs text-orange-400">
          <p>
            {previewUnavailable
              ? t("jobDetail.previewSourceMissing")
              : t("jobDetail.previewFallbackHint")}
            {previewErrorCode
              ? `（${t("jobDetail.previewErrorCode")} ${previewErrorCode}）`
              : ""}
          </p>
          <div className="mt-1 flex flex-wrap items-center gap-3">
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-7 text-[11px]"
              onClick={retryPreviewPlayback}
            >
              <RotateCcw className="mr-1 h-3.5 w-3.5" />
              {t("jobDetail.retryPreview")}
            </Button>
            {rawUrl && (
              <a
                className="text-primary underline underline-offset-2"
                href={rawUrl}
                target="_blank"
                rel="noreferrer"
              >
                {t("jobDetail.tryRawPreview")}
              </a>
            )}
          </div>
        </div>
      )}
    </div>
  );
});
