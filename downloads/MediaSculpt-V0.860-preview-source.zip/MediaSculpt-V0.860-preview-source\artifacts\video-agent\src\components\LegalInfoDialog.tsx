import { useEffect, useState } from "react";
import {
  Activity,
  BadgeCheck,
  BookOpen,
  Copyright,
  FileKey2,
  ShieldCheck,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useI18n } from "@/i18n";
import { PreviewStatusBar } from "@/components/PreviewStatusBar";

type LegalTab =
  | "about"
  | "license"
  | "third-party"
  | "privacy"
  | "rights"
  | "runtime";

export function LegalInfoDialog({
  open,
  onOpenChange,
  defaultTab = "about",
  version,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  defaultTab?: LegalTab;
  version: string;
}) {
  const { t } = useI18n();
  const [tab, setTab] = useState<LegalTab>(defaultTab);

  useEffect(() => {
    if (open) setTab(defaultTab);
  }, [defaultTab, open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[min(86vh,720px)] max-w-3xl overflow-hidden p-0">
        <DialogHeader className="border-b px-6 pb-4 pt-6 pr-12">
          <DialogTitle className="flex items-center gap-2">
            <Copyright className="h-5 w-5 text-primary" />
            {t("legal.title")}
          </DialogTitle>
          <DialogDescription>{t("legal.description")}</DialogDescription>
        </DialogHeader>
        <Tabs
          value={tab}
          onValueChange={(value) => setTab(value as LegalTab)}
          className="flex min-h-0 flex-col"
        >
          <div className="overflow-x-auto border-b px-4 py-2">
            <TabsList className="h-auto min-w-max justify-start">
              <TabsTrigger value="about" className="gap-1.5">
                <BadgeCheck className="h-3.5 w-3.5" />
                {t("legal.aboutTab")}
              </TabsTrigger>
              <TabsTrigger value="license" className="gap-1.5">
                <FileKey2 className="h-3.5 w-3.5" />
                {t("legal.licenseTab")}
              </TabsTrigger>
              <TabsTrigger value="third-party" className="gap-1.5">
                <BookOpen className="h-3.5 w-3.5" />
                {t("legal.thirdPartyTab")}
              </TabsTrigger>
              <TabsTrigger value="privacy" className="gap-1.5">
                <ShieldCheck className="h-3.5 w-3.5" />
                {t("legal.privacyTab")}
              </TabsTrigger>
              <TabsTrigger value="rights" className="gap-1.5">
                <Copyright className="h-3.5 w-3.5" />
                {t("legal.rightsTab")}
              </TabsTrigger>
              <TabsTrigger value="runtime" className="gap-1.5">
                <Activity className="h-3.5 w-3.5" />
                {t("legal.runtimeTab")}
              </TabsTrigger>
            </TabsList>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto px-6 py-5 text-sm leading-6 text-muted-foreground">
            <TabsContent value="about" className="mt-0 space-y-4">
              <section>
                <h3 className="text-base font-semibold text-foreground">
                  {t("legal.aboutHeading")}
                </h3>
                <p>{t("legal.aboutBody", { version })}</p>
              </section>
              <section>
                <h3 className="text-base font-semibold text-foreground">
                  {t("legal.aboutPurposeHeading")}
                </h3>
                <p>{t("legal.aboutPurposeBody")}</p>
              </section>
            </TabsContent>
            <TabsContent value="license" className="mt-0 space-y-4">
              <section>
                <h3 className="text-base font-semibold text-foreground">
                  {t("legal.licenseHeading")}
                </h3>
                <p>{t("legal.licenseBody")}</p>
              </section>
              <section>
                <h3 className="text-base font-semibold text-foreground">
                  {t("legal.previewHeading")}
                </h3>
                <p>{t("legal.previewBody")}</p>
              </section>
              <p className="rounded-md border bg-muted/30 px-3 py-2 text-xs">
                {t("legal.localFiles")}
              </p>
            </TabsContent>
            <TabsContent value="third-party" className="mt-0 space-y-4">
              <section>
                <h3 className="text-base font-semibold text-foreground">
                  {t("legal.thirdPartyHeading")}
                </h3>
                <p>{t("legal.thirdPartyBody")}</p>
              </section>
              <p className="rounded-md border bg-muted/30 px-3 py-2 text-xs">
                {t("legal.thirdPartyFiles")}
              </p>
            </TabsContent>
            <TabsContent value="privacy" className="mt-0 space-y-4">
              <section>
                <h3 className="text-base font-semibold text-foreground">
                  {t("legal.privacyHeading")}
                </h3>
                <p>{t("legal.privacyBody")}</p>
              </section>
              <section>
                <h3 className="text-base font-semibold text-foreground">
                  {t("legal.aiHeading")}
                </h3>
                <p>{t("legal.aiBody")}</p>
              </section>
            </TabsContent>
            <TabsContent value="rights" className="mt-0 space-y-4">
              <section>
                <h3 className="text-base font-semibold text-foreground">
                  {t("legal.rightsHeading")}
                </h3>
                <p>{t("legal.rightsBody")}</p>
              </section>
              <section>
                <h3 className="text-base font-semibold text-foreground">
                  {t("legal.disclaimerHeading")}
                </h3>
                <p>{t("legal.disclaimerBody")}</p>
              </section>
            </TabsContent>
            <TabsContent value="runtime" className="mt-0 space-y-4">
              <section>
                <h3 className="text-base font-semibold text-foreground">
                  {t("legal.runtimeHeading")}
                </h3>
                <p>{t("legal.runtimeDescription")}</p>
              </section>
              <PreviewStatusBar showDetails />
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
