import type { Dispatch, SetStateAction } from "react";
import { SubtitleModeSelector } from "./SubtitleModeSelector";
import { ScanOcrOptionsPanel } from "./ScanOcrOptionsPanel";
import { ScanBilingualSettingsPanel } from "./ScanBilingualSettingsPanel";
import type { ScanCopy } from "@/pages/Scan";
import type { SubtitleMode } from "@/hooks/useWorkbenchState";
import type { BilingualStyleDraft } from "./scan-bilingual-model";

type Translate = (
  path: string,
  params?: Record<string, string | number>,
) => string;

export function ScanSubtitleSection({
  uiText,
  t,
  subtitleMode,
  onSelectSubtitleMode,
  missingFor,
  promptMissing,
  toolLabel,
  bilingualSettingsOpen,
  onOpenBilingualSettings,
  onOpenToolSettings,
  ocrEngine,
  ocrLanguage,
  onOcrEngineChange,
  onOcrLanguageChange,
  bilingualDraft,
  setBilingualDraft,
  onSaveBilingualSettings,
  onCloseBilingualSettings,
}: {
  uiText: ScanCopy;
  t: Translate;
  subtitleMode: SubtitleMode;
  onSelectSubtitleMode: (mode: SubtitleMode) => void;
  missingFor: (mode: string) => string[];
  promptMissing: (mode: string) => boolean;
  toolLabel: (id: string) => string;
  bilingualSettingsOpen: boolean;
  onOpenBilingualSettings: () => void;
  onOpenToolSettings: () => void;
  ocrEngine: string;
  ocrLanguage: string;
  onOcrEngineChange: (value: string) => void;
  onOcrLanguageChange: (value: string) => void;
  bilingualDraft: BilingualStyleDraft | null;
  setBilingualDraft: Dispatch<SetStateAction<BilingualStyleDraft | null>>;
  onSaveBilingualSettings: () => void;
  onCloseBilingualSettings: () => void;
}) {
  return (
    <>
      <SubtitleModeSelector
        title={uiText.subtitleMode}
        activeMode={subtitleMode}
        labels={{
          auto: uiText.subtitleModes.auto.label,
          ocr: uiText.subtitleModes.ocr.label,
          extract: uiText.subtitleModes.extract.label,
          whisper: uiText.subtitleModes.whisper.label,
          transcribe_translate: uiText.subtitleModes.transcribe_translate.label,
          bilingual: uiText.subtitleModes.bilingual.label,
        }}
        descriptions={{
          auto: uiText.subtitleModes.auto.desc,
          ocr: uiText.subtitleModes.ocr.desc,
          extract: uiText.subtitleModes.extract.desc,
          whisper: uiText.subtitleModes.whisper.desc,
          transcribe_translate: uiText.subtitleModes.transcribe_translate.desc,
          bilingual: uiText.subtitleModes.bilingual.desc,
        }}
        onSelect={onSelectSubtitleMode}
        missingFor={missingFor}
        promptMissing={promptMissing}
        toolLabel={toolLabel}
        missingToolText={(tools) => t("scan.missingToolInline", { tools })}
        installToolsText={t("scan.goInstallTools")}
        bilingualEditTitle={t("scan.bilingualEditTitle")}
        bilingualSettingsOpen={bilingualSettingsOpen}
        onOpenBilingualSettings={onOpenBilingualSettings}
        onOpenToolSettings={onOpenToolSettings}
      />
      {subtitleMode === "ocr" && (
        <ScanOcrOptionsPanel
          t={t}
          ocrEngine={ocrEngine}
          ocrLanguage={ocrLanguage}
          onOcrEngineChange={onOcrEngineChange}
          onOcrLanguageChange={onOcrLanguageChange}
        />
      )}
      {bilingualSettingsOpen && bilingualDraft && (
        <ScanBilingualSettingsPanel
          t={t}
          draft={bilingualDraft}
          setDraft={setBilingualDraft}
          onSave={onSaveBilingualSettings}
          onClose={onCloseBilingualSettings}
        />
      )}
    </>
  );
}
